package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x64,0x6F,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_doMain;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_loadIds;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_singleCC = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_doMain = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevp_saveIds = be.BECS_Runtime.boolFalse;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevt_2_ta_ph = beva_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_2));
bevt_4_ta_ph = beva_name.bem_ends_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 102*/
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_ta_ph = beva_arg.bem_swap_2(bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bem_main_1(bevl__args);
bevt_1_ta_ph.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_ta_ph );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_ta_ph = bevp_params.bem_get_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 120*/ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 120*/ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 120*/
 else /* Line: 120*/ {
break;
} /* Line: 120*/
} /* Line: 120*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try /* Line: 129*/ {
bem_config_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 133*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-547430364);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_5_BuildBuild_bels_9));
bevp_buildMessage = bevt_1_ta_ph.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 138*/
if (bevp_printSteps.bevi_bool)/* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 140*/ {
if (bevl_buildFailed.bevi_bool)/* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 140*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 140*/ {
bevp_buildMessage.bem_print_0();
} /* Line: 141*/
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bevp_platform.bemd_0(732032425);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1912890932, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 147*/ {
} /* Line: 147*/
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_ta_loop = null;
BEC_2_6_6_SystemObject bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_6_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_2_4_IOFile bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_2_4_IOFile bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_108_ta_ph = null;
BEC_2_4_6_TextString bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_9_4_ContainerList bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_5_4_LogicBool bevt_127_ta_ph = null;
BEC_2_9_4_ContainerList bevt_128_ta_ph = null;
BEC_2_9_4_ContainerList bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_5_4_LogicBool bevt_133_ta_ph = null;
BEC_2_2_4_IOFile bevt_134_ta_ph = null;
BEC_2_2_4_IOFile bevt_135_ta_ph = null;
BEC_2_5_4_LogicBool bevt_136_ta_ph = null;
BEC_2_2_4_IOFile bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_ta_ph = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 157*/ {
bevt_7_ta_ph = bevp_params.bem_get_1(bevl_bkey);
bevt_0_ta_loop = bevt_7_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 158*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 158*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(39409994);
bevt_10_ta_ph = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_ta_ph.bevi_bool) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 159*/ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_ta_ph);
} /* Line: 161*/
} /* Line: 159*/
 else /* Line: 158*/ {
break;
} /* Line: 158*/
} /* Line: 158*/
} /* Line: 158*/
bevt_14_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_nameGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_12_ta_ph = bevt_13_ta_ph.bem_equals_1(bevt_15_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 166*/ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 167*/
bevt_17_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_12));
bevt_16_ta_ph = bevp_params.bem_get_1(bevt_17_ta_ph);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_firstGet_0();
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_18_ta_ph = bevp_params.bem_has_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_20_ta_ph = bevp_params.bem_get_1(bevt_21_ta_ph);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_firstGet_0();
} /* Line: 171*/
 else /* Line: 172*/ {
bevp_exeName = bevp_libName;
} /* Line: 173*/
bevt_25_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_26_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_24_ta_ph = bevp_params.bem_get_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_firstGet_0();
bevt_22_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_ta_ph);
bevp_buildPath = bevt_22_ta_ph.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevp_buildPath.bem_addStep_1(bevt_27_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_32_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_30_ta_ph = bevp_params.bem_get_2(bevt_31_ta_ph, bevt_32_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_ta_ph);
bevp_includePath = bevt_28_ta_ph.bem_pathGet_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_18));
bevt_37_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_nameGet_0();
bevt_34_ta_ph = bevp_params.bem_get_2(bevt_35_ta_ph, bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_ta_ph );
bevt_40_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_41_ta_ph = bevp_platform.bemd_0(732032425);
bevt_39_ta_ph = bevp_params.bem_get_2(bevt_40_ta_ph, (BEC_2_4_6_TextString) bevt_41_ta_ph );
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_ta_ph );
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_45_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_43_ta_ph = bevp_params.bem_get_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_49_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_47_ta_ph = bevp_params.bem_get_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_firstGet_0();
bevp_doMain = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_53_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_51_ta_ph = bevp_params.bem_get_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_57_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_55_ta_ph = bevp_params.bem_get_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_54_ta_ph = bevt_55_ta_ph.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_54_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_26));
bevp_loadSyns = bevp_params.bem_get_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadIds = bevp_params.bem_get_1(bevt_59_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_60_ta_ph);
bevt_62_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_61_ta_ph = bevp_params.bem_get_1(bevt_62_ta_ph);
bevp_mainName = (BEC_2_4_6_TextString) bevt_61_ta_ph.bem_firstGet_0();
bevt_64_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_63_ta_ph = bevp_params.bem_get_1(bevt_64_ta_ph);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_firstGet_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_65_ta_ph);
if (bevp_usedLibrarysStr == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 192*/ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193*/
bevt_67_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_67_ta_ph);
if (bevp_closeLibrariesStr == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 196*/ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197*/
bevt_69_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_69_ta_ph);
if (bevp_deployFilesFrom == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 200*/ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201*/
bevt_71_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_71_ta_ph);
if (bevp_deployFilesTo == null) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 204*/ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_73_ta_ph);
if (bevp_extIncludes == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 208*/ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209*/
bevt_75_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_75_ta_ph);
if (bevp_ccObjArgs == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 212*/ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213*/
bevt_77_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_77_ta_ph);
if (bevp_extLibs == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 216*/ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217*/
bevt_79_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_79_ta_ph);
if (bevp_linkLibArgs == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 220*/ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221*/
bevt_81_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_81_ta_ph);
if (bevp_extLinkObjects == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 224*/ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 225*/
bevt_83_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_83_ta_ph);
if (bevp_emitFileHeader == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 228*/ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(654289104);
} /* Line: 229*/
bevt_85_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_85_ta_ph);
if (bevp_runArgs == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 232*/ {
bevp_runArgs = bevp_runArgs.bemd_0(654289104);
} /* Line: 233*/
 else /* Line: 234*/ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 235*/
bevt_87_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_88_ta_ph = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_87_ta_ph, bevt_88_ta_ph);
bevt_89_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_89_ta_ph, bevt_90_ta_ph);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_92_ta_ph);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_93_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_93_ta_ph);
if (bevl_pacm == null) {
bevt_94_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_94_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_96_ta_ph = bevl_pacm.bem_isEmptyGet_0();
if (bevt_96_ta_ph.bevi_bool) {
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
 else /* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 243*/ {
bevt_1_ta_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
/* Line: 244*/ {
bevt_97_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 244*/ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 245*/
 else /* Line: 244*/ {
break;
} /* Line: 244*/
} /* Line: 244*/
} /* Line: 244*/
bevt_98_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_98_ta_ph);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_100_ta_ph);
bevt_101_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_101_ta_ph);
bevt_102_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_51));
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitLangs = bevp_params.bem_get_1(bevt_104_ta_ph);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevp_emitFlags = bevp_params.bem_get_1(bevt_105_ta_ph);
bevp_emitChecks = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_106_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_106_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_106_ta_ph.bevi_bool)/* Line: 256*/ {
bevt_2_ta_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_107_ta_ph = bevt_2_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 257*/ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_ta_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 259*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
} /* Line: 257*/
bevt_109_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_110_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_108_ta_ph = bevp_params.bem_get_2(bevt_109_ta_ph, bevt_110_ta_ph);
bevp_compiler = (BEC_2_4_6_TextString) bevt_108_ta_ph.bem_firstGet_0();
bevt_112_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_113_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_111_ta_ph = bevp_params.bem_get_2(bevt_112_ta_ph, bevt_113_ta_ph);
bevp_makeName = (BEC_2_4_6_TextString) bevt_111_ta_ph.bem_firstGet_0();
bevt_116_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_115_ta_ph = bevt_116_ta_ph.bem_add_1(bevp_makeName);
bevt_117_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_114_ta_ph = bevp_params.bem_get_2(bevt_115_ta_ph, bevt_117_ta_ph);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_114_ta_ph.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 272*/ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 273*/
 else /* Line: 274*/ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 275*/
bevt_121_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_60));
bevt_120_ta_ph = bevl_outLang.bem_add_1(bevt_121_ta_ph);
bevt_122_ta_ph = bevp_platform.bemd_0(732032425);
bevt_119_ta_ph = bevt_120_ta_ph.bem_add_1(bevt_122_ta_ph);
bevl_platformSources = bevp_params.bem_get_1(bevt_119_ta_ph);
if (bevl_platformSources == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_124_ta_ph = bevp_params.bem_orderedGet_0();
bevt_124_ta_ph.bem_addAll_1(bevl_platformSources);
} /* Line: 284*/
bevt_126_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_125_ta_ph = bevl_outLang.bem_add_1(bevt_126_ta_ph);
bevl_langSources = bevp_params.bem_get_1(bevt_125_ta_ph);
if (bevl_langSources == null) {
bevt_127_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_127_ta_ph.bevi_bool)/* Line: 288*/ {
bevt_128_ta_ph = bevp_params.bem_orderedGet_0();
bevt_128_ta_ph.bem_addAll_1(bevl_langSources);
} /* Line: 289*/
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_129_ta_ph = bevp_params.bem_orderedGet_0();
bevt_3_ta_loop = bevt_129_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 293*/ {
bevt_130_ta_ph = bevt_3_ta_loop.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_130_ta_ph).bevi_bool)/* Line: 293*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_ta_loop.bemd_0(39409994);
bevt_131_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_131_ta_ph);
} /* Line: 294*/
 else /* Line: 293*/ {
break;
} /* Line: 293*/
} /* Line: 293*/
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(545600326);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_134_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_133_ta_ph = bevt_134_ta_ph.bem_existsGet_0();
if (bevt_133_ta_ph.bevi_bool) {
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 301*/ {
bevt_135_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_135_ta_ph.bem_makeDirs_0();
} /* Line: 302*/
if (bevp_emitFileHeader == null) {
bevt_136_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_136_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_136_ta_ph.bevi_bool)/* Line: 304*/ {
bevt_137_ta_ph = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_137_ta_ph.bem_readerGet_0();
bevt_138_ta_ph = bevl_emr.bemd_0(380783392);
bevp_emitFileHeader = bevt_138_ta_ph.bemd_0(494335874);
bevl_emr.bemd_0(-1794290543);
} /* Line: 307*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_ta_ph = bevl_toRet.bemd_1(-1372582381, bevp_nl);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1372582381, bevt_2_ta_ph);
bevt_3_ta_ph = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_ta_ph.bemd_1(-1372582381, bevt_3_ta_ph);
bevt_5_ta_ph = bevl_toRet.bemd_1(-1372582381, bevp_nl);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(-1372582381, bevt_6_ta_ph);
bevt_7_ta_ph = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_ta_ph.bemd_1(-1372582381, bevt_7_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 321*/ {
bevt_3_ta_ph = bevl_ci.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 321*/ {
bevl_clnode = bevl_ci.bemd_0(39409994);
bevt_5_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_ta_ph = bevl_clnode.bemd_0(-1046924633);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-1441285544);
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_10_ta_ph = bevl_clnode.bemd_0(-1046924633);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1743997957);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-547430364);
bevl_toEmit.bem_put_1(bevt_8_ta_ph);
bevt_11_ta_ph = bevp_emitData.bem_usedByGet_0();
bevt_14_ta_ph = bevl_clnode.bemd_0(-1046924633);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(1743997957);
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-547430364);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_ta_ph.bem_get_1(bevt_12_ta_ph);
if (bevl_usedBy == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_0_ta_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
/* Line: 327*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 327*/ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 328*/
 else /* Line: 327*/ {
break;
} /* Line: 327*/
} /* Line: 327*/
} /* Line: 327*/
bevt_17_ta_ph = bevp_emitData.bem_subClassesGet_0();
bevt_20_ta_ph = bevl_clnode.bemd_0(-1046924633);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(1743997957);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-547430364);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_ta_ph.bem_get_1(bevt_18_ta_ph);
if (bevl_subClasses == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_1_ta_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
/* Line: 333*/ {
bevt_22_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 333*/ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 334*/
 else /* Line: 333*/ {
break;
} /* Line: 333*/
} /* Line: 333*/
} /* Line: 333*/
} /* Line: 332*/
} /* Line: 323*/
 else /* Line: 321*/ {
break;
} /* Line: 321*/
} /* Line: 321*/
bevt_23_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 339*/ {
bevt_24_ta_ph = bevl_ci.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 339*/ {
bevl_clnode = bevl_ci.bemd_0(39409994);
bevt_25_ta_ph = bevl_clnode.bemd_0(-1046924633);
bevt_29_ta_ph = bevl_clnode.bemd_0(-1046924633);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(1743997957);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-547430364);
bevt_26_ta_ph = bevl_toEmit.bem_has_1(bevt_27_ta_ph);
bevt_25_ta_ph.bemd_1(-37857520, bevt_26_ta_ph);
} /* Line: 341*/
 else /* Line: 339*/ {
break;
} /* Line: 339*/
} /* Line: 339*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_emitCommon == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 352*/ {
return bevp_emitCommon;
} /* Line: 353*/
if (bevp_emitLangs == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 358*/ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_64));
bevt_2_ta_ph = bevl_emitLang.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 360*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 361*/
 else /* Line: 360*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_4_ta_ph = bevl_emitLang.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 362*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 363*/
 else /* Line: 360*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_6_ta_ph = bevl_emitLang.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 364*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 365*/
 else /* Line: 360*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_67));
bevt_8_ta_ph = bevl_emitLang.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 366*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 367*/
 else /* Line: 370*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_10_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 371*/
} /* Line: 360*/
} /* Line: 360*/
} /* Line: 360*/
return bevp_emitCommon;
} /* Line: 373*/
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_2_6_10_SystemSerializer bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_7_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_69));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_lsp);
bevt_0_ta_ph.bem_print_0();
bevt_2_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_ta_ph.bem_now_0();
bevt_4_ta_ph = bevl_synEmitPath.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_ta_ph.bemd_0(380783392);
bevt_5_ta_ph = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_ta_ph.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevt_6_ta_ph.bem_addValue_1(bevl_scls);
bevt_8_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_now_0();
bevl_sse = bevt_7_ta_ph.bem_subtract_1(bevl_sst);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_sse);
bevt_9_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_22_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_25_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_26_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_27_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_28_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_29_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_30_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_43_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_82_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
bevt_5_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_ta_ph.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 396*/ {
bevt_0_ta_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
/* Line: 397*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 397*/ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 398*/
 else /* Line: 397*/ {
break;
} /* Line: 397*/
} /* Line: 397*/
} /* Line: 397*/
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 402*/ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool)/* Line: 405*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_libName);
bevt_9_ta_ph.bem_print_0();
} /* Line: 406*/
} /* Line: 405*/
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_ta_loop = bevp_usedLibrarysStr.bemd_0(884317404);
while (true)
/* Line: 411*/ {
bevt_11_ta_ph = bevt_1_ta_loop.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 411*/ {
bevl_ups = bevt_1_ta_loop.bemd_0(39409994);
bevt_13_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 412*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 415*/
} /* Line: 412*/
 else /* Line: 411*/ {
break;
} /* Line: 411*/
} /* Line: 411*/
bevt_2_ta_loop = bevp_closeLibrariesStr.bemd_0(884317404);
while (true)
/* Line: 418*/ {
bevt_14_ta_ph = bevt_2_ta_loop.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 418*/ {
bevl_ups = bevt_2_ta_loop.bemd_0(39409994);
bevt_16_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_ta_ph.bevi_bool) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 419*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_ta_ph = bevl_pack.bemd_0(331922877);
bevp_closeLibraries.bem_put_1(bevt_17_ta_ph);
} /* Line: 423*/
} /* Line: 419*/
 else /* Line: 418*/ {
break;
} /* Line: 418*/
} /* Line: 418*/
if (bevp_parse.bevi_bool)/* Line: 426*/ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
/* Line: 429*/ {
bevt_18_ta_ph = bevl_i.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 429*/ {
bevl_tb = bevl_i.bemd_0(39409994);
bevt_20_ta_ph = bevl_tb.bemd_0(-547430364);
bevt_19_ta_ph = bevl_built.bem_has_1(bevt_20_ta_ph);
if (!(bevt_19_ta_ph.bevi_bool))/* Line: 432*/ {
bevt_21_ta_ph = bevl_tb.bemd_0(-547430364);
bevl_built.bem_put_1(bevt_21_ta_ph);
bem_doParse_1(bevl_tb);
} /* Line: 434*/
} /* Line: 432*/
 else /* Line: 429*/ {
break;
} /* Line: 429*/
} /* Line: 429*/
bem_buildSyns_1(bevl_em);
} /* Line: 437*/
bevt_23_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_now_0();
bevp_parseTime = bevt_22_ta_ph.bem_subtract_1(bevp_startTime);
bevt_25_ta_ph = bem_emitCommonGet_0();
if (bevt_25_ta_ph == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 443*/ {
bevt_26_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_ta_ph.bem_now_0();
bevt_27_ta_ph = bem_emitCommonGet_0();
bevt_27_ta_ph.bem_doEmit_0();
bevt_29_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_28_ta_ph.bem_subtract_1(bevp_startTime);
bevt_31_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_now_0();
bevl_emitTime = bevt_30_ta_ph.bem_subtract_1(bevl_emitStart);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevp_parseTime);
bevt_32_ta_ph.bem_print_0();
bevt_35_ta_ph = (new BEC_2_4_6_TextString(30, bece_BEC_2_5_5_BuildBuild_bels_73));
bevt_34_ta_ph = bevt_35_ta_ph.bem_add_1(bevl_emitTime);
bevt_34_ta_ph.bem_print_0();
bevt_37_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_36_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_38_ta_ph;
} /* Line: 452*/
if (bevp_doEmit.bevi_bool)/* Line: 454*/ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-1379085270);
bevt_39_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 458*/ {
bevt_40_ta_ph = bevl_ci.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 458*/ {
bevl_clnode = bevl_ci.bemd_0(39409994);
bevl_em.bemd_1(1027797519, bevl_clnode);
} /* Line: 460*/
 else /* Line: 458*/ {
break;
} /* Line: 458*/
} /* Line: 458*/
bevl_em.bemd_0(333730766);
bevl_em.bemd_0(-1877934042);
bevt_41_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 464*/ {
bevt_42_ta_ph = bevl_ci.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 464*/ {
bevl_clnode = bevl_ci.bemd_0(39409994);
bevl_em.bemd_1(-149095231, bevl_clnode);
} /* Line: 466*/
 else /* Line: 464*/ {
break;
} /* Line: 464*/
} /* Line: 464*/
} /* Line: 464*/
bevt_44_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_ta_ph = bevt_44_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_43_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 471*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevp_parseTime);
bevt_46_ta_ph.bem_print_0();
} /* Line: 472*/
bevt_49_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_48_ta_ph.bem_print_0();
if (bevp_prepMake.bevi_bool)/* Line: 475*/ {
bevl_em.bemd_1(-1477489094, bevp_deployLibrary);
} /* Line: 477*/
if (bevp_make.bevi_bool)/* Line: 480*/ {
if (bevp_genOnly.bevi_bool) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 481*/ {
bevl_em.bemd_1(-291197992, bevp_deployLibrary);
bevl_em.bemd_1(852940741, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool)/* Line: 484*/ {
bevt_3_ta_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
/* Line: 485*/ {
bevt_51_ta_ph = bevt_3_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 485*/ {
bevl_bp = bevt_3_ta_loop.bem_nextGet_0();
bevt_52_ta_ph = bevl_bp.bemd_0(-1379085270);
bevl_cpFrom = bevt_52_ta_ph.bemd_0(-2073635628);
bevt_53_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_ta_ph.bem_copy_0();
bevt_55_ta_ph = bevl_cpFrom.bemd_0(-216140457);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(-1196171602);
bevl_cpTo.bemd_1(247160293, bevt_54_ta_ph);
bevt_57_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(-782518873);
if (((BEC_2_5_4_LogicBool) bevt_56_ta_ph).bevi_bool)/* Line: 489*/ {
bevt_58_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevt_58_ta_ph.bemd_0(-2120927596);
} /* Line: 490*/
bevt_61_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(-782518873);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(1598647137);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 492*/ {
bevt_62_ta_ph = bevl_cpFrom.bemd_0(-1531348784);
bevt_63_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevl_em.bemd_2(-148645367, bevt_62_ta_ph, bevt_63_ta_ph);
} /* Line: 493*/
} /* Line: 492*/
 else /* Line: 485*/ {
break;
} /* Line: 485*/
} /* Line: 485*/
} /* Line: 485*/
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
/* Line: 500*/ {
bevt_64_ta_ph = bevl_fIter.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_65_ta_ph = bevl_tIter.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_65_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 500*/
 else /* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 500*/ {
bevt_66_ta_ph = bevl_fIter.bemd_0(39409994);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_ta_ph );
bevt_71_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_ta_ph = bevt_71_ta_ph.bem_copy_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_toString_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_68_ta_ph = bevt_69_ta_ph.bem_add_1(bevt_72_ta_ph);
bevt_73_ta_ph = bevl_tIter.bemd_0(39409994);
bevt_67_ta_ph = bevt_68_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_ta_ph);
bevt_75_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevt_74_ta_ph = bevt_75_ta_ph.bemd_0(-782518873);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 504*/ {
bevt_76_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevt_76_ta_ph.bemd_0(-2120927596);
} /* Line: 505*/
bevt_79_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(-782518873);
bevt_77_ta_ph = bevt_78_ta_ph.bemd_0(1598647137);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 507*/ {
bevt_80_ta_ph = bevl_cpFrom.bemd_0(-1531348784);
bevt_81_ta_ph = bevl_cpTo.bemd_0(-1531348784);
bevl_em.bemd_2(-148645367, bevt_80_ta_ph, bevt_81_ta_ph);
} /* Line: 508*/
} /* Line: 507*/
 else /* Line: 500*/ {
break;
} /* Line: 500*/
} /* Line: 500*/
} /* Line: 500*/
} /* Line: 481*/
bevt_83_ta_ph = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_ta_ph = bevt_83_ta_ph.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 515*/ {
bevt_86_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_5_BuildBuild_bels_72));
bevt_85_ta_ph = bevt_86_ta_ph.bem_add_1(bevp_parseTime);
bevt_85_ta_ph.bem_print_0();
} /* Line: 516*/
if (bevp_parseEmitTime == null) {
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 518*/ {
bevt_89_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_5_BuildBuild_bels_74));
bevt_88_ta_ph = bevt_89_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_88_ta_ph.bem_print_0();
} /* Line: 519*/
if (bevp_parseEmitCompileTime == null) {
bevt_90_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_90_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_92_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_5_BuildBuild_bels_75));
bevt_91_ta_ph = bevt_92_ta_ph.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_ta_ph.bem_print_0();
} /* Line: 522*/
if (bevp_run.bevi_bool)/* Line: 525*/ {
bevt_93_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_76));
bevt_93_ta_ph.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(1393165030, bevp_deployLibrary, bevp_runArgs);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_77));
bevt_95_ta_ph = bevt_96_ta_ph.bem_add_1(bevl_result);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_78));
bevt_94_ta_ph = bevt_95_ta_ph.bem_add_1(bevt_97_ta_ph);
bevt_94_ta_ph.bem_print_0();
return bevl_result;
} /* Line: 529*/
bevt_98_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_98_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 535*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 535*/ {
bevl_kls = bevl_ci.bemd_0(39409994);
bevt_2_ta_ph = bevl_kls.bemd_0(-1046924633);
bevt_2_ta_ph.bemd_1(35378670, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(35378670, bevp_libName);
} /* Line: 539*/
 else /* Line: 535*/ {
break;
} /* Line: 535*/
} /* Line: 535*/
bevt_3_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 541*/ {
bevt_4_ta_ph = bevl_ci.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 541*/ {
bevl_kls = bevl_ci.bemd_0(39409994);
bevt_5_ta_ph = bevl_kls.bemd_0(-1046924633);
bevl_syn = bevt_5_ta_ph.bemd_0(1147987750);
bevl_syn.bemd_2(1178638524, this, bevl_kls);
bevl_syn.bemd_1(-58705034, this);
} /* Line: 545*/
 else /* Line: 541*/ {
break;
} /* Line: 541*/
} /* Line: 541*/
bevt_6_ta_ph = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevt_2_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1147987750);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 551*/ {
bevt_4_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(1147987750);
return bevt_3_ta_ph;
} /* Line: 552*/
bevt_5_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_5_ta_ph.bemd_1(35378670, bevp_libName);
bevt_8_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(561831802);
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 555*/ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 556*/
 else /* Line: 557*/ {
bevt_9_ta_ph = bevp_emitData.bem_classesGet_0();
bevt_12_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(561831802);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-547430364);
bevl_pklass = bevt_9_ta_ph.bem_get_1(bevt_10_ta_ph);
if (bevl_pklass == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 560*/ {
bevt_14_ta_ph = bevl_pklass.bemd_0(-1046924633);
bevt_14_ta_ph.bemd_1(35378670, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 562*/
 else /* Line: 563*/ {
bevt_16_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(561831802);
bevl_psyn = bem_getSynNp_1(bevt_15_ta_ph);
} /* Line: 566*/
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 568*/
bevt_17_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_17_ta_ph.bemd_1(1501728928, bevl_syn);
bevt_20_ta_ph = beva_klass.bemd_0(-1046924633);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(1743997957);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-547430364);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_ta_ph , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_nps = beva_np.bemd_0(-547430364);
bevt_0_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_ta_ph.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 578*/ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 579*/
bevt_2_ta_ph = bem_emitterGet_0();
bevl_syn = bevt_2_ta_ph.bemd_1(-1950994511, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_sharedEmitter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 594*/ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 595*/
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_ta_ph.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool)/* Line: 608*/ {
if (bevp_printSteps.bevi_bool)/* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 609*/ {
if (bevp_printPlaces.bevi_bool)/* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 609*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 609*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_79));
bevt_5_ta_ph = beva_toParse.bemd_0(-547430364);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_3_ta_ph.bem_print_0();
} /* Line: 610*/
bevp_fromFile = beva_toParse;
bevt_8_ta_ph = beva_toParse.bemd_0(-1531348784);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-696848978);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(380783392);
bevl_src = bevt_6_ta_ph.bemd_1(-1242295248, bevp_readBuffer);
bevt_10_ta_ph = beva_toParse.bemd_0(-1531348784);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-696848978);
bevt_9_ta_ph.bemd_0(-1794290543);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool)/* Line: 621*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_5_BuildBuild_bels_80));
bevt_11_ta_ph.bem_echo_0();
} /* Line: 622*/
bevt_12_ta_ph = bevl_trans.bemd_0(1494898487);
bem_nodify_2(bevt_12_ta_ph, bevl_toks);
if (bevp_printAllAst.bevi_bool)/* Line: 625*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_5_BuildBuild_bels_81));
bevt_13_ta_ph.bem_print_0();
bevt_14_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_14_ta_ph);
} /* Line: 627*/
if (bevp_printSteps.bevi_bool)/* Line: 630*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_82));
bevt_15_ta_ph.bem_echo_0();
} /* Line: 631*/
bevt_16_ta_ph = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(-697044018, bevt_16_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 634*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_83));
bevt_17_ta_ph.bem_print_0();
bevt_18_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_18_ta_ph);
} /* Line: 636*/
if (bevp_printSteps.bevi_bool)/* Line: 638*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_84));
bevt_19_ta_ph.bem_echo_0();
} /* Line: 639*/
bevt_20_ta_ph = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(-697044018, bevt_20_ta_ph);
bevl_trans.bemd_0(1315428873);
if (bevp_printAllAst.bevi_bool)/* Line: 644*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_85));
bevt_21_ta_ph.bem_print_0();
bevt_22_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_22_ta_ph);
} /* Line: 646*/
if (bevp_printSteps.bevi_bool)/* Line: 649*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_86));
bevt_23_ta_ph.bem_echo_0();
} /* Line: 650*/
bevt_24_ta_ph = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(-697044018, bevt_24_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 653*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_87));
bevt_25_ta_ph.bem_print_0();
bevt_26_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_26_ta_ph);
} /* Line: 655*/
if (bevp_printSteps.bevi_bool)/* Line: 658*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_88));
bevt_27_ta_ph.bem_echo_0();
} /* Line: 659*/
bevt_28_ta_ph = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(-697044018, bevt_28_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 662*/ {
bevt_29_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_89));
bevt_29_ta_ph.bem_print_0();
bevt_30_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_30_ta_ph);
} /* Line: 664*/
if (bevp_printSteps.bevi_bool)/* Line: 667*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_90));
bevt_31_ta_ph.bem_echo_0();
} /* Line: 668*/
bevt_32_ta_ph = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(-697044018, bevt_32_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 671*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_91));
bevt_33_ta_ph.bem_print_0();
bevt_34_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_34_ta_ph);
} /* Line: 673*/
if (bevp_printSteps.bevi_bool)/* Line: 676*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_92));
bevt_35_ta_ph.bem_echo_0();
} /* Line: 677*/
bevt_36_ta_ph = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(-697044018, bevt_36_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 680*/ {
bevt_37_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_93));
bevt_37_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_38_ta_ph);
} /* Line: 682*/
if (bevp_printSteps.bevi_bool)/* Line: 685*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_94));
bevt_39_ta_ph.bem_echo_0();
} /* Line: 686*/
bevt_40_ta_ph = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(-697044018, bevt_40_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 689*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_95));
bevt_41_ta_ph.bem_print_0();
bevt_42_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_42_ta_ph);
} /* Line: 691*/
if (bevp_printSteps.bevi_bool)/* Line: 694*/ {
bevt_43_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_96));
bevt_43_ta_ph.bem_echo_0();
} /* Line: 695*/
bevt_44_ta_ph = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(-697044018, bevt_44_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 698*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_97));
bevt_45_ta_ph.bem_print_0();
bevt_46_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_46_ta_ph);
} /* Line: 700*/
if (bevp_printSteps.bevi_bool)/* Line: 703*/ {
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_98));
bevt_47_ta_ph.bem_echo_0();
} /* Line: 704*/
bevt_48_ta_ph = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(-697044018, bevt_48_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 707*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_99));
bevt_49_ta_ph.bem_print_0();
bevt_50_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_50_ta_ph);
} /* Line: 709*/
if (bevp_printSteps.bevi_bool)/* Line: 711*/ {
bevt_51_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_100));
bevt_51_ta_ph.bem_echo_0();
} /* Line: 712*/
bevt_52_ta_ph = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(-697044018, bevt_52_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 715*/ {
bevt_53_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_101));
bevt_53_ta_ph.bem_print_0();
bevt_54_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_54_ta_ph);
} /* Line: 717*/
if (bevp_printSteps.bevi_bool)/* Line: 720*/ {
bevt_55_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_102));
bevt_55_ta_ph.bem_echo_0();
bevt_56_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_103));
bevt_56_ta_ph.bem_print_0();
} /* Line: 722*/
bevt_57_ta_ph = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(-697044018, bevt_57_ta_ph);
if (bevp_printAst.bevi_bool)/* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 725*/ {
if (bevp_printAllAst.bevi_bool)/* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 725*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 725*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_104));
bevt_58_ta_ph.bem_print_0();
bevt_59_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(-697044018, bevt_59_ta_ph);
} /* Line: 727*/
bevt_60_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 729*/ {
bevt_61_ta_ph = bevl_ci.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 729*/ {
bevl_clnode = bevl_ci.bemd_0(39409994);
bevl_tunode = bevl_clnode.bemd_0(63451852);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(473402575, bevt_62_ta_ph);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_ta_ph = bevl_tunode.bemd_0(-1046924633);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(-668378734);
bevl_ntt.bemd_1(1798879123, bevt_63_ta_ph);
bevl_ntunode.bemd_1(-1522901027, bevl_ntt);
bevl_clnode.bemd_0(-2120927596);
bevl_ntunode.bemd_1(-1131970751, bevl_clnode);
bevl_ntunode.bemd_1(1597293317, bevl_clnode);
} /* Line: 740*/
 else /* Line: 729*/ {
break;
} /* Line: 729*/
} /* Line: 729*/
} /* Line: 729*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
beva_parnode.bemd_0(1818991738);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(139385421);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_ta_ph.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 750*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 750*/ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_ta_ph = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(-1522901027, bevt_2_ta_ph);
bevl_node.bemd_1(1071018021, bevl_nlc);
bevt_4_ta_ph = bevl_node.bemd_0(-1046924633);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1912890932, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 754*/ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 755*/
bevt_6_ta_ph = bevl_node.bemd_0(-1046924633);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(1863587245, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 757*/ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-222459944, beva_parnode);
} /* Line: 759*/
} /* Line: 757*/
 else /* Line: 750*/ {
break;
} /* Line: 750*/
} /* Line: 750*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-1203171897, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(473402575, bevt_5_ta_ph);
bevl_nlnpn.bemd_1(-1522901027, bevl_nlnp);
bevl_nlnpn.bemd_1(1597293317, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevl_nlc.bemd_1(-1998635286, bevt_6_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-784089512, bevt_7_ta_ph);
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1844805637, bevt_8_ta_ph);
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-1049763346, bevt_9_ta_ph);
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(353215518, bevt_10_ta_ph);
bevt_11_ta_ph = beva_node.bemd_0(-1046924633);
bevl_nlc.bemd_1(1345827649, bevt_11_ta_ph);
beva_node.bemd_1(-1131970751, bevl_nlnpn);
bevt_12_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(473402575, bevt_12_ta_ph);
beva_node.bemd_1(-1522901027, bevl_nlc);
bevl_nlnpn.bemd_0(1482023322);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_105));
bevt_13_ta_ph = beva_tName.bemd_1(1912890932, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_106));
bevt_15_ta_ph = beva_tName.bemd_1(1912890932, bevt_16_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 789*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 789*/ {
bevl_pn = beva_node.bemd_0(188920718);
if (bevl_pn == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 791*/ {
bevt_19_ta_ph = bevl_pn.bemd_0(-1970071502);
bevt_20_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(1912890932, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_22_ta_ph = bevl_pn.bemd_0(-1970071502);
bevt_23_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1912890932, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 791*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 791*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 791*/ {
bevl_pn2 = bevl_pn.bemd_0(188920718);
if (bevl_pn2 == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_26_ta_ph = bevl_pn2.bemd_0(-1970071502);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(1863587245, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_29_ta_ph = bevl_pn2.bemd_0(-1970071502);
bevt_30_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(1863587245, bevt_30_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_32_ta_ph = bevl_pn2.bemd_0(-1970071502);
bevt_33_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_1(1863587245, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_31_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_35_ta_ph = bevl_pn2.bemd_0(-1970071502);
bevt_36_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(1863587245, bevt_36_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_38_ta_ph = bevl_pn.bemd_0(-1046924633);
bevt_39_ta_ph = bevl_nlc.bemd_0(639603583);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(-1372582381, bevt_39_ta_ph);
bevl_nlc.bemd_1(1345827649, bevt_37_ta_ph);
bevl_pn.bemd_0(-2120927596);
} /* Line: 800*/
} /* Line: 793*/
} /* Line: 791*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() throws Throwable {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() throws Throwable {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGet_0() throws Throwable {
return bevp_doMain;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() throws Throwable {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGet_0() throws Throwable {
return bevp_loadIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 88, 89, 90, 91, 92, 93, 93, 101, 101, 101, 101, 0, 101, 101, 0, 0, 0, 0, 0, 102, 102, 104, 104, 108, 108, 108, 108, 112, 112, 113, 113, 113, 117, 118, 119, 119, 119, 119, 119, 120, 120, 120, 121, 120, 123, 127, 128, 130, 131, 132, 133, 135, 136, 137, 137, 138, 0, 0, 0, 141, 143, 147, 147, 147, 149, 154, 156, 157, 157, 157, 158, 158, 0, 158, 158, 159, 159, 159, 160, 161, 161, 166, 166, 166, 166, 167, 169, 169, 169, 170, 170, 171, 171, 171, 173, 175, 175, 175, 175, 175, 175, 176, 177, 177, 178, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 185, 185, 186, 186, 187, 187, 189, 189, 189, 190, 190, 190, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 231, 232, 232, 233, 235, 237, 237, 237, 238, 238, 238, 239, 239, 240, 240, 241, 242, 242, 243, 243, 243, 243, 243, 0, 0, 0, 244, 0, 244, 244, 245, 248, 248, 249, 249, 250, 250, 251, 251, 252, 252, 252, 253, 253, 254, 254, 255, 256, 256, 257, 0, 257, 257, 259, 262, 262, 262, 262, 263, 263, 263, 263, 264, 264, 264, 264, 264, 265, 266, 267, 268, 269, 272, 272, 273, 275, 282, 282, 282, 282, 282, 283, 283, 284, 284, 287, 287, 287, 288, 288, 289, 289, 292, 293, 293, 0, 293, 293, 294, 294, 296, 297, 298, 300, 301, 301, 301, 301, 302, 302, 304, 304, 305, 305, 306, 306, 307, 313, 314, 314, 314, 314, 314, 315, 315, 315, 315, 315, 316, 320, 321, 321, 321, 322, 323, 323, 323, 323, 324, 324, 324, 324, 325, 325, 325, 325, 325, 326, 326, 327, 0, 327, 327, 328, 331, 331, 331, 331, 331, 332, 332, 333, 0, 333, 333, 334, 339, 339, 339, 340, 341, 341, 341, 341, 341, 341, 348, 348, 352, 352, 353, 358, 358, 359, 360, 360, 361, 362, 362, 363, 364, 364, 365, 366, 366, 367, 371, 371, 371, 373, 375, 379, 381, 381, 381, 382, 382, 383, 383, 383, 384, 384, 385, 386, 386, 387, 387, 387, 388, 388, 388, 394, 394, 395, 396, 396, 397, 0, 397, 397, 398, 401, 402, 402, 403, 404, 406, 406, 406, 409, 411, 0, 411, 411, 412, 412, 412, 413, 414, 415, 418, 0, 418, 418, 419, 419, 419, 420, 421, 422, 423, 423, 428, 429, 429, 430, 432, 432, 433, 433, 434, 437, 440, 440, 440, 443, 443, 443, 445, 445, 446, 446, 447, 447, 447, 448, 448, 448, 449, 449, 449, 450, 450, 450, 451, 451, 451, 452, 452, 455, 456, 458, 458, 458, 459, 460, 462, 463, 464, 464, 464, 465, 466, 470, 470, 470, 471, 471, 472, 472, 472, 474, 474, 474, 477, 481, 481, 482, 483, 485, 0, 485, 485, 486, 486, 487, 487, 488, 488, 488, 489, 489, 490, 490, 492, 492, 492, 493, 493, 493, 497, 498, 500, 500, 0, 0, 0, 501, 501, 502, 502, 502, 502, 502, 502, 502, 502, 504, 504, 505, 505, 507, 507, 507, 508, 508, 508, 513, 513, 513, 515, 515, 516, 516, 516, 518, 518, 519, 519, 519, 521, 521, 522, 522, 522, 526, 526, 527, 528, 528, 528, 528, 528, 529, 531, 531, 535, 535, 535, 536, 537, 537, 538, 539, 541, 541, 541, 542, 543, 543, 544, 545, 547, 547, 551, 551, 551, 551, 552, 552, 552, 554, 554, 555, 555, 555, 555, 556, 558, 558, 558, 558, 558, 560, 560, 561, 561, 562, 566, 566, 566, 568, 570, 570, 571, 571, 571, 571, 572, 576, 577, 577, 578, 578, 579, 585, 585, 586, 587, 594, 594, 595, 597, 602, 603, 604, 605, 606, 607, 607, 0, 0, 0, 610, 610, 610, 610, 612, 614, 614, 614, 614, 615, 615, 615, 618, 622, 622, 624, 624, 626, 626, 627, 627, 631, 631, 633, 633, 635, 635, 636, 636, 639, 639, 642, 642, 643, 645, 645, 646, 646, 650, 650, 652, 652, 654, 654, 655, 655, 659, 659, 661, 661, 663, 663, 664, 664, 668, 668, 670, 670, 672, 672, 673, 673, 677, 677, 679, 679, 681, 681, 682, 682, 686, 686, 688, 688, 690, 690, 691, 691, 695, 695, 697, 697, 699, 699, 700, 700, 704, 704, 706, 706, 708, 708, 709, 709, 712, 712, 714, 714, 716, 716, 717, 717, 721, 721, 722, 722, 724, 724, 0, 0, 0, 726, 726, 727, 727, 729, 729, 729, 730, 732, 733, 734, 734, 735, 736, 736, 736, 737, 738, 739, 740, 746, 747, 748, 749, 749, 750, 750, 751, 752, 752, 753, 754, 754, 755, 757, 757, 758, 759, 766, 767, 769, 770, 770, 771, 772, 774, 775, 775, 776, 776, 777, 777, 778, 778, 779, 779, 780, 780, 782, 784, 784, 785, 787, 789, 789, 0, 789, 789, 0, 0, 790, 791, 791, 791, 791, 791, 0, 791, 791, 791, 0, 0, 0, 0, 0, 792, 793, 793, 0, 793, 793, 793, 793, 793, 793, 0, 0, 0, 793, 793, 793, 0, 0, 0, 793, 793, 793, 0, 0, 0, 0, 0, 799, 799, 799, 799, 800, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 237, 242, 243, 244, 246, 249, 250, 252, 255, 259, 262, 266, 269, 270, 272, 273, 279, 280, 281, 282, 289, 290, 291, 292, 293, 305, 306, 307, 308, 309, 310, 311, 312, 315, 320, 321, 322, 328, 336, 337, 339, 340, 341, 342, 346, 347, 348, 349, 350, 353, 357, 360, 364, 366, 372, 373, 374, 377, 529, 530, 531, 532, 537, 538, 539, 539, 542, 544, 545, 546, 551, 552, 553, 554, 562, 563, 564, 565, 567, 569, 570, 571, 572, 573, 575, 576, 577, 580, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 647, 648, 650, 651, 652, 657, 658, 660, 661, 662, 667, 668, 670, 671, 672, 677, 678, 680, 681, 682, 687, 688, 690, 691, 692, 697, 698, 700, 701, 702, 707, 708, 710, 711, 712, 717, 718, 720, 721, 722, 727, 728, 730, 731, 732, 737, 738, 740, 741, 742, 747, 748, 751, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 771, 772, 773, 778, 779, 782, 786, 789, 789, 792, 794, 795, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 823, 824, 824, 827, 829, 830, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 860, 861, 864, 866, 867, 868, 869, 870, 871, 876, 877, 878, 880, 881, 882, 883, 888, 889, 890, 892, 893, 894, 894, 897, 899, 900, 901, 907, 908, 909, 910, 911, 912, 913, 918, 919, 920, 922, 927, 928, 929, 930, 931, 932, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 997, 998, 999, 1002, 1004, 1005, 1006, 1007, 1008, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1024, 1025, 1025, 1028, 1030, 1031, 1038, 1039, 1040, 1041, 1042, 1043, 1048, 1049, 1049, 1052, 1054, 1055, 1068, 1069, 1072, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1090, 1091, 1107, 1112, 1113, 1115, 1120, 1121, 1122, 1123, 1125, 1128, 1129, 1131, 1134, 1135, 1137, 1140, 1141, 1143, 1146, 1147, 1148, 1153, 1155, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1314, 1315, 1316, 1317, 1322, 1323, 1323, 1326, 1328, 1329, 1336, 1337, 1342, 1343, 1344, 1346, 1347, 1348, 1351, 1352, 1352, 1355, 1357, 1358, 1359, 1364, 1365, 1366, 1367, 1374, 1374, 1377, 1379, 1380, 1381, 1386, 1387, 1388, 1389, 1390, 1391, 1399, 1400, 1403, 1405, 1406, 1407, 1409, 1410, 1411, 1418, 1420, 1421, 1422, 1423, 1424, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1453, 1454, 1455, 1456, 1459, 1461, 1462, 1468, 1469, 1470, 1471, 1474, 1476, 1477, 1484, 1485, 1486, 1487, 1492, 1493, 1494, 1495, 1497, 1498, 1499, 1501, 1504, 1509, 1510, 1511, 1513, 1513, 1516, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1529, 1530, 1532, 1533, 1534, 1536, 1537, 1538, 1546, 1547, 1550, 1552, 1554, 1557, 1561, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1577, 1578, 1580, 1581, 1582, 1584, 1585, 1586, 1595, 1596, 1597, 1598, 1603, 1604, 1605, 1606, 1608, 1613, 1614, 1615, 1616, 1618, 1623, 1624, 1625, 1626, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1639, 1640, 1653, 1654, 1657, 1659, 1660, 1661, 1662, 1663, 1669, 1670, 1673, 1675, 1676, 1677, 1678, 1679, 1685, 1686, 1714, 1715, 1716, 1721, 1722, 1723, 1724, 1726, 1727, 1728, 1729, 1730, 1735, 1736, 1739, 1740, 1741, 1742, 1743, 1744, 1749, 1750, 1751, 1752, 1755, 1756, 1757, 1759, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1775, 1776, 1777, 1778, 1783, 1784, 1786, 1787, 1788, 1789, 1793, 1798, 1799, 1801, 1880, 1881, 1882, 1883, 1884, 1885, 1886, 1889, 1893, 1896, 1900, 1901, 1902, 1903, 1905, 1906, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1915, 1916, 1918, 1919, 1921, 1922, 1923, 1924, 1927, 1928, 1930, 1931, 1933, 1934, 1935, 1936, 1939, 1940, 1942, 1943, 1944, 1946, 1947, 1948, 1949, 1952, 1953, 1955, 1956, 1958, 1959, 1960, 1961, 1964, 1965, 1967, 1968, 1970, 1971, 1972, 1973, 1976, 1977, 1979, 1980, 1982, 1983, 1984, 1985, 1988, 1989, 1991, 1992, 1994, 1995, 1996, 1997, 2000, 2001, 2003, 2004, 2006, 2007, 2008, 2009, 2012, 2013, 2015, 2016, 2018, 2019, 2020, 2021, 2024, 2025, 2027, 2028, 2030, 2031, 2032, 2033, 2036, 2037, 2039, 2040, 2042, 2043, 2044, 2045, 2048, 2049, 2050, 2051, 2053, 2054, 2056, 2060, 2063, 2067, 2068, 2069, 2070, 2072, 2073, 2076, 2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2112, 2113, 2114, 2115, 2116, 2117, 2120, 2122, 2123, 2124, 2125, 2126, 2127, 2129, 2131, 2132, 2134, 2135, 2190, 2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2218, 2221, 2222, 2224, 2227, 2231, 2232, 2237, 2238, 2239, 2240, 2242, 2245, 2246, 2247, 2249, 2252, 2256, 2259, 2263, 2266, 2267, 2272, 2273, 2276, 2277, 2278, 2280, 2281, 2282, 2284, 2287, 2291, 2294, 2295, 2296, 2298, 2301, 2305, 2308, 2309, 2310, 2312, 2315, 2319, 2322, 2325, 2329, 2330, 2331, 2332, 2333, 2340, 2343, 2347, 2350, 2354, 2357, 2361, 2364, 2368, 2371, 2375, 2378, 2382, 2385, 2389, 2392, 2396, 2399, 2403, 2406, 2410, 2413, 2417, 2420, 2424, 2427, 2431, 2434, 2438, 2441, 2445, 2448, 2452, 2455, 2459, 2462, 2466, 2469, 2473, 2476, 2480, 2483, 2487, 2490, 2494, 2497, 2501, 2504, 2508, 2511, 2515, 2518, 2522, 2525, 2529, 2532, 2536, 2539, 2543, 2546, 2550, 2553, 2557, 2560, 2564, 2567, 2571, 2574, 2578, 2581, 2585, 2588, 2592, 2595, 2599, 2602, 2606, 2609, 2613, 2616, 2620, 2623, 2627, 2630, 2634, 2637, 2641, 2644, 2648, 2651, 2655, 2658, 2662, 2665, 2669, 2672, 2676, 2679, 2683, 2686, 2690, 2693, 2697, 2700, 2704, 2707, 2711, 2714, 2718, 2721, 2725, 2728, 2732, 2735, 2739, 2742, 2746, 2749, 2753, 2756, 2760, 2763, 2767, 2770, 2774, 2777, 2781, 2784, 2788, 2791, 2795, 2798, 2802, 2805, 2809, 2812, 2816, 2819, 2823, 2826, 2830, 2833, 2837, 2840, 2844, 2847, 2851, 2854, 2858, 2861, 2865};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 51 197
new 0 51 197
assign 1 53 198
new 0 53 198
assign 1 54 199
new 0 54 199
assign 1 55 200
new 0 55 200
assign 1 56 201
new 0 56 201
assign 1 58 202
new 0 58 202
assign 1 59 203
new 0 59 203
assign 1 60 204
new 0 60 204
assign 1 61 205
new 0 61 205
assign 1 62 206
new 0 62 206
assign 1 63 207
new 0 63 207
assign 1 64 208
new 0 64 208
assign 1 68 209
new 0 68 209
assign 1 70 210
new 1 70 210
assign 1 71 211
ntypesGet 0 71 211
assign 1 72 212
twtokGet 0 72 212
assign 1 73 213
new 0 73 213
assign 1 73 214
new 1 73 214
assign 1 76 215
new 0 76 215
assign 1 79 216
new 0 79 216
assign 1 80 217
new 0 80 217
assign 1 81 218
new 0 81 218
assign 1 88 219
new 0 88 219
assign 1 89 220
new 0 89 220
assign 1 90 221
new 0 90 221
assign 1 91 222
new 0 91 222
assign 1 92 223
new 0 92 223
assign 1 93 224
new 0 93 224
assign 1 93 225
new 1 93 225
assign 1 101 237
def 1 101 242
assign 1 101 243
new 0 101 243
assign 1 101 244
equals 1 101 244
assign 1 0 246
assign 1 101 249
new 0 101 249
assign 1 101 250
ends 1 101 250
assign 1 0 252
assign 1 0 255
assign 1 0 259
assign 1 0 262
assign 1 0 266
assign 1 102 269
new 0 102 269
return 1 102 270
assign 1 104 272
new 0 104 272
return 1 104 273
assign 1 108 279
new 0 108 279
assign 1 108 280
new 0 108 280
assign 1 108 281
swap 2 108 281
return 1 108 282
assign 1 112 289
new 0 112 289
assign 1 112 290
argsGet 0 112 290
assign 1 113 291
new 0 113 291
assign 1 113 292
main 1 113 292
exit 1 113 293
assign 1 117 305
assign 1 118 306
new 1 118 306
assign 1 119 307
new 0 119 307
assign 1 119 308
new 0 119 308
assign 1 119 309
get 2 119 309
assign 1 119 310
firstGet 0 119 310
assign 1 119 311
new 1 119 311
assign 1 120 312
new 0 120 312
assign 1 120 315
lesser 1 120 320
assign 1 121 321
go 0 121 321
incrementValue 0 120 322
return 1 123 328
assign 1 127 336
new 0 127 336
assign 1 128 337
new 0 128 337
config 0 130 339
assign 1 131 340
new 0 131 340
assign 1 132 341
doWhat 0 132 341
assign 1 133 342
new 0 133 342
assign 1 135 346
toString 0 135 346
assign 1 136 347
new 0 136 347
assign 1 137 348
new 0 137 348
assign 1 137 349
add 1 137 349
assign 1 138 350
new 0 138 350
assign 1 0 353
assign 1 0 357
assign 1 0 360
print 0 141 364
return 1 143 366
assign 1 147 372
nameGet 0 147 372
assign 1 147 373
new 0 147 373
assign 1 147 374
equals 1 147 374
return 1 149 377
assign 1 154 529
new 0 154 529
assign 1 156 530
new 0 156 530
assign 1 157 531
get 1 157 531
assign 1 157 532
def 1 157 537
assign 1 158 538
get 1 158 538
assign 1 158 539
iteratorGet 0 0 539
assign 1 158 542
hasNextGet 0 158 542
assign 1 158 544
nextGet 0 158 544
assign 1 159 545
has 1 159 545
assign 1 159 546
not 0 159 551
put 1 160 552
assign 1 161 553
new 1 161 553
addFile 1 161 554
assign 1 166 562
new 0 166 562
assign 1 166 563
nameGet 0 166 563
assign 1 166 564
new 0 166 564
assign 1 166 565
equals 1 166 565
preProcessorSet 1 167 567
assign 1 169 569
new 0 169 569
assign 1 169 570
get 1 169 570
assign 1 169 571
firstGet 0 169 571
assign 1 170 572
new 0 170 572
assign 1 170 573
has 1 170 573
assign 1 171 575
new 0 171 575
assign 1 171 576
get 1 171 576
assign 1 171 577
firstGet 0 171 577
assign 1 173 580
assign 1 175 582
new 0 175 582
assign 1 175 583
new 0 175 583
assign 1 175 584
get 2 175 584
assign 1 175 585
firstGet 0 175 585
assign 1 175 586
new 1 175 586
assign 1 175 587
pathGet 0 175 587
addStep 1 176 588
assign 1 177 589
new 0 177 589
addStep 1 177 590
assign 1 178 591
new 0 178 591
assign 1 178 592
new 0 178 592
assign 1 178 593
get 2 178 593
assign 1 178 594
firstGet 0 178 594
assign 1 178 595
new 1 178 595
assign 1 178 596
pathGet 0 178 596
assign 1 179 597
new 0 179 597
assign 1 179 598
new 0 179 598
assign 1 179 599
nameGet 0 179 599
assign 1 179 600
get 2 179 600
assign 1 179 601
firstGet 0 179 601
assign 1 179 602
new 1 179 602
assign 1 180 603
new 0 180 603
assign 1 180 604
nameGet 0 180 604
assign 1 180 605
get 2 180 605
assign 1 180 606
firstGet 0 180 606
assign 1 180 607
new 1 180 607
assign 1 181 608
new 0 181 608
assign 1 181 609
new 0 181 609
assign 1 181 610
get 2 181 610
assign 1 181 611
firstGet 0 181 611
assign 1 181 612
new 1 181 612
assign 1 182 613
new 0 182 613
assign 1 182 614
new 0 182 614
assign 1 182 615
get 2 182 615
assign 1 182 616
firstGet 0 182 616
assign 1 182 617
new 1 182 617
assign 1 183 618
new 0 183 618
assign 1 183 619
new 0 183 619
assign 1 183 620
get 2 183 620
assign 1 183 621
firstGet 0 183 621
assign 1 183 622
new 1 183 622
assign 1 184 623
new 0 184 623
assign 1 184 624
new 0 184 624
assign 1 184 625
get 2 184 625
assign 1 184 626
firstGet 0 184 626
assign 1 184 627
new 1 184 627
assign 1 185 628
new 0 185 628
assign 1 185 629
get 1 185 629
assign 1 186 630
new 0 186 630
assign 1 186 631
get 1 186 631
assign 1 187 632
new 0 187 632
assign 1 187 633
get 1 187 633
assign 1 189 634
new 0 189 634
assign 1 189 635
get 1 189 635
assign 1 189 636
firstGet 0 189 636
assign 1 190 637
new 0 190 637
assign 1 190 638
get 1 190 638
assign 1 190 639
firstGet 0 190 639
assign 1 191 640
new 0 191 640
assign 1 191 641
get 1 191 641
assign 1 192 642
undef 1 192 647
assign 1 193 648
new 0 193 648
assign 1 195 650
new 0 195 650
assign 1 195 651
get 1 195 651
assign 1 196 652
undef 1 196 657
assign 1 197 658
new 0 197 658
assign 1 199 660
new 0 199 660
assign 1 199 661
get 1 199 661
assign 1 200 662
undef 1 200 667
assign 1 201 668
new 0 201 668
assign 1 203 670
new 0 203 670
assign 1 203 671
get 1 203 671
assign 1 204 672
undef 1 204 677
assign 1 205 678
new 0 205 678
assign 1 207 680
new 0 207 680
assign 1 207 681
get 1 207 681
assign 1 208 682
undef 1 208 687
assign 1 209 688
new 0 209 688
assign 1 211 690
new 0 211 690
assign 1 211 691
get 1 211 691
assign 1 212 692
undef 1 212 697
assign 1 213 698
new 0 213 698
assign 1 215 700
new 0 215 700
assign 1 215 701
get 1 215 701
assign 1 216 702
undef 1 216 707
assign 1 217 708
new 0 217 708
assign 1 219 710
new 0 219 710
assign 1 219 711
get 1 219 711
assign 1 220 712
undef 1 220 717
assign 1 221 718
new 0 221 718
assign 1 223 720
new 0 223 720
assign 1 223 721
get 1 223 721
assign 1 224 722
undef 1 224 727
assign 1 225 728
new 0 225 728
assign 1 227 730
new 0 227 730
assign 1 227 731
get 1 227 731
assign 1 228 732
def 1 228 737
assign 1 229 738
firstGet 0 229 738
assign 1 231 740
new 0 231 740
assign 1 231 741
get 1 231 741
assign 1 232 742
def 1 232 747
assign 1 233 748
firstGet 0 233 748
assign 1 235 751
new 0 235 751
assign 1 237 753
new 0 237 753
assign 1 237 754
new 0 237 754
assign 1 237 755
isTrue 2 237 755
assign 1 238 756
new 0 238 756
assign 1 238 757
new 0 238 757
assign 1 238 758
isTrue 2 238 758
assign 1 239 759
new 0 239 759
assign 1 239 760
isTrue 1 239 760
assign 1 240 761
new 0 240 761
assign 1 240 762
isTrue 1 240 762
assign 1 241 763
new 0 241 763
assign 1 242 764
new 0 242 764
assign 1 242 765
get 1 242 765
assign 1 243 766
def 1 243 771
assign 1 243 772
isEmptyGet 0 243 772
assign 1 243 773
not 0 243 778
assign 1 0 779
assign 1 0 782
assign 1 0 786
assign 1 244 789
linkedListIteratorGet 0 0 789
assign 1 244 792
hasNextGet 0 244 792
assign 1 244 794
nextGet 0 244 794
put 1 245 795
assign 1 248 802
new 0 248 802
assign 1 248 803
isTrue 1 248 803
assign 1 249 804
new 0 249 804
assign 1 249 805
isTrue 1 249 805
assign 1 250 806
new 0 250 806
assign 1 250 807
isTrue 1 250 807
assign 1 251 808
new 0 251 808
assign 1 251 809
isTrue 1 251 809
assign 1 252 810
new 0 252 810
assign 1 252 811
new 0 252 811
assign 1 252 812
isTrue 2 252 812
assign 1 253 813
new 0 253 813
assign 1 253 814
get 1 253 814
assign 1 254 815
new 0 254 815
assign 1 254 816
get 1 254 816
assign 1 255 817
new 0 255 817
assign 1 256 818
def 1 256 823
assign 1 257 824
linkedListIteratorGet 0 0 824
assign 1 257 827
hasNextGet 0 257 827
assign 1 257 829
nextGet 0 257 829
addValue 1 259 830
assign 1 262 837
new 0 262 837
assign 1 262 838
new 0 262 838
assign 1 262 839
get 2 262 839
assign 1 262 840
firstGet 0 262 840
assign 1 263 841
new 0 263 841
assign 1 263 842
new 0 263 842
assign 1 263 843
get 2 263 843
assign 1 263 844
firstGet 0 263 844
assign 1 264 845
new 0 264 845
assign 1 264 846
add 1 264 846
assign 1 264 847
new 0 264 847
assign 1 264 848
get 2 264 848
assign 1 264 849
firstGet 0 264 849
assign 1 265 850
new 0 265 850
assign 1 266 851
new 0 266 851
assign 1 267 852
new 0 267 852
assign 1 268 853
new 0 268 853
assign 1 269 854
new 0 269 854
assign 1 272 855
def 1 272 860
assign 1 273 861
firstGet 0 273 861
assign 1 275 864
new 0 275 864
assign 1 282 866
new 0 282 866
assign 1 282 867
add 1 282 867
assign 1 282 868
nameGet 0 282 868
assign 1 282 869
add 1 282 869
assign 1 282 870
get 1 282 870
assign 1 283 871
def 1 283 876
assign 1 284 877
orderedGet 0 284 877
addAll 1 284 878
assign 1 287 880
new 0 287 880
assign 1 287 881
add 1 287 881
assign 1 287 882
get 1 287 882
assign 1 288 883
def 1 288 888
assign 1 289 889
orderedGet 0 289 889
addAll 1 289 890
assign 1 292 892
new 0 292 892
assign 1 293 893
orderedGet 0 293 893
assign 1 293 894
iteratorGet 0 0 894
assign 1 293 897
hasNextGet 0 293 897
assign 1 293 899
nextGet 0 293 899
assign 1 294 900
new 1 294 900
addValue 1 294 901
assign 1 296 907
newlineGet 0 296 907
assign 1 297 908
assign 1 298 909
new 1 298 909
assign 1 300 910
copy 0 300 910
assign 1 301 911
fileGet 0 301 911
assign 1 301 912
existsGet 0 301 912
assign 1 301 913
not 0 301 918
assign 1 302 919
fileGet 0 302 919
makeDirs 0 302 920
assign 1 304 922
def 1 304 927
assign 1 305 928
new 1 305 928
assign 1 305 929
readerGet 0 305 929
assign 1 306 930
open 0 306 930
assign 1 306 931
readString 0 306 931
close 0 307 932
assign 1 313 946
classNameGet 0 313 946
assign 1 314 947
add 1 314 947
assign 1 314 948
new 0 314 948
assign 1 314 949
add 1 314 949
assign 1 314 950
toString 0 314 950
assign 1 314 951
add 1 314 951
assign 1 315 952
add 1 315 952
assign 1 315 953
new 0 315 953
assign 1 315 954
add 1 315 954
assign 1 315 955
toString 0 315 955
assign 1 315 956
add 1 315 956
return 1 316 957
assign 1 320 997
new 0 320 997
assign 1 321 998
classesGet 0 321 998
assign 1 321 999
valueIteratorGet 0 321 999
assign 1 321 1002
hasNextGet 0 321 1002
assign 1 322 1004
nextGet 0 322 1004
assign 1 323 1005
shouldEmitGet 0 323 1005
assign 1 323 1006
heldGet 0 323 1006
assign 1 323 1007
fromFileGet 0 323 1007
assign 1 323 1008
has 1 323 1008
assign 1 324 1010
heldGet 0 324 1010
assign 1 324 1011
namepathGet 0 324 1011
assign 1 324 1012
toString 0 324 1012
put 1 324 1013
assign 1 325 1014
usedByGet 0 325 1014
assign 1 325 1015
heldGet 0 325 1015
assign 1 325 1016
namepathGet 0 325 1016
assign 1 325 1017
toString 0 325 1017
assign 1 325 1018
get 1 325 1018
assign 1 326 1019
def 1 326 1024
assign 1 327 1025
setIteratorGet 0 0 1025
assign 1 327 1028
hasNextGet 0 327 1028
assign 1 327 1030
nextGet 0 327 1030
put 1 328 1031
assign 1 331 1038
subClassesGet 0 331 1038
assign 1 331 1039
heldGet 0 331 1039
assign 1 331 1040
namepathGet 0 331 1040
assign 1 331 1041
toString 0 331 1041
assign 1 331 1042
get 1 331 1042
assign 1 332 1043
def 1 332 1048
assign 1 333 1049
setIteratorGet 0 0 1049
assign 1 333 1052
hasNextGet 0 333 1052
assign 1 333 1054
nextGet 0 333 1054
put 1 334 1055
assign 1 339 1068
classesGet 0 339 1068
assign 1 339 1069
valueIteratorGet 0 339 1069
assign 1 339 1072
hasNextGet 0 339 1072
assign 1 340 1074
nextGet 0 340 1074
assign 1 341 1075
heldGet 0 341 1075
assign 1 341 1076
heldGet 0 341 1076
assign 1 341 1077
namepathGet 0 341 1077
assign 1 341 1078
toString 0 341 1078
assign 1 341 1079
has 1 341 1079
shouldWriteSet 1 341 1080
assign 1 348 1090
new 0 348 1090
return 1 348 1091
assign 1 352 1107
def 1 352 1112
return 1 353 1113
assign 1 358 1115
def 1 358 1120
assign 1 359 1121
firstGet 0 359 1121
assign 1 360 1122
new 0 360 1122
assign 1 360 1123
equals 1 360 1123
assign 1 361 1125
new 1 361 1125
assign 1 362 1128
new 0 362 1128
assign 1 362 1129
equals 1 362 1129
assign 1 363 1131
new 1 363 1131
assign 1 364 1134
new 0 364 1134
assign 1 364 1135
equals 1 364 1135
assign 1 365 1137
new 1 365 1137
assign 1 366 1140
new 0 366 1140
assign 1 366 1141
equals 1 366 1141
assign 1 367 1143
new 1 367 1143
assign 1 371 1146
new 0 371 1146
assign 1 371 1147
new 1 371 1147
throw 1 371 1148
return 1 373 1153
return 1 375 1155
assign 1 379 1174
apNew 1 379 1174
assign 1 381 1175
new 0 381 1175
assign 1 381 1176
add 1 381 1176
print 0 381 1177
assign 1 382 1178
new 0 382 1178
assign 1 382 1179
now 0 382 1179
assign 1 383 1180
fileGet 0 383 1180
assign 1 383 1181
readerGet 0 383 1181
assign 1 383 1182
open 0 383 1182
assign 1 384 1183
new 0 384 1183
assign 1 384 1184
deserialize 1 384 1184
close 0 385 1185
assign 1 386 1186
synClassesGet 0 386 1186
addValue 1 386 1187
assign 1 387 1188
new 0 387 1188
assign 1 387 1189
now 0 387 1189
assign 1 387 1190
subtract 1 387 1190
assign 1 388 1191
new 0 388 1191
assign 1 388 1192
add 1 388 1192
print 0 388 1193
assign 1 394 1314
new 0 394 1314
assign 1 394 1315
now 0 394 1315
assign 1 395 1316
new 0 395 1316
assign 1 396 1317
def 1 396 1322
assign 1 397 1323
linkedListIteratorGet 0 0 1323
assign 1 397 1326
hasNextGet 0 397 1326
assign 1 397 1328
nextGet 0 397 1328
loadSyns 1 398 1329
assign 1 401 1336
emitterGet 0 401 1336
assign 1 402 1337
def 1 402 1342
assign 1 403 1343
new 4 403 1343
put 1 404 1344
assign 1 406 1346
new 0 406 1346
assign 1 406 1347
add 1 406 1347
print 0 406 1348
assign 1 409 1351
new 0 409 1351
assign 1 411 1352
iteratorGet 0 0 1352
assign 1 411 1355
hasNextGet 0 411 1355
assign 1 411 1357
nextGet 0 411 1357
assign 1 412 1358
has 1 412 1358
assign 1 412 1359
not 0 412 1364
put 1 413 1365
assign 1 414 1366
new 2 414 1366
addValue 1 415 1367
assign 1 418 1374
iteratorGet 0 0 1374
assign 1 418 1377
hasNextGet 0 418 1377
assign 1 418 1379
nextGet 0 418 1379
assign 1 419 1380
has 1 419 1380
assign 1 419 1381
not 0 419 1386
put 1 420 1387
assign 1 421 1388
new 2 421 1388
addValue 1 422 1389
assign 1 423 1390
libNameGet 0 423 1390
put 1 423 1391
assign 1 428 1399
new 0 428 1399
assign 1 429 1400
iteratorGet 0 429 1400
assign 1 429 1403
hasNextGet 0 429 1403
assign 1 430 1405
nextGet 0 430 1405
assign 1 432 1406
toString 0 432 1406
assign 1 432 1407
has 1 432 1407
assign 1 433 1409
toString 0 433 1409
put 1 433 1410
doParse 1 434 1411
buildSyns 1 437 1418
assign 1 440 1420
new 0 440 1420
assign 1 440 1421
now 0 440 1421
assign 1 440 1422
subtract 1 440 1422
assign 1 443 1423
emitCommonGet 0 443 1423
assign 1 443 1424
def 1 443 1429
assign 1 445 1430
new 0 445 1430
assign 1 445 1431
now 0 445 1431
assign 1 446 1432
emitCommonGet 0 446 1432
doEmit 0 446 1433
assign 1 447 1434
new 0 447 1434
assign 1 447 1435
now 0 447 1435
assign 1 447 1436
subtract 1 447 1436
assign 1 448 1437
new 0 448 1437
assign 1 448 1438
now 0 448 1438
assign 1 448 1439
subtract 1 448 1439
assign 1 449 1440
new 0 449 1440
assign 1 449 1441
add 1 449 1441
print 0 449 1442
assign 1 450 1443
new 0 450 1443
assign 1 450 1444
add 1 450 1444
print 0 450 1445
assign 1 451 1446
new 0 451 1446
assign 1 451 1447
add 1 451 1447
print 0 451 1448
assign 1 452 1449
new 0 452 1449
return 1 452 1450
setClassesToWrite 0 455 1453
libnameInfoGet 0 456 1454
assign 1 458 1455
classesGet 0 458 1455
assign 1 458 1456
valueIteratorGet 0 458 1456
assign 1 458 1459
hasNextGet 0 458 1459
assign 1 459 1461
nextGet 0 459 1461
doEmit 1 460 1462
emitMain 0 462 1468
emitCUInit 0 463 1469
assign 1 464 1470
classesGet 0 464 1470
assign 1 464 1471
valueIteratorGet 0 464 1471
assign 1 464 1474
hasNextGet 0 464 1474
assign 1 465 1476
nextGet 0 465 1476
emitSyn 1 466 1477
assign 1 470 1484
new 0 470 1484
assign 1 470 1485
now 0 470 1485
assign 1 470 1486
subtract 1 470 1486
assign 1 471 1487
def 1 471 1492
assign 1 472 1493
new 0 472 1493
assign 1 472 1494
add 1 472 1494
print 0 472 1495
assign 1 474 1497
new 0 474 1497
assign 1 474 1498
add 1 474 1498
print 0 474 1499
prepMake 1 477 1501
assign 1 481 1504
not 0 481 1509
make 1 482 1510
deployLibrary 1 483 1511
assign 1 485 1513
linkedListIteratorGet 0 0 1513
assign 1 485 1516
hasNextGet 0 485 1516
assign 1 485 1518
nextGet 0 485 1518
assign 1 486 1519
libnameInfoGet 0 486 1519
assign 1 486 1520
unitShlibGet 0 486 1520
assign 1 487 1521
emitPathGet 0 487 1521
assign 1 487 1522
copy 0 487 1522
assign 1 488 1523
stepsGet 0 488 1523
assign 1 488 1524
lastGet 0 488 1524
addStep 1 488 1525
assign 1 489 1526
fileGet 0 489 1526
assign 1 489 1527
existsGet 0 489 1527
assign 1 490 1529
fileGet 0 490 1529
delete 0 490 1530
assign 1 492 1532
fileGet 0 492 1532
assign 1 492 1533
existsGet 0 492 1533
assign 1 492 1534
not 0 492 1534
assign 1 493 1536
fileGet 0 493 1536
assign 1 493 1537
fileGet 0 493 1537
deployFile 2 493 1538
assign 1 497 1546
iteratorGet 0 497 1546
assign 1 498 1547
iteratorGet 0 498 1547
assign 1 500 1550
hasNextGet 0 500 1550
assign 1 500 1552
hasNextGet 0 500 1552
assign 1 0 1554
assign 1 0 1557
assign 1 0 1561
assign 1 501 1564
nextGet 0 501 1564
assign 1 501 1565
apNew 1 501 1565
assign 1 502 1566
emitPathGet 0 502 1566
assign 1 502 1567
copy 0 502 1567
assign 1 502 1568
toString 0 502 1568
assign 1 502 1569
new 0 502 1569
assign 1 502 1570
add 1 502 1570
assign 1 502 1571
nextGet 0 502 1571
assign 1 502 1572
add 1 502 1572
assign 1 502 1573
apNew 1 502 1573
assign 1 504 1574
fileGet 0 504 1574
assign 1 504 1575
existsGet 0 504 1575
assign 1 505 1577
fileGet 0 505 1577
delete 0 505 1578
assign 1 507 1580
fileGet 0 507 1580
assign 1 507 1581
existsGet 0 507 1581
assign 1 507 1582
not 0 507 1582
assign 1 508 1584
fileGet 0 508 1584
assign 1 508 1585
fileGet 0 508 1585
deployFile 2 508 1586
assign 1 513 1595
new 0 513 1595
assign 1 513 1596
now 0 513 1596
assign 1 513 1597
subtract 1 513 1597
assign 1 515 1598
def 1 515 1603
assign 1 516 1604
new 0 516 1604
assign 1 516 1605
add 1 516 1605
print 0 516 1606
assign 1 518 1608
def 1 518 1613
assign 1 519 1614
new 0 519 1614
assign 1 519 1615
add 1 519 1615
print 0 519 1616
assign 1 521 1618
def 1 521 1623
assign 1 522 1624
new 0 522 1624
assign 1 522 1625
add 1 522 1625
print 0 522 1626
assign 1 526 1629
new 0 526 1629
print 0 526 1630
assign 1 527 1631
run 2 527 1631
assign 1 528 1632
new 0 528 1632
assign 1 528 1633
add 1 528 1633
assign 1 528 1634
new 0 528 1634
assign 1 528 1635
add 1 528 1635
print 0 528 1636
return 1 529 1637
assign 1 531 1639
new 0 531 1639
return 1 531 1640
assign 1 535 1653
justParsedGet 0 535 1653
assign 1 535 1654
valueIteratorGet 0 535 1654
assign 1 535 1657
hasNextGet 0 535 1657
assign 1 536 1659
nextGet 0 536 1659
assign 1 537 1660
heldGet 0 537 1660
libNameSet 1 537 1661
assign 1 538 1662
getSyn 2 538 1662
libNameSet 1 539 1663
assign 1 541 1669
justParsedGet 0 541 1669
assign 1 541 1670
valueIteratorGet 0 541 1670
assign 1 541 1673
hasNextGet 0 541 1673
assign 1 542 1675
nextGet 0 542 1675
assign 1 543 1676
heldGet 0 543 1676
assign 1 543 1677
synGet 0 543 1677
checkInheritance 2 544 1678
integrate 1 545 1679
assign 1 547 1685
new 0 547 1685
justParsedSet 1 547 1686
assign 1 551 1714
heldGet 0 551 1714
assign 1 551 1715
synGet 0 551 1715
assign 1 551 1716
def 1 551 1721
assign 1 552 1722
heldGet 0 552 1722
assign 1 552 1723
synGet 0 552 1723
return 1 552 1724
assign 1 554 1726
heldGet 0 554 1726
libNameSet 1 554 1727
assign 1 555 1728
heldGet 0 555 1728
assign 1 555 1729
extendsGet 0 555 1729
assign 1 555 1730
undef 1 555 1735
assign 1 556 1736
new 1 556 1736
assign 1 558 1739
classesGet 0 558 1739
assign 1 558 1740
heldGet 0 558 1740
assign 1 558 1741
extendsGet 0 558 1741
assign 1 558 1742
toString 0 558 1742
assign 1 558 1743
get 1 558 1743
assign 1 560 1744
def 1 560 1749
assign 1 561 1750
heldGet 0 561 1750
libNameSet 1 561 1751
assign 1 562 1752
getSyn 2 562 1752
assign 1 566 1755
heldGet 0 566 1755
assign 1 566 1756
extendsGet 0 566 1756
assign 1 566 1757
getSynNp 1 566 1757
assign 1 568 1759
new 2 568 1759
assign 1 570 1761
heldGet 0 570 1761
synSet 1 570 1762
assign 1 571 1763
heldGet 0 571 1763
assign 1 571 1764
namepathGet 0 571 1764
assign 1 571 1765
toString 0 571 1765
addSynClass 2 571 1766
return 1 572 1767
assign 1 576 1775
toString 0 576 1775
assign 1 577 1776
synClassesGet 0 577 1776
assign 1 577 1777
get 1 577 1777
assign 1 578 1778
def 1 578 1783
return 1 579 1784
assign 1 585 1786
emitterGet 0 585 1786
assign 1 585 1787
loadSyn 1 585 1787
addSynClass 2 586 1788
return 1 587 1789
assign 1 594 1793
undef 1 594 1798
assign 1 595 1799
new 1 595 1799
return 1 597 1801
assign 1 602 1880
new 1 602 1880
assign 1 603 1881
new 0 603 1881
assign 1 604 1882
emitterGet 0 604 1882
assign 1 605 1883
assign 1 606 1884
new 0 606 1884
assign 1 607 1885
shouldEmitGet 0 607 1885
put 1 607 1886
assign 1 0 1889
assign 1 0 1893
assign 1 0 1896
assign 1 610 1900
new 0 610 1900
assign 1 610 1901
toString 0 610 1901
assign 1 610 1902
add 1 610 1902
print 0 610 1903
assign 1 612 1905
assign 1 614 1906
fileGet 0 614 1906
assign 1 614 1907
readerGet 0 614 1907
assign 1 614 1908
open 0 614 1908
assign 1 614 1909
readBuffer 1 614 1909
assign 1 615 1910
fileGet 0 615 1910
assign 1 615 1911
readerGet 0 615 1911
close 0 615 1912
assign 1 618 1913
tokenize 1 618 1913
assign 1 622 1915
new 0 622 1915
echo 0 622 1916
assign 1 624 1918
outermostGet 0 624 1918
nodify 2 624 1919
assign 1 626 1921
new 0 626 1921
print 0 626 1922
assign 1 627 1923
new 2 627 1923
traverse 1 627 1924
assign 1 631 1927
new 0 631 1927
echo 0 631 1928
assign 1 633 1930
new 0 633 1930
traverse 1 633 1931
assign 1 635 1933
new 0 635 1933
print 0 635 1934
assign 1 636 1935
new 2 636 1935
traverse 1 636 1936
assign 1 639 1939
new 0 639 1939
echo 0 639 1940
assign 1 642 1942
new 0 642 1942
traverse 1 642 1943
contain 0 643 1944
assign 1 645 1946
new 0 645 1946
print 0 645 1947
assign 1 646 1948
new 2 646 1948
traverse 1 646 1949
assign 1 650 1952
new 0 650 1952
echo 0 650 1953
assign 1 652 1955
new 0 652 1955
traverse 1 652 1956
assign 1 654 1958
new 0 654 1958
print 0 654 1959
assign 1 655 1960
new 2 655 1960
traverse 1 655 1961
assign 1 659 1964
new 0 659 1964
echo 0 659 1965
assign 1 661 1967
new 0 661 1967
traverse 1 661 1968
assign 1 663 1970
new 0 663 1970
print 0 663 1971
assign 1 664 1972
new 2 664 1972
traverse 1 664 1973
assign 1 668 1976
new 0 668 1976
echo 0 668 1977
assign 1 670 1979
new 0 670 1979
traverse 1 670 1980
assign 1 672 1982
new 0 672 1982
print 0 672 1983
assign 1 673 1984
new 2 673 1984
traverse 1 673 1985
assign 1 677 1988
new 0 677 1988
echo 0 677 1989
assign 1 679 1991
new 0 679 1991
traverse 1 679 1992
assign 1 681 1994
new 0 681 1994
print 0 681 1995
assign 1 682 1996
new 2 682 1996
traverse 1 682 1997
assign 1 686 2000
new 0 686 2000
echo 0 686 2001
assign 1 688 2003
new 0 688 2003
traverse 1 688 2004
assign 1 690 2006
new 0 690 2006
print 0 690 2007
assign 1 691 2008
new 2 691 2008
traverse 1 691 2009
assign 1 695 2012
new 0 695 2012
echo 0 695 2013
assign 1 697 2015
new 0 697 2015
traverse 1 697 2016
assign 1 699 2018
new 0 699 2018
print 0 699 2019
assign 1 700 2020
new 2 700 2020
traverse 1 700 2021
assign 1 704 2024
new 0 704 2024
echo 0 704 2025
assign 1 706 2027
new 0 706 2027
traverse 1 706 2028
assign 1 708 2030
new 0 708 2030
print 0 708 2031
assign 1 709 2032
new 2 709 2032
traverse 1 709 2033
assign 1 712 2036
new 0 712 2036
echo 0 712 2037
assign 1 714 2039
new 0 714 2039
traverse 1 714 2040
assign 1 716 2042
new 0 716 2042
print 0 716 2043
assign 1 717 2044
new 2 717 2044
traverse 1 717 2045
assign 1 721 2048
new 0 721 2048
echo 0 721 2049
assign 1 722 2050
new 0 722 2050
print 0 722 2051
assign 1 724 2053
new 0 724 2053
traverse 1 724 2054
assign 1 0 2056
assign 1 0 2060
assign 1 0 2063
assign 1 726 2067
new 0 726 2067
print 0 726 2068
assign 1 727 2069
new 2 727 2069
traverse 1 727 2070
assign 1 729 2072
classesGet 0 729 2072
assign 1 729 2073
valueIteratorGet 0 729 2073
assign 1 729 2076
hasNextGet 0 729 2076
assign 1 730 2078
nextGet 0 730 2078
assign 1 732 2079
transUnitGet 0 732 2079
assign 1 733 2080
new 1 733 2080
assign 1 734 2081
TRANSUNITGet 0 734 2081
typenameSet 1 734 2082
assign 1 735 2083
new 0 735 2083
assign 1 736 2084
heldGet 0 736 2084
assign 1 736 2085
emitsGet 0 736 2085
emitsSet 1 736 2086
heldSet 1 737 2087
delete 0 738 2088
addValue 1 739 2089
copyLoc 1 740 2090
reInitContained 0 746 2112
assign 1 747 2113
containedGet 0 747 2113
assign 1 748 2114
new 0 748 2114
assign 1 749 2115
new 0 749 2115
assign 1 749 2116
crGet 0 749 2116
assign 1 750 2117
linkedListIteratorGet 0 750 2117
assign 1 750 2120
hasNextGet 0 750 2120
assign 1 751 2122
new 1 751 2122
assign 1 752 2123
nextGet 0 752 2123
heldSet 1 752 2124
nlcSet 1 753 2125
assign 1 754 2126
heldGet 0 754 2126
assign 1 754 2127
equals 1 754 2127
assign 1 755 2129
increment 0 755 2129
assign 1 757 2131
heldGet 0 757 2131
assign 1 757 2132
notEquals 1 757 2132
addValue 1 758 2134
containerSet 1 759 2135
assign 1 766 2190
new 0 766 2190
fromString 1 767 2191
assign 1 769 2192
new 1 769 2192
assign 1 770 2193
NAMEPATHGet 0 770 2193
typenameSet 1 770 2194
heldSet 1 771 2195
copyLoc 1 772 2196
assign 1 774 2197
new 0 774 2197
assign 1 775 2198
new 0 775 2198
nameSet 1 775 2199
assign 1 776 2200
new 0 776 2200
wasBoundSet 1 776 2201
assign 1 777 2202
new 0 777 2202
boundSet 1 777 2203
assign 1 778 2204
new 0 778 2204
isConstructSet 1 778 2205
assign 1 779 2206
new 0 779 2206
isLiteralSet 1 779 2207
assign 1 780 2208
heldGet 0 780 2208
literalValueSet 1 780 2209
addValue 1 782 2210
assign 1 784 2211
CALLGet 0 784 2211
typenameSet 1 784 2212
heldSet 1 785 2213
resolveNp 0 787 2214
assign 1 789 2215
new 0 789 2215
assign 1 789 2216
equals 1 789 2216
assign 1 0 2218
assign 1 789 2221
new 0 789 2221
assign 1 789 2222
equals 1 789 2222
assign 1 0 2224
assign 1 0 2227
assign 1 790 2231
priorPeerGet 0 790 2231
assign 1 791 2232
def 1 791 2237
assign 1 791 2238
typenameGet 0 791 2238
assign 1 791 2239
SUBTRACTGet 0 791 2239
assign 1 791 2240
equals 1 791 2240
assign 1 0 2242
assign 1 791 2245
typenameGet 0 791 2245
assign 1 791 2246
ADDGet 0 791 2246
assign 1 791 2247
equals 1 791 2247
assign 1 0 2249
assign 1 0 2252
assign 1 0 2256
assign 1 0 2259
assign 1 0 2263
assign 1 792 2266
priorPeerGet 0 792 2266
assign 1 793 2267
undef 1 793 2272
assign 1 0 2273
assign 1 793 2276
typenameGet 0 793 2276
assign 1 793 2277
CALLGet 0 793 2277
assign 1 793 2278
notEquals 1 793 2278
assign 1 793 2280
typenameGet 0 793 2280
assign 1 793 2281
IDGet 0 793 2281
assign 1 793 2282
notEquals 1 793 2282
assign 1 0 2284
assign 1 0 2287
assign 1 0 2291
assign 1 793 2294
typenameGet 0 793 2294
assign 1 793 2295
VARGet 0 793 2295
assign 1 793 2296
notEquals 1 793 2296
assign 1 0 2298
assign 1 0 2301
assign 1 0 2305
assign 1 793 2308
typenameGet 0 793 2308
assign 1 793 2309
ACCESSORGet 0 793 2309
assign 1 793 2310
notEquals 1 793 2310
assign 1 0 2312
assign 1 0 2315
assign 1 0 2319
assign 1 0 2322
assign 1 0 2325
assign 1 799 2329
heldGet 0 799 2329
assign 1 799 2330
literalValueGet 0 799 2330
assign 1 799 2331
add 1 799 2331
literalValueSet 1 799 2332
delete 0 800 2333
return 1 0 2340
assign 1 0 2343
return 1 0 2347
assign 1 0 2350
return 1 0 2354
assign 1 0 2357
return 1 0 2361
assign 1 0 2364
return 1 0 2368
assign 1 0 2371
return 1 0 2375
assign 1 0 2378
return 1 0 2382
assign 1 0 2385
return 1 0 2389
assign 1 0 2392
return 1 0 2396
assign 1 0 2399
return 1 0 2403
assign 1 0 2406
return 1 0 2410
assign 1 0 2413
return 1 0 2417
assign 1 0 2420
return 1 0 2424
assign 1 0 2427
return 1 0 2431
assign 1 0 2434
return 1 0 2438
assign 1 0 2441
return 1 0 2445
assign 1 0 2448
return 1 0 2452
assign 1 0 2455
return 1 0 2459
assign 1 0 2462
return 1 0 2466
assign 1 0 2469
return 1 0 2473
assign 1 0 2476
return 1 0 2480
assign 1 0 2483
return 1 0 2487
assign 1 0 2490
return 1 0 2494
assign 1 0 2497
return 1 0 2501
assign 1 0 2504
return 1 0 2508
assign 1 0 2511
return 1 0 2515
assign 1 0 2518
return 1 0 2522
assign 1 0 2525
return 1 0 2529
assign 1 0 2532
return 1 0 2536
assign 1 0 2539
return 1 0 2543
assign 1 0 2546
return 1 0 2550
assign 1 0 2553
return 1 0 2557
assign 1 0 2560
return 1 0 2564
assign 1 0 2567
return 1 0 2571
assign 1 0 2574
return 1 0 2578
assign 1 0 2581
return 1 0 2585
assign 1 0 2588
return 1 0 2592
assign 1 0 2595
return 1 0 2599
assign 1 0 2602
return 1 0 2606
assign 1 0 2609
return 1 0 2613
assign 1 0 2616
return 1 0 2620
assign 1 0 2623
return 1 0 2627
assign 1 0 2630
return 1 0 2634
assign 1 0 2637
return 1 0 2641
assign 1 0 2644
return 1 0 2648
assign 1 0 2651
return 1 0 2655
assign 1 0 2658
return 1 0 2662
assign 1 0 2665
return 1 0 2669
assign 1 0 2672
return 1 0 2676
assign 1 0 2679
return 1 0 2683
assign 1 0 2686
return 1 0 2690
assign 1 0 2693
return 1 0 2697
assign 1 0 2700
return 1 0 2704
assign 1 0 2707
return 1 0 2711
assign 1 0 2714
return 1 0 2718
assign 1 0 2721
return 1 0 2725
assign 1 0 2728
return 1 0 2732
assign 1 0 2735
return 1 0 2739
assign 1 0 2742
return 1 0 2746
assign 1 0 2749
return 1 0 2753
assign 1 0 2756
return 1 0 2760
assign 1 0 2763
return 1 0 2767
assign 1 0 2770
return 1 0 2774
assign 1 0 2777
return 1 0 2781
assign 1 0 2784
return 1 0 2788
assign 1 0 2791
return 1 0 2795
assign 1 0 2798
return 1 0 2802
assign 1 0 2805
return 1 0 2809
assign 1 0 2812
return 1 0 2816
assign 1 0 2819
return 1 0 2823
assign 1 0 2826
return 1 0 2830
assign 1 0 2833
return 1 0 2837
assign 1 0 2840
return 1 0 2844
assign 1 0 2847
return 1 0 2851
assign 1 0 2854
return 1 0 2858
assign 1 0 2861
assign 1 0 2865
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1315317601: return bem_fieldNamesGet_0();
case 2129201068: return bem_outputPlatformGet_0();
case 1296887765: return bem_classNameGet_0();
case -1888387236: return bem_genOnlyGet_0();
case 1092739862: return bem_buildPathGet_0();
case 2028500612: return bem_buildSucceededGet_0();
case 1495109923: return bem_parseGet_0();
case 324152124: return bem_print_0();
case 1734089055: return bem_printAstElementsGet_0();
case 1955973269: return bem_main_0();
case -1079524022: return bem_saveIdsGet_0();
case -1755774950: return bem_printPlacesGet_0();
case -539553779: return bem_printStepsGet_0();
case -2027882540: return bem_deployFilesFromGet_0();
case 1299499595: return bem_runGet_0();
case 1199406569: return bem_parseTimeGet_0();
case -1691743455: return bem_emitDebugGet_0();
case 1846517036: return bem_constantsGet_0();
case 2047089180: return bem_emitChecksGet_0();
case -2097207996: return bem_emitFlagsGet_0();
case 1773012977: return bem_usedLibrarysGet_0();
case -710310348: return bem_deployFilesToGet_0();
case -1669321034: return bem_makeNameGet_0();
case -1289921058: return bem_mainNameGet_0();
case -193164032: return bem_makeArgsGet_0();
case 2136337845: return bem_codeGet_0();
case -444716269: return bem_paramsGet_0();
case 1789394311: return bem_sharedEmitterGet_0();
case 446269685: return bem_argsGet_0();
case -1746514879: return bem_buildMessageGet_0();
case 1355233848: return bem_loadIdsGet_0();
case -1754807821: return bem_emitCs_0();
case 1123564946: return bem_create_0();
case 436858743: return bem_putLineNumbersInTraceGet_0();
case -761327527: return bem_parseEmitTimeGet_0();
case 2126873131: return bem_ntypesGet_0();
case -498741748: return bem_prepMakeGet_0();
case -2029840745: return bem_extLibsGet_0();
case 229810150: return bem_deployPathGet_0();
case 269315261: return bem_deployLibraryGet_0();
case 992032254: return bem_includePathGet_0();
case -11463442: return bem_nlGet_0();
case 5786705: return bem_linkLibArgsGet_0();
case -664018412: return bem_initLibsGet_0();
case 1190411244: return bem_builtGet_0();
case -547430364: return bem_toString_0();
case 915438396: return bem_printAstGet_0();
case -924795589: return bem_extIncludesGet_0();
case 1720472221: return bem_emitLangsGet_0();
case 604385631: return bem_closeLibrariesGet_0();
case 399093400: return bem_closeLibrariesStrGet_0();
case -330424784: return bem_hashGet_0();
case 292013243: return bem_usedLibrarysStrGet_0();
case -575126788: return bem_extLinkObjectsGet_0();
case 2062498919: return bem_emitLibraryGet_0();
case 2038893695: return bem_emitterGet_0();
case 713851327: return bem_readBufferGet_0();
case 331922877: return bem_libNameGet_0();
case 798510555: return bem_startTimeGet_0();
case 360211337: return bem_loadSynsGet_0();
case 545600326: return bem_newlineGet_0();
case -291615020: return bem_twtokGet_0();
case 571938617: return bem_setClassesToWrite_0();
case 1983072075: return bem_platformGet_0();
case 2117645539: return bem_go_0();
case -98808354: return bem_saveSynsGet_0();
case -1809613435: return bem_toBuildGet_0();
case 900720046: return bem_tagGet_0();
case -1441285544: return bem_fromFileGet_0();
case 505601742: return bem_makeGet_0();
case -372838528: return bem_new_0();
case -1154248657: return bem_doWhat_0();
case -952017043: return bem_runArgsGet_0();
case 1565726735: return bem_ccObjArgsGet_0();
case 884317404: return bem_iteratorGet_0();
case 1132476803: return bem_ownProcessGet_0();
case -1288085492: return bem_copy_0();
case 1757613851: return bem_config_0();
case 259321946: return bem_deployUsedLibrariesGet_0();
case -227734505: return bem_estrGet_0();
case 374121348: return bem_emitDataGet_0();
case -390604104: return bem_doEmitGet_0();
case 493926946: return bem_printAllAstGet_0();
case -2092685666: return bem_parseEmitCompileTimeGet_0();
case -1492721144: return bem_emitPathGet_0();
case 2041298072: return bem_exeNameGet_0();
case -353617: return bem_compilerGet_0();
case -2027840575: return bem_emitCommonGet_0();
case 1077567284: return bem_emitFileHeaderGet_0();
case 1030845965: return bem_singleCCGet_0();
case 1510066780: return bem_lctokGet_0();
case -1298887131: return bem_compilerProfileGet_0();
case 1474960450: return bem_doMainGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 537352604: return bem_ccObjArgsSet_1(bevd_0);
case -1798286526: return bem_lctokSet_1(bevd_0);
case 825182401: return bem_usedLibrarysSet_1(bevd_0);
case 591040370: return bem_extIncludesSet_1(bevd_0);
case -1278090349: return bem_makeNameSet_1(bevd_0);
case 35378670: return bem_libNameSet_1(bevd_0);
case 961705306: return bem_parseTimeSet_1(bevd_0);
case -132008918: return bem_exeNameSet_1(bevd_0);
case 1239113614: return bem_deployFilesFromSet_1(bevd_0);
case -400467597: return bem_toBuildSet_1(bevd_0);
case 907903022: return bem_closeLibrariesStrSet_1(bevd_0);
case 2037388693: return bem_parseSet_1(bevd_0);
case 23686068: return bem_emitChecksSet_1(bevd_0);
case -1825986767: return bem_otherType_1(bevd_0);
case -1455046553: return bem_emitFlagsSet_1(bevd_0);
case -2128390649: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 1862342797: return bem_copyTo_1(bevd_0);
case -1661736110: return bem_buildSucceededSet_1(bevd_0);
case 1291070422: return bem_includePathSet_1(bevd_0);
case -2099076423: return bem_genOnlySet_1(bevd_0);
case 1539345170: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case -502441720: return bem_usedLibrarysStrSet_1(bevd_0);
case 1213114609: return bem_extLinkObjectsSet_1(bevd_0);
case 847515890: return bem_loadIdsSet_1(bevd_0);
case -1029735058: return bem_compilerProfileSet_1(bevd_0);
case -1735201048: return bem_ownProcessSet_1(bevd_0);
case 1890681328: return bem_linkLibArgsSet_1(bevd_0);
case -1591241960: return bem_prepMakeSet_1(bevd_0);
case -678743490: return bem_deployFilesToSet_1(bevd_0);
case 1219194386: return bem_saveIdsSet_1(bevd_0);
case -114446680: return bem_makeArgsSet_1(bevd_0);
case 592595513: return bem_sameType_1(bevd_0);
case 1867730554: return bem_doMainSet_1(bevd_0);
case 294215834: return bem_twtokSet_1(bevd_0);
case 1028450894: return bem_emitFileHeaderSet_1(bevd_0);
case -323056422: return bem_outputPlatformSet_1(bevd_0);
case -233153417: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -175812942: return bem_emitCommonSet_1(bevd_0);
case -35179763: return bem_constantsSet_1(bevd_0);
case 1863587245: return bem_notEquals_1(bevd_0);
case -104934235: return bem_saveSynsSet_1(bevd_0);
case -452650659: return bem_printAllAstSet_1(bevd_0);
case 1463667266: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1571543356: return bem_getSynNp_1(bevd_0);
case -183620630: return bem_deployPathSet_1(bevd_0);
case 1956227154: return bem_emitPathSet_1(bevd_0);
case 1912890932: return bem_equals_1(bevd_0);
case -1602114199: return bem_printAstElementsSet_1(bevd_0);
case 335685784: return bem_buildMessageSet_1(bevd_0);
case -1441758497: return bem_printAstSet_1(bevd_0);
case -621584629: return bem_startTimeSet_1(bevd_0);
case 1007340411: return bem_printPlacesSet_1(bevd_0);
case 2075356837: return bem_nlSet_1(bevd_0);
case -427186060: return bem_newlineSet_1(bevd_0);
case -1676166640: return bem_doParse_1(bevd_0);
case -2119494398: return bem_def_1(bevd_0);
case -1933060362: return bem_readBufferSet_1(bevd_0);
case -1520844079: return bem_argsSet_1(bevd_0);
case 527173041: return bem_emitLangsSet_1(bevd_0);
case 552080956: return bem_ntypesSet_1(bevd_0);
case 1366661138: return bem_runSet_1(bevd_0);
case -1799609678: return bem_sameObject_1(bevd_0);
case -1476232899: return bem_sharedEmitterSet_1(bevd_0);
case -2046024222: return bem_extLibsSet_1(bevd_0);
case 1944797697: return bem_buildPathSet_1(bevd_0);
case -1603292487: return bem_builtSet_1(bevd_0);
case -562055731: return bem_fromFileSet_1(bevd_0);
case -1030552067: return bem_platformSet_1(bevd_0);
case 1203776259: return bem_compilerSet_1(bevd_0);
case 118909513: return bem_loadSynsSet_1(bevd_0);
case 676661369: return bem_parseEmitTimeSet_1(bevd_0);
case 482276625: return bem_initLibsSet_1(bevd_0);
case -1240768243: return bem_estrSet_1(bevd_0);
case 721681717: return bem_buildSyns_1(bevd_0);
case -1372515649: return bem_emitLibrarySet_1(bevd_0);
case -158673770: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2094542838: return bem_mainNameSet_1(bevd_0);
case 59007535: return bem_emitDataSet_1(bevd_0);
case -928168257: return bem_runArgsSet_1(bevd_0);
case -1519183985: return bem_printStepsSet_1(bevd_0);
case -1663552981: return bem_emitDebugSet_1(bevd_0);
case -1875098735: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 854282774: return bem_deployLibrarySet_1(bevd_0);
case -1290374989: return bem_undef_1(bevd_0);
case -1100868786: return bem_makeSet_1(bevd_0);
case -1334750151: return bem_codeSet_1(bevd_0);
case -1195828773: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 1034218051: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -1118032155: return bem_deployUsedLibrariesSet_1(bevd_0);
case -1442856222: return bem_doEmitSet_1(bevd_0);
case -1542880827: return bem_paramsSet_1(bevd_0);
case 1078864692: return bem_singleCCSet_1(bevd_0);
case -2049428825: return bem_closeLibrariesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1154474937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1719469512: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 803955704: return bem_getSyn_2(bevd_0, bevd_1);
case 3383792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1239510465: return bem_buildLiteral_2(bevd_0, bevd_1);
case -601625846: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1688393011: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 826572174: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
