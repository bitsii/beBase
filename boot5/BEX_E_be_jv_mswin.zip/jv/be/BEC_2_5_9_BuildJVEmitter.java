package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_8, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_9, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_10, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_12, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_13, 14));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_14, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_27, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_28, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1157812093);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(264279930);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 46 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 59 */
 else  /* Line: 59 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 59 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
return bevt_3_tmpany_phold;
} /* Line: 60 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 66 */
 else  /* Line: 66 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 66 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
return bevt_3_tmpany_phold;
} /* Line: 67 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(632016711);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 37, 37, 37, 37, 37, 42, 43, 44, 44, 45, 45, 46, 46, 48, 48, 48, 49, 55, 55, 55, 55, 55, 55, 59, 59, 59, 0, 0, 0, 60, 60, 62, 62, 66, 66, 66, 0, 0, 0, 67, 67, 69, 69, 73, 73, 77, 77, 77, 77, 77, 78, 78, 78, 78, 78, 78, 79, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 81, 85, 85, 85, 89, 89, 89, 89, 89, 89, 89, 93, 93, 97, 97, 101, 101, 101, 101};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {54, 55, 56, 57, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 105, 106, 107, 108, 109, 119, 120, 121, 122, 124, 125, 126, 127, 129, 130, 131, 132, 141, 142, 143, 144, 145, 146, 154, 159, 160, 162, 165, 169, 172, 173, 175, 176, 184, 189, 190, 192, 195, 199, 202, 203, 205, 206, 210, 211, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 260, 261, 262, 271, 272, 273, 274, 275, 276, 277, 281, 282, 286, 287, 293, 294, 295, 296};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 54
new 0 17 54
assign 1 18 55
new 0 18 55
assign 1 19 56
new 0 19 56
new 1 23 57
assign 1 27 78
new 0 27 78
assign 1 27 79
toString 0 27 79
assign 1 27 80
add 1 27 80
incrementValue 0 28 81
assign 1 29 82
new 0 29 82
assign 1 29 83
addValue 1 29 83
assign 1 29 84
addValue 1 29 84
assign 1 29 85
new 0 29 85
assign 1 29 86
addValue 1 29 86
addValue 1 29 87
assign 1 31 88
containedGet 0 31 88
assign 1 31 89
firstGet 0 31 89
assign 1 31 90
containedGet 0 31 90
assign 1 31 91
firstGet 0 31 91
assign 1 31 92
new 0 31 92
assign 1 31 93
add 1 31 93
assign 1 31 94
new 0 31 94
assign 1 31 95
add 1 31 95
assign 1 31 96
finalAssign 4 31 96
addValue 1 31 97
assign 1 37 105
new 0 37 105
assign 1 37 106
add 1 37 106
assign 1 37 107
new 0 37 107
assign 1 37 108
add 1 37 108
return 1 37 109
getInt 2 42 119
assign 1 43 120
toHexString 1 43 120
assign 1 44 121
new 0 44 121
assign 1 44 122
begins 1 44 122
assign 1 45 124
new 0 45 124
assign 1 45 125
substring 1 45 125
assign 1 46 126
new 0 46 126
addValue 1 46 127
assign 1 48 129
new 0 48 129
assign 1 48 130
once 0 48 130
addValue 1 48 131
addValue 1 49 132
assign 1 55 141
new 0 55 141
assign 1 55 142
add 1 55 142
assign 1 55 143
new 0 55 143
assign 1 55 144
add 1 55 144
assign 1 55 145
add 1 55 145
return 1 55 146
assign 1 59 154
def 1 59 159
assign 1 59 160
isFinalGet 0 59 160
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 60 172
new 0 60 172
return 1 60 173
assign 1 62 175
new 0 62 175
return 1 62 176
assign 1 66 184
def 1 66 189
assign 1 66 190
isFinalGet 0 66 190
assign 1 0 192
assign 1 0 195
assign 1 0 199
assign 1 67 202
new 0 67 202
return 1 67 203
assign 1 69 205
new 0 69 205
return 1 69 206
assign 1 73 210
new 0 73 210
return 1 73 211
assign 1 77 233
new 0 77 233
assign 1 77 234
add 1 77 234
assign 1 77 235
new 0 77 235
assign 1 77 236
add 1 77 236
assign 1 77 237
add 1 77 237
assign 1 78 238
new 0 78 238
assign 1 78 239
addValue 1 78 239
assign 1 78 240
addValue 1 78 240
assign 1 78 241
new 0 78 241
assign 1 78 242
addValue 1 78 242
addValue 1 78 243
assign 1 79 244
new 0 79 244
assign 1 79 245
addValue 1 79 245
addValue 1 79 246
assign 1 80 247
new 0 80 247
assign 1 80 248
addValue 1 80 248
assign 1 80 249
outputPlatformGet 0 80 249
assign 1 80 250
nameGet 0 80 250
assign 1 80 251
addValue 1 80 251
assign 1 80 252
new 0 80 252
assign 1 80 253
addValue 1 80 253
addValue 1 80 254
return 1 81 255
assign 1 85 260
libNameGet 0 85 260
assign 1 85 261
beginNs 1 85 261
return 1 85 262
assign 1 89 271
new 0 89 271
assign 1 89 272
libNs 1 89 272
assign 1 89 273
add 1 89 273
assign 1 89 274
new 0 89 274
assign 1 89 275
add 1 89 275
assign 1 89 276
add 1 89 276
return 1 89 277
assign 1 93 281
getNameSpace 1 93 281
return 1 93 282
assign 1 97 286
new 0 97 286
return 1 97 287
assign 1 101 293
new 0 101 293
assign 1 101 294
once 0 101 294
assign 1 101 295
add 1 101 295
return 1 101 296
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -686526896: return bem_smnlcsGet_0();
case 1289115232: return bem_mainEndGet_0();
case 646312611: return bem_maxDynArgsGet_0();
case 169190902: return bem_mainStartGet_0();
case 743136961: return bem_dynMethodsGet_0();
case -1094733154: return bem_methodCallsGet_0();
case -801589503: return bem_tagGet_0();
case -29400896: return bem_create_0();
case -1748853456: return bem_nullValueGet_0();
case -80890995: return bem_instanceEqualGet_0();
case -638323518: return bem_runtimeInitGet_0();
case 1101321837: return bem_dynConditionsAllGet_0();
case -983678491: return bem_nativeCSlotsGet_0();
case 1338975369: return bem_sourceFileNameGet_0();
case 401357109: return bem_stringNpGet_0();
case -158357292: return bem_constGet_0();
case -1749103224: return bem_iteratorGet_0();
case -831730160: return bem_boolTypeGet_0();
case -1519136463: return bem_lastMethodsSizeGet_0();
case 706564462: return bem_mnodeGet_0();
case 1556112321: return bem_lastMethodsLinesGet_0();
case -14402816: return bem_serializeContents_0();
case -384834396: return bem_buildInitial_0();
case -85727172: return bem_baseSmtdDecGet_0();
case -7634332: return bem_classNameGet_0();
case 260824229: return bem_inFilePathedGet_0();
case 313105347: return bem_libEmitPathGet_0();
case -258597009: return bem_hashGet_0();
case -251850191: return bem_fullLibEmitNameGet_0();
case -748319096: return bem_print_0();
case 1561204422: return bem_ccMethodsGet_0();
case -1320317071: return bem_idToNameGet_0();
case 572235661: return bem_exceptDecGet_0();
case -1761261731: return bem_synEmitPathGet_0();
case -1701242685: return bem_serializationIteratorGet_0();
case 1806318302: return bem_objectCcGet_0();
case 1827688013: return bem_fileExtGet_0();
case -418299044: return bem_intNpGet_0();
case 832758816: return bem_mainOutsideNsGet_0();
case -921508588: return bem_getClassOutput_0();
case -1354540042: return bem_preClassGet_0();
case -1052800757: return bem_echo_0();
case -1498370492: return bem_emitLangGet_0();
case 1018672567: return bem_classCallsGet_0();
case -624627080: return bem_methodsGet_0();
case -794227383: return bem_copy_0();
case -1627148521: return bem_emitLib_0();
case -112649758: return bem_ccCacheGet_0();
case 1588434021: return bem_methodBodyGet_0();
case -170441578: return bem_buildClassInfo_0();
case 2025682641: return bem_lastMethodBodySizeGet_0();
case -252253738: return bem_beginNs_0();
case -1210661662: return bem_classEndGet_0();
case 846910289: return bem_classConfGet_0();
case -467186719: return bem_deserializeClassNameGet_0();
case 2078619893: return bem_callNamesGet_0();
case 243155646: return bem_superNameGet_0();
case 2053720153: return bem_parentConfGet_0();
case -692222890: return bem_doEmit_0();
case -1008530793: return bem_propertyDecsGet_0();
case -1129578589: return bem_onceCountGet_0();
case 9888438: return bem_maxSpillArgsLenGet_0();
case -848782467: return bem_randGet_0();
case 741616125: return bem_buildCreate_0();
case -124916815: return bem_new_0();
case 623766499: return bem_transGet_0();
case -2136197792: return bem_csynGet_0();
case 825942463: return bem_useDynMethodsGet_0();
case -633088031: return bem_methodCatchGet_0();
case 900978335: return bem_serializeToString_0();
case 1296967271: return bem_endNs_0();
case -530169935: return bem_saveSyns_0();
case 2064001927: return bem_nameToIdGet_0();
case -442603592: return bem_msynGet_0();
case 782283455: return bem_buildGet_0();
case 983603268: return bem_lastMethodBodyLinesGet_0();
case -1399953729: return bem_lastCallGet_0();
case -1857422733: return bem_instanceNotEqualGet_0();
case -1699352621: return bem_lineCountGet_0();
case 1262846964: return bem_boolNpGet_0();
case -93701646: return bem_fieldIteratorGet_0();
case -232854273: return bem_overrideMtdDecGet_0();
case 198499627: return bem_nlGet_0();
case -950858708: return bem_initialDecGet_0();
case 1902587985: return bem_afterCast_0();
case -1676134252: return bem_ntypesGet_0();
case -149632320: return bem_toAny_0();
case -970976781: return bem_spropDecGet_0();
case 214312139: return bem_classesInDepthOrderGet_0();
case -1892936231: return bem_invpGet_0();
case -447554703: return bem_trueValueGet_0();
case -1768301008: return bem_classEmitsGet_0();
case -5612807: return bem_returnTypeGet_0();
case -1794032136: return bem_objectNpGet_0();
case 1684937907: return bem_baseMtdDecGet_0();
case -105256852: return bem_smnlecsGet_0();
case -1752113305: return bem_propDecGet_0();
case -401679345: return bem_qGet_0();
case 416229281: return bem_instOfGet_0();
case -1674098047: return bem_once_0();
case 619377723: return bem_superCallsGet_0();
case -1507112748: return bem_mainInClassGet_0();
case -1981241075: return bem_cnodeGet_0();
case -1318429004: return bem_libEmitNameGet_0();
case 1467452194: return bem_onceDecsGet_0();
case 772928368: return bem_boolCcGet_0();
case 1919444630: return bem_coanyiantReturnsGet_0();
case 861710738: return bem_many_0();
case 210300047: return bem_getLibOutput_0();
case 1793055235: return bem_scvpGet_0();
case -51803385: return bem_toString_0();
case -751129125: return bem_falseValueGet_0();
case 171441328: return bem_floatNpGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case -55540991: return bem_csynSet_1(bevd_0);
case -13507689: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 550176080: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1069939989: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1947685773: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -143726495: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2003868871: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1927920191: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1496983862: return bem_falseValueSet_1(bevd_0);
case 1317056416: return bem_cnodeSet_1(bevd_0);
case -508186196: return bem_constSet_1(bevd_0);
case -1465394056: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 725994950: return bem_returnTypeSet_1(bevd_0);
case 1975193630: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -510189115: return bem_superCallsSet_1(bevd_0);
case -323970299: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1608990829: return bem_fileExtSet_1(bevd_0);
case -2058851159: return bem_nameToIdSet_1(bevd_0);
case -2144315142: return bem_dynMethodsSet_1(bevd_0);
case -271716565: return bem_copyTo_1(bevd_0);
case -893988694: return bem_methodCatchSet_1(bevd_0);
case -549228321: return bem_nlSet_1(bevd_0);
case 2036979549: return bem_notEquals_1(bevd_0);
case -1391202250: return bem_defined_1(bevd_0);
case 686141135: return bem_intNpSet_1(bevd_0);
case -1893652508: return bem_objectNpSet_1(bevd_0);
case -48787781: return bem_exceptDecSet_1(bevd_0);
case 161044160: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 916835450: return bem_nullValueSet_1(bevd_0);
case 59208047: return bem_methodCallsSet_1(bevd_0);
case 1298039805: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -680215976: return bem_smnlecsSet_1(bevd_0);
case -900014256: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1938034940: return bem_objectCcSet_1(bevd_0);
case -1474617116: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1475711713: return bem_libEmitPathSet_1(bevd_0);
case -1720439244: return bem_maxDynArgsSet_1(bevd_0);
case 1951868745: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -72183642: return bem_instOfSet_1(bevd_0);
case -1782121914: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1385140950: return bem_nativeCSlotsSet_1(bevd_0);
case -1474467614: return bem_sameObject_1(bevd_0);
case 1514684415: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1182473490: return bem_emitLangSet_1(bevd_0);
case -20159434: return bem_sameClass_1(bevd_0);
case 204012795: return bem_onceCountSet_1(bevd_0);
case -93273669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -218714893: return bem_otherClass_1(bevd_0);
case 867473240: return bem_classCallsSet_1(bevd_0);
case 1763700501: return bem_methodBodySet_1(bevd_0);
case -536696310: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -723873397: return bem_libEmitNameSet_1(bevd_0);
case -1971967519: return bem_instanceNotEqualSet_1(bevd_0);
case -1795363742: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -305636310: return bem_classConfSet_1(bevd_0);
case 1880801153: return bem_invpSet_1(bevd_0);
case -2047606979: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1215081889: return bem_lastMethodsLinesSet_1(bevd_0);
case 1249785847: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1518481031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -55113408: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1738828302: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 739217867: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -936099757: return bem_stringNpSet_1(bevd_0);
case -731106658: return bem_dynConditionsAllSet_1(bevd_0);
case -73997568: return bem_equals_1(bevd_0);
case -799054022: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 153220112: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 634833325: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1120987931: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 616348580: return bem_undef_1(bevd_0);
case -292704689: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1970850163: return bem_sameType_1(bevd_0);
case 1489034049: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 2119251036: return bem_inFilePathedSet_1(bevd_0);
case 804124553: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1669919745: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1739048164: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1219437319: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -978063481: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1759831970: return bem_msynSet_1(bevd_0);
case 238734227: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -2000463908: return bem_synEmitPathSet_1(bevd_0);
case 328134054: return bem_classEmitsSet_1(bevd_0);
case -2122321974: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 2078724986: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 226940097: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 998734234: return bem_methodsSet_1(bevd_0);
case -1122418858: return bem_preClassSet_1(bevd_0);
case -2137832607: return bem_floatNpSet_1(bevd_0);
case 674368499: return bem_boolCcSet_1(bevd_0);
case 165460605: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 303444697: return bem_randSet_1(bevd_0);
case -1270031418: return bem_lastCallSet_1(bevd_0);
case 329092609: return bem_propertyDecsSet_1(bevd_0);
case 1398683235: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1113722368: return bem_instanceEqualSet_1(bevd_0);
case 204230402: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -581518899: return bem_transSet_1(bevd_0);
case -1069104086: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1365566441: return bem_lineCountSet_1(bevd_0);
case 1126993929: return bem_onceDecsSet_1(bevd_0);
case -1111723008: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -683940705: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1913160749: return bem_trueValueSet_1(bevd_0);
case 1551366169: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 88357849: return bem_maxSpillArgsLenSet_1(bevd_0);
case 543957267: return bem_ntypesSet_1(bevd_0);
case -1544582466: return bem_qSet_1(bevd_0);
case -1093477870: return bem_ccCacheSet_1(bevd_0);
case -354990343: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 649612856: return bem_classesInDepthOrderSet_1(bevd_0);
case -1759972490: return bem_parentConfSet_1(bevd_0);
case -1386992522: return bem_ccMethodsSet_1(bevd_0);
case -223966486: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -258846754: return bem_callNamesSet_1(bevd_0);
case 642489795: return bem_otherType_1(bevd_0);
case -27221069: return bem_begin_1(bevd_0);
case 2004187703: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1122140130: return bem_scvpSet_1(bevd_0);
case -2092712540: return bem_def_1(bevd_0);
case -525519210: return bem_idToNameSet_1(bevd_0);
case 2016780421: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -172627648: return bem_buildSet_1(bevd_0);
case -983540661: return bem_undefined_1(bevd_0);
case 889117087: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -43832882: return bem_boolNpSet_1(bevd_0);
case 1919721914: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -911141906: return bem_lastMethodsSizeSet_1(bevd_0);
case -1678381429: return bem_mnodeSet_1(bevd_0);
case 1240129037: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -387099569: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -886625403: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1553858596: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1468098607: return bem_smnlcsSet_1(bevd_0);
case -679363398: return bem_end_1(bevd_0);
case -237368135: return bem_fullLibEmitNameSet_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case -66460559: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -174490161: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1295728935: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 2131321099: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2034641124: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 434064388: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 46109010: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1854709409: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1653170418: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 292502272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1031466779: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -210077967: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -323049121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -925035484: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -909550162: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2093180987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1367679335: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 159386409: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1857333654: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callCase) {
case -257014373: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1451824755: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1855707873: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callCase, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callCase) {
case -398231886: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callCase, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callCase) {
case 1042789001: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -1379087472: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1144060762: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callCase, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
}
