package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(445478930);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(155731488);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(155731488);
bevt_34_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_34_ta_ph.bevi_bool))/* Line: 51*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 52*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 53*/
 else /* Line: 54*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_35_ta_ph);
} /* Line: 55*/
bevt_37_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_38_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_36_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 57*/
} /* Line: 51*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_43_ta_ph = bevl_bet.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_42_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevl_tout.bemd_1(951024182, bevl_bet);
bevl_tout.bemd_0(-97446410);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-752195810);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1491925069);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_21));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_0_ta_ph = bevl_bc.bem_begins_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 85*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
beva_sdec.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 87*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
beva_sdec.bem_addValue_1(bevt_4_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 100*/
 else /* Line: 100*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 100*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 101*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 107*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 107*/
 else /* Line: 107*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 107*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 108*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_exceptDec);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_ms = bevt_0_ta_ph.bem_add_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_30));
bevt_6_ta_ph = bevl_ms.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_9_ta_ph = bevl_ms.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1967536104);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 51, 53, 55, 55, 57, 57, 57, 57, 60, 60, 62, 62, 64, 64, 65, 65, 65, 65, 65, 65, 66, 66, 67, 67, 68, 69, 73, 73, 73, 74, 75, 75, 75, 75, 75, 75, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 83, 84, 85, 85, 86, 86, 87, 87, 89, 89, 90, 96, 96, 96, 96, 96, 96, 100, 100, 100, 0, 0, 0, 101, 101, 103, 103, 107, 107, 107, 0, 0, 0, 108, 108, 110, 110, 114, 114, 118, 118, 118, 118, 118, 119, 119, 119, 119, 119, 119, 120, 120, 120, 121, 121, 121, 121, 121, 121, 121, 121, 122, 126, 126, 126, 130, 130, 130, 130, 130, 130, 130, 134, 134, 138, 138, 142, 142, 142};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {51, 52, 53, 54, 113, 114, 115, 116, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 149, 152, 154, 156, 159, 160, 162, 163, 164, 165, 171, 172, 173, 174, 175, 176, 177, 178, 179, 179, 182, 184, 185, 188, 191, 192, 194, 195, 196, 197, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 271, 272, 273, 274, 276, 277, 278, 279, 281, 282, 283, 292, 293, 294, 295, 296, 297, 305, 310, 311, 313, 316, 320, 323, 324, 326, 327, 335, 340, 341, 343, 346, 350, 353, 354, 356, 357, 361, 362, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 411, 412, 413, 422, 423, 424, 425, 426, 427, 428, 432, 433, 437, 438, 443, 444, 445};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 51
new 0 16 51
assign 1 17 52
new 0 17 52
assign 1 18 53
new 0 18 53
new 1 22 54
assign 1 26 113
classDirGet 0 26 113
assign 1 26 114
fileGet 0 26 114
assign 1 26 115
existsGet 0 26 115
assign 1 26 116
not 0 26 121
assign 1 27 122
classDirGet 0 27 122
assign 1 27 123
fileGet 0 27 123
makeDirs 0 27 124
assign 1 29 126
typePathGet 0 29 126
assign 1 29 127
fileGet 0 29 127
assign 1 29 128
writerGet 0 29 128
assign 1 29 129
open 0 29 129
assign 1 30 130
new 0 30 130
assign 1 31 131
new 0 31 131
addValue 1 31 132
assign 1 32 133
new 0 32 133
assign 1 32 134
addValue 1 32 134
assign 1 32 135
typeEmitNameGet 0 32 135
assign 1 32 136
addValue 1 32 136
assign 1 32 137
new 0 32 137
addValue 1 32 138
assign 1 33 139
new 0 33 139
assign 1 33 140
addValue 1 33 140
assign 1 33 141
typeEmitNameGet 0 33 141
assign 1 33 142
addValue 1 33 142
assign 1 33 143
new 0 33 143
addValue 1 33 144
assign 1 35 145
new 0 35 145
addValue 1 35 146
assign 1 36 147
new 0 36 147
assign 1 37 148
mtdListGet 0 37 148
assign 1 37 149
iteratorGet 0 0 149
assign 1 37 152
hasNextGet 0 37 152
assign 1 37 154
nextGet 0 37 154
assign 1 39 156
new 0 39 156
assign 1 41 159
new 0 41 159
addValue 1 41 160
assign 1 43 162
addValue 1 43 162
assign 1 43 163
nameGet 0 43 163
assign 1 43 164
addValue 1 43 164
addValue 1 43 165
assign 1 45 171
new 0 45 171
addValue 1 45 172
assign 1 46 173
new 0 46 173
addValue 1 46 174
assign 1 48 175
new 0 48 175
addValue 1 48 176
assign 1 49 177
new 0 49 177
assign 1 50 178
ptyListGet 0 50 178
assign 1 50 179
iteratorGet 0 0 179
assign 1 50 182
hasNextGet 0 50 182
assign 1 50 184
nextGet 0 50 184
assign 1 51 185
isSlotGet 0 51 185
assign 1 53 188
new 0 53 188
assign 1 55 191
new 0 55 191
addValue 1 55 192
assign 1 57 194
addValue 1 57 194
assign 1 57 195
nameGet 0 57 195
assign 1 57 196
addValue 1 57 196
addValue 1 57 197
assign 1 60 204
new 0 60 204
addValue 1 60 205
assign 1 62 206
new 0 62 206
addValue 1 62 207
assign 1 64 208
new 0 64 208
addValue 1 64 209
assign 1 65 210
new 0 65 210
assign 1 65 211
addValue 1 65 211
assign 1 65 212
emitNameGet 0 65 212
assign 1 65 213
addValue 1 65 213
assign 1 65 214
new 0 65 214
addValue 1 65 215
assign 1 66 216
new 0 66 216
addValue 1 66 217
assign 1 67 218
new 0 67 218
addValue 1 67 219
write 1 68 220
close 0 69 221
assign 1 73 242
new 0 73 242
assign 1 73 243
toString 0 73 243
assign 1 73 244
add 1 73 244
incrementValue 0 74 245
assign 1 75 246
new 0 75 246
assign 1 75 247
addValue 1 75 247
assign 1 75 248
addValue 1 75 248
assign 1 75 249
new 0 75 249
assign 1 75 250
addValue 1 75 250
addValue 1 75 251
assign 1 77 252
containedGet 0 77 252
assign 1 77 253
firstGet 0 77 253
assign 1 77 254
containedGet 0 77 254
assign 1 77 255
firstGet 0 77 255
assign 1 77 256
new 0 77 256
assign 1 77 257
add 1 77 257
assign 1 77 258
new 0 77 258
assign 1 77 259
add 1 77 259
assign 1 77 260
finalAssign 4 77 260
addValue 1 77 261
getInt 2 83 271
assign 1 84 272
toHexString 1 84 272
assign 1 85 273
new 0 85 273
assign 1 85 274
begins 1 85 274
assign 1 86 276
new 0 86 276
assign 1 86 277
substring 1 86 277
assign 1 87 278
new 0 87 278
addValue 1 87 279
assign 1 89 281
new 0 89 281
addValue 1 89 282
addValue 1 90 283
assign 1 96 292
new 0 96 292
assign 1 96 293
add 1 96 293
assign 1 96 294
new 0 96 294
assign 1 96 295
add 1 96 295
assign 1 96 296
add 1 96 296
return 1 96 297
assign 1 100 305
def 1 100 310
assign 1 100 311
isFinalGet 0 100 311
assign 1 0 313
assign 1 0 316
assign 1 0 320
assign 1 101 323
new 0 101 323
return 1 101 324
assign 1 103 326
new 0 103 326
return 1 103 327
assign 1 107 335
def 1 107 340
assign 1 107 341
isFinalGet 0 107 341
assign 1 0 343
assign 1 0 346
assign 1 0 350
assign 1 108 353
new 0 108 353
return 1 108 354
assign 1 110 356
new 0 110 356
return 1 110 357
assign 1 114 361
new 0 114 361
return 1 114 362
assign 1 118 384
new 0 118 384
assign 1 118 385
add 1 118 385
assign 1 118 386
new 0 118 386
assign 1 118 387
add 1 118 387
assign 1 118 388
add 1 118 388
assign 1 119 389
new 0 119 389
assign 1 119 390
addValue 1 119 390
assign 1 119 391
addValue 1 119 391
assign 1 119 392
new 0 119 392
assign 1 119 393
addValue 1 119 393
addValue 1 119 394
assign 1 120 395
new 0 120 395
assign 1 120 396
addValue 1 120 396
addValue 1 120 397
assign 1 121 398
new 0 121 398
assign 1 121 399
addValue 1 121 399
assign 1 121 400
outputPlatformGet 0 121 400
assign 1 121 401
nameGet 0 121 401
assign 1 121 402
addValue 1 121 402
assign 1 121 403
new 0 121 403
assign 1 121 404
addValue 1 121 404
addValue 1 121 405
return 1 122 406
assign 1 126 411
libNameGet 0 126 411
assign 1 126 412
beginNs 1 126 412
return 1 126 413
assign 1 130 422
new 0 130 422
assign 1 130 423
libNs 1 130 423
assign 1 130 424
add 1 130 424
assign 1 130 425
new 0 130 425
assign 1 130 426
add 1 130 426
assign 1 130 427
add 1 130 427
return 1 130 428
assign 1 134 432
getNameSpace 1 134 432
return 1 134 433
assign 1 138 437
new 0 138 437
return 1 138 438
assign 1 142 443
new 0 142 443
assign 1 142 444
add 1 142 444
return 1 142 445
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -842174414: return bem_maxSpillArgsLenGet_0();
case 1563023391: return bem_preClassGet_0();
case -479088429: return bem_classCallsGet_0();
case -464274831: return bem_instanceEqualGet_0();
case 92759149: return bem_csynGet_0();
case -1098635384: return bem_smnlcsGet_0();
case -550778756: return bem_qGet_0();
case -107675124: return bem_instOfGet_0();
case -1337802702: return bem_doEmit_0();
case 572942595: return bem_create_0();
case 1576391522: return bem_baseSmtdDecGet_0();
case -1433082250: return bem_lastMethodBodySizeGet_0();
case 1660691500: return bem_propDecGet_0();
case 492402303: return bem_beginNs_0();
case -2021786039: return bem_overrideMtdDecGet_0();
case 1077092133: return bem_baseMtdDecGet_0();
case -1225845477: return bem_covariantReturnsGet_0();
case -1808863306: return bem_classesInDepthOrderGet_0();
case -1747504218: return bem_inClassGet_0();
case 593600550: return bem_toString_0();
case 2118574777: return bem_constGet_0();
case -1088779047: return bem_mnodeGet_0();
case 1742904023: return bem_buildGet_0();
case 377909304: return bem_buildClassInfo_0();
case -473565714: return bem_initialDecGet_0();
case 1344351423: return bem_gcMarksGet_0();
case -830092599: return bem_ntypesGet_0();
case -1640809610: return bem_boolTypeGet_0();
case -29382659: return bem_writeBET_0();
case 1957007343: return bem_emitLib_0();
case -235372539: return bem_afterCast_0();
case 1802236174: return bem_newDecGet_0();
case -643803600: return bem_intNpGet_0();
case 220731140: return bem_methodsGet_0();
case 1496650433: return bem_lastMethodsSizeGet_0();
case 916511308: return bem_print_0();
case -134171401: return bem_boolNpGet_0();
case -1092464524: return bem_nameToIdPathGet_0();
case -1621043779: return bem_trueValueGet_0();
case -529087053: return bem_invpGet_0();
case -593179039: return bem_hashGet_0();
case -1436535291: return bem_inFilePathedGet_0();
case -93730680: return bem_buildCreate_0();
case 661229218: return bem_classEndGet_0();
case 1421119965: return bem_saveSyns_0();
case 1927062381: return bem_buildInitial_0();
case 90811774: return bem_classConfGet_0();
case -105495106: return bem_scvpGet_0();
case -296696183: return bem_lineCountGet_0();
case 1384547436: return bem_maxDynArgsGet_0();
case -389120297: return bem_preClassOutput_0();
case 516342665: return bem_smnlecsGet_0();
case 1888624041: return bem_propertyDecsGet_0();
case -929282480: return bem_idToNameGet_0();
case 1472228653: return bem_callNamesGet_0();
case -1635801782: return bem_fullLibEmitNameGet_0();
case 2023291228: return bem_getClassOutput_0();
case 1243297989: return bem_belslitsGet_0();
case 1304976611: return bem_objectCcGet_0();
case -557172869: return bem_fileExtGet_0();
case -269318132: return bem_endNs_0();
case -33356755: return bem_transGet_0();
case -8508210: return bem_classEmitsGet_0();
case 1439270064: return bem_saveIds_0();
case -410583285: return bem_lastCallGet_0();
case 1134574585: return bem_boolCcGet_0();
case -1186528459: return bem_lastMethodsLinesGet_0();
case -1125513683: return bem_getLibOutput_0();
case -62324912: return bem_spropDecGet_0();
case -1007757125: return bem_emitLangGet_0();
case 908392315: return bem_instanceNotEqualGet_0();
case -1867678068: return bem_floatNpGet_0();
case -1802001012: return bem_stringNpGet_0();
case 779510467: return bem_useDynMethodsGet_0();
case 733983974: return bem_nameToIdGet_0();
case -316167854: return bem_cnodeGet_0();
case -1942079604: return bem_objectNpGet_0();
case -1611079151: return bem_exceptDecGet_0();
case 1757997629: return bem_ccCacheGet_0();
case -509281348: return bem_new_0();
case -999073190: return bem_nlGet_0();
case 1964269806: return bem_typeDecGet_0();
case -297022358: return bem_libEmitNameGet_0();
case 1690325984: return bem_methodCatchGet_0();
case -1128741483: return bem_superCallsGet_0();
case -1941488754: return bem_synEmitPathGet_0();
case 1377393171: return bem_iteratorGet_0();
case 1031650463: return bem_returnTypeGet_0();
case -1919366883: return bem_loadIds_0();
case -100741834: return bem_lastMethodBodyLinesGet_0();
case -1185722199: return bem_mainOutsideNsGet_0();
case -1436588716: return bem_copy_0();
case 1729706035: return bem_superNameGet_0();
case 1661302291: return bem_falseValueGet_0();
case -714598263: return bem_mainEndGet_0();
case 1202612685: return bem_parentConfGet_0();
case 1749667450: return bem_libEmitPathGet_0();
case -855176284: return bem_runtimeInitGet_0();
case 2004043873: return bem_onceDecsGet_0();
case -554715026: return bem_methodBodyGet_0();
case 1691985781: return bem_randGet_0();
case 2003646831: return bem_mainStartGet_0();
case -406427064: return bem_mainInClassGet_0();
case -1714497055: return bem_idToNamePathGet_0();
case 473503192: return bem_nativeCSlotsGet_0();
case -1987566143: return bem_ccMethodsGet_0();
case 992469363: return bem_methodCallsGet_0();
case 1141439822: return bem_nullValueGet_0();
case -1117295410: return bem_dynMethodsGet_0();
case -1161229044: return bem_msynGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 187038508: return bem_preClassSet_1(bevd_0);
case 1350908520: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1132397886: return bem_classesInDepthOrderSet_1(bevd_0);
case -1239385327: return bem_undef_1(bevd_0);
case -1214456993: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 740081825: return bem_notEquals_1(bevd_0);
case 1580178633: return bem_idToNameSet_1(bevd_0);
case -1410398479: return bem_lastMethodBodySizeSet_1(bevd_0);
case -898451317: return bem_methodCallsSet_1(bevd_0);
case -1718369094: return bem_trueValueSet_1(bevd_0);
case -1118077405: return bem_synEmitPathSet_1(bevd_0);
case -651084528: return bem_instOfSet_1(bevd_0);
case 1245042803: return bem_methodsSet_1(bevd_0);
case 1793004133: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1874807960: return bem_msynSet_1(bevd_0);
case 1008582343: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1918546308: return bem_nameToIdSet_1(bevd_0);
case -1546435571: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1759367774: return bem_fullLibEmitNameSet_1(bevd_0);
case 1963482048: return bem_lastMethodsLinesSet_1(bevd_0);
case 676384239: return bem_floatNpSet_1(bevd_0);
case 152454017: return bem_def_1(bevd_0);
case 657458251: return bem_onceDecsSet_1(bevd_0);
case -684818523: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1874882310: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -902462867: return bem_classConfSet_1(bevd_0);
case -174777273: return bem_nlSet_1(bevd_0);
case 1973594863: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -2111440306: return bem_methodBodySet_1(bevd_0);
case -1471223660: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 93152968: return bem_fileExtSet_1(bevd_0);
case 470778783: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1027353802: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1406789603: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 105327910: return bem_falseValueSet_1(bevd_0);
case -1819682386: return bem_randSet_1(bevd_0);
case 1057755516: return bem_lineCountSet_1(bevd_0);
case -885379501: return bem_libEmitNameSet_1(bevd_0);
case -1633963528: return bem_maxDynArgsSet_1(bevd_0);
case -1116278553: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 499839279: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 409759068: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1872523372: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1496215653: return bem_returnTypeSet_1(bevd_0);
case 1753266721: return bem_intNpSet_1(bevd_0);
case 1442839527: return bem_inClassSet_1(bevd_0);
case 1793850747: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1461476268: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1490966740: return bem_copyTo_1(bevd_0);
case -262828205: return bem_invpSet_1(bevd_0);
case -1550806262: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1130625629: return bem_qSet_1(bevd_0);
case 608788503: return bem_dynMethodsSet_1(bevd_0);
case 1809271333: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -225299585: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1573708121: return bem_lastCallSet_1(bevd_0);
case 154074191: return bem_stringNpSet_1(bevd_0);
case 1675414103: return bem_boolNpSet_1(bevd_0);
case 1829516969: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 751705064: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -2048604678: return bem_boolCcSet_1(bevd_0);
case -257664443: return bem_equals_1(bevd_0);
case 1629059833: return bem_propertyDecsSet_1(bevd_0);
case -1288910127: return bem_methodCatchSet_1(bevd_0);
case 580377949: return bem_belslitsSet_1(bevd_0);
case 622994737: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1068863371: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 617605031: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -140140499: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1299917123: return bem_cnodeSet_1(bevd_0);
case 454497094: return bem_classCallsSet_1(bevd_0);
case 928389621: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1848583900: return bem_callNamesSet_1(bevd_0);
case 1028904411: return bem_instanceNotEqualSet_1(bevd_0);
case 1566658628: return bem_objectCcSet_1(bevd_0);
case -1814022395: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1768811332: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -709489163: return bem_end_1(bevd_0);
case -1350849067: return bem_ccMethodsSet_1(bevd_0);
case 1980815313: return bem_inFilePathedSet_1(bevd_0);
case -326391637: return bem_constSet_1(bevd_0);
case -1664043865: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1666808356: return bem_lastMethodsSizeSet_1(bevd_0);
case -235995816: return bem_nameToIdPathSet_1(bevd_0);
case 195945534: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1786903547: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1727336330: return bem_nullValueSet_1(bevd_0);
case -1084461931: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1565877504: return bem_objectNpSet_1(bevd_0);
case 830993732: return bem_begin_1(bevd_0);
case 650717189: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1945143143: return bem_instanceEqualSet_1(bevd_0);
case 1337950292: return bem_idToNamePathSet_1(bevd_0);
case 1790583949: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -864835947: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 415341189: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1972573071: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1147932358: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1867445186: return bem_csynSet_1(bevd_0);
case -452238768: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 990922741: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1247942881: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1459618911: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -597184975: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 950863217: return bem_scvpSet_1(bevd_0);
case -1106067544: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1218446290: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 809288000: return bem_classEmitsSet_1(bevd_0);
case 1107597561: return bem_transSet_1(bevd_0);
case -1944321913: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1675063474: return bem_buildSet_1(bevd_0);
case 1670550876: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1764060861: return bem_mnodeSet_1(bevd_0);
case 1372702350: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1167536123: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -910596451: return bem_exceptDecSet_1(bevd_0);
case -1058639715: return bem_nativeCSlotsSet_1(bevd_0);
case 697627155: return bem_gcMarksSet_1(bevd_0);
case -282440212: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 431048155: return bem_superCallsSet_1(bevd_0);
case -682786826: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 83055169: return bem_smnlecsSet_1(bevd_0);
case -469242080: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 214788439: return bem_parentConfSet_1(bevd_0);
case 293572513: return bem_smnlcsSet_1(bevd_0);
case 1378138640: return bem_ntypesSet_1(bevd_0);
case -1298675443: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -274224230: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1207948568: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 711333747: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1915735138: return bem_libEmitPathSet_1(bevd_0);
case -1934361023: return bem_emitLangSet_1(bevd_0);
case -1341388197: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1775320153: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -469387631: return bem_ccCacheSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 426315431: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2087906856: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 8353367: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -840314986: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628920596: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -466247487: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1167164271: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2028229465: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1606608446: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 704366194: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 376456972: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 529653897: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 677704745: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -183499135: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 380768478: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1898474211: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -2112678640: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1395098844: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -778588790: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -171050141: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1669860485: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1054146823: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -2142259933: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -2136335622: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -451074960: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
