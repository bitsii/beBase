package be;
/* IO:File: source/build/JVEmitter.be */
public final class BEC_2_5_9_BuildJVEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_22, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_26, 14));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_29, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_36, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_39, 9));
public static BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public BEC_2_5_9_BuildJVEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 27 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(1268193259);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_tmpany_phold = bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_tmpany_phold = bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 37 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1186965043);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 37 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1001445809);
if (bevl_firstmnsyn.bevi_bool) /* Line: 38 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39 */
 else  /* Line: 40 */ {
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 41 */
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 43 */
 else  /* Line: 37 */ {
break;
} /* Line: 37 */
} /* Line: 37 */
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 50 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1186965043);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1001445809);
if (bevl_firstptsyn.bevi_bool) /* Line: 51 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52 */
 else  /* Line: 53 */ {
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 54 */
bevt_36_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 56 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_tmpany_phold = bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_tmpany_phold.bem_addValue_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_tmpany_phold);
bevl_tout.bemd_1(-110905017, bevl_bet);
bevl_tout.bemd_0(1157301587);
return this;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1179204360);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2042759880);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJVEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 90 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 103 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 104 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 111 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-646385374);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 81, 81, 81, 81, 86, 87, 88, 88, 89, 89, 90, 90, 92, 92, 92, 93, 99, 99, 99, 99, 99, 99, 103, 103, 103, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 0, 0, 0, 111, 111, 113, 113, 117, 117, 121, 121, 121, 121, 121, 122, 122, 122, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 125, 129, 129, 129, 133, 133, 133, 133, 133, 133, 133, 137, 137, 141, 141, 145, 145, 145, 145};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {66, 67, 68, 69, 127, 128, 129, 130, 135, 136, 137, 138, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 163, 166, 168, 170, 173, 174, 176, 177, 178, 179, 185, 186, 187, 188, 189, 190, 191, 192, 193, 193, 196, 198, 200, 203, 204, 206, 207, 208, 209, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 280, 281, 282, 283, 284, 294, 295, 296, 297, 299, 300, 301, 302, 304, 305, 306, 307, 316, 317, 318, 319, 320, 321, 329, 334, 335, 337, 340, 344, 347, 348, 350, 351, 359, 364, 365, 367, 370, 374, 377, 378, 380, 381, 385, 386, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 435, 436, 437, 446, 447, 448, 449, 450, 451, 452, 456, 457, 461, 462, 468, 469, 470, 471};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 66
new 0 16 66
assign 1 17 67
new 0 17 67
assign 1 18 68
new 0 18 68
new 1 22 69
assign 1 26 127
classDirGet 0 26 127
assign 1 26 128
fileGet 0 26 128
assign 1 26 129
existsGet 0 26 129
assign 1 26 130
not 0 26 135
assign 1 27 136
classDirGet 0 27 136
assign 1 27 137
fileGet 0 27 137
makeDirs 0 27 138
assign 1 29 140
typePathGet 0 29 140
assign 1 29 141
fileGet 0 29 141
assign 1 29 142
writerGet 0 29 142
assign 1 29 143
open 0 29 143
assign 1 30 144
new 0 30 144
assign 1 31 145
new 0 31 145
addValue 1 31 146
assign 1 32 147
new 0 32 147
assign 1 32 148
addValue 1 32 148
assign 1 32 149
typeEmitNameGet 0 32 149
assign 1 32 150
addValue 1 32 150
assign 1 32 151
new 0 32 151
addValue 1 32 152
assign 1 33 153
new 0 33 153
assign 1 33 154
addValue 1 33 154
assign 1 33 155
typeEmitNameGet 0 33 155
assign 1 33 156
addValue 1 33 156
assign 1 33 157
new 0 33 157
addValue 1 33 158
assign 1 35 159
new 0 35 159
addValue 1 35 160
assign 1 36 161
new 0 36 161
assign 1 37 162
mtdListGet 0 37 162
assign 1 37 163
iteratorGet 0 0 163
assign 1 37 166
hasNextGet 0 37 166
assign 1 37 168
nextGet 0 37 168
assign 1 39 170
new 0 39 170
assign 1 41 173
new 0 41 173
addValue 1 41 174
assign 1 43 176
addValue 1 43 176
assign 1 43 177
nameGet 0 43 177
assign 1 43 178
addValue 1 43 178
addValue 1 43 179
assign 1 45 185
new 0 45 185
addValue 1 45 186
assign 1 46 187
new 0 46 187
addValue 1 46 188
assign 1 48 189
new 0 48 189
addValue 1 48 190
assign 1 49 191
new 0 49 191
assign 1 50 192
ptyListGet 0 50 192
assign 1 50 193
iteratorGet 0 0 193
assign 1 50 196
hasNextGet 0 50 196
assign 1 50 198
nextGet 0 50 198
assign 1 52 200
new 0 52 200
assign 1 54 203
new 0 54 203
addValue 1 54 204
assign 1 56 206
addValue 1 56 206
assign 1 56 207
nameGet 0 56 207
assign 1 56 208
addValue 1 56 208
addValue 1 56 209
assign 1 58 215
new 0 58 215
addValue 1 58 216
assign 1 60 217
new 0 60 217
addValue 1 60 218
assign 1 62 219
new 0 62 219
addValue 1 62 220
assign 1 63 221
new 0 63 221
assign 1 63 222
addValue 1 63 222
assign 1 63 223
emitNameGet 0 63 223
assign 1 63 224
addValue 1 63 224
assign 1 63 225
new 0 63 225
addValue 1 63 226
assign 1 64 227
new 0 64 227
addValue 1 64 228
assign 1 65 229
new 0 65 229
addValue 1 65 230
write 1 66 231
close 0 67 232
assign 1 71 253
new 0 71 253
assign 1 71 254
toString 0 71 254
assign 1 71 255
add 1 71 255
incrementValue 0 72 256
assign 1 73 257
new 0 73 257
assign 1 73 258
addValue 1 73 258
assign 1 73 259
addValue 1 73 259
assign 1 73 260
new 0 73 260
assign 1 73 261
addValue 1 73 261
addValue 1 73 262
assign 1 75 263
containedGet 0 75 263
assign 1 75 264
firstGet 0 75 264
assign 1 75 265
containedGet 0 75 265
assign 1 75 266
firstGet 0 75 266
assign 1 75 267
new 0 75 267
assign 1 75 268
add 1 75 268
assign 1 75 269
new 0 75 269
assign 1 75 270
add 1 75 270
assign 1 75 271
finalAssign 4 75 271
addValue 1 75 272
assign 1 81 280
new 0 81 280
assign 1 81 281
add 1 81 281
assign 1 81 282
new 0 81 282
assign 1 81 283
add 1 81 283
return 1 81 284
getInt 2 86 294
assign 1 87 295
toHexString 1 87 295
assign 1 88 296
new 0 88 296
assign 1 88 297
begins 1 88 297
assign 1 89 299
new 0 89 299
assign 1 89 300
substring 1 89 300
assign 1 90 301
new 0 90 301
addValue 1 90 302
assign 1 92 304
new 0 92 304
assign 1 92 305
once 0 92 305
addValue 1 92 306
addValue 1 93 307
assign 1 99 316
new 0 99 316
assign 1 99 317
add 1 99 317
assign 1 99 318
new 0 99 318
assign 1 99 319
add 1 99 319
assign 1 99 320
add 1 99 320
return 1 99 321
assign 1 103 329
def 1 103 334
assign 1 103 335
isFinalGet 0 103 335
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 104 347
new 0 104 347
return 1 104 348
assign 1 106 350
new 0 106 350
return 1 106 351
assign 1 110 359
def 1 110 364
assign 1 110 365
isFinalGet 0 110 365
assign 1 0 367
assign 1 0 370
assign 1 0 374
assign 1 111 377
new 0 111 377
return 1 111 378
assign 1 113 380
new 0 113 380
return 1 113 381
assign 1 117 385
new 0 117 385
return 1 117 386
assign 1 121 408
new 0 121 408
assign 1 121 409
add 1 121 409
assign 1 121 410
new 0 121 410
assign 1 121 411
add 1 121 411
assign 1 121 412
add 1 121 412
assign 1 122 413
new 0 122 413
assign 1 122 414
addValue 1 122 414
assign 1 122 415
addValue 1 122 415
assign 1 122 416
new 0 122 416
assign 1 122 417
addValue 1 122 417
addValue 1 122 418
assign 1 123 419
new 0 123 419
assign 1 123 420
addValue 1 123 420
addValue 1 123 421
assign 1 124 422
new 0 124 422
assign 1 124 423
addValue 1 124 423
assign 1 124 424
outputPlatformGet 0 124 424
assign 1 124 425
nameGet 0 124 425
assign 1 124 426
addValue 1 124 426
assign 1 124 427
new 0 124 427
assign 1 124 428
addValue 1 124 428
addValue 1 124 429
return 1 125 430
assign 1 129 435
libNameGet 0 129 435
assign 1 129 436
beginNs 1 129 436
return 1 129 437
assign 1 133 446
new 0 133 446
assign 1 133 447
libNs 1 133 447
assign 1 133 448
add 1 133 448
assign 1 133 449
new 0 133 449
assign 1 133 450
add 1 133 450
assign 1 133 451
add 1 133 451
return 1 133 452
assign 1 137 456
getNameSpace 1 137 456
return 1 137 457
assign 1 141 461
new 0 141 461
return 1 141 462
assign 1 145 468
new 0 145 468
assign 1 145 469
once 0 145 469
assign 1 145 470
add 1 145 470
return 1 145 471
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 762626713: return bem_invpGet_0();
case 14602800: return bem_mnodeGet_0();
case -262466587: return bem_dynMethodsGet_0();
case -1121634438: return bem_ntypesGetDirect_0();
case 1242421487: return bem_transGet_0();
case -38042496: return bem_nameToIdGetDirect_0();
case -1507890122: return bem_libEmitPathGetDirect_0();
case 1637341564: return bem_preClassOutput_0();
case 448917349: return bem_gcMarksGetDirect_0();
case -567505377: return bem_parentConfGetDirect_0();
case 806795805: return bem_classCallsGet_0();
case 1419461318: return bem_stringNpGet_0();
case 2055550833: return bem_objectNpGetDirect_0();
case -2014841986: return bem_ccCacheGet_0();
case -1432222666: return bem_classCallsGetDirect_0();
case -8059182: return bem_maxSpillArgsLenGetDirect_0();
case 129806181: return bem_superNameGet_0();
case 610287972: return bem_superCallsGetDirect_0();
case 2024262513: return bem_callNamesGet_0();
case -1044078638: return bem_trueValueGet_0();
case 195815026: return bem_randGet_0();
case -545885409: return bem_fieldNamesGet_0();
case -437401677: return bem_propDecGet_0();
case 823986744: return bem_inClassGet_0();
case 930506719: return bem_intNpGetDirect_0();
case 678571136: return bem_many_0();
case -221579259: return bem_maxDynArgsGet_0();
case -212638835: return bem_lastCallGetDirect_0();
case 750032035: return bem_lineCountGetDirect_0();
case 1457416126: return bem_saveIds_0();
case 322973431: return bem_print_0();
case 911647168: return bem_callNamesGetDirect_0();
case -1815398055: return bem_methodsGetDirect_0();
case 831531339: return bem_gcMarksGet_0();
case 2122497827: return bem_methodCallsGet_0();
case -163770727: return bem_lastCallGet_0();
case -1184638374: return bem_belslitsGetDirect_0();
case -527327101: return bem_floatNpGetDirect_0();
case -675424880: return bem_exceptDecGet_0();
case 1751425308: return bem_csynGet_0();
case 597357534: return bem_tagGet_0();
case 873874683: return bem_methodCatchGet_0();
case -1658567016: return bem_instanceEqualGet_0();
case 206920291: return bem_ccMethodsGet_0();
case 2035323909: return bem_classEndGet_0();
case -2097301657: return bem_boolCcGet_0();
case 1215450195: return bem_lineCountGet_0();
case -1110799888: return bem_lastMethodBodySizeGetDirect_0();
case 550989691: return bem_mainEndGet_0();
case -660176157: return bem_useDynMethodsGet_0();
case 1264233769: return bem_inFilePathedGet_0();
case -1668138220: return bem_doEmit_0();
case -978042141: return bem_idToNameGetDirect_0();
case 479265473: return bem_nlGet_0();
case 1361267546: return bem_libEmitNameGet_0();
case 1244351569: return bem_smnlcsGet_0();
case 814905688: return bem_ccMethodsGetDirect_0();
case -879214192: return bem_buildGet_0();
case -84373690: return bem_spropDecGet_0();
case -217002931: return bem_returnTypeGetDirect_0();
case 1289072735: return bem_onceDecsGet_0();
case -206365449: return bem_instanceNotEqualGet_0();
case -227311207: return bem_baseMtdDecGet_0();
case -354958887: return bem_nativeCSlotsGet_0();
case -84408331: return bem_scvpGetDirect_0();
case -1179064487: return bem_superCallsGet_0();
case -608212052: return bem_onceCountGetDirect_0();
case -1133232925: return bem_cnodeGetDirect_0();
case 1036851739: return bem_emitLib_0();
case 1304271591: return bem_afterCast_0();
case 305055544: return bem_transGetDirect_0();
case 625547167: return bem_toString_0();
case 291309239: return bem_once_0();
case 2123765846: return bem_nameToIdPathGetDirect_0();
case -702127640: return bem_beginNs_0();
case 305613993: return bem_sourceFileNameGet_0();
case -1607299603: return bem_synEmitPathGet_0();
case -1101326644: return bem_serializeContents_0();
case 1461724031: return bem_copy_0();
case 293241724: return bem_objectCcGet_0();
case -1374957753: return bem_scvpGet_0();
case -1517405787: return bem_saveSyns_0();
case 1313450605: return bem_objectCcGetDirect_0();
case 2127564854: return bem_classConfGetDirect_0();
case 47649203: return bem_smnlecsGetDirect_0();
case -1732500583: return bem_lastMethodsLinesGetDirect_0();
case -2051803278: return bem_exceptDecGetDirect_0();
case 364235321: return bem_echo_0();
case -304415890: return bem_classNameGet_0();
case -680811989: return bem_libEmitNameGetDirect_0();
case -711168741: return bem_instOfGetDirect_0();
case -1569222986: return bem_fieldIteratorGet_0();
case 999477961: return bem_lastMethodBodySizeGet_0();
case -1132703219: return bem_nullValueGetDirect_0();
case -431916258: return bem_buildClassInfo_0();
case -46451121: return bem_synEmitPathGetDirect_0();
case 651763520: return bem_constGet_0();
case 2050059376: return bem_iteratorGet_0();
case -1380385181: return bem_smnlcsGetDirect_0();
case -2112551590: return bem_objectNpGet_0();
case -1394056248: return bem_idToNamePathGet_0();
case 1954751090: return bem_emitLangGet_0();
case 27434785: return bem_newDecGet_0();
case 1289647520: return bem_invpGetDirect_0();
case -1330083450: return bem_classEmitsGet_0();
case 694213554: return bem_boolCcGetDirect_0();
case 148155993: return bem_idToNamePathGetDirect_0();
case -547872543: return bem_runtimeInitGet_0();
case 1424086851: return bem_qGetDirect_0();
case 1248512101: return bem_fullLibEmitNameGet_0();
case 1913022823: return bem_baseSmtdDecGet_0();
case 659697241: return bem_buildCreate_0();
case 690399070: return bem_nativeCSlotsGetDirect_0();
case -1185270250: return bem_ntypesGet_0();
case -1087766017: return bem_serializeToString_0();
case -875742486: return bem_libEmitPathGet_0();
case 2099470513: return bem_endNs_0();
case -788571552: return bem_fullLibEmitNameGetDirect_0();
case -1128980013: return bem_lastMethodBodyLinesGetDirect_0();
case -554112237: return bem_classesInDepthOrderGet_0();
case 224727242: return bem_classEmitsGetDirect_0();
case 863097359: return bem_belslitsGet_0();
case 946237293: return bem_onceDecsGetDirect_0();
case 1928435140: return bem_fileExtGetDirect_0();
case -1892328282: return bem_nullValueGet_0();
case 576955950: return bem_methodCallsGetDirect_0();
case 1558495022: return bem_mainInClassGet_0();
case -713475106: return bem_smnlecsGet_0();
case 657156563: return bem_boolTypeGet_0();
case 1333606718: return bem_floatNpGet_0();
case -43502949: return bem_toAny_0();
case -558990509: return bem_idToNameGet_0();
case 1746075234: return bem_lastMethodBodyLinesGet_0();
case 1851036145: return bem_serializationIteratorGet_0();
case -2118452853: return bem_overrideMtdDecGet_0();
case -608595936: return bem_methodBodyGet_0();
case 421480163: return bem_falseValueGetDirect_0();
case -1696513818: return bem_emitLangGetDirect_0();
case 818812593: return bem_mnodeGetDirect_0();
case 80136932: return bem_getLibOutput_0();
case -381740729: return bem_deserializeClassNameGet_0();
case -362887363: return bem_lastMethodsSizeGetDirect_0();
case -208970472: return bem_msynGetDirect_0();
case -1266550419: return bem_boolNpGet_0();
case -777338417: return bem_classConfGet_0();
case 75735828: return bem_preClassGetDirect_0();
case 1230035770: return bem_onceCountGet_0();
case 1807883746: return bem_falseValueGet_0();
case -753644705: return bem_hashGet_0();
case -410783155: return bem_new_0();
case -958155152: return bem_buildInitial_0();
case -909675958: return bem_create_0();
case -1250843579: return bem_maxDynArgsGetDirect_0();
case -289522478: return bem_typeDecGet_0();
case -578139033: return bem_csynGetDirect_0();
case 2089454684: return bem_methodsGet_0();
case -418503404: return bem_methodBodyGetDirect_0();
case 1097858408: return bem_parentConfGet_0();
case 1030943064: return bem_dynMethodsGetDirect_0();
case 1939512414: return bem_stringNpGetDirect_0();
case 921988836: return bem_ccCacheGetDirect_0();
case -424645755: return bem_initialDecGet_0();
case -1887595123: return bem_instOfGet_0();
case -1069496905: return bem_fileExtGet_0();
case 63627328: return bem_writeBET_0();
case 503585316: return bem_methodCatchGetDirect_0();
case -1629859308: return bem_nlGetDirect_0();
case -410087062: return bem_maxSpillArgsLenGet_0();
case 1172767050: return bem_inFilePathedGetDirect_0();
case -953547237: return bem_msynGet_0();
case -1897442334: return bem_getClassOutput_0();
case -788901832: return bem_intNpGet_0();
case -1699547846: return bem_preClassGet_0();
case -1632710927: return bem_constGetDirect_0();
case 261986256: return bem_classesInDepthOrderGetDirect_0();
case 982109726: return bem_cnodeGet_0();
case 2144192580: return bem_lastMethodsSizeGet_0();
case -301672494: return bem_loadIds_0();
case -774374478: return bem_trueValueGetDirect_0();
case -446495243: return bem_returnTypeGet_0();
case -1351830312: return bem_mainOutsideNsGet_0();
case 202367645: return bem_covariantReturnsGet_0();
case 1479584649: return bem_qGet_0();
case -492097839: return bem_boolNpGetDirect_0();
case 1440701563: return bem_nameToIdGet_0();
case -1978659420: return bem_lastMethodsLinesGet_0();
case 1226275067: return bem_randGetDirect_0();
case 726058466: return bem_propertyDecsGet_0();
case -1531417353: return bem_buildGetDirect_0();
case -1928000045: return bem_mainStartGet_0();
case 275431583: return bem_inClassGetDirect_0();
case -1952274159: return bem_instanceNotEqualGetDirect_0();
case -1742433967: return bem_propertyDecsGetDirect_0();
case 482602273: return bem_nameToIdPathGet_0();
case -1163186971: return bem_instanceEqualGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1903861648: return bem_end_1(bevd_0);
case -1575029220: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case 1440361342: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -169577234: return bem_onceCountSetDirect_1(bevd_0);
case 1165845717: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1874715471: return bem_idToNameSet_1(bevd_0);
case 581347956: return bem_trueValueSetDirect_1(bevd_0);
case 235803718: return bem_lastMethodsLinesSet_1(bevd_0);
case 1166889563: return bem_objectNpSet_1(bevd_0);
case 1843718682: return bem_csynSet_1(bevd_0);
case -1399216026: return bem_inClassSetDirect_1(bevd_0);
case -1382254537: return bem_nameToIdSetDirect_1(bevd_0);
case -1226936976: return bem_intNpSetDirect_1(bevd_0);
case 529739919: return bem_classEmitsSet_1(bevd_0);
case -103953232: return bem_nlSet_1(bevd_0);
case -1599361109: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1306103741: return bem_qSetDirect_1(bevd_0);
case -1460435431: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -326630716: return bem_instanceNotEqualSet_1(bevd_0);
case -1905892341: return bem_gcMarksSetDirect_1(bevd_0);
case -78565799: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1969967243: return bem_onceDecsSetDirect_1(bevd_0);
case 1868902305: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1881830012: return bem_randSetDirect_1(bevd_0);
case -1950611063: return bem_libEmitPathSet_1(bevd_0);
case -1549872908: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1044240808: return bem_msynSetDirect_1(bevd_0);
case 1858478424: return bem_cnodeSet_1(bevd_0);
case -428541332: return bem_mnodeSet_1(bevd_0);
case 1700183538: return bem_boolCcSetDirect_1(bevd_0);
case -1949529196: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case -1673361452: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1378106358: return bem_idToNameSetDirect_1(bevd_0);
case 2005991010: return bem_nameToIdPathSetDirect_1(bevd_0);
case 161267542: return bem_falseValueSetDirect_1(bevd_0);
case -24000032: return bem_superCallsSet_1(bevd_0);
case -1948338449: return bem_objectNpSetDirect_1(bevd_0);
case 566551847: return bem_ntypesSetDirect_1(bevd_0);
case -1363674143: return bem_callNamesSetDirect_1(bevd_0);
case -964395879: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1353038815: return bem_lineCountSetDirect_1(bevd_0);
case -1784357711: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1569056908: return bem_libEmitNameSet_1(bevd_0);
case -1498809597: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -815020427: return bem_fileExtSetDirect_1(bevd_0);
case -462407267: return bem_returnTypeSetDirect_1(bevd_0);
case -52916209: return bem_dynMethodsSetDirect_1(bevd_0);
case -2048763380: return bem_methodCatchSet_1(bevd_0);
case -2062811605: return bem_synEmitPathSetDirect_1(bevd_0);
case 1015127138: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1125130757: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -979238469: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1708841113: return bem_propertyDecsSetDirect_1(bevd_0);
case -1447137700: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -711407389: return bem_qSet_1(bevd_0);
case 1084452576: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 666560783: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2096805338: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 953223163: return bem_exceptDecSet_1(bevd_0);
case 218786300: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -212248841: return bem_floatNpSet_1(bevd_0);
case 1717523708: return bem_lastMethodsSizeSet_1(bevd_0);
case 2001016535: return bem_instOfSetDirect_1(bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case -409000329: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -135745925: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -425878728: return bem_methodCallsSet_1(bevd_0);
case 1401759978: return bem_classesInDepthOrderSet_1(bevd_0);
case -685949400: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1036865828: return bem_begin_1(bevd_0);
case 752790340: return bem_callNamesSet_1(bevd_0);
case -818664461: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 990456960: return bem_nlSetDirect_1(bevd_0);
case 309690044: return bem_objectCcSetDirect_1(bevd_0);
case 1084164925: return bem_classCallsSetDirect_1(bevd_0);
case -108975222: return bem_classConfSet_1(bevd_0);
case -1505757698: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1271753676: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1198689059: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 991180658: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1246878088: return bem_lastCallSet_1(bevd_0);
case 325838560: return bem_parentConfSet_1(bevd_0);
case 948402281: return bem_idToNamePathSetDirect_1(bevd_0);
case -870618679: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -251141237: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1678984653: return bem_cnodeSetDirect_1(bevd_0);
case -222756812: return bem_buildSet_1(bevd_0);
case -1298409589: return bem_methodCatchSetDirect_1(bevd_0);
case 371594577: return bem_instOfSet_1(bevd_0);
case -1488982130: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 839224925: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1163031054: return bem_fileExtSet_1(bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case 891800065: return bem_inFilePathedSet_1(bevd_0);
case 1923163290: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1465335989: return bem_ccMethodsSet_1(bevd_0);
case -889988035: return bem_randSet_1(bevd_0);
case 754410914: return bem_invpSet_1(bevd_0);
case -406683211: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1959449175: return bem_nameToIdSet_1(bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case -209694974: return bem_nullValueSetDirect_1(bevd_0);
case 2100814653: return bem_returnTypeSet_1(bevd_0);
case -1874641507: return bem_fullLibEmitNameSet_1(bevd_0);
case -150749031: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1400134428: return bem_onceDecsSet_1(bevd_0);
case -2121016239: return bem_instanceEqualSetDirect_1(bevd_0);
case 377575387: return bem_methodCallsSetDirect_1(bevd_0);
case -771020557: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 826598614: return bem_intNpSet_1(bevd_0);
case -1066429415: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1418773706: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -495435553: return bem_maxDynArgsSet_1(bevd_0);
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -223372163: return bem_mnodeSetDirect_1(bevd_0);
case -881306106: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case 512973634: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 2025663187: return bem_smnlecsSetDirect_1(bevd_0);
case 102483748: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1291079091: return bem_transSet_1(bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -211309279: return bem_boolCcSet_1(bevd_0);
case -1472629847: return bem_exceptDecSetDirect_1(bevd_0);
case 169644960: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -399634322: return bem_gcMarksSet_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 315351660: return bem_falseValueSet_1(bevd_0);
case -1200425549: return bem_smnlcsSet_1(bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case 88160424: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1910166120: return bem_methodsSet_1(bevd_0);
case 1299223921: return bem_scvpSetDirect_1(bevd_0);
case -23599074: return bem_ccCacheSetDirect_1(bevd_0);
case 1537089005: return bem_transSetDirect_1(bevd_0);
case 1062735581: return bem_ccMethodsSetDirect_1(bevd_0);
case -1434788306: return bem_lastCallSetDirect_1(bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1582044533: return bem_propertyDecsSet_1(bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 1349987040: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 181926170: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1379889168: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
case -422288586: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1632647693: return bem_nameToIdPathSet_1(bevd_0);
case 1750264409: return bem_emitLangSet_1(bevd_0);
case 843407546: return bem_libEmitPathSetDirect_1(bevd_0);
case -1145033675: return bem_libEmitNameSetDirect_1(bevd_0);
case -550335873: return bem_msynSet_1(bevd_0);
case -1778034347: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 793720407: return bem_trueValueSet_1(bevd_0);
case 1265455061: return bem_stringNpSet_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
case -1756187396: return bem_nativeCSlotsSet_1(bevd_0);
case -186793001: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1815165563: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1763384617: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1581065607: return bem_classCallsSet_1(bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case 2016296839: return bem_preClassSet_1(bevd_0);
case 49935555: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -623804442: return bem_smnlecsSet_1(bevd_0);
case -2121600626: return bem_floatNpSetDirect_1(bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case 867701191: return bem_classConfSetDirect_1(bevd_0);
case 523322270: return bem_instanceEqualSet_1(bevd_0);
case -1330439639: return bem_ntypesSet_1(bevd_0);
case -1480474741: return bem_boolNpSet_1(bevd_0);
case 1015687400: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -46919953: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 9635322: return bem_classEmitsSetDirect_1(bevd_0);
case -943801044: return bem_ccCacheSet_1(bevd_0);
case 1090583467: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1932353909: return bem_boolNpSetDirect_1(bevd_0);
case -736100649: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1436588860: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 2097295227: return bem_belslitsSetDirect_1(bevd_0);
case 2094093742: return bem_buildSetDirect_1(bevd_0);
case 1607228846: return bem_lineCountSet_1(bevd_0);
case -1450630675: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -2115306909: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -385414837: return bem_constSetDirect_1(bevd_0);
case -841506934: return bem_nullValueSet_1(bevd_0);
case 1540881190: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -275488367: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1664689681: return bem_methodBodySet_1(bevd_0);
case 878439737: return bem_belslitsSet_1(bevd_0);
case 823457196: return bem_onceCountSet_1(bevd_0);
case -1177780015: return bem_idToNamePathSet_1(bevd_0);
case -2141809329: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -2143787858: return bem_dynMethodsSet_1(bevd_0);
case 1954329525: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 813961691: return bem_inFilePathedSetDirect_1(bevd_0);
case -472252792: return bem_emitLangSetDirect_1(bevd_0);
case 2092589580: return bem_preClassSetDirect_1(bevd_0);
case 1045353352: return bem_methodsSetDirect_1(bevd_0);
case -1912530863: return bem_invpSetDirect_1(bevd_0);
case 31752148: return bem_methodBodySetDirect_1(bevd_0);
case 518789942: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1164282839: return bem_parentConfSetDirect_1(bevd_0);
case -615513724: return bem_stringNpSetDirect_1(bevd_0);
case -625771343: return bem_objectCcSet_1(bevd_0);
case 323536948: return bem_synEmitPathSet_1(bevd_0);
case 1266276289: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1601761478: return bem_scvpSet_1(bevd_0);
case -1457015264: return bem_inClassSet_1(bevd_0);
case 1217703152: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -343661645: return bem_constSet_1(bevd_0);
case -1829080852: return bem_smnlcsSetDirect_1(bevd_0);
case 1246036485: return bem_superCallsSetDirect_1(bevd_0);
case -1492692874: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1187103319: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 2116863753: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1135520778: return bem_csynSetDirect_1(bevd_0);
case -95039700: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1891309098: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1976371203: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1281463701: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1539213350: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 558744534: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1147487217: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 93069808: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1854936021: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 283870926: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1334733540: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1484655687: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1627080451: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -667240565: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1301640344: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 849847690: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 807859906: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -462467849: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1209717190: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1151052651: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 135014852: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 174366705: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJVEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
