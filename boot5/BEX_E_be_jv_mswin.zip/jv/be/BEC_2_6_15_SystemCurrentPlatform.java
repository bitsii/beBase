package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
/* Line: 244*/ {
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 245*/ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                /* Line: 260*/ {
} /* Line: 261*/
/* Line: 268*/ {
} /* Line: 269*/
bem_setName_1(bevl_platformName);
} /* Line: 275*/
} /* Line: 245*/
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-1365129240, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {245, 245, 275, 281, 282, 286, 287, 288};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 32, 38, 39, 44, 45, 46};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 245 20
undef 1 245 25
setName 1 275 32
assign 1 281 38
buildProfile 0 282 39
buildProfile 0 286 44
assign 1 287 45
new 0 287 45
newlineSet 1 288 46
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1140404476: return bem_iteratorGet_0();
case 43620936: return bem_separatorGet_0();
case 1912951938: return bem_nameGet_0();
case -1587764300: return bem_otherSeparatorGet_0();
case -1382010098: return bem_buildProfile_0();
case 416881831: return bem_copy_0();
case -82017130: return bem_toString_0();
case -1621049568: return bem_properNameGet_0();
case -1937935225: return bem_newlineGet_0();
case 153130764: return bem_print_0();
case 324521155: return bem_create_0();
case -142232081: return bem_default_0();
case -177283836: return bem_isWinGet_0();
case -187492472: return bem_new_0();
case -374980925: return bem_nullFileGet_0();
case -932476700: return bem_scriptExtGet_0();
case -159849764: return bem_hashGet_0();
case -991376261: return bem_isNixGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1365129240: return bem_newlineSet_1(bevd_0);
case 1267419746: return bem_def_1(bevd_0);
case -850371892: return bem_notEquals_1(bevd_0);
case 1336352814: return bem_copyTo_1(bevd_0);
case 1060519159: return bem_separatorSet_1(bevd_0);
case 1035482217: return bem_nameSet_1(bevd_0);
case 2134226772: return bem_nullFileSet_1(bevd_0);
case -2003493421: return bem_isNixSet_1(bevd_0);
case 1503120614: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -215851094: return bem_scriptExtSet_1(bevd_0);
case 104436736: return bem_isWinSet_1(bevd_0);
case -393105689: return bem_undef_1(bevd_0);
case 320571403: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -559238061: return bem_equals_1(bevd_0);
case 212159302: return bem_properNameSet_1(bevd_0);
case 1649573447: return bem_otherSeparatorSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2109827654: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1822328732: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 347449110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -911952501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
