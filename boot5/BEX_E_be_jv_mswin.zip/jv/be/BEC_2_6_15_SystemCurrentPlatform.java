package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 566 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 567 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 590 */
} /* Line: 567 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-1788338628, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {567, 567, 590, 596, 597, 601, 602, 603};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 28, 34, 35, 40, 41, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 567 20
undef 1 567 25
setName 1 590 28
assign 1 596 34
buildProfile 0 597 35
buildProfile 0 601 40
assign 1 602 41
new 0 602 41
newlineSet 1 603 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 52211570: return bem_isWinGet_0();
case -1439777293: return bem_hashGet_0();
case -1476019175: return bem_toString_0();
case 1935136194: return bem_classNameGet_0();
case 2079366792: return bem_otherSeparatorGet_0();
case 109404831: return bem_isNixGet_0();
case 742371580: return bem_serializeToString_0();
case -1321403182: return bem_nameGetDirect_0();
case -171787177: return bem_isNixGetDirect_0();
case 1516161879: return bem_fieldNamesGet_0();
case 2022988218: return bem_default_0();
case -433517544: return bem_otherSeparatorGetDirect_0();
case -1750213491: return bem_sourceFileNameGet_0();
case -197579463: return bem_separatorGet_0();
case -2070113098: return bem_create_0();
case -1572746806: return bem_newlineGetDirect_0();
case 1908249207: return bem_newlineGet_0();
case -61288189: return bem_serializationIteratorGet_0();
case 1660533487: return bem_serializeContents_0();
case -1450997322: return bem_nullFileGetDirect_0();
case -2017306021: return bem_isWinGetDirect_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case 2031369362: return bem_nameGet_0();
case 263599231: return bem_buildProfile_0();
case 1730802409: return bem_echo_0();
case 1326542704: return bem_tagGet_0();
case -948982310: return bem_many_0();
case -890668867: return bem_separatorGetDirect_0();
case 1070146794: return bem_toAny_0();
case 450230894: return bem_print_0();
case 623957818: return bem_once_0();
case 1718046883: return bem_nullFileGet_0();
case -2073027086: return bem_fieldIteratorGet_0();
case -897350462: return bem_iteratorGet_0();
case 1172450247: return bem_copy_0();
case -1556712456: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 688446934: return bem_isNixSet_1(bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -619190203: return bem_isWinSetDirect_1(bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case 105834790: return bem_separatorSetDirect_1(bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case 1720822531: return bem_nullFileSet_1(bevd_0);
case 1887602006: return bem_nameSet_1(bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case 1904165829: return bem_otherSeparatorSetDirect_1(bevd_0);
case 2098375547: return bem_isWinSet_1(bevd_0);
case -1879124992: return bem_newlineSetDirect_1(bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case -547391241: return bem_separatorSet_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1788338628: return bem_newlineSet_1(bevd_0);
case -606689094: return bem_otherSeparatorSet_1(bevd_0);
case 1572181989: return bem_nullFileSetDirect_1(bevd_0);
case 229070821: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case 432481086: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
case -1582890711: return bem_nameSetDirect_1(bevd_0);
case -1787539955: return bem_isNixSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
