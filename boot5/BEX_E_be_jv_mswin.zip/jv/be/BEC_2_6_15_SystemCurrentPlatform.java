package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 251*/ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                bem_setName_1(bevl_platformName);
} /* Line: 281*/
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-439169802, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {251, 251, 281, 287, 288, 292, 293, 294};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 24, 27, 32, 33, 38, 39, 40};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 251 19
undef 1 251 24
setName 1 281 27
assign 1 287 32
buildProfile 0 288 33
buildProfile 0 292 38
assign 1 293 39
new 0 293 39
newlineSet 1 294 40
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1879447022: return bem_otherSeparatorGet_0();
case -404357583: return bem_isWinGet_0();
case -1225636174: return bem_toString_0();
case 1184150729: return bem_buildProfile_0();
case 873604125: return bem_isNixGet_0();
case 1045256597: return bem_new_0();
case 1661802748: return bem_print_0();
case 1375409336: return bem_copy_0();
case -991684844: return bem_nameGet_0();
case -355124364: return bem_create_0();
case -1643601283: return bem_nullFileGet_0();
case 1389378690: return bem_iteratorGet_0();
case -1968106897: return bem_newlineGet_0();
case -308470073: return bem_hashGet_0();
case 1796938648: return bem_scriptExtGet_0();
case 179089726: return bem_default_0();
case 1258543328: return bem_properNameGet_0();
case 677480758: return bem_separatorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -439169802: return bem_newlineSet_1(bevd_0);
case 1410683219: return bem_notEquals_1(bevd_0);
case 1024858296: return bem_copyTo_1(bevd_0);
case -997552449: return bem_isWinSet_1(bevd_0);
case -1229040663: return bem_isNixSet_1(bevd_0);
case -1383875759: return bem_otherSeparatorSet_1(bevd_0);
case 207992556: return bem_def_1(bevd_0);
case -297485597: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -2119998280: return bem_undef_1(bevd_0);
case -957169877: return bem_separatorSet_1(bevd_0);
case 1382111438: return bem_properNameSet_1(bevd_0);
case -1047190094: return bem_scriptExtSet_1(bevd_0);
case 789789310: return bem_print_1(bevd_0);
case 145823261: return bem_equals_1(bevd_0);
case -297051389: return bem_nullFileSet_1(bevd_0);
case -139460451: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 1627344108: return bem_nameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1648212160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 195884639: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1847574000: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 369351178: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
