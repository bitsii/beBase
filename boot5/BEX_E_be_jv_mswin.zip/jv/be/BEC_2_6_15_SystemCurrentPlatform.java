package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public final class BEC_2_6_15_SystemCurrentPlatform extends BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public BEC_2_6_15_SystemCurrentPlatform bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
/* Line: 267*/ {
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 268*/ {

                    bevl_platformName = new BEC_2_4_6_TextString(be.BECS_Runtime.platformName.getBytes("UTF-8"));
                /* Line: 283*/ {
} /* Line: 284*/
/* Line: 291*/ {
} /* Line: 292*/
bem_setName_1(bevl_platformName);
} /* Line: 298*/
} /* Line: 268*/
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
super.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(1171451924, bevp_newline);
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {268, 268, 298, 304, 305, 309, 310, 311};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 25, 32, 38, 39, 44, 45, 46};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 268 20
undef 1 268 25
setName 1 298 32
assign 1 304 38
buildProfile 0 305 39
buildProfile 0 309 44
assign 1 310 45
new 0 310 45
newlineSet 1 311 46
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -470548064: return bem_newlineGet_0();
case 2137583163: return bem_nullFileGetDirect_0();
case 487655943: return bem_hashGet_0();
case -1873500089: return bem_isNixGetDirect_0();
case -737828887: return bem_serializeContents_0();
case 1177953347: return bem_fieldNamesGet_0();
case -1318471451: return bem_toString_0();
case 1514228896: return bem_scriptExtGetDirect_0();
case 1747379006: return bem_otherSeparatorGet_0();
case -90905921: return bem_buildProfile_0();
case -818024146: return bem_nullFileGet_0();
case 865076857: return bem_default_0();
case 958645294: return bem_separatorGetDirect_0();
case 1620426785: return bem_fieldIteratorGet_0();
case -522449283: return bem_newlineGetDirect_0();
case -1243764713: return bem_sourceFileNameGet_0();
case 440169444: return bem_tagGet_0();
case 1998804429: return bem_deserializeClassNameGet_0();
case -66115583: return bem_properNameGetDirect_0();
case -2046304502: return bem_create_0();
case 1483871301: return bem_print_0();
case -1739983802: return bem_properNameGet_0();
case 448996129: return bem_classNameGet_0();
case -1633309881: return bem_echo_0();
case -2143605305: return bem_otherSeparatorGetDirect_0();
case -880488938: return bem_isWinGet_0();
case -144308937: return bem_nameGetDirect_0();
case -386652955: return bem_isWinGetDirect_0();
case -1624889671: return bem_copy_0();
case -1564435804: return bem_new_0();
case -1133447824: return bem_scriptExtGet_0();
case -1142809906: return bem_serializationIteratorGet_0();
case 1581478205: return bem_iteratorGet_0();
case 580136199: return bem_isNixGet_0();
case 1324610459: return bem_separatorGet_0();
case -1734684362: return bem_nameGet_0();
case -2033056683: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1724702365: return bem_copyTo_1(bevd_0);
case 1171451924: return bem_newlineSet_1(bevd_0);
case -558277008: return bem_newlineSetDirect_1(bevd_0);
case -1504383108: return bem_separatorSetDirect_1(bevd_0);
case -1900502363: return bem_def_1(bevd_0);
case -1767763000: return bem_sameObject_1(bevd_0);
case -1217337757: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2131363266: return bem_otherSeparatorSet_1(bevd_0);
case 1871732549: return bem_isWinSet_1(bevd_0);
case 93881481: return bem_nullFileSet_1(bevd_0);
case 670662888: return bem_nullFileSetDirect_1(bevd_0);
case -1817347057: return bem_otherSeparatorSetDirect_1(bevd_0);
case 965946056: return bem_sameClass_1(bevd_0);
case 390343929: return bem_nameSetDirect_1(bevd_0);
case 1520865320: return bem_scriptExtSet_1(bevd_0);
case -508263971: return bem_isWinSetDirect_1(bevd_0);
case -48526213: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1788892658: return bem_separatorSet_1(bevd_0);
case 1655576193: return bem_undef_1(bevd_0);
case -1838277299: return bem_isNixSet_1(bevd_0);
case -1801363800: return bem_sameType_1(bevd_0);
case 726063322: return bem_nameSet_1(bevd_0);
case -1274573794: return bem_scriptExtSetDirect_1(bevd_0);
case -2082849717: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1207624041: return bem_properNameSetDirect_1(bevd_0);
case -40889849: return bem_equals_1(bevd_0);
case 887328988: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -776802815: return bem_notEquals_1(bevd_0);
case -630892243: return bem_isNixSetDirect_1(bevd_0);
case -1601506198: return bem_otherClass_1(bevd_0);
case -833168395: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 1276126874: return bem_otherType_1(bevd_0);
case 476310273: return bem_properNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -180551001: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -984805442: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 162928067: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -336527550: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1644303351: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
