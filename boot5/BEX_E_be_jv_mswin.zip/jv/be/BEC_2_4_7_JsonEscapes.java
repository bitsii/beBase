package be;
/* IO:File: source/extended/Json.be */
public final class BEC_2_4_7_JsonEscapes extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_JsonEscapes() { }
private static byte[] becc_BEC_2_4_7_JsonEscapes_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x45,0x73,0x63,0x61,0x70,0x65,0x73};
private static byte[] becc_BEC_2_4_7_JsonEscapes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_0 = {0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_1 = {0x5C,0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_2 = {0x08};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_3 = {0x5C,0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_4 = {0x0C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_5 = {0x5C,0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_6 = {0x0A};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_7 = {0x5C,0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_8 = {0x0D};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_9 = {0x5C,0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_10 = {0x09};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_11 = {0x5C,0x74};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_12 = {0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_13 = {0x5C,0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_14 = {0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_15 = {0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_16 = {0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_17 = {0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_18 = {0x74};
public static BEC_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_inst;

public static BET_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_type;

public BEC_2_9_3_ContainerMap bevp_toEscapes;
public BEC_2_9_3_ContainerMap bevp_fromEscapes;
public BEC_2_4_7_JsonEscapes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_7_TextStrings bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_7_TextStrings bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_7_TextStrings bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_7_TextStrings bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
bevp_toEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_fromEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_1));
bevp_toEscapes.bem_put_2(bevt_0_ta_ph, bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_7_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_ta_ph = bevt_7_ta_ph.bem_quoteGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_11_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_10_ta_ph = bevt_11_ta_ph.bem_quoteGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
bevp_toEscapes.bem_put_2(bevt_4_ta_ph, bevt_8_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_3));
bevp_toEscapes.bem_put_2(bevt_12_ta_ph, bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_5));
bevp_toEscapes.bem_put_2(bevt_16_ta_ph, bevt_19_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_22_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_7));
bevp_toEscapes.bem_put_2(bevt_20_ta_ph, bevt_23_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_9));
bevp_toEscapes.bem_put_2(bevt_24_ta_ph, bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevt_28_ta_ph = bevt_29_ta_ph.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_11));
bevp_toEscapes.bem_put_2(bevt_28_ta_ph, bevt_31_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_34_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevt_34_ta_ph);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_13));
bevp_toEscapes.bem_put_2(bevt_32_ta_ph, bevt_35_ta_ph);
bevt_36_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_37_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevp_fromEscapes.bem_put_2(bevt_36_ta_ph, bevt_37_ta_ph);
bevt_39_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_38_ta_ph = bevt_39_ta_ph.bem_quoteGet_0();
bevt_41_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_40_ta_ph = bevt_41_ta_ph.bem_quoteGet_0();
bevp_fromEscapes.bem_put_2(bevt_38_ta_ph, bevt_40_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_14));
bevt_43_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevp_fromEscapes.bem_put_2(bevt_42_ta_ph, bevt_43_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_15));
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevp_fromEscapes.bem_put_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_16));
bevt_47_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevp_fromEscapes.bem_put_2(bevt_46_ta_ph, bevt_47_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_17));
bevt_49_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevp_fromEscapes.bem_put_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_50_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_18));
bevt_51_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevp_fromEscapes.bem_put_2(bevt_50_ta_ph, bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_53_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevp_fromEscapes.bem_put_2(bevt_52_ta_ph, bevt_53_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGet_0() throws Throwable {
return bevp_toEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGet_0() throws Throwable {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {268, 269, 271, 271, 271, 271, 271, 272, 272, 272, 272, 272, 272, 272, 272, 272, 273, 273, 273, 273, 273, 274, 274, 274, 274, 274, 275, 275, 275, 275, 275, 276, 276, 276, 276, 276, 277, 277, 277, 277, 277, 278, 278, 278, 278, 278, 280, 280, 280, 281, 281, 281, 281, 281, 282, 282, 282, 283, 283, 283, 284, 284, 284, 285, 285, 285, 286, 286, 286, 287, 287, 287, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 165, 168, 172, 175};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 268 90
new 0 268 90
assign 1 269 91
new 0 269 91
assign 1 271 92
new 0 271 92
assign 1 271 93
new 0 271 93
assign 1 271 94
addValue 1 271 94
assign 1 271 95
new 0 271 95
put 2 271 96
assign 1 272 97
new 0 272 97
assign 1 272 98
new 0 272 98
assign 1 272 99
quoteGet 0 272 99
assign 1 272 100
addValue 1 272 100
assign 1 272 101
new 0 272 101
assign 1 272 102
new 0 272 102
assign 1 272 103
quoteGet 0 272 103
assign 1 272 104
add 1 272 104
put 2 272 105
assign 1 273 106
new 0 273 106
assign 1 273 107
new 0 273 107
assign 1 273 108
addValue 1 273 108
assign 1 273 109
new 0 273 109
put 2 273 110
assign 1 274 111
new 0 274 111
assign 1 274 112
new 0 274 112
assign 1 274 113
addValue 1 274 113
assign 1 274 114
new 0 274 114
put 2 274 115
assign 1 275 116
new 0 275 116
assign 1 275 117
new 0 275 117
assign 1 275 118
addValue 1 275 118
assign 1 275 119
new 0 275 119
put 2 275 120
assign 1 276 121
new 0 276 121
assign 1 276 122
new 0 276 122
assign 1 276 123
addValue 1 276 123
assign 1 276 124
new 0 276 124
put 2 276 125
assign 1 277 126
new 0 277 126
assign 1 277 127
new 0 277 127
assign 1 277 128
addValue 1 277 128
assign 1 277 129
new 0 277 129
put 2 277 130
assign 1 278 131
new 0 278 131
assign 1 278 132
new 0 278 132
assign 1 278 133
addValue 1 278 133
assign 1 278 134
new 0 278 134
put 2 278 135
assign 1 280 136
new 0 280 136
assign 1 280 137
new 0 280 137
put 2 280 138
assign 1 281 139
new 0 281 139
assign 1 281 140
quoteGet 0 281 140
assign 1 281 141
new 0 281 141
assign 1 281 142
quoteGet 0 281 142
put 2 281 143
assign 1 282 144
new 0 282 144
assign 1 282 145
new 0 282 145
put 2 282 146
assign 1 283 147
new 0 283 147
assign 1 283 148
new 0 283 148
put 2 283 149
assign 1 284 150
new 0 284 150
assign 1 284 151
new 0 284 151
put 2 284 152
assign 1 285 153
new 0 285 153
assign 1 285 154
new 0 285 154
put 2 285 155
assign 1 286 156
new 0 286 156
assign 1 286 157
new 0 286 157
put 2 286 158
assign 1 287 159
new 0 287 159
assign 1 287 160
new 0 287 160
put 2 287 161
return 1 0 165
assign 1 0 168
return 1 0 172
assign 1 0 175
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 749584012: return bem_hashGet_0();
case 1337268080: return bem_create_0();
case -287453828: return bem_new_0();
case -813823710: return bem_iteratorGet_0();
case 279017063: return bem_copy_0();
case -1162278176: return bem_toString_0();
case 1417495332: return bem_toEscapesGet_0();
case 740774521: return bem_print_0();
case 128265753: return bem_fromEscapesGet_0();
case 998667911: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -286545109: return bem_notEquals_1(bevd_0);
case -41247168: return bem_toEscapesSet_1(bevd_0);
case -917009475: return bem_undef_1(bevd_0);
case -60837636: return bem_def_1(bevd_0);
case -1568587710: return bem_fromEscapesSet_1(bevd_0);
case -1232318468: return bem_equals_1(bevd_0);
case -1600575656: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -539426492: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -533312375: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -306114529: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -551967809: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_JsonEscapes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_7_JsonEscapes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_JsonEscapes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst = (BEC_2_4_7_JsonEscapes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_type;
}
}
