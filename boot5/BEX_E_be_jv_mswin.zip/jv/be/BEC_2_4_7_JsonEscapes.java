package be;
/* IO:File: source/extended/Json.be */
public final class BEC_2_4_7_JsonEscapes extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_JsonEscapes() { }
private static byte[] becc_BEC_2_4_7_JsonEscapes_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x45,0x73,0x63,0x61,0x70,0x65,0x73};
private static byte[] becc_BEC_2_4_7_JsonEscapes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_0 = {0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_1 = {0x5C,0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_2 = {0x08};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_3 = {0x5C,0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_4 = {0x0C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_5 = {0x5C,0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_6 = {0x0A};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_7 = {0x5C,0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_8 = {0x0D};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_9 = {0x5C,0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_10 = {0x09};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_11 = {0x5C,0x74};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_12 = {0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_13 = {0x5C,0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_14 = {0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_15 = {0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_16 = {0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_17 = {0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_18 = {0x74};
public static BEC_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_inst;

public static BET_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_type;

public BEC_2_9_3_ContainerMap bevp_toEscapes;
public BEC_2_9_3_ContainerMap bevp_fromEscapes;
public BEC_2_4_7_JsonEscapes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_default_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_7_TextStrings bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_7_TextStrings bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_7_TextStrings bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_7_TextStrings bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
bevp_toEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_fromEscapes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_1));
bevp_toEscapes.bem_put_2(bevt_0_ta_ph, bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_7_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_ta_ph = bevt_7_ta_ph.bem_quoteGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_11_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_10_ta_ph = bevt_11_ta_ph.bem_quoteGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
bevp_toEscapes.bem_put_2(bevt_4_ta_ph, bevt_8_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_3));
bevp_toEscapes.bem_put_2(bevt_12_ta_ph, bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_5));
bevp_toEscapes.bem_put_2(bevt_16_ta_ph, bevt_19_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_22_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_7));
bevp_toEscapes.bem_put_2(bevt_20_ta_ph, bevt_23_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_9));
bevp_toEscapes.bem_put_2(bevt_24_ta_ph, bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevt_28_ta_ph = bevt_29_ta_ph.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_11));
bevp_toEscapes.bem_put_2(bevt_28_ta_ph, bevt_31_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_34_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevt_34_ta_ph);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_13));
bevp_toEscapes.bem_put_2(bevt_32_ta_ph, bevt_35_ta_ph);
bevt_36_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_37_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevp_fromEscapes.bem_put_2(bevt_36_ta_ph, bevt_37_ta_ph);
bevt_39_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_38_ta_ph = bevt_39_ta_ph.bem_quoteGet_0();
bevt_41_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_40_ta_ph = bevt_41_ta_ph.bem_quoteGet_0();
bevp_fromEscapes.bem_put_2(bevt_38_ta_ph, bevt_40_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_14));
bevt_43_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevp_fromEscapes.bem_put_2(bevt_42_ta_ph, bevt_43_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_15));
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevp_fromEscapes.bem_put_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_16));
bevt_47_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevp_fromEscapes.bem_put_2(bevt_46_ta_ph, bevt_47_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_17));
bevt_49_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevp_fromEscapes.bem_put_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_50_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_18));
bevt_51_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevp_fromEscapes.bem_put_2(bevt_50_ta_ph, bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_53_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevp_fromEscapes.bem_put_2(bevt_52_ta_ph, bevt_53_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGet_0() throws Throwable {
return bevp_toEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGet_0() throws Throwable {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {262, 263, 265, 265, 265, 265, 265, 266, 266, 266, 266, 266, 266, 266, 266, 266, 267, 267, 267, 267, 267, 268, 268, 268, 268, 268, 269, 269, 269, 269, 269, 270, 270, 270, 270, 270, 271, 271, 271, 271, 271, 272, 272, 272, 272, 272, 274, 274, 274, 275, 275, 275, 275, 275, 276, 276, 276, 277, 277, 277, 278, 278, 278, 279, 279, 279, 280, 280, 280, 281, 281, 281, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 165, 168, 172, 175};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 262 90
new 0 262 90
assign 1 263 91
new 0 263 91
assign 1 265 92
new 0 265 92
assign 1 265 93
new 0 265 93
assign 1 265 94
addValue 1 265 94
assign 1 265 95
new 0 265 95
put 2 265 96
assign 1 266 97
new 0 266 97
assign 1 266 98
new 0 266 98
assign 1 266 99
quoteGet 0 266 99
assign 1 266 100
addValue 1 266 100
assign 1 266 101
new 0 266 101
assign 1 266 102
new 0 266 102
assign 1 266 103
quoteGet 0 266 103
assign 1 266 104
add 1 266 104
put 2 266 105
assign 1 267 106
new 0 267 106
assign 1 267 107
new 0 267 107
assign 1 267 108
addValue 1 267 108
assign 1 267 109
new 0 267 109
put 2 267 110
assign 1 268 111
new 0 268 111
assign 1 268 112
new 0 268 112
assign 1 268 113
addValue 1 268 113
assign 1 268 114
new 0 268 114
put 2 268 115
assign 1 269 116
new 0 269 116
assign 1 269 117
new 0 269 117
assign 1 269 118
addValue 1 269 118
assign 1 269 119
new 0 269 119
put 2 269 120
assign 1 270 121
new 0 270 121
assign 1 270 122
new 0 270 122
assign 1 270 123
addValue 1 270 123
assign 1 270 124
new 0 270 124
put 2 270 125
assign 1 271 126
new 0 271 126
assign 1 271 127
new 0 271 127
assign 1 271 128
addValue 1 271 128
assign 1 271 129
new 0 271 129
put 2 271 130
assign 1 272 131
new 0 272 131
assign 1 272 132
new 0 272 132
assign 1 272 133
addValue 1 272 133
assign 1 272 134
new 0 272 134
put 2 272 135
assign 1 274 136
new 0 274 136
assign 1 274 137
new 0 274 137
put 2 274 138
assign 1 275 139
new 0 275 139
assign 1 275 140
quoteGet 0 275 140
assign 1 275 141
new 0 275 141
assign 1 275 142
quoteGet 0 275 142
put 2 275 143
assign 1 276 144
new 0 276 144
assign 1 276 145
new 0 276 145
put 2 276 146
assign 1 277 147
new 0 277 147
assign 1 277 148
new 0 277 148
put 2 277 149
assign 1 278 150
new 0 278 150
assign 1 278 151
new 0 278 151
put 2 278 152
assign 1 279 153
new 0 279 153
assign 1 279 154
new 0 279 154
put 2 279 155
assign 1 280 156
new 0 280 156
assign 1 280 157
new 0 280 157
put 2 280 158
assign 1 281 159
new 0 281 159
assign 1 281 160
new 0 281 160
put 2 281 161
return 1 0 165
assign 1 0 168
return 1 0 172
assign 1 0 175
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1146745485: return bem_fromEscapesGet_0();
case 1873540986: return bem_hashGet_0();
case 485745298: return bem_new_0();
case -1900847811: return bem_print_0();
case -121033251: return bem_create_0();
case 993904896: return bem_copy_0();
case 348103798: return bem_iteratorGet_0();
case 1924335797: return bem_toEscapesGet_0();
case 912791834: return bem_default_0();
case -869004384: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -554072871: return bem_def_1(bevd_0);
case 916259092: return bem_copyTo_1(bevd_0);
case -246132681: return bem_toEscapesSet_1(bevd_0);
case 887202309: return bem_notEquals_1(bevd_0);
case 1218368508: return bem_undef_1(bevd_0);
case -596585082: return bem_equals_1(bevd_0);
case -475721927: return bem_fromEscapesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1669355053: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1189844441: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 87795638: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 14330381: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_JsonEscapes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_7_JsonEscapes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_JsonEscapes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst = (BEC_2_4_7_JsonEscapes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_type;
}
}
