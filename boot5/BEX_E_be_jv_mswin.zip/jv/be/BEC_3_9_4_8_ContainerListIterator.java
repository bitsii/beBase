package be;
/* IO:File: source/base/List.be */
public final class BEC_3_9_4_8_ContainerListIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;

public static BET_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public BEC_2_4_3_MathInt bevp_none;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_3_9_4_8_ContainerListIterator bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_npos = (new BEC_2_4_3_MathInt());
bevp_none = (new BEC_2_4_3_MathInt(-1));
bevp_zero = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) throws Throwable {
bevp_pos = (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (new BEC_2_4_3_MathInt());
bevp_none = (new BEC_2_4_3_MathInt(-1));
bevp_zero = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (bevp_pos.bevi_int > bevp_zero.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 38*/ {
bevt_3_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 38*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 38*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 38*/
 else /* Line: 38*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 38*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 39*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
if (bevp_pos.bevi_int >= bevp_none.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_3_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 55*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 55*/
 else /* Line: 55*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 55*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 56*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 18, 19, 20, 21, 26, 27, 28, 29, 30, 34, 38, 38, 38, 38, 38, 0, 0, 0, 39, 39, 41, 41, 45, 45, 49, 49, 53, 54, 55, 55, 55, 55, 55, 0, 0, 0, 56, 56, 58, 58, 62, 63, 63, 67, 68, 68, 72};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 20, 21, 22, 23, 27, 28, 29, 30, 31, 35, 44, 49, 50, 51, 56, 57, 60, 64, 67, 68, 70, 71, 75, 76, 80, 81, 90, 91, 92, 97, 98, 99, 104, 105, 108, 112, 115, 116, 118, 119, 123, 124, 125, 129, 130, 131, 134};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 18
new 0 17 18
assign 1 18 19
new 0 18 19
assign 1 18 20
new 1 18 20
assign 1 19 21
new 0 19 21
assign 1 20 22
new 0 20 22
assign 1 21 23
new 0 21 23
assign 1 26 27
new 0 26 27
assign 1 27 28
assign 1 28 29
new 0 28 29
assign 1 29 30
new 0 29 30
assign 1 30 31
new 0 30 31
return 1 34 35
assign 1 38 44
greater 1 38 49
assign 1 38 50
lengthGet 0 38 50
assign 1 38 51
lesser 1 38 56
assign 1 0 57
assign 1 0 60
assign 1 0 64
assign 1 39 67
new 0 39 67
return 1 39 68
assign 1 41 70
new 0 41 70
return 1 41 71
assign 1 45 75
get 1 45 75
return 1 45 76
assign 1 49 80
put 2 49 80
return 1 49 81
setValue 1 53 90
incrementValue 0 54 91
assign 1 55 92
greaterEquals 1 55 97
assign 1 55 98
lengthGet 0 55 98
assign 1 55 99
lesser 1 55 104
assign 1 0 105
assign 1 0 108
assign 1 0 112
assign 1 56 115
new 0 56 115
return 1 56 116
assign 1 58 118
new 0 58 118
return 1 58 119
incrementValue 0 62 123
assign 1 63 124
get 1 63 124
return 1 63 125
incrementValue 0 67 129
assign 1 68 130
put 2 68 130
return 1 68 131
addValue 1 72 134
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1092529293: return bem_currentGet_0();
case 1873540986: return bem_hashGet_0();
case -1597652915: return bem_containerGet_0();
case 222701055: return bem_nextGet_0();
case 485745298: return bem_new_0();
case -1287695915: return bem_hasNextGet_0();
case -1900847811: return bem_print_0();
case -121033251: return bem_create_0();
case 993904896: return bem_copy_0();
case 348103798: return bem_iteratorGet_0();
case -1375377866: return bem_hasCurrentGet_0();
case -869004384: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -835752840: return bem_currentSet_1(bevd_0);
case -176806016: return bem_new_1(bevd_0);
case 887202309: return bem_notEquals_1(bevd_0);
case 847853587: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -2036290246: return bem_nextSet_1(bevd_0);
case -554072871: return bem_def_1(bevd_0);
case 916259092: return bem_copyTo_1(bevd_0);
case 1218368508: return bem_undef_1(bevd_0);
case -596585082: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1669355053: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1189844441: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 87795638: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 14330381: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_4_8_ContainerListIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;
}
}
