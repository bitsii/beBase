package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_5_IOFileReaderStdin extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_5_IOFileReaderStdin() { }
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x53,0x74,0x64,0x69,0x6E};
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;

public static BET_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;

public BEC_4_2_4_6_5_IOFileReaderStdin bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
bevp_blockSize = (new BEC_2_4_3_MathInt(1024));
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {719, 720, 725, 725};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 719 15
new 0 719 15
assign 1 720 16
new 0 720 16
assign 1 725 24
new 0 725 24
return 1 725 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -201292676: return bem_create_0();
case -1898385560: return bem_extOpen_0();
case -80392747: return bem_close_0();
case 2111873913: return bem_isClosedGet_0();
case -2065475128: return bem_tagGet_0();
case -507248646: return bem_toString_0();
case -479220991: return bem_echo_0();
case 67894489: return bem_sourceFileNameGet_0();
case -1644626630: return bem_readBufferLine_0();
case 1509454415: return bem_fieldNamesGet_0();
case -755857848: return bem_serializeToString_0();
case -1654941234: return bem_vfileGet_0();
case 1741925051: return bem_vfileGetDirect_0();
case -1230287874: return bem_byteReaderGet_0();
case -842698583: return bem_print_0();
case 657822074: return bem_isClosedGetDirect_0();
case -1011972693: return bem_classNameGet_0();
case -629351436: return bem_readBuffer_0();
case 1975240700: return bem_blockSizeGetDirect_0();
case -1312089850: return bem_serializationIteratorGet_0();
case -445836015: return bem_readString_0();
case 116405623: return bem_once_0();
case 838598675: return bem_deserializeClassNameGet_0();
case -537231128: return bem_default_0();
case 2027881489: return bem_new_0();
case -1817966493: return bem_iteratorGet_0();
case 66023749: return bem_copy_0();
case 1767145499: return bem_toAny_0();
case 1880418594: return bem_many_0();
case -640646750: return bem_blockSizeGet_0();
case 1698347503: return bem_open_0();
case -1641731884: return bem_pathGetDirect_0();
case 1334238154: return bem_hashGet_0();
case -1141120157: return bem_pathGet_0();
case 1292255745: return bem_fieldIteratorGet_0();
case -34410316: return bem_readStringClose_0();
case 1319463124: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1968558358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2009694921: return bem_pathSetDirect_1(bevd_0);
case -1508117625: return bem_otherClass_1(bevd_0);
case 236521366: return bem_def_1(bevd_0);
case 1902941795: return bem_defined_1(bevd_0);
case 1201016043: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 291808284: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 492990940: return bem_blockSizeSetDirect_1(bevd_0);
case 1385258440: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -756117804: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 824292706: return bem_sameType_1(bevd_0);
case -890367556: return bem_undefined_1(bevd_0);
case 358154948: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -341298482: return bem_vfileSet_1(bevd_0);
case 440989655: return bem_copyTo_1(bevd_0);
case -2092079429: return bem_blockSizeSet_1(bevd_0);
case 931801515: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1480214103: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -737237761: return bem_sameObject_1(bevd_0);
case -1890627721: return bem_notEquals_1(bevd_0);
case 508708493: return bem_isClosedSet_1(bevd_0);
case -697364376: return bem_new_1(bevd_0);
case 1317453949: return bem_sameClass_1(bevd_0);
case 1751676394: return bem_otherType_1(bevd_0);
case -1831163242: return bem_isClosedSetDirect_1(bevd_0);
case 1989677345: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1483817890: return bem_undef_1(bevd_0);
case -1328502463: return bem_equals_1(bevd_0);
case 1189457440: return bem_pathSet_1(bevd_0);
case 1228301286: return bem_vfileSetDirect_1(bevd_0);
case 170875778: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -339381951: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 77948450: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1008558996: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 139476281: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1704645214: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1221915514: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -778494517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1737168375: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 219369592: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 618127987: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_5_IOFileReaderStdin();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst = (BEC_4_2_4_6_5_IOFileReaderStdin) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;
}
}
