package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_5_IOFileReaderStdin extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_5_IOFileReaderStdin() { }
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x53,0x74,0x64,0x69,0x6E};
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;

public static BET_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;

public BEC_4_2_4_6_5_IOFileReaderStdin bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
bevp_blockSize = (new BEC_2_4_3_MathInt(1024));
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {743, 744, 749, 749};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 743 15
new 0 743 15
assign 1 744 16
new 0 744 16
assign 1 749 24
new 0 749 24
return 1 749 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 320622940: return bem_echo_0();
case -1874722177: return bem_readBuffer_0();
case 1427535989: return bem_open_0();
case -1313098664: return bem_toString_0();
case 1969080256: return bem_once_0();
case -730588607: return bem_readString_0();
case 1686045927: return bem_isClosedGet_0();
case 1413082515: return bem_pathGet_0();
case 1551415145: return bem_toAny_0();
case 1057536644: return bem_byteReaderGet_0();
case 983736684: return bem_serializationIteratorGet_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case 2084331281: return bem_new_0();
case 247075507: return bem_fieldNamesGet_0();
case 1775441726: return bem_readBufferLine_0();
case 1936584039: return bem_close_0();
case 645211302: return bem_iteratorGet_0();
case 101762581: return bem_serializeContents_0();
case -357139526: return bem_many_0();
case 484635838: return bem_tagGet_0();
case -660733154: return bem_extOpen_0();
case -1100437545: return bem_isClosedGetDirect_0();
case -576502505: return bem_create_0();
case -738439163: return bem_copy_0();
case 785416079: return bem_pathGetDirect_0();
case 1178964645: return bem_vfileGetDirect_0();
case -890719598: return bem_sourceFileNameGet_0();
case 101122454: return bem_vfileGet_0();
case -389757250: return bem_blockSizeGetDirect_0();
case -1522610135: return bem_serializeToString_0();
case 1954228088: return bem_default_0();
case -753430171: return bem_fieldIteratorGet_0();
case -1966626789: return bem_hashGet_0();
case 690609043: return bem_print_0();
case -2005156683: return bem_classNameGet_0();
case 2143311427: return bem_readDiscardClose_0();
case -939926442: return bem_blockSizeGet_0();
case -2010284408: return bem_readStringClose_0();
case 561415109: return bem_readDiscard_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1092746114: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1778890614: return bem_blockSizeSetDirect_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1738765252: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1865671550: return bem_new_1(bevd_0);
case -1430108636: return bem_isClosedSet_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case 273034256: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 1028236811: return bem_blockSizeSet_1(bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case 1353906706: return bem_isClosedSetDirect_1(bevd_0);
case 990011138: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1046992351: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 758604875: return bem_def_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case -1363611238: return bem_pathSet_1(bevd_0);
case -28560571: return bem_vfileSetDirect_1(bevd_0);
case 1082747015: return bem_pathSetDirect_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1881647183: return bem_vfileSet_1(bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 1571543211: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2046982341: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -238781568: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 168856695: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_5_IOFileReaderStdin();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst = (BEC_4_2_4_6_5_IOFileReaderStdin) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;
}
}
