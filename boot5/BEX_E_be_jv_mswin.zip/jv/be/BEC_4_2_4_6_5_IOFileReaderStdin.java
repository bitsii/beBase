package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_5_IOFileReaderStdin extends BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_5_IOFileReaderStdin() { }
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x53,0x74,0x64,0x69,0x6E};
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;

public static BET_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;

public BEC_4_2_4_6_5_IOFileReaderStdin bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
bevp_blockSize = (new BEC_2_4_3_MathInt(1024));
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {669, 670, 675, 675};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 669 15
new 0 669 15
assign 1 670 16
new 0 670 16
assign 1 675 24
new 0 675 24
return 1 675 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1853591109: return bem_open_0();
case -479209354: return bem_hashGet_0();
case -1255628091: return bem_tagGet_0();
case -763800601: return bem_extOpen_0();
case -1531622162: return bem_copy_0();
case -25387250: return bem_vfileGet_0();
case 1663979256: return bem_iteratorGet_0();
case -1084760201: return bem_create_0();
case -2026346603: return bem_new_0();
case 1964378555: return bem_serializeContents_0();
case 1154933275: return bem_serializationIteratorGet_0();
case 1670566168: return bem_sourceFileNameGet_0();
case 102887971: return bem_fieldIteratorGet_0();
case 2115120452: return bem_serializeToString_0();
case -2092271774: return bem_echo_0();
case -333394073: return bem_toString_0();
case 832712678: return bem_readBuffer_0();
case 2138920286: return bem_default_0();
case -837918486: return bem_byteReaderGet_0();
case 817509324: return bem_readStringClose_0();
case -726303319: return bem_readBufferLine_0();
case 269301519: return bem_once_0();
case 1891870089: return bem_print_0();
case 1092154910: return bem_classNameGet_0();
case -415539380: return bem_many_0();
case 1516648384: return bem_readString_0();
case -1075253910: return bem_isClosedGet_0();
case -911546686: return bem_toAny_0();
case 756919921: return bem_blockSizeGet_0();
case -364300988: return bem_pathGet_0();
case -127984856: return bem_deserializeClassNameGet_0();
case 1927540982: return bem_close_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1574704139: return bem_copyTo_1(bevd_0);
case -91281186: return bem_undef_1(bevd_0);
case 1426189010: return bem_vfileSet_1(bevd_0);
case -10491559: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 291716594: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -2088579865: return bem_otherType_1(bevd_0);
case -605366432: return bem_defined_1(bevd_0);
case 1077702335: return bem_equals_1(bevd_0);
case 1793903539: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1674374988: return bem_sameObject_1(bevd_0);
case 825323374: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -2109819584: return bem_def_1(bevd_0);
case 1133099499: return bem_new_1(bevd_0);
case 1541049287: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -816647703: return bem_pathSet_1(bevd_0);
case -2027519443: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 172070198: return bem_blockSizeSet_1(bevd_0);
case 8626873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -266225430: return bem_notEquals_1(bevd_0);
case -1020405356: return bem_otherClass_1(bevd_0);
case -2035847518: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1139979118: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1034957847: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1908721809: return bem_isClosedSet_1(bevd_0);
case 1980041008: return bem_undefined_1(bevd_0);
case -326579864: return bem_sameClass_1(bevd_0);
case -834006616: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 926020368: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1571889490: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2102131694: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -730327046: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1129799281: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -783330142: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456214761: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743986647: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 884194900: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -292574169: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_5_IOFileReaderStdin();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst = (BEC_4_2_4_6_5_IOFileReaderStdin) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;
}
}
