package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_4_MathInts extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
private static byte[] becc_BEC_2_4_4_MathInts_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_4_4_MathInts_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static BEC_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_inst;

public static BET_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public BEC_2_4_4_MathInts bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (new BEC_2_4_3_MathInt());
bevl__min = (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = Integer.MAX_VALUE;
      bevl__min.bevi_int = Integer.MIN_VALUE;
      //System.out.println(bevl__max.bevi_int);
      //System.out.println(bevl__min.bevi_int);
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_one = (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 815 */ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 815 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 815 */ {
return beva_a;
} /* Line: 816 */
return beva_b;
} /*method end*/
public BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 822 */ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 822 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 822 */ {
return beva_a;
} /* Line: 823 */
return beva_b;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGet_0() throws Throwable {
return bevp_min;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() throws Throwable {
return bevp_one;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {767, 768, 807, 808, 809, 810, 815, 815, 0, 815, 815, 0, 0, 816, 818, 822, 822, 0, 822, 822, 0, 0, 823, 825, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 28, 29, 30, 31, 38, 43, 44, 47, 52, 53, 56, 60, 62, 68, 73, 74, 77, 82, 83, 86, 90, 92, 95, 98, 102, 105, 109, 112, 116, 119};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 767 21
new 0 767 21
assign 1 768 22
new 0 768 22
assign 1 807 28
assign 1 808 29
assign 1 809 30
new 0 809 30
assign 1 810 31
new 0 810 31
assign 1 815 38
undef 1 815 43
assign 1 0 44
assign 1 815 47
lesser 1 815 52
assign 1 0 53
assign 1 0 56
return 1 816 60
return 1 818 62
assign 1 822 68
undef 1 822 73
assign 1 0 74
assign 1 822 77
greater 1 822 82
assign 1 0 83
assign 1 0 86
return 1 823 90
return 1 825 92
return 1 0 95
assign 1 0 98
return 1 0 102
assign 1 0 105
return 1 0 109
assign 1 0 112
return 1 0 116
assign 1 0 119
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1670566168: return bem_sourceFileNameGet_0();
case -127984856: return bem_deserializeClassNameGet_0();
case 1891870089: return bem_print_0();
case -566355132: return bem_zeroGet_0();
case 2138920286: return bem_default_0();
case -1084760201: return bem_create_0();
case -1255628091: return bem_tagGet_0();
case -911546686: return bem_toAny_0();
case 1154933275: return bem_serializationIteratorGet_0();
case 1964378555: return bem_serializeContents_0();
case -415539380: return bem_many_0();
case 1092154910: return bem_classNameGet_0();
case -2026346603: return bem_new_0();
case 269301519: return bem_once_0();
case -1531622162: return bem_copy_0();
case -479209354: return bem_hashGet_0();
case -2092271774: return bem_echo_0();
case 102887971: return bem_fieldIteratorGet_0();
case 2115120452: return bem_serializeToString_0();
case -473955276: return bem_maxGet_0();
case -1346782265: return bem_minGet_0();
case -333394073: return bem_toString_0();
case 1663979256: return bem_iteratorGet_0();
case -921753470: return bem_oneGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2027519443: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1139979118: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2088579865: return bem_otherType_1(bevd_0);
case 1674374988: return bem_sameObject_1(bevd_0);
case -326579864: return bem_sameClass_1(bevd_0);
case -1574704139: return bem_copyTo_1(bevd_0);
case 39803323: return bem_minSet_1(bevd_0);
case -266225430: return bem_notEquals_1(bevd_0);
case -1020405356: return bem_otherClass_1(bevd_0);
case -151392430: return bem_maxSet_1(bevd_0);
case -2035847518: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1077702335: return bem_equals_1(bevd_0);
case -605366432: return bem_defined_1(bevd_0);
case -834006616: return bem_sameType_1(bevd_0);
case 439539858: return bem_oneSet_1(bevd_0);
case -1358887801: return bem_zeroSet_1(bevd_0);
case -2109819584: return bem_def_1(bevd_0);
case 1980041008: return bem_undefined_1(bevd_0);
case 8626873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -91281186: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 926020368: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1571889490: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -730327046: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1129799281: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1473562921: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -376504713: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -783330142: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456214761: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743986647: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_MathInts_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_4_MathInts_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_MathInts();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst = (BEC_2_4_4_MathInts) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_type;
}
}
