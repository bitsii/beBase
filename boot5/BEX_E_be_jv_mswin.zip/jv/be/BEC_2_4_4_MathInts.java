package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_4_MathInts extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
private static byte[] becc_BEC_2_4_4_MathInts_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_4_4_MathInts_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static BEC_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_inst;

public static BET_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public BEC_2_4_4_MathInts bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (new BEC_2_4_3_MathInt());
bevl__min = (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = Integer.MAX_VALUE;
      bevl__min.bevi_int = Integer.MIN_VALUE;
      //System.out.println(bevl__max.bevi_int);
      //System.out.println(bevl__min.bevi_int);
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_one = (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 964 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 964 */ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 964 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 964 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 964 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 964 */ {
return beva_a;
} /* Line: 965 */
return beva_b;
} /*method end*/
public BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 971 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 971 */ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 971 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 971 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 971 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 971 */ {
return beva_a;
} /* Line: 972 */
return beva_b;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() throws Throwable {
return bevp_max;
} /*method end*/
public final BEC_2_4_3_MathInt bem_maxGetDirect_0() throws Throwable {
return bevp_max;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGet_0() throws Throwable {
return bevp_min;
} /*method end*/
public final BEC_2_4_3_MathInt bem_minGetDirect_0() throws Throwable {
return bevp_min;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_minSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public final BEC_2_4_3_MathInt bem_zeroGetDirect_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() throws Throwable {
return bevp_one;
} /*method end*/
public final BEC_2_4_3_MathInt bem_oneGetDirect_0() throws Throwable {
return bevp_one;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_4_MathInts bem_oneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {910, 911, 956, 957, 958, 959, 964, 964, 0, 964, 964, 0, 0, 965, 967, 971, 971, 0, 971, 971, 0, 0, 972, 974, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 28, 29, 30, 31, 38, 43, 44, 47, 52, 53, 56, 60, 62, 68, 73, 74, 77, 82, 83, 86, 90, 92, 95, 98, 101, 105, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 910 21
new 0 910 21
assign 1 911 22
new 0 911 22
assign 1 956 28
assign 1 957 29
assign 1 958 30
new 0 958 30
assign 1 959 31
new 0 959 31
assign 1 964 38
undef 1 964 43
assign 1 0 44
assign 1 964 47
lesser 1 964 52
assign 1 0 53
assign 1 0 56
return 1 965 60
return 1 967 62
assign 1 971 68
undef 1 971 73
assign 1 0 74
assign 1 971 77
greater 1 971 82
assign 1 0 83
assign 1 0 86
return 1 972 90
return 1 974 92
return 1 0 95
return 1 0 98
assign 1 0 101
assign 1 0 105
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 367223667: return bem_minGetDirect_0();
case -1515347213: return bem_hashGet_0();
case 507602572: return bem_once_0();
case 631342118: return bem_deserializeClassNameGet_0();
case -862155694: return bem_copy_0();
case -1370019545: return bem_serializeToString_0();
case -583954274: return bem_default_0();
case -647428547: return bem_fieldIteratorGet_0();
case 1379664484: return bem_toAny_0();
case -2097425691: return bem_zeroGetDirect_0();
case -2053182262: return bem_zeroGet_0();
case -688295882: return bem_tagGet_0();
case -1183965149: return bem_maxGet_0();
case -1814630541: return bem_classNameGet_0();
case 2066689040: return bem_oneGet_0();
case 562477328: return bem_serializationIteratorGet_0();
case 886168102: return bem_many_0();
case 899271096: return bem_new_0();
case -542639344: return bem_toString_0();
case 1884909798: return bem_create_0();
case -1906660880: return bem_print_0();
case 1908374935: return bem_maxGetDirect_0();
case -973290132: return bem_iteratorGet_0();
case 1688744619: return bem_serializeContents_0();
case -1825175920: return bem_minGet_0();
case -1412673222: return bem_oneGetDirect_0();
case -1067099981: return bem_fieldNamesGet_0();
case -21012660: return bem_sourceFileNameGet_0();
case -1648627766: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2120701530: return bem_equals_1(bevd_0);
case -241199401: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 933337007: return bem_maxSetDirect_1(bevd_0);
case -242543272: return bem_zeroSet_1(bevd_0);
case -1715866358: return bem_notEquals_1(bevd_0);
case -345992202: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 216018244: return bem_copyTo_1(bevd_0);
case -787854595: return bem_oneSet_1(bevd_0);
case 617185386: return bem_minSet_1(bevd_0);
case -734789597: return bem_undefined_1(bevd_0);
case 1699948937: return bem_maxSet_1(bevd_0);
case -1205899919: return bem_zeroSetDirect_1(bevd_0);
case 1116925492: return bem_sameType_1(bevd_0);
case 1280914604: return bem_otherClass_1(bevd_0);
case 1744917313: return bem_defined_1(bevd_0);
case 1142143738: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 746661405: return bem_minSetDirect_1(bevd_0);
case 898034411: return bem_sameClass_1(bevd_0);
case 2001300007: return bem_sameObject_1(bevd_0);
case -914794223: return bem_undef_1(bevd_0);
case 1402754792: return bem_def_1(bevd_0);
case 112694122: return bem_oneSetDirect_1(bevd_0);
case 1820085236: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1349849963: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2011759429: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1894612: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1172911600: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -603725496: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1784313817: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1485133109: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2028721987: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1506940745: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1630879145: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_MathInts_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_4_MathInts_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_MathInts();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst = (BEC_2_4_4_MathInts) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_type;
}
}
