package be;
/* IO:File: source/extended/Serialize.be */
public final class BEC_2_6_10_SystemSerializer extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_BEC_2_6_10_SystemSerializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_10_SystemSerializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_0 = {0x7C};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_1 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_2 = {0x26};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_3 = {0x40};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_4 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_5 = {0x3F};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_6 = {0x5E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_7 = {};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_8 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_9 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_10 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
public static BEC_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_inst;

public static BET_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_type;

public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public BEC_2_6_10_SystemSerializer bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_2));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_3));
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_5));
bevt_6_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_6));
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bem_new_10(bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph, bevt_6_ta_ph, bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_ta_ph = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_getReference);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_constructString);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_nullMark);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_defineClassTag);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_getClassTag);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_shift);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
bevp_toker = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_7_ta_ph);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevp_saveIdentity = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_ta_ph = null;
if (beva_instance == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 92*/ {
bevt_1_ta_ph = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
bem_serializeI_2(beva_instance, bevt_1_ta_ph);
} /* Line: 93*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session );
bevt_0_ta_ph = beva_instance.bemd_0(-1485421802);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 99*/ {
bem_serializeC_2(beva_instance, beva_session);
} /* Line: 100*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) throws Throwable {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
bevl_instWriter = beva_session.bemd_0(-1406841284);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
bevl_iter = beva_instance.bemd_0(2090308182);
bevt_0_ta_ph = bevl_iter.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 108*/ {
bevl_instWriter.bemd_1(135517263, bevp_group);
while (true)
/* Line: 110*/ {
bevt_1_ta_ph = bevl_iter.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 110*/ {
bevl_i = bevl_iter.bemd_0(-275494575);
if (bevl_i == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 112*/ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 114*/
 else /* Line: 115*/ {
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 117*/ {
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 119*/
 else /* Line: 117*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 120*/ {
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 123*/
 else /* Line: 117*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 124*/ {
bevl_instWriter.bemd_1(135517263, bevp_shift);
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevt_9_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(135517263, bevt_9_ta_ph);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 128*/
} /* Line: 117*/
} /* Line: 117*/
if (bevp_saveIdentity.bevi_bool) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 130*/ {
bevl_instSerial = null;
} /* Line: 131*/
 else /* Line: 132*/ {
bevt_11_ta_ph = beva_session.bemd_0(1587382007);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_11_ta_ph.bemd_1(1117646931, bevl_i);
} /* Line: 133*/
if (bevl_instSerial == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 135*/ {
bem_serializeI_2(bevl_i, beva_session);
} /* Line: 137*/
 else /* Line: 138*/ {
bevl_instWriter.bemd_1(135517263, bevp_getReference);
bevt_13_ta_ph = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(135517263, bevt_13_ta_ph);
} /* Line: 141*/
} /* Line: 135*/
} /* Line: 112*/
 else /* Line: 110*/ {
break;
} /* Line: 110*/
} /* Line: 110*/
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 146*/ {
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 148*/
 else /* Line: 146*/ {
bevt_17_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 149*/ {
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 152*/
 else /* Line: 146*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_19_ta_ph.bevi_int) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 153*/ {
bevl_instWriter.bemd_1(135517263, bevp_shift);
bevl_instWriter.bemd_1(135517263, bevp_nullMark);
bevt_20_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(135517263, bevt_20_ta_ph);
bevl_multiNull = (new BEC_2_4_3_MathInt(0));
} /* Line: 157*/
} /* Line: 146*/
} /* Line: 146*/
bevl_instWriter.bemd_1(135517263, bevp_shift);
bevl_instWriter.bemd_1(135517263, bevp_group);
} /* Line: 160*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) throws Throwable {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_11_ContainerIdentityMap bevt_13_ta_ph = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevl_scount.bem_add_1(bevt_2_ta_ph);
beva_session.bem_serialCountSet_1(bevt_1_ta_ph);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(1350181777);
bevt_3_ta_ph = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 171*/ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevl_instClassTag.bem_add_1(bevt_6_ta_ph);
beva_session.bem_classTagCountSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = beva_session.bem_classTagMapGet_0();
bevt_7_ta_ph.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(135517263, bevp_shift);
bevl_instWriter.bemd_1(135517263, bevp_defineClassTag);
bevl_instWriter.bemd_1(135517263, bevl_instClass);
bevl_instWriter.bemd_1(135517263, bevp_shift);
bevl_instWriter.bemd_1(135517263, bevp_defineClassTag);
bevl_instWriter.bemd_1(135517263, bevl_instClassTagStr);
} /* Line: 181*/
 else /* Line: 182*/ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 183*/
if (bevp_saveIdentity.bevi_bool)/* Line: 185*/ {
bevl_instWriter.bemd_1(135517263, bevp_defineReference);
bevt_8_ta_ph = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(135517263, bevt_8_ta_ph);
} /* Line: 187*/
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(-1070994386);
if (bevl_serializedString == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_6_10_SystemSerializer_bels_7));
bevt_10_ta_ph = bevl_serializedString.bem_notEquals_1(bevt_11_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 190*/
 else /* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 190*/ {
bevl_instWriter.bemd_1(135517263, bevp_constructString);
bevt_12_ta_ph = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(135517263, bevt_12_ta_ph);
} /* Line: 192*/
bevl_instWriter.bemd_1(135517263, bevp_getClassTag);
bevl_instWriter.bemd_1(135517263, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool)/* Line: 196*/ {
bevt_13_ta_ph = beva_session.bem_uniqueGet_0();
bevt_13_ta_ph.bem_put_2(beva_instance, bevl_scount);
} /* Line: 197*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) throws Throwable {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_9_SystemException bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_6_9_SystemException bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_1_ta_ph = beva_instReader.bemd_1(-580813096, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 206*/ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 207*/
 else /* Line: 208*/ {
bevt_4_ta_ph = beva_instReader.bemd_0(1012216241);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_4_ta_ph);
} /* Line: 209*/
bevl_instances = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 215*/ {
bevt_5_ta_ph = bevl_i.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 215*/ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(-275494575);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_state.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_8_ta_ph = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_8_ta_ph.bevi_bool)/* Line: 218*/ {
bevl_state = (new BEC_2_4_3_MathInt(1));
} /* Line: 219*/
 else /* Line: 218*/ {
bevt_9_ta_ph = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_9_ta_ph.bevi_bool)/* Line: 220*/ {
bevl_state = (new BEC_2_4_3_MathInt(2));
} /* Line: 221*/
 else /* Line: 218*/ {
bevt_10_ta_ph = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_10_ta_ph.bevi_bool)/* Line: 222*/ {
bevl_state = (new BEC_2_4_3_MathInt(8));
} /* Line: 223*/
 else /* Line: 218*/ {
bevt_11_ta_ph = bevl_token.bem_equals_1(bevp_shift);
if (bevt_11_ta_ph.bevi_bool)/* Line: 224*/ {
bevl_state = (new BEC_2_4_3_MathInt(1000));
} /* Line: 225*/
 else /* Line: 218*/ {
bevt_12_ta_ph = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_12_ta_ph.bevi_bool)/* Line: 226*/ {
bevl_state = (new BEC_2_4_3_MathInt(4));
} /* Line: 227*/
 else /* Line: 218*/ {
bevt_13_ta_ph = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_13_ta_ph.bevi_bool)/* Line: 228*/ {
if (bevl_groupInstIter == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 230*/ {
bevl_groupInstIter.bemd_1(152242756, null);
} /* Line: 231*/
} /* Line: 230*/
 else /* Line: 218*/ {
bevt_15_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_15_ta_ph.bevi_bool)/* Line: 233*/ {
if (bevl_inst == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 235*/ {
if (bevl_groupInstIter == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 236*/ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 237*/
bevl_groupInstIter = bevl_inst.bemd_0(2090308182);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_18_ta_ph = bevl_groupInstIter.bemd_2(-693517224, bevt_19_ta_ph, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 240*/ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 241*/
} /* Line: 240*/
} /* Line: 235*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
 else /* Line: 217*/ {
bevt_22_ta_ph = (new BEC_2_4_3_MathInt(1000));
if (bevl_state.bevi_int == bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 245*/ {
bevt_23_ta_ph = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_23_ta_ph.bevi_bool)/* Line: 247*/ {
if (bevl_defineClassTagName == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 248*/ {
bevl_state = (new BEC_2_4_3_MathInt(6));
} /* Line: 249*/
 else /* Line: 250*/ {
bevl_state = (new BEC_2_4_3_MathInt(7));
} /* Line: 251*/
} /* Line: 248*/
 else /* Line: 247*/ {
bevt_25_ta_ph = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_25_ta_ph.bevi_bool)/* Line: 253*/ {
bevl_state = (new BEC_2_4_3_MathInt(9));
} /* Line: 254*/
 else /* Line: 247*/ {
bevt_26_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_26_ta_ph.bevi_bool)/* Line: 255*/ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 258*/
} /* Line: 247*/
} /* Line: 247*/
} /* Line: 247*/
 else /* Line: 260*/ {
bevt_28_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_state.bevi_int == bevt_28_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 261*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_31_ta_ph = (new BEC_2_4_6_TextString(73, bece_BEC_2_6_10_SystemSerializer_bels_9));
bevt_30_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_31_ta_ph);
throw new be.BECS_ThrowBack(bevt_30_ta_ph);
} /* Line: 263*/
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 266*/
 else /* Line: 261*/ {
bevt_33_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevl_state.bevi_int == bevt_33_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 267*/ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 269*/
 else /* Line: 261*/ {
bevt_35_ta_ph = (new BEC_2_4_3_MathInt(8));
if (bevl_state.bevi_int == bevt_35_ta_ph.bevi_int) {
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 270*/ {
bevl_glassTagVal = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_36_ta_ph = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_36_ta_ph.bem_get_1(bevl_glassTagVal);
bevt_38_ta_ph = bem_createInstance_1(bevl_klass);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(851006420, bevl_instString);
bevl_inst = bevt_37_ta_ph.bemd_1(1894822196, bevl_instString);
if (bevl_rootInst == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 274*/ {
bevl_rootInst = bevl_inst;
} /* Line: 275*/
if (bevp_saveIdentity.bevi_bool)/* Line: 277*/ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 278*/
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_40_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_40_ta_ph.bevi_bool)/* Line: 282*/ {
bevl_groupInstIter.bemd_1(152242756, bevl_inst);
} /* Line: 283*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 285*/
 else /* Line: 261*/ {
bevt_42_ta_ph = (new BEC_2_4_3_MathInt(4));
if (bevl_state.bevi_int == bevt_42_ta_ph.bevi_int) {
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 286*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(66, bece_BEC_2_6_10_SystemSerializer_bels_10));
bevt_44_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_45_ta_ph);
throw new be.BECS_ThrowBack(bevt_44_ta_ph);
} /* Line: 288*/
bevl_instSerial = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 292*/ {
bevl_groupInstIter.bemd_1(152242756, bevl_inst);
} /* Line: 293*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 295*/
 else /* Line: 261*/ {
bevt_48_ta_ph = (new BEC_2_4_3_MathInt(6));
if (bevl_state.bevi_int == bevt_48_ta_ph.bevi_int) {
bevt_47_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_47_ta_ph.bevi_bool)/* Line: 296*/ {
bevl_defineClassTagName = bevl_token;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 298*/
 else /* Line: 261*/ {
bevt_50_ta_ph = (new BEC_2_4_3_MathInt(7));
if (bevl_state.bevi_int == bevt_50_ta_ph.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 299*/ {
bevl_defineClassTagValue = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_51_ta_ph = bevl_session.bem_classTagMapGet_0();
bevt_51_ta_ph.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 304*/
 else /* Line: 261*/ {
bevt_53_ta_ph = (new BEC_2_4_3_MathInt(9));
if (bevl_state.bevi_int == bevt_53_ta_ph.bevi_int) {
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 305*/ {
if (bevl_groupInstIter == null) {
bevt_54_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_54_ta_ph.bevi_bool)/* Line: 307*/ {
bevl_multiNullCount = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(1001328945, bevl_multiNullCount);
} /* Line: 309*/
bevl_state = (new BEC_2_4_3_MathInt(0));
} /* Line: 311*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 217*/
} /* Line: 217*/
 else /* Line: 215*/ {
break;
} /* Line: 215*/
} /* Line: 215*/
bevl_inst = null;
bevt_0_ta_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
/* Line: 316*/ {
bevt_55_ta_ph = bevt_0_ta_loop.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_55_ta_ph).bevi_bool)/* Line: 316*/ {
bevl_groupInstIter = bevt_0_ta_loop.bemd_0(-275494575);
bevl_groupInstIter.bemd_0(2105019530);
} /* Line: 317*/
 else /* Line: 316*/ {
break;
} /* Line: 316*/
} /* Line: 316*/
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() throws Throwable {
return bevp_group;
} /*method end*/
public final BEC_2_4_6_TextString bem_groupGetDirect_0() throws Throwable {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_groupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public final BEC_2_4_6_TextString bem_defineReferenceGetDirect_0() throws Throwable {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_defineReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public final BEC_2_4_6_TextString bem_getReferenceGetDirect_0() throws Throwable {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_getReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public final BEC_2_4_6_TextString bem_constructStringGetDirect_0() throws Throwable {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_constructStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public final BEC_2_4_6_TextString bem_nullMarkGetDirect_0() throws Throwable {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_nullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public final BEC_2_4_6_TextString bem_getClassTagGetDirect_0() throws Throwable {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_getClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() throws Throwable {
return bevp_shift;
} /*method end*/
public final BEC_2_4_6_TextString bem_shiftGetDirect_0() throws Throwable {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_shiftSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public final BEC_2_4_6_TextString bem_defineClassTagGetDirect_0() throws Throwable {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_defineClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public final BEC_2_4_6_TextString bem_multiNullMarkGetDirect_0() throws Throwable {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_multiNullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public final BEC_2_4_6_TextString bem_endGroupGetDirect_0() throws Throwable {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_endGroupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() throws Throwable {
return bevp_toker;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() throws Throwable {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public final BEC_2_6_3_EncodeHex bem_encoderGetDirect_0() throws Throwable {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_encoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_saveIdentityGetDirect_0() throws Throwable {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_10_SystemSerializer bem_saveIdentitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 77, 77, 77, 77, 77, 77, 77, 78, 76, 80, 81, 86, 87, 88, 92, 92, 93, 93, 98, 99, 100, 105, 106, 107, 108, 109, 110, 111, 112, 112, 114, 117, 117, 117, 118, 119, 120, 120, 120, 121, 122, 123, 124, 124, 124, 125, 126, 127, 127, 128, 130, 130, 131, 133, 133, 135, 135, 137, 140, 141, 141, 146, 146, 146, 147, 148, 149, 149, 149, 150, 151, 152, 153, 153, 153, 154, 155, 156, 156, 157, 159, 160, 165, 166, 166, 166, 168, 169, 170, 170, 171, 171, 172, 173, 174, 174, 174, 175, 175, 176, 177, 178, 179, 180, 181, 183, 186, 187, 187, 189, 190, 190, 190, 190, 0, 0, 0, 191, 192, 192, 194, 195, 197, 197, 202, 203, 204, 205, 206, 206, 206, 207, 209, 209, 211, 215, 215, 216, 217, 217, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 230, 230, 231, 233, 235, 235, 236, 236, 237, 239, 240, 240, 240, 241, 245, 245, 245, 247, 248, 248, 249, 251, 253, 254, 255, 257, 258, 261, 261, 261, 262, 262, 263, 263, 263, 265, 266, 267, 267, 267, 268, 269, 270, 270, 270, 271, 272, 272, 273, 273, 273, 274, 274, 275, 278, 280, 282, 282, 283, 285, 286, 286, 286, 287, 287, 288, 288, 288, 290, 291, 292, 292, 293, 295, 296, 296, 296, 297, 298, 299, 299, 299, 301, 302, 302, 303, 304, 305, 305, 305, 307, 307, 308, 309, 311, 315, 316, 0, 316, 316, 317, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 93, 94, 95, 100, 105, 106, 107, 113, 114, 116, 147, 148, 149, 150, 152, 155, 157, 158, 163, 164, 167, 168, 173, 174, 175, 178, 179, 184, 185, 186, 187, 190, 191, 196, 197, 198, 199, 200, 201, 205, 210, 211, 214, 215, 217, 222, 223, 226, 227, 228, 236, 237, 242, 243, 244, 247, 248, 253, 254, 255, 256, 259, 260, 265, 266, 267, 268, 269, 270, 274, 275, 300, 301, 302, 303, 304, 305, 306, 307, 308, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 329, 332, 333, 334, 336, 337, 342, 343, 344, 346, 349, 353, 356, 357, 358, 360, 361, 363, 364, 443, 444, 445, 446, 447, 448, 449, 451, 454, 455, 457, 458, 461, 463, 464, 465, 470, 471, 473, 476, 478, 481, 483, 486, 488, 491, 493, 496, 498, 503, 504, 508, 510, 515, 516, 521, 522, 524, 525, 526, 527, 529, 541, 542, 547, 548, 550, 555, 556, 559, 563, 565, 568, 570, 571, 577, 578, 583, 584, 589, 590, 591, 592, 594, 595, 598, 599, 604, 605, 606, 609, 610, 615, 616, 617, 618, 619, 620, 621, 622, 627, 628, 631, 633, 634, 639, 640, 642, 645, 646, 651, 652, 657, 658, 659, 660, 662, 663, 664, 669, 670, 672, 675, 676, 681, 682, 683, 686, 687, 692, 693, 694, 695, 696, 697, 700, 701, 706, 707, 712, 713, 714, 716, 731, 732, 732, 735, 737, 738, 744, 747, 750, 753, 757, 761, 764, 767, 771, 775, 778, 781, 785, 789, 792, 795, 799, 803, 806, 809, 813, 817, 820, 823, 827, 831, 834, 837, 841, 845, 848, 851, 855, 859, 862, 865, 869, 873, 876, 879, 883, 887, 890, 893, 897, 901, 904, 907, 911, 915, 918, 921, 925};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 60 46
new 0 60 46
assign 1 60 47
new 0 60 47
assign 1 60 48
new 0 60 48
assign 1 60 49
new 0 60 49
assign 1 60 50
new 0 60 50
assign 1 60 51
new 0 60 51
assign 1 60 52
new 0 60 52
assign 1 60 53
new 0 60 53
assign 1 60 54
new 0 60 54
assign 1 60 55
new 0 60 55
new 10 60 56
assign 1 66 68
assign 1 67 69
assign 1 68 70
assign 1 69 71
assign 1 70 72
assign 1 71 73
assign 1 72 74
assign 1 73 75
assign 1 74 76
assign 1 75 77
assign 1 77 78
add 1 77 78
assign 1 77 79
add 1 77 79
assign 1 77 80
add 1 77 80
assign 1 77 81
add 1 77 81
assign 1 77 82
add 1 77 82
assign 1 77 83
add 1 77 83
assign 1 77 84
add 1 77 84
assign 1 78 85
new 0 78 85
assign 1 76 86
new 2 76 86
assign 1 80 87
new 0 80 87
assign 1 81 88
new 0 81 88
assign 1 86 93
new 0 86 93
serialize 2 87 94
return 1 88 95
assign 1 92 100
def 1 92 105
assign 1 93 106
new 1 93 106
serializeI 2 93 107
defineInstance 2 98 113
assign 1 99 114
serializeContents 0 99 114
serializeC 2 100 116
assign 1 105 147
instWriterGet 0 105 147
assign 1 106 148
new 0 106 148
assign 1 107 149
serializationIteratorGet 0 107 149
assign 1 108 150
hasNextGet 0 108 150
write 1 109 152
assign 1 110 155
hasNextGet 0 110 155
assign 1 111 157
nextGet 0 111 157
assign 1 112 158
undef 1 112 163
assign 1 114 164
increment 0 114 164
assign 1 117 167
new 0 117 167
assign 1 117 168
equals 1 117 173
write 1 118 174
assign 1 119 175
new 0 119 175
assign 1 120 178
new 0 120 178
assign 1 120 179
equals 1 120 184
write 1 121 185
write 1 122 186
assign 1 123 187
new 0 123 187
assign 1 124 190
new 0 124 190
assign 1 124 191
greater 1 124 196
write 1 125 197
write 1 126 198
assign 1 127 199
toString 0 127 199
write 1 127 200
assign 1 128 201
new 0 128 201
assign 1 130 205
not 0 130 210
assign 1 131 211
assign 1 133 214
uniqueGet 0 133 214
assign 1 133 215
get 1 133 215
assign 1 135 217
undef 1 135 222
serializeI 2 137 223
write 1 140 226
assign 1 141 227
toString 0 141 227
write 1 141 228
assign 1 146 236
new 0 146 236
assign 1 146 237
equals 1 146 242
write 1 147 243
assign 1 148 244
new 0 148 244
assign 1 149 247
new 0 149 247
assign 1 149 248
equals 1 149 253
write 1 150 254
write 1 151 255
assign 1 152 256
new 0 152 256
assign 1 153 259
new 0 153 259
assign 1 153 260
greater 1 153 265
write 1 154 266
write 1 155 267
assign 1 156 268
toString 0 156 268
write 1 156 269
assign 1 157 270
new 0 157 270
write 1 159 274
write 1 160 275
assign 1 165 300
serialCountGet 0 165 300
assign 1 166 301
new 0 166 301
assign 1 166 302
add 1 166 302
serialCountSet 1 166 303
assign 1 168 304
instWriterGet 0 168 304
assign 1 169 305
deserializeClassNameGet 0 169 305
assign 1 170 306
classTagMapGet 0 170 306
assign 1 170 307
get 1 170 307
assign 1 171 308
undef 1 171 313
assign 1 172 314
classTagCountGet 0 172 314
assign 1 173 315
toString 0 173 315
assign 1 174 316
new 0 174 316
assign 1 174 317
add 1 174 317
classTagCountSet 1 174 318
assign 1 175 319
classTagMapGet 0 175 319
put 2 175 320
write 1 176 321
write 1 177 322
write 1 178 323
write 1 179 324
write 1 180 325
write 1 181 326
assign 1 183 329
toString 0 183 329
write 1 186 332
assign 1 187 333
toString 0 187 333
write 1 187 334
assign 1 189 336
serializeToString 0 189 336
assign 1 190 337
def 1 190 342
assign 1 190 343
new 0 190 343
assign 1 190 344
notEquals 1 190 344
assign 1 0 346
assign 1 0 349
assign 1 0 353
write 1 191 356
assign 1 192 357
encode 1 192 357
write 1 192 358
write 1 194 360
write 1 195 361
assign 1 197 363
uniqueGet 0 197 363
put 2 197 364
assign 1 202 443
new 0 202 443
assign 1 203 444
new 0 203 444
assign 1 204 445
new 0 204 445
assign 1 205 446
new 0 205 446
assign 1 206 447
new 0 206 447
assign 1 206 448
emptyGet 0 206 448
assign 1 206 449
sameType 1 206 449
assign 1 207 451
tokenize 1 207 451
assign 1 209 454
readString 0 209 454
assign 1 209 455
tokenize 1 209 455
assign 1 211 457
new 0 211 457
assign 1 215 458
linkedListIteratorGet 0 215 458
assign 1 215 461
hasNextGet 0 215 461
assign 1 216 463
nextGet 0 216 463
assign 1 217 464
new 0 217 464
assign 1 217 465
equals 1 217 470
assign 1 218 471
equals 1 218 471
assign 1 219 473
new 0 219 473
assign 1 220 476
equals 1 220 476
assign 1 221 478
new 0 221 478
assign 1 222 481
equals 1 222 481
assign 1 223 483
new 0 223 483
assign 1 224 486
equals 1 224 486
assign 1 225 488
new 0 225 488
assign 1 226 491
equals 1 226 491
assign 1 227 493
new 0 227 493
assign 1 228 496
equals 1 228 496
assign 1 230 498
def 1 230 503
nextSet 1 231 504
assign 1 233 508
equals 1 233 508
assign 1 235 510
def 1 235 515
assign 1 236 516
def 1 236 521
push 1 237 522
assign 1 239 524
serializationIteratorGet 0 239 524
assign 1 240 525
new 0 240 525
assign 1 240 526
new 0 240 526
assign 1 240 527
can 2 240 527
addValue 1 241 529
assign 1 245 541
new 0 245 541
assign 1 245 542
equals 1 245 547
assign 1 247 548
equals 1 247 548
assign 1 248 550
undef 1 248 555
assign 1 249 556
new 0 249 556
assign 1 251 559
new 0 251 559
assign 1 253 563
equals 1 253 563
assign 1 254 565
new 0 254 565
assign 1 255 568
equals 1 255 568
assign 1 257 570
pop 0 257 570
assign 1 258 571
new 0 258 571
assign 1 261 577
new 0 261 577
assign 1 261 578
equals 1 261 583
assign 1 262 584
not 0 262 589
assign 1 263 590
new 0 263 590
assign 1 263 591
new 1 263 591
throw 1 263 592
assign 1 265 594
new 1 265 594
assign 1 266 595
new 0 266 595
assign 1 267 598
new 0 267 598
assign 1 267 599
equals 1 267 604
assign 1 268 605
decode 1 268 605
assign 1 269 606
new 0 269 606
assign 1 270 609
new 0 270 609
assign 1 270 610
equals 1 270 615
assign 1 271 616
new 1 271 616
assign 1 272 617
classTagMapGet 0 272 617
assign 1 272 618
get 1 272 618
assign 1 273 619
createInstance 1 273 619
assign 1 273 620
deserializeFromStringNew 1 273 620
assign 1 273 621
deserializeFromString 1 273 621
assign 1 274 622
undef 1 274 627
assign 1 275 628
put 2 278 631
assign 1 280 633
assign 1 282 634
def 1 282 639
nextSet 1 283 640
assign 1 285 642
new 0 285 642
assign 1 286 645
new 0 286 645
assign 1 286 646
equals 1 286 651
assign 1 287 652
not 0 287 657
assign 1 288 658
new 0 288 658
assign 1 288 659
new 1 288 659
throw 1 288 660
assign 1 290 662
new 1 290 662
assign 1 291 663
get 1 291 663
assign 1 292 664
def 1 292 669
nextSet 1 293 670
assign 1 295 672
new 0 295 672
assign 1 296 675
new 0 296 675
assign 1 296 676
equals 1 296 681
assign 1 297 682
assign 1 298 683
new 0 298 683
assign 1 299 686
new 0 299 686
assign 1 299 687
equals 1 299 692
assign 1 301 693
new 1 301 693
assign 1 302 694
classTagMapGet 0 302 694
put 2 302 695
assign 1 303 696
assign 1 304 697
new 0 304 697
assign 1 305 700
new 0 305 700
assign 1 305 701
equals 1 305 706
assign 1 307 707
def 1 307 712
assign 1 308 713
new 1 308 713
skip 1 309 714
assign 1 311 716
new 0 311 716
assign 1 315 731
assign 1 316 732
iteratorGet 0 0 732
assign 1 316 735
hasNextGet 0 316 735
assign 1 316 737
nextGet 0 316 737
postDeserialize 0 317 738
return 1 319 744
return 1 0 747
return 1 0 750
assign 1 0 753
assign 1 0 757
return 1 0 761
return 1 0 764
assign 1 0 767
assign 1 0 771
return 1 0 775
return 1 0 778
assign 1 0 781
assign 1 0 785
return 1 0 789
return 1 0 792
assign 1 0 795
assign 1 0 799
return 1 0 803
return 1 0 806
assign 1 0 809
assign 1 0 813
return 1 0 817
return 1 0 820
assign 1 0 823
assign 1 0 827
return 1 0 831
return 1 0 834
assign 1 0 837
assign 1 0 841
return 1 0 845
return 1 0 848
assign 1 0 851
assign 1 0 855
return 1 0 859
return 1 0 862
assign 1 0 865
assign 1 0 869
return 1 0 873
return 1 0 876
assign 1 0 879
assign 1 0 883
return 1 0 887
return 1 0 890
assign 1 0 893
assign 1 0 897
return 1 0 901
return 1 0 904
assign 1 0 907
assign 1 0 911
return 1 0 915
return 1 0 918
assign 1 0 921
assign 1 0 925
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1784713590: return bem_groupGetDirect_0();
case 1533301608: return bem_once_0();
case 2090308182: return bem_serializationIteratorGet_0();
case 469657691: return bem_fieldNamesGet_0();
case -1070994386: return bem_serializeToString_0();
case 581565810: return bem_encoderGet_0();
case -238821970: return bem_multiNullMarkGet_0();
case -1893851797: return bem_endGroupGetDirect_0();
case 991750533: return bem_nullMarkGet_0();
case 1965801140: return bem_iteratorGet_0();
case 370205468: return bem_shiftGet_0();
case 2044090738: return bem_defineClassTagGet_0();
case -1010547777: return bem_saveIdentityGetDirect_0();
case -754867309: return bem_groupGet_0();
case 1915998808: return bem_constructStringGetDirect_0();
case -482858: return bem_defineReferenceGetDirect_0();
case 349484786: return bem_multiNullMarkGetDirect_0();
case -1248679117: return bem_toString_0();
case -1027759034: return bem_shiftGetDirect_0();
case -1823784474: return bem_constructStringGet_0();
case -1327508564: return bem_endGroupGet_0();
case 115643823: return bem_defineReferenceGet_0();
case -1648057302: return bem_echo_0();
case 245995345: return bem_encoderGetDirect_0();
case -1456422317: return bem_toAny_0();
case -1354435489: return bem_getClassTagGetDirect_0();
case -2024847551: return bem_getReferenceGet_0();
case 983251128: return bem_new_0();
case 1085612775: return bem_tagGet_0();
case -1921386418: return bem_defineClassTagGetDirect_0();
case -1485421802: return bem_serializeContents_0();
case -1628405423: return bem_getReferenceGetDirect_0();
case -369356392: return bem_fieldIteratorGet_0();
case 238971711: return bem_sourceFileNameGet_0();
case 670399654: return bem_tokerGetDirect_0();
case -1664617154: return bem_tokerGet_0();
case -1250658162: return bem_nullMarkGetDirect_0();
case 1446040207: return bem_many_0();
case -1755880805: return bem_getClassTagGet_0();
case -1588164708: return bem_saveIdentityGet_0();
case 1350181777: return bem_deserializeClassNameGet_0();
case -315448632: return bem_create_0();
case 1579512018: return bem_print_0();
case 677156823: return bem_hashGet_0();
case -1745697587: return bem_classNameGet_0();
case 887875557: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1374629550: return bem_defineClassTagSet_1(bevd_0);
case 851006420: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1788882700: return bem_undef_1(bevd_0);
case -278341153: return bem_endGroupSetDirect_1(bevd_0);
case -364014749: return bem_getReferenceSet_1(bevd_0);
case 203482140: return bem_undefined_1(bevd_0);
case 208910012: return bem_saveIdentitySetDirect_1(bevd_0);
case -753612009: return bem_encoderSetDirect_1(bevd_0);
case 38767287: return bem_copyTo_1(bevd_0);
case -464192217: return bem_constructStringSet_1(bevd_0);
case 380767619: return bem_nullMarkSetDirect_1(bevd_0);
case -13034625: return bem_defineReferenceSet_1(bevd_0);
case -580813096: return bem_sameType_1(bevd_0);
case -2147152173: return bem_saveIdentitySet_1(bevd_0);
case 2116698291: return bem_deserialize_1(bevd_0);
case 1742242987: return bem_groupSet_1(bevd_0);
case -900172179: return bem_defineReferenceSetDirect_1(bevd_0);
case -1922238298: return bem_encoderSet_1(bevd_0);
case -196899404: return bem_shiftSetDirect_1(bevd_0);
case 1459115432: return bem_defineClassTagSetDirect_1(bevd_0);
case -1693745602: return bem_otherType_1(bevd_0);
case -686665507: return bem_getClassTagSetDirect_1(bevd_0);
case 565121501: return bem_def_1(bevd_0);
case -516066761: return bem_defined_1(bevd_0);
case -35002551: return bem_multiNullMarkSetDirect_1(bevd_0);
case 1894822196: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1474459106: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1701652121: return bem_getReferenceSetDirect_1(bevd_0);
case 761891625: return bem_multiNullMarkSet_1(bevd_0);
case -206065516: return bem_groupSetDirect_1(bevd_0);
case -1910203441: return bem_tokerSetDirect_1(bevd_0);
case 1812369063: return bem_sameClass_1(bevd_0);
case -488936779: return bem_tokerSet_1(bevd_0);
case -2023300100: return bem_sameObject_1(bevd_0);
case -513408185: return bem_otherClass_1(bevd_0);
case 1174377727: return bem_getClassTagSet_1(bevd_0);
case 1541806229: return bem_constructStringSetDirect_1(bevd_0);
case -1259728037: return bem_nullMarkSet_1(bevd_0);
case -1630597488: return bem_notEquals_1(bevd_0);
case -9102334: return bem_serialize_1(bevd_0);
case -999371618: return bem_shiftSet_1(bevd_0);
case 898864569: return bem_endGroupSet_1(bevd_0);
case 603494847: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 130714078: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 619523077: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 984576885: return bem_serializeC_2(bevd_0, bevd_1);
case -432356215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1753294364: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 120855590: return bem_serialize_2(bevd_0, bevd_1);
case -693517224: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 391432487: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 828688575: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 999771019: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case 922535408: return bem_serializeI_2(bevd_0, bevd_1);
case 1676574552: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_x(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) throws Throwable {
switch (callId) {
case 1588125990: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return super.bemd_x(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemSerializer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_10_SystemSerializer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemSerializer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst = (BEC_2_6_10_SystemSerializer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_type;
}
}
