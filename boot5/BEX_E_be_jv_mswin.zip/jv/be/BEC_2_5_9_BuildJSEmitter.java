package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_34, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_38, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_64, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_65, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 17));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 38));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_70, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_71, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_72, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_73, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 23));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_76, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_77, 27));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_78, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_79, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_80, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_81, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_82 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_82, 32));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_83 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_83, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_84 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_84, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_85 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_85, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_86 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_87 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_88 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_89 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_90 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_90, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_91 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_92 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_92, 15));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_93 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_93, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_94 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_94, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_95 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_95, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_96 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_96, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_97 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_97, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_98 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_99 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_100 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_101 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_102 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_103 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_104 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_105 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_106 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_107 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_108 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_109 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_110 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_111 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_111, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_112 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_112, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_113 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_114 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_114, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_115 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_115, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_116 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_116, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_117 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_118 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_119 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_120 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_121 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_121, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_122 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formTarg_1(beva_node);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_invp);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-807998271);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1376377841);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1082441232);
bevt_9_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold );
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(2140571684);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 82 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-347381802);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 82 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(289547506);
if (bevl_first.bevi_bool) /* Line: 83 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 84 */
 else  /* Line: 85 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 86 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 88 */
 else  /* Line: 82 */ {
break;
} /* Line: 82 */
} /* Line: 82 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1082441232);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_17_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_20_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_0_tmpany_phold = beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 133 */
bevt_4_tmpany_phold = super.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 149 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-347381802);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 149 */ {
bevl_clnode = bevl_ci.bemd_0(289547506);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_8_tmpany_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(791274490);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-1082441232);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-542639344);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(791274490);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-1082441232);
bevt_15_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold );
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(791274490);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(2140571684);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-176892552);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(791274490);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-1082441232);
bevt_26_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold );
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_33_tmpany_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(791274490);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(2140571684);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-176892552);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 164 */ {
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_41_tmpany_phold = bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 165 */
} /* Line: 164 */
} /* Line: 155 */
 else  /* Line: 149 */ {
break;
} /* Line: 149 */
} /* Line: 149 */
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 173 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-347381802);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(289547506);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_52_tmpany_phold = bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_67_tmpany_phold = bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 176 */
 else  /* Line: 173 */ {
break;
} /* Line: 173 */
} /* Line: 173 */
bevl_libe.bem_write_1(bevl_smap);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_80_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_82_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_84_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 186 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_89_tmpany_phold = bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_94_tmpany_phold = bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 200 */
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
bevt_98_tmpany_phold = bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(1862831185);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
bevt_104_tmpany_phold = bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_106_tmpany_phold = bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 209 */
bevl_libe.bem_write_1(bevl_main);
bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 215 */ {
bem_saveSyns_0();
} /* Line: 216 */
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
 else  /* Line: 224 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 226 */
bevt_4_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 228 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(879987460);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(879987460);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 259 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 260 */
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 266 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 267 */
 else  /* Line: 268 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_86));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 269 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_87));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_88));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_89));
bevt_8_tmpany_phold = bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(2005931617);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(beva_callArgs);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
beva_callArgs = bevt_4_tmpany_phold.bem_add_1(beva_callArgs);
} /* Line: 287 */
 else  /* Line: 288 */ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_91));
} /* Line: 289 */
bevt_10_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1862831185);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_callArgs);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_5_tmpany_phold;
} /* Line: 291 */
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_20_tmpany_phold = beva_callTarget.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = beva_node.bem_heldGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1862831185);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_callArgs);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_98));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 305 */ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 306 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevt_7_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 325 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(740682944);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_99));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_100));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 330 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-347381802);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(289547506);
bevt_17_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(740682944);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(-2106367388);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(-338991492);
bevt_21_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 335 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 329 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_101));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_102));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_103));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_104));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_105));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_106));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_107));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_108));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_109));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_110));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_113));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_117));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_118));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_119));
bevt_6_tmpany_phold = bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_120));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_122));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public final BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 25, 26, 28, 29, 33, 33, 33, 37, 37, 37, 37, 41, 41, 41, 41, 45, 45, 45, 45, 45, 45, 45, 45, 49, 49, 49, 50, 51, 51, 51, 51, 51, 51, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 64, 64, 64, 64, 64, 64, 64, 68, 68, 68, 68, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 71, 71, 71, 76, 76, 77, 79, 79, 79, 79, 81, 82, 0, 82, 82, 84, 86, 86, 88, 88, 88, 88, 88, 88, 92, 92, 92, 97, 97, 97, 98, 100, 100, 100, 100, 100, 103, 103, 103, 103, 105, 105, 105, 107, 107, 107, 107, 107, 110, 110, 110, 110, 110, 110, 112, 112, 112, 114, 119, 120, 121, 127, 127, 127, 132, 133, 133, 133, 133, 135, 135, 144, 146, 147, 148, 149, 149, 151, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 155, 155, 155, 157, 157, 157, 157, 157, 157, 157, 157, 157, 163, 163, 163, 163, 163, 163, 164, 164, 164, 165, 165, 165, 165, 165, 165, 171, 173, 173, 0, 173, 173, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 180, 183, 183, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 189, 190, 193, 194, 194, 195, 197, 198, 198, 198, 198, 198, 198, 198, 199, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 202, 203, 204, 205, 206, 207, 208, 208, 208, 209, 209, 209, 211, 213, 215, 216, 222, 225, 225, 225, 226, 226, 228, 228, 233, 233, 237, 237, 237, 237, 237, 237, 241, 241, 245, 245, 245, 245, 245, 245, 245, 246, 246, 246, 246, 246, 247, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 266, 266, 267, 267, 267, 269, 269, 271, 271, 271, 271, 271, 279, 279, 279, 280, 281, 285, 285, 286, 286, 287, 287, 289, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 293, 293, 293, 293, 293, 293, 293, 293, 293, 293, 293, 297, 298, 305, 305, 306, 308, 309, 309, 314, 314, 322, 322, 323, 324, 324, 324, 324, 324, 325, 325, 325, 327, 327, 327, 329, 329, 329, 330, 330, 330, 330, 0, 330, 330, 331, 331, 332, 332, 332, 333, 333, 334, 334, 335, 341, 345, 346, 351, 351, 355, 355, 359, 359, 363, 363, 367, 367, 371, 371, 375, 375, 380, 380, 386, 386, 391, 391, 395, 395, 395, 395, 395, 395, 399, 399, 403, 403, 403, 403, 403, 408, 408, 408, 408, 408, 408, 408, 413, 413, 413, 413, 413, 413, 413, 415, 417, 417, 417, 422, 422, 426, 426, 430, 430, 430, 430, 435, 435, 439, 440, 440, 441, 445, 446, 446, 447, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {180, 181, 182, 183, 184, 185, 186, 187, 193, 194, 195, 201, 202, 203, 204, 210, 211, 212, 213, 223, 224, 225, 226, 227, 228, 229, 230, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 283, 284, 285, 286, 287, 288, 289, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 349, 350, 351, 352, 353, 354, 355, 356, 357, 357, 360, 362, 364, 367, 368, 370, 371, 372, 373, 374, 375, 381, 382, 383, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 446, 447, 448, 454, 455, 456, 465, 467, 468, 469, 470, 472, 473, 600, 601, 602, 603, 604, 607, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 652, 653, 654, 655, 656, 657, 665, 666, 667, 667, 670, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 710, 711, 712, 713, 714, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 746, 747, 748, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 764, 765, 766, 767, 768, 769, 771, 772, 773, 775, 785, 789, 790, 795, 796, 797, 799, 800, 806, 807, 815, 816, 817, 818, 819, 820, 824, 825, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 986, 991, 992, 993, 994, 997, 998, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1038, 1039, 1041, 1042, 1044, 1045, 1048, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1077, 1078, 1083, 1088, 1089, 1091, 1092, 1093, 1097, 1098, 1129, 1134, 1135, 1136, 1137, 1138, 1139, 1144, 1145, 1146, 1147, 1149, 1150, 1151, 1152, 1153, 1154, 1156, 1157, 1158, 1159, 1159, 1162, 1164, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173, 1174, 1182, 1185, 1186, 1191, 1192, 1196, 1197, 1201, 1202, 1206, 1207, 1211, 1212, 1216, 1217, 1221, 1222, 1226, 1227, 1231, 1232, 1236, 1237, 1245, 1246, 1247, 1248, 1249, 1250, 1254, 1255, 1262, 1263, 1264, 1265, 1266, 1275, 1276, 1277, 1278, 1279, 1280, 1281, 1292, 1293, 1294, 1295, 1296, 1297, 1298, 1299, 1300, 1301, 1302, 1307, 1308, 1312, 1313, 1319, 1320, 1321, 1322, 1326, 1327, 1332, 1333, 1334, 1335, 1340, 1341, 1342, 1343, 1346, 1349, 1352, 1356, 1360, 1363, 1366, 1370};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 180
new 0 17 180
assign 1 18 181
new 0 18 181
assign 1 19 182
new 0 19 182
new 1 23 183
assign 1 25 184
new 0 25 184
assign 1 26 185
new 0 26 185
assign 1 28 186
new 0 28 186
assign 1 29 187
new 0 29 187
assign 1 33 193
formTarg 1 33 193
assign 1 33 194
add 1 33 194
return 1 33 195
assign 1 37 201
formCallTarg 1 37 201
assign 1 37 202
new 0 37 202
assign 1 37 203
add 1 37 203
return 1 37 204
assign 1 41 210
formCallTarg 1 41 210
assign 1 41 211
new 0 41 211
assign 1 41 212
add 1 41 212
return 1 41 213
assign 1 45 223
new 0 45 223
assign 1 45 224
addValue 1 45 224
assign 1 45 225
secondGet 0 45 225
assign 1 45 226
formTarg 1 45 226
assign 1 45 227
addValue 1 45 227
assign 1 45 228
new 0 45 228
assign 1 45 229
addValue 1 45 229
addValue 1 45 230
assign 1 49 251
new 0 49 251
assign 1 49 252
toString 0 49 252
assign 1 49 253
add 1 49 253
incrementValue 0 50 254
assign 1 51 255
new 0 51 255
assign 1 51 256
addValue 1 51 256
assign 1 51 257
addValue 1 51 257
assign 1 51 258
new 0 51 258
assign 1 51 259
addValue 1 51 259
addValue 1 51 260
assign 1 56 261
containedGet 0 56 261
assign 1 56 262
firstGet 0 56 262
assign 1 56 263
containedGet 0 56 263
assign 1 56 264
firstGet 0 56 264
assign 1 56 265
new 0 56 265
assign 1 56 266
add 1 56 266
assign 1 56 267
new 0 56 267
assign 1 56 268
add 1 56 268
assign 1 56 269
finalAssign 4 56 269
addValue 1 56 270
assign 1 64 283
emitNameGet 0 64 283
assign 1 64 284
addValue 1 64 284
assign 1 64 285
new 0 64 285
assign 1 64 286
addValue 1 64 286
assign 1 64 287
addValue 1 64 287
assign 1 64 288
new 0 64 288
addValue 1 64 289
assign 1 68 309
emitNameGet 0 68 309
assign 1 68 310
addValue 1 68 310
assign 1 68 311
new 0 68 311
assign 1 68 312
addValue 1 68 312
addValue 1 68 313
assign 1 69 314
new 0 69 314
assign 1 69 315
addValue 1 69 315
assign 1 69 316
heldGet 0 69 316
assign 1 69 317
namepathGet 0 69 317
assign 1 69 318
getClassConfig 1 69 318
assign 1 69 319
libNameGet 0 69 319
assign 1 69 320
relEmitName 1 69 320
assign 1 69 321
addValue 1 69 321
assign 1 69 322
new 0 69 322
assign 1 69 323
addValue 1 69 323
addValue 1 69 324
assign 1 71 325
new 0 71 325
assign 1 71 326
addValue 1 71 326
addValue 1 71 327
assign 1 76 349
heldGet 0 76 349
assign 1 76 350
synGet 0 76 350
assign 1 77 351
ptyListGet 0 77 351
assign 1 79 352
emitNameGet 0 79 352
assign 1 79 353
addValue 1 79 353
assign 1 79 354
new 0 79 354
addValue 1 79 355
assign 1 81 356
new 0 81 356
assign 1 82 357
iteratorGet 0 0 357
assign 1 82 360
hasNextGet 0 82 360
assign 1 82 362
nextGet 0 82 362
assign 1 84 364
new 0 84 364
assign 1 86 367
new 0 86 367
addValue 1 86 368
assign 1 88 370
addValue 1 88 370
assign 1 88 371
new 0 88 371
assign 1 88 372
addValue 1 88 372
assign 1 88 373
nameGet 0 88 373
assign 1 88 374
addValue 1 88 374
addValue 1 88 375
assign 1 92 381
new 0 92 381
assign 1 92 382
addValue 1 92 382
addValue 1 92 383
assign 1 97 411
heldGet 0 97 411
assign 1 97 412
namepathGet 0 97 412
assign 1 97 413
getClassConfig 1 97 413
assign 1 98 414
getInitialInst 1 98 414
assign 1 100 415
emitNameGet 0 100 415
assign 1 100 416
addValue 1 100 416
assign 1 100 417
new 0 100 417
assign 1 100 418
addValue 1 100 418
addValue 1 100 419
assign 1 103 420
addValue 1 103 420
assign 1 103 421
new 0 103 421
assign 1 103 422
addValue 1 103 422
addValue 1 103 423
assign 1 105 424
new 0 105 424
assign 1 105 425
addValue 1 105 425
addValue 1 105 426
assign 1 107 427
emitNameGet 0 107 427
assign 1 107 428
addValue 1 107 428
assign 1 107 429
new 0 107 429
assign 1 107 430
addValue 1 107 430
addValue 1 107 431
assign 1 110 432
new 0 110 432
assign 1 110 433
addValue 1 110 433
assign 1 110 434
addValue 1 110 434
assign 1 110 435
new 0 110 435
assign 1 110 436
addValue 1 110 436
addValue 1 110 437
assign 1 112 438
new 0 112 438
assign 1 112 439
addValue 1 112 439
addValue 1 112 440
buildPropList 0 114 441
getCode 2 119 446
assign 1 120 447
toString 0 120 447
addValue 1 121 448
assign 1 127 454
new 0 127 454
assign 1 127 455
addValue 1 127 455
addValue 1 127 456
assign 1 132 465
isPropertyGet 0 132 465
assign 1 133 467
new 0 133 467
assign 1 133 468
nameGet 0 133 468
assign 1 133 469
add 1 133 469
return 1 133 470
assign 1 135 472
nameForVar 1 135 472
return 1 135 473
assign 1 144 600
getLibOutput 0 144 600
assign 1 146 601
new 0 146 601
assign 1 147 602
new 0 147 602
assign 1 148 603
new 0 148 603
assign 1 149 604
iteratorGet 0 149 604
assign 1 149 607
hasNextGet 0 149 607
assign 1 151 609
nextGet 0 151 609
assign 1 153 610
new 0 153 610
assign 1 153 611
addValue 1 153 611
assign 1 153 612
addValue 1 153 612
assign 1 153 613
heldGet 0 153 613
assign 1 153 614
namepathGet 0 153 614
assign 1 153 615
toString 0 153 615
assign 1 153 616
addValue 1 153 616
assign 1 153 617
addValue 1 153 617
assign 1 153 618
new 0 153 618
assign 1 153 619
addValue 1 153 619
assign 1 153 620
heldGet 0 153 620
assign 1 153 621
namepathGet 0 153 621
assign 1 153 622
getClassConfig 1 153 622
assign 1 153 623
libNameGet 0 153 623
assign 1 153 624
relEmitName 1 153 624
assign 1 153 625
addValue 1 153 625
assign 1 153 626
new 0 153 626
assign 1 153 627
addValue 1 153 627
addValue 1 153 628
assign 1 155 629
heldGet 0 155 629
assign 1 155 630
synGet 0 155 630
assign 1 155 631
hasDefaultGet 0 155 631
assign 1 157 633
new 0 157 633
assign 1 157 634
heldGet 0 157 634
assign 1 157 635
namepathGet 0 157 635
assign 1 157 636
getClassConfig 1 157 636
assign 1 157 637
libNameGet 0 157 637
assign 1 157 638
relEmitName 1 157 638
assign 1 157 639
add 1 157 639
assign 1 157 640
new 0 157 640
assign 1 157 641
add 1 157 641
assign 1 163 642
new 0 163 642
assign 1 163 643
addValue 1 163 643
assign 1 163 644
addValue 1 163 644
assign 1 163 645
new 0 163 645
assign 1 163 646
addValue 1 163 646
addValue 1 163 647
assign 1 164 648
heldGet 0 164 648
assign 1 164 649
synGet 0 164 649
assign 1 164 650
hasDefaultGet 0 164 650
assign 1 165 652
new 0 165 652
assign 1 165 653
addValue 1 165 653
assign 1 165 654
addValue 1 165 654
assign 1 165 655
new 0 165 655
assign 1 165 656
addValue 1 165 656
addValue 1 165 657
assign 1 171 665
new 0 171 665
assign 1 173 666
keysGet 0 173 666
assign 1 173 667
iteratorGet 0 0 667
assign 1 173 670
hasNextGet 0 173 670
assign 1 173 672
nextGet 0 173 672
assign 1 175 673
new 0 175 673
assign 1 175 674
addValue 1 175 674
assign 1 175 675
new 0 175 675
assign 1 175 676
quoteGet 0 175 676
assign 1 175 677
addValue 1 175 677
assign 1 175 678
addValue 1 175 678
assign 1 175 679
new 0 175 679
assign 1 175 680
quoteGet 0 175 680
assign 1 175 681
addValue 1 175 681
assign 1 175 682
new 0 175 682
assign 1 175 683
addValue 1 175 683
assign 1 175 684
get 1 175 684
assign 1 175 685
addValue 1 175 685
assign 1 175 686
new 0 175 686
assign 1 175 687
addValue 1 175 687
addValue 1 175 688
assign 1 176 689
new 0 176 689
assign 1 176 690
addValue 1 176 690
assign 1 176 691
new 0 176 691
assign 1 176 692
quoteGet 0 176 692
assign 1 176 693
addValue 1 176 693
assign 1 176 694
addValue 1 176 694
assign 1 176 695
new 0 176 695
assign 1 176 696
quoteGet 0 176 696
assign 1 176 697
addValue 1 176 697
assign 1 176 698
new 0 176 698
assign 1 176 699
addValue 1 176 699
assign 1 176 700
get 1 176 700
assign 1 176 701
addValue 1 176 701
assign 1 176 702
new 0 176 702
assign 1 176 703
addValue 1 176 703
addValue 1 176 704
write 1 180 710
assign 1 183 711
usedLibrarysGet 0 183 711
assign 1 183 712
sizeGet 0 183 712
assign 1 183 713
new 0 183 713
assign 1 183 714
equals 1 183 719
assign 1 184 720
new 0 184 720
assign 1 184 721
addValue 1 184 721
addValue 1 184 722
assign 1 185 723
new 0 185 723
assign 1 185 724
addValue 1 185 724
addValue 1 185 725
assign 1 186 726
new 0 186 726
assign 1 186 727
addValue 1 186 727
addValue 1 186 728
write 1 189 730
write 1 190 731
assign 1 193 732
new 0 193 732
assign 1 194 733
mainNameGet 0 194 733
fromString 1 194 734
assign 1 195 735
getClassConfig 1 195 735
assign 1 197 736
new 0 197 736
assign 1 198 737
new 0 198 737
assign 1 198 738
addValue 1 198 738
assign 1 198 739
fullEmitNameGet 0 198 739
assign 1 198 740
addValue 1 198 740
assign 1 198 741
new 0 198 741
assign 1 198 742
addValue 1 198 742
addValue 1 198 743
assign 1 199 744
ownProcessGet 0 199 744
assign 1 200 746
new 0 200 746
assign 1 200 747
addValue 1 200 747
addValue 1 200 748
assign 1 202 750
new 0 202 750
assign 1 202 751
addValue 1 202 751
assign 1 202 752
outputPlatformGet 0 202 752
assign 1 202 753
nameGet 0 202 753
assign 1 202 754
addValue 1 202 754
assign 1 202 755
new 0 202 755
assign 1 202 756
addValue 1 202 756
addValue 1 202 757
write 1 203 758
assign 1 204 759
new 0 204 759
write 1 205 760
write 1 206 761
assign 1 207 762
ownProcessGet 0 207 762
assign 1 208 764
new 0 208 764
assign 1 208 765
addValue 1 208 765
addValue 1 208 766
assign 1 209 767
new 0 209 767
assign 1 209 768
addValue 1 209 768
addValue 1 209 769
write 1 211 771
finishLibOutput 1 213 772
assign 1 215 773
saveSynsGet 0 215 773
saveSyns 0 216 775
assign 1 222 785
isPropertyGet 0 222 785
assign 1 225 789
isArgGet 0 225 789
assign 1 225 790
not 0 225 795
assign 1 226 796
new 0 226 796
addValue 1 226 797
assign 1 228 799
nameForVar 1 228 799
addValue 1 228 800
assign 1 233 806
new 0 233 806
return 1 233 807
assign 1 237 815
new 0 237 815
assign 1 237 816
add 1 237 816
assign 1 237 817
new 0 237 817
assign 1 237 818
add 1 237 818
assign 1 237 819
add 1 237 819
return 1 237 820
assign 1 241 824
new 0 241 824
return 1 241 825
assign 1 245 839
emitNameGet 0 245 839
assign 1 245 840
new 0 245 840
assign 1 245 841
add 1 245 841
assign 1 245 842
add 1 245 842
assign 1 245 843
new 0 245 843
assign 1 245 844
add 1 245 844
assign 1 245 845
addValue 1 245 845
assign 1 246 846
emitNameGet 0 246 846
assign 1 246 847
add 1 246 847
assign 1 246 848
new 0 246 848
assign 1 246 849
add 1 246 849
assign 1 246 850
addValue 1 246 850
return 1 247 851
assign 1 251 865
new 0 251 865
assign 1 251 866
libNameGet 0 251 866
assign 1 251 867
relEmitName 1 251 867
assign 1 251 868
add 1 251 868
assign 1 251 869
new 0 251 869
assign 1 251 870
add 1 251 870
assign 1 251 871
heldGet 0 251 871
assign 1 251 872
literalValueGet 0 251 872
assign 1 251 873
add 1 251 873
assign 1 251 874
new 0 251 874
assign 1 251 875
add 1 251 875
return 1 251 876
assign 1 255 890
new 0 255 890
assign 1 255 891
libNameGet 0 255 891
assign 1 255 892
relEmitName 1 255 892
assign 1 255 893
add 1 255 893
assign 1 255 894
new 0 255 894
assign 1 255 895
add 1 255 895
assign 1 255 896
heldGet 0 255 896
assign 1 255 897
literalValueGet 0 255 897
assign 1 255 898
add 1 255 898
assign 1 255 899
new 0 255 899
assign 1 255 900
add 1 255 900
return 1 255 901
assign 1 260 937
new 0 260 937
assign 1 260 938
libNameGet 0 260 938
assign 1 260 939
relEmitName 1 260 939
assign 1 260 940
add 1 260 940
assign 1 260 941
new 0 260 941
assign 1 260 942
add 1 260 942
assign 1 260 943
emitNameGet 0 260 943
assign 1 260 944
add 1 260 944
assign 1 260 945
new 0 260 945
assign 1 260 946
add 1 260 946
assign 1 260 947
add 1 260 947
assign 1 260 948
new 0 260 948
assign 1 260 949
add 1 260 949
assign 1 260 950
add 1 260 950
assign 1 260 951
new 0 260 951
assign 1 260 952
add 1 260 952
return 1 260 953
assign 1 262 955
new 0 262 955
assign 1 262 956
libNameGet 0 262 956
assign 1 262 957
relEmitName 1 262 957
assign 1 262 958
add 1 262 958
assign 1 262 959
new 0 262 959
assign 1 262 960
add 1 262 960
assign 1 262 961
emitNameGet 0 262 961
assign 1 262 962
add 1 262 962
assign 1 262 963
new 0 262 963
assign 1 262 964
add 1 262 964
assign 1 262 965
add 1 262 965
assign 1 262 966
new 0 262 966
assign 1 262 967
add 1 262 967
assign 1 262 968
add 1 262 968
assign 1 262 969
new 0 262 969
assign 1 262 970
add 1 262 970
return 1 262 971
assign 1 266 986
def 1 266 991
assign 1 267 992
libNameGet 0 267 992
assign 1 267 993
relEmitName 1 267 993
assign 1 267 994
extend 1 267 994
assign 1 269 997
new 0 269 997
assign 1 269 998
extend 1 269 998
assign 1 271 1000
new 0 271 1000
assign 1 271 1001
emitNameGet 0 271 1001
assign 1 271 1002
addValue 1 271 1002
assign 1 271 1003
new 0 271 1003
assign 1 271 1004
addValue 1 271 1004
assign 1 279 1005
new 0 279 1005
assign 1 279 1006
addValue 1 279 1006
addValue 1 279 1007
addValue 1 280 1008
return 1 281 1009
assign 1 285 1038
heldGet 0 285 1038
assign 1 285 1039
superCallGet 0 285 1039
assign 1 286 1041
new 0 286 1041
assign 1 286 1042
notEmpty 1 286 1042
assign 1 287 1044
new 0 287 1044
assign 1 287 1045
add 1 287 1045
assign 1 289 1048
new 0 289 1048
assign 1 291 1050
emitNameGet 0 291 1050
assign 1 291 1051
new 0 291 1051
assign 1 291 1052
add 1 291 1052
assign 1 291 1053
heldGet 0 291 1053
assign 1 291 1054
nameGet 0 291 1054
assign 1 291 1055
add 1 291 1055
assign 1 291 1056
new 0 291 1056
assign 1 291 1057
add 1 291 1057
assign 1 291 1058
add 1 291 1058
assign 1 291 1059
new 0 291 1059
assign 1 291 1060
add 1 291 1060
return 1 291 1061
assign 1 293 1063
new 0 293 1063
assign 1 293 1064
add 1 293 1064
assign 1 293 1065
heldGet 0 293 1065
assign 1 293 1066
nameGet 0 293 1066
assign 1 293 1067
add 1 293 1067
assign 1 293 1068
new 0 293 1068
assign 1 293 1069
add 1 293 1069
assign 1 293 1070
add 1 293 1070
assign 1 293 1071
new 0 293 1071
assign 1 293 1072
add 1 293 1072
return 1 293 1073
assign 1 297 1077
new 0 297 1077
return 1 298 1078
assign 1 305 1083
undef 1 305 1088
assign 1 306 1089
new 0 306 1089
addValue 1 308 1091
assign 1 309 1092
new 0 309 1092
return 1 309 1093
assign 1 314 1097
getLibOutput 0 314 1097
return 1 314 1098
assign 1 322 1129
undef 1 322 1134
assign 1 323 1135
new 0 323 1135
assign 1 324 1136
parentGet 0 324 1136
assign 1 324 1137
fileGet 0 324 1137
assign 1 324 1138
existsGet 0 324 1138
assign 1 324 1139
not 0 324 1144
assign 1 325 1145
parentGet 0 325 1145
assign 1 325 1146
fileGet 0 325 1146
makeDirs 0 325 1147
assign 1 327 1149
fileGet 0 327 1149
assign 1 327 1150
writerGet 0 327 1150
assign 1 327 1151
open 0 327 1151
assign 1 329 1152
paramsGet 0 329 1152
assign 1 329 1153
new 0 329 1153
assign 1 329 1154
has 1 329 1154
assign 1 330 1156
paramsGet 0 330 1156
assign 1 330 1157
new 0 330 1157
assign 1 330 1158
get 1 330 1158
assign 1 330 1159
iteratorGet 0 0 1159
assign 1 330 1162
hasNextGet 0 330 1162
assign 1 330 1164
nextGet 0 330 1164
assign 1 331 1165
apNew 1 331 1165
assign 1 331 1166
fileGet 0 331 1166
assign 1 332 1167
readerGet 0 332 1167
assign 1 332 1168
open 0 332 1168
assign 1 332 1169
readString 0 332 1169
assign 1 333 1170
readerGet 0 333 1170
close 0 333 1171
assign 1 334 1172
countLines 1 334 1172
addValue 1 334 1173
write 1 335 1174
return 1 341 1182
close 0 345 1185
assign 1 346 1186
assign 1 351 1191
new 0 351 1191
return 1 351 1192
assign 1 355 1196
new 0 355 1196
return 1 355 1197
assign 1 359 1201
new 0 359 1201
return 1 359 1202
assign 1 363 1206
new 0 363 1206
return 1 363 1207
assign 1 367 1211
new 0 367 1211
return 1 367 1212
assign 1 371 1216
new 0 371 1216
return 1 371 1217
assign 1 375 1221
new 0 375 1221
return 1 375 1222
assign 1 380 1226
new 0 380 1226
return 1 380 1227
assign 1 386 1231
new 0 386 1231
return 1 386 1232
assign 1 391 1236
new 0 391 1236
return 1 391 1237
assign 1 395 1245
new 0 395 1245
assign 1 395 1246
add 1 395 1246
assign 1 395 1247
new 0 395 1247
assign 1 395 1248
add 1 395 1248
assign 1 395 1249
add 1 395 1249
return 1 395 1250
assign 1 399 1254
new 0 399 1254
return 1 399 1255
assign 1 403 1262
libNameGet 0 403 1262
assign 1 403 1263
relEmitName 1 403 1263
assign 1 403 1264
new 0 403 1264
assign 1 403 1265
add 1 403 1265
return 1 403 1266
assign 1 408 1275
emitNameGet 0 408 1275
assign 1 408 1276
new 0 408 1276
assign 1 408 1277
add 1 408 1277
assign 1 408 1278
new 0 408 1278
assign 1 408 1279
add 1 408 1279
assign 1 408 1280
add 1 408 1280
return 1 408 1281
assign 1 413 1292
emitNameGet 0 413 1292
assign 1 413 1293
addValue 1 413 1293
assign 1 413 1294
new 0 413 1294
assign 1 413 1295
addValue 1 413 1295
assign 1 413 1296
addValue 1 413 1296
assign 1 413 1297
new 0 413 1297
addValue 1 413 1298
addValue 1 415 1299
assign 1 417 1300
new 0 417 1300
assign 1 417 1301
addValue 1 417 1301
addValue 1 417 1302
assign 1 422 1307
new 0 422 1307
return 1 422 1308
assign 1 426 1312
new 0 426 1312
return 1 426 1313
assign 1 430 1319
new 0 430 1319
assign 1 430 1320
add 1 430 1320
assign 1 430 1321
add 1 430 1321
return 1 430 1322
assign 1 435 1326
new 0 435 1326
return 1 435 1327
assign 1 439 1332
getClassConfig 1 439 1332
assign 1 440 1333
fullEmitNameGet 0 440 1333
emitNameSet 1 440 1334
return 1 441 1335
assign 1 445 1340
getLocalClassConfig 1 445 1340
assign 1 446 1341
fullEmitNameGet 0 446 1341
emitNameSet 1 446 1342
return 1 447 1343
return 1 0 1346
return 1 0 1349
assign 1 0 1352
assign 1 0 1356
return 1 0 1360
return 1 0 1363
assign 1 0 1366
assign 1 0 1370
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1443171653: return bem_preClassGet_0();
case -1906660880: return bem_print_0();
case 1392195011: return bem_synEmitPathGetDirect_0();
case -1708115567: return bem_propDecGet_0();
case 1379664484: return bem_toAny_0();
case -821329169: return bem_csynGet_0();
case -803195768: return bem_nlGetDirect_0();
case 562477328: return bem_serializationIteratorGet_0();
case 570507147: return bem_onceDecsGet_0();
case 469271929: return bem_constGetDirect_0();
case 1916381036: return bem_lastMethodBodyLinesGetDirect_0();
case 2104154069: return bem_lastMethodBodySizeGetDirect_0();
case -390720548: return bem_smnlecsGet_0();
case 1835099422: return bem_beginNs_0();
case -21012660: return bem_sourceFileNameGet_0();
case -320366142: return bem_lastCallGetDirect_0();
case 2096149371: return bem_maxDynArgsGetDirect_0();
case 2142160911: return bem_randGetDirect_0();
case -1067099981: return bem_fieldNamesGet_0();
case 1807716944: return bem_nameToIdPathGet_0();
case 1362565490: return bem_initialDecGet_0();
case -855206853: return bem_onceDecsGetDirect_0();
case 837030097: return bem_fileExtGetDirect_0();
case 1973351004: return bem_scvpGet_0();
case 886168102: return bem_many_0();
case -1370019545: return bem_serializeToString_0();
case -1806720305: return bem_classCallsGet_0();
case 1688744619: return bem_serializeContents_0();
case -2038635260: return bem_gcMarksGetDirect_0();
case -1527809673: return bem_nameToIdGetDirect_0();
case -1515347213: return bem_hashGet_0();
case 723041666: return bem_saveSyns_0();
case 1446806725: return bem_objectNpGet_0();
case -1762492069: return bem_nativeCSlotsGet_0();
case -496735965: return bem_buildGetDirect_0();
case -167709088: return bem_synEmitPathGet_0();
case -185155337: return bem_getLibOutput_0();
case 204985166: return bem_classCallsGetDirect_0();
case -406991314: return bem_stringNpGetDirect_0();
case 494321581: return bem_falseValueGet_0();
case -1151001056: return bem_maxSpillArgsLenGet_0();
case -793743234: return bem_idToNamePathGet_0();
case -837773632: return bem_instOfGetDirect_0();
case -1009685364: return bem_transGet_0();
case 620785365: return bem_doEmit_0();
case 356764047: return bem_shlibeGetDirect_0();
case 789267316: return bem_lastMethodsLinesGetDirect_0();
case 896371622: return bem_nlGet_0();
case 1478814730: return bem_smnlecsGetDirect_0();
case 1615988720: return bem_instanceEqualGetDirect_0();
case -1306253059: return bem_exceptDecGetDirect_0();
case -1648627766: return bem_echo_0();
case 783522245: return bem_fullLibEmitNameGetDirect_0();
case 2051860039: return bem_intNpGetDirect_0();
case 1458644700: return bem_intNpGet_0();
case -226412831: return bem_newDecGet_0();
case 1744792791: return bem_ntypesGet_0();
case -924256228: return bem_onceCountGetDirect_0();
case -128774690: return bem_classEmitsGet_0();
case -321153833: return bem_lastMethodBodyLinesGet_0();
case -1089543621: return bem_allOnceDecsGet_0();
case 53708840: return bem_spropDecGet_0();
case -22623853: return bem_loadIds_0();
case -537424112: return bem_inFilePathedGet_0();
case -882299980: return bem_maxSpillArgsLenGetDirect_0();
case -2140286517: return bem_cnodeGetDirect_0();
case 252724935: return bem_callNamesGetDirect_0();
case 1423288377: return bem_methodCallsGet_0();
case 511515045: return bem_emitLib_0();
case 1052521806: return bem_nameToIdGet_0();
case 419628296: return bem_superCallsGetDirect_0();
case 1392061068: return bem_smnlcsGet_0();
case -1946706591: return bem_buildInitial_0();
case 937542636: return bem_emitLangGet_0();
case -1089451271: return bem_emitLangGetDirect_0();
case 1295407275: return bem_methodsGetDirect_0();
case 507602572: return bem_once_0();
case 414174203: return bem_boolTypeGet_0();
case 631342118: return bem_deserializeClassNameGet_0();
case -1518339110: return bem_buildCreate_0();
case -1998451160: return bem_objectCcGetDirect_0();
case -1302818025: return bem_invpGetDirect_0();
case 1977859925: return bem_instOfGet_0();
case -825603434: return bem_maxDynArgsGet_0();
case 1658918232: return bem_trueValueGet_0();
case 277743302: return bem_constGet_0();
case -30480969: return bem_ccMethodsGetDirect_0();
case -109162433: return bem_libEmitPathGetDirect_0();
case 1019449933: return bem_methodBodyGet_0();
case -819759244: return bem_propertyDecsGetDirect_0();
case -343380417: return bem_lastMethodsSizeGet_0();
case -66333192: return bem_methodBodyGetDirect_0();
case 412837307: return bem_inClassGet_0();
case -1662434944: return bem_smnlcsGetDirect_0();
case -1454863227: return bem_dynMethodsGet_0();
case -973290132: return bem_iteratorGet_0();
case 1258032826: return bem_libEmitNameGet_0();
case 2011291806: return bem_onceCountGet_0();
case 923180241: return bem_scvpGetDirect_0();
case -2054053072: return bem_lineCountGet_0();
case -1290832817: return bem_csynGetDirect_0();
case -701195797: return bem_mainStartGet_0();
case 1350384101: return bem_inClassGetDirect_0();
case -1978789210: return bem_baseMtdDecGet_0();
case -862155694: return bem_copy_0();
case 846145801: return bem_overrideMtdDecGet_0();
case -943629304: return bem_methodCatchGet_0();
case 645390382: return bem_shlibeGet_0();
case 1742256079: return bem_typeDecGet_0();
case -53239861: return bem_classesInDepthOrderGetDirect_0();
case 1127780777: return bem_qGet_0();
case 1473424345: return bem_boolNpGetDirect_0();
case -242313118: return bem_nameToIdPathGetDirect_0();
case 318852452: return bem_instanceNotEqualGet_0();
case 899271096: return bem_new_0();
case 1813520847: return bem_parentConfGet_0();
case -1796662778: return bem_invpGet_0();
case -1063710289: return bem_floatNpGet_0();
case -1134262955: return bem_ntypesGetDirect_0();
case -1624348710: return bem_baseSmtdDecGet_0();
case -1419469973: return bem_mnodeGetDirect_0();
case -1942547573: return bem_falseValueGetDirect_0();
case 318493500: return bem_classEndGet_0();
case -1885441842: return bem_returnTypeGetDirect_0();
case 338341900: return bem_dynMethodsGetDirect_0();
case -362592061: return bem_libEmitPathGet_0();
case -571767415: return bem_instanceEqualGet_0();
case 1543222000: return bem_ccMethodsGet_0();
case 1573725065: return bem_superNameGet_0();
case -1149022510: return bem_classesInDepthOrderGet_0();
case 634550415: return bem_returnTypeGet_0();
case -369872861: return bem_cnodeGet_0();
case 400190: return bem_classConfGetDirect_0();
case 1754471485: return bem_parentConfGetDirect_0();
case -174652207: return bem_buildPropList_0();
case -401670014: return bem_msynGet_0();
case 1884909798: return bem_create_0();
case -1607794473: return bem_instanceNotEqualGetDirect_0();
case 498893520: return bem_mainOutsideNsGet_0();
case 681664280: return bem_covariantReturnsGet_0();
case -425759353: return bem_randGet_0();
case -528325655: return bem_idToNamePathGetDirect_0();
case 1121058193: return bem_lineCountGetDirect_0();
case 559429320: return bem_objectCcGet_0();
case -542639344: return bem_toString_0();
case 940243946: return bem_preClassGetDirect_0();
case 1248524827: return bem_propertyDecsGet_0();
case 128226289: return bem_lastMethodBodySizeGet_0();
case -436934342: return bem_objectNpGetDirect_0();
case 1366667781: return bem_buildClassInfo_0();
case 742497361: return bem_stringNpGet_0();
case -2123913770: return bem_afterCast_0();
case -825450620: return bem_superCallsGet_0();
case 1675313987: return bem_msynGetDirect_0();
case -647428547: return bem_fieldIteratorGet_0();
case 1140405502: return bem_nullValueGetDirect_0();
case -466248999: return bem_methodCallsGetDirect_0();
case 1917357536: return bem_nullValueGet_0();
case -1712033076: return bem_lastMethodsSizeGetDirect_0();
case 1308293212: return bem_methodsGet_0();
case 109703261: return bem_getClassOutput_0();
case 969168863: return bem_boolNpGet_0();
case -375470541: return bem_qGetDirect_0();
case 793325997: return bem_classEmitsGetDirect_0();
case 110440161: return bem_lastCallGet_0();
case -1814630541: return bem_classNameGet_0();
case -458380580: return bem_allOnceDecsGetDirect_0();
case 998632063: return bem_boolCcGet_0();
case -2125443620: return bem_mnodeGet_0();
case -499006015: return bem_fileExtGet_0();
case 1523449359: return bem_endNs_0();
case -688295882: return bem_tagGet_0();
case -1630442340: return bem_ccCacheGet_0();
case -2106889407: return bem_saveIds_0();
case -962860715: return bem_idToNameGetDirect_0();
case -602773685: return bem_classConfGet_0();
case -1836714306: return bem_writeBET_0();
case 2063651617: return bem_ccCacheGetDirect_0();
case 1452185181: return bem_gcMarksGet_0();
case -1048148168: return bem_nativeCSlotsGetDirect_0();
case -1445319454: return bem_mainEndGet_0();
case 202699109: return bem_fullLibEmitNameGet_0();
case 1884026183: return bem_trueValueGetDirect_0();
case 1986864933: return bem_libEmitNameGetDirect_0();
case 1775869478: return bem_preClassOutput_0();
case -1483790496: return bem_buildGet_0();
case 1118273880: return bem_transGetDirect_0();
case -1254147796: return bem_floatNpGetDirect_0();
case 1716052169: return bem_boolCcGetDirect_0();
case 1256803798: return bem_callNamesGet_0();
case 395134262: return bem_useDynMethodsGet_0();
case 1043437210: return bem_runtimeInitGet_0();
case 1838318274: return bem_methodCatchGetDirect_0();
case 1525536589: return bem_idToNameGet_0();
case -174666604: return bem_exceptDecGet_0();
case 1506771722: return bem_lastMethodsLinesGet_0();
case -1865849734: return bem_mainInClassGet_0();
case 1785961098: return bem_inFilePathedGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 158039900: return bem_emitLangSet_1(bevd_0);
case 1464836841: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 8346468: return bem_invpSetDirect_1(bevd_0);
case -378266735: return bem_allOnceDecsSetDirect_1(bevd_0);
case -924706757: return bem_ccCacheSetDirect_1(bevd_0);
case -655473575: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -149419345: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 216018244: return bem_copyTo_1(bevd_0);
case 1132677367: return bem_gcMarksSet_1(bevd_0);
case 1919792762: return bem_callNamesSet_1(bevd_0);
case 1744178869: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -646172106: return bem_allOnceDecsSet_1(bevd_0);
case 1402754792: return bem_def_1(bevd_0);
case 1992134721: return bem_idToNamePathSet_1(bevd_0);
case 1027073096: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1673386798: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1112863556: return bem_end_1(bevd_0);
case -241199401: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1987747467: return bem_qSet_1(bevd_0);
case 2082861024: return bem_boolNpSet_1(bevd_0);
case 785544358: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1108661154: return bem_dynMethodsSet_1(bevd_0);
case 912980714: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 1512352293: return bem_lastMethodBodySizeSet_1(bevd_0);
case -2126783814: return bem_synEmitPathSet_1(bevd_0);
case 1887833790: return bem_smnlcsSetDirect_1(bevd_0);
case 1472095976: return bem_idToNameSet_1(bevd_0);
case 308396115: return bem_constSet_1(bevd_0);
case 1461777719: return bem_onceDecsSetDirect_1(bevd_0);
case -1900247155: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 197135058: return bem_cnodeSetDirect_1(bevd_0);
case 1784429290: return bem_intNpSet_1(bevd_0);
case 1568263258: return bem_constSetDirect_1(bevd_0);
case -483162834: return bem_returnTypeSetDirect_1(bevd_0);
case 1666066585: return bem_classesInDepthOrderSet_1(bevd_0);
case -1467625552: return bem_msynSet_1(bevd_0);
case 831525380: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1267841204: return bem_callNamesSetDirect_1(bevd_0);
case 2028866701: return bem_buildSetDirect_1(bevd_0);
case -210297226: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -674616263: return bem_nullValueSetDirect_1(bevd_0);
case 526059739: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2010849114: return bem_nameToIdPathSet_1(bevd_0);
case 1876884158: return bem_maxSpillArgsLenSet_1(bevd_0);
case 906794355: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1652538100: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 517608639: return bem_onceCountSet_1(bevd_0);
case 1794017651: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -349013284: return bem_preClassSet_1(bevd_0);
case 1565444462: return bem_trueValueSetDirect_1(bevd_0);
case -2006597457: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2119315847: return bem_objectNpSetDirect_1(bevd_0);
case 495936951: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1891534456: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1337475186: return bem_ntypesSetDirect_1(bevd_0);
case 1211218901: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 231818304: return bem_classCallsSet_1(bevd_0);
case -241751482: return bem_floatNpSetDirect_1(bevd_0);
case 2060314813: return bem_transSetDirect_1(bevd_0);
case -174598016: return bem_inFilePathedSetDirect_1(bevd_0);
case -260135820: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1339098940: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1786974674: return bem_preClassSetDirect_1(bevd_0);
case -888764602: return bem_methodsSetDirect_1(bevd_0);
case -1257313854: return bem_methodCallsSetDirect_1(bevd_0);
case -1561353119: return bem_ntypesSet_1(bevd_0);
case 822464624: return bem_lineCountSetDirect_1(bevd_0);
case 388706040: return bem_smnlecsSetDirect_1(bevd_0);
case -647189626: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -408640160: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -998281945: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 198747048: return bem_randSet_1(bevd_0);
case 1351762020: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1988327463: return bem_methodBodySetDirect_1(bevd_0);
case -646219218: return bem_superCallsSet_1(bevd_0);
case -1745535429: return bem_mnodeSet_1(bevd_0);
case 1392052312: return bem_boolCcSetDirect_1(bevd_0);
case -1105544004: return bem_nlSet_1(bevd_0);
case -2141462493: return bem_classConfSetDirect_1(bevd_0);
case 496744599: return bem_nameToIdSetDirect_1(bevd_0);
case -1221324972: return bem_objectCcSet_1(bevd_0);
case 1280914604: return bem_otherClass_1(bevd_0);
case 1306585527: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2069576697: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1010729441: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -585129351: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -2036338920: return bem_trueValueSet_1(bevd_0);
case -1964730340: return bem_synEmitPathSetDirect_1(bevd_0);
case -1424162733: return bem_smnlecsSet_1(bevd_0);
case 1204961908: return bem_nlSetDirect_1(bevd_0);
case 49137151: return bem_transSet_1(bevd_0);
case 1266588143: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 301914721: return bem_exceptDecSet_1(bevd_0);
case 1116925492: return bem_sameType_1(bevd_0);
case -1331911531: return bem_csynSetDirect_1(bevd_0);
case 501249295: return bem_gcMarksSetDirect_1(bevd_0);
case 1639644912: return bem_randSetDirect_1(bevd_0);
case -566662019: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -289267275: return bem_begin_1(bevd_0);
case -2086741170: return bem_idToNamePathSetDirect_1(bevd_0);
case -448022040: return bem_fullLibEmitNameSet_1(bevd_0);
case 724535640: return bem_falseValueSetDirect_1(bevd_0);
case -1946611219: return bem_scvpSetDirect_1(bevd_0);
case -841530479: return bem_boolNpSetDirect_1(bevd_0);
case -515609990: return bem_qSetDirect_1(bevd_0);
case 551528297: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1268199715: return bem_invpSet_1(bevd_0);
case -233698510: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -253041042: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1442433367: return bem_methodCatchSet_1(bevd_0);
case 708209504: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1177775473: return bem_methodCallsSet_1(bevd_0);
case -788235403: return bem_nativeCSlotsSet_1(bevd_0);
case -997817368: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1142143738: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1894730374: return bem_lastMethodsSizeSet_1(bevd_0);
case -1506699997: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -69912627: return bem_stringNpSet_1(bevd_0);
case -1790124281: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 499179148: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2000883210: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1599598377: return bem_instOfSet_1(bevd_0);
case -1667654591: return bem_nameToIdPathSetDirect_1(bevd_0);
case -1386550314: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 438391055: return bem_instanceEqualSetDirect_1(bevd_0);
case -894489976: return bem_propertyDecsSetDirect_1(bevd_0);
case 814926291: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 865827493: return bem_csynSet_1(bevd_0);
case 1677788079: return bem_lastCallSetDirect_1(bevd_0);
case -1219332229: return bem_floatNpSet_1(bevd_0);
case 1991227483: return bem_lineCountSet_1(bevd_0);
case 352831802: return bem_maxDynArgsSet_1(bevd_0);
case 1029635094: return bem_ccMethodsSet_1(bevd_0);
case 1631440684: return bem_scvpSet_1(bevd_0);
case -492693856: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -734789597: return bem_undefined_1(bevd_0);
case 408086523: return bem_ccCacheSet_1(bevd_0);
case -1195987573: return bem_superCallsSetDirect_1(bevd_0);
case -1217662451: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 126714264: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 244380737: return bem_inFilePathedSet_1(bevd_0);
case -1715866358: return bem_notEquals_1(bevd_0);
case -1587502659: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1513715833: return bem_shlibeSetDirect_1(bevd_0);
case -296354195: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -606068653: return bem_fileExtSetDirect_1(bevd_0);
case -345992202: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1144855449: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1289754882: return bem_nullValueSet_1(bevd_0);
case 992506169: return bem_mnodeSetDirect_1(bevd_0);
case -1728510858: return bem_smnlcsSet_1(bevd_0);
case 1616451888: return bem_parentConfSet_1(bevd_0);
case 182754761: return bem_cnodeSet_1(bevd_0);
case -914794223: return bem_undef_1(bevd_0);
case -128855781: return bem_methodsSet_1(bevd_0);
case 1744917313: return bem_defined_1(bevd_0);
case -657672469: return bem_ccMethodsSetDirect_1(bevd_0);
case 1198612901: return bem_emitLangSetDirect_1(bevd_0);
case -1743644890: return bem_msynSetDirect_1(bevd_0);
case 1349849963: return bem_otherType_1(bevd_0);
case -1018546965: return bem_maxDynArgsSetDirect_1(bevd_0);
case 395682848: return bem_methodCatchSetDirect_1(bevd_0);
case 1780154880: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 28806675: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -346611826: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -587589180: return bem_nameToIdSet_1(bevd_0);
case -310009584: return bem_libEmitPathSet_1(bevd_0);
case -1043490931: return bem_falseValueSet_1(bevd_0);
case 1434589991: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1245234817: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -606500397: return bem_buildSet_1(bevd_0);
case -1201731121: return bem_shlibeSet_1(bevd_0);
case -1028156837: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1486963961: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -708339816: return bem_boolCcSet_1(bevd_0);
case -496770648: return bem_exceptDecSetDirect_1(bevd_0);
case 560642871: return bem_idToNameSetDirect_1(bevd_0);
case 1269100351: return bem_parentConfSetDirect_1(bevd_0);
case 2001300007: return bem_sameObject_1(bevd_0);
case -758652603: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1411494948: return bem_intNpSetDirect_1(bevd_0);
case 1725227018: return bem_onceCountSetDirect_1(bevd_0);
case -1628539077: return bem_instanceEqualSet_1(bevd_0);
case 1408090480: return bem_objectNpSet_1(bevd_0);
case -289431761: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1572443353: return bem_libEmitNameSet_1(bevd_0);
case -1222910082: return bem_returnTypeSet_1(bevd_0);
case 5979801: return bem_classEmitsSetDirect_1(bevd_0);
case -448309734: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1053119277: return bem_propertyDecsSet_1(bevd_0);
case 1354681409: return bem_inClassSetDirect_1(bevd_0);
case 453957256: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -996792492: return bem_onceDecsSet_1(bevd_0);
case 8179711: return bem_lastMethodsLinesSet_1(bevd_0);
case 1698715225: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2065723947: return bem_instOfSetDirect_1(bevd_0);
case 1373706713: return bem_dynMethodsSetDirect_1(bevd_0);
case -1661795620: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1673241535: return bem_lastCallSet_1(bevd_0);
case -1034051116: return bem_methodBodySet_1(bevd_0);
case 2139027131: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 2025292016: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 68055959: return bem_classConfSet_1(bevd_0);
case 342110923: return bem_instanceNotEqualSet_1(bevd_0);
case -1302581881: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 843093885: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -617358271: return bem_classEmitsSet_1(bevd_0);
case -2079668662: return bem_objectCcSetDirect_1(bevd_0);
case -1989216698: return bem_inClassSet_1(bevd_0);
case 537144487: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1820085236: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1810059664: return bem_libEmitPathSetDirect_1(bevd_0);
case -2078294640: return bem_stringNpSetDirect_1(bevd_0);
case 2003318507: return bem_fileExtSet_1(bevd_0);
case -2120701530: return bem_equals_1(bevd_0);
case 898034411: return bem_sameClass_1(bevd_0);
case -159250713: return bem_libEmitNameSetDirect_1(bevd_0);
case 655424202: return bem_classCallsSetDirect_1(bevd_0);
case -579985919: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1506940745: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1478279581: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -560123773: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -2011759429: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1591533891: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1630879145: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -603725496: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -271130994: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 751583654: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2028721987: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1784313817: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1485133109: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1209760535: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1913909741: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -783944063: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1805350977: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -892362879: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -806788567: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1293653860: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1891697196: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -139626504: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 538771736: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 348892718: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1074653706: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -283288106: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 1015114874: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1068898773: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
