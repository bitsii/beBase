package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x65,0x6D,0x62,0x50,0x6C,0x61,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x6E,0x6F,0x63,0x6F,0x70,0x79,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x62,0x65,0x6D,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x62,0x65,0x76,0x6F,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_82 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_83 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_formTarg_1(beva_node);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_invp);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_7));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_8));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_11));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-880200863);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1844906171);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_14));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_15));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = beva_sdec.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_belsName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_1_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1395624711);
bevt_9_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_ta_ph );
bevt_12_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_12_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_14_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(-1522866158);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_5_ta_ph = bevt_6_ta_ph.bem_has_1(bevt_7_ta_ph);
if (!(bevt_5_ta_ph.bevi_bool))/* Line: 85*/ {
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 87*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(1754712773);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 87*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(-1352571190);
bevt_9_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_9_ta_ph.bevi_bool))/* Line: 88*/ {
if (bevl_first.bevi_bool)/* Line: 89*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 90*/
 else /* Line: 91*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
} /* Line: 92*/
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 94*/
} /* Line: 88*/
 else /* Line: 87*/ {
break;
} /* Line: 87*/
} /* Line: 87*/
} /* Line: 87*/
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_16_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1395624711);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_13_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevl_stinst);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_20_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_21_ta_ph);
bevt_20_ta_ph.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEndCi_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_0_ta_ph = beva_sdec.bem_addValue_1(bevt_1_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevp_onceDecs.bem_addValue_1(beva_sdec);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_3_ta_ph = beva_v.bem_nameGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 146*/
bevt_4_ta_ph = super.bem_nameForVar_1(beva_v);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_7_TextStrings bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_7_TextStrings bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_7_TextStrings bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_7_TextStrings bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_5_4_LogicBool bevt_79_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_5_4_LogicBool bevt_100_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_6_6_SystemObject bevt_109_ta_ph = null;
BEC_2_6_6_SystemObject bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_5_4_LogicBool bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_5_4_LogicBool bevt_119_ta_ph = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
/* Line: 162*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(1754712773);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 162*/ {
bevl_clnode = bevl_ci.bemd_0(-1352571190);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (!(bevt_2_ta_ph.bevi_bool))/* Line: 166*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_11_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_12_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevp_q);
bevt_15_ta_ph = bevl_clnode.bemd_0(-1906134035);
bevt_14_ta_ph = bevt_15_ta_ph.bemd_0(-1395624711);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(13717429);
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevp_q);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_20_ta_ph = bevl_clnode.bemd_0(-1906134035);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-1395624711);
bevt_18_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_19_ta_ph );
bevt_21_ta_ph = bevp_build.bem_libNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_relEmitName_1(bevt_21_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 167*/
bevt_25_ta_ph = bevl_clnode.bemd_0(-1906134035);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(-1522866158);
bevt_23_ta_ph = bevt_24_ta_ph.bemd_0(1049300905);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 169*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_ta_ph = bevl_clnode.bemd_0(-1906134035);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-1395624711);
bevt_29_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_30_ta_ph );
bevt_32_ta_ph = bevp_build.bem_libNameGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bem_relEmitName_1(bevt_32_ta_ph);
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevl_nc = bevt_26_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_36_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevl_nc);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_nl);
bevt_41_ta_ph = bevl_clnode.bemd_0(-1906134035);
bevt_40_ta_ph = bevt_41_ta_ph.bemd_0(-1522866158);
bevt_39_ta_ph = bevt_40_ta_ph.bemd_0(1049300905);
if (((BEC_2_5_4_LogicBool) bevt_39_ta_ph).bevi_bool)/* Line: 178*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_44_ta_ph = bevl_notNullInitDefault.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevl_nc);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 179*/
} /* Line: 178*/
} /* Line: 169*/
 else /* Line: 162*/ {
break;
} /* Line: 162*/
} /* Line: 162*/
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_47_ta_ph = bevp_smnlcs.bem_keysGet_0();
bevt_0_ta_loop = bevt_47_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 187*/ {
bevt_48_ta_ph = bevt_0_ta_loop.bemd_0(1754712773);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 187*/ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-1352571190);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_55_ta_ph = bevl_smap.bem_addValue_1(bevt_56_ta_ph);
bevt_58_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_57_ta_ph = bevt_58_ta_ph.bem_quoteGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevl_smk);
bevt_60_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_59_ta_ph = bevt_60_ta_ph.bem_quoteGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_61_ta_ph);
bevt_62_ta_ph = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_62_ta_ph);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_63_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_71_ta_ph = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_70_ta_ph = bevl_smap.bem_addValue_1(bevt_71_ta_ph);
bevt_73_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_72_ta_ph = bevt_73_ta_ph.bem_quoteGet_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_addValue_1(bevt_72_ta_ph);
bevt_68_ta_ph = bevt_69_ta_ph.bem_addValue_1(bevl_smk);
bevt_75_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_74_ta_ph = bevt_75_ta_ph.bem_quoteGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bem_addValue_1(bevt_74_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_66_ta_ph = bevt_67_ta_ph.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_65_ta_ph = bevt_66_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_64_ta_ph = bevt_65_ta_ph.bem_addValue_1(bevt_78_ta_ph);
bevt_64_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 190*/
 else /* Line: 187*/ {
break;
} /* Line: 187*/
} /* Line: 187*/
bevt_80_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_81_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_79_ta_ph = bevt_80_ta_ph.bem_has_1(bevt_81_ta_ph);
if (!(bevt_79_ta_ph.bevi_bool))/* Line: 194*/ {
bevl_libe.bem_write_1(bevl_smap);
} /* Line: 195*/
bevt_84_ta_ph = bevp_build.bem_usedLibrarysGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_sizeGet_0();
bevt_85_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_83_ta_ph.bevi_int == bevt_85_ta_ph.bevi_int) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 199*/ {
bevt_87_ta_ph = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_86_ta_ph = bevl_libInit.bem_addValue_1(bevt_87_ta_ph);
bevt_86_ta_ph.bem_addValue_1(bevp_nl);
bevt_89_ta_ph = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_88_ta_ph = bevl_libInit.bem_addValue_1(bevt_89_ta_ph);
bevt_88_ta_ph.bem_addValue_1(bevp_nl);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_90_ta_ph = bevl_libInit.bem_addValue_1(bevt_91_ta_ph);
bevt_90_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 202*/
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_92_ta_ph = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_92_ta_ph);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_96_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_95_ta_ph = bevl_main.bem_addValue_1(bevt_96_ta_ph);
bevt_97_ta_ph = bevl_maincc.bem_fullEmitNameGet_0();
bevt_94_ta_ph = bevt_95_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_98_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_93_ta_ph = bevt_94_ta_ph.bem_addValue_1(bevt_98_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_99_ta_ph.bevi_bool)/* Line: 215*/ {
bevt_101_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_102_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_100_ta_ph = bevt_101_ta_ph.bem_has_1(bevt_102_ta_ph);
if (!(bevt_100_ta_ph.bevi_bool))/* Line: 216*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_103_ta_ph = bevl_main.bem_addValue_1(bevt_104_ta_ph);
bevt_103_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 217*/
} /* Line: 216*/
bevt_108_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_107_ta_ph = bevl_main.bem_addValue_1(bevt_108_ta_ph);
bevt_110_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_109_ta_ph = bevt_110_ta_ph.bemd_0(-508927184);
bevt_106_ta_ph = bevt_107_ta_ph.bem_addValue_1(bevt_109_ta_ph);
bevt_111_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_105_ta_ph = bevt_106_ta_ph.bem_addValue_1(bevt_111_ta_ph);
bevt_105_ta_ph.bem_addValue_1(bevp_nl);
bevt_112_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_112_ta_ph.bevi_bool)/* Line: 221*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 222*/
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_113_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_113_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_115_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_114_ta_ph = bevl_main.bem_addValue_1(bevt_115_ta_ph);
bevt_114_ta_ph.bem_addValue_1(bevp_nl);
bevt_117_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_116_ta_ph = bevl_main.bem_addValue_1(bevt_117_ta_ph);
bevt_116_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 229*/
bevt_118_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_118_ta_ph.bevi_bool)/* Line: 231*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 232*/
bem_finishLibOutput_1(bevl_libe);
bevt_119_ta_ph = bevp_build.bem_saveSynsGet_0();
if (bevt_119_ta_ph.bevi_bool)/* Line: 237*/ {
bem_saveSyns_0();
} /* Line: 238*/
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 244*/ {
} /* Line: 244*/
 else /* Line: 246*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 247*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
beva_b.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 248*/
bevt_4_ta_ph = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 250*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_exceptDec);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_parent);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
bevl_extstr = bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_7_ta_ph = bevl_extstr.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevl_extstr = bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1685528963);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1685528963);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_8_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = beva_newcc.bem_relEmitName_1(bevt_8_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_sdec);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_10_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 286*/
 else /* Line: 287*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_67));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 288*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_68));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_8_ta_ph = bevl_begin.bem_addValue_1(bevt_9_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1106563617);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 304*/ {
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(beva_callArgs);
if (bevt_2_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_69));
beva_callArgs = bevt_4_ta_ph.bem_add_1(beva_callArgs);
} /* Line: 306*/
 else /* Line: 307*/ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
} /* Line: 308*/
bevt_10_ta_ph = bevp_parentConf.bem_emitNameGet_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-508927184);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_callArgs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_5_ta_ph;
} /* Line: 310*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_20_ta_ph = beva_callTarget.bem_add_1(bevt_21_ta_ph);
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(-508927184);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_73));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_callArgs);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_25_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_allOnceDecs == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 324*/ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 325*/
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getLibOutput_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
if (bevp_shlibe == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 341*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 343*/ {
bevt_7_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 344*/
bevt_9_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_ta_ph.bemd_0(1480925294);
bevt_11_ta_ph = bevp_build.bem_paramsGet_0();
bevt_12_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_74));
bevt_10_ta_ph = bevt_11_ta_ph.bem_has_1(bevt_12_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 348*/ {
bevt_14_ta_ph = bevp_build.bem_paramsGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_74));
bevt_13_ta_ph = bevt_14_ta_ph.bem_get_1(bevt_15_ta_ph);
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 349*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bemd_0(1754712773);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 349*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-1352571190);
bevt_17_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1480925294);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_ta_ph.bemd_0(1731924966);
bevt_20_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph.bemd_0(2102551733);
bevt_21_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 354*/
 else /* Line: 349*/ {
break;
} /* Line: 349*/
} /* Line: 349*/
} /* Line: 349*/
} /* Line: 348*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_75));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_anyName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_typeName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = beva_newcc.bem_relEmitName_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJSEmitter_bels_78));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_count);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_methods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_80));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_81));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_ta_ph = bevp_methods.bem_addValue_1(bevt_7_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_82));
bevt_1_ta_ph = beva_nameSpace.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_emitName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_83));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 68, 68, 68, 68, 68, 68, 68, 72, 72, 72, 72, 72, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 73, 75, 75, 75, 80, 80, 81, 83, 83, 83, 83, 85, 85, 85, 86, 87, 0, 87, 87, 88, 90, 92, 92, 94, 94, 94, 94, 94, 94, 99, 99, 99, 104, 104, 104, 105, 107, 107, 107, 107, 107, 110, 110, 110, 110, 112, 112, 112, 114, 114, 114, 114, 114, 117, 117, 117, 117, 117, 117, 119, 119, 119, 121, 126, 127, 128, 134, 134, 139, 139, 139, 140, 145, 146, 146, 146, 146, 148, 148, 157, 159, 160, 161, 162, 162, 164, 166, 166, 166, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 167, 169, 169, 169, 171, 171, 171, 171, 171, 171, 171, 171, 171, 177, 177, 177, 177, 177, 177, 178, 178, 178, 179, 179, 179, 179, 179, 179, 185, 187, 187, 0, 187, 187, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 190, 194, 194, 194, 195, 199, 199, 199, 199, 199, 200, 200, 200, 201, 201, 201, 202, 202, 202, 205, 206, 209, 210, 210, 211, 213, 214, 214, 214, 214, 214, 214, 214, 215, 216, 216, 216, 217, 217, 217, 220, 220, 220, 220, 220, 220, 220, 220, 221, 222, 224, 225, 226, 227, 228, 228, 228, 229, 229, 229, 231, 232, 235, 237, 238, 244, 247, 247, 247, 248, 248, 250, 250, 255, 255, 259, 259, 259, 259, 259, 259, 263, 263, 267, 267, 267, 267, 267, 267, 267, 268, 268, 268, 268, 268, 269, 273, 273, 273, 273, 273, 273, 273, 273, 273, 273, 273, 273, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 281, 281, 281, 281, 281, 281, 281, 281, 281, 281, 281, 281, 281, 285, 285, 286, 286, 286, 288, 288, 290, 290, 290, 290, 290, 298, 298, 298, 299, 300, 304, 304, 305, 305, 306, 306, 308, 310, 310, 310, 310, 310, 310, 310, 310, 310, 310, 310, 310, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 312, 316, 317, 324, 324, 325, 327, 328, 328, 333, 333, 341, 341, 342, 343, 343, 343, 343, 343, 344, 344, 344, 346, 346, 346, 348, 348, 348, 349, 349, 349, 349, 0, 349, 349, 350, 350, 351, 351, 351, 352, 352, 353, 353, 354, 360, 364, 365, 370, 370, 374, 374, 378, 378, 382, 382, 386, 386, 390, 390, 394, 394, 399, 399, 405, 405, 410, 410, 414, 414, 414, 414, 414, 414, 418, 418, 418, 418, 418, 423, 423, 423, 423, 423, 423, 423, 428, 428, 428, 428, 428, 428, 428, 430, 432, 432, 432, 437, 437, 441, 441, 445, 445, 445, 445, 450, 450, 454, 455, 455, 456, 460, 461, 461, 462, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {98, 99, 100, 101, 102, 103, 104, 105, 111, 112, 113, 119, 120, 121, 122, 128, 129, 130, 131, 141, 142, 143, 144, 145, 146, 147, 148, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 196, 197, 207, 208, 209, 210, 211, 212, 213, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 288, 289, 289, 292, 294, 295, 298, 301, 302, 304, 305, 306, 307, 308, 309, 317, 318, 319, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 382, 383, 384, 389, 390, 396, 397, 398, 399, 408, 410, 411, 412, 413, 415, 416, 554, 555, 556, 557, 558, 561, 563, 564, 565, 566, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 588, 589, 590, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 611, 612, 613, 614, 615, 616, 624, 625, 626, 626, 629, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 669, 670, 671, 673, 675, 676, 677, 678, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 710, 711, 712, 714, 715, 716, 719, 720, 721, 722, 723, 724, 725, 726, 727, 729, 731, 732, 733, 734, 736, 737, 738, 739, 740, 741, 743, 745, 747, 748, 750, 760, 764, 765, 770, 771, 772, 774, 775, 781, 782, 790, 791, 792, 793, 794, 795, 799, 800, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 918, 923, 924, 925, 926, 929, 930, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 970, 971, 973, 974, 976, 977, 980, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1009, 1010, 1015, 1020, 1021, 1023, 1024, 1025, 1029, 1030, 1061, 1066, 1067, 1068, 1069, 1070, 1071, 1076, 1077, 1078, 1079, 1081, 1082, 1083, 1084, 1085, 1086, 1088, 1089, 1090, 1091, 1091, 1094, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1114, 1117, 1118, 1123, 1124, 1128, 1129, 1133, 1134, 1138, 1139, 1143, 1144, 1148, 1149, 1153, 1154, 1158, 1159, 1163, 1164, 1168, 1169, 1177, 1178, 1179, 1180, 1181, 1182, 1189, 1190, 1191, 1192, 1193, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1234, 1235, 1239, 1240, 1246, 1247, 1248, 1249, 1253, 1254, 1259, 1260, 1261, 1262, 1267, 1268, 1269, 1270, 1273, 1276, 1280, 1283};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 98
new 0 16 98
assign 1 17 99
new 0 17 99
assign 1 18 100
new 0 18 100
new 1 22 101
assign 1 24 102
new 0 24 102
assign 1 25 103
new 0 25 103
assign 1 27 104
new 0 27 104
assign 1 28 105
new 0 28 105
assign 1 32 111
formTarg 1 32 111
assign 1 32 112
add 1 32 112
return 1 32 113
assign 1 36 119
formCallTarg 1 36 119
assign 1 36 120
new 0 36 120
assign 1 36 121
add 1 36 121
return 1 36 122
assign 1 40 128
formCallTarg 1 40 128
assign 1 40 129
new 0 40 129
assign 1 40 130
add 1 40 130
return 1 40 131
assign 1 44 141
new 0 44 141
assign 1 44 142
addValue 1 44 142
assign 1 44 143
secondGet 0 44 143
assign 1 44 144
formTarg 1 44 144
assign 1 44 145
addValue 1 44 145
assign 1 44 146
new 0 44 146
assign 1 44 147
addValue 1 44 147
addValue 1 44 148
assign 1 48 169
new 0 48 169
assign 1 48 170
toString 0 48 170
assign 1 48 171
add 1 48 171
incrementValue 0 49 172
assign 1 50 173
new 0 50 173
assign 1 50 174
addValue 1 50 174
assign 1 50 175
addValue 1 50 175
assign 1 50 176
new 0 50 176
assign 1 50 177
addValue 1 50 177
addValue 1 50 178
assign 1 55 179
containedGet 0 55 179
assign 1 55 180
firstGet 0 55 180
assign 1 55 181
containedGet 0 55 181
assign 1 55 182
firstGet 0 55 182
assign 1 55 183
new 0 55 183
assign 1 55 184
add 1 55 184
assign 1 55 185
new 0 55 185
assign 1 55 186
add 1 55 186
assign 1 55 187
finalAssign 4 55 187
addValue 1 55 188
assign 1 63 196
new 0 63 196
addValue 1 63 197
assign 1 68 207
emitNameGet 0 68 207
assign 1 68 208
addValue 1 68 208
assign 1 68 209
new 0 68 209
assign 1 68 210
addValue 1 68 210
assign 1 68 211
addValue 1 68 211
assign 1 68 212
new 0 68 212
addValue 1 68 213
assign 1 72 233
emitNameGet 0 72 233
assign 1 72 234
addValue 1 72 234
assign 1 72 235
new 0 72 235
assign 1 72 236
addValue 1 72 236
addValue 1 72 237
assign 1 73 238
new 0 73 238
assign 1 73 239
addValue 1 73 239
assign 1 73 240
heldGet 0 73 240
assign 1 73 241
namepathGet 0 73 241
assign 1 73 242
getClassConfig 1 73 242
assign 1 73 243
libNameGet 0 73 243
assign 1 73 244
relEmitName 1 73 244
assign 1 73 245
addValue 1 73 245
assign 1 73 246
new 0 73 246
assign 1 73 247
addValue 1 73 247
addValue 1 73 248
assign 1 75 249
new 0 75 249
assign 1 75 250
addValue 1 75 250
addValue 1 75 251
assign 1 80 277
heldGet 0 80 277
assign 1 80 278
synGet 0 80 278
assign 1 81 279
ptyListGet 0 81 279
assign 1 83 280
emitNameGet 0 83 280
assign 1 83 281
addValue 1 83 281
assign 1 83 282
new 0 83 282
addValue 1 83 283
assign 1 85 284
emitChecksGet 0 85 284
assign 1 85 285
new 0 85 285
assign 1 85 286
has 1 85 286
assign 1 86 288
new 0 86 288
assign 1 87 289
iteratorGet 0 0 289
assign 1 87 292
hasNextGet 0 87 292
assign 1 87 294
nextGet 0 87 294
assign 1 88 295
isSlotGet 0 88 295
assign 1 90 298
new 0 90 298
assign 1 92 301
new 0 92 301
addValue 1 92 302
assign 1 94 304
addValue 1 94 304
assign 1 94 305
new 0 94 305
assign 1 94 306
addValue 1 94 306
assign 1 94 307
nameGet 0 94 307
assign 1 94 308
addValue 1 94 308
addValue 1 94 309
assign 1 99 317
new 0 99 317
assign 1 99 318
addValue 1 99 318
addValue 1 99 319
assign 1 104 347
heldGet 0 104 347
assign 1 104 348
namepathGet 0 104 348
assign 1 104 349
getClassConfig 1 104 349
assign 1 105 350
getInitialInst 1 105 350
assign 1 107 351
emitNameGet 0 107 351
assign 1 107 352
addValue 1 107 352
assign 1 107 353
new 0 107 353
assign 1 107 354
addValue 1 107 354
addValue 1 107 355
assign 1 110 356
addValue 1 110 356
assign 1 110 357
new 0 110 357
assign 1 110 358
addValue 1 110 358
addValue 1 110 359
assign 1 112 360
new 0 112 360
assign 1 112 361
addValue 1 112 361
addValue 1 112 362
assign 1 114 363
emitNameGet 0 114 363
assign 1 114 364
addValue 1 114 364
assign 1 114 365
new 0 114 365
assign 1 114 366
addValue 1 114 366
addValue 1 114 367
assign 1 117 368
new 0 117 368
assign 1 117 369
addValue 1 117 369
assign 1 117 370
addValue 1 117 370
assign 1 117 371
new 0 117 371
assign 1 117 372
addValue 1 117 372
addValue 1 117 373
assign 1 119 374
new 0 119 374
assign 1 119 375
addValue 1 119 375
addValue 1 119 376
buildPropList 0 121 377
getCode 2 126 382
assign 1 127 383
toString 0 127 383
addValue 1 128 384
assign 1 134 389
new 0 134 389
addValue 1 134 390
assign 1 139 396
new 0 139 396
assign 1 139 397
addValue 1 139 397
addValue 1 139 398
addValue 1 140 399
assign 1 145 408
isPropertyGet 0 145 408
assign 1 146 410
new 0 146 410
assign 1 146 411
nameGet 0 146 411
assign 1 146 412
add 1 146 412
return 1 146 413
assign 1 148 415
nameForVar 1 148 415
return 1 148 416
assign 1 157 554
getLibOutput 0 157 554
assign 1 159 555
new 0 159 555
assign 1 160 556
new 0 160 556
assign 1 161 557
new 0 161 557
assign 1 162 558
iteratorGet 0 162 558
assign 1 162 561
hasNextGet 0 162 561
assign 1 164 563
nextGet 0 164 563
assign 1 166 564
emitChecksGet 0 166 564
assign 1 166 565
new 0 166 565
assign 1 166 566
has 1 166 566
assign 1 167 568
new 0 167 568
assign 1 167 569
addValue 1 167 569
assign 1 167 570
addValue 1 167 570
assign 1 167 571
heldGet 0 167 571
assign 1 167 572
namepathGet 0 167 572
assign 1 167 573
toString 0 167 573
assign 1 167 574
addValue 1 167 574
assign 1 167 575
addValue 1 167 575
assign 1 167 576
new 0 167 576
assign 1 167 577
addValue 1 167 577
assign 1 167 578
heldGet 0 167 578
assign 1 167 579
namepathGet 0 167 579
assign 1 167 580
getClassConfig 1 167 580
assign 1 167 581
libNameGet 0 167 581
assign 1 167 582
relEmitName 1 167 582
assign 1 167 583
addValue 1 167 583
assign 1 167 584
new 0 167 584
assign 1 167 585
addValue 1 167 585
addValue 1 167 586
assign 1 169 588
heldGet 0 169 588
assign 1 169 589
synGet 0 169 589
assign 1 169 590
hasDefaultGet 0 169 590
assign 1 171 592
new 0 171 592
assign 1 171 593
heldGet 0 171 593
assign 1 171 594
namepathGet 0 171 594
assign 1 171 595
getClassConfig 1 171 595
assign 1 171 596
libNameGet 0 171 596
assign 1 171 597
relEmitName 1 171 597
assign 1 171 598
add 1 171 598
assign 1 171 599
new 0 171 599
assign 1 171 600
add 1 171 600
assign 1 177 601
new 0 177 601
assign 1 177 602
addValue 1 177 602
assign 1 177 603
addValue 1 177 603
assign 1 177 604
new 0 177 604
assign 1 177 605
addValue 1 177 605
addValue 1 177 606
assign 1 178 607
heldGet 0 178 607
assign 1 178 608
synGet 0 178 608
assign 1 178 609
hasDefaultGet 0 178 609
assign 1 179 611
new 0 179 611
assign 1 179 612
addValue 1 179 612
assign 1 179 613
addValue 1 179 613
assign 1 179 614
new 0 179 614
assign 1 179 615
addValue 1 179 615
addValue 1 179 616
assign 1 185 624
new 0 185 624
assign 1 187 625
keysGet 0 187 625
assign 1 187 626
iteratorGet 0 0 626
assign 1 187 629
hasNextGet 0 187 629
assign 1 187 631
nextGet 0 187 631
assign 1 189 632
new 0 189 632
assign 1 189 633
addValue 1 189 633
assign 1 189 634
new 0 189 634
assign 1 189 635
quoteGet 0 189 635
assign 1 189 636
addValue 1 189 636
assign 1 189 637
addValue 1 189 637
assign 1 189 638
new 0 189 638
assign 1 189 639
quoteGet 0 189 639
assign 1 189 640
addValue 1 189 640
assign 1 189 641
new 0 189 641
assign 1 189 642
addValue 1 189 642
assign 1 189 643
get 1 189 643
assign 1 189 644
addValue 1 189 644
assign 1 189 645
new 0 189 645
assign 1 189 646
addValue 1 189 646
addValue 1 189 647
assign 1 190 648
new 0 190 648
assign 1 190 649
addValue 1 190 649
assign 1 190 650
new 0 190 650
assign 1 190 651
quoteGet 0 190 651
assign 1 190 652
addValue 1 190 652
assign 1 190 653
addValue 1 190 653
assign 1 190 654
new 0 190 654
assign 1 190 655
quoteGet 0 190 655
assign 1 190 656
addValue 1 190 656
assign 1 190 657
new 0 190 657
assign 1 190 658
addValue 1 190 658
assign 1 190 659
get 1 190 659
assign 1 190 660
addValue 1 190 660
assign 1 190 661
new 0 190 661
assign 1 190 662
addValue 1 190 662
addValue 1 190 663
assign 1 194 669
emitChecksGet 0 194 669
assign 1 194 670
new 0 194 670
assign 1 194 671
has 1 194 671
write 1 195 673
assign 1 199 675
usedLibrarysGet 0 199 675
assign 1 199 676
sizeGet 0 199 676
assign 1 199 677
new 0 199 677
assign 1 199 678
equals 1 199 683
assign 1 200 684
new 0 200 684
assign 1 200 685
addValue 1 200 685
addValue 1 200 686
assign 1 201 687
new 0 201 687
assign 1 201 688
addValue 1 201 688
addValue 1 201 689
assign 1 202 690
new 0 202 690
assign 1 202 691
addValue 1 202 691
addValue 1 202 692
write 1 205 694
write 1 206 695
assign 1 209 696
new 0 209 696
assign 1 210 697
mainNameGet 0 210 697
fromString 1 210 698
assign 1 211 699
getClassConfig 1 211 699
assign 1 213 700
new 0 213 700
assign 1 214 701
new 0 214 701
assign 1 214 702
addValue 1 214 702
assign 1 214 703
fullEmitNameGet 0 214 703
assign 1 214 704
addValue 1 214 704
assign 1 214 705
new 0 214 705
assign 1 214 706
addValue 1 214 706
addValue 1 214 707
assign 1 215 708
ownProcessGet 0 215 708
assign 1 216 710
emitChecksGet 0 216 710
assign 1 216 711
new 0 216 711
assign 1 216 712
has 1 216 712
assign 1 217 714
new 0 217 714
assign 1 217 715
addValue 1 217 715
addValue 1 217 716
assign 1 220 719
new 0 220 719
assign 1 220 720
addValue 1 220 720
assign 1 220 721
outputPlatformGet 0 220 721
assign 1 220 722
nameGet 0 220 722
assign 1 220 723
addValue 1 220 723
assign 1 220 724
new 0 220 724
assign 1 220 725
addValue 1 220 725
addValue 1 220 726
assign 1 221 727
doMainGet 0 221 727
write 1 222 729
assign 1 224 731
new 0 224 731
write 1 225 732
write 1 226 733
assign 1 227 734
ownProcessGet 0 227 734
assign 1 228 736
new 0 228 736
assign 1 228 737
addValue 1 228 737
addValue 1 228 738
assign 1 229 739
new 0 229 739
assign 1 229 740
addValue 1 229 740
addValue 1 229 741
assign 1 231 743
doMainGet 0 231 743
write 1 232 745
finishLibOutput 1 235 747
assign 1 237 748
saveSynsGet 0 237 748
saveSyns 0 238 750
assign 1 244 760
isPropertyGet 0 244 760
assign 1 247 764
isArgGet 0 247 764
assign 1 247 765
not 0 247 770
assign 1 248 771
new 0 248 771
addValue 1 248 772
assign 1 250 774
nameForVar 1 250 774
addValue 1 250 775
assign 1 255 781
new 0 255 781
return 1 255 782
assign 1 259 790
new 0 259 790
assign 1 259 791
add 1 259 791
assign 1 259 792
new 0 259 792
assign 1 259 793
add 1 259 793
assign 1 259 794
add 1 259 794
return 1 259 795
assign 1 263 799
new 0 263 799
return 1 263 800
assign 1 267 814
emitNameGet 0 267 814
assign 1 267 815
new 0 267 815
assign 1 267 816
add 1 267 816
assign 1 267 817
add 1 267 817
assign 1 267 818
new 0 267 818
assign 1 267 819
add 1 267 819
assign 1 267 820
addValue 1 267 820
assign 1 268 821
emitNameGet 0 268 821
assign 1 268 822
add 1 268 822
assign 1 268 823
new 0 268 823
assign 1 268 824
add 1 268 824
assign 1 268 825
addValue 1 268 825
return 1 269 826
assign 1 273 840
new 0 273 840
assign 1 273 841
libNameGet 0 273 841
assign 1 273 842
relEmitName 1 273 842
assign 1 273 843
add 1 273 843
assign 1 273 844
new 0 273 844
assign 1 273 845
add 1 273 845
assign 1 273 846
heldGet 0 273 846
assign 1 273 847
literalValueGet 0 273 847
assign 1 273 848
add 1 273 848
assign 1 273 849
new 0 273 849
assign 1 273 850
add 1 273 850
return 1 273 851
assign 1 277 865
new 0 277 865
assign 1 277 866
libNameGet 0 277 866
assign 1 277 867
relEmitName 1 277 867
assign 1 277 868
add 1 277 868
assign 1 277 869
new 0 277 869
assign 1 277 870
add 1 277 870
assign 1 277 871
heldGet 0 277 871
assign 1 277 872
literalValueGet 0 277 872
assign 1 277 873
add 1 277 873
assign 1 277 874
new 0 277 874
assign 1 277 875
add 1 277 875
return 1 277 876
assign 1 281 891
new 0 281 891
assign 1 281 892
libNameGet 0 281 892
assign 1 281 893
relEmitName 1 281 893
assign 1 281 894
add 1 281 894
assign 1 281 895
new 0 281 895
assign 1 281 896
add 1 281 896
assign 1 281 897
add 1 281 897
assign 1 281 898
new 0 281 898
assign 1 281 899
add 1 281 899
assign 1 281 900
add 1 281 900
assign 1 281 901
new 0 281 901
assign 1 281 902
add 1 281 902
return 1 281 903
assign 1 285 918
def 1 285 923
assign 1 286 924
libNameGet 0 286 924
assign 1 286 925
relEmitName 1 286 925
assign 1 286 926
extend 1 286 926
assign 1 288 929
new 0 288 929
assign 1 288 930
extend 1 288 930
assign 1 290 932
new 0 290 932
assign 1 290 933
emitNameGet 0 290 933
assign 1 290 934
addValue 1 290 934
assign 1 290 935
new 0 290 935
assign 1 290 936
addValue 1 290 936
assign 1 298 937
new 0 298 937
assign 1 298 938
addValue 1 298 938
addValue 1 298 939
addValue 1 299 940
return 1 300 941
assign 1 304 970
heldGet 0 304 970
assign 1 304 971
superCallGet 0 304 971
assign 1 305 973
new 0 305 973
assign 1 305 974
notEmpty 1 305 974
assign 1 306 976
new 0 306 976
assign 1 306 977
add 1 306 977
assign 1 308 980
new 0 308 980
assign 1 310 982
emitNameGet 0 310 982
assign 1 310 983
new 0 310 983
assign 1 310 984
add 1 310 984
assign 1 310 985
heldGet 0 310 985
assign 1 310 986
nameGet 0 310 986
assign 1 310 987
add 1 310 987
assign 1 310 988
new 0 310 988
assign 1 310 989
add 1 310 989
assign 1 310 990
add 1 310 990
assign 1 310 991
new 0 310 991
assign 1 310 992
add 1 310 992
return 1 310 993
assign 1 312 995
new 0 312 995
assign 1 312 996
add 1 312 996
assign 1 312 997
heldGet 0 312 997
assign 1 312 998
nameGet 0 312 998
assign 1 312 999
add 1 312 999
assign 1 312 1000
new 0 312 1000
assign 1 312 1001
add 1 312 1001
assign 1 312 1002
add 1 312 1002
assign 1 312 1003
new 0 312 1003
assign 1 312 1004
add 1 312 1004
return 1 312 1005
assign 1 316 1009
new 0 316 1009
return 1 317 1010
assign 1 324 1015
undef 1 324 1020
assign 1 325 1021
new 0 325 1021
addValue 1 327 1023
assign 1 328 1024
new 0 328 1024
return 1 328 1025
assign 1 333 1029
getLibOutput 0 333 1029
return 1 333 1030
assign 1 341 1061
undef 1 341 1066
assign 1 342 1067
new 0 342 1067
assign 1 343 1068
parentGet 0 343 1068
assign 1 343 1069
fileGet 0 343 1069
assign 1 343 1070
existsGet 0 343 1070
assign 1 343 1071
not 0 343 1076
assign 1 344 1077
parentGet 0 344 1077
assign 1 344 1078
fileGet 0 344 1078
makeDirs 0 344 1079
assign 1 346 1081
fileGet 0 346 1081
assign 1 346 1082
writerGet 0 346 1082
assign 1 346 1083
open 0 346 1083
assign 1 348 1084
paramsGet 0 348 1084
assign 1 348 1085
new 0 348 1085
assign 1 348 1086
has 1 348 1086
assign 1 349 1088
paramsGet 0 349 1088
assign 1 349 1089
new 0 349 1089
assign 1 349 1090
get 1 349 1090
assign 1 349 1091
iteratorGet 0 0 1091
assign 1 349 1094
hasNextGet 0 349 1094
assign 1 349 1096
nextGet 0 349 1096
assign 1 350 1097
apNew 1 350 1097
assign 1 350 1098
fileGet 0 350 1098
assign 1 351 1099
readerGet 0 351 1099
assign 1 351 1100
open 0 351 1100
assign 1 351 1101
readString 0 351 1101
assign 1 352 1102
readerGet 0 352 1102
close 0 352 1103
assign 1 353 1104
countLines 1 353 1104
addValue 1 353 1105
write 1 354 1106
return 1 360 1114
close 0 364 1117
assign 1 365 1118
assign 1 370 1123
new 0 370 1123
return 1 370 1124
assign 1 374 1128
new 0 374 1128
return 1 374 1129
assign 1 378 1133
new 0 378 1133
return 1 378 1134
assign 1 382 1138
new 0 382 1138
return 1 382 1139
assign 1 386 1143
new 0 386 1143
return 1 386 1144
assign 1 390 1148
new 0 390 1148
return 1 390 1149
assign 1 394 1153
new 0 394 1153
return 1 394 1154
assign 1 399 1158
new 0 399 1158
return 1 399 1159
assign 1 405 1163
new 0 405 1163
return 1 405 1164
assign 1 410 1168
new 0 410 1168
return 1 410 1169
assign 1 414 1177
new 0 414 1177
assign 1 414 1178
add 1 414 1178
assign 1 414 1179
new 0 414 1179
assign 1 414 1180
add 1 414 1180
assign 1 414 1181
add 1 414 1181
return 1 414 1182
assign 1 418 1189
libNameGet 0 418 1189
assign 1 418 1190
relEmitName 1 418 1190
assign 1 418 1191
new 0 418 1191
assign 1 418 1192
add 1 418 1192
return 1 418 1193
assign 1 423 1202
emitNameGet 0 423 1202
assign 1 423 1203
new 0 423 1203
assign 1 423 1204
add 1 423 1204
assign 1 423 1205
new 0 423 1205
assign 1 423 1206
add 1 423 1206
assign 1 423 1207
add 1 423 1207
return 1 423 1208
assign 1 428 1219
emitNameGet 0 428 1219
assign 1 428 1220
addValue 1 428 1220
assign 1 428 1221
new 0 428 1221
assign 1 428 1222
addValue 1 428 1222
assign 1 428 1223
addValue 1 428 1223
assign 1 428 1224
new 0 428 1224
addValue 1 428 1225
addValue 1 430 1226
assign 1 432 1227
new 0 432 1227
assign 1 432 1228
addValue 1 432 1228
addValue 1 432 1229
assign 1 437 1234
new 0 437 1234
return 1 437 1235
assign 1 441 1239
new 0 441 1239
return 1 441 1240
assign 1 445 1246
new 0 445 1246
assign 1 445 1247
add 1 445 1247
assign 1 445 1248
add 1 445 1248
return 1 445 1249
assign 1 450 1253
new 0 450 1253
return 1 450 1254
assign 1 454 1259
getClassConfig 1 454 1259
assign 1 455 1260
fullEmitNameGet 0 455 1260
emitNameSet 1 455 1261
return 1 456 1262
assign 1 460 1267
getLocalClassConfig 1 460 1267
assign 1 461 1268
fullEmitNameGet 0 461 1268
emitNameSet 1 461 1269
return 1 462 1270
return 1 0 1273
assign 1 0 1276
return 1 0 1280
assign 1 0 1283
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 358536854: return bem_trueValueGet_0();
case -1520670979: return bem_spropDecGet_0();
case 73873887: return bem_overrideMtdDecGet_0();
case -1560586347: return bem_synEmitPathGet_0();
case 1427164803: return bem_ccCacheGet_0();
case -631275147: return bem_buildClassInfo_0();
case -1701376828: return bem_onceDecsGet_0();
case -942122539: return bem_boolCcGet_0();
case 1182467868: return bem_lastMethodBodySizeGet_0();
case 1599605788: return bem_stringNpGet_0();
case -897263524: return bem_floatNpGet_0();
case 1723592700: return bem_lastMethodBodyLinesGet_0();
case -123880973: return bem_copy_0();
case -1410685861: return bem_nativeCSlotsGet_0();
case 1810630815: return bem_lastMethodsLinesGet_0();
case 1222796480: return bem_emitLangGet_0();
case -528055827: return bem_doEmit_0();
case 2072802633: return bem_ccMethodsGet_0();
case -2072791561: return bem_lineCountGet_0();
case -339829227: return bem_buildGet_0();
case -2036775162: return bem_loadIds_0();
case 1146036983: return bem_instanceNotEqualGet_0();
case -1945298452: return bem_nlGet_0();
case 296383961: return bem_objectCcGet_0();
case -1001814672: return bem_methodsGet_0();
case 29900174: return bem_maxDynArgsGet_0();
case 1977066180: return bem_fileExtGet_0();
case 2049364969: return bem_newDecGet_0();
case -982115875: return bem_buildCreate_0();
case 1197182256: return bem_falseValueGet_0();
case 621334352: return bem_print_0();
case -1488207327: return bem_intNpGet_0();
case 1000621180: return bem_useDynMethodsGet_0();
case -2101005653: return bem_covariantReturnsGet_0();
case 1653421910: return bem_baseSmtdDecGet_0();
case -893391950: return bem_libEmitNameGet_0();
case 935498172: return bem_fullLibEmitNameGet_0();
case -1704250489: return bem_instOfGet_0();
case 107525885: return bem_runtimeInitGet_0();
case -550588596: return bem_idToNamePathGet_0();
case -1509126792: return bem_cnodeGet_0();
case 1796434970: return bem_gcMarksGet_0();
case 1576958369: return bem_mainStartGet_0();
case 1438192594: return bem_hashGet_0();
case -977064711: return bem_constGet_0();
case -1843543517: return bem_classCallsGet_0();
case 309355335: return bem_buildPropList_0();
case 13717429: return bem_toString_0();
case -417447334: return bem_endNs_0();
case -1021459982: return bem_instanceEqualGet_0();
case 267478710: return bem_maxSpillArgsLenGet_0();
case -494064585: return bem_typeDecGet_0();
case -580843070: return bem_superCallsGet_0();
case -49260595: return bem_saveSyns_0();
case 200878754: return bem_beginNs_0();
case -1368888993: return bem_nullValueGet_0();
case -1983878186: return bem_new_0();
case -1923461434: return bem_nameToIdGet_0();
case -666492963: return bem_dynMethodsGet_0();
case 913187683: return bem_inFilePathedGet_0();
case 1652337876: return bem_classEndGet_0();
case 773367632: return bem_mainEndGet_0();
case -729105372: return bem_smnlecsGet_0();
case -2100461476: return bem_classConfGet_0();
case 1846700257: return bem_ntypesGet_0();
case -687771718: return bem_msynGet_0();
case -839809393: return bem_objectNpGet_0();
case 879868798: return bem_mainInClassGet_0();
case 315181054: return bem_methodBodyGet_0();
case 110567225: return bem_propDecGet_0();
case -307261338: return bem_returnTypeGet_0();
case -1312388773: return bem_methodCatchGet_0();
case 1883680812: return bem_shlibeGet_0();
case 1268572923: return bem_mainOutsideNsGet_0();
case -762259872: return bem_nameToIdPathGet_0();
case -677240114: return bem_afterCast_0();
case 1245776159: return bem_lastCallGet_0();
case -443343999: return bem_create_0();
case -387516352: return bem_invpGet_0();
case -1461281083: return bem_preClassOutput_0();
case 2129516054: return bem_boolNpGet_0();
case 1604677155: return bem_randGet_0();
case -1003281216: return bem_iteratorGet_0();
case -1260650106: return bem_lastMethodsSizeGet_0();
case -210318525: return bem_preClassGet_0();
case 987052331: return bem_buildInitial_0();
case -523249172: return bem_qGet_0();
case -1828787266: return bem_scvpGet_0();
case 470438712: return bem_callNamesGet_0();
case 1061937767: return bem_libEmitPathGet_0();
case 1252337884: return bem_csynGet_0();
case -1661907474: return bem_emitLib_0();
case -797568900: return bem_transGet_0();
case -1535379921: return bem_initialDecGet_0();
case 1406116895: return bem_propertyDecsGet_0();
case 300264770: return bem_classesInDepthOrderGet_0();
case -408864942: return bem_exceptDecGet_0();
case -449616136: return bem_classEmitsGet_0();
case 1700881079: return bem_smnlcsGet_0();
case 2106428289: return bem_getLibOutput_0();
case 969237500: return bem_parentConfGet_0();
case -2106752808: return bem_boolTypeGet_0();
case 880803223: return bem_baseMtdDecGet_0();
case 1196697207: return bem_allOnceDecsGet_0();
case -792691875: return bem_belslitsGet_0();
case 837465455: return bem_idToNameGet_0();
case -1991629180: return bem_saveIds_0();
case -1293933020: return bem_methodCallsGet_0();
case 1251135035: return bem_superNameGet_0();
case 923330562: return bem_writeBET_0();
case 1768821998: return bem_getClassOutput_0();
case 1844220292: return bem_inClassGet_0();
case 895042439: return bem_mnodeGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 999900869: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 880247448: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 672542868: return bem_msynSet_1(bevd_0);
case -1137562205: return bem_classEmitsSet_1(bevd_0);
case -1108287399: return bem_lineCountSet_1(bevd_0);
case -230261390: return bem_lastCallSet_1(bevd_0);
case 674829607: return bem_lastMethodsLinesSet_1(bevd_0);
case 1390514047: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1759976322: return bem_allOnceDecsSet_1(bevd_0);
case 2058415087: return bem_classesInDepthOrderSet_1(bevd_0);
case -366701133: return bem_csynSet_1(bevd_0);
case -481440394: return bem_idToNamePathSet_1(bevd_0);
case -2050568438: return bem_instOfSet_1(bevd_0);
case -506959062: return bem_belslitsSet_1(bevd_0);
case -501048330: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -750328753: return bem_onceDecsSet_1(bevd_0);
case -1241551703: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -601992574: return bem_floatNpSet_1(bevd_0);
case -40385456: return bem_cnodeSet_1(bevd_0);
case 1128552781: return bem_fileExtSet_1(bevd_0);
case -891369511: return bem_classCallsSet_1(bevd_0);
case -1660653499: return bem_mnodeSet_1(bevd_0);
case 9624847: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1734395939: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 196661416: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 981730221: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1390070643: return bem_inFilePathedSet_1(bevd_0);
case -865818327: return bem_methodCallsSet_1(bevd_0);
case -1945196219: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -134101220: return bem_boolCcSet_1(bevd_0);
case -295878488: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1319066780: return bem_preClassSet_1(bevd_0);
case -1022643950: return bem_callNamesSet_1(bevd_0);
case 111490697: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 391809063: return bem_smnlecsSet_1(bevd_0);
case -1768679702: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 301931194: return bem_equals_1(bevd_0);
case -1059075650: return bem_lastMethodBodySizeSet_1(bevd_0);
case 2138463296: return bem_falseValueSet_1(bevd_0);
case -1068398459: return bem_buildSet_1(bevd_0);
case 1056609592: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1094817404: return bem_libEmitNameSet_1(bevd_0);
case 1927612532: return bem_propertyDecsSet_1(bevd_0);
case 1524828928: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1610968576: return bem_lastMethodsSizeSet_1(bevd_0);
case -995631439: return bem_fullLibEmitNameSet_1(bevd_0);
case -1649810875: return bem_maxDynArgsSet_1(bevd_0);
case -574760083: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1355165899: return bem_copyTo_1(bevd_0);
case -1106914660: return bem_gcMarksSet_1(bevd_0);
case 75157111: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1290351604: return bem_instanceNotEqualSet_1(bevd_0);
case 324289112: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -2076162537: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -731871147: return bem_def_1(bevd_0);
case 1177223859: return bem_nlSet_1(bevd_0);
case 1994796860: return bem_end_1(bevd_0);
case 1875973619: return bem_methodBodySet_1(bevd_0);
case -1439811606: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1166695769: return bem_ntypesSet_1(bevd_0);
case 1026207965: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1851383061: return bem_objectCcSet_1(bevd_0);
case 1840696756: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -359443761: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 45536613: return bem_libEmitPathSet_1(bevd_0);
case -1232712165: return bem_smnlcsSet_1(bevd_0);
case -1943883622: return bem_invpSet_1(bevd_0);
case -292957700: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1430536168: return bem_trueValueSet_1(bevd_0);
case 845196387: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -901715440: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1110421471: return bem_idToNameSet_1(bevd_0);
case -533699880: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 672018476: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1450178393: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1797824418: return bem_objectNpSet_1(bevd_0);
case -1073368483: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -183829283: return bem_transSet_1(bevd_0);
case 875394494: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1833921780: return bem_synEmitPathSet_1(bevd_0);
case -1497338836: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1277718220: return bem_nullValueSet_1(bevd_0);
case -1658320257: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 459939763: return bem_classConfSet_1(bevd_0);
case -1173678418: return bem_constSet_1(bevd_0);
case -788341625: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1718675487: return bem_inClassSet_1(bevd_0);
case -1013065753: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1815622140: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -501422696: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1322163114: return bem_nativeCSlotsSet_1(bevd_0);
case -2092141930: return bem_shlibeSet_1(bevd_0);
case -552786190: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1204890982: return bem_intNpSet_1(bevd_0);
case -1902029339: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 643060440: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1514446661: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 349576679: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -523180327: return bem_superCallsSet_1(bevd_0);
case -794453162: return bem_methodsSet_1(bevd_0);
case 1713177550: return bem_undef_1(bevd_0);
case 1743930065: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 22486223: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1037402078: return bem_ccCacheSet_1(bevd_0);
case 1713353720: return bem_stringNpSet_1(bevd_0);
case -233299509: return bem_methodCatchSet_1(bevd_0);
case 1540808601: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1299371672: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -527794535: return bem_emitLangSet_1(bevd_0);
case -345300334: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -191818346: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -2087350247: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 273319432: return bem_instanceEqualSet_1(bevd_0);
case -617178270: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1161759387: return bem_boolNpSet_1(bevd_0);
case 272676851: return bem_qSet_1(bevd_0);
case -1424125345: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -42304635: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 14926670: return bem_scvpSet_1(bevd_0);
case 180507430: return bem_parentConfSet_1(bevd_0);
case -1311468930: return bem_ccMethodsSet_1(bevd_0);
case -1632324182: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1624668280: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case 957352821: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1017425821: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1608669851: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 994562493: return bem_nameToIdSet_1(bevd_0);
case -505011339: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -182879054: return bem_notEquals_1(bevd_0);
case -1490784480: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 848530943: return bem_nameToIdPathSet_1(bevd_0);
case 1457154911: return bem_exceptDecSet_1(bevd_0);
case 242996131: return bem_maxSpillArgsLenSet_1(bevd_0);
case -2080164322: return bem_returnTypeSet_1(bevd_0);
case -789598060: return bem_begin_1(bevd_0);
case 1505594031: return bem_randSet_1(bevd_0);
case 1637320120: return bem_dynMethodsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1473620469: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1378156325: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2073859118: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 31731822: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2045785647: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -58283259: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1915461939: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1060856435: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1299754053: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1201235615: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1808641530: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945576771: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1548431016: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126940755: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1439750054: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -25358949: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1676733928: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 441633929: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1572738239: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1451483650: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1002511968: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 933261835: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1974024647: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1635679277: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1119195790: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
