package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_31, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_53, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_54, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_56, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_20, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_57, 38));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_58, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_60, 23));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 27));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_62, 32));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_65, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_66, 15));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_72, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_73, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_78, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formTarg_1(beva_node);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_invp);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1179204360);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2042759880);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(253761398);
bevt_9_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold );
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1069020754);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 81 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1186965043);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 81 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1001445809);
if (bevl_first.bevi_bool) /* Line: 82 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 83 */
 else  /* Line: 84 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 85 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 87 */
 else  /* Line: 81 */ {
break;
} /* Line: 81 */
} /* Line: 81 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(253761398);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_17_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_20_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_0_tmpany_phold = beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 132 */
bevt_4_tmpany_phold = super.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_110_tmpany_phold = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 148 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-1186965043);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 148 */ {
bevl_clnode = bevl_ci.bemd_0(1001445809);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_8_tmpany_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(1579422599);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(253761398);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(625547167);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(1579422599);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(253761398);
bevt_15_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold );
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(1579422599);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1069020754);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-539125426);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(1579422599);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(253761398);
bevt_26_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold );
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_33_tmpany_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(1579422599);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(1069020754);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-539125426);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 163 */ {
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_41_tmpany_phold = bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 164 */
} /* Line: 163 */
} /* Line: 154 */
 else  /* Line: 148 */ {
break;
} /* Line: 148 */
} /* Line: 148 */
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 172 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1186965043);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1001445809);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_52_tmpany_phold = bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_67_tmpany_phold = bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 175 */
 else  /* Line: 172 */ {
break;
} /* Line: 172 */
} /* Line: 172 */
bevl_libe.bem_write_1(bevl_smap);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_80_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_82_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_84_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 185 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_89_tmpany_phold = bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_94_tmpany_phold = bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 199 */
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_98_tmpany_phold = bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(-646385374);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_103_tmpany_phold = bevp_build.bem_doMainGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 203 */
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_104_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_104_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevt_106_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_105_tmpany_phold = bevl_main.bem_addValue_1(bevt_106_tmpany_phold);
bevt_105_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_108_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_107_tmpany_phold = bevl_main.bem_addValue_1(bevt_108_tmpany_phold);
bevt_107_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 210 */
bevt_109_tmpany_phold = bevp_build.bem_doMainGet_0();
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 213 */
bem_finishLibOutput_1(bevl_libe);
bevt_110_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_110_tmpany_phold.bevi_bool) /* Line: 218 */ {
bem_saveSyns_0();
} /* Line: 219 */
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 225 */ {
} /* Line: 225 */
 else  /* Line: 227 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 229 */
bevt_4_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 231 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1021205597);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1021205597);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 262 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 263 */
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 269 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 270 */
 else  /* Line: 271 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 272 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_8_tmpany_phold = bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1386188143);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 288 */ {
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(beva_callArgs);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 289 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
beva_callArgs = bevt_4_tmpany_phold.bem_add_1(beva_callArgs);
} /* Line: 290 */
 else  /* Line: 291 */ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
} /* Line: 292 */
bevt_10_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-646385374);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_callArgs);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_5_tmpany_phold;
} /* Line: 294 */
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_20_tmpany_phold = beva_callTarget.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = beva_node.bem_heldGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(-646385374);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_callArgs);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 308 */ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 309 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_7_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 328 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(1268193259);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 332 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 333 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1186965043);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 333 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1001445809);
bevt_17_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1268193259);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(1971213138);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(1157301587);
bevt_21_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 338 */
 else  /* Line: 333 */ {
break;
} /* Line: 333 */
} /* Line: 333 */
} /* Line: 333 */
} /* Line: 332 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_tmpany_phold = bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public final BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 63, 63, 63, 63, 63, 67, 67, 67, 67, 67, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 70, 70, 70, 75, 75, 76, 78, 78, 78, 78, 80, 81, 0, 81, 81, 83, 85, 85, 87, 87, 87, 87, 87, 87, 91, 91, 91, 96, 96, 96, 97, 99, 99, 99, 99, 99, 102, 102, 102, 102, 104, 104, 104, 106, 106, 106, 106, 106, 109, 109, 109, 109, 109, 109, 111, 111, 111, 113, 118, 119, 120, 126, 126, 126, 131, 132, 132, 132, 132, 134, 134, 143, 145, 146, 147, 148, 148, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 154, 154, 154, 156, 156, 156, 156, 156, 156, 156, 156, 156, 162, 162, 162, 162, 162, 162, 163, 163, 163, 164, 164, 164, 164, 164, 164, 170, 172, 172, 0, 172, 172, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 179, 182, 182, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 188, 189, 192, 193, 193, 194, 196, 197, 197, 197, 197, 197, 197, 197, 198, 199, 199, 199, 201, 201, 201, 201, 201, 201, 201, 201, 202, 203, 205, 206, 207, 208, 209, 209, 209, 210, 210, 210, 212, 213, 216, 218, 219, 225, 228, 228, 228, 229, 229, 231, 231, 236, 236, 240, 240, 240, 240, 240, 240, 244, 244, 248, 248, 248, 248, 248, 248, 248, 249, 249, 249, 249, 249, 250, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 265, 269, 269, 270, 270, 270, 272, 272, 274, 274, 274, 274, 274, 282, 282, 282, 283, 284, 288, 288, 289, 289, 290, 290, 292, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 296, 296, 296, 296, 296, 296, 296, 296, 296, 296, 296, 300, 301, 308, 308, 309, 311, 312, 312, 317, 317, 325, 325, 326, 327, 327, 327, 327, 327, 328, 328, 328, 330, 330, 330, 332, 332, 332, 333, 333, 333, 333, 0, 333, 333, 334, 334, 335, 335, 335, 336, 336, 337, 337, 338, 344, 348, 349, 354, 354, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 378, 378, 383, 383, 389, 389, 394, 394, 398, 398, 398, 398, 398, 398, 402, 402, 406, 406, 406, 406, 406, 411, 411, 411, 411, 411, 411, 411, 416, 416, 416, 416, 416, 416, 416, 418, 420, 420, 420, 425, 425, 429, 429, 433, 433, 433, 433, 438, 438, 442, 443, 443, 444, 448, 449, 449, 450, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {137, 138, 139, 140, 141, 142, 143, 144, 150, 151, 152, 158, 159, 160, 161, 167, 168, 169, 170, 180, 181, 182, 183, 184, 185, 186, 187, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 240, 241, 242, 243, 244, 245, 246, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 306, 307, 308, 309, 310, 311, 312, 313, 314, 314, 317, 319, 321, 324, 325, 327, 328, 329, 330, 331, 332, 338, 339, 340, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 403, 404, 405, 411, 412, 413, 422, 424, 425, 426, 427, 429, 430, 559, 560, 561, 562, 563, 566, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 611, 612, 613, 614, 615, 616, 624, 625, 626, 626, 629, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 669, 670, 671, 672, 673, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 705, 706, 707, 709, 710, 711, 712, 713, 714, 715, 716, 717, 719, 721, 722, 723, 724, 726, 727, 728, 729, 730, 731, 733, 735, 737, 738, 740, 750, 754, 755, 760, 761, 762, 764, 765, 771, 772, 780, 781, 782, 783, 784, 785, 789, 790, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 951, 956, 957, 958, 959, 962, 963, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 1003, 1004, 1006, 1007, 1009, 1010, 1013, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1042, 1043, 1048, 1053, 1054, 1056, 1057, 1058, 1062, 1063, 1094, 1099, 1100, 1101, 1102, 1103, 1104, 1109, 1110, 1111, 1112, 1114, 1115, 1116, 1117, 1118, 1119, 1121, 1122, 1123, 1124, 1124, 1127, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1147, 1150, 1151, 1156, 1157, 1161, 1162, 1166, 1167, 1171, 1172, 1176, 1177, 1181, 1182, 1186, 1187, 1191, 1192, 1196, 1197, 1201, 1202, 1210, 1211, 1212, 1213, 1214, 1215, 1219, 1220, 1227, 1228, 1229, 1230, 1231, 1240, 1241, 1242, 1243, 1244, 1245, 1246, 1257, 1258, 1259, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1267, 1272, 1273, 1277, 1278, 1284, 1285, 1286, 1287, 1291, 1292, 1297, 1298, 1299, 1300, 1305, 1306, 1307, 1308, 1311, 1314, 1317, 1321, 1325, 1328, 1331, 1335};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 137
new 0 16 137
assign 1 17 138
new 0 17 138
assign 1 18 139
new 0 18 139
new 1 22 140
assign 1 24 141
new 0 24 141
assign 1 25 142
new 0 25 142
assign 1 27 143
new 0 27 143
assign 1 28 144
new 0 28 144
assign 1 32 150
formTarg 1 32 150
assign 1 32 151
add 1 32 151
return 1 32 152
assign 1 36 158
formCallTarg 1 36 158
assign 1 36 159
new 0 36 159
assign 1 36 160
add 1 36 160
return 1 36 161
assign 1 40 167
formCallTarg 1 40 167
assign 1 40 168
new 0 40 168
assign 1 40 169
add 1 40 169
return 1 40 170
assign 1 44 180
new 0 44 180
assign 1 44 181
addValue 1 44 181
assign 1 44 182
secondGet 0 44 182
assign 1 44 183
formTarg 1 44 183
assign 1 44 184
addValue 1 44 184
assign 1 44 185
new 0 44 185
assign 1 44 186
addValue 1 44 186
addValue 1 44 187
assign 1 48 208
new 0 48 208
assign 1 48 209
toString 0 48 209
assign 1 48 210
add 1 48 210
incrementValue 0 49 211
assign 1 50 212
new 0 50 212
assign 1 50 213
addValue 1 50 213
assign 1 50 214
addValue 1 50 214
assign 1 50 215
new 0 50 215
assign 1 50 216
addValue 1 50 216
addValue 1 50 217
assign 1 55 218
containedGet 0 55 218
assign 1 55 219
firstGet 0 55 219
assign 1 55 220
containedGet 0 55 220
assign 1 55 221
firstGet 0 55 221
assign 1 55 222
new 0 55 222
assign 1 55 223
add 1 55 223
assign 1 55 224
new 0 55 224
assign 1 55 225
add 1 55 225
assign 1 55 226
finalAssign 4 55 226
addValue 1 55 227
assign 1 63 240
emitNameGet 0 63 240
assign 1 63 241
addValue 1 63 241
assign 1 63 242
new 0 63 242
assign 1 63 243
addValue 1 63 243
assign 1 63 244
addValue 1 63 244
assign 1 63 245
new 0 63 245
addValue 1 63 246
assign 1 67 266
emitNameGet 0 67 266
assign 1 67 267
addValue 1 67 267
assign 1 67 268
new 0 67 268
assign 1 67 269
addValue 1 67 269
addValue 1 67 270
assign 1 68 271
new 0 68 271
assign 1 68 272
addValue 1 68 272
assign 1 68 273
heldGet 0 68 273
assign 1 68 274
namepathGet 0 68 274
assign 1 68 275
getClassConfig 1 68 275
assign 1 68 276
libNameGet 0 68 276
assign 1 68 277
relEmitName 1 68 277
assign 1 68 278
addValue 1 68 278
assign 1 68 279
new 0 68 279
assign 1 68 280
addValue 1 68 280
addValue 1 68 281
assign 1 70 282
new 0 70 282
assign 1 70 283
addValue 1 70 283
addValue 1 70 284
assign 1 75 306
heldGet 0 75 306
assign 1 75 307
synGet 0 75 307
assign 1 76 308
ptyListGet 0 76 308
assign 1 78 309
emitNameGet 0 78 309
assign 1 78 310
addValue 1 78 310
assign 1 78 311
new 0 78 311
addValue 1 78 312
assign 1 80 313
new 0 80 313
assign 1 81 314
iteratorGet 0 0 314
assign 1 81 317
hasNextGet 0 81 317
assign 1 81 319
nextGet 0 81 319
assign 1 83 321
new 0 83 321
assign 1 85 324
new 0 85 324
addValue 1 85 325
assign 1 87 327
addValue 1 87 327
assign 1 87 328
new 0 87 328
assign 1 87 329
addValue 1 87 329
assign 1 87 330
nameGet 0 87 330
assign 1 87 331
addValue 1 87 331
addValue 1 87 332
assign 1 91 338
new 0 91 338
assign 1 91 339
addValue 1 91 339
addValue 1 91 340
assign 1 96 368
heldGet 0 96 368
assign 1 96 369
namepathGet 0 96 369
assign 1 96 370
getClassConfig 1 96 370
assign 1 97 371
getInitialInst 1 97 371
assign 1 99 372
emitNameGet 0 99 372
assign 1 99 373
addValue 1 99 373
assign 1 99 374
new 0 99 374
assign 1 99 375
addValue 1 99 375
addValue 1 99 376
assign 1 102 377
addValue 1 102 377
assign 1 102 378
new 0 102 378
assign 1 102 379
addValue 1 102 379
addValue 1 102 380
assign 1 104 381
new 0 104 381
assign 1 104 382
addValue 1 104 382
addValue 1 104 383
assign 1 106 384
emitNameGet 0 106 384
assign 1 106 385
addValue 1 106 385
assign 1 106 386
new 0 106 386
assign 1 106 387
addValue 1 106 387
addValue 1 106 388
assign 1 109 389
new 0 109 389
assign 1 109 390
addValue 1 109 390
assign 1 109 391
addValue 1 109 391
assign 1 109 392
new 0 109 392
assign 1 109 393
addValue 1 109 393
addValue 1 109 394
assign 1 111 395
new 0 111 395
assign 1 111 396
addValue 1 111 396
addValue 1 111 397
buildPropList 0 113 398
getCode 2 118 403
assign 1 119 404
toString 0 119 404
addValue 1 120 405
assign 1 126 411
new 0 126 411
assign 1 126 412
addValue 1 126 412
addValue 1 126 413
assign 1 131 422
isPropertyGet 0 131 422
assign 1 132 424
new 0 132 424
assign 1 132 425
nameGet 0 132 425
assign 1 132 426
add 1 132 426
return 1 132 427
assign 1 134 429
nameForVar 1 134 429
return 1 134 430
assign 1 143 559
getLibOutput 0 143 559
assign 1 145 560
new 0 145 560
assign 1 146 561
new 0 146 561
assign 1 147 562
new 0 147 562
assign 1 148 563
iteratorGet 0 148 563
assign 1 148 566
hasNextGet 0 148 566
assign 1 150 568
nextGet 0 150 568
assign 1 152 569
new 0 152 569
assign 1 152 570
addValue 1 152 570
assign 1 152 571
addValue 1 152 571
assign 1 152 572
heldGet 0 152 572
assign 1 152 573
namepathGet 0 152 573
assign 1 152 574
toString 0 152 574
assign 1 152 575
addValue 1 152 575
assign 1 152 576
addValue 1 152 576
assign 1 152 577
new 0 152 577
assign 1 152 578
addValue 1 152 578
assign 1 152 579
heldGet 0 152 579
assign 1 152 580
namepathGet 0 152 580
assign 1 152 581
getClassConfig 1 152 581
assign 1 152 582
libNameGet 0 152 582
assign 1 152 583
relEmitName 1 152 583
assign 1 152 584
addValue 1 152 584
assign 1 152 585
new 0 152 585
assign 1 152 586
addValue 1 152 586
addValue 1 152 587
assign 1 154 588
heldGet 0 154 588
assign 1 154 589
synGet 0 154 589
assign 1 154 590
hasDefaultGet 0 154 590
assign 1 156 592
new 0 156 592
assign 1 156 593
heldGet 0 156 593
assign 1 156 594
namepathGet 0 156 594
assign 1 156 595
getClassConfig 1 156 595
assign 1 156 596
libNameGet 0 156 596
assign 1 156 597
relEmitName 1 156 597
assign 1 156 598
add 1 156 598
assign 1 156 599
new 0 156 599
assign 1 156 600
add 1 156 600
assign 1 162 601
new 0 162 601
assign 1 162 602
addValue 1 162 602
assign 1 162 603
addValue 1 162 603
assign 1 162 604
new 0 162 604
assign 1 162 605
addValue 1 162 605
addValue 1 162 606
assign 1 163 607
heldGet 0 163 607
assign 1 163 608
synGet 0 163 608
assign 1 163 609
hasDefaultGet 0 163 609
assign 1 164 611
new 0 164 611
assign 1 164 612
addValue 1 164 612
assign 1 164 613
addValue 1 164 613
assign 1 164 614
new 0 164 614
assign 1 164 615
addValue 1 164 615
addValue 1 164 616
assign 1 170 624
new 0 170 624
assign 1 172 625
keysGet 0 172 625
assign 1 172 626
iteratorGet 0 0 626
assign 1 172 629
hasNextGet 0 172 629
assign 1 172 631
nextGet 0 172 631
assign 1 174 632
new 0 174 632
assign 1 174 633
addValue 1 174 633
assign 1 174 634
new 0 174 634
assign 1 174 635
quoteGet 0 174 635
assign 1 174 636
addValue 1 174 636
assign 1 174 637
addValue 1 174 637
assign 1 174 638
new 0 174 638
assign 1 174 639
quoteGet 0 174 639
assign 1 174 640
addValue 1 174 640
assign 1 174 641
new 0 174 641
assign 1 174 642
addValue 1 174 642
assign 1 174 643
get 1 174 643
assign 1 174 644
addValue 1 174 644
assign 1 174 645
new 0 174 645
assign 1 174 646
addValue 1 174 646
addValue 1 174 647
assign 1 175 648
new 0 175 648
assign 1 175 649
addValue 1 175 649
assign 1 175 650
new 0 175 650
assign 1 175 651
quoteGet 0 175 651
assign 1 175 652
addValue 1 175 652
assign 1 175 653
addValue 1 175 653
assign 1 175 654
new 0 175 654
assign 1 175 655
quoteGet 0 175 655
assign 1 175 656
addValue 1 175 656
assign 1 175 657
new 0 175 657
assign 1 175 658
addValue 1 175 658
assign 1 175 659
get 1 175 659
assign 1 175 660
addValue 1 175 660
assign 1 175 661
new 0 175 661
assign 1 175 662
addValue 1 175 662
addValue 1 175 663
write 1 179 669
assign 1 182 670
usedLibrarysGet 0 182 670
assign 1 182 671
sizeGet 0 182 671
assign 1 182 672
new 0 182 672
assign 1 182 673
equals 1 182 678
assign 1 183 679
new 0 183 679
assign 1 183 680
addValue 1 183 680
addValue 1 183 681
assign 1 184 682
new 0 184 682
assign 1 184 683
addValue 1 184 683
addValue 1 184 684
assign 1 185 685
new 0 185 685
assign 1 185 686
addValue 1 185 686
addValue 1 185 687
write 1 188 689
write 1 189 690
assign 1 192 691
new 0 192 691
assign 1 193 692
mainNameGet 0 193 692
fromString 1 193 693
assign 1 194 694
getClassConfig 1 194 694
assign 1 196 695
new 0 196 695
assign 1 197 696
new 0 197 696
assign 1 197 697
addValue 1 197 697
assign 1 197 698
fullEmitNameGet 0 197 698
assign 1 197 699
addValue 1 197 699
assign 1 197 700
new 0 197 700
assign 1 197 701
addValue 1 197 701
addValue 1 197 702
assign 1 198 703
ownProcessGet 0 198 703
assign 1 199 705
new 0 199 705
assign 1 199 706
addValue 1 199 706
addValue 1 199 707
assign 1 201 709
new 0 201 709
assign 1 201 710
addValue 1 201 710
assign 1 201 711
outputPlatformGet 0 201 711
assign 1 201 712
nameGet 0 201 712
assign 1 201 713
addValue 1 201 713
assign 1 201 714
new 0 201 714
assign 1 201 715
addValue 1 201 715
addValue 1 201 716
assign 1 202 717
doMainGet 0 202 717
write 1 203 719
assign 1 205 721
new 0 205 721
write 1 206 722
write 1 207 723
assign 1 208 724
ownProcessGet 0 208 724
assign 1 209 726
new 0 209 726
assign 1 209 727
addValue 1 209 727
addValue 1 209 728
assign 1 210 729
new 0 210 729
assign 1 210 730
addValue 1 210 730
addValue 1 210 731
assign 1 212 733
doMainGet 0 212 733
write 1 213 735
finishLibOutput 1 216 737
assign 1 218 738
saveSynsGet 0 218 738
saveSyns 0 219 740
assign 1 225 750
isPropertyGet 0 225 750
assign 1 228 754
isArgGet 0 228 754
assign 1 228 755
not 0 228 760
assign 1 229 761
new 0 229 761
addValue 1 229 762
assign 1 231 764
nameForVar 1 231 764
addValue 1 231 765
assign 1 236 771
new 0 236 771
return 1 236 772
assign 1 240 780
new 0 240 780
assign 1 240 781
add 1 240 781
assign 1 240 782
new 0 240 782
assign 1 240 783
add 1 240 783
assign 1 240 784
add 1 240 784
return 1 240 785
assign 1 244 789
new 0 244 789
return 1 244 790
assign 1 248 804
emitNameGet 0 248 804
assign 1 248 805
new 0 248 805
assign 1 248 806
add 1 248 806
assign 1 248 807
add 1 248 807
assign 1 248 808
new 0 248 808
assign 1 248 809
add 1 248 809
assign 1 248 810
addValue 1 248 810
assign 1 249 811
emitNameGet 0 249 811
assign 1 249 812
add 1 249 812
assign 1 249 813
new 0 249 813
assign 1 249 814
add 1 249 814
assign 1 249 815
addValue 1 249 815
return 1 250 816
assign 1 254 830
new 0 254 830
assign 1 254 831
libNameGet 0 254 831
assign 1 254 832
relEmitName 1 254 832
assign 1 254 833
add 1 254 833
assign 1 254 834
new 0 254 834
assign 1 254 835
add 1 254 835
assign 1 254 836
heldGet 0 254 836
assign 1 254 837
literalValueGet 0 254 837
assign 1 254 838
add 1 254 838
assign 1 254 839
new 0 254 839
assign 1 254 840
add 1 254 840
return 1 254 841
assign 1 258 855
new 0 258 855
assign 1 258 856
libNameGet 0 258 856
assign 1 258 857
relEmitName 1 258 857
assign 1 258 858
add 1 258 858
assign 1 258 859
new 0 258 859
assign 1 258 860
add 1 258 860
assign 1 258 861
heldGet 0 258 861
assign 1 258 862
literalValueGet 0 258 862
assign 1 258 863
add 1 258 863
assign 1 258 864
new 0 258 864
assign 1 258 865
add 1 258 865
return 1 258 866
assign 1 263 902
new 0 263 902
assign 1 263 903
libNameGet 0 263 903
assign 1 263 904
relEmitName 1 263 904
assign 1 263 905
add 1 263 905
assign 1 263 906
new 0 263 906
assign 1 263 907
add 1 263 907
assign 1 263 908
emitNameGet 0 263 908
assign 1 263 909
add 1 263 909
assign 1 263 910
new 0 263 910
assign 1 263 911
add 1 263 911
assign 1 263 912
add 1 263 912
assign 1 263 913
new 0 263 913
assign 1 263 914
add 1 263 914
assign 1 263 915
add 1 263 915
assign 1 263 916
new 0 263 916
assign 1 263 917
add 1 263 917
return 1 263 918
assign 1 265 920
new 0 265 920
assign 1 265 921
libNameGet 0 265 921
assign 1 265 922
relEmitName 1 265 922
assign 1 265 923
add 1 265 923
assign 1 265 924
new 0 265 924
assign 1 265 925
add 1 265 925
assign 1 265 926
emitNameGet 0 265 926
assign 1 265 927
add 1 265 927
assign 1 265 928
new 0 265 928
assign 1 265 929
add 1 265 929
assign 1 265 930
add 1 265 930
assign 1 265 931
new 0 265 931
assign 1 265 932
add 1 265 932
assign 1 265 933
add 1 265 933
assign 1 265 934
new 0 265 934
assign 1 265 935
add 1 265 935
return 1 265 936
assign 1 269 951
def 1 269 956
assign 1 270 957
libNameGet 0 270 957
assign 1 270 958
relEmitName 1 270 958
assign 1 270 959
extend 1 270 959
assign 1 272 962
new 0 272 962
assign 1 272 963
extend 1 272 963
assign 1 274 965
new 0 274 965
assign 1 274 966
emitNameGet 0 274 966
assign 1 274 967
addValue 1 274 967
assign 1 274 968
new 0 274 968
assign 1 274 969
addValue 1 274 969
assign 1 282 970
new 0 282 970
assign 1 282 971
addValue 1 282 971
addValue 1 282 972
addValue 1 283 973
return 1 284 974
assign 1 288 1003
heldGet 0 288 1003
assign 1 288 1004
superCallGet 0 288 1004
assign 1 289 1006
new 0 289 1006
assign 1 289 1007
notEmpty 1 289 1007
assign 1 290 1009
new 0 290 1009
assign 1 290 1010
add 1 290 1010
assign 1 292 1013
new 0 292 1013
assign 1 294 1015
emitNameGet 0 294 1015
assign 1 294 1016
new 0 294 1016
assign 1 294 1017
add 1 294 1017
assign 1 294 1018
heldGet 0 294 1018
assign 1 294 1019
nameGet 0 294 1019
assign 1 294 1020
add 1 294 1020
assign 1 294 1021
new 0 294 1021
assign 1 294 1022
add 1 294 1022
assign 1 294 1023
add 1 294 1023
assign 1 294 1024
new 0 294 1024
assign 1 294 1025
add 1 294 1025
return 1 294 1026
assign 1 296 1028
new 0 296 1028
assign 1 296 1029
add 1 296 1029
assign 1 296 1030
heldGet 0 296 1030
assign 1 296 1031
nameGet 0 296 1031
assign 1 296 1032
add 1 296 1032
assign 1 296 1033
new 0 296 1033
assign 1 296 1034
add 1 296 1034
assign 1 296 1035
add 1 296 1035
assign 1 296 1036
new 0 296 1036
assign 1 296 1037
add 1 296 1037
return 1 296 1038
assign 1 300 1042
new 0 300 1042
return 1 301 1043
assign 1 308 1048
undef 1 308 1053
assign 1 309 1054
new 0 309 1054
addValue 1 311 1056
assign 1 312 1057
new 0 312 1057
return 1 312 1058
assign 1 317 1062
getLibOutput 0 317 1062
return 1 317 1063
assign 1 325 1094
undef 1 325 1099
assign 1 326 1100
new 0 326 1100
assign 1 327 1101
parentGet 0 327 1101
assign 1 327 1102
fileGet 0 327 1102
assign 1 327 1103
existsGet 0 327 1103
assign 1 327 1104
not 0 327 1109
assign 1 328 1110
parentGet 0 328 1110
assign 1 328 1111
fileGet 0 328 1111
makeDirs 0 328 1112
assign 1 330 1114
fileGet 0 330 1114
assign 1 330 1115
writerGet 0 330 1115
assign 1 330 1116
open 0 330 1116
assign 1 332 1117
paramsGet 0 332 1117
assign 1 332 1118
new 0 332 1118
assign 1 332 1119
has 1 332 1119
assign 1 333 1121
paramsGet 0 333 1121
assign 1 333 1122
new 0 333 1122
assign 1 333 1123
get 1 333 1123
assign 1 333 1124
iteratorGet 0 0 1124
assign 1 333 1127
hasNextGet 0 333 1127
assign 1 333 1129
nextGet 0 333 1129
assign 1 334 1130
apNew 1 334 1130
assign 1 334 1131
fileGet 0 334 1131
assign 1 335 1132
readerGet 0 335 1132
assign 1 335 1133
open 0 335 1133
assign 1 335 1134
readString 0 335 1134
assign 1 336 1135
readerGet 0 336 1135
close 0 336 1136
assign 1 337 1137
countLines 1 337 1137
addValue 1 337 1138
write 1 338 1139
return 1 344 1147
close 0 348 1150
assign 1 349 1151
assign 1 354 1156
new 0 354 1156
return 1 354 1157
assign 1 358 1161
new 0 358 1161
return 1 358 1162
assign 1 362 1166
new 0 362 1166
return 1 362 1167
assign 1 366 1171
new 0 366 1171
return 1 366 1172
assign 1 370 1176
new 0 370 1176
return 1 370 1177
assign 1 374 1181
new 0 374 1181
return 1 374 1182
assign 1 378 1186
new 0 378 1186
return 1 378 1187
assign 1 383 1191
new 0 383 1191
return 1 383 1192
assign 1 389 1196
new 0 389 1196
return 1 389 1197
assign 1 394 1201
new 0 394 1201
return 1 394 1202
assign 1 398 1210
new 0 398 1210
assign 1 398 1211
add 1 398 1211
assign 1 398 1212
new 0 398 1212
assign 1 398 1213
add 1 398 1213
assign 1 398 1214
add 1 398 1214
return 1 398 1215
assign 1 402 1219
new 0 402 1219
return 1 402 1220
assign 1 406 1227
libNameGet 0 406 1227
assign 1 406 1228
relEmitName 1 406 1228
assign 1 406 1229
new 0 406 1229
assign 1 406 1230
add 1 406 1230
return 1 406 1231
assign 1 411 1240
emitNameGet 0 411 1240
assign 1 411 1241
new 0 411 1241
assign 1 411 1242
add 1 411 1242
assign 1 411 1243
new 0 411 1243
assign 1 411 1244
add 1 411 1244
assign 1 411 1245
add 1 411 1245
return 1 411 1246
assign 1 416 1257
emitNameGet 0 416 1257
assign 1 416 1258
addValue 1 416 1258
assign 1 416 1259
new 0 416 1259
assign 1 416 1260
addValue 1 416 1260
assign 1 416 1261
addValue 1 416 1261
assign 1 416 1262
new 0 416 1262
addValue 1 416 1263
addValue 1 418 1264
assign 1 420 1265
new 0 420 1265
assign 1 420 1266
addValue 1 420 1266
addValue 1 420 1267
assign 1 425 1272
new 0 425 1272
return 1 425 1273
assign 1 429 1277
new 0 429 1277
return 1 429 1278
assign 1 433 1284
new 0 433 1284
assign 1 433 1285
add 1 433 1285
assign 1 433 1286
add 1 433 1286
return 1 433 1287
assign 1 438 1291
new 0 438 1291
return 1 438 1292
assign 1 442 1297
getClassConfig 1 442 1297
assign 1 443 1298
fullEmitNameGet 0 443 1298
emitNameSet 1 443 1299
return 1 444 1300
assign 1 448 1305
getLocalClassConfig 1 448 1305
assign 1 449 1306
fullEmitNameGet 0 449 1306
emitNameSet 1 449 1307
return 1 450 1308
return 1 0 1311
return 1 0 1314
assign 1 0 1317
assign 1 0 1321
return 1 0 1325
return 1 0 1328
assign 1 0 1331
assign 1 0 1335
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 762626713: return bem_invpGet_0();
case 14602800: return bem_mnodeGet_0();
case -262466587: return bem_dynMethodsGet_0();
case -1121634438: return bem_ntypesGetDirect_0();
case 1242421487: return bem_transGet_0();
case -38042496: return bem_nameToIdGetDirect_0();
case -1507890122: return bem_libEmitPathGetDirect_0();
case 1637341564: return bem_preClassOutput_0();
case 448917349: return bem_gcMarksGetDirect_0();
case -567505377: return bem_parentConfGetDirect_0();
case 806795805: return bem_classCallsGet_0();
case 1419461318: return bem_stringNpGet_0();
case 2055550833: return bem_objectNpGetDirect_0();
case -2014841986: return bem_ccCacheGet_0();
case -1432222666: return bem_classCallsGetDirect_0();
case -8059182: return bem_maxSpillArgsLenGetDirect_0();
case 129806181: return bem_superNameGet_0();
case -1491091683: return bem_buildPropList_0();
case 610287972: return bem_superCallsGetDirect_0();
case 2024262513: return bem_callNamesGet_0();
case -1044078638: return bem_trueValueGet_0();
case 195815026: return bem_randGet_0();
case -545885409: return bem_fieldNamesGet_0();
case -437401677: return bem_propDecGet_0();
case 823986744: return bem_inClassGet_0();
case 930506719: return bem_intNpGetDirect_0();
case 678571136: return bem_many_0();
case -221579259: return bem_maxDynArgsGet_0();
case -212638835: return bem_lastCallGetDirect_0();
case 750032035: return bem_lineCountGetDirect_0();
case 1457416126: return bem_saveIds_0();
case 242939144: return bem_allOnceDecsGet_0();
case 322973431: return bem_print_0();
case 911647168: return bem_callNamesGetDirect_0();
case -1815398055: return bem_methodsGetDirect_0();
case 831531339: return bem_gcMarksGet_0();
case 2122497827: return bem_methodCallsGet_0();
case -163770727: return bem_lastCallGet_0();
case -1184638374: return bem_belslitsGetDirect_0();
case -527327101: return bem_floatNpGetDirect_0();
case -675424880: return bem_exceptDecGet_0();
case 1751425308: return bem_csynGet_0();
case 597357534: return bem_tagGet_0();
case 873874683: return bem_methodCatchGet_0();
case -1658567016: return bem_instanceEqualGet_0();
case 206920291: return bem_ccMethodsGet_0();
case 2035323909: return bem_classEndGet_0();
case -2097301657: return bem_boolCcGet_0();
case 1215450195: return bem_lineCountGet_0();
case -1110799888: return bem_lastMethodBodySizeGetDirect_0();
case 550989691: return bem_mainEndGet_0();
case -660176157: return bem_useDynMethodsGet_0();
case 1264233769: return bem_inFilePathedGet_0();
case -1668138220: return bem_doEmit_0();
case -978042141: return bem_idToNameGetDirect_0();
case 479265473: return bem_nlGet_0();
case 1361267546: return bem_libEmitNameGet_0();
case 1244351569: return bem_smnlcsGet_0();
case 814905688: return bem_ccMethodsGetDirect_0();
case -879214192: return bem_buildGet_0();
case -84373690: return bem_spropDecGet_0();
case -217002931: return bem_returnTypeGetDirect_0();
case 1289072735: return bem_onceDecsGet_0();
case -206365449: return bem_instanceNotEqualGet_0();
case -227311207: return bem_baseMtdDecGet_0();
case -354958887: return bem_nativeCSlotsGet_0();
case -84408331: return bem_scvpGetDirect_0();
case -1179064487: return bem_superCallsGet_0();
case -608212052: return bem_onceCountGetDirect_0();
case -1133232925: return bem_cnodeGetDirect_0();
case 1036851739: return bem_emitLib_0();
case 1304271591: return bem_afterCast_0();
case 305055544: return bem_transGetDirect_0();
case 625547167: return bem_toString_0();
case 291309239: return bem_once_0();
case 2123765846: return bem_nameToIdPathGetDirect_0();
case -702127640: return bem_beginNs_0();
case 305613993: return bem_sourceFileNameGet_0();
case -1607299603: return bem_synEmitPathGet_0();
case -1101326644: return bem_serializeContents_0();
case 1461724031: return bem_copy_0();
case 293241724: return bem_objectCcGet_0();
case -1374957753: return bem_scvpGet_0();
case -1517405787: return bem_saveSyns_0();
case 1313450605: return bem_objectCcGetDirect_0();
case 2127564854: return bem_classConfGetDirect_0();
case 47649203: return bem_smnlecsGetDirect_0();
case -1732500583: return bem_lastMethodsLinesGetDirect_0();
case -2051803278: return bem_exceptDecGetDirect_0();
case 1002715198: return bem_shlibeGetDirect_0();
case 364235321: return bem_echo_0();
case -304415890: return bem_classNameGet_0();
case -680811989: return bem_libEmitNameGetDirect_0();
case -711168741: return bem_instOfGetDirect_0();
case -1569222986: return bem_fieldIteratorGet_0();
case 999477961: return bem_lastMethodBodySizeGet_0();
case -1132703219: return bem_nullValueGetDirect_0();
case -431916258: return bem_buildClassInfo_0();
case -46451121: return bem_synEmitPathGetDirect_0();
case 651763520: return bem_constGet_0();
case 2050059376: return bem_iteratorGet_0();
case -1380385181: return bem_smnlcsGetDirect_0();
case -2112551590: return bem_objectNpGet_0();
case -1394056248: return bem_idToNamePathGet_0();
case 1954751090: return bem_emitLangGet_0();
case 27434785: return bem_newDecGet_0();
case 1289647520: return bem_invpGetDirect_0();
case -1330083450: return bem_classEmitsGet_0();
case 694213554: return bem_boolCcGetDirect_0();
case 148155993: return bem_idToNamePathGetDirect_0();
case -547872543: return bem_runtimeInitGet_0();
case 1424086851: return bem_qGetDirect_0();
case 1248512101: return bem_fullLibEmitNameGet_0();
case 1913022823: return bem_baseSmtdDecGet_0();
case 659697241: return bem_buildCreate_0();
case 690399070: return bem_nativeCSlotsGetDirect_0();
case -1185270250: return bem_ntypesGet_0();
case -1087766017: return bem_serializeToString_0();
case -875742486: return bem_libEmitPathGet_0();
case 2099470513: return bem_endNs_0();
case -788571552: return bem_fullLibEmitNameGetDirect_0();
case -1128980013: return bem_lastMethodBodyLinesGetDirect_0();
case -554112237: return bem_classesInDepthOrderGet_0();
case 224727242: return bem_classEmitsGetDirect_0();
case 863097359: return bem_belslitsGet_0();
case 946237293: return bem_onceDecsGetDirect_0();
case 1928435140: return bem_fileExtGetDirect_0();
case -1892328282: return bem_nullValueGet_0();
case 576955950: return bem_methodCallsGetDirect_0();
case 1558495022: return bem_mainInClassGet_0();
case -713475106: return bem_smnlecsGet_0();
case 657156563: return bem_boolTypeGet_0();
case 1333606718: return bem_floatNpGet_0();
case -43502949: return bem_toAny_0();
case -2129237808: return bem_allOnceDecsGetDirect_0();
case -558990509: return bem_idToNameGet_0();
case 1746075234: return bem_lastMethodBodyLinesGet_0();
case 1851036145: return bem_serializationIteratorGet_0();
case -2118452853: return bem_overrideMtdDecGet_0();
case -608595936: return bem_methodBodyGet_0();
case 421480163: return bem_falseValueGetDirect_0();
case -1696513818: return bem_emitLangGetDirect_0();
case 818812593: return bem_mnodeGetDirect_0();
case 80136932: return bem_getLibOutput_0();
case -1160115097: return bem_shlibeGet_0();
case -381740729: return bem_deserializeClassNameGet_0();
case -362887363: return bem_lastMethodsSizeGetDirect_0();
case -208970472: return bem_msynGetDirect_0();
case -1266550419: return bem_boolNpGet_0();
case -777338417: return bem_classConfGet_0();
case 75735828: return bem_preClassGetDirect_0();
case 1230035770: return bem_onceCountGet_0();
case 1807883746: return bem_falseValueGet_0();
case -753644705: return bem_hashGet_0();
case -410783155: return bem_new_0();
case -958155152: return bem_buildInitial_0();
case -909675958: return bem_create_0();
case -1250843579: return bem_maxDynArgsGetDirect_0();
case -289522478: return bem_typeDecGet_0();
case -578139033: return bem_csynGetDirect_0();
case 2089454684: return bem_methodsGet_0();
case -418503404: return bem_methodBodyGetDirect_0();
case 1097858408: return bem_parentConfGet_0();
case 1030943064: return bem_dynMethodsGetDirect_0();
case 1939512414: return bem_stringNpGetDirect_0();
case 921988836: return bem_ccCacheGetDirect_0();
case -424645755: return bem_initialDecGet_0();
case -1887595123: return bem_instOfGet_0();
case -1069496905: return bem_fileExtGet_0();
case 63627328: return bem_writeBET_0();
case 503585316: return bem_methodCatchGetDirect_0();
case -1629859308: return bem_nlGetDirect_0();
case -410087062: return bem_maxSpillArgsLenGet_0();
case 1172767050: return bem_inFilePathedGetDirect_0();
case -953547237: return bem_msynGet_0();
case -1897442334: return bem_getClassOutput_0();
case -788901832: return bem_intNpGet_0();
case -1699547846: return bem_preClassGet_0();
case -1632710927: return bem_constGetDirect_0();
case 261986256: return bem_classesInDepthOrderGetDirect_0();
case 982109726: return bem_cnodeGet_0();
case 2144192580: return bem_lastMethodsSizeGet_0();
case -301672494: return bem_loadIds_0();
case -774374478: return bem_trueValueGetDirect_0();
case -446495243: return bem_returnTypeGet_0();
case -1351830312: return bem_mainOutsideNsGet_0();
case 202367645: return bem_covariantReturnsGet_0();
case 1479584649: return bem_qGet_0();
case -492097839: return bem_boolNpGetDirect_0();
case 1440701563: return bem_nameToIdGet_0();
case -1978659420: return bem_lastMethodsLinesGet_0();
case 1226275067: return bem_randGetDirect_0();
case 726058466: return bem_propertyDecsGet_0();
case -1531417353: return bem_buildGetDirect_0();
case -1928000045: return bem_mainStartGet_0();
case 275431583: return bem_inClassGetDirect_0();
case -1952274159: return bem_instanceNotEqualGetDirect_0();
case -1742433967: return bem_propertyDecsGetDirect_0();
case 482602273: return bem_nameToIdPathGet_0();
case -1163186971: return bem_instanceEqualGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1903861648: return bem_end_1(bevd_0);
case -1575029220: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case 1440361342: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -169577234: return bem_onceCountSetDirect_1(bevd_0);
case 1165845717: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1874715471: return bem_idToNameSet_1(bevd_0);
case 581347956: return bem_trueValueSetDirect_1(bevd_0);
case 235803718: return bem_lastMethodsLinesSet_1(bevd_0);
case 1166889563: return bem_objectNpSet_1(bevd_0);
case 1843718682: return bem_csynSet_1(bevd_0);
case -1399216026: return bem_inClassSetDirect_1(bevd_0);
case -1382254537: return bem_nameToIdSetDirect_1(bevd_0);
case -1226936976: return bem_intNpSetDirect_1(bevd_0);
case 529739919: return bem_classEmitsSet_1(bevd_0);
case -103953232: return bem_nlSet_1(bevd_0);
case -1599361109: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1306103741: return bem_qSetDirect_1(bevd_0);
case -1460435431: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -326630716: return bem_instanceNotEqualSet_1(bevd_0);
case -1905892341: return bem_gcMarksSetDirect_1(bevd_0);
case -78565799: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1969967243: return bem_onceDecsSetDirect_1(bevd_0);
case 1868902305: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1881830012: return bem_randSetDirect_1(bevd_0);
case -1950611063: return bem_libEmitPathSet_1(bevd_0);
case -1549872908: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1044240808: return bem_msynSetDirect_1(bevd_0);
case 1858478424: return bem_cnodeSet_1(bevd_0);
case -428541332: return bem_mnodeSet_1(bevd_0);
case 1700183538: return bem_boolCcSetDirect_1(bevd_0);
case -1949529196: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case -1673361452: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1378106358: return bem_idToNameSetDirect_1(bevd_0);
case 2005991010: return bem_nameToIdPathSetDirect_1(bevd_0);
case 161267542: return bem_falseValueSetDirect_1(bevd_0);
case -24000032: return bem_superCallsSet_1(bevd_0);
case -1948338449: return bem_objectNpSetDirect_1(bevd_0);
case 566551847: return bem_ntypesSetDirect_1(bevd_0);
case -1363674143: return bem_callNamesSetDirect_1(bevd_0);
case -964395879: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1353038815: return bem_lineCountSetDirect_1(bevd_0);
case -1784357711: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1569056908: return bem_libEmitNameSet_1(bevd_0);
case -1498809597: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -815020427: return bem_fileExtSetDirect_1(bevd_0);
case -462407267: return bem_returnTypeSetDirect_1(bevd_0);
case -52916209: return bem_dynMethodsSetDirect_1(bevd_0);
case -2048763380: return bem_methodCatchSet_1(bevd_0);
case -2062811605: return bem_synEmitPathSetDirect_1(bevd_0);
case 1015127138: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1546813089: return bem_shlibeSetDirect_1(bevd_0);
case -1125130757: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 2106236866: return bem_allOnceDecsSet_1(bevd_0);
case -979238469: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1708841113: return bem_propertyDecsSetDirect_1(bevd_0);
case -1447137700: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -711407389: return bem_qSet_1(bevd_0);
case 1084452576: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 666560783: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2096805338: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 953223163: return bem_exceptDecSet_1(bevd_0);
case 218786300: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -212248841: return bem_floatNpSet_1(bevd_0);
case 1717523708: return bem_lastMethodsSizeSet_1(bevd_0);
case 2001016535: return bem_instOfSetDirect_1(bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case -409000329: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -135745925: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -425878728: return bem_methodCallsSet_1(bevd_0);
case 1401759978: return bem_classesInDepthOrderSet_1(bevd_0);
case -685949400: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1036865828: return bem_begin_1(bevd_0);
case 752790340: return bem_callNamesSet_1(bevd_0);
case -818664461: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 990456960: return bem_nlSetDirect_1(bevd_0);
case 309690044: return bem_objectCcSetDirect_1(bevd_0);
case 1084164925: return bem_classCallsSetDirect_1(bevd_0);
case -108975222: return bem_classConfSet_1(bevd_0);
case -1505757698: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1271753676: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1198689059: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 991180658: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1246878088: return bem_lastCallSet_1(bevd_0);
case 325838560: return bem_parentConfSet_1(bevd_0);
case 948402281: return bem_idToNamePathSetDirect_1(bevd_0);
case -870618679: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -251141237: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1678984653: return bem_cnodeSetDirect_1(bevd_0);
case -801030940: return bem_allOnceDecsSetDirect_1(bevd_0);
case -222756812: return bem_buildSet_1(bevd_0);
case -1298409589: return bem_methodCatchSetDirect_1(bevd_0);
case 371594577: return bem_instOfSet_1(bevd_0);
case -1488982130: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 839224925: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1163031054: return bem_fileExtSet_1(bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case 891800065: return bem_inFilePathedSet_1(bevd_0);
case 1923163290: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1465335989: return bem_ccMethodsSet_1(bevd_0);
case -889988035: return bem_randSet_1(bevd_0);
case 754410914: return bem_invpSet_1(bevd_0);
case -406683211: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1959449175: return bem_nameToIdSet_1(bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case -209694974: return bem_nullValueSetDirect_1(bevd_0);
case 2100814653: return bem_returnTypeSet_1(bevd_0);
case -1874641507: return bem_fullLibEmitNameSet_1(bevd_0);
case -150749031: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1400134428: return bem_onceDecsSet_1(bevd_0);
case -2121016239: return bem_instanceEqualSetDirect_1(bevd_0);
case 377575387: return bem_methodCallsSetDirect_1(bevd_0);
case -771020557: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 826598614: return bem_intNpSet_1(bevd_0);
case -1066429415: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1418773706: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -495435553: return bem_maxDynArgsSet_1(bevd_0);
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -223372163: return bem_mnodeSetDirect_1(bevd_0);
case -881306106: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case 512973634: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 2025663187: return bem_smnlecsSetDirect_1(bevd_0);
case 102483748: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1291079091: return bem_transSet_1(bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -211309279: return bem_boolCcSet_1(bevd_0);
case -1472629847: return bem_exceptDecSetDirect_1(bevd_0);
case 169644960: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -399634322: return bem_gcMarksSet_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 315351660: return bem_falseValueSet_1(bevd_0);
case -1200425549: return bem_smnlcsSet_1(bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case 88160424: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1910166120: return bem_methodsSet_1(bevd_0);
case 1299223921: return bem_scvpSetDirect_1(bevd_0);
case -23599074: return bem_ccCacheSetDirect_1(bevd_0);
case 1537089005: return bem_transSetDirect_1(bevd_0);
case 1062735581: return bem_ccMethodsSetDirect_1(bevd_0);
case -1434788306: return bem_lastCallSetDirect_1(bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1582044533: return bem_propertyDecsSet_1(bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 1349987040: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 181926170: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1379889168: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
case -422288586: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1632647693: return bem_nameToIdPathSet_1(bevd_0);
case 1750264409: return bem_emitLangSet_1(bevd_0);
case 843407546: return bem_libEmitPathSetDirect_1(bevd_0);
case -1145033675: return bem_libEmitNameSetDirect_1(bevd_0);
case -550335873: return bem_msynSet_1(bevd_0);
case -1778034347: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 793720407: return bem_trueValueSet_1(bevd_0);
case 1265455061: return bem_stringNpSet_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
case -1756187396: return bem_nativeCSlotsSet_1(bevd_0);
case -186793001: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1815165563: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1763384617: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1581065607: return bem_classCallsSet_1(bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case 338819673: return bem_shlibeSet_1(bevd_0);
case 2016296839: return bem_preClassSet_1(bevd_0);
case 49935555: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -623804442: return bem_smnlecsSet_1(bevd_0);
case -2121600626: return bem_floatNpSetDirect_1(bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case 867701191: return bem_classConfSetDirect_1(bevd_0);
case 523322270: return bem_instanceEqualSet_1(bevd_0);
case -1330439639: return bem_ntypesSet_1(bevd_0);
case -1480474741: return bem_boolNpSet_1(bevd_0);
case 1015687400: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -46919953: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 9635322: return bem_classEmitsSetDirect_1(bevd_0);
case -943801044: return bem_ccCacheSet_1(bevd_0);
case 1090583467: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1932353909: return bem_boolNpSetDirect_1(bevd_0);
case -736100649: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1436588860: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 2097295227: return bem_belslitsSetDirect_1(bevd_0);
case 2094093742: return bem_buildSetDirect_1(bevd_0);
case 1607228846: return bem_lineCountSet_1(bevd_0);
case -1450630675: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -2115306909: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -385414837: return bem_constSetDirect_1(bevd_0);
case -841506934: return bem_nullValueSet_1(bevd_0);
case 1540881190: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -275488367: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1664689681: return bem_methodBodySet_1(bevd_0);
case 878439737: return bem_belslitsSet_1(bevd_0);
case 823457196: return bem_onceCountSet_1(bevd_0);
case -1177780015: return bem_idToNamePathSet_1(bevd_0);
case -2141809329: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -2143787858: return bem_dynMethodsSet_1(bevd_0);
case 1954329525: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 813961691: return bem_inFilePathedSetDirect_1(bevd_0);
case -472252792: return bem_emitLangSetDirect_1(bevd_0);
case 2092589580: return bem_preClassSetDirect_1(bevd_0);
case 1045353352: return bem_methodsSetDirect_1(bevd_0);
case -1912530863: return bem_invpSetDirect_1(bevd_0);
case 31752148: return bem_methodBodySetDirect_1(bevd_0);
case 518789942: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1164282839: return bem_parentConfSetDirect_1(bevd_0);
case -615513724: return bem_stringNpSetDirect_1(bevd_0);
case -625771343: return bem_objectCcSet_1(bevd_0);
case 323536948: return bem_synEmitPathSet_1(bevd_0);
case 1266276289: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1601761478: return bem_scvpSet_1(bevd_0);
case -1457015264: return bem_inClassSet_1(bevd_0);
case 1217703152: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -343661645: return bem_constSet_1(bevd_0);
case -1829080852: return bem_smnlcsSetDirect_1(bevd_0);
case 1246036485: return bem_superCallsSetDirect_1(bevd_0);
case -1492692874: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1187103319: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 2116863753: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1135520778: return bem_csynSetDirect_1(bevd_0);
case -95039700: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1891309098: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1976371203: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1281463701: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1539213350: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 558744534: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1147487217: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 93069808: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1854936021: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 283870926: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1334733540: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1484655687: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1627080451: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -667240565: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1301640344: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 849847690: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 807859906: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -462467849: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1209717190: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1151052651: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 135014852: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 174366705: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
