package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_31, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_42, 6));
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x65,0x6D,0x62,0x50,0x6C,0x61,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_47, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_55, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_56, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_58, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_20, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 38));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_60, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_62, 23));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_63, 27));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_64, 32));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 15));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_70, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_71, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_76, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_77, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_80, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_formTarg_1(beva_node);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_invp);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bem_formCallTarg_1(beva_node);
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1722136922);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-559889746);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = beva_sdec.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_belsName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_1_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_3_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-599604443);
bevt_9_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_ta_ph );
bevt_12_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_12_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(-816144494);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 81*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 81*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(1817051966);
if (bevl_first.bevi_bool)/* Line: 82*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 83*/
 else /* Line: 84*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 85*/
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 87*/
 else /* Line: 81*/ {
break;
} /* Line: 81*/
} /* Line: 81*/
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-599604443);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_13_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevl_stinst);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_20_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_21_ta_ph);
bevt_20_ta_ph.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_0_ta_ph = beva_sdec.bem_addValue_1(bevt_1_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_ta_ph = beva_v.bem_nameGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 132*/
bevt_4_ta_ph = super.bem_nameForVar_1(beva_v);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_7_TextStrings bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_7_TextStrings bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_7_TextStrings bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_7_TextStrings bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_5_4_LogicBool bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_5_4_LogicBool bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
/* Line: 148*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 148*/ {
bevl_clnode = bevl_ci.bemd_0(1817051966);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_8_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevp_q);
bevt_12_ta_ph = bevl_clnode.bemd_0(345872792);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-599604443);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-2068645774);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevp_q);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_17_ta_ph = bevl_clnode.bemd_0(345872792);
bevt_16_ta_ph = bevt_17_ta_ph.bemd_0(-599604443);
bevt_15_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_ta_ph );
bevt_18_ta_ph = bevp_build.bem_libNameGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_relEmitName_1(bevt_18_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_22_ta_ph = bevl_clnode.bemd_0(345872792);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-816144494);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-1203590127);
if (((BEC_2_5_4_LogicBool) bevt_20_ta_ph).bevi_bool)/* Line: 154*/ {
bevt_24_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_ta_ph = bevl_clnode.bemd_0(345872792);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-599604443);
bevt_26_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_ta_ph );
bevt_29_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_relEmitName_1(bevt_29_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_30_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_34_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_33_ta_ph = bevl_notNullInitConstruct.bem_addValue_1(bevt_34_ta_ph);
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevl_nc);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevt_35_ta_ph);
bevt_31_ta_ph.bem_addValue_1(bevp_nl);
bevt_38_ta_ph = bevl_clnode.bemd_0(345872792);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_0(-816144494);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(-1203590127);
if (((BEC_2_5_4_LogicBool) bevt_36_ta_ph).bevi_bool)/* Line: 163*/ {
bevt_42_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_41_ta_ph = bevl_notNullInitDefault.bem_addValue_1(bevt_42_ta_ph);
bevt_40_ta_ph = bevt_41_ta_ph.bem_addValue_1(bevl_nc);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_39_ta_ph = bevt_40_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_39_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 164*/
} /* Line: 163*/
} /* Line: 154*/
 else /* Line: 148*/ {
break;
} /* Line: 148*/
} /* Line: 148*/
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_ta_ph = bevp_smnlcs.bem_keysGet_0();
bevt_0_ta_loop = bevt_44_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 172*/ {
bevt_45_ta_ph = bevt_0_ta_loop.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 172*/ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(1817051966);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_52_ta_ph = bevl_smap.bem_addValue_1(bevt_53_ta_ph);
bevt_55_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_ta_ph = bevt_55_ta_ph.bem_quoteGet_0();
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_54_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevl_smk);
bevt_57_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_ta_ph = bevt_57_ta_ph.bem_quoteGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_48_ta_ph = bevt_49_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_ta_ph = bevt_48_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_46_ta_ph = bevt_47_ta_ph.bem_addValue_1(bevt_60_ta_ph);
bevt_46_ta_ph.bem_addValue_1(bevp_nl);
bevt_68_ta_ph = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_67_ta_ph = bevl_smap.bem_addValue_1(bevt_68_ta_ph);
bevt_70_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_ta_ph = bevt_70_ta_ph.bem_quoteGet_0();
bevt_66_ta_ph = bevt_67_ta_ph.bem_addValue_1(bevt_69_ta_ph);
bevt_65_ta_ph = bevt_66_ta_ph.bem_addValue_1(bevl_smk);
bevt_72_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_ta_ph = bevt_72_ta_ph.bem_quoteGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_73_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_63_ta_ph = bevt_64_ta_ph.bem_addValue_1(bevt_73_ta_ph);
bevt_74_ta_ph = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_ta_ph = bevt_63_ta_ph.bem_addValue_1(bevt_74_ta_ph);
bevt_75_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_61_ta_ph = bevt_62_ta_ph.bem_addValue_1(bevt_75_ta_ph);
bevt_61_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 175*/
 else /* Line: 172*/ {
break;
} /* Line: 172*/
} /* Line: 172*/
bevt_77_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_78_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
bevt_76_ta_ph = bevt_77_ta_ph.bem_has_1(bevt_78_ta_ph);
if (!(bevt_76_ta_ph.bevi_bool))/* Line: 179*/ {
bevl_libe.bem_write_1(bevl_smap);
} /* Line: 180*/
bevt_81_ta_ph = bevp_build.bem_usedLibrarysGet_0();
bevt_80_ta_ph = bevt_81_ta_ph.bem_sizeGet_0();
bevt_82_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
if (bevt_80_ta_ph.bevi_int == bevt_82_ta_ph.bevi_int) {
bevt_79_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_79_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_79_ta_ph.bevi_bool)/* Line: 184*/ {
bevt_84_ta_ph = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_83_ta_ph = bevl_libInit.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_85_ta_ph = bevl_libInit.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevt_88_ta_ph = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_87_ta_ph = bevl_libInit.bem_addValue_1(bevt_88_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 187*/
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_89_ta_ph = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_89_ta_ph);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_93_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_92_ta_ph = bevl_main.bem_addValue_1(bevt_93_ta_ph);
bevt_94_ta_ph = bevl_maincc.bem_fullEmitNameGet_0();
bevt_91_ta_ph = bevt_92_ta_ph.bem_addValue_1(bevt_94_ta_ph);
bevt_95_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_90_ta_ph = bevt_91_ta_ph.bem_addValue_1(bevt_95_ta_ph);
bevt_90_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_96_ta_ph.bevi_bool)/* Line: 200*/ {
bevt_98_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_99_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_97_ta_ph = bevt_98_ta_ph.bem_has_1(bevt_99_ta_ph);
if (!(bevt_97_ta_ph.bevi_bool))/* Line: 201*/ {
bevt_101_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_100_ta_ph = bevl_main.bem_addValue_1(bevt_101_ta_ph);
bevt_100_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 202*/
} /* Line: 201*/
bevt_105_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_104_ta_ph = bevl_main.bem_addValue_1(bevt_105_ta_ph);
bevt_107_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_106_ta_ph = bevt_107_ta_ph.bemd_0(690554068);
bevt_103_ta_ph = bevt_104_ta_ph.bem_addValue_1(bevt_106_ta_ph);
bevt_108_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_102_ta_ph = bevt_103_ta_ph.bem_addValue_1(bevt_108_ta_ph);
bevt_102_ta_ph.bem_addValue_1(bevp_nl);
bevt_109_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_109_ta_ph.bevi_bool)/* Line: 206*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 207*/
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_110_ta_ph = bevp_build.bem_ownProcessGet_0();
if (bevt_110_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_112_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_111_ta_ph = bevl_main.bem_addValue_1(bevt_112_ta_ph);
bevt_111_ta_ph.bem_addValue_1(bevp_nl);
bevt_114_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_113_ta_ph = bevl_main.bem_addValue_1(bevt_114_ta_ph);
bevt_113_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 214*/
bevt_115_ta_ph = bevp_build.bem_doMainGet_0();
if (bevt_115_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 217*/
bem_finishLibOutput_1(bevl_libe);
bevt_116_ta_ph = bevp_build.bem_saveSynsGet_0();
if (bevt_116_ta_ph.bevi_bool)/* Line: 222*/ {
bem_saveSyns_0();
} /* Line: 223*/
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 229*/ {
} /* Line: 229*/
 else /* Line: 231*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 232*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
beva_b.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 233*/
bevt_4_ta_ph = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 235*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_exceptDec);
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_parent);
bevt_5_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_5_ta_ph);
bevl_extstr = bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_7_ta_ph = bevl_extstr.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevl_extstr = bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1700503514);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1700503514);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
if (beva_isOnce.bevi_bool)/* Line: 266*/ {
bevt_8_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_13_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_belsName);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_0_ta_ph;
} /* Line: 267*/
bevt_24_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_26_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = beva_newcc.bem_relEmitName_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_29_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(beva_belsName);
bevt_30_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_lisz);
bevt_31_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_31_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 274*/
 else /* Line: 275*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_65));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 276*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_6_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_8_ta_ph = bevl_begin.bem_addValue_1(bevt_9_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_heldGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1371335117);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 292*/ {
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(beva_callArgs);
if (bevt_2_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
beva_callArgs = bevt_4_ta_ph.bem_add_1(beva_callArgs);
} /* Line: 294*/
 else /* Line: 295*/ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
} /* Line: 296*/
bevt_10_ta_ph = bevp_parentConf.bem_emitNameGet_0();
bevt_11_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(690554068);
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_callArgs);
bevt_15_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_15_ta_ph);
return bevt_5_ta_ph;
} /* Line: 298*/
bevt_21_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_20_ta_ph = beva_callTarget.bem_add_1(bevt_21_ta_ph);
bevt_23_ta_ph = beva_node.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(690554068);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(beva_callArgs);
bevt_25_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_25_ta_ph);
return bevt_16_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_allOnceDecs == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 312*/ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 313*/
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getLibOutput_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_13_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
if (bevp_shlibe == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 329*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_7_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 332*/
bevt_9_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_ta_ph.bemd_0(-1497983482);
bevt_11_ta_ph = bevp_build.bem_paramsGet_0();
bevt_12_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_10_ta_ph = bevt_11_ta_ph.bem_has_1(bevt_12_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_14_ta_ph = bevp_build.bem_paramsGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_72));
bevt_13_ta_ph = bevt_14_ta_ph.bem_get_1(bevt_15_ta_ph);
bevt_0_ta_loop = bevt_13_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 337*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 337*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(1817051966);
bevt_17_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-1497983482);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_ta_ph.bemd_0(127589283);
bevt_20_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph.bemd_0(623808225);
bevt_21_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 342*/
 else /* Line: 337*/ {
break;
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 337*/
} /* Line: 336*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_73));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_anyName);
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_typeName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = beva_newcc.bem_relEmitName_1(bevt_2_ta_ph);
bevt_3_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_4_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_43;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_count);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_methods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_78));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
bevt_0_ta_ph.bem_addValue_1(bevt_5_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_ta_ph = bevp_methods.bem_addValue_1(bevt_7_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_5_9_BuildJSEmitter_bevo_44;
bevt_1_ta_ph = beva_nameSpace.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_emitName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_81));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_ta_ph = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_ta_ph);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public final BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 63, 63, 63, 63, 63, 67, 67, 67, 67, 67, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 70, 70, 70, 75, 75, 76, 78, 78, 78, 78, 80, 81, 0, 81, 81, 83, 85, 85, 87, 87, 87, 87, 87, 87, 91, 91, 91, 96, 96, 96, 97, 99, 99, 99, 99, 99, 102, 102, 102, 102, 104, 104, 104, 106, 106, 106, 106, 106, 109, 109, 109, 109, 109, 109, 111, 111, 111, 113, 118, 119, 120, 126, 126, 126, 131, 132, 132, 132, 132, 134, 134, 143, 145, 146, 147, 148, 148, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 154, 154, 154, 156, 156, 156, 156, 156, 156, 156, 156, 156, 162, 162, 162, 162, 162, 162, 163, 163, 163, 164, 164, 164, 164, 164, 164, 170, 172, 172, 0, 172, 172, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 179, 179, 179, 180, 184, 184, 184, 184, 184, 185, 185, 185, 186, 186, 186, 187, 187, 187, 190, 191, 194, 195, 195, 196, 198, 199, 199, 199, 199, 199, 199, 199, 200, 201, 201, 201, 202, 202, 202, 205, 205, 205, 205, 205, 205, 205, 205, 206, 207, 209, 210, 211, 212, 213, 213, 213, 214, 214, 214, 216, 217, 220, 222, 223, 229, 232, 232, 232, 233, 233, 235, 235, 240, 240, 244, 244, 244, 244, 244, 244, 248, 248, 252, 252, 252, 252, 252, 252, 252, 253, 253, 253, 253, 253, 254, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 269, 273, 273, 274, 274, 274, 276, 276, 278, 278, 278, 278, 278, 286, 286, 286, 287, 288, 292, 292, 293, 293, 294, 294, 296, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 298, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 304, 305, 312, 312, 313, 315, 316, 316, 321, 321, 329, 329, 330, 331, 331, 331, 331, 331, 332, 332, 332, 334, 334, 334, 336, 336, 336, 337, 337, 337, 337, 0, 337, 337, 338, 338, 339, 339, 339, 340, 340, 341, 341, 342, 348, 352, 353, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 378, 378, 382, 382, 387, 387, 393, 393, 398, 398, 402, 402, 402, 402, 402, 402, 406, 406, 410, 410, 410, 410, 410, 415, 415, 415, 415, 415, 415, 415, 420, 420, 420, 420, 420, 420, 420, 422, 424, 424, 424, 429, 429, 433, 433, 437, 437, 437, 437, 442, 442, 446, 447, 447, 448, 452, 453, 453, 454, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {141, 142, 143, 144, 145, 146, 147, 148, 154, 155, 156, 162, 163, 164, 165, 171, 172, 173, 174, 184, 185, 186, 187, 188, 189, 190, 191, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 244, 245, 246, 247, 248, 249, 250, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 310, 311, 312, 313, 314, 315, 316, 317, 318, 318, 321, 323, 325, 328, 329, 331, 332, 333, 334, 335, 336, 342, 343, 344, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 407, 408, 409, 415, 416, 417, 426, 428, 429, 430, 431, 433, 434, 569, 570, 571, 572, 573, 576, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 621, 622, 623, 624, 625, 626, 634, 635, 636, 636, 639, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 679, 680, 681, 683, 685, 686, 687, 688, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 720, 721, 722, 724, 725, 726, 729, 730, 731, 732, 733, 734, 735, 736, 737, 739, 741, 742, 743, 744, 746, 747, 748, 749, 750, 751, 753, 755, 757, 758, 760, 770, 774, 775, 780, 781, 782, 784, 785, 791, 792, 800, 801, 802, 803, 804, 805, 809, 810, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 971, 976, 977, 978, 979, 982, 983, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 1023, 1024, 1026, 1027, 1029, 1030, 1033, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1062, 1063, 1068, 1073, 1074, 1076, 1077, 1078, 1082, 1083, 1114, 1119, 1120, 1121, 1122, 1123, 1124, 1129, 1130, 1131, 1132, 1134, 1135, 1136, 1137, 1138, 1139, 1141, 1142, 1143, 1144, 1144, 1147, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1167, 1170, 1171, 1176, 1177, 1181, 1182, 1186, 1187, 1191, 1192, 1196, 1197, 1201, 1202, 1206, 1207, 1211, 1212, 1216, 1217, 1221, 1222, 1230, 1231, 1232, 1233, 1234, 1235, 1239, 1240, 1247, 1248, 1249, 1250, 1251, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1277, 1278, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1292, 1293, 1297, 1298, 1304, 1305, 1306, 1307, 1311, 1312, 1317, 1318, 1319, 1320, 1325, 1326, 1327, 1328, 1331, 1334, 1337, 1341, 1345, 1348, 1351, 1355};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 141
new 0 16 141
assign 1 17 142
new 0 17 142
assign 1 18 143
new 0 18 143
new 1 22 144
assign 1 24 145
new 0 24 145
assign 1 25 146
new 0 25 146
assign 1 27 147
new 0 27 147
assign 1 28 148
new 0 28 148
assign 1 32 154
formTarg 1 32 154
assign 1 32 155
add 1 32 155
return 1 32 156
assign 1 36 162
formCallTarg 1 36 162
assign 1 36 163
new 0 36 163
assign 1 36 164
add 1 36 164
return 1 36 165
assign 1 40 171
formCallTarg 1 40 171
assign 1 40 172
new 0 40 172
assign 1 40 173
add 1 40 173
return 1 40 174
assign 1 44 184
new 0 44 184
assign 1 44 185
addValue 1 44 185
assign 1 44 186
secondGet 0 44 186
assign 1 44 187
formTarg 1 44 187
assign 1 44 188
addValue 1 44 188
assign 1 44 189
new 0 44 189
assign 1 44 190
addValue 1 44 190
addValue 1 44 191
assign 1 48 212
new 0 48 212
assign 1 48 213
toString 0 48 213
assign 1 48 214
add 1 48 214
incrementValue 0 49 215
assign 1 50 216
new 0 50 216
assign 1 50 217
addValue 1 50 217
assign 1 50 218
addValue 1 50 218
assign 1 50 219
new 0 50 219
assign 1 50 220
addValue 1 50 220
addValue 1 50 221
assign 1 55 222
containedGet 0 55 222
assign 1 55 223
firstGet 0 55 223
assign 1 55 224
containedGet 0 55 224
assign 1 55 225
firstGet 0 55 225
assign 1 55 226
new 0 55 226
assign 1 55 227
add 1 55 227
assign 1 55 228
new 0 55 228
assign 1 55 229
add 1 55 229
assign 1 55 230
finalAssign 4 55 230
addValue 1 55 231
assign 1 63 244
emitNameGet 0 63 244
assign 1 63 245
addValue 1 63 245
assign 1 63 246
new 0 63 246
assign 1 63 247
addValue 1 63 247
assign 1 63 248
addValue 1 63 248
assign 1 63 249
new 0 63 249
addValue 1 63 250
assign 1 67 270
emitNameGet 0 67 270
assign 1 67 271
addValue 1 67 271
assign 1 67 272
new 0 67 272
assign 1 67 273
addValue 1 67 273
addValue 1 67 274
assign 1 68 275
new 0 68 275
assign 1 68 276
addValue 1 68 276
assign 1 68 277
heldGet 0 68 277
assign 1 68 278
namepathGet 0 68 278
assign 1 68 279
getClassConfig 1 68 279
assign 1 68 280
libNameGet 0 68 280
assign 1 68 281
relEmitName 1 68 281
assign 1 68 282
addValue 1 68 282
assign 1 68 283
new 0 68 283
assign 1 68 284
addValue 1 68 284
addValue 1 68 285
assign 1 70 286
new 0 70 286
assign 1 70 287
addValue 1 70 287
addValue 1 70 288
assign 1 75 310
heldGet 0 75 310
assign 1 75 311
synGet 0 75 311
assign 1 76 312
ptyListGet 0 76 312
assign 1 78 313
emitNameGet 0 78 313
assign 1 78 314
addValue 1 78 314
assign 1 78 315
new 0 78 315
addValue 1 78 316
assign 1 80 317
new 0 80 317
assign 1 81 318
iteratorGet 0 0 318
assign 1 81 321
hasNextGet 0 81 321
assign 1 81 323
nextGet 0 81 323
assign 1 83 325
new 0 83 325
assign 1 85 328
new 0 85 328
addValue 1 85 329
assign 1 87 331
addValue 1 87 331
assign 1 87 332
new 0 87 332
assign 1 87 333
addValue 1 87 333
assign 1 87 334
nameGet 0 87 334
assign 1 87 335
addValue 1 87 335
addValue 1 87 336
assign 1 91 342
new 0 91 342
assign 1 91 343
addValue 1 91 343
addValue 1 91 344
assign 1 96 372
heldGet 0 96 372
assign 1 96 373
namepathGet 0 96 373
assign 1 96 374
getClassConfig 1 96 374
assign 1 97 375
getInitialInst 1 97 375
assign 1 99 376
emitNameGet 0 99 376
assign 1 99 377
addValue 1 99 377
assign 1 99 378
new 0 99 378
assign 1 99 379
addValue 1 99 379
addValue 1 99 380
assign 1 102 381
addValue 1 102 381
assign 1 102 382
new 0 102 382
assign 1 102 383
addValue 1 102 383
addValue 1 102 384
assign 1 104 385
new 0 104 385
assign 1 104 386
addValue 1 104 386
addValue 1 104 387
assign 1 106 388
emitNameGet 0 106 388
assign 1 106 389
addValue 1 106 389
assign 1 106 390
new 0 106 390
assign 1 106 391
addValue 1 106 391
addValue 1 106 392
assign 1 109 393
new 0 109 393
assign 1 109 394
addValue 1 109 394
assign 1 109 395
addValue 1 109 395
assign 1 109 396
new 0 109 396
assign 1 109 397
addValue 1 109 397
addValue 1 109 398
assign 1 111 399
new 0 111 399
assign 1 111 400
addValue 1 111 400
addValue 1 111 401
buildPropList 0 113 402
getCode 2 118 407
assign 1 119 408
toString 0 119 408
addValue 1 120 409
assign 1 126 415
new 0 126 415
assign 1 126 416
addValue 1 126 416
addValue 1 126 417
assign 1 131 426
isPropertyGet 0 131 426
assign 1 132 428
new 0 132 428
assign 1 132 429
nameGet 0 132 429
assign 1 132 430
add 1 132 430
return 1 132 431
assign 1 134 433
nameForVar 1 134 433
return 1 134 434
assign 1 143 569
getLibOutput 0 143 569
assign 1 145 570
new 0 145 570
assign 1 146 571
new 0 146 571
assign 1 147 572
new 0 147 572
assign 1 148 573
iteratorGet 0 148 573
assign 1 148 576
hasNextGet 0 148 576
assign 1 150 578
nextGet 0 150 578
assign 1 152 579
new 0 152 579
assign 1 152 580
addValue 1 152 580
assign 1 152 581
addValue 1 152 581
assign 1 152 582
heldGet 0 152 582
assign 1 152 583
namepathGet 0 152 583
assign 1 152 584
toString 0 152 584
assign 1 152 585
addValue 1 152 585
assign 1 152 586
addValue 1 152 586
assign 1 152 587
new 0 152 587
assign 1 152 588
addValue 1 152 588
assign 1 152 589
heldGet 0 152 589
assign 1 152 590
namepathGet 0 152 590
assign 1 152 591
getClassConfig 1 152 591
assign 1 152 592
libNameGet 0 152 592
assign 1 152 593
relEmitName 1 152 593
assign 1 152 594
addValue 1 152 594
assign 1 152 595
new 0 152 595
assign 1 152 596
addValue 1 152 596
addValue 1 152 597
assign 1 154 598
heldGet 0 154 598
assign 1 154 599
synGet 0 154 599
assign 1 154 600
hasDefaultGet 0 154 600
assign 1 156 602
new 0 156 602
assign 1 156 603
heldGet 0 156 603
assign 1 156 604
namepathGet 0 156 604
assign 1 156 605
getClassConfig 1 156 605
assign 1 156 606
libNameGet 0 156 606
assign 1 156 607
relEmitName 1 156 607
assign 1 156 608
add 1 156 608
assign 1 156 609
new 0 156 609
assign 1 156 610
add 1 156 610
assign 1 162 611
new 0 162 611
assign 1 162 612
addValue 1 162 612
assign 1 162 613
addValue 1 162 613
assign 1 162 614
new 0 162 614
assign 1 162 615
addValue 1 162 615
addValue 1 162 616
assign 1 163 617
heldGet 0 163 617
assign 1 163 618
synGet 0 163 618
assign 1 163 619
hasDefaultGet 0 163 619
assign 1 164 621
new 0 164 621
assign 1 164 622
addValue 1 164 622
assign 1 164 623
addValue 1 164 623
assign 1 164 624
new 0 164 624
assign 1 164 625
addValue 1 164 625
addValue 1 164 626
assign 1 170 634
new 0 170 634
assign 1 172 635
keysGet 0 172 635
assign 1 172 636
iteratorGet 0 0 636
assign 1 172 639
hasNextGet 0 172 639
assign 1 172 641
nextGet 0 172 641
assign 1 174 642
new 0 174 642
assign 1 174 643
addValue 1 174 643
assign 1 174 644
new 0 174 644
assign 1 174 645
quoteGet 0 174 645
assign 1 174 646
addValue 1 174 646
assign 1 174 647
addValue 1 174 647
assign 1 174 648
new 0 174 648
assign 1 174 649
quoteGet 0 174 649
assign 1 174 650
addValue 1 174 650
assign 1 174 651
new 0 174 651
assign 1 174 652
addValue 1 174 652
assign 1 174 653
get 1 174 653
assign 1 174 654
addValue 1 174 654
assign 1 174 655
new 0 174 655
assign 1 174 656
addValue 1 174 656
addValue 1 174 657
assign 1 175 658
new 0 175 658
assign 1 175 659
addValue 1 175 659
assign 1 175 660
new 0 175 660
assign 1 175 661
quoteGet 0 175 661
assign 1 175 662
addValue 1 175 662
assign 1 175 663
addValue 1 175 663
assign 1 175 664
new 0 175 664
assign 1 175 665
quoteGet 0 175 665
assign 1 175 666
addValue 1 175 666
assign 1 175 667
new 0 175 667
assign 1 175 668
addValue 1 175 668
assign 1 175 669
get 1 175 669
assign 1 175 670
addValue 1 175 670
assign 1 175 671
new 0 175 671
assign 1 175 672
addValue 1 175 672
addValue 1 175 673
assign 1 179 679
emitChecksGet 0 179 679
assign 1 179 680
new 0 179 680
assign 1 179 681
has 1 179 681
write 1 180 683
assign 1 184 685
usedLibrarysGet 0 184 685
assign 1 184 686
sizeGet 0 184 686
assign 1 184 687
new 0 184 687
assign 1 184 688
equals 1 184 693
assign 1 185 694
new 0 185 694
assign 1 185 695
addValue 1 185 695
addValue 1 185 696
assign 1 186 697
new 0 186 697
assign 1 186 698
addValue 1 186 698
addValue 1 186 699
assign 1 187 700
new 0 187 700
assign 1 187 701
addValue 1 187 701
addValue 1 187 702
write 1 190 704
write 1 191 705
assign 1 194 706
new 0 194 706
assign 1 195 707
mainNameGet 0 195 707
fromString 1 195 708
assign 1 196 709
getClassConfig 1 196 709
assign 1 198 710
new 0 198 710
assign 1 199 711
new 0 199 711
assign 1 199 712
addValue 1 199 712
assign 1 199 713
fullEmitNameGet 0 199 713
assign 1 199 714
addValue 1 199 714
assign 1 199 715
new 0 199 715
assign 1 199 716
addValue 1 199 716
addValue 1 199 717
assign 1 200 718
ownProcessGet 0 200 718
assign 1 201 720
emitChecksGet 0 201 720
assign 1 201 721
new 0 201 721
assign 1 201 722
has 1 201 722
assign 1 202 724
new 0 202 724
assign 1 202 725
addValue 1 202 725
addValue 1 202 726
assign 1 205 729
new 0 205 729
assign 1 205 730
addValue 1 205 730
assign 1 205 731
outputPlatformGet 0 205 731
assign 1 205 732
nameGet 0 205 732
assign 1 205 733
addValue 1 205 733
assign 1 205 734
new 0 205 734
assign 1 205 735
addValue 1 205 735
addValue 1 205 736
assign 1 206 737
doMainGet 0 206 737
write 1 207 739
assign 1 209 741
new 0 209 741
write 1 210 742
write 1 211 743
assign 1 212 744
ownProcessGet 0 212 744
assign 1 213 746
new 0 213 746
assign 1 213 747
addValue 1 213 747
addValue 1 213 748
assign 1 214 749
new 0 214 749
assign 1 214 750
addValue 1 214 750
addValue 1 214 751
assign 1 216 753
doMainGet 0 216 753
write 1 217 755
finishLibOutput 1 220 757
assign 1 222 758
saveSynsGet 0 222 758
saveSyns 0 223 760
assign 1 229 770
isPropertyGet 0 229 770
assign 1 232 774
isArgGet 0 232 774
assign 1 232 775
not 0 232 780
assign 1 233 781
new 0 233 781
addValue 1 233 782
assign 1 235 784
nameForVar 1 235 784
addValue 1 235 785
assign 1 240 791
new 0 240 791
return 1 240 792
assign 1 244 800
new 0 244 800
assign 1 244 801
add 1 244 801
assign 1 244 802
new 0 244 802
assign 1 244 803
add 1 244 803
assign 1 244 804
add 1 244 804
return 1 244 805
assign 1 248 809
new 0 248 809
return 1 248 810
assign 1 252 824
emitNameGet 0 252 824
assign 1 252 825
new 0 252 825
assign 1 252 826
add 1 252 826
assign 1 252 827
add 1 252 827
assign 1 252 828
new 0 252 828
assign 1 252 829
add 1 252 829
assign 1 252 830
addValue 1 252 830
assign 1 253 831
emitNameGet 0 253 831
assign 1 253 832
add 1 253 832
assign 1 253 833
new 0 253 833
assign 1 253 834
add 1 253 834
assign 1 253 835
addValue 1 253 835
return 1 254 836
assign 1 258 850
new 0 258 850
assign 1 258 851
libNameGet 0 258 851
assign 1 258 852
relEmitName 1 258 852
assign 1 258 853
add 1 258 853
assign 1 258 854
new 0 258 854
assign 1 258 855
add 1 258 855
assign 1 258 856
heldGet 0 258 856
assign 1 258 857
literalValueGet 0 258 857
assign 1 258 858
add 1 258 858
assign 1 258 859
new 0 258 859
assign 1 258 860
add 1 258 860
return 1 258 861
assign 1 262 875
new 0 262 875
assign 1 262 876
libNameGet 0 262 876
assign 1 262 877
relEmitName 1 262 877
assign 1 262 878
add 1 262 878
assign 1 262 879
new 0 262 879
assign 1 262 880
add 1 262 880
assign 1 262 881
heldGet 0 262 881
assign 1 262 882
literalValueGet 0 262 882
assign 1 262 883
add 1 262 883
assign 1 262 884
new 0 262 884
assign 1 262 885
add 1 262 885
return 1 262 886
assign 1 267 922
new 0 267 922
assign 1 267 923
libNameGet 0 267 923
assign 1 267 924
relEmitName 1 267 924
assign 1 267 925
add 1 267 925
assign 1 267 926
new 0 267 926
assign 1 267 927
add 1 267 927
assign 1 267 928
emitNameGet 0 267 928
assign 1 267 929
add 1 267 929
assign 1 267 930
new 0 267 930
assign 1 267 931
add 1 267 931
assign 1 267 932
add 1 267 932
assign 1 267 933
new 0 267 933
assign 1 267 934
add 1 267 934
assign 1 267 935
add 1 267 935
assign 1 267 936
new 0 267 936
assign 1 267 937
add 1 267 937
return 1 267 938
assign 1 269 940
new 0 269 940
assign 1 269 941
libNameGet 0 269 941
assign 1 269 942
relEmitName 1 269 942
assign 1 269 943
add 1 269 943
assign 1 269 944
new 0 269 944
assign 1 269 945
add 1 269 945
assign 1 269 946
emitNameGet 0 269 946
assign 1 269 947
add 1 269 947
assign 1 269 948
new 0 269 948
assign 1 269 949
add 1 269 949
assign 1 269 950
add 1 269 950
assign 1 269 951
new 0 269 951
assign 1 269 952
add 1 269 952
assign 1 269 953
add 1 269 953
assign 1 269 954
new 0 269 954
assign 1 269 955
add 1 269 955
return 1 269 956
assign 1 273 971
def 1 273 976
assign 1 274 977
libNameGet 0 274 977
assign 1 274 978
relEmitName 1 274 978
assign 1 274 979
extend 1 274 979
assign 1 276 982
new 0 276 982
assign 1 276 983
extend 1 276 983
assign 1 278 985
new 0 278 985
assign 1 278 986
emitNameGet 0 278 986
assign 1 278 987
addValue 1 278 987
assign 1 278 988
new 0 278 988
assign 1 278 989
addValue 1 278 989
assign 1 286 990
new 0 286 990
assign 1 286 991
addValue 1 286 991
addValue 1 286 992
addValue 1 287 993
return 1 288 994
assign 1 292 1023
heldGet 0 292 1023
assign 1 292 1024
superCallGet 0 292 1024
assign 1 293 1026
new 0 293 1026
assign 1 293 1027
notEmpty 1 293 1027
assign 1 294 1029
new 0 294 1029
assign 1 294 1030
add 1 294 1030
assign 1 296 1033
new 0 296 1033
assign 1 298 1035
emitNameGet 0 298 1035
assign 1 298 1036
new 0 298 1036
assign 1 298 1037
add 1 298 1037
assign 1 298 1038
heldGet 0 298 1038
assign 1 298 1039
nameGet 0 298 1039
assign 1 298 1040
add 1 298 1040
assign 1 298 1041
new 0 298 1041
assign 1 298 1042
add 1 298 1042
assign 1 298 1043
add 1 298 1043
assign 1 298 1044
new 0 298 1044
assign 1 298 1045
add 1 298 1045
return 1 298 1046
assign 1 300 1048
new 0 300 1048
assign 1 300 1049
add 1 300 1049
assign 1 300 1050
heldGet 0 300 1050
assign 1 300 1051
nameGet 0 300 1051
assign 1 300 1052
add 1 300 1052
assign 1 300 1053
new 0 300 1053
assign 1 300 1054
add 1 300 1054
assign 1 300 1055
add 1 300 1055
assign 1 300 1056
new 0 300 1056
assign 1 300 1057
add 1 300 1057
return 1 300 1058
assign 1 304 1062
new 0 304 1062
return 1 305 1063
assign 1 312 1068
undef 1 312 1073
assign 1 313 1074
new 0 313 1074
addValue 1 315 1076
assign 1 316 1077
new 0 316 1077
return 1 316 1078
assign 1 321 1082
getLibOutput 0 321 1082
return 1 321 1083
assign 1 329 1114
undef 1 329 1119
assign 1 330 1120
new 0 330 1120
assign 1 331 1121
parentGet 0 331 1121
assign 1 331 1122
fileGet 0 331 1122
assign 1 331 1123
existsGet 0 331 1123
assign 1 331 1124
not 0 331 1129
assign 1 332 1130
parentGet 0 332 1130
assign 1 332 1131
fileGet 0 332 1131
makeDirs 0 332 1132
assign 1 334 1134
fileGet 0 334 1134
assign 1 334 1135
writerGet 0 334 1135
assign 1 334 1136
open 0 334 1136
assign 1 336 1137
paramsGet 0 336 1137
assign 1 336 1138
new 0 336 1138
assign 1 336 1139
has 1 336 1139
assign 1 337 1141
paramsGet 0 337 1141
assign 1 337 1142
new 0 337 1142
assign 1 337 1143
get 1 337 1143
assign 1 337 1144
iteratorGet 0 0 1144
assign 1 337 1147
hasNextGet 0 337 1147
assign 1 337 1149
nextGet 0 337 1149
assign 1 338 1150
apNew 1 338 1150
assign 1 338 1151
fileGet 0 338 1151
assign 1 339 1152
readerGet 0 339 1152
assign 1 339 1153
open 0 339 1153
assign 1 339 1154
readString 0 339 1154
assign 1 340 1155
readerGet 0 340 1155
close 0 340 1156
assign 1 341 1157
countLines 1 341 1157
addValue 1 341 1158
write 1 342 1159
return 1 348 1167
close 0 352 1170
assign 1 353 1171
assign 1 358 1176
new 0 358 1176
return 1 358 1177
assign 1 362 1181
new 0 362 1181
return 1 362 1182
assign 1 366 1186
new 0 366 1186
return 1 366 1187
assign 1 370 1191
new 0 370 1191
return 1 370 1192
assign 1 374 1196
new 0 374 1196
return 1 374 1197
assign 1 378 1201
new 0 378 1201
return 1 378 1202
assign 1 382 1206
new 0 382 1206
return 1 382 1207
assign 1 387 1211
new 0 387 1211
return 1 387 1212
assign 1 393 1216
new 0 393 1216
return 1 393 1217
assign 1 398 1221
new 0 398 1221
return 1 398 1222
assign 1 402 1230
new 0 402 1230
assign 1 402 1231
add 1 402 1231
assign 1 402 1232
new 0 402 1232
assign 1 402 1233
add 1 402 1233
assign 1 402 1234
add 1 402 1234
return 1 402 1235
assign 1 406 1239
new 0 406 1239
return 1 406 1240
assign 1 410 1247
libNameGet 0 410 1247
assign 1 410 1248
relEmitName 1 410 1248
assign 1 410 1249
new 0 410 1249
assign 1 410 1250
add 1 410 1250
return 1 410 1251
assign 1 415 1260
emitNameGet 0 415 1260
assign 1 415 1261
new 0 415 1261
assign 1 415 1262
add 1 415 1262
assign 1 415 1263
new 0 415 1263
assign 1 415 1264
add 1 415 1264
assign 1 415 1265
add 1 415 1265
return 1 415 1266
assign 1 420 1277
emitNameGet 0 420 1277
assign 1 420 1278
addValue 1 420 1278
assign 1 420 1279
new 0 420 1279
assign 1 420 1280
addValue 1 420 1280
assign 1 420 1281
addValue 1 420 1281
assign 1 420 1282
new 0 420 1282
addValue 1 420 1283
addValue 1 422 1284
assign 1 424 1285
new 0 424 1285
assign 1 424 1286
addValue 1 424 1286
addValue 1 424 1287
assign 1 429 1292
new 0 429 1292
return 1 429 1293
assign 1 433 1297
new 0 433 1297
return 1 433 1298
assign 1 437 1304
new 0 437 1304
assign 1 437 1305
add 1 437 1305
assign 1 437 1306
add 1 437 1306
return 1 437 1307
assign 1 442 1311
new 0 442 1311
return 1 442 1312
assign 1 446 1317
getClassConfig 1 446 1317
assign 1 447 1318
fullEmitNameGet 0 447 1318
emitNameSet 1 447 1319
return 1 448 1320
assign 1 452 1325
getLocalClassConfig 1 452 1325
assign 1 453 1326
fullEmitNameGet 0 453 1326
emitNameSet 1 453 1327
return 1 454 1328
return 1 0 1331
return 1 0 1334
assign 1 0 1337
assign 1 0 1341
return 1 0 1345
return 1 0 1348
assign 1 0 1351
assign 1 0 1355
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -29732036: return bem_overrideMtdDecGet_0();
case 151131677: return bem_buildGetDirect_0();
case 585149034: return bem_classEndGet_0();
case -717799538: return bem_maxDynArgsGet_0();
case -755526441: return bem_qGetDirect_0();
case -789957864: return bem_inClassGetDirect_0();
case -1023516553: return bem_csynGetDirect_0();
case -752079455: return bem_preClassOutput_0();
case 917671751: return bem_instanceEqualGetDirect_0();
case 1986580358: return bem_objectCcGetDirect_0();
case -1000935856: return bem_nameToIdGetDirect_0();
case -1357904439: return bem_objectNpGetDirect_0();
case 1656595387: return bem_mnodeGet_0();
case -940424070: return bem_lastMethodBodySizeGet_0();
case -452650535: return bem_newDecGet_0();
case -2015317360: return bem_nameToIdPathGetDirect_0();
case -366848944: return bem_maxDynArgsGetDirect_0();
case -1189893527: return bem_scvpGet_0();
case 1380215264: return bem_objectCcGet_0();
case -510915100: return bem_libEmitNameGetDirect_0();
case -1261017080: return bem_intNpGetDirect_0();
case 1337499076: return bem_fieldIteratorGet_0();
case 2129480230: return bem_lastMethodBodyLinesGetDirect_0();
case 1757418298: return bem_methodsGetDirect_0();
case 1193472713: return bem_belslitsGet_0();
case 656174411: return bem_iteratorGet_0();
case 229842178: return bem_nlGet_0();
case -1799291118: return bem_doEmit_0();
case -1822333277: return bem_csynGet_0();
case 842363651: return bem_getClassOutput_0();
case 1433312714: return bem_deserializeClassNameGet_0();
case -1193538733: return bem_echo_0();
case -1916545082: return bem_hashGet_0();
case -734976527: return bem_callNamesGet_0();
case 1916215552: return bem_instOfGetDirect_0();
case 1856995458: return bem_invpGetDirect_0();
case 1036495058: return bem_intNpGet_0();
case 1993725787: return bem_buildGet_0();
case 501101616: return bem_callNamesGetDirect_0();
case 1583640413: return bem_initialDecGet_0();
case 564184085: return bem_buildPropList_0();
case -2068645774: return bem_toString_0();
case 1891960843: return bem_transGet_0();
case -267015715: return bem_idToNameGetDirect_0();
case -902348708: return bem_parentConfGet_0();
case -1116424397: return bem_smnlcsGet_0();
case 1917547317: return bem_randGet_0();
case -1104000419: return bem_msynGetDirect_0();
case 1333189262: return bem_copy_0();
case -548965720: return bem_inFilePathedGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 298356207: return bem_instanceNotEqualGet_0();
case -1191535574: return bem_falseValueGet_0();
case 899969508: return bem_preClassGetDirect_0();
case -48695731: return bem_instanceEqualGet_0();
case 1058212856: return bem_idToNameGet_0();
case -422497726: return bem_runtimeInitGet_0();
case -1559952738: return bem_emitLib_0();
case 2056024374: return bem_methodCallsGet_0();
case -309752116: return bem_returnTypeGetDirect_0();
case 1476240485: return bem_lineCountGetDirect_0();
case -1831488804: return bem_qGet_0();
case -677866177: return bem_classCallsGet_0();
case 266871206: return bem_nullValueGet_0();
case 2129092358: return bem_gcMarksGet_0();
case -1001919328: return bem_covariantReturnsGet_0();
case 1856785219: return bem_classConfGetDirect_0();
case -1134589630: return bem_serializeToString_0();
case 2051569138: return bem_nullValueGetDirect_0();
case -1852461637: return bem_cnodeGet_0();
case -1850668923: return bem_ccCacheGetDirect_0();
case 529390948: return bem_endNs_0();
case 1253234356: return bem_instOfGet_0();
case 1577458831: return bem_lineCountGet_0();
case 1258540231: return bem_print_0();
case 925325675: return bem_idToNamePathGetDirect_0();
case 444565010: return bem_methodBodyGetDirect_0();
case 298936905: return bem_libEmitPathGetDirect_0();
case -1525390187: return bem_buildInitial_0();
case 1098649367: return bem_msynGet_0();
case 470335985: return bem_fieldNamesGet_0();
case 1080913057: return bem_fileExtGetDirect_0();
case 737976761: return bem_lastMethodsSizeGet_0();
case 1690251055: return bem_gcMarksGetDirect_0();
case 1772500176: return bem_ccMethodsGet_0();
case -350999440: return bem_cnodeGetDirect_0();
case -1961806899: return bem_stringNpGet_0();
case 465992683: return bem_transGetDirect_0();
case 1839847089: return bem_writeBET_0();
case -2041544936: return bem_exceptDecGetDirect_0();
case -837283569: return bem_libEmitPathGet_0();
case -973440461: return bem_methodsGet_0();
case 1135223148: return bem_lastMethodsSizeGetDirect_0();
case 62419287: return bem_allOnceDecsGetDirect_0();
case -1034301811: return bem_mainEndGet_0();
case -1188551003: return bem_idToNamePathGet_0();
case 312205093: return bem_trueValueGet_0();
case 1221571963: return bem_mainInClassGet_0();
case 933301402: return bem_lastMethodsLinesGet_0();
case 1180826433: return bem_classEmitsGetDirect_0();
case 11299634: return bem_saveIds_0();
case 363720406: return bem_boolNpGetDirect_0();
case -578132238: return bem_ccCacheGet_0();
case -1766970755: return bem_onceCountGetDirect_0();
case -1880507321: return bem_getLibOutput_0();
case -168218266: return bem_methodBodyGet_0();
case 550390899: return bem_methodCatchGetDirect_0();
case 1422294520: return bem_create_0();
case -869586494: return bem_parentConfGetDirect_0();
case -1613110621: return bem_invpGet_0();
case -339373526: return bem_randGetDirect_0();
case 1413812010: return bem_nativeCSlotsGetDirect_0();
case 254283761: return bem_classNameGet_0();
case 227840825: return bem_inFilePathedGetDirect_0();
case 1247534455: return bem_propertyDecsGet_0();
case 537631098: return bem_onceDecsGetDirect_0();
case 321782565: return bem_buildClassInfo_0();
case -1273799844: return bem_nameToIdPathGet_0();
case 1887791078: return bem_toAny_0();
case 238716313: return bem_once_0();
case 2034744041: return bem_classesInDepthOrderGet_0();
case -1037077574: return bem_lastCallGet_0();
case -1449015112: return bem_emitLangGetDirect_0();
case -1594326943: return bem_inClassGet_0();
case -451118000: return bem_fullLibEmitNameGet_0();
case -1323357806: return bem_nameToIdGet_0();
case -2138855749: return bem_propDecGet_0();
case 1934692954: return bem_scvpGetDirect_0();
case 1980803638: return bem_classCallsGetDirect_0();
case 35667786: return bem_classConfGet_0();
case 1913773249: return bem_nativeCSlotsGet_0();
case -1627288883: return bem_floatNpGetDirect_0();
case -1667230363: return bem_new_0();
case -1903807792: return bem_maxSpillArgsLenGet_0();
case 1553588426: return bem_preClassGet_0();
case -979044395: return bem_falseValueGetDirect_0();
case -1288241432: return bem_lastCallGetDirect_0();
case 530474190: return bem_afterCast_0();
case -453346357: return bem_methodCatchGet_0();
case -1764395136: return bem_saveSyns_0();
case 181316061: return bem_serializeContents_0();
case -1783245443: return bem_boolCcGetDirect_0();
case 1123314980: return bem_dynMethodsGet_0();
case 768376479: return bem_smnlcsGetDirect_0();
case 1242427585: return bem_ccMethodsGetDirect_0();
case -668555863: return bem_spropDecGet_0();
case 1314170679: return bem_superCallsGet_0();
case 1482412556: return bem_lastMethodBodySizeGetDirect_0();
case 587671213: return bem_synEmitPathGetDirect_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -991693042: return bem_synEmitPathGet_0();
case -1023448518: return bem_instanceNotEqualGetDirect_0();
case 1157357901: return bem_boolCcGet_0();
case -1385380140: return bem_constGet_0();
case -1701550418: return bem_propertyDecsGetDirect_0();
case 32986096: return bem_tagGet_0();
case 1632727317: return bem_allOnceDecsGet_0();
case -434766936: return bem_many_0();
case 2100721281: return bem_lastMethodsLinesGetDirect_0();
case 328328880: return bem_methodCallsGetDirect_0();
case -1080342211: return bem_shlibeGetDirect_0();
case -242402138: return bem_mnodeGetDirect_0();
case -374235391: return bem_lastMethodBodyLinesGet_0();
case 846592645: return bem_trueValueGetDirect_0();
case -258998512: return bem_objectNpGet_0();
case 898826466: return bem_onceDecsGet_0();
case -587131595: return bem_floatNpGet_0();
case -1123500786: return bem_buildCreate_0();
case -1147320806: return bem_fullLibEmitNameGetDirect_0();
case 1485986232: return bem_baseMtdDecGet_0();
case -606872092: return bem_libEmitNameGet_0();
case -1253020820: return bem_belslitsGetDirect_0();
case -489446933: return bem_dynMethodsGetDirect_0();
case 1684533668: return bem_smnlecsGet_0();
case -785883820: return bem_smnlecsGetDirect_0();
case 358371897: return bem_baseSmtdDecGet_0();
case 840272884: return bem_ntypesGet_0();
case 1327334697: return bem_mainStartGet_0();
case -1723302242: return bem_emitLangGet_0();
case -1140117387: return bem_classesInDepthOrderGetDirect_0();
case 1607056796: return bem_onceCountGet_0();
case 2038180728: return bem_stringNpGetDirect_0();
case -1418943130: return bem_ntypesGetDirect_0();
case -1845802663: return bem_typeDecGet_0();
case -450487984: return bem_superCallsGetDirect_0();
case 1455477083: return bem_boolTypeGet_0();
case 1552911846: return bem_fileExtGet_0();
case 765155539: return bem_nlGetDirect_0();
case -1659804734: return bem_classEmitsGet_0();
case 2109943745: return bem_maxSpillArgsLenGetDirect_0();
case -15310768: return bem_loadIds_0();
case 1724284574: return bem_constGetDirect_0();
case 1071090121: return bem_shlibeGet_0();
case 161130083: return bem_exceptDecGet_0();
case -1161742750: return bem_useDynMethodsGet_0();
case -1602950882: return bem_superNameGet_0();
case 463630623: return bem_returnTypeGet_0();
case 1829444033: return bem_mainOutsideNsGet_0();
case 2124793366: return bem_boolNpGet_0();
case 1506300538: return bem_beginNs_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -979569384: return bem_lastCallSet_1(bevd_0);
case -1321994552: return bem_allOnceDecsSetDirect_1(bevd_0);
case 442716156: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1771030837: return bem_allOnceDecsSet_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
case 2026806365: return bem_ccCacheSet_1(bevd_0);
case -1934267789: return bem_methodsSet_1(bevd_0);
case -37261922: return bem_idToNamePathSetDirect_1(bevd_0);
case -483224371: return bem_end_1(bevd_0);
case -1194802938: return bem_libEmitPathSetDirect_1(bevd_0);
case -1977406324: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 82701214: return bem_inClassSet_1(bevd_0);
case 1222911066: return bem_smnlcsSet_1(bevd_0);
case -754384555: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 101067285: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -145188299: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case -1510764863: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1583009348: return bem_lastMethodBodySizeSet_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case -2004073086: return bem_cnodeSetDirect_1(bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case 1208256538: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 782492745: return bem_boolCcSet_1(bevd_0);
case 100251224: return bem_boolNpSet_1(bevd_0);
case 567333240: return bem_methodCallsSetDirect_1(bevd_0);
case -1796582804: return bem_methodCallsSet_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case 1494601127: return bem_trueValueSetDirect_1(bevd_0);
case 1892842053: return bem_constSetDirect_1(bevd_0);
case 556236018: return bem_classesInDepthOrderSet_1(bevd_0);
case 569412263: return bem_nullValueSetDirect_1(bevd_0);
case -478894174: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -300365056: return bem_instOfSet_1(bevd_0);
case 113461456: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1081419254: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1351279617: return bem_superCallsSet_1(bevd_0);
case 105570547: return bem_methodCatchSet_1(bevd_0);
case 1896513581: return bem_inClassSetDirect_1(bevd_0);
case 2005274557: return bem_classCallsSet_1(bevd_0);
case 813259161: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1436903741: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 2099765945: return bem_ntypesSetDirect_1(bevd_0);
case -346331210: return bem_synEmitPathSetDirect_1(bevd_0);
case -1440676783: return bem_returnTypeSet_1(bevd_0);
case 823620346: return bem_nlSetDirect_1(bevd_0);
case -1666068121: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -721025572: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1308169089: return bem_mnodeSet_1(bevd_0);
case 773394862: return bem_preClassSet_1(bevd_0);
case -1670469512: return bem_scvpSetDirect_1(bevd_0);
case 1241028206: return bem_gcMarksSetDirect_1(bevd_0);
case 738621725: return bem_ccMethodsSet_1(bevd_0);
case -747587606: return bem_stringNpSetDirect_1(bevd_0);
case 1727292505: return bem_idToNameSetDirect_1(bevd_0);
case -1646460992: return bem_qSet_1(bevd_0);
case 817491315: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -581270720: return bem_maxDynArgsSet_1(bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 1018516778: return bem_maxDynArgsSetDirect_1(bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -354977022: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1056853624: return bem_libEmitNameSet_1(bevd_0);
case 1278693728: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 1110424093: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 985302193: return bem_instanceNotEqualSet_1(bevd_0);
case -686880993: return bem_nativeCSlotsSet_1(bevd_0);
case -2123639399: return bem_lastMethodsSizeSet_1(bevd_0);
case -1100093800: return bem_nameToIdPathSetDirect_1(bevd_0);
case 118707240: return bem_onceCountSet_1(bevd_0);
case -930974087: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1524582495: return bem_smnlecsSetDirect_1(bevd_0);
case -1389290446: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -490250776: return bem_gcMarksSet_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 721528016: return bem_lineCountSet_1(bevd_0);
case -79055419: return bem_classCallsSetDirect_1(bevd_0);
case 1063980900: return bem_methodBodySet_1(bevd_0);
case -225136743: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 2138922463: return bem_nameToIdSetDirect_1(bevd_0);
case -493038259: return bem_falseValueSetDirect_1(bevd_0);
case 129810800: return bem_ntypesSet_1(bevd_0);
case -2063844470: return bem_returnTypeSetDirect_1(bevd_0);
case -428829557: return bem_inFilePathedSet_1(bevd_0);
case -570491086: return bem_transSetDirect_1(bevd_0);
case 1414879252: return bem_dynMethodsSet_1(bevd_0);
case 1904913447: return bem_nullValueSet_1(bevd_0);
case -572653293: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1633682500: return bem_randSetDirect_1(bevd_0);
case -46361386: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1176259388: return bem_boolNpSetDirect_1(bevd_0);
case -848476564: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -1931567829: return bem_propertyDecsSet_1(bevd_0);
case -509559552: return bem_callNamesSet_1(bevd_0);
case 1992881414: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -167479391: return bem_classEmitsSetDirect_1(bevd_0);
case -121165450: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -595781152: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1290216463: return bem_def_1(bevd_0);
case 1570354795: return bem_nlSet_1(bevd_0);
case -2028797397: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -2132959930: return bem_synEmitPathSet_1(bevd_0);
case 1532119691: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -468047507: return bem_nameToIdSet_1(bevd_0);
case 1070156727: return bem_scvpSet_1(bevd_0);
case 1704676773: return bem_callNamesSetDirect_1(bevd_0);
case -381804475: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2015073056: return bem_methodBodySetDirect_1(bevd_0);
case 1641712379: return bem_buildSet_1(bevd_0);
case -648018148: return bem_superCallsSetDirect_1(bevd_0);
case 126386272: return bem_shlibeSet_1(bevd_0);
case 1948301764: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1876845778: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1383953383: return bem_methodCatchSetDirect_1(bevd_0);
case 625789827: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 181225722: return bem_objectCcSetDirect_1(bevd_0);
case -1595774243: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 501903115: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -2041752223: return bem_onceCountSetDirect_1(bevd_0);
case 580030442: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case -1804894090: return bem_inFilePathedSetDirect_1(bevd_0);
case -477694371: return bem_onceDecsSet_1(bevd_0);
case 1468154624: return bem_instanceEqualSet_1(bevd_0);
case 100560712: return bem_constSet_1(bevd_0);
case -91320720: return bem_propertyDecsSetDirect_1(bevd_0);
case 378573853: return bem_mnodeSetDirect_1(bevd_0);
case 76274936: return bem_libEmitNameSetDirect_1(bevd_0);
case -717201420: return bem_randSet_1(bevd_0);
case 1058594803: return bem_classEmitsSet_1(bevd_0);
case 831765129: return bem_instOfSetDirect_1(bevd_0);
case 174206693: return bem_stringNpSet_1(bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -53489173: return bem_belslitsSetDirect_1(bevd_0);
case -1767096457: return bem_boolCcSetDirect_1(bevd_0);
case -247208881: return bem_intNpSet_1(bevd_0);
case 1750566125: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1071256737: return bem_invpSet_1(bevd_0);
case 1527654224: return bem_nameToIdPathSet_1(bevd_0);
case 962960868: return bem_idToNameSet_1(bevd_0);
case 2126926759: return bem_belslitsSet_1(bevd_0);
case -878433385: return bem_objectCcSet_1(bevd_0);
case 1959319386: return bem_exceptDecSet_1(bevd_0);
case -335638872: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1484740695: return bem_exceptDecSetDirect_1(bevd_0);
case 1854448500: return bem_emitLangSet_1(bevd_0);
case 1539139665: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1937352894: return bem_preClassSetDirect_1(bevd_0);
case -1748561251: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 55460621: return bem_csynSet_1(bevd_0);
case -1024351632: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case 1222334048: return bem_qSetDirect_1(bevd_0);
case -1914536347: return bem_transSet_1(bevd_0);
case -1225155359: return bem_lastCallSetDirect_1(bevd_0);
case -519040746: return bem_smnlcsSetDirect_1(bevd_0);
case 2081373829: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1158316319: return bem_intNpSetDirect_1(bevd_0);
case -959234375: return bem_dynMethodsSetDirect_1(bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case 1421222080: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1675417581: return bem_shlibeSetDirect_1(bevd_0);
case 2034296106: return bem_objectNpSetDirect_1(bevd_0);
case 6556549: return bem_floatNpSet_1(bevd_0);
case -608231493: return bem_buildSetDirect_1(bevd_0);
case -643811668: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -76047564: return bem_lineCountSetDirect_1(bevd_0);
case 1412776807: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 477621069: return bem_fileExtSet_1(bevd_0);
case -1900331597: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1441861332: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1508312363: return bem_cnodeSet_1(bevd_0);
case 736984884: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1334889888: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -156349453: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1603820096: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1230327020: return bem_csynSetDirect_1(bevd_0);
case -1878583861: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 270728390: return bem_classConfSetDirect_1(bevd_0);
case 2090327715: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1235695486: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -147288172: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1097960976: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1854027062: return bem_idToNamePathSet_1(bevd_0);
case -1102996784: return bem_lastMethodsLinesSet_1(bevd_0);
case 1338582924: return bem_onceDecsSetDirect_1(bevd_0);
case -873053246: return bem_trueValueSet_1(bevd_0);
case -288801937: return bem_smnlecsSet_1(bevd_0);
case -485900394: return bem_ccCacheSetDirect_1(bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case 922290210: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -887751171: return bem_emitLangSetDirect_1(bevd_0);
case 1413627295: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -731447345: return bem_invpSetDirect_1(bevd_0);
case 227922790: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1300144723: return bem_falseValueSet_1(bevd_0);
case -234591008: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1357106257: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -687529662: return bem_classConfSet_1(bevd_0);
case 1310009999: return bem_libEmitPathSet_1(bevd_0);
case -1697976049: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 579831333: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1056695419: return bem_fileExtSetDirect_1(bevd_0);
case 584155665: return bem_msynSetDirect_1(bevd_0);
case 1338931231: return bem_msynSet_1(bevd_0);
case 1675566006: return bem_begin_1(bevd_0);
case 85787050: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -433226457: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1198972989: return bem_parentConfSet_1(bevd_0);
case -291500282: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -197692736: return bem_ccMethodsSetDirect_1(bevd_0);
case 422501964: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 671098028: return bem_parentConfSetDirect_1(bevd_0);
case 1240633174: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 954929315: return bem_instanceEqualSetDirect_1(bevd_0);
case 107458077: return bem_objectNpSet_1(bevd_0);
case -1242160887: return bem_maxSpillArgsLenSet_1(bevd_0);
case 311896173: return bem_methodsSetDirect_1(bevd_0);
case -1119342817: return bem_floatNpSetDirect_1(bevd_0);
case 125260509: return bem_fullLibEmitNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1557706702: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 927578052: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1162680592: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -76945828: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -373793185: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 107303109: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1485492804: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 760417998: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1826706811: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -588398374: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1698742060: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1267569066: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -131373805: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1110954592: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 880167489: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -686310495: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 429439457: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 252135929: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -631886675: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1685907219: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -923123068: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
