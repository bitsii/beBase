package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_31, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_53, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_54, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_56, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_20, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_57, 38));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_58, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_60, 23));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 27));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_62, 32));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_65, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_66, 15));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_72, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_73, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_78, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildJSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formTarg_1(beva_node);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_invp);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-2018649338);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2038891686);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1129539545);
bevt_9_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold );
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(-990159871);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 81 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1664274967);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 81 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(396718224);
if (bevl_first.bevi_bool) /* Line: 82 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 83 */
 else  /* Line: 84 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 85 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 87 */
 else  /* Line: 81 */ {
break;
} /* Line: 81 */
} /* Line: 81 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1129539545);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_17_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_20_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_0_tmpany_phold = beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 132 */
bevt_4_tmpany_phold = super.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_writeBET_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 148 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-1664274967);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 148 */ {
bevl_clnode = bevl_ci.bemd_0(396718224);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_8_tmpany_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(436982975);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-1129539545);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(148544119);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(436982975);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-1129539545);
bevt_15_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold );
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(436982975);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-990159871);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-1932451641);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(436982975);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-1129539545);
bevt_26_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold );
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_33_tmpany_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(436982975);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(-990159871);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-1932451641);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 163 */ {
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_41_tmpany_phold = bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 164 */
} /* Line: 163 */
} /* Line: 154 */
 else  /* Line: 148 */ {
break;
} /* Line: 148 */
} /* Line: 148 */
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 172 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1664274967);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(396718224);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_52_tmpany_phold = bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_67_tmpany_phold = bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 175 */
 else  /* Line: 172 */ {
break;
} /* Line: 172 */
} /* Line: 172 */
bevl_libe.bem_write_1(bevl_smap);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_80_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_82_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_84_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 185 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_89_tmpany_phold = bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_94_tmpany_phold = bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 199 */
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_98_tmpany_phold = bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(1041262721);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_104_tmpany_phold = bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_106_tmpany_phold = bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 208 */
bevl_libe.bem_write_1(bevl_main);
bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 214 */ {
bem_saveSyns_0();
} /* Line: 215 */
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 221 */ {
} /* Line: 221 */
 else  /* Line: 223 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 225 */
bevt_4_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 227 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(289170173);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(289170173);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 258 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 259 */
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 266 */
 else  /* Line: 267 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 268 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_8_tmpany_phold = bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(113330719);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(beva_callArgs);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
beva_callArgs = bevt_4_tmpany_phold.bem_add_1(beva_callArgs);
} /* Line: 286 */
 else  /* Line: 287 */ {
beva_callArgs = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
} /* Line: 288 */
bevt_10_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1041262721);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_callArgs);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_5_tmpany_phold;
} /* Line: 290 */
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_20_tmpany_phold = beva_callTarget.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = beva_node.bem_heldGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1041262721);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_callArgs);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 305 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_7_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 324 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(-718845534);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1664274967);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(396718224);
bevt_17_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-718845534);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(-1018795891);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(2142572680);
bevt_21_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 334 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 328 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_tmpany_phold = bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public final BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 63, 63, 63, 63, 63, 67, 67, 67, 67, 67, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 70, 70, 70, 75, 75, 76, 78, 78, 78, 78, 80, 81, 0, 81, 81, 83, 85, 85, 87, 87, 87, 87, 87, 87, 91, 91, 91, 96, 96, 96, 97, 99, 99, 99, 99, 99, 102, 102, 102, 102, 104, 104, 104, 106, 106, 106, 106, 106, 109, 109, 109, 109, 109, 109, 111, 111, 111, 113, 118, 119, 120, 126, 126, 126, 131, 132, 132, 132, 132, 134, 134, 143, 145, 146, 147, 148, 148, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 154, 154, 154, 156, 156, 156, 156, 156, 156, 156, 156, 156, 162, 162, 162, 162, 162, 162, 163, 163, 163, 164, 164, 164, 164, 164, 164, 170, 172, 172, 0, 172, 172, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 179, 182, 182, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 188, 189, 192, 193, 193, 194, 196, 197, 197, 197, 197, 197, 197, 197, 198, 199, 199, 199, 201, 201, 201, 201, 201, 201, 201, 201, 202, 203, 204, 205, 206, 207, 207, 207, 208, 208, 208, 210, 212, 214, 215, 221, 224, 224, 224, 225, 225, 227, 227, 232, 232, 236, 236, 236, 236, 236, 236, 240, 240, 244, 244, 244, 244, 244, 244, 244, 245, 245, 245, 245, 245, 246, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 265, 265, 266, 266, 266, 268, 268, 270, 270, 270, 270, 270, 278, 278, 278, 279, 280, 284, 284, 285, 285, 286, 286, 288, 290, 290, 290, 290, 290, 290, 290, 290, 290, 290, 290, 290, 292, 292, 292, 292, 292, 292, 292, 292, 292, 292, 292, 296, 297, 304, 304, 305, 307, 308, 308, 313, 313, 321, 321, 322, 323, 323, 323, 323, 323, 324, 324, 324, 326, 326, 326, 328, 328, 328, 329, 329, 329, 329, 0, 329, 329, 330, 330, 331, 331, 331, 332, 332, 333, 333, 334, 340, 344, 345, 350, 350, 354, 354, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 379, 379, 385, 385, 390, 390, 394, 394, 394, 394, 394, 394, 398, 398, 402, 402, 402, 402, 402, 407, 407, 407, 407, 407, 407, 407, 412, 412, 412, 412, 412, 412, 412, 414, 416, 416, 416, 421, 421, 425, 425, 429, 429, 429, 429, 434, 434, 438, 439, 439, 440, 444, 445, 445, 446, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {137, 138, 139, 140, 141, 142, 143, 144, 150, 151, 152, 158, 159, 160, 161, 167, 168, 169, 170, 180, 181, 182, 183, 184, 185, 186, 187, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 240, 241, 242, 243, 244, 245, 246, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 306, 307, 308, 309, 310, 311, 312, 313, 314, 314, 317, 319, 321, 324, 325, 327, 328, 329, 330, 331, 332, 338, 339, 340, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 403, 404, 405, 411, 412, 413, 422, 424, 425, 426, 427, 429, 430, 557, 558, 559, 560, 561, 564, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 609, 610, 611, 612, 613, 614, 622, 623, 624, 624, 627, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 667, 668, 669, 670, 671, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 703, 704, 705, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 721, 722, 723, 724, 725, 726, 728, 729, 730, 732, 742, 746, 747, 752, 753, 754, 756, 757, 763, 764, 772, 773, 774, 775, 776, 777, 781, 782, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 943, 948, 949, 950, 951, 954, 955, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 995, 996, 998, 999, 1001, 1002, 1005, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1034, 1035, 1040, 1045, 1046, 1048, 1049, 1050, 1054, 1055, 1086, 1091, 1092, 1093, 1094, 1095, 1096, 1101, 1102, 1103, 1104, 1106, 1107, 1108, 1109, 1110, 1111, 1113, 1114, 1115, 1116, 1116, 1119, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1139, 1142, 1143, 1148, 1149, 1153, 1154, 1158, 1159, 1163, 1164, 1168, 1169, 1173, 1174, 1178, 1179, 1183, 1184, 1188, 1189, 1193, 1194, 1202, 1203, 1204, 1205, 1206, 1207, 1211, 1212, 1219, 1220, 1221, 1222, 1223, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1264, 1265, 1269, 1270, 1276, 1277, 1278, 1279, 1283, 1284, 1289, 1290, 1291, 1292, 1297, 1298, 1299, 1300, 1303, 1306, 1309, 1313, 1317, 1320, 1323, 1327};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 137
new 0 16 137
assign 1 17 138
new 0 17 138
assign 1 18 139
new 0 18 139
new 1 22 140
assign 1 24 141
new 0 24 141
assign 1 25 142
new 0 25 142
assign 1 27 143
new 0 27 143
assign 1 28 144
new 0 28 144
assign 1 32 150
formTarg 1 32 150
assign 1 32 151
add 1 32 151
return 1 32 152
assign 1 36 158
formCallTarg 1 36 158
assign 1 36 159
new 0 36 159
assign 1 36 160
add 1 36 160
return 1 36 161
assign 1 40 167
formCallTarg 1 40 167
assign 1 40 168
new 0 40 168
assign 1 40 169
add 1 40 169
return 1 40 170
assign 1 44 180
new 0 44 180
assign 1 44 181
addValue 1 44 181
assign 1 44 182
secondGet 0 44 182
assign 1 44 183
formTarg 1 44 183
assign 1 44 184
addValue 1 44 184
assign 1 44 185
new 0 44 185
assign 1 44 186
addValue 1 44 186
addValue 1 44 187
assign 1 48 208
new 0 48 208
assign 1 48 209
toString 0 48 209
assign 1 48 210
add 1 48 210
incrementValue 0 49 211
assign 1 50 212
new 0 50 212
assign 1 50 213
addValue 1 50 213
assign 1 50 214
addValue 1 50 214
assign 1 50 215
new 0 50 215
assign 1 50 216
addValue 1 50 216
addValue 1 50 217
assign 1 55 218
containedGet 0 55 218
assign 1 55 219
firstGet 0 55 219
assign 1 55 220
containedGet 0 55 220
assign 1 55 221
firstGet 0 55 221
assign 1 55 222
new 0 55 222
assign 1 55 223
add 1 55 223
assign 1 55 224
new 0 55 224
assign 1 55 225
add 1 55 225
assign 1 55 226
finalAssign 4 55 226
addValue 1 55 227
assign 1 63 240
emitNameGet 0 63 240
assign 1 63 241
addValue 1 63 241
assign 1 63 242
new 0 63 242
assign 1 63 243
addValue 1 63 243
assign 1 63 244
addValue 1 63 244
assign 1 63 245
new 0 63 245
addValue 1 63 246
assign 1 67 266
emitNameGet 0 67 266
assign 1 67 267
addValue 1 67 267
assign 1 67 268
new 0 67 268
assign 1 67 269
addValue 1 67 269
addValue 1 67 270
assign 1 68 271
new 0 68 271
assign 1 68 272
addValue 1 68 272
assign 1 68 273
heldGet 0 68 273
assign 1 68 274
namepathGet 0 68 274
assign 1 68 275
getClassConfig 1 68 275
assign 1 68 276
libNameGet 0 68 276
assign 1 68 277
relEmitName 1 68 277
assign 1 68 278
addValue 1 68 278
assign 1 68 279
new 0 68 279
assign 1 68 280
addValue 1 68 280
addValue 1 68 281
assign 1 70 282
new 0 70 282
assign 1 70 283
addValue 1 70 283
addValue 1 70 284
assign 1 75 306
heldGet 0 75 306
assign 1 75 307
synGet 0 75 307
assign 1 76 308
ptyListGet 0 76 308
assign 1 78 309
emitNameGet 0 78 309
assign 1 78 310
addValue 1 78 310
assign 1 78 311
new 0 78 311
addValue 1 78 312
assign 1 80 313
new 0 80 313
assign 1 81 314
iteratorGet 0 0 314
assign 1 81 317
hasNextGet 0 81 317
assign 1 81 319
nextGet 0 81 319
assign 1 83 321
new 0 83 321
assign 1 85 324
new 0 85 324
addValue 1 85 325
assign 1 87 327
addValue 1 87 327
assign 1 87 328
new 0 87 328
assign 1 87 329
addValue 1 87 329
assign 1 87 330
nameGet 0 87 330
assign 1 87 331
addValue 1 87 331
addValue 1 87 332
assign 1 91 338
new 0 91 338
assign 1 91 339
addValue 1 91 339
addValue 1 91 340
assign 1 96 368
heldGet 0 96 368
assign 1 96 369
namepathGet 0 96 369
assign 1 96 370
getClassConfig 1 96 370
assign 1 97 371
getInitialInst 1 97 371
assign 1 99 372
emitNameGet 0 99 372
assign 1 99 373
addValue 1 99 373
assign 1 99 374
new 0 99 374
assign 1 99 375
addValue 1 99 375
addValue 1 99 376
assign 1 102 377
addValue 1 102 377
assign 1 102 378
new 0 102 378
assign 1 102 379
addValue 1 102 379
addValue 1 102 380
assign 1 104 381
new 0 104 381
assign 1 104 382
addValue 1 104 382
addValue 1 104 383
assign 1 106 384
emitNameGet 0 106 384
assign 1 106 385
addValue 1 106 385
assign 1 106 386
new 0 106 386
assign 1 106 387
addValue 1 106 387
addValue 1 106 388
assign 1 109 389
new 0 109 389
assign 1 109 390
addValue 1 109 390
assign 1 109 391
addValue 1 109 391
assign 1 109 392
new 0 109 392
assign 1 109 393
addValue 1 109 393
addValue 1 109 394
assign 1 111 395
new 0 111 395
assign 1 111 396
addValue 1 111 396
addValue 1 111 397
buildPropList 0 113 398
getCode 2 118 403
assign 1 119 404
toString 0 119 404
addValue 1 120 405
assign 1 126 411
new 0 126 411
assign 1 126 412
addValue 1 126 412
addValue 1 126 413
assign 1 131 422
isPropertyGet 0 131 422
assign 1 132 424
new 0 132 424
assign 1 132 425
nameGet 0 132 425
assign 1 132 426
add 1 132 426
return 1 132 427
assign 1 134 429
nameForVar 1 134 429
return 1 134 430
assign 1 143 557
getLibOutput 0 143 557
assign 1 145 558
new 0 145 558
assign 1 146 559
new 0 146 559
assign 1 147 560
new 0 147 560
assign 1 148 561
iteratorGet 0 148 561
assign 1 148 564
hasNextGet 0 148 564
assign 1 150 566
nextGet 0 150 566
assign 1 152 567
new 0 152 567
assign 1 152 568
addValue 1 152 568
assign 1 152 569
addValue 1 152 569
assign 1 152 570
heldGet 0 152 570
assign 1 152 571
namepathGet 0 152 571
assign 1 152 572
toString 0 152 572
assign 1 152 573
addValue 1 152 573
assign 1 152 574
addValue 1 152 574
assign 1 152 575
new 0 152 575
assign 1 152 576
addValue 1 152 576
assign 1 152 577
heldGet 0 152 577
assign 1 152 578
namepathGet 0 152 578
assign 1 152 579
getClassConfig 1 152 579
assign 1 152 580
libNameGet 0 152 580
assign 1 152 581
relEmitName 1 152 581
assign 1 152 582
addValue 1 152 582
assign 1 152 583
new 0 152 583
assign 1 152 584
addValue 1 152 584
addValue 1 152 585
assign 1 154 586
heldGet 0 154 586
assign 1 154 587
synGet 0 154 587
assign 1 154 588
hasDefaultGet 0 154 588
assign 1 156 590
new 0 156 590
assign 1 156 591
heldGet 0 156 591
assign 1 156 592
namepathGet 0 156 592
assign 1 156 593
getClassConfig 1 156 593
assign 1 156 594
libNameGet 0 156 594
assign 1 156 595
relEmitName 1 156 595
assign 1 156 596
add 1 156 596
assign 1 156 597
new 0 156 597
assign 1 156 598
add 1 156 598
assign 1 162 599
new 0 162 599
assign 1 162 600
addValue 1 162 600
assign 1 162 601
addValue 1 162 601
assign 1 162 602
new 0 162 602
assign 1 162 603
addValue 1 162 603
addValue 1 162 604
assign 1 163 605
heldGet 0 163 605
assign 1 163 606
synGet 0 163 606
assign 1 163 607
hasDefaultGet 0 163 607
assign 1 164 609
new 0 164 609
assign 1 164 610
addValue 1 164 610
assign 1 164 611
addValue 1 164 611
assign 1 164 612
new 0 164 612
assign 1 164 613
addValue 1 164 613
addValue 1 164 614
assign 1 170 622
new 0 170 622
assign 1 172 623
keysGet 0 172 623
assign 1 172 624
iteratorGet 0 0 624
assign 1 172 627
hasNextGet 0 172 627
assign 1 172 629
nextGet 0 172 629
assign 1 174 630
new 0 174 630
assign 1 174 631
addValue 1 174 631
assign 1 174 632
new 0 174 632
assign 1 174 633
quoteGet 0 174 633
assign 1 174 634
addValue 1 174 634
assign 1 174 635
addValue 1 174 635
assign 1 174 636
new 0 174 636
assign 1 174 637
quoteGet 0 174 637
assign 1 174 638
addValue 1 174 638
assign 1 174 639
new 0 174 639
assign 1 174 640
addValue 1 174 640
assign 1 174 641
get 1 174 641
assign 1 174 642
addValue 1 174 642
assign 1 174 643
new 0 174 643
assign 1 174 644
addValue 1 174 644
addValue 1 174 645
assign 1 175 646
new 0 175 646
assign 1 175 647
addValue 1 175 647
assign 1 175 648
new 0 175 648
assign 1 175 649
quoteGet 0 175 649
assign 1 175 650
addValue 1 175 650
assign 1 175 651
addValue 1 175 651
assign 1 175 652
new 0 175 652
assign 1 175 653
quoteGet 0 175 653
assign 1 175 654
addValue 1 175 654
assign 1 175 655
new 0 175 655
assign 1 175 656
addValue 1 175 656
assign 1 175 657
get 1 175 657
assign 1 175 658
addValue 1 175 658
assign 1 175 659
new 0 175 659
assign 1 175 660
addValue 1 175 660
addValue 1 175 661
write 1 179 667
assign 1 182 668
usedLibrarysGet 0 182 668
assign 1 182 669
sizeGet 0 182 669
assign 1 182 670
new 0 182 670
assign 1 182 671
equals 1 182 676
assign 1 183 677
new 0 183 677
assign 1 183 678
addValue 1 183 678
addValue 1 183 679
assign 1 184 680
new 0 184 680
assign 1 184 681
addValue 1 184 681
addValue 1 184 682
assign 1 185 683
new 0 185 683
assign 1 185 684
addValue 1 185 684
addValue 1 185 685
write 1 188 687
write 1 189 688
assign 1 192 689
new 0 192 689
assign 1 193 690
mainNameGet 0 193 690
fromString 1 193 691
assign 1 194 692
getClassConfig 1 194 692
assign 1 196 693
new 0 196 693
assign 1 197 694
new 0 197 694
assign 1 197 695
addValue 1 197 695
assign 1 197 696
fullEmitNameGet 0 197 696
assign 1 197 697
addValue 1 197 697
assign 1 197 698
new 0 197 698
assign 1 197 699
addValue 1 197 699
addValue 1 197 700
assign 1 198 701
ownProcessGet 0 198 701
assign 1 199 703
new 0 199 703
assign 1 199 704
addValue 1 199 704
addValue 1 199 705
assign 1 201 707
new 0 201 707
assign 1 201 708
addValue 1 201 708
assign 1 201 709
outputPlatformGet 0 201 709
assign 1 201 710
nameGet 0 201 710
assign 1 201 711
addValue 1 201 711
assign 1 201 712
new 0 201 712
assign 1 201 713
addValue 1 201 713
addValue 1 201 714
write 1 202 715
assign 1 203 716
new 0 203 716
write 1 204 717
write 1 205 718
assign 1 206 719
ownProcessGet 0 206 719
assign 1 207 721
new 0 207 721
assign 1 207 722
addValue 1 207 722
addValue 1 207 723
assign 1 208 724
new 0 208 724
assign 1 208 725
addValue 1 208 725
addValue 1 208 726
write 1 210 728
finishLibOutput 1 212 729
assign 1 214 730
saveSynsGet 0 214 730
saveSyns 0 215 732
assign 1 221 742
isPropertyGet 0 221 742
assign 1 224 746
isArgGet 0 224 746
assign 1 224 747
not 0 224 752
assign 1 225 753
new 0 225 753
addValue 1 225 754
assign 1 227 756
nameForVar 1 227 756
addValue 1 227 757
assign 1 232 763
new 0 232 763
return 1 232 764
assign 1 236 772
new 0 236 772
assign 1 236 773
add 1 236 773
assign 1 236 774
new 0 236 774
assign 1 236 775
add 1 236 775
assign 1 236 776
add 1 236 776
return 1 236 777
assign 1 240 781
new 0 240 781
return 1 240 782
assign 1 244 796
emitNameGet 0 244 796
assign 1 244 797
new 0 244 797
assign 1 244 798
add 1 244 798
assign 1 244 799
add 1 244 799
assign 1 244 800
new 0 244 800
assign 1 244 801
add 1 244 801
assign 1 244 802
addValue 1 244 802
assign 1 245 803
emitNameGet 0 245 803
assign 1 245 804
add 1 245 804
assign 1 245 805
new 0 245 805
assign 1 245 806
add 1 245 806
assign 1 245 807
addValue 1 245 807
return 1 246 808
assign 1 250 822
new 0 250 822
assign 1 250 823
libNameGet 0 250 823
assign 1 250 824
relEmitName 1 250 824
assign 1 250 825
add 1 250 825
assign 1 250 826
new 0 250 826
assign 1 250 827
add 1 250 827
assign 1 250 828
heldGet 0 250 828
assign 1 250 829
literalValueGet 0 250 829
assign 1 250 830
add 1 250 830
assign 1 250 831
new 0 250 831
assign 1 250 832
add 1 250 832
return 1 250 833
assign 1 254 847
new 0 254 847
assign 1 254 848
libNameGet 0 254 848
assign 1 254 849
relEmitName 1 254 849
assign 1 254 850
add 1 254 850
assign 1 254 851
new 0 254 851
assign 1 254 852
add 1 254 852
assign 1 254 853
heldGet 0 254 853
assign 1 254 854
literalValueGet 0 254 854
assign 1 254 855
add 1 254 855
assign 1 254 856
new 0 254 856
assign 1 254 857
add 1 254 857
return 1 254 858
assign 1 259 894
new 0 259 894
assign 1 259 895
libNameGet 0 259 895
assign 1 259 896
relEmitName 1 259 896
assign 1 259 897
add 1 259 897
assign 1 259 898
new 0 259 898
assign 1 259 899
add 1 259 899
assign 1 259 900
emitNameGet 0 259 900
assign 1 259 901
add 1 259 901
assign 1 259 902
new 0 259 902
assign 1 259 903
add 1 259 903
assign 1 259 904
add 1 259 904
assign 1 259 905
new 0 259 905
assign 1 259 906
add 1 259 906
assign 1 259 907
add 1 259 907
assign 1 259 908
new 0 259 908
assign 1 259 909
add 1 259 909
return 1 259 910
assign 1 261 912
new 0 261 912
assign 1 261 913
libNameGet 0 261 913
assign 1 261 914
relEmitName 1 261 914
assign 1 261 915
add 1 261 915
assign 1 261 916
new 0 261 916
assign 1 261 917
add 1 261 917
assign 1 261 918
emitNameGet 0 261 918
assign 1 261 919
add 1 261 919
assign 1 261 920
new 0 261 920
assign 1 261 921
add 1 261 921
assign 1 261 922
add 1 261 922
assign 1 261 923
new 0 261 923
assign 1 261 924
add 1 261 924
assign 1 261 925
add 1 261 925
assign 1 261 926
new 0 261 926
assign 1 261 927
add 1 261 927
return 1 261 928
assign 1 265 943
def 1 265 948
assign 1 266 949
libNameGet 0 266 949
assign 1 266 950
relEmitName 1 266 950
assign 1 266 951
extend 1 266 951
assign 1 268 954
new 0 268 954
assign 1 268 955
extend 1 268 955
assign 1 270 957
new 0 270 957
assign 1 270 958
emitNameGet 0 270 958
assign 1 270 959
addValue 1 270 959
assign 1 270 960
new 0 270 960
assign 1 270 961
addValue 1 270 961
assign 1 278 962
new 0 278 962
assign 1 278 963
addValue 1 278 963
addValue 1 278 964
addValue 1 279 965
return 1 280 966
assign 1 284 995
heldGet 0 284 995
assign 1 284 996
superCallGet 0 284 996
assign 1 285 998
new 0 285 998
assign 1 285 999
notEmpty 1 285 999
assign 1 286 1001
new 0 286 1001
assign 1 286 1002
add 1 286 1002
assign 1 288 1005
new 0 288 1005
assign 1 290 1007
emitNameGet 0 290 1007
assign 1 290 1008
new 0 290 1008
assign 1 290 1009
add 1 290 1009
assign 1 290 1010
heldGet 0 290 1010
assign 1 290 1011
nameGet 0 290 1011
assign 1 290 1012
add 1 290 1012
assign 1 290 1013
new 0 290 1013
assign 1 290 1014
add 1 290 1014
assign 1 290 1015
add 1 290 1015
assign 1 290 1016
new 0 290 1016
assign 1 290 1017
add 1 290 1017
return 1 290 1018
assign 1 292 1020
new 0 292 1020
assign 1 292 1021
add 1 292 1021
assign 1 292 1022
heldGet 0 292 1022
assign 1 292 1023
nameGet 0 292 1023
assign 1 292 1024
add 1 292 1024
assign 1 292 1025
new 0 292 1025
assign 1 292 1026
add 1 292 1026
assign 1 292 1027
add 1 292 1027
assign 1 292 1028
new 0 292 1028
assign 1 292 1029
add 1 292 1029
return 1 292 1030
assign 1 296 1034
new 0 296 1034
return 1 297 1035
assign 1 304 1040
undef 1 304 1045
assign 1 305 1046
new 0 305 1046
addValue 1 307 1048
assign 1 308 1049
new 0 308 1049
return 1 308 1050
assign 1 313 1054
getLibOutput 0 313 1054
return 1 313 1055
assign 1 321 1086
undef 1 321 1091
assign 1 322 1092
new 0 322 1092
assign 1 323 1093
parentGet 0 323 1093
assign 1 323 1094
fileGet 0 323 1094
assign 1 323 1095
existsGet 0 323 1095
assign 1 323 1096
not 0 323 1101
assign 1 324 1102
parentGet 0 324 1102
assign 1 324 1103
fileGet 0 324 1103
makeDirs 0 324 1104
assign 1 326 1106
fileGet 0 326 1106
assign 1 326 1107
writerGet 0 326 1107
assign 1 326 1108
open 0 326 1108
assign 1 328 1109
paramsGet 0 328 1109
assign 1 328 1110
new 0 328 1110
assign 1 328 1111
has 1 328 1111
assign 1 329 1113
paramsGet 0 329 1113
assign 1 329 1114
new 0 329 1114
assign 1 329 1115
get 1 329 1115
assign 1 329 1116
iteratorGet 0 0 1116
assign 1 329 1119
hasNextGet 0 329 1119
assign 1 329 1121
nextGet 0 329 1121
assign 1 330 1122
apNew 1 330 1122
assign 1 330 1123
fileGet 0 330 1123
assign 1 331 1124
readerGet 0 331 1124
assign 1 331 1125
open 0 331 1125
assign 1 331 1126
readString 0 331 1126
assign 1 332 1127
readerGet 0 332 1127
close 0 332 1128
assign 1 333 1129
countLines 1 333 1129
addValue 1 333 1130
write 1 334 1131
return 1 340 1139
close 0 344 1142
assign 1 345 1143
assign 1 350 1148
new 0 350 1148
return 1 350 1149
assign 1 354 1153
new 0 354 1153
return 1 354 1154
assign 1 358 1158
new 0 358 1158
return 1 358 1159
assign 1 362 1163
new 0 362 1163
return 1 362 1164
assign 1 366 1168
new 0 366 1168
return 1 366 1169
assign 1 370 1173
new 0 370 1173
return 1 370 1174
assign 1 374 1178
new 0 374 1178
return 1 374 1179
assign 1 379 1183
new 0 379 1183
return 1 379 1184
assign 1 385 1188
new 0 385 1188
return 1 385 1189
assign 1 390 1193
new 0 390 1193
return 1 390 1194
assign 1 394 1202
new 0 394 1202
assign 1 394 1203
add 1 394 1203
assign 1 394 1204
new 0 394 1204
assign 1 394 1205
add 1 394 1205
assign 1 394 1206
add 1 394 1206
return 1 394 1207
assign 1 398 1211
new 0 398 1211
return 1 398 1212
assign 1 402 1219
libNameGet 0 402 1219
assign 1 402 1220
relEmitName 1 402 1220
assign 1 402 1221
new 0 402 1221
assign 1 402 1222
add 1 402 1222
return 1 402 1223
assign 1 407 1232
emitNameGet 0 407 1232
assign 1 407 1233
new 0 407 1233
assign 1 407 1234
add 1 407 1234
assign 1 407 1235
new 0 407 1235
assign 1 407 1236
add 1 407 1236
assign 1 407 1237
add 1 407 1237
return 1 407 1238
assign 1 412 1249
emitNameGet 0 412 1249
assign 1 412 1250
addValue 1 412 1250
assign 1 412 1251
new 0 412 1251
assign 1 412 1252
addValue 1 412 1252
assign 1 412 1253
addValue 1 412 1253
assign 1 412 1254
new 0 412 1254
addValue 1 412 1255
addValue 1 414 1256
assign 1 416 1257
new 0 416 1257
assign 1 416 1258
addValue 1 416 1258
addValue 1 416 1259
assign 1 421 1264
new 0 421 1264
return 1 421 1265
assign 1 425 1269
new 0 425 1269
return 1 425 1270
assign 1 429 1276
new 0 429 1276
assign 1 429 1277
add 1 429 1277
assign 1 429 1278
add 1 429 1278
return 1 429 1279
assign 1 434 1283
new 0 434 1283
return 1 434 1284
assign 1 438 1289
getClassConfig 1 438 1289
assign 1 439 1290
fullEmitNameGet 0 439 1290
emitNameSet 1 439 1291
return 1 440 1292
assign 1 444 1297
getLocalClassConfig 1 444 1297
assign 1 445 1298
fullEmitNameGet 0 445 1298
emitNameSet 1 445 1299
return 1 446 1300
return 1 0 1303
return 1 0 1306
assign 1 0 1309
assign 1 0 1313
return 1 0 1317
return 1 0 1320
assign 1 0 1323
assign 1 0 1327
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 646823289: return bem_doEmit_0();
case -1086919095: return bem_classCallsGet_0();
case -902106328: return bem_cnodeGetDirect_0();
case 1923646891: return bem_dynMethodsGet_0();
case -818971344: return bem_synEmitPathGetDirect_0();
case -1721261866: return bem_invpGet_0();
case -1628357999: return bem_libEmitPathGet_0();
case -1195700203: return bem_libEmitNameGetDirect_0();
case 1343532008: return bem_classCallsGetDirect_0();
case 2146604653: return bem_new_0();
case 2136749844: return bem_lastMethodsLinesGetDirect_0();
case 1166728449: return bem_buildInitial_0();
case 151302307: return bem_preClassGet_0();
case 663609612: return bem_typeDecGet_0();
case 1309827888: return bem_trueValueGet_0();
case -868362432: return bem_inFilePathedGetDirect_0();
case -53819633: return bem_callNamesGetDirect_0();
case -1256134567: return bem_callNamesGet_0();
case 1776377328: return bem_idToNamePathGetDirect_0();
case 1962808537: return bem_preClassOutput_0();
case -1802118474: return bem_exceptDecGetDirect_0();
case 482546648: return bem_classEmitsGet_0();
case -387947574: return bem_methodsGetDirect_0();
case -1087877643: return bem_msynGet_0();
case 2057140547: return bem_fullLibEmitNameGet_0();
case -1066306992: return bem_newDecGet_0();
case -944787526: return bem_gcMarksGet_0();
case 1810511644: return bem_methodCatchGet_0();
case 138886518: return bem_allOnceDecsGetDirect_0();
case 1079715015: return bem_buildClassInfo_0();
case 2113462777: return bem_synEmitPathGet_0();
case 2071706392: return bem_useDynMethodsGet_0();
case -1321970887: return bem_maxDynArgsGet_0();
case -1798528670: return bem_initialDecGet_0();
case 1834235196: return bem_cnodeGet_0();
case -1153726180: return bem_intNpGet_0();
case -838712213: return bem_instOfGetDirect_0();
case -1639371095: return bem_ntypesGet_0();
case 2004374802: return bem_stringNpGet_0();
case 908678857: return bem_print_0();
case -413130018: return bem_buildPropList_0();
case 1375566090: return bem_emitLib_0();
case 1612868412: return bem_ntypesGetDirect_0();
case -1495285966: return bem_methodBodyGetDirect_0();
case 1501664467: return bem_randGet_0();
case -915432079: return bem_classEndGet_0();
case 200469525: return bem_getLibOutput_0();
case 237017545: return bem_idToNameGet_0();
case -39122310: return bem_lineCountGetDirect_0();
case 1485612473: return bem_writeBET_0();
case -2042854670: return bem_trueValueGetDirect_0();
case 666601378: return bem_nameToIdPathGet_0();
case 150268016: return bem_intNpGetDirect_0();
case -1762478527: return bem_lastMethodBodyLinesGet_0();
case -881577546: return bem_classNameGet_0();
case 641839943: return bem_toAny_0();
case -1064864071: return bem_csynGetDirect_0();
case -634018133: return bem_tagGet_0();
case 569361306: return bem_iteratorGet_0();
case 186733185: return bem_lastCallGet_0();
case 1837107012: return bem_lastMethodBodySizeGet_0();
case -1005523228: return bem_methodCallsGet_0();
case 1224795703: return bem_ccCacheGet_0();
case -171365935: return bem_preClassGetDirect_0();
case -2031839191: return bem_serializationIteratorGet_0();
case 1983074826: return bem_nlGetDirect_0();
case -865169425: return bem_falseValueGet_0();
case -729603204: return bem_maxSpillArgsLenGet_0();
case -1006837746: return bem_constGet_0();
case 1819061990: return bem_instanceNotEqualGet_0();
case 2042041169: return bem_fileExtGetDirect_0();
case 942994770: return bem_covariantReturnsGet_0();
case -478423110: return bem_instanceEqualGetDirect_0();
case 899963928: return bem_inClassGet_0();
case 2139585364: return bem_mnodeGetDirect_0();
case 2040947934: return bem_superCallsGetDirect_0();
case -1747090097: return bem_gcMarksGetDirect_0();
case 340249648: return bem_maxDynArgsGetDirect_0();
case 1392064084: return bem_shlibeGet_0();
case -1180318661: return bem_classesInDepthOrderGet_0();
case -1750720088: return bem_hashGet_0();
case 395091631: return bem_lastMethodsSizeGet_0();
case -1601512485: return bem_lastMethodsSizeGetDirect_0();
case -800933500: return bem_objectNpGet_0();
case -998223757: return bem_objectCcGet_0();
case 230685666: return bem_classEmitsGetDirect_0();
case -115449476: return bem_nativeCSlotsGetDirect_0();
case 1716650463: return bem_methodsGet_0();
case 500998186: return bem_inFilePathedGet_0();
case 1452142167: return bem_fullLibEmitNameGetDirect_0();
case 846670018: return bem_onceCountGet_0();
case -662044571: return bem_dynMethodsGetDirect_0();
case -1286532424: return bem_ccMethodsGet_0();
case -2146016269: return bem_saveIds_0();
case 163513797: return bem_superCallsGet_0();
case 1461026666: return bem_nameToIdGet_0();
case 1719248637: return bem_ccCacheGetDirect_0();
case 1820533298: return bem_overrideMtdDecGet_0();
case -1835740905: return bem_instanceNotEqualGetDirect_0();
case 866336776: return bem_smnlecsGet_0();
case -1997036010: return bem_lastMethodsLinesGet_0();
case -502926965: return bem_methodCallsGetDirect_0();
case -720028246: return bem_nameToIdPathGetDirect_0();
case -1678204823: return bem_qGet_0();
case -1082691863: return bem_nativeCSlotsGet_0();
case 1782351683: return bem_serializeContents_0();
case -1692002869: return bem_fileExtGet_0();
case 273861147: return bem_allOnceDecsGet_0();
case 1387547038: return bem_classConfGetDirect_0();
case 267507275: return bem_transGetDirect_0();
case -1460231469: return bem_smnlcsGet_0();
case -855735856: return bem_buildGetDirect_0();
case -904466526: return bem_baseMtdDecGet_0();
case 971841201: return bem_fieldIteratorGet_0();
case 424521488: return bem_nullValueGet_0();
case -726529783: return bem_mainEndGet_0();
case 914241590: return bem_objectNpGetDirect_0();
case 1842426844: return bem_nlGet_0();
case 895960004: return bem_boolCcGetDirect_0();
case -326132901: return bem_boolNpGet_0();
case -899875556: return bem_libEmitPathGetDirect_0();
case -1809994046: return bem_propertyDecsGetDirect_0();
case -2062445616: return bem_superNameGet_0();
case -1411642383: return bem_classConfGet_0();
case -928509599: return bem_boolTypeGet_0();
case -1097304047: return bem_loadIds_0();
case -124285366: return bem_once_0();
case 413395465: return bem_transGet_0();
case 1068181813: return bem_randGetDirect_0();
case -212742483: return bem_echo_0();
case 655620620: return bem_floatNpGetDirect_0();
case -653750385: return bem_create_0();
case -1758625559: return bem_saveSyns_0();
case -954619393: return bem_afterCast_0();
case 1799159769: return bem_runtimeInitGet_0();
case -1006479396: return bem_returnTypeGet_0();
case -1294849394: return bem_baseSmtdDecGet_0();
case -1124160179: return bem_invpGetDirect_0();
case 2106355049: return bem_returnTypeGetDirect_0();
case -815057909: return bem_msynGetDirect_0();
case -1907188428: return bem_floatNpGet_0();
case -683112419: return bem_onceCountGetDirect_0();
case -1855666320: return bem_libEmitNameGet_0();
case 12111282: return bem_shlibeGetDirect_0();
case -257370559: return bem_beginNs_0();
case -1990550831: return bem_lastMethodBodySizeGetDirect_0();
case -1998747330: return bem_nameToIdGetDirect_0();
case -854511160: return bem_objectCcGetDirect_0();
case -400079944: return bem_exceptDecGet_0();
case 1099447992: return bem_fieldNamesGet_0();
case -1259978393: return bem_mainStartGet_0();
case 2145261709: return bem_belslitsGetDirect_0();
case 1760456201: return bem_idToNamePathGet_0();
case -89359279: return bem_falseValueGetDirect_0();
case -722498137: return bem_spropDecGet_0();
case -2007275567: return bem_many_0();
case 1267585317: return bem_lineCountGet_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case -242546956: return bem_belslitsGet_0();
case -1230751789: return bem_onceDecsGet_0();
case 14743300: return bem_parentConfGetDirect_0();
case 13742193: return bem_idToNameGetDirect_0();
case 555331476: return bem_instanceEqualGet_0();
case -1305371023: return bem_stringNpGetDirect_0();
case -985354433: return bem_scvpGetDirect_0();
case -1385204784: return bem_buildGet_0();
case -1373657831: return bem_constGetDirect_0();
case 2128445163: return bem_maxSpillArgsLenGetDirect_0();
case 881302857: return bem_smnlecsGetDirect_0();
case -451092612: return bem_methodBodyGet_0();
case -278324298: return bem_mnodeGet_0();
case -302265823: return bem_propDecGet_0();
case -224465120: return bem_sourceFileNameGet_0();
case -1938381034: return bem_qGetDirect_0();
case 1910395014: return bem_mainInClassGet_0();
case 722596708: return bem_ccMethodsGetDirect_0();
case 604182023: return bem_nullValueGetDirect_0();
case -1328345321: return bem_boolNpGetDirect_0();
case -1092510954: return bem_copy_0();
case 1579043352: return bem_scvpGet_0();
case -1803794503: return bem_buildCreate_0();
case 393738758: return bem_serializeToString_0();
case 1449923226: return bem_instOfGet_0();
case -1912093384: return bem_propertyDecsGet_0();
case 43838264: return bem_mainOutsideNsGet_0();
case -1888296242: return bem_boolCcGet_0();
case -1752174175: return bem_getClassOutput_0();
case -53699307: return bem_emitLangGet_0();
case 148544119: return bem_toString_0();
case 1605392742: return bem_classesInDepthOrderGetDirect_0();
case 1773361118: return bem_smnlcsGetDirect_0();
case 462378862: return bem_onceDecsGetDirect_0();
case -1718202904: return bem_inClassGetDirect_0();
case 169519118: return bem_emitLangGetDirect_0();
case 1591167957: return bem_parentConfGet_0();
case -1520854343: return bem_csynGet_0();
case -2111607285: return bem_lastMethodBodyLinesGetDirect_0();
case 1355413466: return bem_lastCallGetDirect_0();
case -1742135291: return bem_methodCatchGetDirect_0();
case -1198783266: return bem_endNs_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 69446296: return bem_methodCatchSetDirect_1(bevd_0);
case 419718997: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -566061966: return bem_ccMethodsSet_1(bevd_0);
case -966016152: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 323587335: return bem_callNamesSetDirect_1(bevd_0);
case 1067345399: return bem_inClassSetDirect_1(bevd_0);
case 589086139: return bem_cnodeSet_1(bevd_0);
case -1874361369: return bem_belslitsSet_1(bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1260157276: return bem_intNpSet_1(bevd_0);
case 338229476: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1116687296: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1702274080: return bem_nameToIdPathSet_1(bevd_0);
case -1098555327: return bem_begin_1(bevd_0);
case -479203590: return bem_randSet_1(bevd_0);
case 1559125065: return bem_exceptDecSetDirect_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case 853793569: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1175495648: return bem_belslitsSetDirect_1(bevd_0);
case 396146666: return bem_parentConfSet_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case -260775172: return bem_libEmitPathSet_1(bevd_0);
case -624032248: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1395946469: return bem_buildSetDirect_1(bevd_0);
case -1897095887: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1709135655: return bem_allOnceDecsSetDirect_1(bevd_0);
case 534029739: return bem_floatNpSetDirect_1(bevd_0);
case 1962092540: return bem_trueValueSetDirect_1(bevd_0);
case -1516710209: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -884607798: return bem_def_1(bevd_0);
case -1871239391: return bem_idToNamePathSetDirect_1(bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 651409556: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1995474416: return bem_nullValueSet_1(bevd_0);
case -2122791077: return bem_onceCountSetDirect_1(bevd_0);
case 1398155938: return bem_qSetDirect_1(bevd_0);
case 1791803349: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -493917687: return bem_constSetDirect_1(bevd_0);
case 2114116164: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 612596783: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1289781490: return bem_synEmitPathSet_1(bevd_0);
case 1675888187: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 840254928: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -233616486: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1732845627: return bem_objectCcSetDirect_1(bevd_0);
case -331303167: return bem_exceptDecSet_1(bevd_0);
case 1599409230: return bem_transSetDirect_1(bevd_0);
case 5516032: return bem_libEmitPathSetDirect_1(bevd_0);
case -2043208654: return bem_instOfSet_1(bevd_0);
case -1965723084: return bem_end_1(bevd_0);
case 1308611667: return bem_methodCatchSet_1(bevd_0);
case 1117233189: return bem_propertyDecsSetDirect_1(bevd_0);
case -1917450052: return bem_gcMarksSetDirect_1(bevd_0);
case 2074991958: return bem_smnlcsSetDirect_1(bevd_0);
case 433651423: return bem_propertyDecsSet_1(bevd_0);
case 613413476: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -2146454320: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -564024909: return bem_msynSet_1(bevd_0);
case 81964140: return bem_classCallsSetDirect_1(bevd_0);
case -764720261: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -314180939: return bem_objectNpSetDirect_1(bevd_0);
case 1613144744: return bem_scvpSet_1(bevd_0);
case -1671139741: return bem_ccMethodsSetDirect_1(bevd_0);
case 520606598: return bem_methodBodySet_1(bevd_0);
case 1250891055: return bem_methodBodySetDirect_1(bevd_0);
case -71220196: return bem_nameToIdSet_1(bevd_0);
case -2108576337: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1974828276: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1597904464: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1238149813: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1969699365: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case 1895744253: return bem_onceCountSet_1(bevd_0);
case -225683550: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1957185547: return bem_libEmitNameSet_1(bevd_0);
case 1704222442: return bem_mnodeSet_1(bevd_0);
case 1657448166: return bem_shlibeSetDirect_1(bevd_0);
case -1120315216: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1674360: return bem_superCallsSetDirect_1(bevd_0);
case 131617795: return bem_fullLibEmitNameSet_1(bevd_0);
case -1167781281: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 668791275: return bem_gcMarksSet_1(bevd_0);
case 1267499529: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1475841531: return bem_nlSetDirect_1(bevd_0);
case 1614416297: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1254029122: return bem_dynMethodsSetDirect_1(bevd_0);
case -769668771: return bem_lastMethodsSizeSet_1(bevd_0);
case 389856415: return bem_transSet_1(bevd_0);
case -173182286: return bem_smnlcsSet_1(bevd_0);
case -615448643: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -576747961: return bem_parentConfSetDirect_1(bevd_0);
case -573959153: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 409783352: return bem_lastCallSetDirect_1(bevd_0);
case -197197370: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1271968097: return bem_fileExtSetDirect_1(bevd_0);
case -1389606478: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -686677392: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1550323564: return bem_boolCcSet_1(bevd_0);
case -1276601667: return bem_onceDecsSet_1(bevd_0);
case 902927835: return bem_intNpSetDirect_1(bevd_0);
case 1693525626: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 30609929: return bem_inClassSet_1(bevd_0);
case -679164869: return bem_smnlecsSet_1(bevd_0);
case -1087018120: return bem_csynSet_1(bevd_0);
case 1326308235: return bem_methodCallsSetDirect_1(bevd_0);
case 1006002153: return bem_instanceNotEqualSet_1(bevd_0);
case 1715549632: return bem_falseValueSetDirect_1(bevd_0);
case 2128294996: return bem_mnodeSetDirect_1(bevd_0);
case 1322344715: return bem_csynSetDirect_1(bevd_0);
case -1742169645: return bem_nativeCSlotsSet_1(bevd_0);
case -1227085501: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 2087229279: return bem_boolNpSetDirect_1(bevd_0);
case -402623089: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1076333450: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -292288689: return bem_classesInDepthOrderSet_1(bevd_0);
case -1096821195: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 743367089: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 519535501: return bem_nameToIdSetDirect_1(bevd_0);
case 1339320831: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 98944077: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 851087273: return bem_allOnceDecsSet_1(bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case 2029091088: return bem_instanceEqualSetDirect_1(bevd_0);
case -33062512: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1431785058: return bem_dynMethodsSet_1(bevd_0);
case 1927945740: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1158505642: return bem_floatNpSet_1(bevd_0);
case 59638896: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case -181910759: return bem_objectNpSet_1(bevd_0);
case -1490138443: return bem_maxSpillArgsLenSet_1(bevd_0);
case 507386329: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1386459809: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1177522670: return bem_ccCacheSetDirect_1(bevd_0);
case -362018761: return bem_callNamesSet_1(bevd_0);
case 1370275378: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1767979815: return bem_classConfSet_1(bevd_0);
case -1277527661: return bem_lineCountSet_1(bevd_0);
case -1985408091: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1942737597: return bem_scvpSetDirect_1(bevd_0);
case 1445545522: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1099248872: return bem_invpSetDirect_1(bevd_0);
case -1605483583: return bem_synEmitPathSetDirect_1(bevd_0);
case -194596178: return bem_stringNpSet_1(bevd_0);
case -1937066510: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -295420620: return bem_preClassSet_1(bevd_0);
case -1445710770: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 757377022: return bem_lastMethodsLinesSet_1(bevd_0);
case 679414709: return bem_msynSetDirect_1(bevd_0);
case -48215943: return bem_ccCacheSet_1(bevd_0);
case -1930526131: return bem_preClassSetDirect_1(bevd_0);
case -1132848828: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1507597696: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -599782276: return bem_cnodeSetDirect_1(bevd_0);
case -2118561189: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 981317794: return bem_inFilePathedSetDirect_1(bevd_0);
case 1305409847: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -160494861: return bem_nlSet_1(bevd_0);
case -251413512: return bem_instOfSetDirect_1(bevd_0);
case 355191902: return bem_classEmitsSetDirect_1(bevd_0);
case 1776711103: return bem_methodsSetDirect_1(bevd_0);
case -36683744: return bem_falseValueSet_1(bevd_0);
case -1405698346: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -198740682: return bem_returnTypeSetDirect_1(bevd_0);
case -1725639892: return bem_classCallsSet_1(bevd_0);
case 852742351: return bem_libEmitNameSetDirect_1(bevd_0);
case -1360718904: return bem_idToNameSet_1(bevd_0);
case -1115704725: return bem_emitLangSetDirect_1(bevd_0);
case -1774445847: return bem_qSet_1(bevd_0);
case 1583095440: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1295149004: return bem_nameToIdPathSetDirect_1(bevd_0);
case -559486335: return bem_boolNpSet_1(bevd_0);
case -560122016: return bem_onceDecsSetDirect_1(bevd_0);
case 1735237316: return bem_methodsSet_1(bevd_0);
case -709060621: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 888557808: return bem_classEmitsSet_1(bevd_0);
case -208478360: return bem_nullValueSetDirect_1(bevd_0);
case -305725605: return bem_trueValueSet_1(bevd_0);
case -784006715: return bem_constSet_1(bevd_0);
case 1351215318: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -376324907: return bem_randSetDirect_1(bevd_0);
case -992760071: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case -1593387783: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 8203800: return bem_idToNamePathSet_1(bevd_0);
case 1817714883: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case 1367325140: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1087016024: return bem_maxDynArgsSet_1(bevd_0);
case -1173609708: return bem_objectCcSet_1(bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case -486157824: return bem_instanceEqualSet_1(bevd_0);
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -957505831: return bem_classConfSetDirect_1(bevd_0);
case -448360789: return bem_otherClass_1(bevd_0);
case 1163482839: return bem_ntypesSetDirect_1(bevd_0);
case 1491295407: return bem_inFilePathedSet_1(bevd_0);
case -849302818: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1703616583: return bem_notEquals_1(bevd_0);
case -386897817: return bem_idToNameSetDirect_1(bevd_0);
case 1909609125: return bem_smnlecsSetDirect_1(bevd_0);
case 218537229: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1065328932: return bem_returnTypeSet_1(bevd_0);
case -1591512279: return bem_lineCountSetDirect_1(bevd_0);
case 1158216913: return bem_emitLangSet_1(bevd_0);
case 569732288: return bem_invpSet_1(bevd_0);
case 1022262742: return bem_ntypesSet_1(bevd_0);
case -1850885075: return bem_lastCallSet_1(bevd_0);
case -1485110333: return bem_fileExtSet_1(bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case 1921565395: return bem_stringNpSetDirect_1(bevd_0);
case 403746227: return bem_buildSet_1(bevd_0);
case 242779919: return bem_methodCallsSet_1(bevd_0);
case 769767216: return bem_shlibeSet_1(bevd_0);
case 886071917: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1762272429: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1936706111: return bem_superCallsSet_1(bevd_0);
case 1981934857: return bem_boolCcSetDirect_1(bevd_0);
case -147280839: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1704903806: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -955325243: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -697497061: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1500686415: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1917844223: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -93538800: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2076599887: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1182882959: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1951518940: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1202172054: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1355427790: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -128979347: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -934822993: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1933445343: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -520667396: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1277882295: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1988547019: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1221634327: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1860013025: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1463072636: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -6622048: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
