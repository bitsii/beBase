package be;
/* IO:File: source/build/Pass2.be */
public final class BEC_3_5_5_5_BuildVisitPass2 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass2() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x32};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass2_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass2_bels_0 = {0x2E};
public static BEC_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass2 bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;

public BEC_2_4_3_MathInt bevp_idType;
public BEC_2_4_3_MathInt bevp_intType;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_3_5_5_5_BuildVisitPass2 bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
BEC_2_5_9_BuildConstants bevt_0_ta_ph = null;
BEC_2_5_9_BuildConstants bevt_1_ta_ph = null;
super.bem_begin_1(beva_transi);
bevp_idType = bevp_ntypes.bem_IDGet_0();
bevp_intType = bevp_ntypes.bem_INTLGet_0();
bevt_0_ta_ph = bevp_build.bem_constantsGet_0();
bevp_matchMap = bevt_0_ta_ph.bem_matchMapGet_0();
bevt_1_ta_ph = bevp_build.bem_constantsGet_0();
bevp_rwords = bevt_1_ta_ph.bem_rwordsGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_held = null;
BEC_2_6_6_SystemObject bevl_type = null;
BEC_2_5_4_BuildNode bevl_nxp = null;
BEC_2_5_4_BuildNode bevl_nxp2 = null;
BEC_2_5_4_BuildNode bevl_nxp3 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_BuildNode bevt_27_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 33*/ {
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 34*/
bevl_held = beva_node.bem_heldGet_0();
if (bevl_held == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 37*/ {
bevl_type = bevp_matchMap.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 39*/ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 41*/
 else /* Line: 42*/ {
bevt_8_ta_ph = bevl_held.bemd_0(262834587);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 44*/ {
bevl_nxp = beva_node.bem_nextPeerGet_0();
if (bevl_nxp == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 46*/ {
bevt_11_ta_ph = bevl_nxp.bem_heldGet_0();
if (bevt_11_ta_ph == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 46*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 46*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 46*/
 else /* Line: 46*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 46*/ {
bevt_13_ta_ph = bevl_nxp.bem_heldGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass2_bels_0));
bevt_12_ta_ph = bevt_13_ta_ph.bemd_1(145823261, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 47*/ {
bevl_nxp2 = bevl_nxp.bem_nextPeerGet_0();
if (bevl_nxp2 == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_17_ta_ph = bevl_nxp2.bem_heldGet_0();
if (bevt_17_ta_ph == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 49*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 49*/ {
bevl_nxp3 = bevl_nxp2.bem_nextDescendGet_0();
bevt_19_ta_ph = bevl_nxp2.bem_heldGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(262834587);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 51*/ {
bevt_22_ta_ph = beva_node.bem_heldGet_0();
bevt_23_ta_ph = bevl_nxp.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1706536744, bevt_23_ta_ph);
bevt_24_ta_ph = bevl_nxp2.bem_heldGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_1(1706536744, bevt_24_ta_ph);
beva_node.bem_heldSet_1(bevt_20_ta_ph);
bevt_25_ta_ph = bevp_ntypes.bem_FLOATLGet_0();
beva_node.bem_typenameSet_1(bevt_25_ta_ph);
bevl_nxp2.bem_remove_0();
bevl_nxp.bem_remove_0();
return bevl_nxp3;
} /* Line: 56*/
} /* Line: 51*/
} /* Line: 49*/
} /* Line: 47*/
beva_node.bem_typenameSet_1(bevp_intType);
} /* Line: 61*/
 else /* Line: 62*/ {
bevl_type = bevp_rwords.bem_get_1(bevl_held);
if (bevl_type == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 64*/ {
beva_node.bem_typenameSet_1(bevl_type);
} /* Line: 65*/
 else /* Line: 66*/ {
beva_node.bem_typenameSet_1(bevp_idType);
} /* Line: 67*/
} /* Line: 64*/
} /* Line: 44*/
} /* Line: 39*/
bevt_27_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_27_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_idTypeGet_0() throws Throwable {
return bevp_idType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_idTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_idType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intTypeGet_0() throws Throwable {
return bevp_intType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_intTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_intType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() throws Throwable {
return bevp_matchMap;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() throws Throwable {
return bevp_rwords;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass2 bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 24, 25, 26, 26, 27, 27, 33, 33, 33, 33, 34, 34, 36, 37, 37, 38, 39, 39, 41, 44, 45, 46, 46, 46, 46, 46, 0, 0, 0, 47, 47, 47, 48, 49, 49, 49, 49, 49, 0, 0, 0, 50, 51, 51, 52, 52, 52, 52, 52, 52, 53, 53, 54, 55, 56, 61, 63, 64, 64, 65, 67, 72, 72, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 22, 23, 24, 25, 62, 63, 64, 69, 70, 71, 73, 74, 79, 80, 81, 86, 87, 90, 92, 93, 98, 99, 100, 105, 106, 109, 113, 116, 117, 118, 120, 121, 126, 127, 128, 133, 134, 137, 141, 144, 145, 146, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 163, 166, 167, 172, 173, 176, 181, 182, 185, 188, 192, 195, 199, 202, 206, 209};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 21 19
assign 1 24 20
IDGet 0 24 20
assign 1 25 21
INTLGet 0 25 21
assign 1 26 22
constantsGet 0 26 22
assign 1 26 23
matchMapGet 0 26 23
assign 1 27 24
constantsGet 0 27 24
assign 1 27 25
rwordsGet 0 27 25
assign 1 33 62
typenameGet 0 33 62
assign 1 33 63
TRANSUNITGet 0 33 63
assign 1 33 64
equals 1 33 69
assign 1 34 70
nextDescendGet 0 34 70
return 1 34 71
assign 1 36 73
heldGet 0 36 73
assign 1 37 74
def 1 37 79
assign 1 38 80
get 1 38 80
assign 1 39 81
def 1 39 86
typenameSet 1 41 87
assign 1 44 90
isIntegerGet 0 44 90
assign 1 45 92
nextPeerGet 0 45 92
assign 1 46 93
def 1 46 98
assign 1 46 99
heldGet 0 46 99
assign 1 46 100
def 1 46 105
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 47 116
heldGet 0 47 116
assign 1 47 117
new 0 47 117
assign 1 47 118
equals 1 47 118
assign 1 48 120
nextPeerGet 0 48 120
assign 1 49 121
def 1 49 126
assign 1 49 127
heldGet 0 49 127
assign 1 49 128
def 1 49 133
assign 1 0 134
assign 1 0 137
assign 1 0 141
assign 1 50 144
nextDescendGet 0 50 144
assign 1 51 145
heldGet 0 51 145
assign 1 51 146
isIntegerGet 0 51 146
assign 1 52 148
heldGet 0 52 148
assign 1 52 149
heldGet 0 52 149
assign 1 52 150
add 1 52 150
assign 1 52 151
heldGet 0 52 151
assign 1 52 152
add 1 52 152
heldSet 1 52 153
assign 1 53 154
FLOATLGet 0 53 154
typenameSet 1 53 155
remove 0 54 156
remove 0 55 157
return 1 56 158
typenameSet 1 61 163
assign 1 63 166
get 1 63 166
assign 1 64 167
def 1 64 172
typenameSet 1 65 173
typenameSet 1 67 176
assign 1 72 181
nextDescendGet 0 72 181
return 1 72 182
return 1 0 185
assign 1 0 188
return 1 0 192
assign 1 0 195
return 1 0 199
assign 1 0 202
return 1 0 206
assign 1 0 209
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -308470073: return bem_hashGet_0();
case 1045256597: return bem_new_0();
case -1348914949: return bem_buildGet_0();
case 1661802748: return bem_print_0();
case 544713611: return bem_rwordsGet_0();
case -1225636174: return bem_toString_0();
case 1375409336: return bem_copy_0();
case -355124364: return bem_create_0();
case -1277020716: return bem_intTypeGet_0();
case 1431165396: return bem_ntypesGet_0();
case 1000772956: return bem_transGet_0();
case 1043863121: return bem_constGet_0();
case 1389378690: return bem_iteratorGet_0();
case -1772891407: return bem_idTypeGet_0();
case 119641648: return bem_matchMapGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1410683219: return bem_notEquals_1(bevd_0);
case 1024858296: return bem_copyTo_1(bevd_0);
case 1773296708: return bem_begin_1(bevd_0);
case 459198389: return bem_idTypeSet_1(bevd_0);
case 207992556: return bem_def_1(bevd_0);
case -2119998280: return bem_undef_1(bevd_0);
case 158845737: return bem_constSet_1(bevd_0);
case 682848832: return bem_rwordsSet_1(bevd_0);
case 160232648: return bem_transSet_1(bevd_0);
case 56051856: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 370009006: return bem_ntypesSet_1(bevd_0);
case 789789310: return bem_print_1(bevd_0);
case 145823261: return bem_equals_1(bevd_0);
case 847023395: return bem_matchMapSet_1(bevd_0);
case 1704487413: return bem_intTypeSet_1(bevd_0);
case -136479842: return bem_buildSet_1(bevd_0);
case -93528922: return bem_end_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1648212160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 195884639: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1847574000: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 369351178: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass2_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass2_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass2();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst = (BEC_3_5_5_5_BuildVisitPass2) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass2.bece_BEC_3_5_5_5_BuildVisitPass2_bevs_type;
}
}
