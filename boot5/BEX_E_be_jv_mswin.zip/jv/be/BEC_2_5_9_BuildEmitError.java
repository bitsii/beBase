package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError extends BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1062524217: return bem_create_0();
case -724376869: return bem_msgGet_0();
case -2117173126: return bem_new_0();
case -702355927: return bem_langGet_0();
case 1375653277: return bem_vvGet_0();
case -1934249204: return bem_print_0();
case 5890667: return bem_framesTextGet_0();
case 929442346: return bem_translatedGet_0();
case 555004610: return bem_emitLangGet_0();
case 66953015: return bem_iteratorGet_0();
case -366794572: return bem_descriptionGet_0();
case 1587585403: return bem_klassNameGet_0();
case 401546844: return bem_copy_0();
case 1000052795: return bem_hashGet_0();
case 1238195615: return bem_nodeGet_0();
case -1523761823: return bem_fileNameGet_0();
case 789336479: return bem_toString_0();
case -378716474: return bem_framesGet_0();
case -1563287989: return bem_methodNameGet_0();
case -508585239: return bem_getFrameText_0();
case -373546143: return bem_lineNumberGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 846157257: return bem_translatedSet_1(bevd_0);
case 1825279481: return bem_undef_1(bevd_0);
case -1433542779: return bem_equals_1(bevd_0);
case 334838796: return bem_vvSet_1(bevd_0);
case -1452071763: return bem_copyTo_1(bevd_0);
case -131722701: return bem_new_1(bevd_0);
case -1936766817: return bem_def_1(bevd_0);
case 1075662720: return bem_framesSet_1(bevd_0);
case 1481679760: return bem_notEquals_1(bevd_0);
case -1067389453: return bem_emitLangSet_1(bevd_0);
case 1341386761: return bem_lineNumberSet_1(bevd_0);
case -2087729604: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1194879360: return bem_descriptionSet_1(bevd_0);
case -1229539905: return bem_fileNameSet_1(bevd_0);
case 669374924: return bem_framesTextSet_1(bevd_0);
case 1847435880: return bem_msgSet_1(bevd_0);
case 890259662: return bem_nodeSet_1(bevd_0);
case -1352862948: return bem_langSet_1(bevd_0);
case -1718364958: return bem_methodNameSet_1(bevd_0);
case -1840807240: return bem_klassNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 541953148: return bem_new_2(bevd_0, bevd_1);
case 1895247931: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 572178426: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1090949571: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -76193545: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1215081188: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildEmitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
