package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError extends BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2027973265: return bem_lineNumberGet_0();
case 115372562: return bem_descriptionGet_0();
case -1725748534: return bem_msgGet_0();
case 782047985: return bem_methodNameGet_0();
case -343641898: return bem_klassNameGet_0();
case 2006813550: return bem_print_0();
case -753678241: return bem_toString_0();
case -1679021371: return bem_emitLangGet_0();
case 1122124820: return bem_framesGet_0();
case 1670031147: return bem_nodeGet_0();
case -1202199849: return bem_new_0();
case -181284836: return bem_getFrameText_0();
case 142227109: return bem_copy_0();
case -1965821747: return bem_framesTextGet_0();
case 2131863320: return bem_vvGet_0();
case 1883105734: return bem_create_0();
case -346231273: return bem_translatedGet_0();
case -2072460600: return bem_fileNameGet_0();
case 135466177: return bem_hashGet_0();
case 1653976958: return bem_iteratorGet_0();
case 330102481: return bem_langGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1325771233: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1624317506: return bem_nodeSet_1(bevd_0);
case 482599590: return bem_def_1(bevd_0);
case -1515495753: return bem_emitLangSet_1(bevd_0);
case 1821973452: return bem_framesTextSet_1(bevd_0);
case 1489287764: return bem_translatedSet_1(bevd_0);
case 413616696: return bem_notEquals_1(bevd_0);
case 317788441: return bem_fileNameSet_1(bevd_0);
case -2104029535: return bem_undef_1(bevd_0);
case 1883405602: return bem_vvSet_1(bevd_0);
case -1671327202: return bem_msgSet_1(bevd_0);
case 595179209: return bem_new_1(bevd_0);
case 1032699113: return bem_framesSet_1(bevd_0);
case 32426158: return bem_langSet_1(bevd_0);
case 1456028789: return bem_klassNameSet_1(bevd_0);
case -1252553549: return bem_descriptionSet_1(bevd_0);
case -103408206: return bem_methodNameSet_1(bevd_0);
case 72201968: return bem_equals_1(bevd_0);
case 1888968278: return bem_lineNumberSet_1(bevd_0);
case 388121757: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 102060006: return bem_new_2(bevd_0, bevd_1);
case -938062108: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -771677452: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -544842910: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 844231596: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1660164568: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildEmitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
