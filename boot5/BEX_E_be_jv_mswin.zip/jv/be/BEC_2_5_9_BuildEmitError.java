package be;
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError extends BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 150380928: return bem_vvGet_0();
case -328556546: return bem_emitLangGetDirect_0();
case -1986003652: return bem_klassNameGet_0();
case -39673733: return bem_emitLangGet_0();
case 106780997: return bem_nodeGetDirect_0();
case 418773895: return bem_langGetDirect_0();
case -1735168136: return bem_nodeGet_0();
case -1571514733: return bem_framesTextGet_0();
case 854710191: return bem_create_0();
case 1847639727: return bem_new_0();
case -1331374769: return bem_toString_0();
case 81509878: return bem_translatedGet_0();
case 1087307352: return bem_lineNumberGet_0();
case 38127485: return bem_iteratorGet_0();
case 936862305: return bem_translatedGetDirect_0();
case 125506977: return bem_vvGetDirect_0();
case -792396328: return bem_getFrameText_0();
case -188995241: return bem_lineNumberGetDirect_0();
case 1095667243: return bem_framesGetDirect_0();
case -379003245: return bem_framesTextGetDirect_0();
case -593469656: return bem_sourceFileNameGet_0();
case 636345: return bem_print_0();
case 1084314011: return bem_langGet_0();
case 1860407294: return bem_descriptionGetDirect_0();
case -199251519: return bem_descriptionGet_0();
case 319352223: return bem_framesGet_0();
case -1549864865: return bem_klassNameGetDirect_0();
case 793589441: return bem_classNameGet_0();
case -1931931140: return bem_msgGet_0();
case -1335617350: return bem_fileNameGetDirect_0();
case -1818293830: return bem_fieldNamesGet_0();
case -97490856: return bem_methodNameGetDirect_0();
case -22788464: return bem_hashGet_0();
case -419246867: return bem_methodNameGet_0();
case -287252244: return bem_msgGetDirect_0();
case 2061432375: return bem_tagGet_0();
case -279251516: return bem_fileNameGet_0();
case -1508036637: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1281048000: return bem_notEquals_1(bevd_0);
case 1083056257: return bem_vvSet_1(bevd_0);
case -218462789: return bem_methodNameSet_1(bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2116298318: return bem_klassNameSetDirect_1(bevd_0);
case -1834645072: return bem_framesSetDirect_1(bevd_0);
case 135501522: return bem_descriptionSetDirect_1(bevd_0);
case -2125778327: return bem_lineNumberSetDirect_1(bevd_0);
case -1800952931: return bem_fileNameSetDirect_1(bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
case -545405418: return bem_methodNameSetDirect_1(bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case 842617592: return bem_descriptionSet_1(bevd_0);
case -571141497: return bem_nodeSet_1(bevd_0);
case 843550336: return bem_fileNameSet_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case -373346759: return bem_klassNameSet_1(bevd_0);
case 1350538828: return bem_langSet_1(bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case 1417136546: return bem_framesTextSet_1(bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case -771559984: return bem_translatedSet_1(bevd_0);
case -1046528567: return bem_framesSet_1(bevd_0);
case 1180729850: return bem_translatedSetDirect_1(bevd_0);
case -1134337472: return bem_msgSet_1(bevd_0);
case -353727689: return bem_emitLangSet_1(bevd_0);
case -2109329813: return bem_nodeSetDirect_1(bevd_0);
case 2069037463: return bem_emitLangSetDirect_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case -785087004: return bem_new_1(bevd_0);
case 27814621: return bem_langSetDirect_1(bevd_0);
case -2027330087: return bem_vvSetDirect_1(bevd_0);
case 2081955240: return bem_lineNumberSet_1(bevd_0);
case 1209355945: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1857743790: return bem_msgSetDirect_1(bevd_0);
case -1486190194: return bem_framesTextSetDirect_1(bevd_0);
case -502376443: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -463850981: return bem_new_2(bevd_0, bevd_1);
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -2145430509: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildEmitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
