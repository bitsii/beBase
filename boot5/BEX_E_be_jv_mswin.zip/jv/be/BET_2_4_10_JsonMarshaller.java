package be;
public class BET_2_4_10_JsonMarshaller extends BETS_Object {
public BET_2_4_10_JsonMarshaller() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "marshall_1", "marshallWrite_2", "marshallWriteInst_2", "jsonEscapePoint_2", "jsonEscape_1", "jsonEscape_3", "marshallWriteString_2", "marshallWriteList_2", "marshallWriteMap_2", "strGet_0", "strSet_1", "arrGet_0", "arrSet_1", "mapGet_0", "mapSet_1", "intGet_0", "intSet_1", "booGet_0", "booSet_1", "qGet_0", "qSet_1", "mbiGet_0", "mbiSet_1", "txtptGet_0", "txtptSet_1", "escapedGet_0", "escapedSet_1", "stpGet_0", "stpSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "str", "arr", "map", "int", "boo", "q", "mbi", "txtpt", "escaped", "stp" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_10_JsonMarshaller();
}
}
