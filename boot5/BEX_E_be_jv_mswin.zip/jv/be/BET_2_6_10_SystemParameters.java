package be;
public class BET_2_6_10_SystemParameters extends BETS_Object {
public BET_2_6_10_SystemParameters() {String[] bevs_mtnames = new String[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "toJson_0", "fromJson_1", "fromJsonFile_1", "toJsonFile_1", "addValue_1", "new_1", "addArgs_1", "preProcessorSet_1", "isTrue_2", "isTrue_1", "has_1", "get_1", "get_2", "getFirst_1", "getFirst_2", "addParameter_2", "addParam_2", "addFile_1", "initialArgsGet_0", "initialArgsGetDirect_0", "initialArgsSet_1", "initialArgsSetDirect_1", "argsGet_0", "argsGetDirect_0", "argsSet_1", "argsSetDirect_1", "paramsGet_0", "paramsGetDirect_0", "paramsSet_1", "paramsSetDirect_1", "orderedGet_0", "orderedGetDirect_0", "orderedSet_1", "orderedSetDirect_1", "fileTokGet_0", "fileTokGetDirect_0", "fileTokSet_1", "fileTokSetDirect_1", "preProcessorGet_0", "preProcessorGetDirect_0", "preProcessorSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "initialArgs", "args", "params", "ordered", "fileTok", "preProcessor" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_10_SystemParameters();
}
}
