package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildVarSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildVarSyn() { }
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_inst;

public static BET_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_6_BuildVarSyn bem_new_0() throws Throwable {
bevp_isTyped = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_npNew_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
bevp_namepath = beva_np;
bevp_isTyped = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_anyNew_1(BEC_2_5_3_BuildVar beva_full) throws Throwable {
bevp_name = beva_full.bem_nameGet_0();
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_5_6_BuildVarSyn beva_o) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_o == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 39 */
if (bevp_name == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_7_tmpany_phold = beva_o.bem_nameGet_0();
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_9_tmpany_phold = beva_o.bem_nameGet_0();
bevt_8_tmpany_phold = bevp_name.bem_notEquals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 41 */
bevt_12_tmpany_phold = beva_o.bem_isTypedGet_0();
bevt_11_tmpany_phold = bevp_isTyped.bem_notEquals_1(bevt_12_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 44 */
if (bevp_isTyped.bevi_bool) /* Line: 46 */ {
bevt_15_tmpany_phold = beva_o.bem_namepathGet_0();
bevt_14_tmpany_phold = bevp_namepath.bem_notEquals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 47 */
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isTypedGetDirect_0() throws Throwable {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_isTypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isSelfGetDirect_0() throws Throwable {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_isSelfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() throws Throwable {
return bevp_isThis;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isThisGetDirect_0() throws Throwable {
return bevp_isThis;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_6_BuildVarSyn bem_isThisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 24, 25, 30, 31, 32, 33, 34, 39, 39, 39, 39, 40, 40, 40, 40, 40, 0, 0, 0, 40, 40, 0, 0, 0, 41, 41, 43, 43, 44, 44, 46, 46, 0, 0, 0, 47, 47, 49, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 21, 22, 26, 27, 28, 29, 30, 52, 57, 58, 59, 61, 66, 67, 68, 73, 74, 77, 81, 84, 85, 87, 90, 94, 97, 98, 100, 101, 103, 104, 107, 108, 110, 113, 117, 120, 121, 123, 124, 127, 130, 133, 137, 141, 144, 147, 151, 155, 158, 161, 165, 169, 172, 175, 179, 183, 186, 189, 193};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 17
new 0 20 17
assign 1 24 21
assign 1 25 22
new 0 25 22
assign 1 30 26
nameGet 0 30 26
assign 1 31 27
namepathGet 0 31 27
assign 1 32 28
isTypedGet 0 32 28
assign 1 33 29
isSelfGet 0 33 29
assign 1 34 30
isThisGet 0 34 30
assign 1 39 52
undef 1 39 57
assign 1 39 58
new 0 39 58
return 1 39 59
assign 1 40 61
def 1 40 66
assign 1 40 67
nameGet 0 40 67
assign 1 40 68
def 1 40 73
assign 1 0 74
assign 1 0 77
assign 1 0 81
assign 1 40 84
nameGet 0 40 84
assign 1 40 85
notEquals 1 40 85
assign 1 0 87
assign 1 0 90
assign 1 0 94
assign 1 41 97
new 0 41 97
return 1 41 98
assign 1 43 100
isTypedGet 0 43 100
assign 1 43 101
notEquals 1 43 101
assign 1 44 103
new 0 44 103
return 1 44 104
assign 1 46 107
namepathGet 0 46 107
assign 1 46 108
notEquals 1 46 108
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 47 120
new 0 47 120
return 1 47 121
assign 1 49 123
new 0 49 123
return 1 49 124
return 1 0 127
return 1 0 130
assign 1 0 133
assign 1 0 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
return 1 0 155
return 1 0 158
assign 1 0 161
assign 1 0 165
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2003774128: return bem_nameGet_0();
case -102149480: return bem_serializeToString_0();
case 1482277663: return bem_echo_0();
case -41333960: return bem_deserializeClassNameGet_0();
case -2107653327: return bem_fieldIteratorGet_0();
case -314408008: return bem_iteratorGet_0();
case -1990041666: return bem_isSelfGet_0();
case 1821082307: return bem_print_0();
case 1851614804: return bem_isTypedGetDirect_0();
case -511250160: return bem_fieldNamesGet_0();
case 577093211: return bem_many_0();
case -1425389541: return bem_new_0();
case -670803938: return bem_sourceFileNameGet_0();
case -1944312485: return bem_isSelfGetDirect_0();
case 361790008: return bem_hashGet_0();
case -408995472: return bem_isThisGetDirect_0();
case -1920210020: return bem_once_0();
case 1144340710: return bem_namepathGet_0();
case 1800445194: return bem_create_0();
case 296622746: return bem_classNameGet_0();
case 463099877: return bem_isThisGet_0();
case -19384722: return bem_toAny_0();
case -1768205182: return bem_serializationIteratorGet_0();
case -2074204580: return bem_copy_0();
case 1544245486: return bem_namepathGetDirect_0();
case 1679558291: return bem_nameGetDirect_0();
case -461072455: return bem_toString_0();
case 1993705736: return bem_serializeContents_0();
case -212193921: return bem_tagGet_0();
case -46457883: return bem_isTypedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1938540329: return bem_contentsEqual_1((BEC_2_5_6_BuildVarSyn) bevd_0);
case 521426561: return bem_isTypedSet_1(bevd_0);
case 1026739914: return bem_defined_1(bevd_0);
case -1192710672: return bem_equals_1(bevd_0);
case 1961670890: return bem_nameSet_1(bevd_0);
case 1895642098: return bem_anyNew_1((BEC_2_5_3_BuildVar) bevd_0);
case -1265268146: return bem_isSelfSetDirect_1(bevd_0);
case -1908940247: return bem_otherClass_1(bevd_0);
case -784434267: return bem_namepathSetDirect_1(bevd_0);
case -1987055831: return bem_notEquals_1(bevd_0);
case -1398560259: return bem_otherType_1(bevd_0);
case 955731831: return bem_npNew_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1245326192: return bem_isSelfSet_1(bevd_0);
case -1272397031: return bem_sameClass_1(bevd_0);
case -2110248602: return bem_undefined_1(bevd_0);
case -1463366211: return bem_def_1(bevd_0);
case -1161197989: return bem_sameType_1(bevd_0);
case 953495563: return bem_nameSetDirect_1(bevd_0);
case 242004544: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 331997677: return bem_isThisSet_1(bevd_0);
case -1888047780: return bem_isTypedSetDirect_1(bevd_0);
case 1389268037: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1734943196: return bem_isThisSetDirect_1(bevd_0);
case 764373340: return bem_copyTo_1(bevd_0);
case -1567535449: return bem_sameObject_1(bevd_0);
case 649915710: return bem_namepathSet_1(bevd_0);
case -155631619: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -320284120: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -676548815: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 764231776: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -830320987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -711906439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1354452916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1773886690: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220461512: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 278898562: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildVarSyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildVarSyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildVarSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst = (BEC_2_5_6_BuildVarSyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_type;
}
}
