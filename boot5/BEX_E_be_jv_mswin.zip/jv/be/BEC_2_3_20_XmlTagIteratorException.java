package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException extends BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 386788561: return bem_new_0();
case -935771084: return bem_sourceFileNameGet_0();
case -261636586: return bem_classNameGet_0();
case 601927729: return bem_translatedGet_0();
case -1620819332: return bem_once_0();
case 1637405965: return bem_toString_0();
case 1807961516: return bem_translateEmittedException_0();
case 1680598331: return bem_fileNameGet_0();
case -2006545388: return bem_emitLangGet_0();
case 1008210359: return bem_translateEmittedExceptionInner_0();
case 28948395: return bem_descriptionGet_0();
case -1975952737: return bem_tagGet_0();
case -1197182710: return bem_serializeToString_0();
case 636889369: return bem_framesTextGet_0();
case 582818432: return bem_create_0();
case -545246440: return bem_lineNumberGet_0();
case 1342246094: return bem_print_0();
case 168705805: return bem_iteratorGet_0();
case -117420215: return bem_serializeContents_0();
case -1799894149: return bem_vvGet_0();
case -1905624113: return bem_klassNameGet_0();
case -1545699131: return bem_getFrameText_0();
case 65678538: return bem_echo_0();
case 1446398062: return bem_methodNameGet_0();
case 866679447: return bem_serializationIteratorGet_0();
case 1053098123: return bem_hashGet_0();
case -195618331: return bem_langGet_0();
case 2092326455: return bem_many_0();
case -1687339816: return bem_framesGet_0();
case 1449516553: return bem_copy_0();
case 845917022: return bem_fieldIteratorGet_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -1712633963: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case 525364011: return bem_descriptionSet_1(bevd_0);
case -1921133350: return bem_defined_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case 165751765: return bem_fileNameSet_1(bevd_0);
case -547624410: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1071375584: return bem_methodNameSet_1(bevd_0);
case -199699675: return bem_vvSet_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case -2059923898: return bem_klassNameSet_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -473011801: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case 305586350: return bem_framesTextSet_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 93431873: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 707881002: return bem_new_1(bevd_0);
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1202707136: return bem_langSet_1(bevd_0);
case 344697195: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 1450939818: return bem_lineNumberSet_1(bevd_0);
case 1571740046: return bem_framesSet_1(bevd_0);
case -223731749: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 780018541: return bem_emitLangSet_1(bevd_0);
case -1789905588: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1590486509: return bem_translatedSet_1(bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1636640102: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_20_XmlTagIteratorException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
}
