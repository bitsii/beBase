package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException extends BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;

public static BET_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -881174756: return bem_descriptionGet_0();
case -349777708: return bem_fileNameGet_0();
case 795741226: return bem_lineNumberGet_0();
case 356367657: return bem_langGet_0();
case -1411238004: return bem_copy_0();
case -1712096433: return bem_emitLangGet_0();
case 527172959: return bem_new_0();
case -40105533: return bem_translatedGet_0();
case 259361829: return bem_getFrameText_0();
case 64606951: return bem_methodNameGet_0();
case -882993327: return bem_klassNameGet_0();
case 1491897585: return bem_iteratorGet_0();
case 1503533254: return bem_framesGet_0();
case -1485820769: return bem_hashGet_0();
case -2109115167: return bem_vvGet_0();
case 952781905: return bem_toString_0();
case -656779138: return bem_framesTextGet_0();
case -841536904: return bem_create_0();
case 1104924426: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -570393359: return bem_equals_1(bevd_0);
case -785352134: return bem_vvSet_1(bevd_0);
case 1990932052: return bem_klassNameSet_1(bevd_0);
case -1721969959: return bem_translatedSet_1(bevd_0);
case -1158695021: return bem_descriptionSet_1(bevd_0);
case 1938071873: return bem_framesSet_1(bevd_0);
case -942389906: return bem_undef_1(bevd_0);
case -2098067152: return bem_print_1(bevd_0);
case -1357042895: return bem_framesTextSet_1(bevd_0);
case -401699856: return bem_new_1(bevd_0);
case -116858113: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1686329485: return bem_fileNameSet_1(bevd_0);
case -1617493725: return bem_methodNameSet_1(bevd_0);
case -1704624927: return bem_lineNumberSet_1(bevd_0);
case -661822576: return bem_notEquals_1(bevd_0);
case -1095224362: return bem_def_1(bevd_0);
case 41816091: return bem_emitLangSet_1(bevd_0);
case 2139946505: return bem_copyTo_1(bevd_0);
case 1744167395: return bem_langSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1603596126: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 130165321: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 492015902: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2061117733: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2043767882: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_20_XmlTagIteratorException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;
}
}
