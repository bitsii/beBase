package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException extends BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;

public static BET_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -919772434: return bem_serializeToString_0();
case 1776086751: return bem_fileNameGetDirect_0();
case 2064556163: return bem_klassNameGet_0();
case 1928293906: return bem_once_0();
case 619304343: return bem_hashGet_0();
case 1623987490: return bem_serializeContents_0();
case 407789443: return bem_methodNameGetDirect_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case 1385440424: return bem_emitLangGet_0();
case 322458447: return bem_translateEmittedException_0();
case -465411094: return bem_klassNameGetDirect_0();
case 868760417: return bem_serializationIteratorGet_0();
case -1836757512: return bem_copy_0();
case 1452564531: return bem_toString_0();
case -757699318: return bem_iteratorGet_0();
case 1065543761: return bem_langGet_0();
case 998021668: return bem_langGetDirect_0();
case -977356120: return bem_fieldNamesGet_0();
case 1605752359: return bem_many_0();
case 438244040: return bem_create_0();
case 1576417178: return bem_new_0();
case -197180620: return bem_echo_0();
case 1148186102: return bem_toAny_0();
case -501838281: return bem_descriptionGet_0();
case 681563544: return bem_lineNumberGetDirect_0();
case 1066844859: return bem_getFrameText_0();
case -701837270: return bem_framesGet_0();
case 141983605: return bem_sourceFileNameGet_0();
case -464967776: return bem_classNameGet_0();
case 802324918: return bem_framesTextGetDirect_0();
case -294275930: return bem_lineNumberGet_0();
case -2028524717: return bem_translatedGet_0();
case 1739178121: return bem_fileNameGet_0();
case -571532887: return bem_translatedGetDirect_0();
case 259514819: return bem_vvGetDirect_0();
case 555221661: return bem_emitLangGetDirect_0();
case 500389220: return bem_print_0();
case -1577376052: return bem_methodNameGet_0();
case 612655702: return bem_descriptionGetDirect_0();
case 717709992: return bem_framesGetDirect_0();
case -978724962: return bem_tagGet_0();
case 730875238: return bem_framesTextGet_0();
case -1693291784: return bem_vvGet_0();
case 23744672: return bem_translateEmittedExceptionInner_0();
case -1895797969: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1399711040: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 849561595: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case 137909243: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1874280381: return bem_klassNameSetDirect_1(bevd_0);
case 664139783: return bem_translatedSet_1(bevd_0);
case -1670220047: return bem_fileNameSetDirect_1(bevd_0);
case -2109520205: return bem_methodNameSetDirect_1(bevd_0);
case 1698026019: return bem_new_1(bevd_0);
case 1592373155: return bem_framesSetDirect_1(bevd_0);
case 1149773549: return bem_vvSet_1(bevd_0);
case -2080355933: return bem_defined_1(bevd_0);
case -217159540: return bem_framesTextSetDirect_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case 664447252: return bem_fileNameSet_1(bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case -1583961333: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -341841106: return bem_klassNameSet_1(bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case -1564294537: return bem_langSetDirect_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
case -1559076513: return bem_emitLangSet_1(bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case -1303807005: return bem_methodNameSet_1(bevd_0);
case 1945904012: return bem_emitLangSetDirect_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case -1856971928: return bem_vvSetDirect_1(bevd_0);
case 554878156: return bem_descriptionSetDirect_1(bevd_0);
case 1949971683: return bem_lineNumberSetDirect_1(bevd_0);
case 910618841: return bem_framesSet_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case 643357388: return bem_translatedSetDirect_1(bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 626970944: return bem_framesTextSet_1(bevd_0);
case 1764782799: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1932446897: return bem_langSet_1(bevd_0);
case 638723889: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -558105795: return bem_lineNumberSet_1(bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 308935537: return bem_descriptionSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -220218582: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_20_XmlTagIteratorException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;
}
}
