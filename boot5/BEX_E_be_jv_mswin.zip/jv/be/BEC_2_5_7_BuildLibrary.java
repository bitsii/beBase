package be;
/* IO:File: source/build/Library.be */
public final class BEC_2_5_7_BuildLibrary extends BEC_2_6_6_SystemObject {
public BEC_2_5_7_BuildLibrary() { }
private static byte[] becc_BEC_2_5_7_BuildLibrary_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] becc_BEC_2_5_7_BuildLibrary_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x2E,0x62,0x65};
public static BEC_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_inst;

public static BET_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_type;

public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_5_9_BuildClassInfo bevp_libnameInfo;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_5_7_BuildLibrary bem_new_2(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_libPath = null;
BEC_2_6_6_SystemObject bevl_libnameNp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevp_build = beva__build;
if (bevp_libName == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 16*/ {
bevl_libPath = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_basePath = bevl_libPath.bem_parentGet_0();
bevp_emitPath = bevp_basePath.bem_copy_0();
bevt_1_ta_ph = bevl_libPath.bem_stepsGet_0();
bevp_libName = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lastGet_0();
} /* Line: 20*/
 else /* Line: 21*/ {
bevp_basePath = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_emitPath = bevp_basePath.bem_copy_0();
} /* Line: 23*/
if (bevp_libName == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 25*/ {
bevl_libnameNp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_libnameNp.bemd_1(721702279, bevp_libName);
if (bevp_exeName == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 28*/ {
bevp_exeName = bevp_libName;
} /* Line: 28*/
bevt_4_ta_ph = bevp_build.bem_emitterGet_0();
bevp_libnameInfo = (new BEC_2_5_9_BuildClassInfo()).bem_new_5((BEC_2_5_8_BuildNamePath) bevl_libnameNp , bevt_4_ta_ph, bevp_emitPath, bevp_libName, bevp_exeName);
} /* Line: 29*/
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_new_4(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) throws Throwable {
bevp_libName = beva__libName;
bevp_exeName = beva__exeName;
bem_new_2(beva_spath, beva__build);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInfoGet_0() throws Throwable {
return bevp_libnameInfo;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libnameInfoSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {12, 16, 16, 17, 18, 19, 20, 20, 22, 23, 25, 25, 26, 27, 28, 28, 28, 29, 29, 34, 35, 36, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 31, 32, 33, 34, 35, 36, 39, 40, 42, 47, 48, 49, 50, 55, 56, 58, 59, 64, 65, 66, 70, 73, 77, 80, 84, 87, 91, 94, 98, 101, 105, 108};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 12 25
assign 1 16 26
undef 1 16 31
assign 1 17 32
new 1 17 32
assign 1 18 33
parentGet 0 18 33
assign 1 19 34
copy 0 19 34
assign 1 20 35
stepsGet 0 20 35
assign 1 20 36
lastGet 0 20 36
assign 1 22 39
new 1 22 39
assign 1 23 40
copy 0 23 40
assign 1 25 42
def 1 25 47
assign 1 26 48
new 0 26 48
fromString 1 27 49
assign 1 28 50
undef 1 28 55
assign 1 28 56
assign 1 29 58
emitterGet 0 29 58
assign 1 29 59
new 5 29 59
assign 1 34 64
assign 1 35 65
new 2 36 66
return 1 0 70
assign 1 0 73
return 1 0 77
assign 1 0 80
return 1 0 84
assign 1 0 87
return 1 0 91
assign 1 0 94
return 1 0 98
assign 1 0 101
return 1 0 105
assign 1 0 108
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -49906999: return bem_libnameInfoGet_0();
case -173931073: return bem_basePathGet_0();
case 902093803: return bem_new_0();
case -169489012: return bem_hashGet_0();
case -103606480: return bem_classNameGet_0();
case -832661413: return bem_copy_0();
case 1677427617: return bem_exeNameGet_0();
case -2141402500: return bem_emitPathGet_0();
case -2022684029: return bem_tagGet_0();
case 1431977737: return bem_create_0();
case 1935037882: return bem_libNameGet_0();
case 877439935: return bem_buildGet_0();
case 146976840: return bem_iteratorGet_0();
case 786281233: return bem_print_0();
case -1936670813: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1239929173: return bem_copyTo_1(bevd_0);
case 1324342877: return bem_undef_1(bevd_0);
case 1750033248: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -586319938: return bem_libNameSet_1(bevd_0);
case -1974318672: return bem_def_1(bevd_0);
case -1291023472: return bem_emitPathSet_1(bevd_0);
case -909760479: return bem_libnameInfoSet_1(bevd_0);
case 1959493383: return bem_notEquals_1(bevd_0);
case -283259228: return bem_basePathSet_1(bevd_0);
case -2074034102: return bem_sameObject_1(bevd_0);
case -994341698: return bem_buildSet_1(bevd_0);
case -1900104838: return bem_equals_1(bevd_0);
case -633327399: return bem_exeNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -378001330: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1813762108: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1271563629: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 603991209: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1710912728: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1704255266: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2000969884: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_5_7_BuildLibrary_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_5_7_BuildLibrary_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_7_BuildLibrary();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst = (BEC_2_5_7_BuildLibrary) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_type;
}
}
