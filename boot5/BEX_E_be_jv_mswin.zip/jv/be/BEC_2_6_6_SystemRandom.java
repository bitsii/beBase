package be;
/* IO:File: source/base/Random.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x52,0x61,0x6E,0x64,0x6F,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seed_1(BEC_2_4_3_MathInt beva_seed) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getInt_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt());
bevt_2_ta_ph = bem_getInt_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_getInt_1(beva_value);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_ta_ph = bem_getString_2(bevt_1_ta_ph, beva_size);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
bevt_1_ta_ph = beva_str.bem_capacityGet_0();
if (bevt_1_ta_ph.bevi_int < beva_size.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 121*/ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 122*/
bevt_2_ta_ph = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_ta_ph);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 130*/ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(26));
bevt_6_ta_ph = bem_getIntMax_2(bevl_value, bevt_7_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(65));
bevt_6_ta_ph.bevi_int += bevt_8_ta_ph.bevi_int;
bevt_5_ta_ph = bevt_6_ta_ph;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_5_ta_ph);
bevl_i.bevi_int++;
} /* Line: 130*/
 else /* Line: 130*/ {
break;
} /* Line: 130*/
} /* Line: 130*/
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 74, 74, 74, 105, 109, 109, 109, 109, 109, 113, 113, 113, 113, 117, 117, 117, 121, 121, 121, 122, 124, 124, 129, 130, 130, 130, 132, 132, 132, 132, 132, 130, 134};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 33, 34, 35, 40, 47, 48, 49, 50, 51, 57, 58, 59, 60, 65, 66, 67, 81, 82, 87, 88, 90, 91, 92, 93, 96, 101, 102, 103, 104, 105, 107, 108, 114};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 38 19
assign 1 74 33
new 0 74 33
assign 1 74 34
getInt 1 74 34
return 1 74 35
return 1 105 40
assign 1 109 47
new 0 109 47
assign 1 109 48
getInt 1 109 48
assign 1 109 49
absValue 0 109 49
assign 1 109 50
modulusValue 1 109 50
return 1 109 51
assign 1 113 57
getInt 1 113 57
assign 1 113 58
absValue 0 113 58
assign 1 113 59
modulusValue 1 113 59
return 1 113 60
assign 1 117 65
new 1 117 65
assign 1 117 66
getString 2 117 66
return 1 117 67
assign 1 121 81
capacityGet 0 121 81
assign 1 121 82
lesser 1 121 87
capacitySet 1 122 88
assign 1 124 90
copy 0 124 90
sizeSet 1 124 91
assign 1 129 92
new 0 129 92
assign 1 130 93
new 0 130 93
assign 1 130 96
lesser 1 130 101
assign 1 132 102
new 0 132 102
assign 1 132 103
getIntMax 2 132 103
assign 1 132 104
new 0 132 104
assign 1 132 105
addValue 1 132 105
setIntUnchecked 2 132 107
incrementValue 0 130 108
return 1 134 114
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -593179039: return bem_hashGet_0();
case -1634228593: return bem_getInt_0();
case 505123521: return bem_seedNow_0();
case -509281348: return bem_new_0();
case -567577081: return bem_default_0();
case 593600550: return bem_toString_0();
case 1377393171: return bem_iteratorGet_0();
case 572942595: return bem_create_0();
case 916511308: return bem_print_0();
case -1436588716: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1787750141: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case -2137768355: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case -1742480123: return bem_seed_1((BEC_2_4_3_MathInt) bevd_0);
case -257664443: return bem_equals_1(bevd_0);
case 152454017: return bem_def_1(bevd_0);
case -1239385327: return bem_undef_1(bevd_0);
case -1490966740: return bem_copyTo_1(bevd_0);
case 740081825: return bem_notEquals_1(bevd_0);
case -1857239395: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 376456972: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2087906856: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 426315431: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -840314986: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1724367826: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2137344558: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
