package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_1 = (new BEC_2_4_3_MathInt(65));
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getInt_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_2_tmpany_phold = bem_getInt_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_getInt_1(beva_value);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpany_phold = bem_getString_2(bevt_1_tmpany_phold, beva_size);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_str.bem_capacityGet_0();
if (bevt_1_tmpany_phold.bevi_int < beva_size.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 277 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 278 */
bevt_2_tmpany_phold = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpany_phold);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 286 */ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_0;
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) bevt_9_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bem_getIntMax_2(bevl_value, bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_1;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevt_7_tmpany_phold;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 286 */
 else  /* Line: 286 */ {
break;
} /* Line: 286 */
} /* Line: 286 */
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {202, 230, 230, 230, 261, 265, 265, 265, 265, 265, 269, 269, 269, 269, 273, 273, 273, 277, 277, 277, 278, 280, 280, 285, 286, 286, 286, 288, 288, 288, 288, 288, 288, 288, 286, 290};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 34, 35, 36, 41, 48, 49, 50, 51, 52, 58, 59, 60, 61, 66, 67, 68, 85, 86, 91, 92, 94, 95, 96, 97, 100, 105, 106, 107, 108, 109, 110, 111, 113, 114, 120};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 202 23
assign 1 230 34
new 0 230 34
assign 1 230 35
getInt 1 230 35
return 1 230 36
return 1 261 41
assign 1 265 48
new 0 265 48
assign 1 265 49
getInt 1 265 49
assign 1 265 50
absValue 0 265 50
assign 1 265 51
modulusValue 1 265 51
return 1 265 52
assign 1 269 58
getInt 1 269 58
assign 1 269 59
absValue 0 269 59
assign 1 269 60
modulusValue 1 269 60
return 1 269 61
assign 1 273 66
new 1 273 66
assign 1 273 67
getString 2 273 67
return 1 273 68
assign 1 277 85
capacityGet 0 277 85
assign 1 277 86
lesser 1 277 91
capacitySet 1 278 92
assign 1 280 94
copy 0 280 94
sizeSet 1 280 95
assign 1 285 96
new 0 285 96
assign 1 286 97
new 0 286 97
assign 1 286 100
lesser 1 286 105
assign 1 288 106
new 0 288 106
assign 1 288 107
once 0 288 107
assign 1 288 108
getIntMax 2 288 108
assign 1 288 109
new 0 288 109
assign 1 288 110
once 0 288 110
assign 1 288 111
addValue 1 288 111
setIntUnchecked 2 288 113
incrementValue 0 286 114
return 1 290 120
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1551415145: return bem_toAny_0();
case 690609043: return bem_print_0();
case -1522610135: return bem_serializeToString_0();
case -2005156683: return bem_classNameGet_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case -753430171: return bem_fieldIteratorGet_0();
case -996677244: return bem_getInt_0();
case 983736684: return bem_serializationIteratorGet_0();
case 247075507: return bem_fieldNamesGet_0();
case -1071791812: return bem_seedNow_0();
case -576502505: return bem_create_0();
case 2084331281: return bem_new_0();
case 320622940: return bem_echo_0();
case -738439163: return bem_copy_0();
case 1954228088: return bem_default_0();
case 1969080256: return bem_once_0();
case -1966626789: return bem_hashGet_0();
case -1313098664: return bem_toString_0();
case 101762581: return bem_serializeContents_0();
case 645211302: return bem_iteratorGet_0();
case -890719598: return bem_sourceFileNameGet_0();
case 484635838: return bem_tagGet_0();
case -357139526: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -670773723: return bem_sameType_1(bevd_0);
case -1493123844: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -828392158: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case -1270441812: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1539089369: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 202038813: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
