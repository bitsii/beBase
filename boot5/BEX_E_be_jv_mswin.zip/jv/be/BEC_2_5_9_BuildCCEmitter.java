package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x74,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x61,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x62,0x65,0x76,0x74,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x62,0x65,0x76,0x6B,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
if (bevp_parentConf == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_3_ta_ph = bevp_build.bem_libNameGet_0();
bevt_2_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_3_ta_ph);
bevl_extends = bem_extend_1(bevt_2_ta_ph);
} /* Line: 48*/
 else /* Line: 49*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_4_ta_ph);
} /* Line: 50*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevl_extends);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_5_ta_ph.bem_addValue_1(bevt_9_ta_ph);
if (bevp_parentConf == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_12_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_14_ta_ph = bevl_begin.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_17_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_13_ta_ph.bem_addValue_1(bevt_18_ta_ph);
} /* Line: 59*/
 else /* Line: 60*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
} /* Line: 65*/
bevt_22_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_23_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_25_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (!(bevt_24_ta_ph.bevi_bool))/* Line: 80*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_27_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_28_ta_ph);
} /* Line: 82*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_29_ta_ph);
bevt_34_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_35_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_36_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_36_ta_ph);
bevt_37_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_37_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_38_ta_ph);
bevp_heow.bem_write_1(bevt_30_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (bevt_43_ta_ph.bevi_bool)/* Line: 90*/ {
bevt_47_ta_ph = beva_csyn.bem_hasDefaultGet_0();
if (bevt_47_ta_ph.bevi_bool) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 90*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 90*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 90*/
 else /* Line: 90*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 90*/ {
bevt_48_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_48_ta_ph);
} /* Line: 91*/
bevt_50_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_51_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_49_ta_ph = bevt_50_ta_ph.bem_has_1(bevt_51_ta_ph);
if (!(bevt_49_ta_ph.bevi_bool))/* Line: 93*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevp_heow.bem_write_1(bevt_53_ta_ph);
} /* Line: 95*/
bevt_56_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_57_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_55_ta_ph = bevt_56_ta_ph.bem_add_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_54_ta_ph = bevt_55_ta_ph.bem_add_1(bevt_58_ta_ph);
bevp_heow.bem_write_1(bevt_54_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_62_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_60_ta_ph = bevt_61_ta_ph.bem_add_1(bevt_62_ta_ph);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_59_ta_ph = bevt_60_ta_ph.bem_add_1(bevt_63_ta_ph);
bevp_deow.bem_write_1(bevt_59_ta_ph);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_64_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(416712597);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_14_ta_ph = bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_20_ta_ph = bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 150*/ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 151*/
 else /* Line: 150*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1880681292);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(567335501, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 152*/ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
} /* Line: 153*/
 else /* Line: 150*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1880681292);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(567335501, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 154*/ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
} /* Line: 155*/
 else /* Line: 156*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 157*/
} /* Line: 150*/
} /* Line: 150*/
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_4_6_TextString bevl_prefix = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isTmpVarGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 165*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
} /* Line: 166*/
 else /* Line: 165*/ {
bevt_1_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 167*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
} /* Line: 168*/
 else /* Line: 165*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 169*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
} /* Line: 170*/
 else /* Line: 171*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
} /* Line: 172*/
} /* Line: 165*/
} /* Line: 165*/
bevt_4_ta_ph = beva_v.bem_nameGet_0();
bevt_3_ta_ph = bevl_prefix.bem_add_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_decNameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_4_6_TextString bevl_prefix = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isTmpVarGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 181*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
} /* Line: 182*/
 else /* Line: 181*/ {
bevt_1_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 183*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
} /* Line: 184*/
 else /* Line: 181*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 185*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
} /* Line: 186*/
 else /* Line: 187*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
} /* Line: 188*/
} /* Line: 181*/
} /* Line: 181*/
bevt_4_ta_ph = beva_v.bem_nameGet_0();
bevt_3_ta_ph = bevl_prefix.bem_add_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1880681292);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(567335501, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 195*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 197*/
bevt_5_ta_ph = super.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1120221001);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1670817152, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 207*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1985622817);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 208*/
 else /* Line: 209*/ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 210*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_24_ta_ph = bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(433708714);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-2018689634);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 241*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 242*/
 else /* Line: 243*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 244*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 249*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
} /* Line: 250*/
 else /* Line: 251*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 252*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
} /* Line: 253*/
 else /* Line: 254*/ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
} /* Line: 255*/
} /* Line: 252*/
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_18_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_22_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 274*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1830050258);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 275*/
 else /* Line: 276*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(1830050258);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 277*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1830050258);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 284*/
 else /* Line: 285*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(1830050258);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 286*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_litArgs = bevt_0_ta_ph.bem_add_1(beva_sdec);
bevt_5_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_ta_ph = bevp_build.bem_libNameGet_0();
bevt_13_ta_ph = beva_newcc.bem_relEmitName_1(bevt_14_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = beva_newcc.bem_relEmitName_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_litArgs);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevl_newCall = bevt_7_ta_ph.bem_add_1(bevt_19_ta_ph);
} /* Line: 294*/
 else /* Line: 295*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = bevp_build.bem_libNameGet_0();
bevt_29_ta_ph = beva_newcc.bem_relEmitName_1(bevt_30_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevl_litArgs);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevl_newCall = bevt_20_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 296*/
return bevl_newCall;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 345*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 345*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 345*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 345*/ {
return this;
} /* Line: 346*/
 else /* Line: 347*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1087400086);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(-149039685);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 350*/ {
return this;
} /* Line: 353*/
bevp_setOutputTime = bevl_outts;
} /* Line: 356*/
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 361*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 362*/
bevt_2_ta_ph = super.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 368*/ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 371*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 376*/ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 384*/
} /* Line: 382*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 391*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_7_ta_ph = bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_14_ta_ph = bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 394*/
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_4_ContainerList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_4_ContainerList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_beh.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevl_beh.bem_addValue_1(bevt_19_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_23_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_22_ta_ph = bevl_bet.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevt_20_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevl_bet.bem_addValue_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (!(bevt_28_ta_ph.bevi_bool))/* Line: 414*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_31_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 416*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 416*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(900728463);
if (bevl_firstmnsyn.bevi_bool)/* Line: 417*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 418*/
 else /* Line: 419*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_33_ta_ph);
} /* Line: 420*/
bevt_35_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_36_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_36_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 422*/
 else /* Line: 416*/ {
break;
} /* Line: 416*/
} /* Line: 416*/
} /* Line: 416*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevl_bet.bem_addValue_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_38_ta_ph = bevt_39_ta_ph.bem_has_1(bevt_40_ta_ph);
if (!(bevt_38_ta_ph.bevi_bool))/* Line: 427*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
} /* Line: 428*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 432*/ {
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_46_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 434*/ {
bevt_47_ta_ph = bevt_1_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 434*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(900728463);
bevt_48_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_48_ta_ph.bevi_bool))/* Line: 435*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 436*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 437*/
 else /* Line: 438*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_49_ta_ph);
} /* Line: 439*/
bevt_51_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_52_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_52_ta_ph);
bevt_50_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 441*/
} /* Line: 435*/
 else /* Line: 434*/ {
break;
} /* Line: 434*/
} /* Line: 434*/
} /* Line: 434*/
bevt_53_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_bet.bem_addValue_1(bevt_54_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_56_ta_ph = bevl_bet.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_55_ta_ph = bevt_56_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_55_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_61_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_62_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_60_ta_ph = bevt_61_ta_ph.bem_equals_1(bevt_62_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_65_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_64_ta_ph = bevl_bet.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bem_addValue_1(bevt_66_ta_ph);
bevt_67_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_63_ta_ph.bem_addValue_1(bevt_67_ta_ph);
} /* Line: 451*/
 else /* Line: 452*/ {
bevt_70_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_69_ta_ph = bevl_bet.bem_addValue_1(bevt_70_ta_ph);
bevt_71_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_68_ta_ph.bem_addValue_1(bevt_72_ta_ph);
} /* Line: 453*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_bet.bem_addValue_1(bevt_73_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_75_ta_ph = bevl_bet.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_74_ta_ph.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_80_ta_ph = bem_genMark_1(bevt_81_ta_ph);
bevl_bet.bem_addValue_1(bevt_80_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_bet.bem_addValue_1(bevt_82_ta_ph);
bevt_83_ta_ph = bem_getClassOutput_0();
bevt_83_ta_ph.bem_write_1(bevl_bet);
bevt_84_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_84_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_45_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_56_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 476*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_8_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_14_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 482*/ {
bevt_23_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 483*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(1287088203);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(1287088203);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 488*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 490*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 490*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(900728463);
bevt_35_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(1287088203);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(428366797);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(-722852782);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 496*/
 else /* Line: 490*/ {
break;
} /* Line: 490*/
} /* Line: 490*/
} /* Line: 490*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_deow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_43_ta_ph = bevp_build.bem_paramsGet_0();
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_42_ta_ph = bevt_43_ta_ph.bem_has_1(bevt_44_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 510*/ {
bevt_46_ta_ph = bevp_build.bem_paramsGet_0();
bevt_47_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_45_ta_ph = bevt_46_ta_ph.bem_get_1(bevt_47_ta_ph);
bevt_1_ta_loop = bevt_45_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 512*/ {
bevt_48_ta_ph = bevt_1_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 512*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(900728463);
bevt_49_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_49_ta_ph.bem_fileGet_0();
bevt_51_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bemd_0(1287088203);
bevl_inc = (BEC_2_4_6_TextString) bevt_50_ta_ph.bemd_0(428366797);
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_52_ta_ph.bemd_0(-722852782);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 518*/
 else /* Line: 512*/ {
break;
} /* Line: 512*/
} /* Line: 512*/
} /* Line: 512*/
bevt_54_ta_ph = bevp_build.bem_paramsGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_53_ta_ph = bevt_54_ta_ph.bem_has_1(bevt_55_ta_ph);
if (bevt_53_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_57_ta_ph = bevp_build.bem_paramsGet_0();
bevt_58_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_56_ta_ph = bevt_57_ta_ph.bem_get_1(bevt_58_ta_ph);
bevt_2_ta_loop = bevt_56_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 523*/ {
bevt_59_ta_ph = bevt_2_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 523*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(900728463);
bevt_60_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_60_ta_ph.bem_fileGet_0();
bevt_62_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(1287088203);
bevl_inc = (BEC_2_4_6_TextString) bevt_61_ta_ph.bemd_0(428366797);
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_63_ta_ph.bemd_0(-722852782);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 529*/
 else /* Line: 523*/ {
break;
} /* Line: 523*/
} /* Line: 523*/
} /* Line: 523*/
} /* Line: 521*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 542*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 544*/ {
bevt_8_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 545*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(1287088203);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 551*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 553*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 553*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(900728463);
bevt_19_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(1287088203);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(428366797);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(-722852782);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 559*/
 else /* Line: 553*/ {
break;
} /* Line: 553*/
} /* Line: 553*/
} /* Line: 553*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bem_increment_0();
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 565*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 566*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 566*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(900728463);
bevt_31_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(1287088203);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(428366797);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(-722852782);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 571*/
 else /* Line: 566*/ {
break;
} /* Line: 566*/
} /* Line: 566*/
} /* Line: 566*/
} /* Line: 565*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 589*/ {
bevl_mh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_5_ta_ph = bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 592*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 613*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_4_ta_ph = beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 614*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(210457681);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 626*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 626*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(900728463);
bevt_6_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_6_ta_ph.bevi_bool))/* Line: 627*/ {
if (bevl_first.bevi_bool)/* Line: 628*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 629*/
 else /* Line: 630*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 631*/
bevt_10_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 633*/
} /* Line: 627*/
 else /* Line: 626*/ {
break;
} /* Line: 626*/
} /* Line: 626*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_14_ta_ph);
bevt_13_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_6_6_SystemObject bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
bevt_2_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_3_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_2_ta_ph.bem_relEmitName_1(bevt_3_ta_ph);
bevt_5_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(416712597);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_4_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_14_ta_ph = bem_overrideMtdDecGet_0();
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevl_oname);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_21_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_20_ta_ph.bevi_bool)/* Line: 675*/ {
bevt_22_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_22_ta_ph, bevl_asnr);
} /* Line: 676*/
bevt_26_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_25_ta_ph = bevt_26_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevl_asnr);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_23_ta_ph.bem_addValue_1(bevp_nl);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_29_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_30_ta_ph);
bevt_29_ta_ph.bem_addValue_1(bevp_nl);
bevt_38_ta_ph = bem_overrideMtdDecGet_0();
bevt_37_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_38_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bem_addValue_1(bevl_oname);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_33_ta_ph = bevt_34_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevt_42_ta_ph);
bevt_31_ta_ph.bem_addValue_1(bevp_nl);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_45_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_46_ta_ph);
bevt_44_ta_ph = bevt_45_ta_ph.bem_addValue_1(bevl_stinst);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevt_47_ta_ph);
bevt_43_ta_ph.bem_addValue_1(bevp_nl);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_48_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_49_ta_ph);
bevt_48_ta_ph.bem_addValue_1(bevp_nl);
bevt_56_ta_ph = bem_overrideMtdDecGet_0();
bevt_55_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_54_ta_ph = bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_60_ta_ph);
bevt_50_ta_ph.bem_addValue_1(bevp_nl);
bevt_63_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_62_ta_ph = bevt_63_ta_ph.bemd_0(7681266);
if (bevt_62_ta_ph == null) {
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 695*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 695*/ {
bevt_66_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_65_ta_ph = bevt_66_ta_ph.bemd_0(7681266);
bevt_64_ta_ph = bevt_65_ta_ph.bemd_1(567335501, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 695*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 695*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 695*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 695*/ {
bevt_68_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_67_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_68_ta_ph);
bevt_67_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 696*/
 else /* Line: 697*/ {
bevt_70_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_69_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_70_ta_ph);
bevt_69_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 698*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_71_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_72_ta_ph);
bevt_71_ta_ph.bem_addValue_1(bevp_nl);
bevt_79_ta_ph = bem_overrideMtdDecGet_0();
bevt_78_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_77_ta_ph = bevt_78_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_76_ta_ph = bevt_77_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_75_ta_ph = bevt_76_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_83_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevt_83_ta_ph);
bevt_73_ta_ph.bem_addValue_1(bevp_nl);
bevt_85_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_84_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_85_ta_ph);
bevt_84_ta_ph.bem_addValue_1(bevp_nl);
bevt_87_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_86_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_87_ta_ph);
bevt_86_ta_ph.bem_addValue_1(bevp_nl);
bevt_89_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_90_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_88_ta_ph = bevt_89_ta_ph.bem_has_1(bevt_90_ta_ph);
if (bevt_88_ta_ph.bevi_bool)/* Line: 711*/ {
bevt_94_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(210457681);
bevt_92_ta_ph = bevt_93_ta_ph.bemd_0(-589241341);
bevt_91_ta_ph = bevt_92_ta_ph.bemd_0(-1597635155);
if (((BEC_2_5_4_LogicBool) bevt_91_ta_ph).bevi_bool)/* Line: 711*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 711*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 711*/
 else /* Line: 711*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (!(bevt_1_ta_anchor.bevi_bool))/* Line: 711*/ {
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_98_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_97_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_98_ta_ph);
bevt_99_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_96_ta_ph = bevt_97_ta_ph.bem_addValue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_95_ta_ph = bevt_96_ta_ph.bem_addValue_1(bevt_100_ta_ph);
bevt_95_ta_ph.bem_addValue_1(bevp_nl);
bevt_104_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_103_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_104_ta_ph);
bevt_102_ta_ph = bevt_103_ta_ph.bem_addValue_1(bevl_tinst);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_101_ta_ph = bevt_102_ta_ph.bem_addValue_1(bevt_105_ta_ph);
bevt_101_ta_ph.bem_addValue_1(bevp_nl);
bevt_107_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_106_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_107_ta_ph);
bevt_106_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 718*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 27, 28, 29, 33, 35, 36, 37, 38, 39, 43, 47, 47, 48, 48, 48, 50, 50, 52, 52, 52, 52, 52, 52, 54, 54, 55, 55, 57, 57, 59, 59, 59, 59, 59, 59, 59, 61, 61, 63, 63, 65, 65, 68, 68, 70, 70, 72, 74, 76, 78, 80, 80, 80, 81, 81, 82, 82, 84, 84, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 86, 86, 87, 87, 88, 88, 89, 89, 90, 90, 90, 90, 90, 90, 0, 0, 0, 91, 91, 93, 93, 93, 94, 94, 95, 95, 97, 97, 97, 97, 97, 97, 99, 99, 99, 99, 99, 99, 101, 101, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 106, 106, 106, 106, 106, 106, 106, 106, 106, 106, 106, 108, 108, 108, 112, 114, 115, 116, 116, 117, 121, 121, 125, 125, 129, 129, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 136, 138, 138, 138, 138, 138, 138, 140, 140, 140, 140, 140, 140, 140, 140, 140, 140, 142, 144, 144, 150, 150, 150, 150, 151, 152, 152, 152, 152, 153, 154, 154, 154, 154, 155, 157, 157, 159, 165, 166, 167, 168, 169, 170, 172, 174, 174, 174, 181, 182, 183, 184, 185, 186, 188, 190, 190, 190, 195, 195, 195, 195, 196, 196, 197, 199, 199, 203, 203, 203, 203, 203, 203, 203, 203, 207, 207, 207, 207, 208, 208, 208, 210, 216, 216, 216, 216, 216, 218, 218, 218, 218, 218, 218, 218, 218, 220, 222, 224, 224, 224, 224, 224, 224, 224, 224, 224, 224, 224, 226, 226, 226, 226, 226, 226, 226, 226, 226, 226, 226, 226, 226, 226, 228, 233, 233, 233, 234, 235, 235, 235, 235, 235, 235, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 241, 241, 241, 242, 242, 242, 242, 242, 244, 244, 244, 244, 244, 244, 244, 249, 249, 250, 252, 252, 252, 253, 255, 258, 258, 258, 258, 258, 258, 258, 258, 263, 263, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 267, 268, 268, 268, 268, 268, 268, 268, 268, 268, 270, 270, 270, 274, 274, 274, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 275, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 277, 279, 283, 283, 283, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 288, 292, 292, 292, 292, 292, 293, 293, 293, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 294, 296, 296, 296, 296, 296, 296, 296, 296, 296, 296, 296, 296, 296, 296, 298, 303, 304, 305, 305, 306, 312, 312, 312, 312, 316, 316, 320, 320, 325, 325, 329, 329, 333, 333, 337, 337, 337, 344, 345, 0, 345, 345, 345, 345, 345, 0, 0, 346, 348, 348, 348, 349, 349, 349, 350, 353, 356, 361, 362, 362, 364, 364, 368, 369, 370, 370, 371, 376, 378, 379, 379, 380, 381, 382, 382, 383, 383, 383, 384, 390, 391, 391, 391, 392, 392, 392, 392, 392, 392, 392, 392, 392, 393, 393, 393, 393, 394, 394, 394, 396, 400, 400, 400, 400, 400, 400, 401, 402, 402, 402, 402, 402, 402, 403, 403, 404, 404, 404, 404, 405, 405, 406, 406, 407, 407, 408, 408, 409, 411, 412, 412, 412, 412, 412, 412, 412, 412, 413, 413, 414, 414, 414, 415, 416, 416, 0, 416, 416, 418, 420, 420, 422, 422, 422, 422, 425, 425, 427, 427, 427, 428, 428, 431, 431, 432, 432, 432, 433, 434, 434, 0, 434, 434, 435, 437, 439, 439, 441, 441, 441, 441, 445, 445, 447, 447, 449, 449, 449, 449, 449, 449, 450, 450, 450, 451, 451, 451, 451, 451, 451, 453, 453, 453, 453, 453, 453, 455, 455, 457, 457, 457, 457, 457, 457, 458, 458, 459, 459, 459, 460, 460, 463, 463, 464, 464, 476, 476, 477, 478, 478, 478, 478, 478, 478, 478, 479, 479, 479, 479, 479, 479, 479, 480, 480, 481, 481, 482, 482, 482, 482, 482, 483, 483, 483, 485, 485, 485, 486, 486, 486, 488, 488, 488, 490, 490, 490, 490, 0, 490, 490, 492, 492, 493, 493, 493, 494, 494, 496, 500, 500, 503, 503, 504, 504, 510, 510, 510, 512, 512, 512, 512, 0, 512, 512, 514, 514, 515, 515, 515, 516, 516, 518, 521, 521, 521, 523, 523, 523, 523, 0, 523, 523, 525, 525, 526, 526, 526, 527, 527, 529, 536, 537, 542, 542, 543, 544, 544, 544, 544, 544, 545, 545, 545, 547, 547, 547, 549, 549, 551, 551, 551, 553, 553, 553, 553, 0, 553, 553, 555, 555, 556, 556, 556, 557, 557, 559, 563, 563, 564, 565, 565, 565, 566, 566, 566, 566, 0, 566, 566, 567, 567, 568, 568, 568, 569, 569, 570, 570, 571, 577, 582, 583, 585, 585, 587, 587, 589, 589, 589, 590, 591, 591, 591, 592, 595, 596, 601, 601, 605, 605, 609, 609, 613, 613, 613, 614, 614, 614, 614, 614, 620, 620, 621, 623, 623, 623, 623, 625, 626, 0, 626, 626, 627, 629, 631, 631, 633, 633, 633, 633, 633, 633, 638, 638, 638, 643, 645, 645, 645, 645, 645, 647, 647, 647, 647, 647, 647, 647, 647, 647, 647, 647, 649, 653, 653, 654, 654, 654, 654, 655, 659, 659, 660, 660, 660, 660, 661, 661, 661, 661, 665, 665, 665, 669, 669, 669, 670, 670, 670, 671, 673, 673, 673, 673, 673, 673, 673, 673, 673, 673, 673, 673, 673, 673, 673, 674, 675, 675, 676, 676, 679, 679, 679, 679, 679, 679, 679, 681, 681, 681, 684, 684, 684, 684, 684, 684, 684, 684, 684, 684, 684, 684, 684, 689, 689, 689, 689, 689, 689, 692, 692, 692, 694, 694, 694, 694, 694, 694, 694, 694, 694, 694, 694, 694, 695, 695, 695, 695, 0, 695, 695, 695, 0, 0, 696, 696, 696, 698, 698, 698, 700, 701, 704, 704, 704, 706, 706, 706, 706, 706, 706, 706, 706, 706, 706, 706, 706, 707, 707, 707, 709, 709, 709, 711, 711, 711, 711, 711, 711, 711, 0, 0, 0, 712, 714, 714, 714, 714, 714, 714, 714, 716, 716, 716, 716, 716, 716, 718, 718, 718, 725, 725, 725, 725, 725, 726, 726, 726, 726, 726, 728, 733, 733, 734, 734, 734, 734, 735, 735, 735, 735, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 189, 260, 265, 266, 267, 268, 271, 272, 274, 275, 276, 277, 278, 279, 280, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 299, 300, 301, 302, 303, 304, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 318, 319, 320, 321, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 347, 348, 353, 354, 357, 361, 364, 365, 367, 368, 369, 371, 372, 373, 374, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 454, 455, 456, 457, 458, 459, 463, 464, 468, 469, 473, 474, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 553, 554, 555, 560, 561, 564, 565, 566, 567, 569, 572, 573, 574, 575, 577, 580, 581, 585, 594, 596, 599, 601, 604, 606, 609, 613, 614, 615, 624, 626, 629, 631, 634, 636, 639, 643, 644, 645, 655, 656, 657, 658, 660, 661, 662, 664, 665, 675, 676, 677, 678, 679, 680, 681, 682, 692, 693, 694, 695, 697, 698, 699, 702, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 839, 840, 845, 846, 847, 848, 849, 850, 853, 854, 855, 856, 857, 858, 859, 877, 878, 880, 883, 884, 885, 887, 890, 893, 894, 895, 896, 897, 898, 899, 900, 904, 905, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 996, 997, 998, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1035, 1072, 1073, 1074, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1111, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1158, 1159, 1160, 1161, 1162, 1163, 1164, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1189, 1194, 1195, 1196, 1197, 1198, 1205, 1206, 1207, 1208, 1212, 1213, 1217, 1218, 1222, 1223, 1227, 1228, 1232, 1233, 1238, 1239, 1240, 1256, 1257, 1259, 1262, 1263, 1264, 1265, 1270, 1271, 1274, 1278, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1289, 1291, 1299, 1301, 1302, 1304, 1305, 1311, 1313, 1314, 1315, 1316, 1327, 1329, 1330, 1331, 1332, 1333, 1334, 1339, 1340, 1341, 1342, 1343, 1366, 1367, 1368, 1369, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1388, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1525, 1526, 1527, 1527, 1530, 1532, 1534, 1537, 1538, 1540, 1541, 1542, 1543, 1550, 1551, 1552, 1553, 1554, 1556, 1557, 1559, 1560, 1561, 1562, 1563, 1565, 1566, 1567, 1567, 1570, 1572, 1573, 1576, 1579, 1580, 1582, 1583, 1584, 1585, 1593, 1594, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1607, 1608, 1609, 1610, 1611, 1612, 1615, 1616, 1617, 1618, 1619, 1620, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1712, 1717, 1718, 1719, 1720, 1721, 1722, 1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1745, 1746, 1747, 1748, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1760, 1761, 1762, 1763, 1763, 1766, 1768, 1769, 1770, 1771, 1772, 1773, 1774, 1775, 1776, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1790, 1791, 1793, 1794, 1795, 1796, 1796, 1799, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1809, 1816, 1817, 1818, 1820, 1821, 1822, 1823, 1823, 1826, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1835, 1836, 1847, 1848, 1891, 1896, 1897, 1898, 1899, 1900, 1901, 1906, 1907, 1908, 1909, 1911, 1912, 1913, 1914, 1915, 1916, 1917, 1918, 1920, 1921, 1922, 1923, 1923, 1926, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1943, 1944, 1945, 1946, 1947, 1948, 1950, 1951, 1952, 1953, 1953, 1956, 1958, 1959, 1960, 1961, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1976, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1997, 1998, 1999, 2000, 2001, 2003, 2004, 2009, 2010, 2014, 2015, 2020, 2021, 2032, 2033, 2034, 2036, 2037, 2038, 2039, 2040, 2064, 2065, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2072, 2075, 2077, 2078, 2081, 2084, 2085, 2087, 2088, 2089, 2090, 2091, 2092, 2099, 2100, 2101, 2121, 2122, 2123, 2124, 2125, 2126, 2127, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2138, 2147, 2148, 2149, 2150, 2151, 2152, 2153, 2165, 2166, 2167, 2168, 2169, 2170, 2171, 2172, 2173, 2174, 2179, 2180, 2181, 2297, 2298, 2299, 2300, 2301, 2302, 2303, 2304, 2305, 2306, 2307, 2308, 2309, 2310, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2323, 2324, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2343, 2344, 2345, 2346, 2347, 2348, 2349, 2350, 2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359, 2360, 2361, 2362, 2363, 2364, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2377, 2378, 2381, 2382, 2383, 2385, 2388, 2392, 2393, 2394, 2397, 2398, 2399, 2401, 2402, 2403, 2404, 2405, 2406, 2407, 2408, 2409, 2410, 2411, 2412, 2413, 2414, 2415, 2416, 2417, 2418, 2419, 2420, 2421, 2422, 2423, 2424, 2425, 2426, 2428, 2429, 2430, 2431, 2433, 2436, 2440, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2452, 2453, 2454, 2455, 2456, 2457, 2458, 2459, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480, 2481, 2482, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502, 2503, 2504, 2507, 2510, 2514, 2517, 2521, 2524, 2528, 2531, 2535, 2538, 2542, 2545, 2549, 2552, 2556, 2559, 2563, 2566, 2570, 2573, 2577, 2580};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 174
new 0 23 174
assign 1 24 175
new 0 24 175
assign 1 25 176
new 0 25 176
assign 1 27 177
new 0 27 177
assign 1 28 178
new 0 28 178
assign 1 29 179
new 0 29 179
new 1 33 180
assign 1 35 181
new 0 35 181
assign 1 36 182
new 0 36 182
assign 1 37 183
new 0 37 183
assign 1 38 184
new 0 38 184
assign 1 39 185
new 0 39 185
addValue 1 43 189
assign 1 47 260
def 1 47 265
assign 1 48 266
libNameGet 0 48 266
assign 1 48 267
relEmitName 1 48 267
assign 1 48 268
extend 1 48 268
assign 1 50 271
new 0 50 271
assign 1 50 272
extend 1 50 272
assign 1 52 274
new 0 52 274
assign 1 52 275
emitNameGet 0 52 275
assign 1 52 276
addValue 1 52 276
assign 1 52 277
addValue 1 52 277
assign 1 52 278
new 0 52 278
assign 1 52 279
addValue 1 52 279
assign 1 54 280
def 1 54 285
assign 1 55 286
new 0 55 286
addValue 1 55 287
assign 1 57 288
new 0 57 288
addValue 1 57 289
assign 1 59 290
new 0 59 290
assign 1 59 291
addValue 1 59 291
assign 1 59 292
libNameGet 0 59 292
assign 1 59 293
relEmitName 1 59 293
assign 1 59 294
addValue 1 59 294
assign 1 59 295
new 0 59 295
addValue 1 59 296
assign 1 61 299
new 0 61 299
addValue 1 61 300
assign 1 63 301
new 0 63 301
addValue 1 63 302
assign 1 65 303
new 0 65 303
addValue 1 65 304
assign 1 68 306
new 0 68 306
addValue 1 68 307
assign 1 70 308
new 0 70 308
addValue 1 70 309
write 1 72 310
write 1 74 311
write 1 76 312
clear 0 78 313
assign 1 80 314
emitChecksGet 0 80 314
assign 1 80 315
new 0 80 315
assign 1 80 316
has 1 80 316
assign 1 81 318
new 0 81 318
write 1 81 319
assign 1 82 320
new 0 82 320
write 1 82 321
assign 1 84 323
new 0 84 323
write 1 84 324
assign 1 85 325
new 0 85 325
assign 1 85 326
emitNameGet 0 85 326
assign 1 85 327
add 1 85 327
assign 1 85 328
new 0 85 328
assign 1 85 329
add 1 85 329
assign 1 85 330
getHeaderInitialInst 1 85 330
assign 1 85 331
add 1 85 331
assign 1 85 332
new 0 85 332
assign 1 85 333
add 1 85 333
write 1 85 334
assign 1 86 335
new 0 86 335
write 1 86 336
assign 1 87 337
new 0 87 337
write 1 87 338
assign 1 88 339
new 0 88 339
write 1 88 340
assign 1 89 341
new 0 89 341
write 1 89 342
assign 1 90 343
emitChecksGet 0 90 343
assign 1 90 344
new 0 90 344
assign 1 90 345
has 1 90 345
assign 1 90 347
hasDefaultGet 0 90 347
assign 1 90 348
not 0 90 353
assign 1 0 354
assign 1 0 357
assign 1 0 361
assign 1 91 364
new 0 91 364
write 1 91 365
assign 1 93 367
emitChecksGet 0 93 367
assign 1 93 368
new 0 93 368
assign 1 93 369
has 1 93 369
assign 1 94 371
new 0 94 371
write 1 94 372
assign 1 95 373
new 0 95 373
write 1 95 374
assign 1 97 376
new 0 97 376
assign 1 97 377
emitNameGet 0 97 377
assign 1 97 378
add 1 97 378
assign 1 97 379
new 0 97 379
assign 1 97 380
add 1 97 380
write 1 97 381
assign 1 99 382
new 0 99 382
assign 1 99 383
emitNameGet 0 99 383
assign 1 99 384
add 1 99 384
assign 1 99 385
new 0 99 385
assign 1 99 386
add 1 99 386
write 1 99 387
assign 1 101 388
new 0 101 388
return 1 101 389
assign 1 105 419
overrideMtdDecGet 0 105 419
assign 1 105 420
addValue 1 105 420
assign 1 105 421
getClassConfig 1 105 421
assign 1 105 422
libNameGet 0 105 422
assign 1 105 423
relEmitName 1 105 423
assign 1 105 424
addValue 1 105 424
assign 1 105 425
new 0 105 425
assign 1 105 426
addValue 1 105 426
assign 1 105 427
emitNameGet 0 105 427
assign 1 105 428
addValue 1 105 428
assign 1 105 429
new 0 105 429
assign 1 105 430
addValue 1 105 430
assign 1 105 431
addValue 1 105 431
assign 1 105 432
new 0 105 432
assign 1 105 433
addValue 1 105 433
addValue 1 105 434
assign 1 106 435
new 0 106 435
assign 1 106 436
addValue 1 106 436
assign 1 106 437
heldGet 0 106 437
assign 1 106 438
namepathGet 0 106 438
assign 1 106 439
getClassConfig 1 106 439
assign 1 106 440
libNameGet 0 106 440
assign 1 106 441
relEmitName 1 106 441
assign 1 106 442
addValue 1 106 442
assign 1 106 443
new 0 106 443
assign 1 106 444
addValue 1 106 444
addValue 1 106 445
assign 1 108 446
new 0 108 446
assign 1 108 447
addValue 1 108 447
addValue 1 108 448
assign 1 112 454
new 0 112 454
write 1 114 455
clear 0 115 456
assign 1 116 457
new 0 116 457
write 1 116 458
return 1 117 459
assign 1 121 463
new 0 121 463
return 1 121 464
assign 1 125 468
new 0 125 468
return 1 125 469
assign 1 129 473
new 0 129 473
return 1 129 474
assign 1 134 504
addValue 1 134 504
assign 1 134 505
libNameGet 0 134 505
assign 1 134 506
relEmitName 1 134 506
assign 1 134 507
addValue 1 134 507
assign 1 134 508
new 0 134 508
assign 1 134 509
addValue 1 134 509
assign 1 134 510
emitNameGet 0 134 510
assign 1 134 511
addValue 1 134 511
assign 1 134 512
new 0 134 512
assign 1 134 513
addValue 1 134 513
assign 1 134 514
addValue 1 134 514
assign 1 134 515
new 0 134 515
addValue 1 134 516
addValue 1 136 517
assign 1 138 518
new 0 138 518
assign 1 138 519
addValue 1 138 519
assign 1 138 520
addValue 1 138 520
assign 1 138 521
new 0 138 521
assign 1 138 522
addValue 1 138 522
addValue 1 138 523
assign 1 140 524
new 0 140 524
assign 1 140 525
addValue 1 140 525
assign 1 140 526
libNameGet 0 140 526
assign 1 140 527
relEmitName 1 140 527
assign 1 140 528
addValue 1 140 528
assign 1 140 529
new 0 140 529
assign 1 140 530
addValue 1 140 530
assign 1 140 531
addValue 1 140 531
assign 1 140 532
new 0 140 532
addValue 1 140 533
addValue 1 142 534
assign 1 144 535
new 0 144 535
addValue 1 144 536
assign 1 150 553
typenameGet 0 150 553
assign 1 150 554
NULLGet 0 150 554
assign 1 150 555
equals 1 150 560
assign 1 151 561
new 0 151 561
assign 1 152 564
heldGet 0 152 564
assign 1 152 565
nameGet 0 152 565
assign 1 152 566
new 0 152 566
assign 1 152 567
equals 1 152 567
assign 1 153 569
new 0 153 569
assign 1 154 572
heldGet 0 154 572
assign 1 154 573
nameGet 0 154 573
assign 1 154 574
new 0 154 574
assign 1 154 575
equals 1 154 575
assign 1 155 577
new 0 155 577
assign 1 157 580
heldGet 0 157 580
assign 1 157 581
nameForVar 1 157 581
return 1 159 585
assign 1 165 594
isTmpVarGet 0 165 594
assign 1 166 596
new 0 166 596
assign 1 167 599
isPropertyGet 0 167 599
assign 1 168 601
new 0 168 601
assign 1 169 604
isArgGet 0 169 604
assign 1 170 606
new 0 170 606
assign 1 172 609
new 0 172 609
assign 1 174 613
nameGet 0 174 613
assign 1 174 614
add 1 174 614
return 1 174 615
assign 1 181 624
isTmpVarGet 0 181 624
assign 1 182 626
new 0 182 626
assign 1 183 629
isPropertyGet 0 183 629
assign 1 184 631
new 0 184 631
assign 1 185 634
isArgGet 0 185 634
assign 1 186 636
new 0 186 636
assign 1 188 639
new 0 188 639
assign 1 190 643
nameGet 0 190 643
assign 1 190 644
add 1 190 644
return 1 190 645
assign 1 195 655
heldGet 0 195 655
assign 1 195 656
nameGet 0 195 656
assign 1 195 657
new 0 195 657
assign 1 195 658
equals 1 195 658
assign 1 196 660
new 0 196 660
assign 1 196 661
add 1 196 661
return 1 197 662
assign 1 199 664
formCallTarg 1 199 664
return 1 199 665
assign 1 203 675
new 0 203 675
assign 1 203 676
addValue 1 203 676
assign 1 203 677
secondGet 0 203 677
assign 1 203 678
formTarg 1 203 678
assign 1 203 679
addValue 1 203 679
assign 1 203 680
new 0 203 680
assign 1 203 681
addValue 1 203 681
addValue 1 203 682
assign 1 207 692
heldGet 0 207 692
assign 1 207 693
langsGet 0 207 693
assign 1 207 694
new 0 207 694
assign 1 207 695
has 1 207 695
assign 1 208 697
heldGet 0 208 697
assign 1 208 698
textGet 0 208 698
addValue 1 208 699
handleClassEmit 1 210 702
assign 1 216 744
new 0 216 744
assign 1 216 745
emitNameGet 0 216 745
assign 1 216 746
add 1 216 746
assign 1 216 747
new 0 216 747
assign 1 216 748
add 1 216 748
assign 1 218 749
new 0 218 749
assign 1 218 750
typeEmitNameGet 0 218 750
assign 1 218 751
add 1 218 751
assign 1 218 752
new 0 218 752
assign 1 218 753
add 1 218 753
assign 1 218 754
add 1 218 754
assign 1 218 755
new 0 218 755
assign 1 218 756
add 1 218 756
addClassHeader 1 220 757
assign 1 222 758
new 0 222 758
assign 1 224 759
typeEmitNameGet 0 224 759
assign 1 224 760
addValue 1 224 760
assign 1 224 761
new 0 224 761
assign 1 224 762
addValue 1 224 762
assign 1 224 763
emitNameGet 0 224 763
assign 1 224 764
addValue 1 224 764
assign 1 224 765
new 0 224 765
assign 1 224 766
addValue 1 224 766
assign 1 224 767
addValue 1 224 767
assign 1 224 768
new 0 224 768
addValue 1 224 769
assign 1 226 770
new 0 226 770
assign 1 226 771
addValue 1 226 771
assign 1 226 772
typeEmitNameGet 0 226 772
assign 1 226 773
addValue 1 226 773
assign 1 226 774
new 0 226 774
assign 1 226 775
addValue 1 226 775
assign 1 226 776
emitNameGet 0 226 776
assign 1 226 777
addValue 1 226 777
assign 1 226 778
new 0 226 778
assign 1 226 779
emitNameGet 0 226 779
assign 1 226 780
add 1 226 780
assign 1 226 781
new 0 226 781
assign 1 226 782
add 1 226 782
addValue 1 226 783
return 1 228 784
assign 1 233 804
new 0 233 804
assign 1 233 805
toString 0 233 805
assign 1 233 806
add 1 233 806
incrementValue 0 234 807
assign 1 235 808
new 0 235 808
assign 1 235 809
addValue 1 235 809
assign 1 235 810
addValue 1 235 810
assign 1 235 811
new 0 235 811
assign 1 235 812
addValue 1 235 812
addValue 1 235 813
assign 1 237 814
containedGet 0 237 814
assign 1 237 815
firstGet 0 237 815
assign 1 237 816
containedGet 0 237 816
assign 1 237 817
firstGet 0 237 817
assign 1 237 818
new 0 237 818
assign 1 237 819
add 1 237 819
assign 1 237 820
new 0 237 820
assign 1 237 821
add 1 237 821
assign 1 237 822
finalAssign 4 237 822
addValue 1 237 823
assign 1 241 839
isTypedGet 0 241 839
assign 1 241 840
not 0 241 845
assign 1 242 846
libNameGet 0 242 846
assign 1 242 847
relEmitName 1 242 847
assign 1 242 848
addValue 1 242 848
assign 1 242 849
new 0 242 849
addValue 1 242 850
assign 1 244 853
namepathGet 0 244 853
assign 1 244 854
getClassConfig 1 244 854
assign 1 244 855
libNameGet 0 244 855
assign 1 244 856
relEmitName 1 244 856
assign 1 244 857
addValue 1 244 857
assign 1 244 858
new 0 244 858
addValue 1 244 859
assign 1 249 877
new 0 249 877
assign 1 249 878
equals 1 249 878
assign 1 250 880
new 0 250 880
assign 1 252 883
emitChecksGet 0 252 883
assign 1 252 884
new 0 252 884
assign 1 252 885
has 1 252 885
assign 1 253 887
new 0 253 887
assign 1 255 890
new 0 255 890
assign 1 258 893
new 0 258 893
assign 1 258 894
add 1 258 894
assign 1 258 895
libNameGet 0 258 895
assign 1 258 896
relEmitName 1 258 896
assign 1 258 897
add 1 258 897
assign 1 258 898
new 0 258 898
assign 1 258 899
add 1 258 899
return 1 258 900
assign 1 263 904
new 0 263 904
return 1 263 905
assign 1 267 932
overrideMtdDecGet 0 267 932
assign 1 267 933
addValue 1 267 933
assign 1 267 934
new 0 267 934
assign 1 267 935
addValue 1 267 935
assign 1 267 936
emitNameGet 0 267 936
assign 1 267 937
addValue 1 267 937
assign 1 267 938
new 0 267 938
assign 1 267 939
addValue 1 267 939
assign 1 267 940
addValue 1 267 940
assign 1 267 941
new 0 267 941
assign 1 267 942
addValue 1 267 942
assign 1 267 943
addValue 1 267 943
assign 1 267 944
new 0 267 944
assign 1 267 945
addValue 1 267 945
addValue 1 267 946
assign 1 268 947
new 0 268 947
assign 1 268 948
addValue 1 268 948
assign 1 268 949
addValue 1 268 949
assign 1 268 950
new 0 268 950
assign 1 268 951
addValue 1 268 951
assign 1 268 952
addValue 1 268 952
assign 1 268 953
new 0 268 953
assign 1 268 954
addValue 1 268 954
addValue 1 268 955
assign 1 270 956
new 0 270 956
assign 1 270 957
addValue 1 270 957
addValue 1 270 958
assign 1 274 996
emitChecksGet 0 274 996
assign 1 274 997
new 0 274 997
assign 1 274 998
has 1 274 998
assign 1 275 1000
new 0 275 1000
assign 1 275 1001
libNameGet 0 275 1001
assign 1 275 1002
relEmitName 1 275 1002
assign 1 275 1003
add 1 275 1003
assign 1 275 1004
new 0 275 1004
assign 1 275 1005
add 1 275 1005
assign 1 275 1006
libNameGet 0 275 1006
assign 1 275 1007
relEmitName 1 275 1007
assign 1 275 1008
add 1 275 1008
assign 1 275 1009
new 0 275 1009
assign 1 275 1010
add 1 275 1010
assign 1 275 1011
heldGet 0 275 1011
assign 1 275 1012
literalValueGet 0 275 1012
assign 1 275 1013
add 1 275 1013
assign 1 275 1014
new 0 275 1014
assign 1 275 1015
add 1 275 1015
assign 1 277 1018
new 0 277 1018
assign 1 277 1019
libNameGet 0 277 1019
assign 1 277 1020
relEmitName 1 277 1020
assign 1 277 1021
add 1 277 1021
assign 1 277 1022
new 0 277 1022
assign 1 277 1023
add 1 277 1023
assign 1 277 1024
libNameGet 0 277 1024
assign 1 277 1025
relEmitName 1 277 1025
assign 1 277 1026
add 1 277 1026
assign 1 277 1027
new 0 277 1027
assign 1 277 1028
add 1 277 1028
assign 1 277 1029
heldGet 0 277 1029
assign 1 277 1030
literalValueGet 0 277 1030
assign 1 277 1031
add 1 277 1031
assign 1 277 1032
new 0 277 1032
assign 1 277 1033
add 1 277 1033
return 1 279 1035
assign 1 283 1072
emitChecksGet 0 283 1072
assign 1 283 1073
new 0 283 1073
assign 1 283 1074
has 1 283 1074
assign 1 284 1076
new 0 284 1076
assign 1 284 1077
libNameGet 0 284 1077
assign 1 284 1078
relEmitName 1 284 1078
assign 1 284 1079
add 1 284 1079
assign 1 284 1080
new 0 284 1080
assign 1 284 1081
add 1 284 1081
assign 1 284 1082
libNameGet 0 284 1082
assign 1 284 1083
relEmitName 1 284 1083
assign 1 284 1084
add 1 284 1084
assign 1 284 1085
new 0 284 1085
assign 1 284 1086
add 1 284 1086
assign 1 284 1087
heldGet 0 284 1087
assign 1 284 1088
literalValueGet 0 284 1088
assign 1 284 1089
add 1 284 1089
assign 1 284 1090
new 0 284 1090
assign 1 284 1091
add 1 284 1091
assign 1 286 1094
new 0 286 1094
assign 1 286 1095
libNameGet 0 286 1095
assign 1 286 1096
relEmitName 1 286 1096
assign 1 286 1097
add 1 286 1097
assign 1 286 1098
new 0 286 1098
assign 1 286 1099
add 1 286 1099
assign 1 286 1100
libNameGet 0 286 1100
assign 1 286 1101
relEmitName 1 286 1101
assign 1 286 1102
add 1 286 1102
assign 1 286 1103
new 0 286 1103
assign 1 286 1104
add 1 286 1104
assign 1 286 1105
heldGet 0 286 1105
assign 1 286 1106
literalValueGet 0 286 1106
assign 1 286 1107
add 1 286 1107
assign 1 286 1108
new 0 286 1108
assign 1 286 1109
add 1 286 1109
return 1 288 1111
assign 1 292 1149
new 0 292 1149
assign 1 292 1150
add 1 292 1150
assign 1 292 1151
new 0 292 1151
assign 1 292 1152
add 1 292 1152
assign 1 292 1153
add 1 292 1153
assign 1 293 1154
emitChecksGet 0 293 1154
assign 1 293 1155
new 0 293 1155
assign 1 293 1156
has 1 293 1156
assign 1 294 1158
new 0 294 1158
assign 1 294 1159
libNameGet 0 294 1159
assign 1 294 1160
relEmitName 1 294 1160
assign 1 294 1161
add 1 294 1161
assign 1 294 1162
new 0 294 1162
assign 1 294 1163
add 1 294 1163
assign 1 294 1164
libNameGet 0 294 1164
assign 1 294 1165
relEmitName 1 294 1165
assign 1 294 1166
add 1 294 1166
assign 1 294 1167
new 0 294 1167
assign 1 294 1168
add 1 294 1168
assign 1 294 1169
add 1 294 1169
assign 1 294 1170
new 0 294 1170
assign 1 294 1171
add 1 294 1171
assign 1 296 1174
new 0 296 1174
assign 1 296 1175
libNameGet 0 296 1175
assign 1 296 1176
relEmitName 1 296 1176
assign 1 296 1177
add 1 296 1177
assign 1 296 1178
new 0 296 1178
assign 1 296 1179
add 1 296 1179
assign 1 296 1180
libNameGet 0 296 1180
assign 1 296 1181
relEmitName 1 296 1181
assign 1 296 1182
add 1 296 1182
assign 1 296 1183
new 0 296 1183
assign 1 296 1184
add 1 296 1184
assign 1 296 1185
add 1 296 1185
assign 1 296 1186
new 0 296 1186
assign 1 296 1187
add 1 296 1187
return 1 298 1189
getCode 2 303 1194
assign 1 304 1195
toHexString 1 304 1195
assign 1 305 1196
new 0 305 1196
addValue 1 305 1197
addValue 1 306 1198
assign 1 312 1205
new 0 312 1205
assign 1 312 1206
add 1 312 1206
assign 1 312 1207
add 1 312 1207
return 1 312 1208
assign 1 316 1212
new 0 316 1212
return 1 316 1213
assign 1 320 1217
new 0 320 1217
return 1 320 1218
assign 1 325 1222
new 0 325 1222
return 1 325 1223
assign 1 329 1227
new 0 329 1227
return 1 329 1228
assign 1 333 1232
new 0 333 1232
return 1 333 1233
assign 1 337 1238
new 0 337 1238
assign 1 337 1239
add 1 337 1239
return 1 337 1240
assign 1 344 1256
assign 1 345 1257
singleCCGet 0 345 1257
assign 1 0 1259
assign 1 345 1262
classPathGet 0 345 1262
assign 1 345 1263
fileGet 0 345 1263
assign 1 345 1264
existsGet 0 345 1264
assign 1 345 1265
not 0 345 1270
assign 1 0 1271
assign 1 0 1274
return 1 346 1278
assign 1 348 1281
classPathGet 0 348 1281
assign 1 348 1282
fileGet 0 348 1282
assign 1 348 1283
lastUpdatedGet 0 348 1283
assign 1 349 1284
fromFileGet 0 349 1284
assign 1 349 1285
fileGet 0 349 1285
assign 1 349 1286
lastUpdatedGet 0 349 1286
assign 1 350 1287
greater 1 350 1287
return 1 353 1289
assign 1 356 1291
assign 1 361 1299
singleCCGet 0 361 1299
assign 1 362 1301
getLibOutput 0 362 1301
return 1 362 1302
assign 1 364 1304
getClassOutput 0 364 1304
return 1 364 1305
assign 1 368 1311
singleCCGet 0 368 1311
assign 1 369 1313
new 0 369 1313
assign 1 370 1314
countLines 1 370 1314
addValue 1 370 1315
write 1 371 1316
assign 1 376 1327
singleCCGet 0 376 1327
assign 1 378 1329
new 0 378 1329
assign 1 379 1330
countLines 1 379 1330
addValue 1 379 1331
write 1 380 1332
close 0 381 1333
assign 1 382 1334
def 1 382 1339
assign 1 383 1340
pathGet 0 383 1340
assign 1 383 1341
fileGet 0 383 1341
lastUpdatedSet 1 383 1342
assign 1 384 1343
assign 1 390 1366
new 0 390 1366
assign 1 391 1367
emitChecksGet 0 391 1367
assign 1 391 1368
new 0 391 1368
assign 1 391 1369
has 1 391 1369
assign 1 392 1371
new 0 392 1371
assign 1 392 1372
addValue 1 392 1372
assign 1 392 1373
addValue 1 392 1373
assign 1 392 1374
new 0 392 1374
assign 1 392 1375
addValue 1 392 1375
assign 1 392 1376
addValue 1 392 1376
assign 1 392 1377
new 0 392 1377
assign 1 392 1378
addValue 1 392 1378
addValue 1 392 1379
assign 1 393 1380
addValue 1 393 1380
assign 1 393 1381
new 0 393 1381
assign 1 393 1382
addValue 1 393 1382
addValue 1 393 1383
assign 1 394 1384
new 0 394 1384
assign 1 394 1385
addValue 1 394 1385
addValue 1 394 1386
return 1 396 1388
assign 1 400 1482
new 0 400 1482
assign 1 400 1483
typeEmitNameGet 0 400 1483
assign 1 400 1484
add 1 400 1484
assign 1 400 1485
new 0 400 1485
assign 1 400 1486
add 1 400 1486
write 1 400 1487
assign 1 401 1488
new 0 401 1488
assign 1 402 1489
new 0 402 1489
assign 1 402 1490
addValue 1 402 1490
assign 1 402 1491
typeEmitNameGet 0 402 1491
assign 1 402 1492
addValue 1 402 1492
assign 1 402 1493
new 0 402 1493
addValue 1 402 1494
assign 1 403 1495
new 0 403 1495
addValue 1 403 1496
assign 1 404 1497
typeEmitNameGet 0 404 1497
assign 1 404 1498
addValue 1 404 1498
assign 1 404 1499
new 0 404 1499
addValue 1 404 1500
assign 1 405 1501
new 0 405 1501
addValue 1 405 1502
assign 1 406 1503
new 0 406 1503
addValue 1 406 1504
assign 1 407 1505
new 0 407 1505
addValue 1 407 1506
assign 1 408 1507
new 0 408 1507
addValue 1 408 1508
write 1 409 1509
assign 1 411 1510
new 0 411 1510
assign 1 412 1511
typeEmitNameGet 0 412 1511
assign 1 412 1512
addValue 1 412 1512
assign 1 412 1513
new 0 412 1513
assign 1 412 1514
addValue 1 412 1514
assign 1 412 1515
typeEmitNameGet 0 412 1515
assign 1 412 1516
addValue 1 412 1516
assign 1 412 1517
new 0 412 1517
addValue 1 412 1518
assign 1 413 1519
new 0 413 1519
addValue 1 413 1520
assign 1 414 1521
emitChecksGet 0 414 1521
assign 1 414 1522
new 0 414 1522
assign 1 414 1523
has 1 414 1523
assign 1 415 1525
new 0 415 1525
assign 1 416 1526
mtdListGet 0 416 1526
assign 1 416 1527
iteratorGet 0 0 1527
assign 1 416 1530
hasNextGet 0 416 1530
assign 1 416 1532
nextGet 0 416 1532
assign 1 418 1534
new 0 418 1534
assign 1 420 1537
new 0 420 1537
addValue 1 420 1538
assign 1 422 1540
addValue 1 422 1540
assign 1 422 1541
nameGet 0 422 1541
assign 1 422 1542
addValue 1 422 1542
addValue 1 422 1543
assign 1 425 1550
new 0 425 1550
addValue 1 425 1551
assign 1 427 1552
emitChecksGet 0 427 1552
assign 1 427 1553
new 0 427 1553
assign 1 427 1554
has 1 427 1554
assign 1 428 1556
new 0 428 1556
addValue 1 428 1557
assign 1 431 1559
new 0 431 1559
addValue 1 431 1560
assign 1 432 1561
emitChecksGet 0 432 1561
assign 1 432 1562
new 0 432 1562
assign 1 432 1563
has 1 432 1563
assign 1 433 1565
new 0 433 1565
assign 1 434 1566
ptyListGet 0 434 1566
assign 1 434 1567
iteratorGet 0 0 1567
assign 1 434 1570
hasNextGet 0 434 1570
assign 1 434 1572
nextGet 0 434 1572
assign 1 435 1573
isSlotGet 0 435 1573
assign 1 437 1576
new 0 437 1576
assign 1 439 1579
new 0 439 1579
addValue 1 439 1580
assign 1 441 1582
addValue 1 441 1582
assign 1 441 1583
nameGet 0 441 1583
assign 1 441 1584
addValue 1 441 1584
addValue 1 441 1585
assign 1 445 1593
new 0 445 1593
addValue 1 445 1594
assign 1 447 1595
new 0 447 1595
addValue 1 447 1596
assign 1 449 1597
new 0 449 1597
assign 1 449 1598
addValue 1 449 1598
assign 1 449 1599
typeEmitNameGet 0 449 1599
assign 1 449 1600
addValue 1 449 1600
assign 1 449 1601
new 0 449 1601
addValue 1 449 1602
assign 1 450 1603
emitNameGet 0 450 1603
assign 1 450 1604
new 0 450 1604
assign 1 450 1605
equals 1 450 1605
assign 1 451 1607
new 0 451 1607
assign 1 451 1608
addValue 1 451 1608
assign 1 451 1609
emitNameGet 0 451 1609
assign 1 451 1610
addValue 1 451 1610
assign 1 451 1611
new 0 451 1611
addValue 1 451 1612
assign 1 453 1615
new 0 453 1615
assign 1 453 1616
addValue 1 453 1616
assign 1 453 1617
emitNameGet 0 453 1617
assign 1 453 1618
addValue 1 453 1618
assign 1 453 1619
new 0 453 1619
addValue 1 453 1620
assign 1 455 1622
new 0 455 1622
addValue 1 455 1623
assign 1 457 1624
new 0 457 1624
assign 1 457 1625
addValue 1 457 1625
assign 1 457 1626
typeEmitNameGet 0 457 1626
assign 1 457 1627
addValue 1 457 1627
assign 1 457 1628
new 0 457 1628
addValue 1 457 1629
assign 1 458 1630
new 0 458 1630
addValue 1 458 1631
assign 1 459 1632
new 0 459 1632
assign 1 459 1633
genMark 1 459 1633
addValue 1 459 1634
assign 1 460 1635
new 0 460 1635
addValue 1 460 1636
assign 1 463 1637
getClassOutput 0 463 1637
write 1 463 1638
assign 1 464 1639
countLines 1 464 1639
addValue 1 464 1640
assign 1 476 1712
undef 1 476 1717
assign 1 477 1718
libNameGet 0 477 1718
assign 1 478 1719
new 0 478 1719
assign 1 478 1720
sizeGet 0 478 1720
assign 1 478 1721
add 1 478 1721
assign 1 478 1722
new 0 478 1722
assign 1 478 1723
add 1 478 1723
assign 1 478 1724
add 1 478 1724
assign 1 478 1725
add 1 478 1725
assign 1 479 1726
new 0 479 1726
assign 1 479 1727
sizeGet 0 479 1727
assign 1 479 1728
add 1 479 1728
assign 1 479 1729
new 0 479 1729
assign 1 479 1730
add 1 479 1730
assign 1 479 1731
add 1 479 1731
assign 1 479 1732
add 1 479 1732
assign 1 480 1733
parentGet 0 480 1733
assign 1 480 1734
addStep 1 480 1734
assign 1 481 1735
parentGet 0 481 1735
assign 1 481 1736
addStep 1 481 1736
assign 1 482 1737
parentGet 0 482 1737
assign 1 482 1738
fileGet 0 482 1738
assign 1 482 1739
existsGet 0 482 1739
assign 1 482 1740
not 0 482 1745
assign 1 483 1746
parentGet 0 483 1746
assign 1 483 1747
fileGet 0 483 1747
makeDirs 0 483 1748
assign 1 485 1750
fileGet 0 485 1750
assign 1 485 1751
writerGet 0 485 1751
assign 1 485 1752
open 0 485 1752
assign 1 486 1753
fileGet 0 486 1753
assign 1 486 1754
writerGet 0 486 1754
assign 1 486 1755
open 0 486 1755
assign 1 488 1756
paramsGet 0 488 1756
assign 1 488 1757
new 0 488 1757
assign 1 488 1758
has 1 488 1758
assign 1 490 1760
paramsGet 0 490 1760
assign 1 490 1761
new 0 490 1761
assign 1 490 1762
get 1 490 1762
assign 1 490 1763
iteratorGet 0 0 1763
assign 1 490 1766
hasNextGet 0 490 1766
assign 1 490 1768
nextGet 0 490 1768
assign 1 492 1769
apNew 1 492 1769
assign 1 492 1770
fileGet 0 492 1770
assign 1 493 1771
readerGet 0 493 1771
assign 1 493 1772
open 0 493 1772
assign 1 493 1773
readString 0 493 1773
assign 1 494 1774
readerGet 0 494 1774
close 0 494 1775
write 1 496 1776
assign 1 500 1783
new 0 500 1783
write 1 500 1784
assign 1 503 1785
new 0 503 1785
write 1 503 1786
assign 1 504 1787
new 0 504 1787
write 1 504 1788
assign 1 510 1789
paramsGet 0 510 1789
assign 1 510 1790
new 0 510 1790
assign 1 510 1791
has 1 510 1791
assign 1 512 1793
paramsGet 0 512 1793
assign 1 512 1794
new 0 512 1794
assign 1 512 1795
get 1 512 1795
assign 1 512 1796
iteratorGet 0 0 1796
assign 1 512 1799
hasNextGet 0 512 1799
assign 1 512 1801
nextGet 0 512 1801
assign 1 514 1802
apNew 1 514 1802
assign 1 514 1803
fileGet 0 514 1803
assign 1 515 1804
readerGet 0 515 1804
assign 1 515 1805
open 0 515 1805
assign 1 515 1806
readString 0 515 1806
assign 1 516 1807
readerGet 0 516 1807
close 0 516 1808
write 1 518 1809
assign 1 521 1816
paramsGet 0 521 1816
assign 1 521 1817
new 0 521 1817
assign 1 521 1818
has 1 521 1818
assign 1 523 1820
paramsGet 0 523 1820
assign 1 523 1821
new 0 523 1821
assign 1 523 1822
get 1 523 1822
assign 1 523 1823
iteratorGet 0 0 1823
assign 1 523 1826
hasNextGet 0 523 1826
assign 1 523 1828
nextGet 0 523 1828
assign 1 525 1829
apNew 1 525 1829
assign 1 525 1830
fileGet 0 525 1830
assign 1 526 1831
readerGet 0 526 1831
assign 1 526 1832
open 0 526 1832
assign 1 526 1833
readString 0 526 1833
assign 1 527 1834
readerGet 0 527 1834
close 0 527 1835
write 1 529 1836
begin 1 536 1847
prepHeaderOutput 0 537 1848
assign 1 542 1891
undef 1 542 1896
assign 1 543 1897
new 0 543 1897
assign 1 544 1898
parentGet 0 544 1898
assign 1 544 1899
fileGet 0 544 1899
assign 1 544 1900
existsGet 0 544 1900
assign 1 544 1901
not 0 544 1906
assign 1 545 1907
parentGet 0 545 1907
assign 1 545 1908
fileGet 0 545 1908
makeDirs 0 545 1909
assign 1 547 1911
fileGet 0 547 1911
assign 1 547 1912
writerGet 0 547 1912
assign 1 547 1913
open 0 547 1913
assign 1 549 1914
new 0 549 1914
write 1 549 1915
assign 1 551 1916
paramsGet 0 551 1916
assign 1 551 1917
new 0 551 1917
assign 1 551 1918
has 1 551 1918
assign 1 553 1920
paramsGet 0 553 1920
assign 1 553 1921
new 0 553 1921
assign 1 553 1922
get 1 553 1922
assign 1 553 1923
iteratorGet 0 0 1923
assign 1 553 1926
hasNextGet 0 553 1926
assign 1 553 1928
nextGet 0 553 1928
assign 1 555 1929
apNew 1 555 1929
assign 1 555 1930
fileGet 0 555 1930
assign 1 556 1931
readerGet 0 556 1931
assign 1 556 1932
open 0 556 1932
assign 1 556 1933
readString 0 556 1933
assign 1 557 1934
readerGet 0 557 1934
close 0 557 1935
write 1 559 1936
assign 1 563 1943
new 0 563 1943
write 1 563 1944
increment 0 564 1945
assign 1 565 1946
paramsGet 0 565 1946
assign 1 565 1947
new 0 565 1947
assign 1 565 1948
has 1 565 1948
assign 1 566 1950
paramsGet 0 566 1950
assign 1 566 1951
new 0 566 1951
assign 1 566 1952
get 1 566 1952
assign 1 566 1953
iteratorGet 0 0 1953
assign 1 566 1956
hasNextGet 0 566 1956
assign 1 566 1958
nextGet 0 566 1958
assign 1 567 1959
apNew 1 567 1959
assign 1 567 1960
fileGet 0 567 1960
assign 1 568 1961
readerGet 0 568 1961
assign 1 568 1962
open 0 568 1962
assign 1 568 1963
readString 0 568 1963
assign 1 569 1964
readerGet 0 569 1964
close 0 569 1965
assign 1 570 1966
countLines 1 570 1966
addValue 1 570 1967
write 1 571 1968
return 1 577 1976
close 0 582 1987
assign 1 583 1988
assign 1 585 1989
new 0 585 1989
write 1 585 1990
assign 1 587 1991
new 0 587 1991
write 1 587 1992
assign 1 589 1993
emitChecksGet 0 589 1993
assign 1 589 1994
new 0 589 1994
assign 1 589 1995
has 1 589 1995
assign 1 590 1997
new 0 590 1997
assign 1 591 1998
new 0 591 1998
assign 1 591 1999
addValue 1 591 1999
addValue 1 591 2000
write 1 592 2001
close 0 595 2003
close 0 596 2004
assign 1 601 2009
new 0 601 2009
return 1 601 2010
assign 1 605 2014
new 0 605 2014
addValue 1 605 2015
assign 1 609 2020
new 0 609 2020
addValue 1 609 2021
assign 1 613 2032
emitChecksGet 0 613 2032
assign 1 613 2033
new 0 613 2033
assign 1 613 2034
has 1 613 2034
assign 1 614 2036
new 0 614 2036
assign 1 614 2037
addValue 1 614 2037
assign 1 614 2038
addValue 1 614 2038
assign 1 614 2039
new 0 614 2039
addValue 1 614 2040
assign 1 620 2064
heldGet 0 620 2064
assign 1 620 2065
synGet 0 620 2065
assign 1 621 2066
ptyListGet 0 621 2066
assign 1 623 2067
emitNameGet 0 623 2067
assign 1 623 2068
addValue 1 623 2068
assign 1 623 2069
new 0 623 2069
addValue 1 623 2070
assign 1 625 2071
new 0 625 2071
assign 1 626 2072
iteratorGet 0 0 2072
assign 1 626 2075
hasNextGet 0 626 2075
assign 1 626 2077
nextGet 0 626 2077
assign 1 627 2078
isSlotGet 0 627 2078
assign 1 629 2081
new 0 629 2081
assign 1 631 2084
new 0 631 2084
addValue 1 631 2085
assign 1 633 2087
addValue 1 633 2087
assign 1 633 2088
new 0 633 2088
assign 1 633 2089
addValue 1 633 2089
assign 1 633 2090
nameGet 0 633 2090
assign 1 633 2091
addValue 1 633 2091
addValue 1 633 2092
assign 1 638 2099
new 0 638 2099
assign 1 638 2100
addValue 1 638 2100
addValue 1 638 2101
assign 1 643 2121
new 0 643 2121
assign 1 645 2122
new 0 645 2122
assign 1 645 2123
emitNameGet 0 645 2123
assign 1 645 2124
add 1 645 2124
assign 1 645 2125
new 0 645 2125
assign 1 645 2126
add 1 645 2126
assign 1 647 2127
emitNameGet 0 647 2127
assign 1 647 2128
addValue 1 647 2128
assign 1 647 2129
new 0 647 2129
assign 1 647 2130
addValue 1 647 2130
assign 1 647 2131
emitNameGet 0 647 2131
assign 1 647 2132
addValue 1 647 2132
assign 1 647 2133
new 0 647 2133
assign 1 647 2134
addValue 1 647 2134
assign 1 647 2135
addValue 1 647 2135
assign 1 647 2136
new 0 647 2136
addValue 1 647 2137
return 1 649 2138
assign 1 653 2147
libNameGet 0 653 2147
assign 1 653 2148
relEmitName 1 653 2148
assign 1 654 2149
new 0 654 2149
assign 1 654 2150
add 1 654 2150
assign 1 654 2151
new 0 654 2151
assign 1 654 2152
add 1 654 2152
return 1 655 2153
assign 1 659 2165
libNameGet 0 659 2165
assign 1 659 2166
relEmitName 1 659 2166
assign 1 660 2167
new 0 660 2167
assign 1 660 2168
add 1 660 2168
assign 1 660 2169
new 0 660 2169
assign 1 660 2170
add 1 660 2170
assign 1 661 2171
new 0 661 2171
assign 1 661 2172
add 1 661 2172
assign 1 661 2173
add 1 661 2173
return 1 661 2174
assign 1 665 2179
new 0 665 2179
assign 1 665 2180
add 1 665 2180
return 1 665 2181
assign 1 669 2297
getClassConfig 1 669 2297
assign 1 669 2298
libNameGet 0 669 2298
assign 1 669 2299
relEmitName 1 669 2299
assign 1 670 2300
heldGet 0 670 2300
assign 1 670 2301
namepathGet 0 670 2301
assign 1 670 2302
getClassConfig 1 670 2302
assign 1 671 2303
getInitialInst 1 671 2303
assign 1 673 2304
overrideMtdDecGet 0 673 2304
assign 1 673 2305
addValue 1 673 2305
assign 1 673 2306
new 0 673 2306
assign 1 673 2307
addValue 1 673 2307
assign 1 673 2308
emitNameGet 0 673 2308
assign 1 673 2309
addValue 1 673 2309
assign 1 673 2310
new 0 673 2310
assign 1 673 2311
addValue 1 673 2311
assign 1 673 2312
addValue 1 673 2312
assign 1 673 2313
new 0 673 2313
assign 1 673 2314
addValue 1 673 2314
assign 1 673 2315
addValue 1 673 2315
assign 1 673 2316
new 0 673 2316
assign 1 673 2317
addValue 1 673 2317
addValue 1 673 2318
assign 1 674 2319
new 0 674 2319
assign 1 675 2320
emitNameGet 0 675 2320
assign 1 675 2321
notEquals 1 675 2321
assign 1 676 2323
new 0 676 2323
assign 1 676 2324
formCast 3 676 2324
assign 1 679 2326
addValue 1 679 2326
assign 1 679 2327
new 0 679 2327
assign 1 679 2328
addValue 1 679 2328
assign 1 679 2329
addValue 1 679 2329
assign 1 679 2330
new 0 679 2330
assign 1 679 2331
addValue 1 679 2331
addValue 1 679 2332
assign 1 681 2333
new 0 681 2333
assign 1 681 2334
addValue 1 681 2334
addValue 1 681 2335
assign 1 684 2336
overrideMtdDecGet 0 684 2336
assign 1 684 2337
addValue 1 684 2337
assign 1 684 2338
addValue 1 684 2338
assign 1 684 2339
new 0 684 2339
assign 1 684 2340
addValue 1 684 2340
assign 1 684 2341
emitNameGet 0 684 2341
assign 1 684 2342
addValue 1 684 2342
assign 1 684 2343
new 0 684 2343
assign 1 684 2344
addValue 1 684 2344
assign 1 684 2345
addValue 1 684 2345
assign 1 684 2346
new 0 684 2346
assign 1 684 2347
addValue 1 684 2347
addValue 1 684 2348
assign 1 689 2349
new 0 689 2349
assign 1 689 2350
addValue 1 689 2350
assign 1 689 2351
addValue 1 689 2351
assign 1 689 2352
new 0 689 2352
assign 1 689 2353
addValue 1 689 2353
addValue 1 689 2354
assign 1 692 2355
new 0 692 2355
assign 1 692 2356
addValue 1 692 2356
addValue 1 692 2357
assign 1 694 2358
overrideMtdDecGet 0 694 2358
assign 1 694 2359
addValue 1 694 2359
assign 1 694 2360
new 0 694 2360
assign 1 694 2361
addValue 1 694 2361
assign 1 694 2362
emitNameGet 0 694 2362
assign 1 694 2363
addValue 1 694 2363
assign 1 694 2364
new 0 694 2364
assign 1 694 2365
addValue 1 694 2365
assign 1 694 2366
addValue 1 694 2366
assign 1 694 2367
new 0 694 2367
assign 1 694 2368
addValue 1 694 2368
addValue 1 694 2369
assign 1 695 2370
heldGet 0 695 2370
assign 1 695 2371
extendsGet 0 695 2371
assign 1 695 2372
undef 1 695 2377
assign 1 0 2378
assign 1 695 2381
heldGet 0 695 2381
assign 1 695 2382
extendsGet 0 695 2382
assign 1 695 2383
equals 1 695 2383
assign 1 0 2385
assign 1 0 2388
assign 1 696 2392
new 0 696 2392
assign 1 696 2393
addValue 1 696 2393
addValue 1 696 2394
assign 1 698 2397
new 0 698 2397
assign 1 698 2398
addValue 1 698 2398
addValue 1 698 2399
addValue 1 700 2401
clear 0 701 2402
assign 1 704 2403
new 0 704 2403
assign 1 704 2404
addValue 1 704 2404
addValue 1 704 2405
assign 1 706 2406
overrideMtdDecGet 0 706 2406
assign 1 706 2407
addValue 1 706 2407
assign 1 706 2408
new 0 706 2408
assign 1 706 2409
addValue 1 706 2409
assign 1 706 2410
emitNameGet 0 706 2410
assign 1 706 2411
addValue 1 706 2411
assign 1 706 2412
new 0 706 2412
assign 1 706 2413
addValue 1 706 2413
assign 1 706 2414
addValue 1 706 2414
assign 1 706 2415
new 0 706 2415
assign 1 706 2416
addValue 1 706 2416
addValue 1 706 2417
assign 1 707 2418
new 0 707 2418
assign 1 707 2419
addValue 1 707 2419
addValue 1 707 2420
assign 1 709 2421
new 0 709 2421
assign 1 709 2422
addValue 1 709 2422
addValue 1 709 2423
assign 1 711 2424
emitChecksGet 0 711 2424
assign 1 711 2425
new 0 711 2425
assign 1 711 2426
has 1 711 2426
assign 1 711 2428
heldGet 0 711 2428
assign 1 711 2429
synGet 0 711 2429
assign 1 711 2430
hasDefaultGet 0 711 2430
assign 1 711 2431
not 0 711 2431
assign 1 0 2433
assign 1 0 2436
assign 1 0 2440
assign 1 712 2443
getTypeInst 1 712 2443
assign 1 714 2444
new 0 714 2444
assign 1 714 2445
addValue 1 714 2445
assign 1 714 2446
emitNameGet 0 714 2446
assign 1 714 2447
addValue 1 714 2447
assign 1 714 2448
new 0 714 2448
assign 1 714 2449
addValue 1 714 2449
addValue 1 714 2450
assign 1 716 2451
new 0 716 2451
assign 1 716 2452
addValue 1 716 2452
assign 1 716 2453
addValue 1 716 2453
assign 1 716 2454
new 0 716 2454
assign 1 716 2455
addValue 1 716 2455
addValue 1 716 2456
assign 1 718 2457
new 0 718 2457
assign 1 718 2458
addValue 1 718 2458
addValue 1 718 2459
assign 1 725 2472
new 0 725 2472
assign 1 725 2473
add 1 725 2473
assign 1 725 2474
new 0 725 2474
assign 1 725 2475
add 1 725 2475
write 1 725 2476
assign 1 726 2477
new 0 726 2477
assign 1 726 2478
add 1 726 2478
assign 1 726 2479
new 0 726 2479
assign 1 726 2480
add 1 726 2480
write 1 726 2481
emitLib 0 728 2482
assign 1 733 2495
libNameGet 0 733 2495
assign 1 733 2496
relEmitName 1 733 2496
assign 1 734 2497
new 0 734 2497
assign 1 734 2498
add 1 734 2498
assign 1 734 2499
new 0 734 2499
assign 1 734 2500
add 1 734 2500
assign 1 735 2501
new 0 735 2501
assign 1 735 2502
add 1 735 2502
assign 1 735 2503
add 1 735 2503
return 1 735 2504
return 1 0 2507
assign 1 0 2510
return 1 0 2514
assign 1 0 2517
return 1 0 2521
assign 1 0 2524
return 1 0 2528
assign 1 0 2531
return 1 0 2535
assign 1 0 2538
return 1 0 2542
assign 1 0 2545
return 1 0 2549
assign 1 0 2552
return 1 0 2556
assign 1 0 2559
return 1 0 2563
assign 1 0 2566
return 1 0 2570
assign 1 0 2573
return 1 0 2577
assign 1 0 2580
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1962423391: return bem_inFilePathedGet_0();
case -424955215: return bem_methodCallsGet_0();
case 668645503: return bem_new_0();
case -1885078136: return bem_baseSmtdDecGet_0();
case -1252651867: return bem_lineCountGet_0();
case 157115939: return bem_endNs_0();
case -587266305: return bem_maxDynArgsGet_0();
case 748870249: return bem_constGet_0();
case 1889144218: return bem_classHeadBodyGet_0();
case 695562143: return bem_parentConfGet_0();
case 1302633190: return bem_heowGet_0();
case 1508799196: return bem_gcMarksGet_0();
case 762936388: return bem_boolNpGet_0();
case -1629631874: return bem_propDecGet_0();
case -892204798: return bem_ccMethodsGet_0();
case -1017448881: return bem_fullLibEmitNameGet_0();
case 1193621038: return bem_falseValueGet_0();
case -1430858927: return bem_useDynMethodsGet_0();
case 326916018: return bem_iteratorGet_0();
case -1555834283: return bem_objectNpGet_0();
case -157551407: return bem_fileExtGet_0();
case 1273116306: return bem_classEmitsGet_0();
case 2021605548: return bem_overrideMtdDecGet_0();
case -994419444: return bem_stringNpGet_0();
case 1710176502: return bem_classCallsGet_0();
case -161809366: return bem_copy_0();
case 1401626610: return bem_print_0();
case -169298279: return bem_mainStartGet_0();
case -2140525323: return bem_emitLangGet_0();
case -1020049994: return bem_callNamesGet_0();
case -1116000851: return bem_ntypesGet_0();
case 323000744: return bem_onceDecsGet_0();
case 673614402: return bem_instanceNotEqualGet_0();
case -491885699: return bem_classesInDepthOrderGet_0();
case 1420360319: return bem_intNpGet_0();
case 2119015631: return bem_preClassGet_0();
case 2132435442: return bem_deowGet_0();
case -892864536: return bem_methodCatchGet_0();
case 1776428340: return bem_methodsGet_0();
case 846069581: return bem_boolTypeGet_0();
case -1907053121: return bem_instanceEqualGet_0();
case 1695112983: return bem_objectCcGet_0();
case -1385507384: return bem_runtimeInitGet_0();
case 35014349: return bem_setOutputTimeGet_0();
case -161413294: return bem_synEmitPathGet_0();
case -1519078495: return bem_emitLib_0();
case 884659234: return bem_doEmit_0();
case 1945070194: return bem_libEmitPathGet_0();
case -1331882675: return bem_saveSyns_0();
case 2115106675: return bem_buildPropList_0();
case 1996398184: return bem_methodBodyGet_0();
case 888024752: return bem_nullValueGet_0();
case 2110839309: return bem_lastMethodsSizeGet_0();
case -673183124: return bem_dynMethodsGet_0();
case -1202633660: return bem_covariantReturnsGet_0();
case -872452116: return bem_inClassGet_0();
case -1939123501: return bem_spropDecGet_0();
case -487366157: return bem_writeBET_0();
case 104138777: return bem_cnodeGet_0();
case -539381946: return bem_trueValueGet_0();
case -1075217657: return bem_boolCcGet_0();
case 984593204: return bem_afterCast_0();
case -577872362: return bem_getClassOutput_0();
case -1313245695: return bem_floatNpGet_0();
case 1416039164: return bem_shlibeGet_0();
case -517664014: return bem_headExtGet_0();
case -751392559: return bem_invpGet_0();
case 1755830586: return bem_returnTypeGet_0();
case -1882824508: return bem_superCallsGet_0();
case 2087563741: return bem_initialDecGet_0();
case -1279560337: return bem_lastMethodBodyLinesGet_0();
case 2037704197: return bem_idToNamePathGet_0();
case -1321771278: return bem_ccCacheGet_0();
case -2014082899: return bem_mainOutsideNsGet_0();
case -376514807: return bem_nlGet_0();
case 2112503353: return bem_loadIds_0();
case -1527524637: return bem_saveIds_0();
case -1397235784: return bem_newDecGet_0();
case -927478661: return bem_getLibOutput_0();
case 1647775124: return bem_maxSpillArgsLenGet_0();
case 840785797: return bem_deopGet_0();
case 1720683544: return bem_heopGet_0();
case -568694870: return bem_typeDecGet_0();
case -2039518296: return bem_idToNameGet_0();
case -1528983497: return bem_exceptDecGet_0();
case 603669559: return bem_prepHeaderOutput_0();
case -942184561: return bem_randGet_0();
case 1835697255: return bem_instOfGet_0();
case 1828704259: return bem_buildClassInfo_0();
case 233702056: return bem_classHeadersGet_0();
case -1203635661: return bem_superNameGet_0();
case -716300033: return bem_transGet_0();
case 1939511278: return bem_qGet_0();
case 1736937809: return bem_beginNs_0();
case 726380142: return bem_mnodeGet_0();
case -1470569929: return bem_buildInitial_0();
case -1081069288: return bem_baseMtdDecGet_0();
case -308440487: return bem_scvpGet_0();
case -1330149907: return bem_lastMethodBodySizeGet_0();
case 1547937850: return bem_msynGet_0();
case 1305856737: return bem_mainInClassGet_0();
case -1134204813: return bem_nativeCSlotsGet_0();
case 597892476: return bem_nameToIdPathGet_0();
case -1087070790: return bem_libEmitNameGet_0();
case -1957851395: return bem_lastMethodsLinesGet_0();
case 171453037: return bem_classEndGet_0();
case 690027011: return bem_nameToIdGet_0();
case 2090945888: return bem_csynGet_0();
case -67492023: return bem_smnlcsGet_0();
case -508717313: return bem_create_0();
case 1101146524: return bem_smnlecsGet_0();
case 969005479: return bem_toString_0();
case -781790416: return bem_deonGet_0();
case 1105711602: return bem_propertyDecsGet_0();
case 1899997731: return bem_mainEndGet_0();
case 402801771: return bem_preClassOutput_0();
case -2109183562: return bem_buildGet_0();
case -1877988678: return bem_hashGet_0();
case -457181639: return bem_heonGet_0();
case 879887927: return bem_belslitsGet_0();
case 1789309248: return bem_buildCreate_0();
case 366163814: return bem_classConfGet_0();
case 1848039847: return bem_lastCallGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 323139664: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 302525107: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1704939091: return bem_synEmitPathSet_1(bevd_0);
case 512096595: return bem_propertyDecsSet_1(bevd_0);
case -1813220257: return bem_heonSet_1(bevd_0);
case -765976491: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 312212566: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -286120357: return bem_nameToIdSet_1(bevd_0);
case 1441839002: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1641168301: return bem_falseValueSet_1(bevd_0);
case -1383729112: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1765263300: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 914441556: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 906177244: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1009193769: return bem_mnodeSet_1(bevd_0);
case -1872962328: return bem_superCallsSet_1(bevd_0);
case 1703242757: return bem_fullLibEmitNameSet_1(bevd_0);
case -1150799885: return bem_nativeCSlotsSet_1(bevd_0);
case -1468626716: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case -817718778: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 573950005: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1621855469: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 567335501: return bem_equals_1(bevd_0);
case 1155980899: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1488191292: return bem_transSet_1(bevd_0);
case -1098835823: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1513695005: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 780775842: return bem_cnodeSet_1(bevd_0);
case 1431937855: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1702331907: return bem_nameToIdPathSet_1(bevd_0);
case -521832381: return bem_gcMarksSet_1(bevd_0);
case -548547709: return bem_end_1(bevd_0);
case -184662939: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1844188896: return bem_scvpSet_1(bevd_0);
case -745397485: return bem_classHeadBodySet_1(bevd_0);
case 764241640: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1302589590: return bem_maxDynArgsSet_1(bevd_0);
case 2039257006: return bem_lastMethodsSizeSet_1(bevd_0);
case -462727178: return bem_boolNpSet_1(bevd_0);
case -301605581: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1869023695: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 234518228: return bem_nlSet_1(bevd_0);
case -265399065: return bem_dynMethodsSet_1(bevd_0);
case -618889736: return bem_headExtSet_1(bevd_0);
case 2130357488: return bem_csynSet_1(bevd_0);
case -475260793: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -660283705: return bem_inClassSet_1(bevd_0);
case -1685766411: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 256843745: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1530052518: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 384561560: return bem_libEmitPathSet_1(bevd_0);
case -1581048634: return bem_copyTo_1(bevd_0);
case -97687935: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1506828185: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1234510973: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 382332086: return bem_emitLangSet_1(bevd_0);
case -1738736366: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 939305500: return bem_def_1(bevd_0);
case 2104334470: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -367779700: return bem_fileExtSet_1(bevd_0);
case 1794040328: return bem_libEmitNameSet_1(bevd_0);
case 428679492: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -236666611: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 325301186: return bem_classesInDepthOrderSet_1(bevd_0);
case -530387925: return bem_decNameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1035024158: return bem_stringNpSet_1(bevd_0);
case -1417363947: return bem_ntypesSet_1(bevd_0);
case -462265817: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1310829131: return bem_classEmitsSet_1(bevd_0);
case -167485660: return bem_inFilePathedSet_1(bevd_0);
case 2023065404: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2025044049: return bem_trueValueSet_1(bevd_0);
case 318822585: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 262351233: return bem_heopSet_1(bevd_0);
case 1559297306: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1777577686: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1911342384: return bem_idToNameSet_1(bevd_0);
case -1563216825: return bem_methodsSet_1(bevd_0);
case 1727004501: return bem_constSet_1(bevd_0);
case -1420726332: return bem_buildSet_1(bevd_0);
case -126943212: return bem_nullValueSet_1(bevd_0);
case 886029361: return bem_methodCatchSet_1(bevd_0);
case -1312377705: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -795173353: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 547126494: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1005554432: return bem_lastCallSet_1(bevd_0);
case -1097664697: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -498306818: return bem_methodCallsSet_1(bevd_0);
case 1044795275: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1376956624: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1391871629: return bem_undef_1(bevd_0);
case 1910975854: return bem_classConfSet_1(bevd_0);
case 1934239601: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 655646458: return bem_heowSet_1(bevd_0);
case -184158356: return bem_setOutputTimeSet_1(bevd_0);
case 1776341267: return bem_ccMethodsSet_1(bevd_0);
case -193285373: return bem_objectCcSet_1(bevd_0);
case -1947851359: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2122208409: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -941479741: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2131262269: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1823696897: return bem_instanceEqualSet_1(bevd_0);
case 1648459472: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 564350697: return bem_ccCacheSet_1(bevd_0);
case 1109916153: return bem_deowSet_1(bevd_0);
case -839414377: return bem_parentConfSet_1(bevd_0);
case 708175851: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1765175358: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -320180742: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1623573286: return bem_deopSet_1(bevd_0);
case -806408594: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1830988407: return bem_classCallsSet_1(bevd_0);
case 1381571707: return bem_smnlcsSet_1(bevd_0);
case -795604476: return bem_instOfSet_1(bevd_0);
case 1757597714: return bem_belslitsSet_1(bevd_0);
case -1178962941: return bem_intNpSet_1(bevd_0);
case -659976923: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1717328581: return bem_exceptDecSet_1(bevd_0);
case 489238688: return bem_preClassSet_1(bevd_0);
case -547762656: return bem_invpSet_1(bevd_0);
case -180481790: return bem_floatNpSet_1(bevd_0);
case -333740272: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -72659768: return bem_callNamesSet_1(bevd_0);
case 1430466239: return bem_classHeadersSet_1(bevd_0);
case 851344237: return bem_msynSet_1(bevd_0);
case 1088967242: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -213648422: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -753637337: return bem_objectNpSet_1(bevd_0);
case -105838459: return bem_idToNamePathSet_1(bevd_0);
case -51652884: return bem_randSet_1(bevd_0);
case 1421865064: return bem_lineCountSet_1(bevd_0);
case 1767310908: return bem_boolCcSet_1(bevd_0);
case 718358649: return bem_onceDecsSet_1(bevd_0);
case 1716832582: return bem_begin_1(bevd_0);
case -1958309162: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 101566037: return bem_returnTypeSet_1(bevd_0);
case 3863156: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 498382664: return bem_qSet_1(bevd_0);
case -1061800139: return bem_deonSet_1(bevd_0);
case 402483963: return bem_lastMethodsLinesSet_1(bevd_0);
case 1604865159: return bem_shlibeSet_1(bevd_0);
case 384220308: return bem_notEquals_1(bevd_0);
case -26680707: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 21174112: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1302085205: return bem_smnlecsSet_1(bevd_0);
case -1065247733: return bem_instanceNotEqualSet_1(bevd_0);
case 613864448: return bem_methodBodySet_1(bevd_0);
case 422058995: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1961786723: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 3944149: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1578770471: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 2046340809: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -164817074: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1522479849: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 163536847: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1357111626: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1122611565: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1107804172: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -992241231: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1551759405: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2039832928: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1245060724: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 72722300: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 164309614: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -2144770361: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -293735122: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -2132229737: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1388683713: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 945666872: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2144400846: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1139215441: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1787972875: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -278616183: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
