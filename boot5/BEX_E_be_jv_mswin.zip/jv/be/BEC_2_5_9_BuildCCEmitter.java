package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x28,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28,0x29,0x29,0x2D,0x3E,0x62,0x65,0x6D,0x73,0x5F,0x63,0x63,0x73,0x6E,0x65,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x2A,0x29,0x20,0x28,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x29,0x2D,0x3E,0x62,0x65,0x6D,0x73,0x5F,0x63,0x63,0x69,0x6E,0x65,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x28,0x29,0x29,0x2D,0x3E,0x62,0x65,0x6D,0x73,0x5F,0x63,0x63,0x73,0x6E,0x65,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x63,0x63,0x42,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x2C,0x20,0x67,0x63,0x5F,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 42*/
 else /* Line: 43*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 44*/
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_extends);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
if (bevp_parentConf == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_ta_ph = bevl_begin.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_libNameGet_0();
bevt_15_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_16_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 53*/
 else /* Line: 54*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
} /* Line: 59*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_24_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_25_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_23_ta_ph = bevt_24_ta_ph.bem_has_1(bevt_25_ta_ph);
if (!(bevt_23_ta_ph.bevi_bool))/* Line: 74*/ {
bevt_26_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_27_ta_ph);
} /* Line: 76*/
bevt_28_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_28_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_34_ta_ph);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_36_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_36_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_37_ta_ph);
bevp_heow.bem_write_1(bevt_29_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 85*/ {
bevt_46_ta_ph = (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_47_ta_ph);
} /* Line: 87*/
bevt_50_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_51_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_add_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevt_52_ta_ph);
bevp_heow.bem_write_1(bevt_48_ta_ph);
bevt_55_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_56_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_add_1(bevt_56_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bem_add_1(bevt_57_ta_ph);
bevp_deow.bem_write_1(bevt_53_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_58_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-826207728);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_ta_ph = bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_20_ta_ph = bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 142*/ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 143*/
 else /* Line: 142*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1734684362);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-40889849, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 144*/ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
} /* Line: 145*/
 else /* Line: 142*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1734684362);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(-40889849, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 146*/ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
} /* Line: 147*/
 else /* Line: 148*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 149*/
} /* Line: 142*/
} /* Line: 142*/
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1734684362);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-40889849, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 155*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 157*/
bevt_5_ta_ph = super.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(318820918);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1282336027, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 167*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(1081447814);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 168*/
 else /* Line: 169*/ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 170*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_24_ta_ph = bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1305224443);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(59023781);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 201*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 202*/
 else /* Line: 203*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 204*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 209*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 210*/
 else /* Line: 211*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 212*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 213*/
 else /* Line: 214*/ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
} /* Line: 215*/
} /* Line: 212*/
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_18_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_22_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(490750506);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 235*/
 else /* Line: 236*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(490750506);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 237*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(490750506);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 244*/
 else /* Line: 245*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(490750506);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 246*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_litArgs = bevt_0_ta_ph.bem_add_1(beva_sdec);
bevt_5_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 253*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_ta_ph = bevp_build.bem_libNameGet_0();
bevt_13_ta_ph = beva_newcc.bem_relEmitName_1(bevt_14_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = beva_newcc.bem_relEmitName_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_litArgs);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevl_newCall = bevt_7_ta_ph.bem_add_1(bevt_19_ta_ph);
} /* Line: 254*/
 else /* Line: 255*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = bevp_build.bem_libNameGet_0();
bevt_29_ta_ph = beva_newcc.bem_relEmitName_1(bevt_30_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevl_litArgs);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevl_newCall = bevt_20_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 256*/
return bevl_newCall;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 305*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 305*/ {
return this;
} /* Line: 306*/
 else /* Line: 307*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(520494824);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(-611117261);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 310*/ {
return this;
} /* Line: 313*/
bevp_setOutputTime = bevl_outts;
} /* Line: 316*/
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 322*/
bevt_2_ta_ph = super.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 328*/ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 331*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 336*/ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 344*/
} /* Line: 342*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_7_ta_ph = bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_14_ta_ph = bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 354*/
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_4_ContainerList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_4_ContainerList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevl_beh.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevl_beh.bem_addValue_1(bevt_19_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_23_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_22_ta_ph = bevl_bet.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_20_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_bet.bem_addValue_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (!(bevt_28_ta_ph.bevi_bool))/* Line: 374*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_31_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 376*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 376*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(760457360);
if (bevl_firstmnsyn.bevi_bool)/* Line: 377*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 378*/
 else /* Line: 379*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevl_bet.bem_addValue_1(bevt_33_ta_ph);
} /* Line: 380*/
bevt_35_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_36_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_36_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 382*/
 else /* Line: 376*/ {
break;
} /* Line: 376*/
} /* Line: 376*/
} /* Line: 376*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_bet.bem_addValue_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_38_ta_ph = bevt_39_ta_ph.bem_has_1(bevt_40_ta_ph);
if (!(bevt_38_ta_ph.bevi_bool))/* Line: 387*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
} /* Line: 388*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 392*/ {
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_46_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 394*/ {
bevt_47_ta_ph = bevt_1_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 394*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(760457360);
if (bevl_firstptsyn.bevi_bool)/* Line: 395*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 396*/
 else /* Line: 397*/ {
bevt_48_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevl_bet.bem_addValue_1(bevt_48_ta_ph);
} /* Line: 398*/
bevt_50_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_51_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_51_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 400*/
 else /* Line: 394*/ {
break;
} /* Line: 394*/
} /* Line: 394*/
} /* Line: 394*/
bevt_52_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_55_ta_ph = bevl_bet.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevt_54_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_60_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_61_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevt_59_ta_ph = bevt_60_ta_ph.bem_equals_1(bevt_61_ta_ph);
if (bevt_59_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_64_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_63_ta_ph = bevl_bet.bem_addValue_1(bevt_64_ta_ph);
bevt_65_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_62_ta_ph = bevt_63_ta_ph.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_62_ta_ph.bem_addValue_1(bevt_66_ta_ph);
} /* Line: 409*/
 else /* Line: 410*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_68_ta_ph = bevl_bet.bem_addValue_1(bevt_69_ta_ph);
bevt_70_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bem_addValue_1(bevt_70_ta_ph);
bevt_71_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_67_ta_ph.bem_addValue_1(bevt_71_ta_ph);
} /* Line: 411*/
bevt_72_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_72_ta_ph);
bevt_75_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_74_ta_ph = bevl_bet.bem_addValue_1(bevt_75_ta_ph);
bevt_76_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_73_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevl_bet.bem_addValue_1(bevt_78_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_79_ta_ph = bem_genMark_1(bevt_80_ta_ph);
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_81_ta_ph);
bevt_82_ta_ph = bem_getClassOutput_0();
bevt_82_ta_ph.bem_write_1(bevl_bet);
bevt_83_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_83_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_45_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_56_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 434*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_8_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevt_14_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_23_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 441*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(1576695093);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(1576695093);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 448*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 448*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(760457360);
bevt_35_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(1576695093);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(458752985);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(-539525929);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 454*/
 else /* Line: 448*/ {
break;
} /* Line: 448*/
} /* Line: 448*/
} /* Line: 448*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_deow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_43_ta_ph = bevp_build.bem_paramsGet_0();
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_42_ta_ph = bevt_43_ta_ph.bem_has_1(bevt_44_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 468*/ {
bevt_46_ta_ph = bevp_build.bem_paramsGet_0();
bevt_47_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_45_ta_ph = bevt_46_ta_ph.bem_get_1(bevt_47_ta_ph);
bevt_1_ta_loop = bevt_45_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 470*/ {
bevt_48_ta_ph = bevt_1_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 470*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(760457360);
bevt_49_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_49_ta_ph.bem_fileGet_0();
bevt_51_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bemd_0(1576695093);
bevl_inc = (BEC_2_4_6_TextString) bevt_50_ta_ph.bemd_0(458752985);
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_52_ta_ph.bemd_0(-539525929);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 476*/
 else /* Line: 470*/ {
break;
} /* Line: 470*/
} /* Line: 470*/
} /* Line: 470*/
bevt_54_ta_ph = bevp_build.bem_paramsGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_53_ta_ph = bevt_54_ta_ph.bem_has_1(bevt_55_ta_ph);
if (bevt_53_ta_ph.bevi_bool)/* Line: 479*/ {
bevt_57_ta_ph = bevp_build.bem_paramsGet_0();
bevt_58_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_56_ta_ph = bevt_57_ta_ph.bem_get_1(bevt_58_ta_ph);
bevt_2_ta_loop = bevt_56_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 481*/ {
bevt_59_ta_ph = bevt_2_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 481*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(760457360);
bevt_60_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_60_ta_ph.bem_fileGet_0();
bevt_62_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(1576695093);
bevl_inc = (BEC_2_4_6_TextString) bevt_61_ta_ph.bemd_0(458752985);
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_63_ta_ph.bemd_0(-539525929);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 487*/
 else /* Line: 481*/ {
break;
} /* Line: 481*/
} /* Line: 481*/
} /* Line: 481*/
} /* Line: 479*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 500*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 502*/ {
bevt_8_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 503*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(1576695093);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 509*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 511*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 511*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(760457360);
bevt_19_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(1576695093);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(458752985);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(-539525929);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 517*/
 else /* Line: 511*/ {
break;
} /* Line: 511*/
} /* Line: 511*/
} /* Line: 511*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bem_increment_0();
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 523*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 524*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 524*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(760457360);
bevt_31_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(1576695093);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(458752985);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(-539525929);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 529*/
 else /* Line: 524*/ {
break;
} /* Line: 524*/
} /* Line: 524*/
} /* Line: 524*/
} /* Line: 523*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 547*/ {
bevl_mh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_5_ta_ph = bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 550*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 571*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_4_ta_ph = beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 572*/
 else /* Line: 571*/ {
bevt_8_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_7_ta_ph = bevt_8_ta_ph.bem_has_1(bevt_9_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 573*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_11_ta_ph = beva_sdec.bem_addValue_1(bevt_12_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(beva_belsName);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_10_ta_ph.bem_addValue_1(bevt_13_ta_ph);
} /* Line: 574*/
} /* Line: 571*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(-1991014770);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 586*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(1833302716);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 586*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(760457360);
if (bevl_first.bevi_bool)/* Line: 587*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 588*/
 else /* Line: 589*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 590*/
bevt_9_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 592*/
 else /* Line: 586*/ {
break;
} /* Line: 586*/
} /* Line: 586*/
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
bevt_1_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_ta_ph.bem_relEmitName_1(bevt_2_ta_ph);
bevt_4_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-826207728);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_ta_ph = bem_overrideMtdDecGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevl_oname);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_20_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_19_ta_ph.bevi_bool)/* Line: 633*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_ta_ph, bevl_asnr);
} /* Line: 634*/
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevl_asnr);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_28_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_29_ta_ph);
bevt_28_ta_ph.bem_addValue_1(bevp_nl);
bevt_37_ta_ph = bem_overrideMtdDecGet_0();
bevt_36_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevl_oname);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_ta_ph = bevt_31_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_30_ta_ph.bem_addValue_1(bevp_nl);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_44_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevl_stinst);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_47_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_48_ta_ph);
bevt_47_ta_ph.bem_addValue_1(bevp_nl);
bevt_55_ta_ph = bem_overrideMtdDecGet_0();
bevt_54_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_55_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_62_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(324268778);
if (bevt_61_ta_ph == null) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 653*/ {
bevt_65_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bemd_0(324268778);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_1(-40889849, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 653*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 653*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 653*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_66_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_67_ta_ph);
bevt_66_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 654*/
 else /* Line: 655*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_68_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_69_ta_ph);
bevt_68_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 656*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_70_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_71_ta_ph);
bevt_70_ta_ph.bem_addValue_1(bevp_nl);
bevt_78_ta_ph = bem_overrideMtdDecGet_0();
bevt_77_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_76_ta_ph = bevt_77_ta_ph.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_ta_ph = bevt_73_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_72_ta_ph.bem_addValue_1(bevp_nl);
bevt_84_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_83_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_85_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_89_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_90_ta_ph);
bevt_91_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_88_ta_ph = bevt_89_ta_ph.bem_addValue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_87_ta_ph = bevt_88_ta_ph.bem_addValue_1(bevt_92_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_95_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_96_ta_ph);
bevt_94_ta_ph = bevt_95_ta_ph.bem_addValue_1(bevl_tinst);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_93_ta_ph = bevt_94_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_98_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_99_ta_ph);
bevt_98_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_headExtGetDirect_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadersGetDirect_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public final BEC_2_4_6_TextString bem_deonGetDirect_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public final BEC_2_4_6_TextString bem_heonGetDirect_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 21, 22, 23, 27, 29, 30, 31, 32, 33, 37, 41, 41, 42, 42, 42, 44, 44, 46, 46, 46, 46, 46, 46, 48, 48, 49, 49, 51, 51, 53, 53, 53, 53, 53, 53, 53, 55, 55, 57, 57, 59, 59, 62, 62, 64, 64, 66, 68, 70, 72, 74, 74, 74, 75, 75, 76, 76, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 85, 86, 86, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 91, 91, 91, 91, 93, 93, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 100, 100, 100, 104, 106, 107, 108, 108, 109, 113, 113, 117, 117, 121, 121, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 128, 130, 130, 130, 130, 130, 130, 132, 132, 132, 132, 132, 132, 132, 132, 132, 132, 134, 136, 136, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 146, 146, 146, 146, 147, 149, 149, 151, 155, 155, 155, 155, 156, 156, 157, 159, 159, 163, 163, 163, 163, 163, 163, 163, 163, 167, 167, 167, 167, 168, 168, 168, 170, 176, 176, 176, 176, 176, 178, 178, 178, 178, 178, 178, 178, 178, 180, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 188, 193, 193, 193, 194, 195, 195, 195, 195, 195, 195, 197, 197, 197, 197, 197, 197, 197, 197, 197, 197, 201, 201, 201, 202, 202, 202, 202, 202, 204, 204, 204, 204, 204, 204, 204, 209, 209, 210, 212, 212, 212, 213, 215, 218, 218, 218, 218, 218, 218, 218, 218, 223, 223, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 228, 228, 228, 228, 228, 228, 228, 228, 228, 230, 230, 230, 234, 234, 234, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 239, 243, 243, 243, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 252, 252, 252, 252, 252, 253, 253, 253, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 258, 263, 264, 265, 265, 266, 272, 272, 272, 272, 276, 276, 280, 280, 285, 285, 289, 289, 293, 293, 297, 297, 297, 304, 305, 0, 305, 305, 305, 305, 305, 0, 0, 306, 308, 308, 308, 309, 309, 309, 310, 313, 316, 321, 322, 322, 324, 324, 328, 329, 330, 330, 331, 336, 338, 339, 339, 340, 341, 342, 342, 343, 343, 343, 344, 350, 351, 351, 351, 352, 352, 352, 352, 352, 352, 352, 352, 352, 353, 353, 353, 353, 354, 354, 354, 356, 360, 360, 360, 360, 360, 360, 361, 362, 362, 362, 362, 362, 362, 363, 363, 364, 364, 364, 364, 365, 365, 366, 366, 367, 367, 368, 368, 369, 371, 372, 372, 372, 372, 372, 372, 372, 372, 373, 373, 374, 374, 374, 375, 376, 376, 0, 376, 376, 378, 380, 380, 382, 382, 382, 382, 385, 385, 387, 387, 387, 388, 388, 391, 391, 392, 392, 392, 393, 394, 394, 0, 394, 394, 396, 398, 398, 400, 400, 400, 400, 403, 403, 405, 405, 407, 407, 407, 407, 407, 407, 408, 408, 408, 409, 409, 409, 409, 409, 409, 411, 411, 411, 411, 411, 411, 413, 413, 415, 415, 415, 415, 415, 415, 416, 416, 417, 417, 417, 418, 418, 421, 421, 422, 422, 434, 434, 435, 436, 436, 436, 436, 436, 436, 436, 437, 437, 437, 437, 437, 437, 437, 438, 438, 439, 439, 440, 440, 440, 440, 440, 441, 441, 441, 443, 443, 443, 444, 444, 444, 446, 446, 446, 448, 448, 448, 448, 0, 448, 448, 450, 450, 451, 451, 451, 452, 452, 454, 458, 458, 461, 461, 462, 462, 468, 468, 468, 470, 470, 470, 470, 0, 470, 470, 472, 472, 473, 473, 473, 474, 474, 476, 479, 479, 479, 481, 481, 481, 481, 0, 481, 481, 483, 483, 484, 484, 484, 485, 485, 487, 494, 495, 500, 500, 501, 502, 502, 502, 502, 502, 503, 503, 503, 505, 505, 505, 507, 507, 509, 509, 509, 511, 511, 511, 511, 0, 511, 511, 513, 513, 514, 514, 514, 515, 515, 517, 521, 521, 522, 523, 523, 523, 524, 524, 524, 524, 0, 524, 524, 525, 525, 526, 526, 526, 527, 527, 528, 528, 529, 535, 540, 541, 543, 543, 545, 545, 547, 547, 547, 548, 549, 549, 549, 550, 553, 554, 559, 559, 563, 563, 567, 567, 571, 571, 571, 572, 572, 572, 572, 572, 573, 573, 573, 574, 574, 574, 574, 574, 580, 580, 581, 583, 583, 583, 583, 585, 586, 0, 586, 586, 588, 590, 590, 592, 592, 592, 592, 592, 592, 596, 596, 596, 601, 603, 603, 603, 603, 603, 605, 605, 605, 605, 605, 605, 605, 605, 605, 605, 605, 607, 611, 611, 612, 612, 612, 612, 613, 617, 617, 618, 618, 618, 618, 619, 619, 619, 619, 623, 623, 623, 627, 627, 627, 628, 628, 628, 629, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 631, 632, 633, 633, 634, 634, 637, 637, 637, 637, 637, 637, 637, 639, 639, 639, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 642, 647, 647, 647, 647, 647, 647, 650, 650, 650, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 653, 653, 653, 653, 0, 653, 653, 653, 0, 0, 654, 654, 654, 656, 656, 656, 658, 659, 662, 662, 662, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 665, 665, 665, 667, 667, 667, 669, 671, 671, 671, 671, 671, 671, 671, 673, 673, 673, 673, 673, 673, 675, 675, 675, 681, 681, 681, 681, 681, 682, 682, 682, 682, 682, 684, 689, 689, 690, 690, 690, 690, 691, 691, 691, 691, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 188, 253, 258, 259, 260, 261, 264, 265, 267, 268, 269, 270, 271, 272, 273, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 292, 293, 294, 295, 296, 297, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 311, 312, 313, 314, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 342, 343, 344, 345, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 425, 426, 427, 428, 429, 430, 434, 435, 439, 440, 444, 445, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 524, 525, 526, 531, 532, 535, 536, 537, 538, 540, 543, 544, 545, 546, 548, 551, 552, 556, 566, 567, 568, 569, 571, 572, 573, 575, 576, 586, 587, 588, 589, 590, 591, 592, 593, 603, 604, 605, 606, 608, 609, 610, 613, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 750, 751, 756, 757, 758, 759, 760, 761, 764, 765, 766, 767, 768, 769, 770, 788, 789, 791, 794, 795, 796, 798, 801, 804, 805, 806, 807, 808, 809, 810, 811, 815, 816, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 907, 908, 909, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 946, 983, 984, 985, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1022, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1100, 1105, 1106, 1107, 1108, 1109, 1116, 1117, 1118, 1119, 1123, 1124, 1128, 1129, 1133, 1134, 1138, 1139, 1143, 1144, 1149, 1150, 1151, 1167, 1168, 1170, 1173, 1174, 1175, 1176, 1181, 1182, 1185, 1189, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1200, 1202, 1210, 1212, 1213, 1215, 1216, 1222, 1224, 1225, 1226, 1227, 1238, 1240, 1241, 1242, 1243, 1244, 1245, 1250, 1251, 1252, 1253, 1254, 1277, 1278, 1279, 1280, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1294, 1295, 1296, 1297, 1299, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1435, 1436, 1437, 1437, 1440, 1442, 1444, 1447, 1448, 1450, 1451, 1452, 1453, 1460, 1461, 1462, 1463, 1464, 1466, 1467, 1469, 1470, 1471, 1472, 1473, 1475, 1476, 1477, 1477, 1480, 1482, 1484, 1487, 1488, 1490, 1491, 1492, 1493, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1514, 1515, 1516, 1517, 1518, 1519, 1522, 1523, 1524, 1525, 1526, 1527, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1619, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1652, 1653, 1654, 1655, 1657, 1658, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1667, 1668, 1669, 1670, 1670, 1673, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1690, 1691, 1692, 1693, 1694, 1695, 1696, 1697, 1698, 1700, 1701, 1702, 1703, 1703, 1706, 1708, 1709, 1710, 1711, 1712, 1713, 1714, 1715, 1716, 1723, 1724, 1725, 1727, 1728, 1729, 1730, 1730, 1733, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1754, 1755, 1798, 1803, 1804, 1805, 1806, 1807, 1808, 1813, 1814, 1815, 1816, 1818, 1819, 1820, 1821, 1822, 1823, 1824, 1825, 1827, 1828, 1829, 1830, 1830, 1833, 1835, 1836, 1837, 1838, 1839, 1840, 1841, 1842, 1843, 1850, 1851, 1852, 1853, 1854, 1855, 1857, 1858, 1859, 1860, 1860, 1863, 1865, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1883, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1904, 1905, 1906, 1907, 1908, 1910, 1911, 1916, 1917, 1921, 1922, 1927, 1928, 1946, 1947, 1948, 1950, 1951, 1952, 1953, 1954, 1957, 1958, 1959, 1961, 1962, 1963, 1964, 1965, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1997, 2000, 2002, 2004, 2007, 2008, 2010, 2011, 2012, 2013, 2014, 2015, 2021, 2022, 2023, 2043, 2044, 2045, 2046, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2060, 2069, 2070, 2071, 2072, 2073, 2074, 2075, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2101, 2102, 2103, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2237, 2238, 2240, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2284, 2285, 2286, 2291, 2292, 2295, 2296, 2297, 2299, 2302, 2306, 2307, 2308, 2311, 2312, 2313, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2343, 2344, 2345, 2346, 2347, 2348, 2349, 2350, 2351, 2352, 2353, 2354, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398, 2401, 2404, 2407, 2411, 2415, 2418, 2421, 2425, 2429, 2432, 2435, 2439, 2443, 2446, 2449, 2453, 2457, 2460, 2463, 2467, 2471, 2474, 2477, 2481, 2485, 2488, 2491, 2495, 2499, 2502, 2505, 2509, 2513, 2516, 2519, 2523, 2527, 2530, 2533, 2537, 2541, 2544, 2547, 2551};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 173
new 0 17 173
assign 1 18 174
new 0 18 174
assign 1 19 175
new 0 19 175
assign 1 21 176
new 0 21 176
assign 1 22 177
new 0 22 177
assign 1 23 178
new 0 23 178
new 1 27 179
assign 1 29 180
new 0 29 180
assign 1 30 181
new 0 30 181
assign 1 31 182
new 0 31 182
assign 1 32 183
new 0 32 183
assign 1 33 184
new 0 33 184
addValue 1 37 188
assign 1 41 253
def 1 41 258
assign 1 42 259
libNameGet 0 42 259
assign 1 42 260
relEmitName 1 42 260
assign 1 42 261
extend 1 42 261
assign 1 44 264
new 0 44 264
assign 1 44 265
extend 1 44 265
assign 1 46 267
new 0 46 267
assign 1 46 268
emitNameGet 0 46 268
assign 1 46 269
addValue 1 46 269
assign 1 46 270
addValue 1 46 270
assign 1 46 271
new 0 46 271
assign 1 46 272
addValue 1 46 272
assign 1 48 273
def 1 48 278
assign 1 49 279
new 0 49 279
addValue 1 49 280
assign 1 51 281
new 0 51 281
addValue 1 51 282
assign 1 53 283
new 0 53 283
assign 1 53 284
addValue 1 53 284
assign 1 53 285
libNameGet 0 53 285
assign 1 53 286
relEmitName 1 53 286
assign 1 53 287
addValue 1 53 287
assign 1 53 288
new 0 53 288
addValue 1 53 289
assign 1 55 292
new 0 55 292
addValue 1 55 293
assign 1 57 294
new 0 57 294
addValue 1 57 295
assign 1 59 296
new 0 59 296
addValue 1 59 297
assign 1 62 299
new 0 62 299
addValue 1 62 300
assign 1 64 301
new 0 64 301
addValue 1 64 302
write 1 66 303
write 1 68 304
write 1 70 305
clear 0 72 306
assign 1 74 307
emitChecksGet 0 74 307
assign 1 74 308
new 0 74 308
assign 1 74 309
has 1 74 309
assign 1 75 311
new 0 75 311
write 1 75 312
assign 1 76 313
new 0 76 313
write 1 76 314
assign 1 78 316
new 0 78 316
write 1 78 317
assign 1 79 318
new 0 79 318
assign 1 79 319
emitNameGet 0 79 319
assign 1 79 320
add 1 79 320
assign 1 79 321
new 0 79 321
assign 1 79 322
add 1 79 322
assign 1 79 323
getHeaderInitialInst 1 79 323
assign 1 79 324
add 1 79 324
assign 1 79 325
new 0 79 325
assign 1 79 326
add 1 79 326
write 1 79 327
assign 1 80 328
new 0 80 328
write 1 80 329
assign 1 81 330
new 0 81 330
write 1 81 331
assign 1 82 332
new 0 82 332
write 1 82 333
assign 1 83 334
new 0 83 334
write 1 83 335
assign 1 84 336
new 0 84 336
write 1 84 337
assign 1 85 338
emitChecksGet 0 85 338
assign 1 85 339
new 0 85 339
assign 1 85 340
has 1 85 340
assign 1 86 342
new 0 86 342
write 1 86 343
assign 1 87 344
new 0 87 344
write 1 87 345
assign 1 89 347
new 0 89 347
assign 1 89 348
emitNameGet 0 89 348
assign 1 89 349
add 1 89 349
assign 1 89 350
new 0 89 350
assign 1 89 351
add 1 89 351
write 1 89 352
assign 1 91 353
new 0 91 353
assign 1 91 354
emitNameGet 0 91 354
assign 1 91 355
add 1 91 355
assign 1 91 356
new 0 91 356
assign 1 91 357
add 1 91 357
write 1 91 358
assign 1 93 359
new 0 93 359
return 1 93 360
assign 1 97 390
overrideMtdDecGet 0 97 390
assign 1 97 391
addValue 1 97 391
assign 1 97 392
getClassConfig 1 97 392
assign 1 97 393
libNameGet 0 97 393
assign 1 97 394
relEmitName 1 97 394
assign 1 97 395
addValue 1 97 395
assign 1 97 396
new 0 97 396
assign 1 97 397
addValue 1 97 397
assign 1 97 398
emitNameGet 0 97 398
assign 1 97 399
addValue 1 97 399
assign 1 97 400
new 0 97 400
assign 1 97 401
addValue 1 97 401
assign 1 97 402
addValue 1 97 402
assign 1 97 403
new 0 97 403
assign 1 97 404
addValue 1 97 404
addValue 1 97 405
assign 1 98 406
new 0 98 406
assign 1 98 407
addValue 1 98 407
assign 1 98 408
heldGet 0 98 408
assign 1 98 409
namepathGet 0 98 409
assign 1 98 410
getClassConfig 1 98 410
assign 1 98 411
libNameGet 0 98 411
assign 1 98 412
relEmitName 1 98 412
assign 1 98 413
addValue 1 98 413
assign 1 98 414
new 0 98 414
assign 1 98 415
addValue 1 98 415
addValue 1 98 416
assign 1 100 417
new 0 100 417
assign 1 100 418
addValue 1 100 418
addValue 1 100 419
assign 1 104 425
new 0 104 425
write 1 106 426
clear 0 107 427
assign 1 108 428
new 0 108 428
write 1 108 429
return 1 109 430
assign 1 113 434
new 0 113 434
return 1 113 435
assign 1 117 439
new 0 117 439
return 1 117 440
assign 1 121 444
new 0 121 444
return 1 121 445
assign 1 126 475
addValue 1 126 475
assign 1 126 476
libNameGet 0 126 476
assign 1 126 477
relEmitName 1 126 477
assign 1 126 478
addValue 1 126 478
assign 1 126 479
new 0 126 479
assign 1 126 480
addValue 1 126 480
assign 1 126 481
emitNameGet 0 126 481
assign 1 126 482
addValue 1 126 482
assign 1 126 483
new 0 126 483
assign 1 126 484
addValue 1 126 484
assign 1 126 485
addValue 1 126 485
assign 1 126 486
new 0 126 486
addValue 1 126 487
addValue 1 128 488
assign 1 130 489
new 0 130 489
assign 1 130 490
addValue 1 130 490
assign 1 130 491
addValue 1 130 491
assign 1 130 492
new 0 130 492
assign 1 130 493
addValue 1 130 493
addValue 1 130 494
assign 1 132 495
new 0 132 495
assign 1 132 496
addValue 1 132 496
assign 1 132 497
libNameGet 0 132 497
assign 1 132 498
relEmitName 1 132 498
assign 1 132 499
addValue 1 132 499
assign 1 132 500
new 0 132 500
assign 1 132 501
addValue 1 132 501
assign 1 132 502
addValue 1 132 502
assign 1 132 503
new 0 132 503
addValue 1 132 504
addValue 1 134 505
assign 1 136 506
new 0 136 506
addValue 1 136 507
assign 1 142 524
typenameGet 0 142 524
assign 1 142 525
NULLGet 0 142 525
assign 1 142 526
equals 1 142 531
assign 1 143 532
new 0 143 532
assign 1 144 535
heldGet 0 144 535
assign 1 144 536
nameGet 0 144 536
assign 1 144 537
new 0 144 537
assign 1 144 538
equals 1 144 538
assign 1 145 540
new 0 145 540
assign 1 146 543
heldGet 0 146 543
assign 1 146 544
nameGet 0 146 544
assign 1 146 545
new 0 146 545
assign 1 146 546
equals 1 146 546
assign 1 147 548
new 0 147 548
assign 1 149 551
heldGet 0 149 551
assign 1 149 552
nameForVar 1 149 552
return 1 151 556
assign 1 155 566
heldGet 0 155 566
assign 1 155 567
nameGet 0 155 567
assign 1 155 568
new 0 155 568
assign 1 155 569
equals 1 155 569
assign 1 156 571
new 0 156 571
assign 1 156 572
add 1 156 572
return 1 157 573
assign 1 159 575
formCallTarg 1 159 575
return 1 159 576
assign 1 163 586
new 0 163 586
assign 1 163 587
addValue 1 163 587
assign 1 163 588
secondGet 0 163 588
assign 1 163 589
formTarg 1 163 589
assign 1 163 590
addValue 1 163 590
assign 1 163 591
new 0 163 591
assign 1 163 592
addValue 1 163 592
addValue 1 163 593
assign 1 167 603
heldGet 0 167 603
assign 1 167 604
langsGet 0 167 604
assign 1 167 605
new 0 167 605
assign 1 167 606
has 1 167 606
assign 1 168 608
heldGet 0 168 608
assign 1 168 609
textGet 0 168 609
addValue 1 168 610
handleClassEmit 1 170 613
assign 1 176 655
new 0 176 655
assign 1 176 656
emitNameGet 0 176 656
assign 1 176 657
add 1 176 657
assign 1 176 658
new 0 176 658
assign 1 176 659
add 1 176 659
assign 1 178 660
new 0 178 660
assign 1 178 661
typeEmitNameGet 0 178 661
assign 1 178 662
add 1 178 662
assign 1 178 663
new 0 178 663
assign 1 178 664
add 1 178 664
assign 1 178 665
add 1 178 665
assign 1 178 666
new 0 178 666
assign 1 178 667
add 1 178 667
addClassHeader 1 180 668
assign 1 182 669
new 0 182 669
assign 1 184 670
typeEmitNameGet 0 184 670
assign 1 184 671
addValue 1 184 671
assign 1 184 672
new 0 184 672
assign 1 184 673
addValue 1 184 673
assign 1 184 674
emitNameGet 0 184 674
assign 1 184 675
addValue 1 184 675
assign 1 184 676
new 0 184 676
assign 1 184 677
addValue 1 184 677
assign 1 184 678
addValue 1 184 678
assign 1 184 679
new 0 184 679
addValue 1 184 680
assign 1 186 681
new 0 186 681
assign 1 186 682
addValue 1 186 682
assign 1 186 683
typeEmitNameGet 0 186 683
assign 1 186 684
addValue 1 186 684
assign 1 186 685
new 0 186 685
assign 1 186 686
addValue 1 186 686
assign 1 186 687
emitNameGet 0 186 687
assign 1 186 688
addValue 1 186 688
assign 1 186 689
new 0 186 689
assign 1 186 690
emitNameGet 0 186 690
assign 1 186 691
add 1 186 691
assign 1 186 692
new 0 186 692
assign 1 186 693
add 1 186 693
addValue 1 186 694
return 1 188 695
assign 1 193 715
new 0 193 715
assign 1 193 716
toString 0 193 716
assign 1 193 717
add 1 193 717
incrementValue 0 194 718
assign 1 195 719
new 0 195 719
assign 1 195 720
addValue 1 195 720
assign 1 195 721
addValue 1 195 721
assign 1 195 722
new 0 195 722
assign 1 195 723
addValue 1 195 723
addValue 1 195 724
assign 1 197 725
containedGet 0 197 725
assign 1 197 726
firstGet 0 197 726
assign 1 197 727
containedGet 0 197 727
assign 1 197 728
firstGet 0 197 728
assign 1 197 729
new 0 197 729
assign 1 197 730
add 1 197 730
assign 1 197 731
new 0 197 731
assign 1 197 732
add 1 197 732
assign 1 197 733
finalAssign 4 197 733
addValue 1 197 734
assign 1 201 750
isTypedGet 0 201 750
assign 1 201 751
not 0 201 756
assign 1 202 757
libNameGet 0 202 757
assign 1 202 758
relEmitName 1 202 758
assign 1 202 759
addValue 1 202 759
assign 1 202 760
new 0 202 760
addValue 1 202 761
assign 1 204 764
namepathGet 0 204 764
assign 1 204 765
getClassConfig 1 204 765
assign 1 204 766
libNameGet 0 204 766
assign 1 204 767
relEmitName 1 204 767
assign 1 204 768
addValue 1 204 768
assign 1 204 769
new 0 204 769
addValue 1 204 770
assign 1 209 788
new 0 209 788
assign 1 209 789
equals 1 209 789
assign 1 210 791
new 0 210 791
assign 1 212 794
emitChecksGet 0 212 794
assign 1 212 795
new 0 212 795
assign 1 212 796
has 1 212 796
assign 1 213 798
new 0 213 798
assign 1 215 801
new 0 215 801
assign 1 218 804
new 0 218 804
assign 1 218 805
add 1 218 805
assign 1 218 806
libNameGet 0 218 806
assign 1 218 807
relEmitName 1 218 807
assign 1 218 808
add 1 218 808
assign 1 218 809
new 0 218 809
assign 1 218 810
add 1 218 810
return 1 218 811
assign 1 223 815
new 0 223 815
return 1 223 816
assign 1 227 843
overrideMtdDecGet 0 227 843
assign 1 227 844
addValue 1 227 844
assign 1 227 845
new 0 227 845
assign 1 227 846
addValue 1 227 846
assign 1 227 847
emitNameGet 0 227 847
assign 1 227 848
addValue 1 227 848
assign 1 227 849
new 0 227 849
assign 1 227 850
addValue 1 227 850
assign 1 227 851
addValue 1 227 851
assign 1 227 852
new 0 227 852
assign 1 227 853
addValue 1 227 853
assign 1 227 854
addValue 1 227 854
assign 1 227 855
new 0 227 855
assign 1 227 856
addValue 1 227 856
addValue 1 227 857
assign 1 228 858
new 0 228 858
assign 1 228 859
addValue 1 228 859
assign 1 228 860
addValue 1 228 860
assign 1 228 861
new 0 228 861
assign 1 228 862
addValue 1 228 862
assign 1 228 863
addValue 1 228 863
assign 1 228 864
new 0 228 864
assign 1 228 865
addValue 1 228 865
addValue 1 228 866
assign 1 230 867
new 0 230 867
assign 1 230 868
addValue 1 230 868
addValue 1 230 869
assign 1 234 907
emitChecksGet 0 234 907
assign 1 234 908
new 0 234 908
assign 1 234 909
has 1 234 909
assign 1 235 911
new 0 235 911
assign 1 235 912
libNameGet 0 235 912
assign 1 235 913
relEmitName 1 235 913
assign 1 235 914
add 1 235 914
assign 1 235 915
new 0 235 915
assign 1 235 916
add 1 235 916
assign 1 235 917
libNameGet 0 235 917
assign 1 235 918
relEmitName 1 235 918
assign 1 235 919
add 1 235 919
assign 1 235 920
new 0 235 920
assign 1 235 921
add 1 235 921
assign 1 235 922
heldGet 0 235 922
assign 1 235 923
literalValueGet 0 235 923
assign 1 235 924
add 1 235 924
assign 1 235 925
new 0 235 925
assign 1 235 926
add 1 235 926
assign 1 237 929
new 0 237 929
assign 1 237 930
libNameGet 0 237 930
assign 1 237 931
relEmitName 1 237 931
assign 1 237 932
add 1 237 932
assign 1 237 933
new 0 237 933
assign 1 237 934
add 1 237 934
assign 1 237 935
libNameGet 0 237 935
assign 1 237 936
relEmitName 1 237 936
assign 1 237 937
add 1 237 937
assign 1 237 938
new 0 237 938
assign 1 237 939
add 1 237 939
assign 1 237 940
heldGet 0 237 940
assign 1 237 941
literalValueGet 0 237 941
assign 1 237 942
add 1 237 942
assign 1 237 943
new 0 237 943
assign 1 237 944
add 1 237 944
return 1 239 946
assign 1 243 983
emitChecksGet 0 243 983
assign 1 243 984
new 0 243 984
assign 1 243 985
has 1 243 985
assign 1 244 987
new 0 244 987
assign 1 244 988
libNameGet 0 244 988
assign 1 244 989
relEmitName 1 244 989
assign 1 244 990
add 1 244 990
assign 1 244 991
new 0 244 991
assign 1 244 992
add 1 244 992
assign 1 244 993
libNameGet 0 244 993
assign 1 244 994
relEmitName 1 244 994
assign 1 244 995
add 1 244 995
assign 1 244 996
new 0 244 996
assign 1 244 997
add 1 244 997
assign 1 244 998
heldGet 0 244 998
assign 1 244 999
literalValueGet 0 244 999
assign 1 244 1000
add 1 244 1000
assign 1 244 1001
new 0 244 1001
assign 1 244 1002
add 1 244 1002
assign 1 246 1005
new 0 246 1005
assign 1 246 1006
libNameGet 0 246 1006
assign 1 246 1007
relEmitName 1 246 1007
assign 1 246 1008
add 1 246 1008
assign 1 246 1009
new 0 246 1009
assign 1 246 1010
add 1 246 1010
assign 1 246 1011
libNameGet 0 246 1011
assign 1 246 1012
relEmitName 1 246 1012
assign 1 246 1013
add 1 246 1013
assign 1 246 1014
new 0 246 1014
assign 1 246 1015
add 1 246 1015
assign 1 246 1016
heldGet 0 246 1016
assign 1 246 1017
literalValueGet 0 246 1017
assign 1 246 1018
add 1 246 1018
assign 1 246 1019
new 0 246 1019
assign 1 246 1020
add 1 246 1020
return 1 248 1022
assign 1 252 1060
new 0 252 1060
assign 1 252 1061
add 1 252 1061
assign 1 252 1062
new 0 252 1062
assign 1 252 1063
add 1 252 1063
assign 1 252 1064
add 1 252 1064
assign 1 253 1065
emitChecksGet 0 253 1065
assign 1 253 1066
new 0 253 1066
assign 1 253 1067
has 1 253 1067
assign 1 254 1069
new 0 254 1069
assign 1 254 1070
libNameGet 0 254 1070
assign 1 254 1071
relEmitName 1 254 1071
assign 1 254 1072
add 1 254 1072
assign 1 254 1073
new 0 254 1073
assign 1 254 1074
add 1 254 1074
assign 1 254 1075
libNameGet 0 254 1075
assign 1 254 1076
relEmitName 1 254 1076
assign 1 254 1077
add 1 254 1077
assign 1 254 1078
new 0 254 1078
assign 1 254 1079
add 1 254 1079
assign 1 254 1080
add 1 254 1080
assign 1 254 1081
new 0 254 1081
assign 1 254 1082
add 1 254 1082
assign 1 256 1085
new 0 256 1085
assign 1 256 1086
libNameGet 0 256 1086
assign 1 256 1087
relEmitName 1 256 1087
assign 1 256 1088
add 1 256 1088
assign 1 256 1089
new 0 256 1089
assign 1 256 1090
add 1 256 1090
assign 1 256 1091
libNameGet 0 256 1091
assign 1 256 1092
relEmitName 1 256 1092
assign 1 256 1093
add 1 256 1093
assign 1 256 1094
new 0 256 1094
assign 1 256 1095
add 1 256 1095
assign 1 256 1096
add 1 256 1096
assign 1 256 1097
new 0 256 1097
assign 1 256 1098
add 1 256 1098
return 1 258 1100
getCode 2 263 1105
assign 1 264 1106
toHexString 1 264 1106
assign 1 265 1107
new 0 265 1107
addValue 1 265 1108
addValue 1 266 1109
assign 1 272 1116
new 0 272 1116
assign 1 272 1117
add 1 272 1117
assign 1 272 1118
add 1 272 1118
return 1 272 1119
assign 1 276 1123
new 0 276 1123
return 1 276 1124
assign 1 280 1128
new 0 280 1128
return 1 280 1129
assign 1 285 1133
new 0 285 1133
return 1 285 1134
assign 1 289 1138
new 0 289 1138
return 1 289 1139
assign 1 293 1143
new 0 293 1143
return 1 293 1144
assign 1 297 1149
new 0 297 1149
assign 1 297 1150
add 1 297 1150
return 1 297 1151
assign 1 304 1167
assign 1 305 1168
singleCCGet 0 305 1168
assign 1 0 1170
assign 1 305 1173
classPathGet 0 305 1173
assign 1 305 1174
fileGet 0 305 1174
assign 1 305 1175
existsGet 0 305 1175
assign 1 305 1176
not 0 305 1181
assign 1 0 1182
assign 1 0 1185
return 1 306 1189
assign 1 308 1192
classPathGet 0 308 1192
assign 1 308 1193
fileGet 0 308 1193
assign 1 308 1194
lastUpdatedGet 0 308 1194
assign 1 309 1195
fromFileGet 0 309 1195
assign 1 309 1196
fileGet 0 309 1196
assign 1 309 1197
lastUpdatedGet 0 309 1197
assign 1 310 1198
greater 1 310 1198
return 1 313 1200
assign 1 316 1202
assign 1 321 1210
singleCCGet 0 321 1210
assign 1 322 1212
getLibOutput 0 322 1212
return 1 322 1213
assign 1 324 1215
getClassOutput 0 324 1215
return 1 324 1216
assign 1 328 1222
singleCCGet 0 328 1222
assign 1 329 1224
new 0 329 1224
assign 1 330 1225
countLines 1 330 1225
addValue 1 330 1226
write 1 331 1227
assign 1 336 1238
singleCCGet 0 336 1238
assign 1 338 1240
new 0 338 1240
assign 1 339 1241
countLines 1 339 1241
addValue 1 339 1242
write 1 340 1243
close 0 341 1244
assign 1 342 1245
def 1 342 1250
assign 1 343 1251
pathGet 0 343 1251
assign 1 343 1252
fileGet 0 343 1252
lastUpdatedSet 1 343 1253
assign 1 344 1254
assign 1 350 1277
new 0 350 1277
assign 1 351 1278
emitChecksGet 0 351 1278
assign 1 351 1279
new 0 351 1279
assign 1 351 1280
has 1 351 1280
assign 1 352 1282
new 0 352 1282
assign 1 352 1283
addValue 1 352 1283
assign 1 352 1284
addValue 1 352 1284
assign 1 352 1285
new 0 352 1285
assign 1 352 1286
addValue 1 352 1286
assign 1 352 1287
addValue 1 352 1287
assign 1 352 1288
new 0 352 1288
assign 1 352 1289
addValue 1 352 1289
addValue 1 352 1290
assign 1 353 1291
addValue 1 353 1291
assign 1 353 1292
new 0 353 1292
assign 1 353 1293
addValue 1 353 1293
addValue 1 353 1294
assign 1 354 1295
new 0 354 1295
assign 1 354 1296
addValue 1 354 1296
addValue 1 354 1297
return 1 356 1299
assign 1 360 1392
new 0 360 1392
assign 1 360 1393
typeEmitNameGet 0 360 1393
assign 1 360 1394
add 1 360 1394
assign 1 360 1395
new 0 360 1395
assign 1 360 1396
add 1 360 1396
write 1 360 1397
assign 1 361 1398
new 0 361 1398
assign 1 362 1399
new 0 362 1399
assign 1 362 1400
addValue 1 362 1400
assign 1 362 1401
typeEmitNameGet 0 362 1401
assign 1 362 1402
addValue 1 362 1402
assign 1 362 1403
new 0 362 1403
addValue 1 362 1404
assign 1 363 1405
new 0 363 1405
addValue 1 363 1406
assign 1 364 1407
typeEmitNameGet 0 364 1407
assign 1 364 1408
addValue 1 364 1408
assign 1 364 1409
new 0 364 1409
addValue 1 364 1410
assign 1 365 1411
new 0 365 1411
addValue 1 365 1412
assign 1 366 1413
new 0 366 1413
addValue 1 366 1414
assign 1 367 1415
new 0 367 1415
addValue 1 367 1416
assign 1 368 1417
new 0 368 1417
addValue 1 368 1418
write 1 369 1419
assign 1 371 1420
new 0 371 1420
assign 1 372 1421
typeEmitNameGet 0 372 1421
assign 1 372 1422
addValue 1 372 1422
assign 1 372 1423
new 0 372 1423
assign 1 372 1424
addValue 1 372 1424
assign 1 372 1425
typeEmitNameGet 0 372 1425
assign 1 372 1426
addValue 1 372 1426
assign 1 372 1427
new 0 372 1427
addValue 1 372 1428
assign 1 373 1429
new 0 373 1429
addValue 1 373 1430
assign 1 374 1431
emitChecksGet 0 374 1431
assign 1 374 1432
new 0 374 1432
assign 1 374 1433
has 1 374 1433
assign 1 375 1435
new 0 375 1435
assign 1 376 1436
mtdListGet 0 376 1436
assign 1 376 1437
iteratorGet 0 0 1437
assign 1 376 1440
hasNextGet 0 376 1440
assign 1 376 1442
nextGet 0 376 1442
assign 1 378 1444
new 0 378 1444
assign 1 380 1447
new 0 380 1447
addValue 1 380 1448
assign 1 382 1450
addValue 1 382 1450
assign 1 382 1451
nameGet 0 382 1451
assign 1 382 1452
addValue 1 382 1452
addValue 1 382 1453
assign 1 385 1460
new 0 385 1460
addValue 1 385 1461
assign 1 387 1462
emitChecksGet 0 387 1462
assign 1 387 1463
new 0 387 1463
assign 1 387 1464
has 1 387 1464
assign 1 388 1466
new 0 388 1466
addValue 1 388 1467
assign 1 391 1469
new 0 391 1469
addValue 1 391 1470
assign 1 392 1471
emitChecksGet 0 392 1471
assign 1 392 1472
new 0 392 1472
assign 1 392 1473
has 1 392 1473
assign 1 393 1475
new 0 393 1475
assign 1 394 1476
ptyListGet 0 394 1476
assign 1 394 1477
iteratorGet 0 0 1477
assign 1 394 1480
hasNextGet 0 394 1480
assign 1 394 1482
nextGet 0 394 1482
assign 1 396 1484
new 0 396 1484
assign 1 398 1487
new 0 398 1487
addValue 1 398 1488
assign 1 400 1490
addValue 1 400 1490
assign 1 400 1491
nameGet 0 400 1491
assign 1 400 1492
addValue 1 400 1492
addValue 1 400 1493
assign 1 403 1500
new 0 403 1500
addValue 1 403 1501
assign 1 405 1502
new 0 405 1502
addValue 1 405 1503
assign 1 407 1504
new 0 407 1504
assign 1 407 1505
addValue 1 407 1505
assign 1 407 1506
typeEmitNameGet 0 407 1506
assign 1 407 1507
addValue 1 407 1507
assign 1 407 1508
new 0 407 1508
addValue 1 407 1509
assign 1 408 1510
emitNameGet 0 408 1510
assign 1 408 1511
new 0 408 1511
assign 1 408 1512
equals 1 408 1512
assign 1 409 1514
new 0 409 1514
assign 1 409 1515
addValue 1 409 1515
assign 1 409 1516
emitNameGet 0 409 1516
assign 1 409 1517
addValue 1 409 1517
assign 1 409 1518
new 0 409 1518
addValue 1 409 1519
assign 1 411 1522
new 0 411 1522
assign 1 411 1523
addValue 1 411 1523
assign 1 411 1524
emitNameGet 0 411 1524
assign 1 411 1525
addValue 1 411 1525
assign 1 411 1526
new 0 411 1526
addValue 1 411 1527
assign 1 413 1529
new 0 413 1529
addValue 1 413 1530
assign 1 415 1531
new 0 415 1531
assign 1 415 1532
addValue 1 415 1532
assign 1 415 1533
typeEmitNameGet 0 415 1533
assign 1 415 1534
addValue 1 415 1534
assign 1 415 1535
new 0 415 1535
addValue 1 415 1536
assign 1 416 1537
new 0 416 1537
addValue 1 416 1538
assign 1 417 1539
new 0 417 1539
assign 1 417 1540
genMark 1 417 1540
addValue 1 417 1541
assign 1 418 1542
new 0 418 1542
addValue 1 418 1543
assign 1 421 1544
getClassOutput 0 421 1544
write 1 421 1545
assign 1 422 1546
countLines 1 422 1546
addValue 1 422 1547
assign 1 434 1619
undef 1 434 1624
assign 1 435 1625
libNameGet 0 435 1625
assign 1 436 1626
new 0 436 1626
assign 1 436 1627
sizeGet 0 436 1627
assign 1 436 1628
add 1 436 1628
assign 1 436 1629
new 0 436 1629
assign 1 436 1630
add 1 436 1630
assign 1 436 1631
add 1 436 1631
assign 1 436 1632
add 1 436 1632
assign 1 437 1633
new 0 437 1633
assign 1 437 1634
sizeGet 0 437 1634
assign 1 437 1635
add 1 437 1635
assign 1 437 1636
new 0 437 1636
assign 1 437 1637
add 1 437 1637
assign 1 437 1638
add 1 437 1638
assign 1 437 1639
add 1 437 1639
assign 1 438 1640
parentGet 0 438 1640
assign 1 438 1641
addStep 1 438 1641
assign 1 439 1642
parentGet 0 439 1642
assign 1 439 1643
addStep 1 439 1643
assign 1 440 1644
parentGet 0 440 1644
assign 1 440 1645
fileGet 0 440 1645
assign 1 440 1646
existsGet 0 440 1646
assign 1 440 1647
not 0 440 1652
assign 1 441 1653
parentGet 0 441 1653
assign 1 441 1654
fileGet 0 441 1654
makeDirs 0 441 1655
assign 1 443 1657
fileGet 0 443 1657
assign 1 443 1658
writerGet 0 443 1658
assign 1 443 1659
open 0 443 1659
assign 1 444 1660
fileGet 0 444 1660
assign 1 444 1661
writerGet 0 444 1661
assign 1 444 1662
open 0 444 1662
assign 1 446 1663
paramsGet 0 446 1663
assign 1 446 1664
new 0 446 1664
assign 1 446 1665
has 1 446 1665
assign 1 448 1667
paramsGet 0 448 1667
assign 1 448 1668
new 0 448 1668
assign 1 448 1669
get 1 448 1669
assign 1 448 1670
iteratorGet 0 0 1670
assign 1 448 1673
hasNextGet 0 448 1673
assign 1 448 1675
nextGet 0 448 1675
assign 1 450 1676
apNew 1 450 1676
assign 1 450 1677
fileGet 0 450 1677
assign 1 451 1678
readerGet 0 451 1678
assign 1 451 1679
open 0 451 1679
assign 1 451 1680
readString 0 451 1680
assign 1 452 1681
readerGet 0 452 1681
close 0 452 1682
write 1 454 1683
assign 1 458 1690
new 0 458 1690
write 1 458 1691
assign 1 461 1692
new 0 461 1692
write 1 461 1693
assign 1 462 1694
new 0 462 1694
write 1 462 1695
assign 1 468 1696
paramsGet 0 468 1696
assign 1 468 1697
new 0 468 1697
assign 1 468 1698
has 1 468 1698
assign 1 470 1700
paramsGet 0 470 1700
assign 1 470 1701
new 0 470 1701
assign 1 470 1702
get 1 470 1702
assign 1 470 1703
iteratorGet 0 0 1703
assign 1 470 1706
hasNextGet 0 470 1706
assign 1 470 1708
nextGet 0 470 1708
assign 1 472 1709
apNew 1 472 1709
assign 1 472 1710
fileGet 0 472 1710
assign 1 473 1711
readerGet 0 473 1711
assign 1 473 1712
open 0 473 1712
assign 1 473 1713
readString 0 473 1713
assign 1 474 1714
readerGet 0 474 1714
close 0 474 1715
write 1 476 1716
assign 1 479 1723
paramsGet 0 479 1723
assign 1 479 1724
new 0 479 1724
assign 1 479 1725
has 1 479 1725
assign 1 481 1727
paramsGet 0 481 1727
assign 1 481 1728
new 0 481 1728
assign 1 481 1729
get 1 481 1729
assign 1 481 1730
iteratorGet 0 0 1730
assign 1 481 1733
hasNextGet 0 481 1733
assign 1 481 1735
nextGet 0 481 1735
assign 1 483 1736
apNew 1 483 1736
assign 1 483 1737
fileGet 0 483 1737
assign 1 484 1738
readerGet 0 484 1738
assign 1 484 1739
open 0 484 1739
assign 1 484 1740
readString 0 484 1740
assign 1 485 1741
readerGet 0 485 1741
close 0 485 1742
write 1 487 1743
begin 1 494 1754
prepHeaderOutput 0 495 1755
assign 1 500 1798
undef 1 500 1803
assign 1 501 1804
new 0 501 1804
assign 1 502 1805
parentGet 0 502 1805
assign 1 502 1806
fileGet 0 502 1806
assign 1 502 1807
existsGet 0 502 1807
assign 1 502 1808
not 0 502 1813
assign 1 503 1814
parentGet 0 503 1814
assign 1 503 1815
fileGet 0 503 1815
makeDirs 0 503 1816
assign 1 505 1818
fileGet 0 505 1818
assign 1 505 1819
writerGet 0 505 1819
assign 1 505 1820
open 0 505 1820
assign 1 507 1821
new 0 507 1821
write 1 507 1822
assign 1 509 1823
paramsGet 0 509 1823
assign 1 509 1824
new 0 509 1824
assign 1 509 1825
has 1 509 1825
assign 1 511 1827
paramsGet 0 511 1827
assign 1 511 1828
new 0 511 1828
assign 1 511 1829
get 1 511 1829
assign 1 511 1830
iteratorGet 0 0 1830
assign 1 511 1833
hasNextGet 0 511 1833
assign 1 511 1835
nextGet 0 511 1835
assign 1 513 1836
apNew 1 513 1836
assign 1 513 1837
fileGet 0 513 1837
assign 1 514 1838
readerGet 0 514 1838
assign 1 514 1839
open 0 514 1839
assign 1 514 1840
readString 0 514 1840
assign 1 515 1841
readerGet 0 515 1841
close 0 515 1842
write 1 517 1843
assign 1 521 1850
new 0 521 1850
write 1 521 1851
increment 0 522 1852
assign 1 523 1853
paramsGet 0 523 1853
assign 1 523 1854
new 0 523 1854
assign 1 523 1855
has 1 523 1855
assign 1 524 1857
paramsGet 0 524 1857
assign 1 524 1858
new 0 524 1858
assign 1 524 1859
get 1 524 1859
assign 1 524 1860
iteratorGet 0 0 1860
assign 1 524 1863
hasNextGet 0 524 1863
assign 1 524 1865
nextGet 0 524 1865
assign 1 525 1866
apNew 1 525 1866
assign 1 525 1867
fileGet 0 525 1867
assign 1 526 1868
readerGet 0 526 1868
assign 1 526 1869
open 0 526 1869
assign 1 526 1870
readString 0 526 1870
assign 1 527 1871
readerGet 0 527 1871
close 0 527 1872
assign 1 528 1873
countLines 1 528 1873
addValue 1 528 1874
write 1 529 1875
return 1 535 1883
close 0 540 1894
assign 1 541 1895
assign 1 543 1896
new 0 543 1896
write 1 543 1897
assign 1 545 1898
new 0 545 1898
write 1 545 1899
assign 1 547 1900
emitChecksGet 0 547 1900
assign 1 547 1901
new 0 547 1901
assign 1 547 1902
has 1 547 1902
assign 1 548 1904
new 0 548 1904
assign 1 549 1905
new 0 549 1905
assign 1 549 1906
addValue 1 549 1906
addValue 1 549 1907
write 1 550 1908
close 0 553 1910
close 0 554 1911
assign 1 559 1916
new 0 559 1916
return 1 559 1917
assign 1 563 1921
new 0 563 1921
addValue 1 563 1922
assign 1 567 1927
new 0 567 1927
addValue 1 567 1928
assign 1 571 1946
emitChecksGet 0 571 1946
assign 1 571 1947
new 0 571 1947
assign 1 571 1948
has 1 571 1948
assign 1 572 1950
new 0 572 1950
assign 1 572 1951
addValue 1 572 1951
assign 1 572 1952
addValue 1 572 1952
assign 1 572 1953
new 0 572 1953
addValue 1 572 1954
assign 1 573 1957
emitChecksGet 0 573 1957
assign 1 573 1958
new 0 573 1958
assign 1 573 1959
has 1 573 1959
assign 1 574 1961
new 0 574 1961
assign 1 574 1962
addValue 1 574 1962
assign 1 574 1963
addValue 1 574 1963
assign 1 574 1964
new 0 574 1964
addValue 1 574 1965
assign 1 580 1989
heldGet 0 580 1989
assign 1 580 1990
synGet 0 580 1990
assign 1 581 1991
ptyListGet 0 581 1991
assign 1 583 1992
emitNameGet 0 583 1992
assign 1 583 1993
addValue 1 583 1993
assign 1 583 1994
new 0 583 1994
addValue 1 583 1995
assign 1 585 1996
new 0 585 1996
assign 1 586 1997
iteratorGet 0 0 1997
assign 1 586 2000
hasNextGet 0 586 2000
assign 1 586 2002
nextGet 0 586 2002
assign 1 588 2004
new 0 588 2004
assign 1 590 2007
new 0 590 2007
addValue 1 590 2008
assign 1 592 2010
addValue 1 592 2010
assign 1 592 2011
new 0 592 2011
assign 1 592 2012
addValue 1 592 2012
assign 1 592 2013
nameGet 0 592 2013
assign 1 592 2014
addValue 1 592 2014
addValue 1 592 2015
assign 1 596 2021
new 0 596 2021
assign 1 596 2022
addValue 1 596 2022
addValue 1 596 2023
assign 1 601 2043
new 0 601 2043
assign 1 603 2044
new 0 603 2044
assign 1 603 2045
emitNameGet 0 603 2045
assign 1 603 2046
add 1 603 2046
assign 1 603 2047
new 0 603 2047
assign 1 603 2048
add 1 603 2048
assign 1 605 2049
emitNameGet 0 605 2049
assign 1 605 2050
addValue 1 605 2050
assign 1 605 2051
new 0 605 2051
assign 1 605 2052
addValue 1 605 2052
assign 1 605 2053
emitNameGet 0 605 2053
assign 1 605 2054
addValue 1 605 2054
assign 1 605 2055
new 0 605 2055
assign 1 605 2056
addValue 1 605 2056
assign 1 605 2057
addValue 1 605 2057
assign 1 605 2058
new 0 605 2058
addValue 1 605 2059
return 1 607 2060
assign 1 611 2069
libNameGet 0 611 2069
assign 1 611 2070
relEmitName 1 611 2070
assign 1 612 2071
new 0 612 2071
assign 1 612 2072
add 1 612 2072
assign 1 612 2073
new 0 612 2073
assign 1 612 2074
add 1 612 2074
return 1 613 2075
assign 1 617 2087
libNameGet 0 617 2087
assign 1 617 2088
relEmitName 1 617 2088
assign 1 618 2089
new 0 618 2089
assign 1 618 2090
add 1 618 2090
assign 1 618 2091
new 0 618 2091
assign 1 618 2092
add 1 618 2092
assign 1 619 2093
new 0 619 2093
assign 1 619 2094
add 1 619 2094
assign 1 619 2095
add 1 619 2095
return 1 619 2096
assign 1 623 2101
new 0 623 2101
assign 1 623 2102
add 1 623 2102
return 1 623 2103
assign 1 627 2211
getClassConfig 1 627 2211
assign 1 627 2212
libNameGet 0 627 2212
assign 1 627 2213
relEmitName 1 627 2213
assign 1 628 2214
heldGet 0 628 2214
assign 1 628 2215
namepathGet 0 628 2215
assign 1 628 2216
getClassConfig 1 628 2216
assign 1 629 2217
getInitialInst 1 629 2217
assign 1 631 2218
overrideMtdDecGet 0 631 2218
assign 1 631 2219
addValue 1 631 2219
assign 1 631 2220
new 0 631 2220
assign 1 631 2221
addValue 1 631 2221
assign 1 631 2222
emitNameGet 0 631 2222
assign 1 631 2223
addValue 1 631 2223
assign 1 631 2224
new 0 631 2224
assign 1 631 2225
addValue 1 631 2225
assign 1 631 2226
addValue 1 631 2226
assign 1 631 2227
new 0 631 2227
assign 1 631 2228
addValue 1 631 2228
assign 1 631 2229
addValue 1 631 2229
assign 1 631 2230
new 0 631 2230
assign 1 631 2231
addValue 1 631 2231
addValue 1 631 2232
assign 1 632 2233
new 0 632 2233
assign 1 633 2234
emitNameGet 0 633 2234
assign 1 633 2235
notEquals 1 633 2235
assign 1 634 2237
new 0 634 2237
assign 1 634 2238
formCast 3 634 2238
assign 1 637 2240
addValue 1 637 2240
assign 1 637 2241
new 0 637 2241
assign 1 637 2242
addValue 1 637 2242
assign 1 637 2243
addValue 1 637 2243
assign 1 637 2244
new 0 637 2244
assign 1 637 2245
addValue 1 637 2245
addValue 1 637 2246
assign 1 639 2247
new 0 639 2247
assign 1 639 2248
addValue 1 639 2248
addValue 1 639 2249
assign 1 642 2250
overrideMtdDecGet 0 642 2250
assign 1 642 2251
addValue 1 642 2251
assign 1 642 2252
addValue 1 642 2252
assign 1 642 2253
new 0 642 2253
assign 1 642 2254
addValue 1 642 2254
assign 1 642 2255
emitNameGet 0 642 2255
assign 1 642 2256
addValue 1 642 2256
assign 1 642 2257
new 0 642 2257
assign 1 642 2258
addValue 1 642 2258
assign 1 642 2259
addValue 1 642 2259
assign 1 642 2260
new 0 642 2260
assign 1 642 2261
addValue 1 642 2261
addValue 1 642 2262
assign 1 647 2263
new 0 647 2263
assign 1 647 2264
addValue 1 647 2264
assign 1 647 2265
addValue 1 647 2265
assign 1 647 2266
new 0 647 2266
assign 1 647 2267
addValue 1 647 2267
addValue 1 647 2268
assign 1 650 2269
new 0 650 2269
assign 1 650 2270
addValue 1 650 2270
addValue 1 650 2271
assign 1 652 2272
overrideMtdDecGet 0 652 2272
assign 1 652 2273
addValue 1 652 2273
assign 1 652 2274
new 0 652 2274
assign 1 652 2275
addValue 1 652 2275
assign 1 652 2276
emitNameGet 0 652 2276
assign 1 652 2277
addValue 1 652 2277
assign 1 652 2278
new 0 652 2278
assign 1 652 2279
addValue 1 652 2279
assign 1 652 2280
addValue 1 652 2280
assign 1 652 2281
new 0 652 2281
assign 1 652 2282
addValue 1 652 2282
addValue 1 652 2283
assign 1 653 2284
heldGet 0 653 2284
assign 1 653 2285
extendsGet 0 653 2285
assign 1 653 2286
undef 1 653 2291
assign 1 0 2292
assign 1 653 2295
heldGet 0 653 2295
assign 1 653 2296
extendsGet 0 653 2296
assign 1 653 2297
equals 1 653 2297
assign 1 0 2299
assign 1 0 2302
assign 1 654 2306
new 0 654 2306
assign 1 654 2307
addValue 1 654 2307
addValue 1 654 2308
assign 1 656 2311
new 0 656 2311
assign 1 656 2312
addValue 1 656 2312
addValue 1 656 2313
addValue 1 658 2315
clear 0 659 2316
assign 1 662 2317
new 0 662 2317
assign 1 662 2318
addValue 1 662 2318
addValue 1 662 2319
assign 1 664 2320
overrideMtdDecGet 0 664 2320
assign 1 664 2321
addValue 1 664 2321
assign 1 664 2322
new 0 664 2322
assign 1 664 2323
addValue 1 664 2323
assign 1 664 2324
emitNameGet 0 664 2324
assign 1 664 2325
addValue 1 664 2325
assign 1 664 2326
new 0 664 2326
assign 1 664 2327
addValue 1 664 2327
assign 1 664 2328
addValue 1 664 2328
assign 1 664 2329
new 0 664 2329
assign 1 664 2330
addValue 1 664 2330
addValue 1 664 2331
assign 1 665 2332
new 0 665 2332
assign 1 665 2333
addValue 1 665 2333
addValue 1 665 2334
assign 1 667 2335
new 0 667 2335
assign 1 667 2336
addValue 1 667 2336
addValue 1 667 2337
assign 1 669 2338
getTypeInst 1 669 2338
assign 1 671 2339
new 0 671 2339
assign 1 671 2340
addValue 1 671 2340
assign 1 671 2341
emitNameGet 0 671 2341
assign 1 671 2342
addValue 1 671 2342
assign 1 671 2343
new 0 671 2343
assign 1 671 2344
addValue 1 671 2344
addValue 1 671 2345
assign 1 673 2346
new 0 673 2346
assign 1 673 2347
addValue 1 673 2347
assign 1 673 2348
addValue 1 673 2348
assign 1 673 2349
new 0 673 2349
assign 1 673 2350
addValue 1 673 2350
addValue 1 673 2351
assign 1 675 2352
new 0 675 2352
assign 1 675 2353
addValue 1 675 2353
addValue 1 675 2354
assign 1 681 2366
new 0 681 2366
assign 1 681 2367
add 1 681 2367
assign 1 681 2368
new 0 681 2368
assign 1 681 2369
add 1 681 2369
write 1 681 2370
assign 1 682 2371
new 0 682 2371
assign 1 682 2372
add 1 682 2372
assign 1 682 2373
new 0 682 2373
assign 1 682 2374
add 1 682 2374
write 1 682 2375
emitLib 0 684 2376
assign 1 689 2389
libNameGet 0 689 2389
assign 1 689 2390
relEmitName 1 689 2390
assign 1 690 2391
new 0 690 2391
assign 1 690 2392
add 1 690 2392
assign 1 690 2393
new 0 690 2393
assign 1 690 2394
add 1 690 2394
assign 1 691 2395
new 0 691 2395
assign 1 691 2396
add 1 691 2396
assign 1 691 2397
add 1 691 2397
return 1 691 2398
return 1 0 2401
return 1 0 2404
assign 1 0 2407
assign 1 0 2411
return 1 0 2415
return 1 0 2418
assign 1 0 2421
assign 1 0 2425
return 1 0 2429
return 1 0 2432
assign 1 0 2435
assign 1 0 2439
return 1 0 2443
return 1 0 2446
assign 1 0 2449
assign 1 0 2453
return 1 0 2457
return 1 0 2460
assign 1 0 2463
assign 1 0 2467
return 1 0 2471
return 1 0 2474
assign 1 0 2477
assign 1 0 2481
return 1 0 2485
return 1 0 2488
assign 1 0 2491
assign 1 0 2495
return 1 0 2499
return 1 0 2502
assign 1 0 2505
assign 1 0 2509
return 1 0 2513
return 1 0 2516
assign 1 0 2519
assign 1 0 2523
return 1 0 2527
return 1 0 2530
assign 1 0 2533
assign 1 0 2537
return 1 0 2541
return 1 0 2544
assign 1 0 2547
assign 1 0 2551
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1905048586: return bem_parentConfGet_0();
case -496504343: return bem_nameToIdGetDirect_0();
case 1246901786: return bem_nlGetDirect_0();
case -285949490: return bem_buildInitial_0();
case -2043611193: return bem_smnlecsGet_0();
case -1837681216: return bem_boolNpGetDirect_0();
case 1483871301: return bem_print_0();
case 1510619220: return bem_smnlcsGet_0();
case 1417709660: return bem_newDecGet_0();
case 648854108: return bem_inClassGetDirect_0();
case 931803743: return bem_initialDecGet_0();
case 869462119: return bem_classHeadBodyGetDirect_0();
case 2105313901: return bem_randGet_0();
case 2132579461: return bem_invpGet_0();
case -1342825111: return bem_ccCacheGet_0();
case 2047640217: return bem_buildGetDirect_0();
case -716909725: return bem_preClassGet_0();
case 847199398: return bem_msynGet_0();
case 772136621: return bem_classEmitsGetDirect_0();
case -41826997: return bem_classHeadersGetDirect_0();
case -1615184066: return bem_emitLangGet_0();
case -1413347530: return bem_boolNpGet_0();
case -864207572: return bem_lastMethodBodyLinesGetDirect_0();
case 1640366804: return bem_maxDynArgsGetDirect_0();
case -1477430996: return bem_lastMethodsLinesGet_0();
case -40404697: return bem_exceptDecGetDirect_0();
case 1474587875: return bem_superNameGet_0();
case 708481776: return bem_qGetDirect_0();
case -1064247027: return bem_cnodeGet_0();
case 2126103809: return bem_falseValueGet_0();
case -916073745: return bem_idToNamePathGet_0();
case -1712947480: return bem_libEmitNameGetDirect_0();
case 448996129: return bem_classNameGet_0();
case -415465252: return bem_boolTypeGet_0();
case -1745665844: return bem_ccMethodsGetDirect_0();
case -779841335: return bem_dynMethodsGetDirect_0();
case -2039920444: return bem_callNamesGet_0();
case 1581478205: return bem_iteratorGet_0();
case -2139626817: return bem_emitLib_0();
case 921720133: return bem_classConfGet_0();
case 992621905: return bem_floatNpGetDirect_0();
case 431235415: return bem_smnlecsGetDirect_0();
case 712340316: return bem_methodsGetDirect_0();
case -1516096869: return bem_instOfGet_0();
case 216599422: return bem_stringNpGetDirect_0();
case -1747289470: return bem_boolCcGetDirect_0();
case 1880225664: return bem_propertyDecsGet_0();
case -791697800: return bem_classEmitsGet_0();
case -1836543373: return bem_buildPropList_0();
case -609107358: return bem_mnodeGetDirect_0();
case 1894015908: return bem_synEmitPathGet_0();
case 1002249641: return bem_methodCallsGetDirect_0();
case -330518448: return bem_instOfGetDirect_0();
case -1031837621: return bem_transGetDirect_0();
case 627106237: return bem_intNpGet_0();
case -672140231: return bem_mainInClassGet_0();
case -1579873230: return bem_callNamesGetDirect_0();
case -65226717: return bem_idToNameGetDirect_0();
case -1036129250: return bem_mainStartGet_0();
case -1689304037: return bem_idToNamePathGetDirect_0();
case 1588626922: return bem_headExtGet_0();
case 1654667257: return bem_instanceEqualGet_0();
case -1715577338: return bem_overrideMtdDecGet_0();
case 1707338236: return bem_classEndGet_0();
case -54172161: return bem_classHeadBodyGet_0();
case 487655943: return bem_hashGet_0();
case -1265616905: return bem_invpGetDirect_0();
case -737828887: return bem_serializeContents_0();
case 1620426785: return bem_fieldIteratorGet_0();
case 1071271470: return bem_preClassGetDirect_0();
case 2089095728: return bem_lastMethodsSizeGet_0();
case -704616004: return bem_methodCallsGet_0();
case -608244293: return bem_inFilePathedGet_0();
case -810873426: return bem_classCallsGet_0();
case 470948947: return bem_libEmitPathGetDirect_0();
case -1278073942: return bem_doEmit_0();
case 1908654172: return bem_classCallsGetDirect_0();
case 483333725: return bem_heopGet_0();
case -1725198944: return bem_lineCountGet_0();
case -1572015203: return bem_stringNpGet_0();
case 1094767720: return bem_nativeCSlotsGet_0();
case -2071009393: return bem_lastMethodsLinesGetDirect_0();
case -1622978170: return bem_getClassOutput_0();
case 34284163: return bem_deopGet_0();
case -1507492485: return bem_nullValueGet_0();
case -1722302090: return bem_deopGetDirect_0();
case 184445081: return bem_getLibOutput_0();
case 392683688: return bem_constGet_0();
case 413823665: return bem_inClassGet_0();
case -1996723895: return bem_saveSyns_0();
case 1026744520: return bem_fileExtGet_0();
case 1070446799: return bem_baseSmtdDecGet_0();
case 1039762127: return bem_ccMethodsGet_0();
case -1978205903: return bem_heonGetDirect_0();
case -130970851: return bem_scvpGetDirect_0();
case -1396945123: return bem_constGetDirect_0();
case 293528805: return bem_covariantReturnsGet_0();
case 935821029: return bem_buildCreate_0();
case -390571753: return bem_onceDecsGetDirect_0();
case 1059928307: return bem_nullValueGetDirect_0();
case -2046304502: return bem_create_0();
case -1896602876: return bem_preClassOutput_0();
case -1264655638: return bem_transGet_0();
case 995090711: return bem_randGetDirect_0();
case -360433951: return bem_smnlcsGetDirect_0();
case -493185831: return bem_classesInDepthOrderGet_0();
case 1586902318: return bem_endNs_0();
case -1365518642: return bem_libEmitNameGet_0();
case -567072059: return bem_nameToIdPathGet_0();
case -1881554749: return bem_classesInDepthOrderGetDirect_0();
case 670056253: return bem_csynGet_0();
case -1215942975: return bem_returnTypeGetDirect_0();
case 1985770817: return bem_fullLibEmitNameGetDirect_0();
case -1419436866: return bem_instanceNotEqualGet_0();
case -109711178: return bem_lastCallGetDirect_0();
case -727891294: return bem_methodBodyGetDirect_0();
case 740905823: return bem_parentConfGetDirect_0();
case 1815966069: return bem_idToNameGet_0();
case 1945891707: return bem_baseMtdDecGet_0();
case 491692925: return bem_deonGetDirect_0();
case 768475521: return bem_floatNpGet_0();
case 1867025799: return bem_maxSpillArgsLenGetDirect_0();
case 1263735690: return bem_objectNpGet_0();
case -1202238867: return bem_onceDecsGet_0();
case 1593471901: return bem_afterCast_0();
case 2064223645: return bem_saveIds_0();
case -2033056683: return bem_serializeToString_0();
case 203797428: return bem_mnodeGet_0();
case 2075894197: return bem_intNpGetDirect_0();
case -823404476: return bem_superCallsGet_0();
case 2107651007: return bem_lastMethodBodySizeGet_0();
case -1346676674: return bem_runtimeInitGet_0();
case 1802860995: return bem_returnTypeGet_0();
case -835001284: return bem_shlibeGet_0();
case 300439498: return bem_nameToIdGet_0();
case -650269644: return bem_dynMethodsGet_0();
case -416926671: return bem_objectCcGetDirect_0();
case -1007338962: return bem_methodsGet_0();
case 2068644321: return bem_propDecGet_0();
case -79966691: return bem_deowGet_0();
case 440169444: return bem_tagGet_0();
case -1243764713: return bem_sourceFileNameGet_0();
case -966553588: return bem_lastMethodsSizeGetDirect_0();
case 1889317880: return bem_methodCatchGetDirect_0();
case -1467994622: return bem_classConfGetDirect_0();
case -317472257: return bem_instanceEqualGetDirect_0();
case 1875311115: return bem_nlGet_0();
case -1142345744: return bem_libEmitPathGet_0();
case 366830108: return bem_qGet_0();
case 830158372: return bem_heopGetDirect_0();
case -1371904046: return bem_boolCcGet_0();
case -343091257: return bem_mainEndGet_0();
case -676412474: return bem_prepHeaderOutput_0();
case -1901277244: return bem_setOutputTimeGet_0();
case 1177953347: return bem_fieldNamesGet_0();
case -137683530: return bem_heonGet_0();
case -1402660941: return bem_trueValueGet_0();
case 427857021: return bem_lastCallGet_0();
case -2085276285: return bem_objectCcGet_0();
case -1781744279: return bem_msynGetDirect_0();
case -1808094366: return bem_lineCountGetDirect_0();
case -546904741: return bem_lastMethodBodyLinesGet_0();
case 295100584: return bem_classHeadersGet_0();
case 1452134057: return bem_exceptDecGet_0();
case 592304305: return bem_gcMarksGet_0();
case -1582099636: return bem_fileExtGetDirect_0();
case -223238840: return bem_mainOutsideNsGet_0();
case -1633309881: return bem_echo_0();
case 1384308940: return bem_cnodeGetDirect_0();
case -1858029773: return bem_csynGetDirect_0();
case -1925658326: return bem_belslitsGetDirect_0();
case -818807513: return bem_synEmitPathGetDirect_0();
case 155318499: return bem_ntypesGet_0();
case 1736260330: return bem_typeDecGet_0();
case 2124697834: return bem_buildClassInfo_0();
case -1552631533: return bem_trueValueGetDirect_0();
case -1211458299: return bem_deowGetDirect_0();
case -689378050: return bem_heowGetDirect_0();
case -2101319947: return bem_writeBET_0();
case -1318471451: return bem_toString_0();
case 358055197: return bem_lastMethodBodySizeGetDirect_0();
case 53254432: return bem_scvpGet_0();
case 448708385: return bem_maxSpillArgsLenGet_0();
case -1142809906: return bem_serializationIteratorGet_0();
case -1417028920: return bem_falseValueGetDirect_0();
case -1022536508: return bem_superCallsGetDirect_0();
case -1624889671: return bem_copy_0();
case -699067214: return bem_maxDynArgsGet_0();
case -345684309: return bem_methodBodyGet_0();
case -1564435804: return bem_new_0();
case 954808161: return bem_nameToIdPathGetDirect_0();
case -172014954: return bem_gcMarksGetDirect_0();
case -1202899823: return bem_belslitsGet_0();
case -1862425968: return bem_objectNpGetDirect_0();
case -1060437377: return bem_methodCatchGet_0();
case -1883032963: return bem_deonGet_0();
case -689507204: return bem_loadIds_0();
case -1230859656: return bem_heowGet_0();
case -862700434: return bem_shlibeGetDirect_0();
case -482561942: return bem_propertyDecsGetDirect_0();
case -459402135: return bem_spropDecGet_0();
case -1533381043: return bem_instanceNotEqualGetDirect_0();
case 978026423: return bem_beginNs_0();
case -944317370: return bem_buildGet_0();
case -1960473534: return bem_inFilePathedGetDirect_0();
case -1578880452: return bem_setOutputTimeGetDirect_0();
case -519290827: return bem_ccCacheGetDirect_0();
case 1998804429: return bem_deserializeClassNameGet_0();
case 381543886: return bem_nativeCSlotsGetDirect_0();
case 535819729: return bem_fullLibEmitNameGet_0();
case -498450411: return bem_headExtGetDirect_0();
case 1694794732: return bem_ntypesGetDirect_0();
case 1104929273: return bem_emitLangGetDirect_0();
case -1453410815: return bem_useDynMethodsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1176393151: return bem_idToNameSetDirect_1(bevd_0);
case 1144186210: return bem_scvpSetDirect_1(bevd_0);
case -556524265: return bem_lastCallSetDirect_1(bevd_0);
case 1986570248: return bem_synEmitPathSetDirect_1(bevd_0);
case -1762502713: return bem_gcMarksSet_1(bevd_0);
case -1651690674: return bem_classCallsSet_1(bevd_0);
case 2001988342: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1116783961: return bem_inFilePathedSet_1(bevd_0);
case 809920109: return bem_deowSetDirect_1(bevd_0);
case -589814194: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 974638892: return bem_classConfSet_1(bevd_0);
case 1270683734: return bem_cnodeSet_1(bevd_0);
case 920574580: return bem_constSetDirect_1(bevd_0);
case 2136008133: return bem_invpSetDirect_1(bevd_0);
case 1499168724: return bem_intNpSet_1(bevd_0);
case -543440136: return bem_deonSetDirect_1(bevd_0);
case 477230505: return bem_propertyDecsSetDirect_1(bevd_0);
case -589557323: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1005183903: return bem_classHeadBodySetDirect_1(bevd_0);
case -984868650: return bem_nameToIdPathSet_1(bevd_0);
case 124582017: return bem_headExtSet_1(bevd_0);
case 771465978: return bem_classEmitsSetDirect_1(bevd_0);
case -1453027758: return bem_nlSet_1(bevd_0);
case -685088526: return bem_deopSet_1(bevd_0);
case -1268158319: return bem_scvpSet_1(bevd_0);
case 1832537262: return bem_methodBodySet_1(bevd_0);
case 835036950: return bem_classesInDepthOrderSet_1(bevd_0);
case 1526386251: return bem_inClassSetDirect_1(bevd_0);
case -417515303: return bem_libEmitNameSet_1(bevd_0);
case -1500817430: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -591456150: return bem_randSet_1(bevd_0);
case 1160896762: return bem_heowSetDirect_1(bevd_0);
case 1388339915: return bem_idToNamePathSetDirect_1(bevd_0);
case 1406873133: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -536795541: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1601506198: return bem_otherClass_1(bevd_0);
case 1796457979: return bem_libEmitPathSet_1(bevd_0);
case 32265803: return bem_buildSetDirect_1(bevd_0);
case -769314128: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1312709529: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 793385385: return bem_objectNpSetDirect_1(bevd_0);
case -535212349: return bem_parentConfSetDirect_1(bevd_0);
case -1095715354: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1851732120: return bem_emitLangSetDirect_1(bevd_0);
case 1141578901: return bem_smnlecsSetDirect_1(bevd_0);
case 164136834: return bem_smnlcsSetDirect_1(bevd_0);
case 1199488369: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1920957546: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1684141587: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1106774368: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -511463371: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1665183499: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1220674189: return bem_stringNpSet_1(bevd_0);
case 483074134: return bem_deonSet_1(bevd_0);
case -1365797396: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 501727324: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1160715443: return bem_maxDynArgsSet_1(bevd_0);
case -1242363724: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -647806649: return bem_callNamesSetDirect_1(bevd_0);
case 989547111: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -865859830: return bem_methodCatchSet_1(bevd_0);
case 1384207300: return bem_lineCountSet_1(bevd_0);
case 2070690279: return bem_methodCatchSetDirect_1(bevd_0);
case -1074454539: return bem_onceDecsSetDirect_1(bevd_0);
case -666394800: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1249546838: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -1889443202: return bem_classHeadBodySet_1(bevd_0);
case 65230552: return bem_exceptDecSetDirect_1(bevd_0);
case -92924146: return bem_constSet_1(bevd_0);
case -1456472621: return bem_parentConfSet_1(bevd_0);
case 65669227: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1716640190: return bem_heopSetDirect_1(bevd_0);
case -1558076352: return bem_lastMethodsSizeSet_1(bevd_0);
case -898101289: return bem_lineCountSetDirect_1(bevd_0);
case -1645276451: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1276126874: return bem_otherType_1(bevd_0);
case -543492534: return bem_classEmitsSet_1(bevd_0);
case 1506859944: return bem_instanceNotEqualSet_1(bevd_0);
case 581422588: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1573182686: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -331697156: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1900502363: return bem_def_1(bevd_0);
case -776802815: return bem_notEquals_1(bevd_0);
case 1566952497: return bem_heonSet_1(bevd_0);
case -321786320: return bem_exceptDecSet_1(bevd_0);
case -2069827054: return bem_maxSpillArgsLenSet_1(bevd_0);
case 2117517194: return bem_callNamesSet_1(bevd_0);
case 888804053: return bem_buildSet_1(bevd_0);
case -195131290: return bem_nullValueSet_1(bevd_0);
case -1569135551: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -966425643: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -2082849717: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -5580524: return bem_lastMethodBodySizeSet_1(bevd_0);
case -346196908: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -513393413: return bem_instanceEqualSetDirect_1(bevd_0);
case 855685611: return bem_nlSetDirect_1(bevd_0);
case -1280208682: return bem_belslitsSetDirect_1(bevd_0);
case -1049365982: return bem_libEmitNameSetDirect_1(bevd_0);
case 3154289: return bem_heopSet_1(bevd_0);
case 2096311091: return bem_classCallsSetDirect_1(bevd_0);
case 1001549105: return bem_intNpSetDirect_1(bevd_0);
case 969619747: return bem_ntypesSet_1(bevd_0);
case 1742538477: return bem_heowSet_1(bevd_0);
case -768475414: return bem_emitLangSet_1(bevd_0);
case -1913720579: return bem_msynSet_1(bevd_0);
case 1463519031: return bem_idToNameSet_1(bevd_0);
case -1314033294: return bem_superCallsSet_1(bevd_0);
case 965946056: return bem_sameClass_1(bevd_0);
case 501453905: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2107777913: return bem_boolNpSet_1(bevd_0);
case -20453904: return bem_nativeCSlotsSet_1(bevd_0);
case -127095304: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1759310334: return bem_methodCallsSetDirect_1(bevd_0);
case 1153344770: return bem_deowSet_1(bevd_0);
case 837772927: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -2028446465: return bem_cnodeSetDirect_1(bevd_0);
case -1210668381: return bem_returnTypeSet_1(bevd_0);
case -490707087: return bem_nameToIdSetDirect_1(bevd_0);
case 393195232: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1248961715: return bem_smnlecsSet_1(bevd_0);
case 1720715698: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -434895019: return bem_inClassSet_1(bevd_0);
case 1216425801: return bem_gcMarksSetDirect_1(bevd_0);
case 2124776177: return bem_instanceEqualSet_1(bevd_0);
case -1367412627: return bem_objectNpSet_1(bevd_0);
case 2133936581: return bem_dynMethodsSet_1(bevd_0);
case -1062855160: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -246848852: return bem_objectCcSetDirect_1(bevd_0);
case -1047611956: return bem_returnTypeSetDirect_1(bevd_0);
case 1507443405: return bem_classHeadersSet_1(bevd_0);
case 1627151964: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -161465199: return bem_objectCcSet_1(bevd_0);
case 1370027600: return bem_heonSetDirect_1(bevd_0);
case 1988655945: return bem_maxDynArgsSetDirect_1(bevd_0);
case 1604441302: return bem_boolCcSetDirect_1(bevd_0);
case 2030931455: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 609103448: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -898541022: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 533860283: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1947946723: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1217337757: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -428805633: return bem_smnlcsSet_1(bevd_0);
case 1498629367: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -547153682: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1428615783: return bem_shlibeSetDirect_1(bevd_0);
case -1794266403: return bem_randSetDirect_1(bevd_0);
case -40889849: return bem_equals_1(bevd_0);
case -162013749: return bem_methodBodySetDirect_1(bevd_0);
case -1692419446: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1580911739: return bem_transSetDirect_1(bevd_0);
case -1801363800: return bem_sameType_1(bevd_0);
case -2031308664: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 307579069: return bem_mnodeSetDirect_1(bevd_0);
case -984846802: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1676473663: return bem_transSet_1(bevd_0);
case -1506038673: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1985945477: return bem_boolNpSetDirect_1(bevd_0);
case -1810764107: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1666603936: return bem_methodCallsSet_1(bevd_0);
case 776341306: return bem_boolCcSet_1(bevd_0);
case -1411103959: return bem_csynSetDirect_1(bevd_0);
case -1765215876: return bem_propertyDecsSet_1(bevd_0);
case -165039915: return bem_classHeadersSetDirect_1(bevd_0);
case 830628482: return bem_ccMethodsSetDirect_1(bevd_0);
case 1977467180: return bem_floatNpSet_1(bevd_0);
case 1883454306: return bem_onceDecsSet_1(bevd_0);
case 862019834: return bem_preClassSet_1(bevd_0);
case 1303671033: return bem_synEmitPathSet_1(bevd_0);
case 1308667600: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1112214825: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 778877421: return bem_superCallsSetDirect_1(bevd_0);
case -828647760: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1829674463: return bem_instOfSet_1(bevd_0);
case -215197654: return bem_nullValueSetDirect_1(bevd_0);
case -1043565263: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1704386845: return bem_methodsSet_1(bevd_0);
case 968418057: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 814665709: return bem_qSet_1(bevd_0);
case -119916863: return bem_csynSet_1(bevd_0);
case -2109657116: return bem_headExtSetDirect_1(bevd_0);
case 1655576193: return bem_undef_1(bevd_0);
case 147216419: return bem_inFilePathedSetDirect_1(bevd_0);
case -1778125736: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -579885477: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1904650588: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case -1596601005: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -992746474: return bem_libEmitPathSetDirect_1(bevd_0);
case -1502629244: return bem_lastMethodsLinesSet_1(bevd_0);
case -688233547: return bem_floatNpSetDirect_1(bevd_0);
case -559309812: return bem_falseValueSetDirect_1(bevd_0);
case -523405153: return bem_ccCacheSet_1(bevd_0);
case -739210206: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 975426469: return bem_methodsSetDirect_1(bevd_0);
case -1464630734: return bem_instOfSetDirect_1(bevd_0);
case 1727762653: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1724702365: return bem_copyTo_1(bevd_0);
case -1496416198: return bem_nameToIdPathSetDirect_1(bevd_0);
case 31987140: return bem_fullLibEmitNameSet_1(bevd_0);
case -1550031625: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -426441700: return bem_stringNpSetDirect_1(bevd_0);
case 1739469338: return bem_msynSetDirect_1(bevd_0);
case -260650300: return bem_qSetDirect_1(bevd_0);
case 1193928649: return bem_ccMethodsSet_1(bevd_0);
case 576869909: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1235580441: return bem_invpSet_1(bevd_0);
case -1365264983: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1676374907: return bem_trueValueSetDirect_1(bevd_0);
case 516883755: return bem_mnodeSet_1(bevd_0);
case -1545442975: return bem_nameToIdSet_1(bevd_0);
case 169951417: return bem_fileExtSetDirect_1(bevd_0);
case 517106548: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1531282659: return bem_setOutputTimeSet_1(bevd_0);
case 2085486820: return bem_begin_1(bevd_0);
case -1578040652: return bem_setOutputTimeSetDirect_1(bevd_0);
case -1929541195: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1619863769: return bem_ntypesSetDirect_1(bevd_0);
case -1397790748: return bem_preClassSetDirect_1(bevd_0);
case -494951066: return bem_idToNamePathSet_1(bevd_0);
case -139444378: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 690536844: return bem_deopSetDirect_1(bevd_0);
case 1076492440: return bem_classConfSetDirect_1(bevd_0);
case 1860254211: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 905653088: return bem_dynMethodsSetDirect_1(bevd_0);
case 1314487362: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 887328988: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -343673135: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -134372548: return bem_trueValueSet_1(bevd_0);
case -1767763000: return bem_sameObject_1(bevd_0);
case 2143680922: return bem_ccCacheSetDirect_1(bevd_0);
case -48526213: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1968002631: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1447328242: return bem_lastCallSet_1(bevd_0);
case 1036105379: return bem_fileExtSet_1(bevd_0);
case -761989943: return bem_shlibeSet_1(bevd_0);
case 55284305: return bem_end_1(bevd_0);
case -870454536: return bem_belslitsSet_1(bevd_0);
case 28269320: return bem_falseValueSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 410322673: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -984805442: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -180551001: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 911764577: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 994140170: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1549411179: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1575588604: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1484503901: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -336527550: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2086573663: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 162928067: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -739728997: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1644303351: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -94627864: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -794593192: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 281086555: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 2032060631: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -47283370: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1070958654: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 539687796: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 594537162: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 780734768: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -35785513: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 1906201451: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 963885469: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1308676246: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
