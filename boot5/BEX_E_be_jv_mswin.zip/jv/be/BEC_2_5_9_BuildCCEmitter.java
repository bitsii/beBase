package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_24, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_26, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_34, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_35, 14));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_36, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_37, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_69, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_70, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_71, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_80, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_84, 28));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_85, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_88, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_91, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x2A,0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_92, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_102, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_103, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_104, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_105, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_106, 45));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_107, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_108, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_109, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_110, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_111, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_112, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_113, 45));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_114, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x66,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_115, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_116, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_117, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_118, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_119, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_120, 0));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_121, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_122, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_123, 45));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_124, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_125, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_128, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_129, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_130, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_131, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_133, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_134, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_142, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_150, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_53 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_151, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_159 = {0x5D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_160 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_161 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_162 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_163 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_164 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_165 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_166 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_167 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_168 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_169 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_170 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_171 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_172 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_173 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_174 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_175 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_175, 22));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_176 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_177 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_178 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_179 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_180 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_181 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_182 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_183 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_184 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_185 = {0x66,0x6F,0x72,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x69,0x20,0x3D,0x20,0x30,0x3B,0x20,0x69,0x20,0x3C,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x20,0x69,0x2B,0x2B,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_186 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x67,0x5F,0x6C,0x65,0x20,0x3D,0x20,0x2A,0x28,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B,0x69,0x5D,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_187 = {0x62,0x65,0x76,0x67,0x5F,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_188 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_189 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_190 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_191 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_192 = {0x5D,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_193 = {0x7D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_194 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_195 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_196 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_197 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_55 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_197, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_198 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_56 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_198, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_199 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_199, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_200 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_200, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_201 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_202 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_203 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_204 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_205 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_206 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_207 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_208 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_209 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_210 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_211 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_212 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_213 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_214 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_215 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_216 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_217 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_218 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_219 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_220 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_221 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_222 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_223 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_224 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_225 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_59 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_225, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_226 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_60 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_226, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_227 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_228 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_229 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_230 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_61 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_230, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_231 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_62 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_231, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_232 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_63 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_232, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_233 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_64 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_233, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_234 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_65 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_234, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_235 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_66 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_235, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_236 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_237 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_238 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_239 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_240 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_241 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_242 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_243 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_244 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_245 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_246 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_247 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_248 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_249 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_250 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_251 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_252 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_253 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_254 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_255 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_256 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_257 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_258 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_259 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_260 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_261 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_262 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_263 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_264 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_265 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_266 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_267 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_268 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_269 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_67 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_269, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_270 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_68 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_270, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_271 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_69 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_271, 2));
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_6_TextString bevp_onceDecRefs;
public BEC_2_4_3_MathInt bevp_onceDecRefsCount;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefs = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefsCount = (new BEC_2_4_3_MathInt(0));
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 45 */
 else  /* Line: 46 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 47 */
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 56 */
 else  /* Line: 57 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevl_begin.bem_addValue_1(bevt_20_tmpany_phold);
} /* Line: 62 */
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevl_begin.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevl_begin.bem_addValue_1(bevt_22_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevp_heow.bem_write_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevp_heow.bem_write_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_31_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevp_heow.bem_write_1(bevt_26_tmpany_phold);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevp_heow.bem_write_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_45_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_49_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_50_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_51_tmpany_phold);
bevp_deow.bem_write_1(bevt_47_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
return bevt_52_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_7_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_6_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_17_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_22_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(2008532828);
bevt_20_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_tmpany_phold );
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_25_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_26_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_0_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_14_tmpany_phold = bevp_methods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_20_tmpany_phold = bevp_classHeadBody.bem_addValue_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_22_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_17_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevp_classHeadBody.bem_addValue_1(bevt_26_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
} /* Line: 142 */
 else  /* Line: 141 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(2031369362);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-299391132, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
} /* Line: 144 */
 else  /* Line: 141 */ {
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(2031369362);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(-299391132, bevt_10_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 145 */ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
} /* Line: 146 */
 else  /* Line: 147 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_tmpany_phold );
} /* Line: 148 */
} /* Line: 141 */
} /* Line: 141 */
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(2031369362);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-299391132, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 156 */
bevt_5_tmpany_phold = super.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1783050050);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-159187266, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-1632698618);
bevp_classHeaders.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 167 */
 else  /* Line: 168 */ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 169 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_8_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevl_clh = bevt_4_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_11_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_24_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_32_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1518464696);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-34332134);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_4_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = beva_b.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_2_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 201 */
 else  /* Line: 202 */ {
bevt_9_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_8_tmpany_phold = bem_getClassConfig_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_6_tmpany_phold = beva_b.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_6_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
} /* Line: 203 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
} /* Line: 209 */
 else  /* Line: 210 */ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
} /* Line: 211 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevt_18_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevt_22_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 229 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-262525036);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 230 */
bevt_16_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_17_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = beva_node.bem_heldGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(-262525036);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevl_newCall = bevt_11_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 237 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-262525036);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 238 */
bevt_16_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_17_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = beva_node.bem_heldGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(-262525036);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevl_newCall = bevt_11_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 245 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 246 */
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevl_litArgs = bevt_12_tmpany_phold.bem_add_1(beva_belsName);
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_22_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_43;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevl_litArgs);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_44;
bevl_newCall = bevt_16_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
return bevl_newCall;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevp_onceDecRefsCount.bevi_int++;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_notEmpty_1(bevp_onceDecRefs);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevp_onceDecRefs.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 257 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_3_tmpany_phold = bevp_onceDecRefs.bem_addValue_1(bevt_4_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(beva_anyName);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_45;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_typeName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_46;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_47;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_48;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_49;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_50;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(2031369362);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_51;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
bevp_setOutputTime = null;
bevt_1_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 312 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 312 */ {
return this;
} /* Line: 313 */
 else  /* Line: 314 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevl_outts = bevt_6_tmpany_phold.bem_lastUpdatedGet_0();
bevt_9_tmpany_phold = bevp_inClass.bem_fromFileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-2124998212);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bemd_0(1870470022);
bevt_10_tmpany_phold = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 317 */ {
return this;
} /* Line: 320 */
bevp_setOutputTime = bevl_outts;
} /* Line: 323 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_1_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_1_tmpany_phold = bem_getLibOutput_0();
return bevt_1_tmpany_phold;
} /* Line: 329 */
bevt_2_tmpany_phold = super.bem_getClassOutput_0();
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 335 */ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 338 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 343 */ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevt_4_tmpany_phold = beva_cle.bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 351 */
} /* Line: 349 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_4_tmpany_phold = bevl_bet.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_9_tmpany_phold = bevl_bet.bem_addValue_1(beva_mvn);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_11_tmpany_phold = bevl_bet.bem_addValue_1(bevt_12_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_52;
bevt_5_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_53;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevp_deow.bem_write_1(bevt_2_tmpany_phold);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_8_tmpany_phold = bevl_beh.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevl_beh.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = bevl_beh.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevl_beh.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevl_beh.bem_addValue_1(bevt_17_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_158));
bevt_19_tmpany_phold = bevl_beh.bem_addValue_1(bevt_20_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_159));
bevt_18_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_160));
bevl_beh.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_161));
bevl_beh.bem_addValue_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_162));
bevl_beh.bem_addValue_1(bevt_24_tmpany_phold);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_28_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_27_tmpany_phold = bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_163));
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_164));
bevt_25_tmpany_phold.bem_addValue_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_165));
bevl_bet.bem_addValue_1(bevt_32_tmpany_phold);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_33_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_33_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 382 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 382 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(2106399977);
if (bevl_firstmnsyn.bevi_bool) /* Line: 383 */ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 384 */
 else  /* Line: 385 */ {
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_166));
bevl_bet.bem_addValue_1(bevt_35_tmpany_phold);
} /* Line: 386 */
bevt_37_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_38_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 388 */
 else  /* Line: 382 */ {
break;
} /* Line: 382 */
} /* Line: 382 */
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_167));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_168));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_169));
bevl_bet.bem_addValue_1(bevt_41_tmpany_phold);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_42_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_42_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 395 */ {
bevt_43_tmpany_phold = bevt_1_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_43_tmpany_phold).bevi_bool) /* Line: 395 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(2106399977);
if (bevl_firstptsyn.bevi_bool) /* Line: 396 */ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 397 */
 else  /* Line: 398 */ {
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_170));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
} /* Line: 399 */
bevt_46_tmpany_phold = bevl_bet.bem_addValue_1(bevp_q);
bevt_47_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_45_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 401 */
 else  /* Line: 395 */ {
break;
} /* Line: 395 */
} /* Line: 395 */
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_171));
bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_172));
bevl_bet.bem_addValue_1(bevt_49_tmpany_phold);
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_173));
bevt_51_tmpany_phold = bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_174));
bevt_50_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_57_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_54;
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 408 */ {
bevt_60_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_176));
bevt_59_tmpany_phold = bevl_bet.bem_addValue_1(bevt_60_tmpany_phold);
bevt_61_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bem_addValue_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_177));
bevt_58_tmpany_phold.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 409 */
 else  /* Line: 410 */ {
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_178));
bevt_64_tmpany_phold = bevl_bet.bem_addValue_1(bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_addValue_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_179));
bevt_63_tmpany_phold.bem_addValue_1(bevt_67_tmpany_phold);
} /* Line: 411 */
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_180));
bevl_bet.bem_addValue_1(bevt_68_tmpany_phold);
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_181));
bevt_70_tmpany_phold = bevl_bet.bem_addValue_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_addValue_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_182));
bevt_69_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_183));
bevl_bet.bem_addValue_1(bevt_74_tmpany_phold);
bevt_76_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_184));
bevt_75_tmpany_phold = bem_genMark_1(bevt_76_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_185));
bevl_bet.bem_addValue_1(bevt_77_tmpany_phold);
bevt_78_tmpany_phold = (new BEC_2_4_6_TextString(56, bece_BEC_2_5_9_BuildCCEmitter_bels_186));
bevl_bet.bem_addValue_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_187));
bevt_79_tmpany_phold = bem_genMark_1(bevt_80_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_79_tmpany_phold);
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_188));
bevl_bet.bem_addValue_1(bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_189));
bevl_bet.bem_addValue_1(bevt_82_tmpany_phold);
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_190));
bevt_89_tmpany_phold = bevp_onceDecs.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_191));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_86_tmpany_phold = bevt_87_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_192));
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_addValue_1(bevt_93_tmpany_phold);
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bem_addValue_1(bevp_onceDecRefs);
bevt_94_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_193));
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bem_addValue_1(bevt_94_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_194));
bevt_98_tmpany_phold = bevp_onceDecs.bem_addValue_1(bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_195));
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_addValue_1(bevt_101_tmpany_phold);
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_196));
bevt_95_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevp_onceDecRefs.bem_clear_0();
bevp_onceDecRefsCount = (new BEC_2_4_3_MathInt(0));
bevt_103_tmpany_phold = bem_getClassOutput_0();
bevt_103_tmpany_phold.bem_write_1(bevl_bet);
bevt_104_tmpany_phold = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_104_tmpany_phold.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_20_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_31_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
if (bevp_deow == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 442 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_55;
bevt_8_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_56;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_4_tmpany_phold.bem_add_1(bevp_headExt);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_57;
bevt_14_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_58;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_10_tmpany_phold.bem_add_1(bevp_headExt);
bevt_16_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_17_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_21_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_existsGet_0();
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 448 */ {
bevt_23_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_fileGet_0();
bevt_22_tmpany_phold.bem_makeDirs_0();
} /* Line: 449 */
bevt_25_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_tmpany_phold.bemd_0(-41895186);
bevt_27_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_tmpany_phold.bemd_0(-41895186);
bevt_29_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_201));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_has_1(bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 454 */ {
bevt_32_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_33_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_202));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_get_1(bevt_33_tmpany_phold);
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 456 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 456 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(2106399977);
bevt_35_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_tmpany_phold.bem_fileGet_0();
bevt_37_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-41895186);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bemd_0(-1448868238);
bevt_38_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_38_tmpany_phold.bemd_0(-396818886);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 462 */
 else  /* Line: 456 */ {
break;
} /* Line: 456 */
} /* Line: 456 */
} /* Line: 456 */
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_203));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_204));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_205));
bevp_deow.bem_write_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_206));
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_207));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_has_1(bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 476 */ {
bevt_47_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_208));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_get_1(bevt_48_tmpany_phold);
bevt_1_tmpany_loop = bevt_46_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 478 */ {
bevt_49_tmpany_phold = bevt_1_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_49_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(2106399977);
bevt_50_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_tmpany_phold.bem_fileGet_0();
bevt_52_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(-41895186);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bemd_0(-1448868238);
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_53_tmpany_phold.bemd_0(-396818886);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 484 */
 else  /* Line: 478 */ {
break;
} /* Line: 478 */
} /* Line: 478 */
} /* Line: 478 */
bevt_55_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_209));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_has_1(bevt_56_tmpany_phold);
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 487 */ {
bevt_58_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_210));
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_get_1(bevt_59_tmpany_phold);
bevt_2_tmpany_loop = bevt_57_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 489 */ {
bevt_60_tmpany_phold = bevt_2_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(2106399977);
bevt_61_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_tmpany_phold.bem_fileGet_0();
bevt_63_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(-41895186);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bemd_0(-1448868238);
bevt_64_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_64_tmpany_phold.bemd_0(-396818886);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 495 */
 else  /* Line: 489 */ {
break;
} /* Line: 489 */
} /* Line: 489 */
} /* Line: 489 */
} /* Line: 487 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_27_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 508 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_existsGet_0();
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 510 */ {
bevt_8_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 511 */
bevt_10_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_tmpany_phold.bemd_0(-41895186);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_211));
bevp_shlibe.bem_write_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_212));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_has_1(bevt_14_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 517 */ {
bevt_16_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_213));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_get_1(bevt_17_tmpany_phold);
bevt_0_tmpany_loop = bevt_15_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 519 */ {
bevt_18_tmpany_phold = bevt_0_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 519 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(2106399977);
bevt_19_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-41895186);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bemd_0(-1448868238);
bevt_22_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_22_tmpany_phold.bemd_0(-396818886);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 525 */
 else  /* Line: 519 */ {
break;
} /* Line: 519 */
} /* Line: 519 */
} /* Line: 519 */
bevt_23_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_214));
bevp_shlibe.bem_write_1(bevt_23_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_25_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_215));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_has_1(bevt_26_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 531 */ {
bevt_28_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_216));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_get_1(bevt_29_tmpany_phold);
bevt_1_tmpany_loop = bevt_27_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 532 */ {
bevt_30_tmpany_phold = bevt_1_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 532 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(2106399977);
bevt_31_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_tmpany_phold.bem_fileGet_0();
bevt_33_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-41895186);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bemd_0(-1448868238);
bevt_34_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_34_tmpany_phold.bemd_0(-396818886);
bevt_35_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 537 */
 else  /* Line: 532 */ {
break;
} /* Line: 532 */
} /* Line: 532 */
} /* Line: 532 */
} /* Line: 531 */
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_217));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_218));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_219));
bevt_1_tmpany_phold = beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_220));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(-1087020761);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_221));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 574 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(464565053);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 574 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(2106399977);
if (bevl_first.bevi_bool) /* Line: 575 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 576 */
 else  /* Line: 577 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_222));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 578 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_223));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 580 */
 else  /* Line: 574 */ {
break;
} /* Line: 574 */
} /* Line: 574 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_224));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_59;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_60;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = bevl_initialDec.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_227));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_228));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_229));
bevt_4_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_61;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_62;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_63;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_64;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_65;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_66;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
bevt_1_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_tmpany_phold.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(2008532828);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_236));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_237));
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_238));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_239));
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_240));
bevt_20_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_241));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_tmpany_phold, bevl_asnr);
} /* Line: 622 */
bevt_25_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_242));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_243));
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_29_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_244));
bevt_28_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_29_tmpany_phold);
bevt_28_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_38_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_245));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_246));
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_247));
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_45_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_248));
bevt_44_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_45_tmpany_phold);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_46_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_249));
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_addValue_1(bevt_46_tmpany_phold);
bevt_42_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_250));
bevt_47_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_48_tmpany_phold);
bevt_47_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_55_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_54_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_55_tmpany_phold);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_251));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_57_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_addValue_1(bevt_57_tmpany_phold);
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_252));
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_253));
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_49_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_62_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-2042811033);
if (bevt_61_tmpany_phold == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 641 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 641 */ {
bevt_65_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_0(-2042811033);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(-299391132, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 641 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 641 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 641 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 641 */ {
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_254));
bevt_66_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_67_tmpany_phold);
bevt_66_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 642 */
 else  /* Line: 643 */ {
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_255));
bevt_68_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_69_tmpany_phold);
bevt_68_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 644 */
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_256));
bevt_70_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_71_tmpany_phold);
bevt_70_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_78_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_77_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_257));
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_addValue_1(bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_addValue_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_258));
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_addValue_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_82_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_259));
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bem_addValue_1(bevt_82_tmpany_phold);
bevt_72_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_84_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_260));
bevt_83_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_84_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_261));
bevt_85_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_86_tmpany_phold);
bevt_85_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_262));
bevt_89_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_263));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_96_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_264));
bevt_95_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_96_tmpany_phold);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_97_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_265));
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bem_addValue_1(bevt_97_tmpany_phold);
bevt_93_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_266));
bevt_98_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_99_tmpany_phold);
bevt_98_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_267));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_268));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_67;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_68;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_69;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_headExtGetDirect_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public final BEC_2_4_6_TextString bem_classHeadersGetDirect_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGet_0() throws Throwable {
return bevp_onceDecRefs;
} /*method end*/
public final BEC_2_4_6_TextString bem_onceDecRefsGetDirect_0() throws Throwable {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGet_0() throws Throwable {
return bevp_onceDecRefsCount;
} /*method end*/
public final BEC_2_4_3_MathInt bem_onceDecRefsCountGetDirect_0() throws Throwable {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public final BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public final BEC_2_4_6_TextString bem_deonGetDirect_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public final BEC_2_4_6_TextString bem_heonGetDirect_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public final BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 20, 22, 23, 24, 25, 26, 30, 32, 33, 34, 35, 36, 40, 44, 44, 45, 45, 45, 47, 47, 49, 49, 49, 49, 49, 49, 51, 51, 52, 52, 54, 54, 56, 56, 56, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 65, 65, 67, 67, 69, 71, 73, 75, 77, 77, 78, 78, 79, 79, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 86, 86, 87, 87, 88, 88, 88, 88, 88, 88, 90, 90, 90, 90, 90, 90, 92, 92, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 99, 99, 99, 103, 105, 106, 107, 107, 108, 112, 112, 116, 116, 120, 120, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 125, 127, 129, 129, 129, 129, 129, 129, 131, 131, 131, 131, 131, 131, 131, 131, 131, 131, 133, 135, 135, 141, 141, 141, 141, 142, 143, 143, 143, 143, 144, 145, 145, 145, 145, 146, 148, 148, 150, 154, 154, 154, 154, 155, 155, 156, 158, 158, 162, 162, 162, 162, 162, 162, 162, 162, 166, 166, 166, 166, 167, 167, 167, 169, 175, 175, 175, 175, 175, 177, 177, 177, 177, 177, 177, 177, 177, 179, 181, 183, 183, 183, 183, 183, 183, 183, 183, 183, 183, 183, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 187, 192, 192, 192, 193, 194, 194, 194, 194, 194, 194, 196, 196, 196, 196, 196, 196, 196, 196, 196, 196, 200, 200, 200, 201, 201, 201, 201, 201, 203, 203, 203, 203, 203, 203, 203, 208, 208, 209, 211, 213, 213, 213, 213, 213, 213, 213, 213, 218, 218, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 222, 223, 223, 223, 223, 223, 223, 223, 223, 223, 225, 225, 225, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 230, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 233, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 240, 241, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 249, 249, 249, 249, 249, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 251, 255, 256, 256, 257, 257, 259, 259, 259, 260, 260, 260, 260, 260, 265, 266, 267, 267, 267, 268, 274, 274, 274, 274, 278, 278, 282, 282, 287, 287, 291, 291, 291, 291, 291, 292, 292, 292, 292, 292, 292, 293, 293, 293, 294, 294, 294, 294, 294, 294, 294, 294, 296, 296, 300, 300, 304, 304, 304, 304, 311, 312, 0, 312, 312, 312, 312, 312, 0, 0, 313, 315, 315, 315, 316, 316, 316, 317, 320, 323, 328, 329, 329, 331, 331, 335, 336, 337, 337, 338, 343, 345, 346, 346, 347, 348, 349, 349, 350, 350, 350, 351, 357, 358, 358, 358, 358, 358, 358, 358, 358, 358, 359, 359, 359, 359, 360, 360, 360, 361, 365, 365, 365, 365, 365, 365, 366, 367, 367, 367, 367, 367, 367, 368, 368, 369, 369, 369, 369, 370, 370, 371, 371, 372, 372, 372, 372, 372, 373, 373, 374, 374, 375, 375, 376, 378, 379, 379, 379, 379, 379, 379, 379, 379, 380, 380, 381, 382, 382, 0, 382, 382, 384, 386, 386, 388, 388, 388, 388, 390, 390, 391, 391, 393, 393, 394, 395, 395, 0, 395, 395, 397, 399, 399, 401, 401, 401, 401, 403, 403, 405, 405, 407, 407, 407, 407, 407, 407, 408, 408, 408, 409, 409, 409, 409, 409, 409, 411, 411, 411, 411, 411, 411, 413, 413, 415, 415, 415, 415, 415, 415, 416, 416, 417, 417, 417, 418, 418, 419, 419, 420, 420, 420, 421, 421, 422, 422, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 425, 425, 425, 425, 425, 425, 425, 425, 425, 426, 427, 429, 429, 430, 430, 442, 442, 443, 444, 444, 444, 444, 444, 444, 444, 445, 445, 445, 445, 445, 445, 445, 446, 446, 447, 447, 448, 448, 448, 448, 448, 449, 449, 449, 451, 451, 451, 452, 452, 452, 454, 454, 454, 456, 456, 456, 456, 0, 456, 456, 458, 458, 459, 459, 459, 460, 460, 462, 466, 466, 467, 467, 469, 469, 470, 470, 476, 476, 476, 478, 478, 478, 478, 0, 478, 478, 480, 480, 481, 481, 481, 482, 482, 484, 487, 487, 487, 489, 489, 489, 489, 0, 489, 489, 491, 491, 492, 492, 492, 493, 493, 495, 502, 503, 508, 508, 509, 510, 510, 510, 510, 510, 511, 511, 511, 513, 513, 513, 515, 515, 517, 517, 517, 519, 519, 519, 519, 0, 519, 519, 521, 521, 522, 522, 522, 523, 523, 525, 529, 529, 530, 531, 531, 531, 532, 532, 532, 532, 0, 532, 532, 533, 533, 534, 534, 534, 535, 535, 536, 536, 537, 543, 547, 548, 550, 550, 552, 552, 553, 554, 559, 559, 563, 563, 563, 563, 563, 568, 568, 569, 571, 571, 571, 571, 573, 574, 0, 574, 574, 576, 578, 578, 580, 580, 580, 580, 580, 580, 584, 584, 584, 589, 591, 591, 591, 591, 591, 593, 593, 593, 593, 593, 593, 593, 593, 593, 593, 593, 595, 599, 599, 600, 600, 600, 600, 601, 605, 605, 606, 606, 606, 606, 607, 607, 607, 607, 611, 611, 611, 615, 615, 615, 616, 616, 616, 617, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 619, 620, 621, 621, 622, 622, 625, 625, 625, 625, 625, 625, 625, 627, 627, 627, 630, 630, 630, 630, 630, 630, 630, 630, 630, 630, 630, 630, 630, 635, 635, 635, 635, 635, 635, 638, 638, 638, 640, 640, 640, 640, 640, 640, 640, 640, 640, 640, 640, 640, 641, 641, 641, 641, 0, 641, 641, 641, 0, 0, 642, 642, 642, 644, 644, 644, 646, 647, 650, 650, 650, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 652, 653, 653, 653, 655, 655, 655, 657, 659, 659, 659, 659, 659, 659, 659, 661, 661, 661, 661, 661, 661, 663, 663, 663, 669, 669, 670, 670, 672, 677, 677, 678, 678, 678, 678, 679, 679, 679, 679, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 384, 443, 448, 449, 450, 451, 454, 455, 457, 458, 459, 460, 461, 462, 463, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 482, 483, 484, 485, 486, 487, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 605, 606, 607, 608, 609, 610, 614, 615, 619, 620, 624, 625, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 704, 705, 706, 711, 712, 715, 716, 717, 718, 720, 723, 724, 725, 726, 728, 731, 732, 736, 746, 747, 748, 749, 751, 752, 753, 755, 756, 766, 767, 768, 769, 770, 771, 772, 773, 783, 784, 785, 786, 788, 789, 790, 793, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 930, 931, 936, 937, 938, 939, 940, 941, 944, 945, 946, 947, 948, 949, 950, 965, 966, 968, 971, 973, 974, 975, 976, 977, 978, 979, 980, 984, 985, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1239, 1240, 1241, 1243, 1244, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1259, 1260, 1261, 1262, 1263, 1264, 1271, 1272, 1273, 1274, 1278, 1279, 1283, 1284, 1288, 1289, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1339, 1340, 1346, 1347, 1348, 1349, 1365, 1366, 1368, 1371, 1372, 1373, 1374, 1379, 1380, 1383, 1387, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1398, 1400, 1408, 1410, 1411, 1413, 1414, 1420, 1422, 1423, 1424, 1425, 1436, 1438, 1439, 1440, 1441, 1442, 1443, 1448, 1449, 1450, 1451, 1452, 1472, 1473, 1474, 1475, 1476, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1603, 1604, 1605, 1606, 1607, 1608, 1609, 1610, 1611, 1612, 1613, 1614, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1648, 1649, 1650, 1651, 1651, 1654, 1656, 1658, 1661, 1662, 1664, 1665, 1666, 1667, 1673, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1681, 1684, 1686, 1688, 1691, 1692, 1694, 1695, 1696, 1697, 1703, 1704, 1705, 1706, 1707, 1708, 1709, 1710, 1711, 1712, 1713, 1714, 1715, 1717, 1718, 1719, 1720, 1721, 1722, 1725, 1726, 1727, 1728, 1729, 1730, 1732, 1733, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1770, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1856, 1861, 1862, 1863, 1864, 1865, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1881, 1882, 1883, 1884, 1889, 1890, 1891, 1892, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1904, 1905, 1906, 1907, 1907, 1910, 1912, 1913, 1914, 1915, 1916, 1917, 1918, 1919, 1920, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1939, 1940, 1941, 1942, 1942, 1945, 1947, 1948, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1962, 1963, 1964, 1966, 1967, 1968, 1969, 1969, 1972, 1974, 1975, 1976, 1977, 1978, 1979, 1980, 1981, 1982, 1993, 1994, 2037, 2042, 2043, 2044, 2045, 2046, 2047, 2052, 2053, 2054, 2055, 2057, 2058, 2059, 2060, 2061, 2062, 2063, 2064, 2066, 2067, 2068, 2069, 2069, 2072, 2074, 2075, 2076, 2077, 2078, 2079, 2080, 2081, 2082, 2089, 2090, 2091, 2092, 2093, 2094, 2096, 2097, 2098, 2099, 2099, 2102, 2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112, 2113, 2114, 2122, 2127, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2139, 2140, 2147, 2148, 2149, 2150, 2151, 2173, 2174, 2175, 2176, 2177, 2178, 2179, 2180, 2181, 2181, 2184, 2186, 2188, 2191, 2192, 2194, 2195, 2196, 2197, 2198, 2199, 2205, 2206, 2207, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2285, 2286, 2287, 2395, 2396, 2397, 2398, 2399, 2400, 2401, 2402, 2403, 2404, 2405, 2406, 2407, 2408, 2409, 2410, 2411, 2412, 2413, 2414, 2415, 2416, 2417, 2418, 2419, 2421, 2422, 2424, 2425, 2426, 2427, 2428, 2429, 2430, 2431, 2432, 2433, 2434, 2435, 2436, 2437, 2438, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2452, 2453, 2454, 2455, 2456, 2457, 2458, 2459, 2460, 2461, 2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469, 2470, 2475, 2476, 2479, 2480, 2481, 2483, 2486, 2490, 2491, 2492, 2495, 2496, 2497, 2499, 2500, 2501, 2502, 2503, 2504, 2505, 2506, 2507, 2508, 2509, 2510, 2511, 2512, 2513, 2514, 2515, 2516, 2517, 2518, 2519, 2520, 2521, 2522, 2523, 2524, 2525, 2526, 2527, 2528, 2529, 2530, 2531, 2532, 2533, 2534, 2535, 2536, 2537, 2538, 2544, 2545, 2546, 2547, 2548, 2561, 2562, 2563, 2564, 2565, 2566, 2567, 2568, 2569, 2570, 2573, 2576, 2579, 2583, 2587, 2590, 2593, 2597, 2601, 2604, 2607, 2611, 2615, 2618, 2621, 2625, 2629, 2632, 2635, 2639, 2643, 2646, 2649, 2653, 2657, 2660, 2663, 2667, 2671, 2674, 2677, 2681, 2685, 2688, 2691, 2695, 2699, 2702, 2705, 2709, 2713, 2716, 2719, 2723, 2727, 2730, 2733, 2737, 2741, 2744, 2747, 2751};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 367
new 0 18 367
assign 1 19 368
new 0 19 368
assign 1 20 369
new 0 20 369
assign 1 22 370
new 0 22 370
assign 1 23 371
new 0 23 371
assign 1 24 372
new 0 24 372
assign 1 25 373
new 0 25 373
assign 1 26 374
new 0 26 374
new 1 30 375
assign 1 32 376
new 0 32 376
assign 1 33 377
new 0 33 377
assign 1 34 378
new 0 34 378
assign 1 35 379
new 0 35 379
assign 1 36 380
new 0 36 380
addValue 1 40 384
assign 1 44 443
def 1 44 448
assign 1 45 449
libNameGet 0 45 449
assign 1 45 450
relEmitName 1 45 450
assign 1 45 451
extend 1 45 451
assign 1 47 454
new 0 47 454
assign 1 47 455
extend 1 47 455
assign 1 49 457
new 0 49 457
assign 1 49 458
emitNameGet 0 49 458
assign 1 49 459
addValue 1 49 459
assign 1 49 460
addValue 1 49 460
assign 1 49 461
new 0 49 461
assign 1 49 462
addValue 1 49 462
assign 1 51 463
def 1 51 468
assign 1 52 469
new 0 52 469
addValue 1 52 470
assign 1 54 471
new 0 54 471
addValue 1 54 472
assign 1 56 473
new 0 56 473
assign 1 56 474
addValue 1 56 474
assign 1 56 475
libNameGet 0 56 475
assign 1 56 476
relEmitName 1 56 476
assign 1 56 477
addValue 1 56 477
assign 1 56 478
new 0 56 478
addValue 1 56 479
assign 1 58 482
new 0 58 482
addValue 1 58 483
assign 1 60 484
new 0 60 484
addValue 1 60 485
assign 1 62 486
new 0 62 486
addValue 1 62 487
assign 1 65 489
new 0 65 489
addValue 1 65 490
assign 1 67 491
new 0 67 491
addValue 1 67 492
write 1 69 493
write 1 71 494
write 1 73 495
clear 0 75 496
assign 1 77 497
new 0 77 497
write 1 77 498
assign 1 78 499
new 0 78 499
write 1 78 500
assign 1 79 501
new 0 79 501
write 1 79 502
assign 1 80 503
new 0 80 503
assign 1 80 504
emitNameGet 0 80 504
assign 1 80 505
add 1 80 505
assign 1 80 506
new 0 80 506
assign 1 80 507
add 1 80 507
assign 1 80 508
getHeaderInitialInst 1 80 508
assign 1 80 509
add 1 80 509
assign 1 80 510
new 0 80 510
assign 1 80 511
add 1 80 511
write 1 80 512
assign 1 81 513
new 0 81 513
write 1 81 514
assign 1 82 515
new 0 82 515
write 1 82 516
assign 1 83 517
new 0 83 517
write 1 83 518
assign 1 84 519
new 0 84 519
write 1 84 520
assign 1 85 521
new 0 85 521
write 1 85 522
assign 1 86 523
new 0 86 523
write 1 86 524
assign 1 87 525
new 0 87 525
write 1 87 526
assign 1 88 527
new 0 88 527
assign 1 88 528
emitNameGet 0 88 528
assign 1 88 529
add 1 88 529
assign 1 88 530
new 0 88 530
assign 1 88 531
add 1 88 531
write 1 88 532
assign 1 90 533
new 0 90 533
assign 1 90 534
emitNameGet 0 90 534
assign 1 90 535
add 1 90 535
assign 1 90 536
new 0 90 536
assign 1 90 537
add 1 90 537
write 1 90 538
assign 1 92 539
new 0 92 539
return 1 92 540
assign 1 96 570
overrideMtdDecGet 0 96 570
assign 1 96 571
addValue 1 96 571
assign 1 96 572
getClassConfig 1 96 572
assign 1 96 573
libNameGet 0 96 573
assign 1 96 574
relEmitName 1 96 574
assign 1 96 575
addValue 1 96 575
assign 1 96 576
new 0 96 576
assign 1 96 577
addValue 1 96 577
assign 1 96 578
emitNameGet 0 96 578
assign 1 96 579
addValue 1 96 579
assign 1 96 580
new 0 96 580
assign 1 96 581
addValue 1 96 581
assign 1 96 582
addValue 1 96 582
assign 1 96 583
new 0 96 583
assign 1 96 584
addValue 1 96 584
addValue 1 96 585
assign 1 97 586
new 0 97 586
assign 1 97 587
addValue 1 97 587
assign 1 97 588
heldGet 0 97 588
assign 1 97 589
namepathGet 0 97 589
assign 1 97 590
getClassConfig 1 97 590
assign 1 97 591
libNameGet 0 97 591
assign 1 97 592
relEmitName 1 97 592
assign 1 97 593
addValue 1 97 593
assign 1 97 594
new 0 97 594
assign 1 97 595
addValue 1 97 595
addValue 1 97 596
assign 1 99 597
new 0 99 597
assign 1 99 598
addValue 1 99 598
addValue 1 99 599
assign 1 103 605
new 0 103 605
write 1 105 606
clear 0 106 607
assign 1 107 608
new 0 107 608
write 1 107 609
return 1 108 610
assign 1 112 614
new 0 112 614
return 1 112 615
assign 1 116 619
new 0 116 619
return 1 116 620
assign 1 120 624
new 0 120 624
return 1 120 625
assign 1 125 655
addValue 1 125 655
assign 1 125 656
libNameGet 0 125 656
assign 1 125 657
relEmitName 1 125 657
assign 1 125 658
addValue 1 125 658
assign 1 125 659
new 0 125 659
assign 1 125 660
addValue 1 125 660
assign 1 125 661
emitNameGet 0 125 661
assign 1 125 662
addValue 1 125 662
assign 1 125 663
new 0 125 663
assign 1 125 664
addValue 1 125 664
assign 1 125 665
addValue 1 125 665
assign 1 125 666
new 0 125 666
addValue 1 125 667
addValue 1 127 668
assign 1 129 669
new 0 129 669
assign 1 129 670
addValue 1 129 670
assign 1 129 671
addValue 1 129 671
assign 1 129 672
new 0 129 672
assign 1 129 673
addValue 1 129 673
addValue 1 129 674
assign 1 131 675
new 0 131 675
assign 1 131 676
addValue 1 131 676
assign 1 131 677
libNameGet 0 131 677
assign 1 131 678
relEmitName 1 131 678
assign 1 131 679
addValue 1 131 679
assign 1 131 680
new 0 131 680
assign 1 131 681
addValue 1 131 681
assign 1 131 682
addValue 1 131 682
assign 1 131 683
new 0 131 683
addValue 1 131 684
addValue 1 133 685
assign 1 135 686
new 0 135 686
addValue 1 135 687
assign 1 141 704
typenameGet 0 141 704
assign 1 141 705
NULLGet 0 141 705
assign 1 141 706
equals 1 141 711
assign 1 142 712
new 0 142 712
assign 1 143 715
heldGet 0 143 715
assign 1 143 716
nameGet 0 143 716
assign 1 143 717
new 0 143 717
assign 1 143 718
equals 1 143 718
assign 1 144 720
new 0 144 720
assign 1 145 723
heldGet 0 145 723
assign 1 145 724
nameGet 0 145 724
assign 1 145 725
new 0 145 725
assign 1 145 726
equals 1 145 726
assign 1 146 728
new 0 146 728
assign 1 148 731
heldGet 0 148 731
assign 1 148 732
nameForVar 1 148 732
return 1 150 736
assign 1 154 746
heldGet 0 154 746
assign 1 154 747
nameGet 0 154 747
assign 1 154 748
new 0 154 748
assign 1 154 749
equals 1 154 749
assign 1 155 751
new 0 155 751
assign 1 155 752
add 1 155 752
return 1 156 753
assign 1 158 755
formCallTarg 1 158 755
return 1 158 756
assign 1 162 766
new 0 162 766
assign 1 162 767
addValue 1 162 767
assign 1 162 768
secondGet 0 162 768
assign 1 162 769
formTarg 1 162 769
assign 1 162 770
addValue 1 162 770
assign 1 162 771
new 0 162 771
assign 1 162 772
addValue 1 162 772
addValue 1 162 773
assign 1 166 783
heldGet 0 166 783
assign 1 166 784
langsGet 0 166 784
assign 1 166 785
new 0 166 785
assign 1 166 786
has 1 166 786
assign 1 167 788
heldGet 0 167 788
assign 1 167 789
textGet 0 167 789
addValue 1 167 790
handleClassEmit 1 169 793
assign 1 175 835
new 0 175 835
assign 1 175 836
emitNameGet 0 175 836
assign 1 175 837
add 1 175 837
assign 1 175 838
new 0 175 838
assign 1 175 839
add 1 175 839
assign 1 177 840
new 0 177 840
assign 1 177 841
typeEmitNameGet 0 177 841
assign 1 177 842
add 1 177 842
assign 1 177 843
new 0 177 843
assign 1 177 844
add 1 177 844
assign 1 177 845
add 1 177 845
assign 1 177 846
new 0 177 846
assign 1 177 847
add 1 177 847
addClassHeader 1 179 848
assign 1 181 849
new 0 181 849
assign 1 183 850
typeEmitNameGet 0 183 850
assign 1 183 851
addValue 1 183 851
assign 1 183 852
new 0 183 852
assign 1 183 853
addValue 1 183 853
assign 1 183 854
emitNameGet 0 183 854
assign 1 183 855
addValue 1 183 855
assign 1 183 856
new 0 183 856
assign 1 183 857
addValue 1 183 857
assign 1 183 858
addValue 1 183 858
assign 1 183 859
new 0 183 859
addValue 1 183 860
assign 1 185 861
new 0 185 861
assign 1 185 862
addValue 1 185 862
assign 1 185 863
typeEmitNameGet 0 185 863
assign 1 185 864
addValue 1 185 864
assign 1 185 865
new 0 185 865
assign 1 185 866
addValue 1 185 866
assign 1 185 867
emitNameGet 0 185 867
assign 1 185 868
addValue 1 185 868
assign 1 185 869
new 0 185 869
assign 1 185 870
emitNameGet 0 185 870
assign 1 185 871
add 1 185 871
assign 1 185 872
new 0 185 872
assign 1 185 873
add 1 185 873
addValue 1 185 874
return 1 187 875
assign 1 192 895
new 0 192 895
assign 1 192 896
toString 0 192 896
assign 1 192 897
add 1 192 897
incrementValue 0 193 898
assign 1 194 899
new 0 194 899
assign 1 194 900
addValue 1 194 900
assign 1 194 901
addValue 1 194 901
assign 1 194 902
new 0 194 902
assign 1 194 903
addValue 1 194 903
addValue 1 194 904
assign 1 196 905
containedGet 0 196 905
assign 1 196 906
firstGet 0 196 906
assign 1 196 907
containedGet 0 196 907
assign 1 196 908
firstGet 0 196 908
assign 1 196 909
new 0 196 909
assign 1 196 910
add 1 196 910
assign 1 196 911
new 0 196 911
assign 1 196 912
add 1 196 912
assign 1 196 913
finalAssign 4 196 913
addValue 1 196 914
assign 1 200 930
isTypedGet 0 200 930
assign 1 200 931
not 0 200 936
assign 1 201 937
libNameGet 0 201 937
assign 1 201 938
relEmitName 1 201 938
assign 1 201 939
addValue 1 201 939
assign 1 201 940
new 0 201 940
addValue 1 201 941
assign 1 203 944
namepathGet 0 203 944
assign 1 203 945
getClassConfig 1 203 945
assign 1 203 946
libNameGet 0 203 946
assign 1 203 947
relEmitName 1 203 947
assign 1 203 948
addValue 1 203 948
assign 1 203 949
new 0 203 949
addValue 1 203 950
assign 1 208 965
new 0 208 965
assign 1 208 966
equals 1 208 966
assign 1 209 968
new 0 209 968
assign 1 211 971
new 0 211 971
assign 1 213 973
new 0 213 973
assign 1 213 974
add 1 213 974
assign 1 213 975
libNameGet 0 213 975
assign 1 213 976
relEmitName 1 213 976
assign 1 213 977
add 1 213 977
assign 1 213 978
new 0 213 978
assign 1 213 979
add 1 213 979
return 1 213 980
assign 1 218 984
new 0 218 984
return 1 218 985
assign 1 222 1012
overrideMtdDecGet 0 222 1012
assign 1 222 1013
addValue 1 222 1013
assign 1 222 1014
new 0 222 1014
assign 1 222 1015
addValue 1 222 1015
assign 1 222 1016
emitNameGet 0 222 1016
assign 1 222 1017
addValue 1 222 1017
assign 1 222 1018
new 0 222 1018
assign 1 222 1019
addValue 1 222 1019
assign 1 222 1020
addValue 1 222 1020
assign 1 222 1021
new 0 222 1021
assign 1 222 1022
addValue 1 222 1022
assign 1 222 1023
addValue 1 222 1023
assign 1 222 1024
new 0 222 1024
assign 1 222 1025
addValue 1 222 1025
addValue 1 222 1026
assign 1 223 1027
new 0 223 1027
assign 1 223 1028
addValue 1 223 1028
assign 1 223 1029
addValue 1 223 1029
assign 1 223 1030
new 0 223 1030
assign 1 223 1031
addValue 1 223 1031
assign 1 223 1032
addValue 1 223 1032
assign 1 223 1033
new 0 223 1033
assign 1 223 1034
addValue 1 223 1034
addValue 1 223 1035
assign 1 225 1036
new 0 225 1036
assign 1 225 1037
addValue 1 225 1037
addValue 1 225 1038
assign 1 230 1070
new 0 230 1070
assign 1 230 1071
libNameGet 0 230 1071
assign 1 230 1072
relEmitName 1 230 1072
assign 1 230 1073
add 1 230 1073
assign 1 230 1074
new 0 230 1074
assign 1 230 1075
add 1 230 1075
assign 1 230 1076
heldGet 0 230 1076
assign 1 230 1077
literalValueGet 0 230 1077
assign 1 230 1078
add 1 230 1078
assign 1 230 1079
new 0 230 1079
assign 1 230 1080
add 1 230 1080
return 1 230 1081
assign 1 232 1083
new 0 232 1083
assign 1 232 1084
libNameGet 0 232 1084
assign 1 232 1085
relEmitName 1 232 1085
assign 1 232 1086
add 1 232 1086
assign 1 232 1087
new 0 232 1087
assign 1 232 1088
add 1 232 1088
assign 1 232 1089
libNameGet 0 232 1089
assign 1 232 1090
relEmitName 1 232 1090
assign 1 232 1091
add 1 232 1091
assign 1 232 1092
new 0 232 1092
assign 1 232 1093
add 1 232 1093
assign 1 232 1094
heldGet 0 232 1094
assign 1 232 1095
literalValueGet 0 232 1095
assign 1 232 1096
add 1 232 1096
assign 1 232 1097
new 0 232 1097
assign 1 232 1098
add 1 232 1098
return 1 233 1099
assign 1 238 1130
new 0 238 1130
assign 1 238 1131
libNameGet 0 238 1131
assign 1 238 1132
relEmitName 1 238 1132
assign 1 238 1133
add 1 238 1133
assign 1 238 1134
new 0 238 1134
assign 1 238 1135
add 1 238 1135
assign 1 238 1136
heldGet 0 238 1136
assign 1 238 1137
literalValueGet 0 238 1137
assign 1 238 1138
add 1 238 1138
assign 1 238 1139
new 0 238 1139
assign 1 238 1140
add 1 238 1140
return 1 238 1141
assign 1 240 1143
new 0 240 1143
assign 1 240 1144
libNameGet 0 240 1144
assign 1 240 1145
relEmitName 1 240 1145
assign 1 240 1146
add 1 240 1146
assign 1 240 1147
new 0 240 1147
assign 1 240 1148
add 1 240 1148
assign 1 240 1149
libNameGet 0 240 1149
assign 1 240 1150
relEmitName 1 240 1150
assign 1 240 1151
add 1 240 1151
assign 1 240 1152
new 0 240 1152
assign 1 240 1153
add 1 240 1153
assign 1 240 1154
heldGet 0 240 1154
assign 1 240 1155
literalValueGet 0 240 1155
assign 1 240 1156
add 1 240 1156
assign 1 240 1157
new 0 240 1157
assign 1 240 1158
add 1 240 1158
return 1 241 1159
assign 1 246 1194
new 0 246 1194
assign 1 246 1195
libNameGet 0 246 1195
assign 1 246 1196
relEmitName 1 246 1196
assign 1 246 1197
add 1 246 1197
assign 1 246 1198
new 0 246 1198
assign 1 246 1199
add 1 246 1199
assign 1 246 1200
add 1 246 1200
assign 1 246 1201
new 0 246 1201
assign 1 246 1202
add 1 246 1202
assign 1 246 1203
add 1 246 1203
assign 1 246 1204
new 0 246 1204
assign 1 246 1205
add 1 246 1205
return 1 246 1206
assign 1 249 1208
new 0 249 1208
assign 1 249 1209
add 1 249 1209
assign 1 249 1210
new 0 249 1210
assign 1 249 1211
add 1 249 1211
assign 1 249 1212
add 1 249 1212
assign 1 250 1213
new 0 250 1213
assign 1 250 1214
libNameGet 0 250 1214
assign 1 250 1215
relEmitName 1 250 1215
assign 1 250 1216
add 1 250 1216
assign 1 250 1217
new 0 250 1217
assign 1 250 1218
add 1 250 1218
assign 1 250 1219
libNameGet 0 250 1219
assign 1 250 1220
relEmitName 1 250 1220
assign 1 250 1221
add 1 250 1221
assign 1 250 1222
new 0 250 1222
assign 1 250 1223
add 1 250 1223
assign 1 250 1224
add 1 250 1224
assign 1 250 1225
new 0 250 1225
assign 1 250 1226
add 1 250 1226
return 1 251 1227
incrementValue 0 255 1239
assign 1 256 1240
new 0 256 1240
assign 1 256 1241
notEmpty 1 256 1241
assign 1 257 1243
new 0 257 1243
addValue 1 257 1244
assign 1 259 1246
new 0 259 1246
assign 1 259 1247
addValue 1 259 1247
addValue 1 259 1248
assign 1 260 1249
new 0 260 1249
assign 1 260 1250
add 1 260 1250
assign 1 260 1251
new 0 260 1251
assign 1 260 1252
add 1 260 1252
return 1 260 1253
getCode 2 265 1259
assign 1 266 1260
toHexString 1 266 1260
assign 1 267 1261
new 0 267 1261
assign 1 267 1262
once 0 267 1262
addValue 1 267 1263
addValue 1 268 1264
assign 1 274 1271
new 0 274 1271
assign 1 274 1272
add 1 274 1272
assign 1 274 1273
add 1 274 1273
return 1 274 1274
assign 1 278 1278
new 0 278 1278
return 1 278 1279
assign 1 282 1283
new 0 282 1283
return 1 282 1284
assign 1 287 1288
new 0 287 1288
return 1 287 1289
assign 1 291 1312
new 0 291 1312
assign 1 291 1313
add 1 291 1313
assign 1 291 1314
new 0 291 1314
assign 1 291 1315
add 1 291 1315
assign 1 291 1316
add 1 291 1316
assign 1 292 1317
new 0 292 1317
assign 1 292 1318
addValue 1 292 1318
assign 1 292 1319
addValue 1 292 1319
assign 1 292 1320
new 0 292 1320
assign 1 292 1321
addValue 1 292 1321
addValue 1 292 1322
assign 1 293 1323
new 0 293 1323
assign 1 293 1324
addValue 1 293 1324
addValue 1 293 1325
assign 1 294 1326
new 0 294 1326
assign 1 294 1327
addValue 1 294 1327
assign 1 294 1328
outputPlatformGet 0 294 1328
assign 1 294 1329
nameGet 0 294 1329
assign 1 294 1330
addValue 1 294 1330
assign 1 294 1331
new 0 294 1331
assign 1 294 1332
addValue 1 294 1332
addValue 1 294 1333
assign 1 296 1334
new 0 296 1334
return 1 296 1335
assign 1 300 1339
new 0 300 1339
return 1 300 1340
assign 1 304 1346
new 0 304 1346
assign 1 304 1347
once 0 304 1347
assign 1 304 1348
add 1 304 1348
return 1 304 1349
assign 1 311 1365
assign 1 312 1366
singleCCGet 0 312 1366
assign 1 0 1368
assign 1 312 1371
classPathGet 0 312 1371
assign 1 312 1372
fileGet 0 312 1372
assign 1 312 1373
existsGet 0 312 1373
assign 1 312 1374
not 0 312 1379
assign 1 0 1380
assign 1 0 1383
return 1 313 1387
assign 1 315 1390
classPathGet 0 315 1390
assign 1 315 1391
fileGet 0 315 1391
assign 1 315 1392
lastUpdatedGet 0 315 1392
assign 1 316 1393
fromFileGet 0 316 1393
assign 1 316 1394
fileGet 0 316 1394
assign 1 316 1395
lastUpdatedGet 0 316 1395
assign 1 317 1396
greater 1 317 1396
return 1 320 1398
assign 1 323 1400
assign 1 328 1408
singleCCGet 0 328 1408
assign 1 329 1410
getLibOutput 0 329 1410
return 1 329 1411
assign 1 331 1413
getClassOutput 0 331 1413
return 1 331 1414
assign 1 335 1420
singleCCGet 0 335 1420
assign 1 336 1422
new 0 336 1422
assign 1 337 1423
countLines 1 337 1423
addValue 1 337 1424
write 1 338 1425
assign 1 343 1436
singleCCGet 0 343 1436
assign 1 345 1438
new 0 345 1438
assign 1 346 1439
countLines 1 346 1439
addValue 1 346 1440
write 1 347 1441
close 0 348 1442
assign 1 349 1443
def 1 349 1448
assign 1 350 1449
pathGet 0 350 1449
assign 1 350 1450
fileGet 0 350 1450
lastUpdatedSet 1 350 1451
assign 1 351 1452
assign 1 357 1472
new 0 357 1472
assign 1 358 1473
new 0 358 1473
assign 1 358 1474
addValue 1 358 1474
assign 1 358 1475
addValue 1 358 1475
assign 1 358 1476
new 0 358 1476
assign 1 358 1477
addValue 1 358 1477
assign 1 358 1478
addValue 1 358 1478
assign 1 358 1479
new 0 358 1479
assign 1 358 1480
addValue 1 358 1480
addValue 1 358 1481
assign 1 359 1482
addValue 1 359 1482
assign 1 359 1483
new 0 359 1483
assign 1 359 1484
addValue 1 359 1484
addValue 1 359 1485
assign 1 360 1486
new 0 360 1486
assign 1 360 1487
addValue 1 360 1487
addValue 1 360 1488
return 1 361 1489
assign 1 365 1603
new 0 365 1603
assign 1 365 1604
typeEmitNameGet 0 365 1604
assign 1 365 1605
add 1 365 1605
assign 1 365 1606
new 0 365 1606
assign 1 365 1607
add 1 365 1607
write 1 365 1608
assign 1 366 1609
new 0 366 1609
assign 1 367 1610
new 0 367 1610
assign 1 367 1611
addValue 1 367 1611
assign 1 367 1612
typeEmitNameGet 0 367 1612
assign 1 367 1613
addValue 1 367 1613
assign 1 367 1614
new 0 367 1614
addValue 1 367 1615
assign 1 368 1616
new 0 368 1616
addValue 1 368 1617
assign 1 369 1618
typeEmitNameGet 0 369 1618
assign 1 369 1619
addValue 1 369 1619
assign 1 369 1620
new 0 369 1620
addValue 1 369 1621
assign 1 370 1622
new 0 370 1622
addValue 1 370 1623
assign 1 371 1624
new 0 371 1624
addValue 1 371 1625
assign 1 372 1626
new 0 372 1626
assign 1 372 1627
addValue 1 372 1627
assign 1 372 1628
addValue 1 372 1628
assign 1 372 1629
new 0 372 1629
addValue 1 372 1630
assign 1 373 1631
new 0 373 1631
addValue 1 373 1632
assign 1 374 1633
new 0 374 1633
addValue 1 374 1634
assign 1 375 1635
new 0 375 1635
addValue 1 375 1636
write 1 376 1637
assign 1 378 1638
new 0 378 1638
assign 1 379 1639
typeEmitNameGet 0 379 1639
assign 1 379 1640
addValue 1 379 1640
assign 1 379 1641
new 0 379 1641
assign 1 379 1642
addValue 1 379 1642
assign 1 379 1643
typeEmitNameGet 0 379 1643
assign 1 379 1644
addValue 1 379 1644
assign 1 379 1645
new 0 379 1645
addValue 1 379 1646
assign 1 380 1647
new 0 380 1647
addValue 1 380 1648
assign 1 381 1649
new 0 381 1649
assign 1 382 1650
mtdListGet 0 382 1650
assign 1 382 1651
iteratorGet 0 0 1651
assign 1 382 1654
hasNextGet 0 382 1654
assign 1 382 1656
nextGet 0 382 1656
assign 1 384 1658
new 0 384 1658
assign 1 386 1661
new 0 386 1661
addValue 1 386 1662
assign 1 388 1664
addValue 1 388 1664
assign 1 388 1665
nameGet 0 388 1665
assign 1 388 1666
addValue 1 388 1666
addValue 1 388 1667
assign 1 390 1673
new 0 390 1673
addValue 1 390 1674
assign 1 391 1675
new 0 391 1675
addValue 1 391 1676
assign 1 393 1677
new 0 393 1677
addValue 1 393 1678
assign 1 394 1679
new 0 394 1679
assign 1 395 1680
ptyListGet 0 395 1680
assign 1 395 1681
iteratorGet 0 0 1681
assign 1 395 1684
hasNextGet 0 395 1684
assign 1 395 1686
nextGet 0 395 1686
assign 1 397 1688
new 0 397 1688
assign 1 399 1691
new 0 399 1691
addValue 1 399 1692
assign 1 401 1694
addValue 1 401 1694
assign 1 401 1695
nameGet 0 401 1695
assign 1 401 1696
addValue 1 401 1696
addValue 1 401 1697
assign 1 403 1703
new 0 403 1703
addValue 1 403 1704
assign 1 405 1705
new 0 405 1705
addValue 1 405 1706
assign 1 407 1707
new 0 407 1707
assign 1 407 1708
addValue 1 407 1708
assign 1 407 1709
typeEmitNameGet 0 407 1709
assign 1 407 1710
addValue 1 407 1710
assign 1 407 1711
new 0 407 1711
addValue 1 407 1712
assign 1 408 1713
emitNameGet 0 408 1713
assign 1 408 1714
new 0 408 1714
assign 1 408 1715
equals 1 408 1715
assign 1 409 1717
new 0 409 1717
assign 1 409 1718
addValue 1 409 1718
assign 1 409 1719
emitNameGet 0 409 1719
assign 1 409 1720
addValue 1 409 1720
assign 1 409 1721
new 0 409 1721
addValue 1 409 1722
assign 1 411 1725
new 0 411 1725
assign 1 411 1726
addValue 1 411 1726
assign 1 411 1727
emitNameGet 0 411 1727
assign 1 411 1728
addValue 1 411 1728
assign 1 411 1729
new 0 411 1729
addValue 1 411 1730
assign 1 413 1732
new 0 413 1732
addValue 1 413 1733
assign 1 415 1734
new 0 415 1734
assign 1 415 1735
addValue 1 415 1735
assign 1 415 1736
typeEmitNameGet 0 415 1736
assign 1 415 1737
addValue 1 415 1737
assign 1 415 1738
new 0 415 1738
addValue 1 415 1739
assign 1 416 1740
new 0 416 1740
addValue 1 416 1741
assign 1 417 1742
new 0 417 1742
assign 1 417 1743
genMark 1 417 1743
addValue 1 417 1744
assign 1 418 1745
new 0 418 1745
addValue 1 418 1746
assign 1 419 1747
new 0 419 1747
addValue 1 419 1748
assign 1 420 1749
new 0 420 1749
assign 1 420 1750
genMark 1 420 1750
addValue 1 420 1751
assign 1 421 1752
new 0 421 1752
addValue 1 421 1753
assign 1 422 1754
new 0 422 1754
addValue 1 422 1755
assign 1 424 1756
new 0 424 1756
assign 1 424 1757
addValue 1 424 1757
assign 1 424 1758
typeEmitNameGet 0 424 1758
assign 1 424 1759
addValue 1 424 1759
assign 1 424 1760
new 0 424 1760
assign 1 424 1761
addValue 1 424 1761
assign 1 424 1762
addValue 1 424 1762
assign 1 424 1763
new 0 424 1763
assign 1 424 1764
addValue 1 424 1764
assign 1 424 1765
addValue 1 424 1765
assign 1 424 1766
new 0 424 1766
assign 1 424 1767
addValue 1 424 1767
addValue 1 424 1768
assign 1 425 1769
new 0 425 1769
assign 1 425 1770
addValue 1 425 1770
assign 1 425 1771
typeEmitNameGet 0 425 1771
assign 1 425 1772
addValue 1 425 1772
assign 1 425 1773
new 0 425 1773
assign 1 425 1774
addValue 1 425 1774
assign 1 425 1775
addValue 1 425 1775
assign 1 425 1776
new 0 425 1776
addValue 1 425 1777
clear 0 426 1778
assign 1 427 1779
new 0 427 1779
assign 1 429 1780
getClassOutput 0 429 1780
write 1 429 1781
assign 1 430 1782
countLines 1 430 1782
addValue 1 430 1783
assign 1 442 1856
undef 1 442 1861
assign 1 443 1862
libNameGet 0 443 1862
assign 1 444 1863
new 0 444 1863
assign 1 444 1864
sizeGet 0 444 1864
assign 1 444 1865
add 1 444 1865
assign 1 444 1866
new 0 444 1866
assign 1 444 1867
add 1 444 1867
assign 1 444 1868
add 1 444 1868
assign 1 444 1869
add 1 444 1869
assign 1 445 1870
new 0 445 1870
assign 1 445 1871
sizeGet 0 445 1871
assign 1 445 1872
add 1 445 1872
assign 1 445 1873
new 0 445 1873
assign 1 445 1874
add 1 445 1874
assign 1 445 1875
add 1 445 1875
assign 1 445 1876
add 1 445 1876
assign 1 446 1877
parentGet 0 446 1877
assign 1 446 1878
addStep 1 446 1878
assign 1 447 1879
parentGet 0 447 1879
assign 1 447 1880
addStep 1 447 1880
assign 1 448 1881
parentGet 0 448 1881
assign 1 448 1882
fileGet 0 448 1882
assign 1 448 1883
existsGet 0 448 1883
assign 1 448 1884
not 0 448 1889
assign 1 449 1890
parentGet 0 449 1890
assign 1 449 1891
fileGet 0 449 1891
makeDirs 0 449 1892
assign 1 451 1894
fileGet 0 451 1894
assign 1 451 1895
writerGet 0 451 1895
assign 1 451 1896
open 0 451 1896
assign 1 452 1897
fileGet 0 452 1897
assign 1 452 1898
writerGet 0 452 1898
assign 1 452 1899
open 0 452 1899
assign 1 454 1900
paramsGet 0 454 1900
assign 1 454 1901
new 0 454 1901
assign 1 454 1902
has 1 454 1902
assign 1 456 1904
paramsGet 0 456 1904
assign 1 456 1905
new 0 456 1905
assign 1 456 1906
get 1 456 1906
assign 1 456 1907
iteratorGet 0 0 1907
assign 1 456 1910
hasNextGet 0 456 1910
assign 1 456 1912
nextGet 0 456 1912
assign 1 458 1913
apNew 1 458 1913
assign 1 458 1914
fileGet 0 458 1914
assign 1 459 1915
readerGet 0 459 1915
assign 1 459 1916
open 0 459 1916
assign 1 459 1917
readString 0 459 1917
assign 1 460 1918
readerGet 0 460 1918
close 0 460 1919
write 1 462 1920
assign 1 466 1927
new 0 466 1927
write 1 466 1928
assign 1 467 1929
new 0 467 1929
write 1 467 1930
assign 1 469 1931
new 0 469 1931
write 1 469 1932
assign 1 470 1933
new 0 470 1933
write 1 470 1934
assign 1 476 1935
paramsGet 0 476 1935
assign 1 476 1936
new 0 476 1936
assign 1 476 1937
has 1 476 1937
assign 1 478 1939
paramsGet 0 478 1939
assign 1 478 1940
new 0 478 1940
assign 1 478 1941
get 1 478 1941
assign 1 478 1942
iteratorGet 0 0 1942
assign 1 478 1945
hasNextGet 0 478 1945
assign 1 478 1947
nextGet 0 478 1947
assign 1 480 1948
apNew 1 480 1948
assign 1 480 1949
fileGet 0 480 1949
assign 1 481 1950
readerGet 0 481 1950
assign 1 481 1951
open 0 481 1951
assign 1 481 1952
readString 0 481 1952
assign 1 482 1953
readerGet 0 482 1953
close 0 482 1954
write 1 484 1955
assign 1 487 1962
paramsGet 0 487 1962
assign 1 487 1963
new 0 487 1963
assign 1 487 1964
has 1 487 1964
assign 1 489 1966
paramsGet 0 489 1966
assign 1 489 1967
new 0 489 1967
assign 1 489 1968
get 1 489 1968
assign 1 489 1969
iteratorGet 0 0 1969
assign 1 489 1972
hasNextGet 0 489 1972
assign 1 489 1974
nextGet 0 489 1974
assign 1 491 1975
apNew 1 491 1975
assign 1 491 1976
fileGet 0 491 1976
assign 1 492 1977
readerGet 0 492 1977
assign 1 492 1978
open 0 492 1978
assign 1 492 1979
readString 0 492 1979
assign 1 493 1980
readerGet 0 493 1980
close 0 493 1981
write 1 495 1982
begin 1 502 1993
prepHeaderOutput 0 503 1994
assign 1 508 2037
undef 1 508 2042
assign 1 509 2043
new 0 509 2043
assign 1 510 2044
parentGet 0 510 2044
assign 1 510 2045
fileGet 0 510 2045
assign 1 510 2046
existsGet 0 510 2046
assign 1 510 2047
not 0 510 2052
assign 1 511 2053
parentGet 0 511 2053
assign 1 511 2054
fileGet 0 511 2054
makeDirs 0 511 2055
assign 1 513 2057
fileGet 0 513 2057
assign 1 513 2058
writerGet 0 513 2058
assign 1 513 2059
open 0 513 2059
assign 1 515 2060
new 0 515 2060
write 1 515 2061
assign 1 517 2062
paramsGet 0 517 2062
assign 1 517 2063
new 0 517 2063
assign 1 517 2064
has 1 517 2064
assign 1 519 2066
paramsGet 0 519 2066
assign 1 519 2067
new 0 519 2067
assign 1 519 2068
get 1 519 2068
assign 1 519 2069
iteratorGet 0 0 2069
assign 1 519 2072
hasNextGet 0 519 2072
assign 1 519 2074
nextGet 0 519 2074
assign 1 521 2075
apNew 1 521 2075
assign 1 521 2076
fileGet 0 521 2076
assign 1 522 2077
readerGet 0 522 2077
assign 1 522 2078
open 0 522 2078
assign 1 522 2079
readString 0 522 2079
assign 1 523 2080
readerGet 0 523 2080
close 0 523 2081
write 1 525 2082
assign 1 529 2089
new 0 529 2089
write 1 529 2090
increment 0 530 2091
assign 1 531 2092
paramsGet 0 531 2092
assign 1 531 2093
new 0 531 2093
assign 1 531 2094
has 1 531 2094
assign 1 532 2096
paramsGet 0 532 2096
assign 1 532 2097
new 0 532 2097
assign 1 532 2098
get 1 532 2098
assign 1 532 2099
iteratorGet 0 0 2099
assign 1 532 2102
hasNextGet 0 532 2102
assign 1 532 2104
nextGet 0 532 2104
assign 1 533 2105
apNew 1 533 2105
assign 1 533 2106
fileGet 0 533 2106
assign 1 534 2107
readerGet 0 534 2107
assign 1 534 2108
open 0 534 2108
assign 1 534 2109
readString 0 534 2109
assign 1 535 2110
readerGet 0 535 2110
close 0 535 2111
assign 1 536 2112
countLines 1 536 2112
addValue 1 536 2113
write 1 537 2114
return 1 543 2122
close 0 547 2127
assign 1 548 2128
assign 1 550 2129
new 0 550 2129
write 1 550 2130
assign 1 552 2131
new 0 552 2131
write 1 552 2132
close 0 553 2133
close 0 554 2134
assign 1 559 2139
new 0 559 2139
return 1 559 2140
assign 1 563 2147
new 0 563 2147
assign 1 563 2148
addValue 1 563 2148
assign 1 563 2149
addValue 1 563 2149
assign 1 563 2150
new 0 563 2150
addValue 1 563 2151
assign 1 568 2173
heldGet 0 568 2173
assign 1 568 2174
synGet 0 568 2174
assign 1 569 2175
ptyListGet 0 569 2175
assign 1 571 2176
emitNameGet 0 571 2176
assign 1 571 2177
addValue 1 571 2177
assign 1 571 2178
new 0 571 2178
addValue 1 571 2179
assign 1 573 2180
new 0 573 2180
assign 1 574 2181
iteratorGet 0 0 2181
assign 1 574 2184
hasNextGet 0 574 2184
assign 1 574 2186
nextGet 0 574 2186
assign 1 576 2188
new 0 576 2188
assign 1 578 2191
new 0 578 2191
addValue 1 578 2192
assign 1 580 2194
addValue 1 580 2194
assign 1 580 2195
new 0 580 2195
assign 1 580 2196
addValue 1 580 2196
assign 1 580 2197
nameGet 0 580 2197
assign 1 580 2198
addValue 1 580 2198
addValue 1 580 2199
assign 1 584 2205
new 0 584 2205
assign 1 584 2206
addValue 1 584 2206
addValue 1 584 2207
assign 1 589 2227
new 0 589 2227
assign 1 591 2228
new 0 591 2228
assign 1 591 2229
emitNameGet 0 591 2229
assign 1 591 2230
add 1 591 2230
assign 1 591 2231
new 0 591 2231
assign 1 591 2232
add 1 591 2232
assign 1 593 2233
emitNameGet 0 593 2233
assign 1 593 2234
addValue 1 593 2234
assign 1 593 2235
new 0 593 2235
assign 1 593 2236
addValue 1 593 2236
assign 1 593 2237
emitNameGet 0 593 2237
assign 1 593 2238
addValue 1 593 2238
assign 1 593 2239
new 0 593 2239
assign 1 593 2240
addValue 1 593 2240
assign 1 593 2241
addValue 1 593 2241
assign 1 593 2242
new 0 593 2242
addValue 1 593 2243
return 1 595 2244
assign 1 599 2253
libNameGet 0 599 2253
assign 1 599 2254
relEmitName 1 599 2254
assign 1 600 2255
new 0 600 2255
assign 1 600 2256
add 1 600 2256
assign 1 600 2257
new 0 600 2257
assign 1 600 2258
add 1 600 2258
return 1 601 2259
assign 1 605 2271
libNameGet 0 605 2271
assign 1 605 2272
relEmitName 1 605 2272
assign 1 606 2273
new 0 606 2273
assign 1 606 2274
add 1 606 2274
assign 1 606 2275
new 0 606 2275
assign 1 606 2276
add 1 606 2276
assign 1 607 2277
new 0 607 2277
assign 1 607 2278
add 1 607 2278
assign 1 607 2279
add 1 607 2279
return 1 607 2280
assign 1 611 2285
new 0 611 2285
assign 1 611 2286
add 1 611 2286
return 1 611 2287
assign 1 615 2395
getClassConfig 1 615 2395
assign 1 615 2396
libNameGet 0 615 2396
assign 1 615 2397
relEmitName 1 615 2397
assign 1 616 2398
heldGet 0 616 2398
assign 1 616 2399
namepathGet 0 616 2399
assign 1 616 2400
getClassConfig 1 616 2400
assign 1 617 2401
getInitialInst 1 617 2401
assign 1 619 2402
overrideMtdDecGet 0 619 2402
assign 1 619 2403
addValue 1 619 2403
assign 1 619 2404
new 0 619 2404
assign 1 619 2405
addValue 1 619 2405
assign 1 619 2406
emitNameGet 0 619 2406
assign 1 619 2407
addValue 1 619 2407
assign 1 619 2408
new 0 619 2408
assign 1 619 2409
addValue 1 619 2409
assign 1 619 2410
addValue 1 619 2410
assign 1 619 2411
new 0 619 2411
assign 1 619 2412
addValue 1 619 2412
assign 1 619 2413
addValue 1 619 2413
assign 1 619 2414
new 0 619 2414
assign 1 619 2415
addValue 1 619 2415
addValue 1 619 2416
assign 1 620 2417
new 0 620 2417
assign 1 621 2418
emitNameGet 0 621 2418
assign 1 621 2419
notEquals 1 621 2419
assign 1 622 2421
new 0 622 2421
assign 1 622 2422
formCast 3 622 2422
assign 1 625 2424
addValue 1 625 2424
assign 1 625 2425
new 0 625 2425
assign 1 625 2426
addValue 1 625 2426
assign 1 625 2427
addValue 1 625 2427
assign 1 625 2428
new 0 625 2428
assign 1 625 2429
addValue 1 625 2429
addValue 1 625 2430
assign 1 627 2431
new 0 627 2431
assign 1 627 2432
addValue 1 627 2432
addValue 1 627 2433
assign 1 630 2434
overrideMtdDecGet 0 630 2434
assign 1 630 2435
addValue 1 630 2435
assign 1 630 2436
addValue 1 630 2436
assign 1 630 2437
new 0 630 2437
assign 1 630 2438
addValue 1 630 2438
assign 1 630 2439
emitNameGet 0 630 2439
assign 1 630 2440
addValue 1 630 2440
assign 1 630 2441
new 0 630 2441
assign 1 630 2442
addValue 1 630 2442
assign 1 630 2443
addValue 1 630 2443
assign 1 630 2444
new 0 630 2444
assign 1 630 2445
addValue 1 630 2445
addValue 1 630 2446
assign 1 635 2447
new 0 635 2447
assign 1 635 2448
addValue 1 635 2448
assign 1 635 2449
addValue 1 635 2449
assign 1 635 2450
new 0 635 2450
assign 1 635 2451
addValue 1 635 2451
addValue 1 635 2452
assign 1 638 2453
new 0 638 2453
assign 1 638 2454
addValue 1 638 2454
addValue 1 638 2455
assign 1 640 2456
overrideMtdDecGet 0 640 2456
assign 1 640 2457
addValue 1 640 2457
assign 1 640 2458
new 0 640 2458
assign 1 640 2459
addValue 1 640 2459
assign 1 640 2460
emitNameGet 0 640 2460
assign 1 640 2461
addValue 1 640 2461
assign 1 640 2462
new 0 640 2462
assign 1 640 2463
addValue 1 640 2463
assign 1 640 2464
addValue 1 640 2464
assign 1 640 2465
new 0 640 2465
assign 1 640 2466
addValue 1 640 2466
addValue 1 640 2467
assign 1 641 2468
heldGet 0 641 2468
assign 1 641 2469
extendsGet 0 641 2469
assign 1 641 2470
undef 1 641 2475
assign 1 0 2476
assign 1 641 2479
heldGet 0 641 2479
assign 1 641 2480
extendsGet 0 641 2480
assign 1 641 2481
equals 1 641 2481
assign 1 0 2483
assign 1 0 2486
assign 1 642 2490
new 0 642 2490
assign 1 642 2491
addValue 1 642 2491
addValue 1 642 2492
assign 1 644 2495
new 0 644 2495
assign 1 644 2496
addValue 1 644 2496
addValue 1 644 2497
addValue 1 646 2499
clear 0 647 2500
assign 1 650 2501
new 0 650 2501
assign 1 650 2502
addValue 1 650 2502
addValue 1 650 2503
assign 1 652 2504
overrideMtdDecGet 0 652 2504
assign 1 652 2505
addValue 1 652 2505
assign 1 652 2506
new 0 652 2506
assign 1 652 2507
addValue 1 652 2507
assign 1 652 2508
emitNameGet 0 652 2508
assign 1 652 2509
addValue 1 652 2509
assign 1 652 2510
new 0 652 2510
assign 1 652 2511
addValue 1 652 2511
assign 1 652 2512
addValue 1 652 2512
assign 1 652 2513
new 0 652 2513
assign 1 652 2514
addValue 1 652 2514
addValue 1 652 2515
assign 1 653 2516
new 0 653 2516
assign 1 653 2517
addValue 1 653 2517
addValue 1 653 2518
assign 1 655 2519
new 0 655 2519
assign 1 655 2520
addValue 1 655 2520
addValue 1 655 2521
assign 1 657 2522
getTypeInst 1 657 2522
assign 1 659 2523
new 0 659 2523
assign 1 659 2524
addValue 1 659 2524
assign 1 659 2525
emitNameGet 0 659 2525
assign 1 659 2526
addValue 1 659 2526
assign 1 659 2527
new 0 659 2527
assign 1 659 2528
addValue 1 659 2528
addValue 1 659 2529
assign 1 661 2530
new 0 661 2530
assign 1 661 2531
addValue 1 661 2531
assign 1 661 2532
addValue 1 661 2532
assign 1 661 2533
new 0 661 2533
assign 1 661 2534
addValue 1 661 2534
addValue 1 661 2535
assign 1 663 2536
new 0 663 2536
assign 1 663 2537
addValue 1 663 2537
addValue 1 663 2538
assign 1 669 2544
new 0 669 2544
write 1 669 2545
assign 1 670 2546
new 0 670 2546
write 1 670 2547
emitLib 0 672 2548
assign 1 677 2561
libNameGet 0 677 2561
assign 1 677 2562
relEmitName 1 677 2562
assign 1 678 2563
new 0 678 2563
assign 1 678 2564
add 1 678 2564
assign 1 678 2565
new 0 678 2565
assign 1 678 2566
add 1 678 2566
assign 1 679 2567
new 0 679 2567
assign 1 679 2568
add 1 679 2568
assign 1 679 2569
add 1 679 2569
return 1 679 2570
return 1 0 2573
return 1 0 2576
assign 1 0 2579
assign 1 0 2583
return 1 0 2587
return 1 0 2590
assign 1 0 2593
assign 1 0 2597
return 1 0 2601
return 1 0 2604
assign 1 0 2607
assign 1 0 2611
return 1 0 2615
return 1 0 2618
assign 1 0 2621
assign 1 0 2625
return 1 0 2629
return 1 0 2632
assign 1 0 2635
assign 1 0 2639
return 1 0 2643
return 1 0 2646
assign 1 0 2649
assign 1 0 2653
return 1 0 2657
return 1 0 2660
assign 1 0 2663
assign 1 0 2667
return 1 0 2671
return 1 0 2674
assign 1 0 2677
assign 1 0 2681
return 1 0 2685
return 1 0 2688
assign 1 0 2691
assign 1 0 2695
return 1 0 2699
return 1 0 2702
assign 1 0 2705
assign 1 0 2709
return 1 0 2713
return 1 0 2716
assign 1 0 2719
assign 1 0 2723
return 1 0 2727
return 1 0 2730
assign 1 0 2733
assign 1 0 2737
return 1 0 2741
return 1 0 2744
assign 1 0 2747
assign 1 0 2751
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -941547118: return bem_lastMethodsSizeGet_0();
case 97230952: return bem_libEmitNameGet_0();
case 436075888: return bem_lineCountGetDirect_0();
case -380226756: return bem_constGetDirect_0();
case 1377100999: return bem_dynMethodsGetDirect_0();
case 1240045385: return bem_setOutputTimeGet_0();
case 1901916547: return bem_onceDecsGetDirect_0();
case -1447122961: return bem_invpGetDirect_0();
case 1411843323: return bem_preClassGet_0();
case 582307875: return bem_preClassGetDirect_0();
case -61288189: return bem_serializationIteratorGet_0();
case 457760451: return bem_buildPropList_0();
case -629699645: return bem_fileExtGet_0();
case -948982310: return bem_many_0();
case -199778082: return bem_maxSpillArgsLenGet_0();
case -1569398019: return bem_maxDynArgsGetDirect_0();
case 742371580: return bem_serializeToString_0();
case -1797152602: return bem_qGet_0();
case 1225439890: return bem_instanceNotEqualGetDirect_0();
case -95265831: return bem_nameToIdGetDirect_0();
case -687815287: return bem_heowGetDirect_0();
case -2115535475: return bem_boolNpGet_0();
case 1433583073: return bem_classEmitsGet_0();
case -1439777293: return bem_hashGet_0();
case -244685365: return bem_classesInDepthOrderGetDirect_0();
case 261956701: return bem_nullValueGet_0();
case -5285599: return bem_intNpGet_0();
case -1191677393: return bem_trueValueGetDirect_0();
case -1528004109: return bem_typeDecGet_0();
case -1999181502: return bem_synEmitPathGet_0();
case 1530543851: return bem_randGet_0();
case -1865605321: return bem_onceDecRefsCountGet_0();
case 317621722: return bem_methodBodyGet_0();
case 1249212658: return bem_lastMethodBodySizeGet_0();
case 688699882: return bem_methodCatchGet_0();
case -1234683771: return bem_methodBodyGetDirect_0();
case 1738849852: return bem_scvpGetDirect_0();
case -221281422: return bem_initialDecGet_0();
case -150559380: return bem_deopGet_0();
case 464848627: return bem_methodCallsGetDirect_0();
case 167637252: return bem_mnodeGet_0();
case 1963837533: return bem_classHeadersGetDirect_0();
case 198915418: return bem_boolCcGetDirect_0();
case -248198855: return bem_doEmit_0();
case -1641579125: return bem_transGet_0();
case -273141546: return bem_libEmitPathGet_0();
case -514516007: return bem_heopGet_0();
case -289513057: return bem_invpGet_0();
case -944594213: return bem_fullLibEmitNameGetDirect_0();
case -355309285: return bem_mainInClassGet_0();
case -101967145: return bem_newDecGet_0();
case 1831686403: return bem_classHeadBodyGetDirect_0();
case -1371196098: return bem_deowGetDirect_0();
case -2073027086: return bem_fieldIteratorGet_0();
case -277742008: return bem_inClassGetDirect_0();
case 448071959: return bem_boolCcGet_0();
case 921650877: return bem_setOutputTimeGetDirect_0();
case -1863047507: return bem_spropDecGet_0();
case -222737348: return bem_emitLib_0();
case 1660533487: return bem_serializeContents_0();
case 1172450247: return bem_copy_0();
case 450230894: return bem_print_0();
case 225928131: return bem_useDynMethodsGet_0();
case 1320512377: return bem_nativeCSlotsGetDirect_0();
case -1078431593: return bem_lastMethodsLinesGetDirect_0();
case 1935136194: return bem_classNameGet_0();
case 597331846: return bem_intNpGetDirect_0();
case -938652026: return bem_objectNpGetDirect_0();
case -88814214: return bem_lastMethodBodySizeGetDirect_0();
case 1399418751: return bem_mainEndGet_0();
case -1659200791: return bem_propDecGet_0();
case 556232746: return bem_constGet_0();
case -980955129: return bem_fullLibEmitNameGet_0();
case -678019437: return bem_runtimeInitGet_0();
case 107872936: return bem_covariantReturnsGet_0();
case -812913132: return bem_onceDecRefsGet_0();
case -2046131563: return bem_idToNamePathGet_0();
case 2094042242: return bem_methodsGet_0();
case 1725307276: return bem_trueValueGet_0();
case -1556712456: return bem_new_0();
case -569588682: return bem_ccCacheGetDirect_0();
case 1745434672: return bem_superCallsGet_0();
case -2070113098: return bem_create_0();
case -1887836979: return bem_csynGetDirect_0();
case -320859248: return bem_nullValueGetDirect_0();
case -425669411: return bem_classConfGet_0();
case -1883070823: return bem_lastMethodBodyLinesGet_0();
case -1482354462: return bem_callNamesGetDirect_0();
case -897350462: return bem_iteratorGet_0();
case 1720185016: return bem_lastMethodBodyLinesGetDirect_0();
case -1076119565: return bem_lineCountGet_0();
case 623957818: return bem_once_0();
case 1744055959: return bem_falseValueGet_0();
case 1477020252: return bem_shlibeGetDirect_0();
case -871990282: return bem_propertyDecsGet_0();
case 893404390: return bem_saveSyns_0();
case -1476019175: return bem_toString_0();
case -1303250868: return bem_instanceEqualGet_0();
case 810192605: return bem_nlGetDirect_0();
case -1895333538: return bem_onceCountGetDirect_0();
case 2009823505: return bem_scvpGet_0();
case 798716309: return bem_mnodeGetDirect_0();
case -1750213491: return bem_sourceFileNameGet_0();
case 69040633: return bem_preClassOutput_0();
case -843491555: return bem_lastMethodsLinesGet_0();
case -818416868: return bem_deonGetDirect_0();
case -262565871: return bem_boolNpGetDirect_0();
case 1212398549: return bem_deopGetDirect_0();
case -1433049901: return bem_maxSpillArgsLenGetDirect_0();
case 324108738: return bem_mainOutsideNsGet_0();
case 621289419: return bem_overrideMtdDecGet_0();
case -452224728: return bem_parentConfGet_0();
case 1412784394: return bem_libEmitPathGetDirect_0();
case -1994287465: return bem_saveIds_0();
case 1070146794: return bem_toAny_0();
case 171397147: return bem_onceDecsGet_0();
case -698574222: return bem_instanceNotEqualGet_0();
case 1007360258: return bem_beginNs_0();
case -1361348296: return bem_instOfGetDirect_0();
case -26412245: return bem_randGetDirect_0();
case 1387777362: return bem_callNamesGet_0();
case 2032770284: return bem_methodsGetDirect_0();
case 1003816395: return bem_inFilePathedGet_0();
case 1574942552: return bem_loadIds_0();
case 605301946: return bem_returnTypeGet_0();
case 111067509: return bem_superNameGet_0();
case -159312932: return bem_floatNpGetDirect_0();
case -810819461: return bem_heopGetDirect_0();
case 445087939: return bem_headExtGetDirect_0();
case -2117655905: return bem_buildCreate_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case -1641085857: return bem_maxDynArgsGet_0();
case 1938116062: return bem_parentConfGetDirect_0();
case 1559384997: return bem_ccMethodsGetDirect_0();
case -1314270062: return bem_returnTypeGetDirect_0();
case 666230770: return bem_idToNameGetDirect_0();
case 708275842: return bem_gcMarksGetDirect_0();
case -1085179682: return bem_onceDecRefsGetDirect_0();
case -193388928: return bem_nameToIdPathGet_0();
case -547100573: return bem_nativeCSlotsGet_0();
case 281600343: return bem_smnlecsGet_0();
case -566653645: return bem_classEndGet_0();
case -1081365549: return bem_classHeadBodyGet_0();
case 657097720: return bem_classHeadersGet_0();
case -8388925: return bem_lastCallGet_0();
case -413288025: return bem_emitLangGet_0();
case -1301617781: return bem_smnlcsGetDirect_0();
case 164807289: return bem_onceCountGet_0();
case -612503838: return bem_classCallsGet_0();
case -931144665: return bem_transGetDirect_0();
case 246855257: return bem_baseSmtdDecGet_0();
case -1273791515: return bem_heonGet_0();
case -964627812: return bem_classCallsGetDirect_0();
case -2140873022: return bem_deonGet_0();
case 299148262: return bem_falseValueGetDirect_0();
case 1730802409: return bem_echo_0();
case -1451470412: return bem_mainStartGet_0();
case 1895371205: return bem_buildInitial_0();
case -1572913142: return bem_csynGet_0();
case -1516627858: return bem_floatNpGet_0();
case -1334889155: return bem_gcMarksGet_0();
case 578486517: return bem_heowGet_0();
case 186442690: return bem_classEmitsGetDirect_0();
case -2008187541: return bem_lastMethodsSizeGetDirect_0();
case -1953855424: return bem_stringNpGetDirect_0();
case -1072119120: return bem_nameToIdPathGetDirect_0();
case -1376255632: return bem_msynGetDirect_0();
case 1690692252: return bem_buildGet_0();
case -25881660: return bem_idToNameGet_0();
case 947838872: return bem_superCallsGetDirect_0();
case -1586484060: return bem_emitLangGetDirect_0();
case -1301854574: return bem_lastCallGetDirect_0();
case 473397081: return bem_deowGet_0();
case 1877473651: return bem_headExtGet_0();
case -688760187: return bem_qGetDirect_0();
case 726478212: return bem_objectCcGetDirect_0();
case 769708717: return bem_objectCcGet_0();
case 15993195: return bem_fileExtGetDirect_0();
case 1607142792: return bem_methodCallsGet_0();
case -96689873: return bem_ccMethodsGet_0();
case -798993814: return bem_shlibeGet_0();
case -1905994121: return bem_buildClassInfo_0();
case -378355939: return bem_objectNpGet_0();
case 2051436746: return bem_instanceEqualGetDirect_0();
case -500317647: return bem_afterCast_0();
case 775721865: return bem_exceptDecGet_0();
case -327945515: return bem_synEmitPathGetDirect_0();
case -1146453011: return bem_smnlecsGetDirect_0();
case 205861005: return bem_exceptDecGetDirect_0();
case -633663590: return bem_propertyDecsGetDirect_0();
case -704063199: return bem_classConfGetDirect_0();
case -384841986: return bem_ntypesGetDirect_0();
case -856814773: return bem_nameToIdGet_0();
case 1473167576: return bem_getLibOutput_0();
case 1326542704: return bem_tagGet_0();
case -1535284731: return bem_cnodeGet_0();
case 401060022: return bem_endNs_0();
case 657995251: return bem_libEmitNameGetDirect_0();
case 510323151: return bem_heonGetDirect_0();
case 1535180374: return bem_baseMtdDecGet_0();
case 840452620: return bem_prepHeaderOutput_0();
case 1283604068: return bem_getClassOutput_0();
case 64214387: return bem_idToNamePathGetDirect_0();
case -1505582100: return bem_boolTypeGet_0();
case 2008992711: return bem_msynGet_0();
case -535662035: return bem_inFilePathedGetDirect_0();
case -1041474195: return bem_cnodeGetDirect_0();
case 1305223964: return bem_classesInDepthOrderGet_0();
case 786261834: return bem_stringNpGet_0();
case -719522885: return bem_writeBET_0();
case -1021107371: return bem_ccCacheGet_0();
case -400774596: return bem_inClassGet_0();
case 1818028821: return bem_nlGet_0();
case 1694144692: return bem_methodCatchGetDirect_0();
case 982790540: return bem_dynMethodsGet_0();
case -892890107: return bem_instOfGet_0();
case -1555808460: return bem_smnlcsGet_0();
case 272022985: return bem_buildGetDirect_0();
case 1516161879: return bem_fieldNamesGet_0();
case -1460776411: return bem_onceDecRefsCountGetDirect_0();
case -1441125084: return bem_ntypesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1503102008: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 2125290402: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -943049382: return bem_floatNpSet_1(bevd_0);
case 368118040: return bem_heopSet_1(bevd_0);
case -1432545290: return bem_onceDecRefsSet_1(bevd_0);
case -1994625388: return bem_headExtSet_1(bevd_0);
case -1545524663: return bem_msynSet_1(bevd_0);
case -407505918: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case -850572470: return bem_callNamesSetDirect_1(bevd_0);
case -1744391875: return bem_constSet_1(bevd_0);
case 1624871422: return bem_synEmitPathSetDirect_1(bevd_0);
case -1566020675: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1236536622: return bem_lastMethodsSizeSet_1(bevd_0);
case 1597545695: return bem_onceDecRefsCountSetDirect_1(bevd_0);
case -988160454: return bem_csynSet_1(bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case 1407532684: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 875527588: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1764692174: return bem_callNamesSet_1(bevd_0);
case -1189542692: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1808619345: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1715070874: return bem_ccMethodsSetDirect_1(bevd_0);
case -1684116891: return bem_ccMethodsSet_1(bevd_0);
case 200477883: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 600550776: return bem_idToNamePathSetDirect_1(bevd_0);
case 229070821: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1889785091: return bem_maxDynArgsSet_1(bevd_0);
case -582027866: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 548629380: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -872213932: return bem_trueValueSet_1(bevd_0);
case -2005622789: return bem_setOutputTimeSet_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
case 1292975230: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case 1087291107: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -494856915: return bem_randSetDirect_1(bevd_0);
case 1184365196: return bem_onceDecRefsCountSet_1(bevd_0);
case -1001547693: return bem_nlSetDirect_1(bevd_0);
case 411538752: return bem_parentConfSet_1(bevd_0);
case -1533491858: return bem_ntypesSetDirect_1(bevd_0);
case -330693972: return bem_onceCountSetDirect_1(bevd_0);
case -391046114: return bem_deonSet_1(bevd_0);
case 1658895849: return bem_methodCallsSetDirect_1(bevd_0);
case -934497387: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1579555647: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -893162358: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 688334799: return bem_classEmitsSet_1(bevd_0);
case -1197681792: return bem_lineCountSet_1(bevd_0);
case -1854968922: return bem_fullLibEmitNameSet_1(bevd_0);
case -1883295562: return bem_begin_1(bevd_0);
case 542633904: return bem_invpSet_1(bevd_0);
case -1934800047: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1739634961: return bem_ntypesSet_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1958218467: return bem_onceDecRefsSetDirect_1(bevd_0);
case 940522172: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1493664808: return bem_stringNpSetDirect_1(bevd_0);
case -1705165043: return bem_onceDecsSetDirect_1(bevd_0);
case -722509755: return bem_floatNpSetDirect_1(bevd_0);
case 1593654990: return bem_exceptDecSet_1(bevd_0);
case -1742204703: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1598990020: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 2102873802: return bem_inClassSet_1(bevd_0);
case 1178527120: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 465452887: return bem_smnlecsSet_1(bevd_0);
case 2002588564: return bem_lineCountSetDirect_1(bevd_0);
case 1664272888: return bem_boolNpSet_1(bevd_0);
case -737545856: return bem_methodsSet_1(bevd_0);
case 1249632523: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 711638103: return bem_stringNpSet_1(bevd_0);
case 518574254: return bem_methodsSetDirect_1(bevd_0);
case -597750913: return bem_classHeadersSetDirect_1(bevd_0);
case 1013706612: return bem_mnodeSet_1(bevd_0);
case 1900763527: return bem_scvpSetDirect_1(bevd_0);
case -1893487788: return bem_emitLangSet_1(bevd_0);
case -1346244702: return bem_classHeadersSet_1(bevd_0);
case 1271463018: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1928195159: return bem_maxDynArgsSetDirect_1(bevd_0);
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -597552074: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 2007683022: return bem_libEmitNameSetDirect_1(bevd_0);
case -679157193: return bem_classHeadBodySet_1(bevd_0);
case 1119782412: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 812128814: return bem_falseValueSet_1(bevd_0);
case 1324998203: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1653080367: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -1416647571: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1537557094: return bem_gcMarksSet_1(bevd_0);
case 1515550228: return bem_onceCountSet_1(bevd_0);
case 1011031306: return bem_idToNamePathSet_1(bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -879763167: return bem_msynSetDirect_1(bevd_0);
case -1083634783: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -87387177: return bem_transSet_1(bevd_0);
case 1768295770: return bem_nullValueSet_1(bevd_0);
case 972291523: return bem_heopSetDirect_1(bevd_0);
case 690366069: return bem_lastCallSetDirect_1(bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case -468564958: return bem_dynMethodsSetDirect_1(bevd_0);
case 202827097: return bem_cnodeSet_1(bevd_0);
case 1323022202: return bem_lastMethodsLinesSet_1(bevd_0);
case -380011364: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case -497366440: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1673432080: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case -593972180: return bem_instanceEqualSetDirect_1(bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1053255131: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1412467724: return bem_scvpSet_1(bevd_0);
case -1738175976: return bem_shlibeSet_1(bevd_0);
case 771441994: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1897482083: return bem_ccCacheSet_1(bevd_0);
case -1916335512: return bem_inFilePathedSetDirect_1(bevd_0);
case -2103737273: return bem_instanceNotEqualSet_1(bevd_0);
case -444534009: return bem_propertyDecsSet_1(bevd_0);
case -2046233884: return bem_parentConfSetDirect_1(bevd_0);
case 330438308: return bem_smnlcsSet_1(bevd_0);
case -1306430644: return bem_boolCcSet_1(bevd_0);
case -1397906821: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 300539863: return bem_csynSetDirect_1(bevd_0);
case -1399668038: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1197904101: return bem_nameToIdPathSet_1(bevd_0);
case 1928420245: return bem_returnTypeSet_1(bevd_0);
case -432279623: return bem_onceDecsSet_1(bevd_0);
case 2121541852: return bem_mnodeSetDirect_1(bevd_0);
case 924024327: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1587182091: return bem_qSet_1(bevd_0);
case -1394214480: return bem_methodBodySet_1(bevd_0);
case 1021332604: return bem_classCallsSet_1(bevd_0);
case -1178174937: return bem_propertyDecsSetDirect_1(bevd_0);
case 594386313: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1700164666: return bem_smnlcsSetDirect_1(bevd_0);
case -1930470197: return bem_deopSet_1(bevd_0);
case -290319248: return bem_nameToIdSetDirect_1(bevd_0);
case -72297177: return bem_lastCallSet_1(bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case -718552025: return bem_classCallsSetDirect_1(bevd_0);
case 1944133143: return bem_methodCatchSet_1(bevd_0);
case -404142373: return bem_exceptDecSetDirect_1(bevd_0);
case -231317810: return bem_ccCacheSetDirect_1(bevd_0);
case 661850664: return bem_objectCcSet_1(bevd_0);
case 788265113: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1497996617: return bem_end_1(bevd_0);
case -238753983: return bem_boolNpSetDirect_1(bevd_0);
case -1775591297: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1119847251: return bem_nameToIdSet_1(bevd_0);
case 2061048830: return bem_nlSet_1(bevd_0);
case -90024761: return bem_methodCatchSetDirect_1(bevd_0);
case 1973348530: return bem_classHeadBodySetDirect_1(bevd_0);
case -484191734: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 762476145: return bem_nameToIdPathSetDirect_1(bevd_0);
case -1370449926: return bem_lastMethodBodySizeSet_1(bevd_0);
case 550270194: return bem_transSetDirect_1(bevd_0);
case -200447426: return bem_classConfSetDirect_1(bevd_0);
case -1153935604: return bem_trueValueSetDirect_1(bevd_0);
case -1296280987: return bem_gcMarksSetDirect_1(bevd_0);
case 854279557: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1669730703: return bem_buildSet_1(bevd_0);
case 1865486075: return bem_dynMethodsSet_1(bevd_0);
case 1413610422: return bem_deopSetDirect_1(bevd_0);
case -1861922032: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 183653636: return bem_preClassSet_1(bevd_0);
case 1653892875: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -369204384: return bem_superCallsSet_1(bevd_0);
case 774907339: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1881885544: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -2127977686: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case -1164958562: return bem_heowSet_1(bevd_0);
case -376576527: return bem_heonSetDirect_1(bevd_0);
case -719052990: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 879205992: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 2134647187: return bem_falseValueSetDirect_1(bevd_0);
case 1251192868: return bem_instOfSetDirect_1(bevd_0);
case -1454329863: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1621649523: return bem_idToNameSetDirect_1(bevd_0);
case 1328768749: return bem_cnodeSetDirect_1(bevd_0);
case -316808363: return bem_classesInDepthOrderSet_1(bevd_0);
case -582007337: return bem_randSet_1(bevd_0);
case -839872798: return bem_smnlecsSetDirect_1(bevd_0);
case -1219231639: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -580942362: return bem_synEmitPathSet_1(bevd_0);
case -1142666380: return bem_deowSetDirect_1(bevd_0);
case -909855432: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 71325940: return bem_buildSetDirect_1(bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case -1985857164: return bem_instOfSet_1(bevd_0);
case 1192056813: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 74344702: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2069938861: return bem_intNpSetDirect_1(bevd_0);
case 2099795723: return bem_idToNameSet_1(bevd_0);
case -908100743: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1368544993: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1774639333: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 728497720: return bem_classConfSet_1(bevd_0);
case -1727988623: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 744056529: return bem_objectNpSetDirect_1(bevd_0);
case -935314284: return bem_methodCallsSet_1(bevd_0);
case -232348472: return bem_inClassSetDirect_1(bevd_0);
case -945711441: return bem_libEmitPathSet_1(bevd_0);
case -2134153548: return bem_constSetDirect_1(bevd_0);
case -1607945316: return bem_objectNpSet_1(bevd_0);
case 59847925: return bem_emitLangSetDirect_1(bevd_0);
case 1739457278: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 2089690688: return bem_heonSet_1(bevd_0);
case 56238944: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1963292306: return bem_shlibeSetDirect_1(bevd_0);
case 914844141: return bem_methodBodySetDirect_1(bevd_0);
case -760840902: return bem_heowSetDirect_1(bevd_0);
case 110085297: return bem_deowSet_1(bevd_0);
case -1919679612: return bem_fileExtSetDirect_1(bevd_0);
case -1411888508: return bem_nullValueSetDirect_1(bevd_0);
case -1296374847: return bem_returnTypeSetDirect_1(bevd_0);
case -1815762942: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -2044570351: return bem_boolCcSetDirect_1(bevd_0);
case -635000816: return bem_setOutputTimeSetDirect_1(bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 1248508378: return bem_invpSetDirect_1(bevd_0);
case -1263387090: return bem_libEmitNameSet_1(bevd_0);
case 318323147: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1837872565: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -917811759: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1077534884: return bem_instanceEqualSet_1(bevd_0);
case -1990858923: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 724728698: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 233818121: return bem_superCallsSetDirect_1(bevd_0);
case 1478557421: return bem_inFilePathedSet_1(bevd_0);
case 158442969: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 644664: return bem_libEmitPathSetDirect_1(bevd_0);
case -946616518: return bem_fileExtSet_1(bevd_0);
case -1473289919: return bem_preClassSetDirect_1(bevd_0);
case -373799293: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2119108499: return bem_maxSpillArgsLenSet_1(bevd_0);
case 727112408: return bem_objectCcSetDirect_1(bevd_0);
case 1442384128: return bem_headExtSetDirect_1(bevd_0);
case 1799505119: return bem_deonSetDirect_1(bevd_0);
case -515551240: return bem_nativeCSlotsSet_1(bevd_0);
case -2048404225: return bem_classEmitsSetDirect_1(bevd_0);
case 1797195373: return bem_intNpSet_1(bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case -1210176289: return bem_qSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1679265081: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1021667403: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2054727215: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 761871294: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2096411009: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2116378310: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -149596713: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381634415: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1808952870: return bem_writeOnceDecs_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1376609773: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1107106904: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1188027921: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1651769522: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 12925382: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1824084051: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -61336329: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1399566139: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1983972004: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1838029824: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -288144182: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
