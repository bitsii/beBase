package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 41*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 42*/
 else /* Line: 43*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 44*/
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_extends);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
if (bevp_parentConf == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_10_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_ta_ph = bevl_begin.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_libNameGet_0();
bevt_15_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_16_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 53*/
 else /* Line: 54*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
} /* Line: 59*/
bevt_21_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_24_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_25_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_23_ta_ph = bevt_24_ta_ph.bem_has_1(bevt_25_ta_ph);
if (!(bevt_23_ta_ph.bevi_bool))/* Line: 74*/ {
bevt_26_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_27_ta_ph);
} /* Line: 76*/
bevt_28_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_28_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_34_ta_ph);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_36_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_36_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_37_ta_ph);
bevp_heow.bem_write_1(bevt_29_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 85*/ {
bevt_46_ta_ph = (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_46_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_47_ta_ph);
} /* Line: 87*/
bevt_50_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_51_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_add_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevt_52_ta_ph);
bevp_heow.bem_write_1(bevt_48_ta_ph);
bevt_55_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_56_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_54_ta_ph = bevt_55_ta_ph.bem_add_1(bevt_56_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bem_add_1(bevt_57_ta_ph);
bevp_deow.bem_write_1(bevt_53_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_58_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-105133659);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_ta_ph = bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_20_ta_ph = bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 142*/ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 143*/
 else /* Line: 142*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(1967536104);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-257664443, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 144*/ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
} /* Line: 145*/
 else /* Line: 142*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1967536104);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(-257664443, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 146*/ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
} /* Line: 147*/
 else /* Line: 148*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 149*/
} /* Line: 142*/
} /* Line: 142*/
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1967536104);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-257664443, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 155*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 157*/
bevt_5_ta_ph = super.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-616014137);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1281216215, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 167*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-290879441);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 168*/
 else /* Line: 169*/ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 170*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_24_ta_ph = bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-752195810);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1491925069);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 201*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 202*/
 else /* Line: 203*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 204*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 209*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 210*/
 else /* Line: 211*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 212*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 213*/
 else /* Line: 214*/ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
} /* Line: 215*/
} /* Line: 212*/
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_18_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_22_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-64930541);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 235*/
 else /* Line: 236*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-64930541);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 237*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-64930541);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 244*/
 else /* Line: 245*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-64930541);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 246*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_litArgs = bevt_0_ta_ph.bem_add_1(beva_sdec);
bevt_5_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 253*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_ta_ph = bevp_build.bem_libNameGet_0();
bevt_13_ta_ph = beva_newcc.bem_relEmitName_1(bevt_14_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = beva_newcc.bem_relEmitName_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_litArgs);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_7_ta_ph.bem_add_1(bevt_19_ta_ph);
} /* Line: 254*/
 else /* Line: 255*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = bevp_build.bem_libNameGet_0();
bevt_29_ta_ph = beva_newcc.bem_relEmitName_1(bevt_30_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevl_litArgs);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_20_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 256*/
return bevl_newCall;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 305*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 305*/ {
return this;
} /* Line: 306*/
 else /* Line: 307*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(106303818);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(611114673);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 310*/ {
return this;
} /* Line: 313*/
bevp_setOutputTime = bevl_outts;
} /* Line: 316*/
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 322*/
bevt_2_ta_ph = super.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 328*/ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 331*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 336*/ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 344*/
} /* Line: 342*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_7_ta_ph = bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_14_ta_ph = bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 354*/
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_4_ContainerList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_4_ContainerList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevl_beh.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevl_beh.bem_addValue_1(bevt_19_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_23_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_22_ta_ph = bevl_bet.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_20_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevl_bet.bem_addValue_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (!(bevt_28_ta_ph.bevi_bool))/* Line: 374*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_31_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 376*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 376*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(155731488);
if (bevl_firstmnsyn.bevi_bool)/* Line: 377*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 378*/
 else /* Line: 379*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevl_bet.bem_addValue_1(bevt_33_ta_ph);
} /* Line: 380*/
bevt_35_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_36_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_36_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 382*/
 else /* Line: 376*/ {
break;
} /* Line: 376*/
} /* Line: 376*/
} /* Line: 376*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevl_bet.bem_addValue_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_38_ta_ph = bevt_39_ta_ph.bem_has_1(bevt_40_ta_ph);
if (!(bevt_38_ta_ph.bevi_bool))/* Line: 387*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
} /* Line: 388*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 392*/ {
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_46_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 394*/ {
bevt_47_ta_ph = bevt_1_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 394*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(155731488);
bevt_48_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_48_ta_ph.bevi_bool))/* Line: 395*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 396*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 397*/
 else /* Line: 398*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevl_bet.bem_addValue_1(bevt_49_ta_ph);
} /* Line: 399*/
bevt_51_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_52_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_52_ta_ph);
bevt_50_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 401*/
} /* Line: 395*/
 else /* Line: 394*/ {
break;
} /* Line: 394*/
} /* Line: 394*/
} /* Line: 394*/
bevt_53_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_bet.bem_addValue_1(bevt_54_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_56_ta_ph = bevl_bet.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_55_ta_ph = bevt_56_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevt_55_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_61_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_62_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevt_60_ta_ph = bevt_61_ta_ph.bem_equals_1(bevt_62_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 410*/ {
bevt_65_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_64_ta_ph = bevl_bet.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bem_addValue_1(bevt_66_ta_ph);
bevt_67_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_63_ta_ph.bem_addValue_1(bevt_67_ta_ph);
} /* Line: 411*/
 else /* Line: 412*/ {
bevt_70_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_69_ta_ph = bevl_bet.bem_addValue_1(bevt_70_ta_ph);
bevt_71_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_68_ta_ph.bem_addValue_1(bevt_72_ta_ph);
} /* Line: 413*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_bet.bem_addValue_1(bevt_73_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_75_ta_ph = bevl_bet.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevt_74_ta_ph.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_80_ta_ph = bem_genMark_1(bevt_81_ta_ph);
bevl_bet.bem_addValue_1(bevt_80_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevl_bet.bem_addValue_1(bevt_82_ta_ph);
bevt_83_ta_ph = bem_getClassOutput_0();
bevt_83_ta_ph.bem_write_1(bevl_bet);
bevt_84_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_84_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_45_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_56_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 436*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_8_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_14_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 442*/ {
bevt_23_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 443*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(445478930);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(445478930);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 448*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 450*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 450*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(155731488);
bevt_35_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(445478930);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(1850545982);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(-97446410);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 456*/
 else /* Line: 450*/ {
break;
} /* Line: 450*/
} /* Line: 450*/
} /* Line: 450*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevp_deow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_43_ta_ph = bevp_build.bem_paramsGet_0();
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_42_ta_ph = bevt_43_ta_ph.bem_has_1(bevt_44_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 470*/ {
bevt_46_ta_ph = bevp_build.bem_paramsGet_0();
bevt_47_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_45_ta_ph = bevt_46_ta_ph.bem_get_1(bevt_47_ta_ph);
bevt_1_ta_loop = bevt_45_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 472*/ {
bevt_48_ta_ph = bevt_1_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 472*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(155731488);
bevt_49_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_49_ta_ph.bem_fileGet_0();
bevt_51_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bemd_0(445478930);
bevl_inc = (BEC_2_4_6_TextString) bevt_50_ta_ph.bemd_0(1850545982);
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_52_ta_ph.bemd_0(-97446410);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 478*/
 else /* Line: 472*/ {
break;
} /* Line: 472*/
} /* Line: 472*/
} /* Line: 472*/
bevt_54_ta_ph = bevp_build.bem_paramsGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_53_ta_ph = bevt_54_ta_ph.bem_has_1(bevt_55_ta_ph);
if (bevt_53_ta_ph.bevi_bool)/* Line: 481*/ {
bevt_57_ta_ph = bevp_build.bem_paramsGet_0();
bevt_58_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_56_ta_ph = bevt_57_ta_ph.bem_get_1(bevt_58_ta_ph);
bevt_2_ta_loop = bevt_56_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 483*/ {
bevt_59_ta_ph = bevt_2_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 483*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(155731488);
bevt_60_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_60_ta_ph.bem_fileGet_0();
bevt_62_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(445478930);
bevl_inc = (BEC_2_4_6_TextString) bevt_61_ta_ph.bemd_0(1850545982);
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_63_ta_ph.bemd_0(-97446410);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 489*/
 else /* Line: 483*/ {
break;
} /* Line: 483*/
} /* Line: 483*/
} /* Line: 483*/
} /* Line: 481*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 502*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 504*/ {
bevt_8_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 505*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(445478930);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 511*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 513*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 513*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(155731488);
bevt_19_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(445478930);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(1850545982);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(-97446410);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 519*/
 else /* Line: 513*/ {
break;
} /* Line: 513*/
} /* Line: 513*/
} /* Line: 513*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bem_increment_0();
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 525*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 526*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 526*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(155731488);
bevt_31_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(445478930);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(1850545982);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(-97446410);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 531*/
 else /* Line: 526*/ {
break;
} /* Line: 526*/
} /* Line: 526*/
} /* Line: 526*/
} /* Line: 525*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 549*/ {
bevl_mh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_5_ta_ph = bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 552*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 573*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_4_ta_ph = beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 574*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(-1237962180);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 586*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 586*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(155731488);
bevt_6_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_6_ta_ph.bevi_bool))/* Line: 587*/ {
if (bevl_first.bevi_bool)/* Line: 588*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 589*/
 else /* Line: 590*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 591*/
bevt_10_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 593*/
} /* Line: 587*/
 else /* Line: 586*/ {
break;
} /* Line: 586*/
} /* Line: 586*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_14_ta_ph);
bevt_13_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
bevt_1_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_ta_ph.bem_relEmitName_1(bevt_2_ta_ph);
bevt_4_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-105133659);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_ta_ph = bem_overrideMtdDecGet_0();
bevt_12_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevl_oname);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_20_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_19_ta_ph.bevi_bool)/* Line: 635*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_ta_ph, bevl_asnr);
} /* Line: 636*/
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevl_asnr);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_28_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_29_ta_ph);
bevt_28_ta_ph.bem_addValue_1(bevp_nl);
bevt_37_ta_ph = bem_overrideMtdDecGet_0();
bevt_36_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevl_oname);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_ta_ph = bevt_31_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_30_ta_ph.bem_addValue_1(bevp_nl);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_44_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevl_stinst);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_42_ta_ph = bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_47_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_48_ta_ph);
bevt_47_ta_ph.bem_addValue_1(bevp_nl);
bevt_55_ta_ph = bem_overrideMtdDecGet_0();
bevt_54_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_55_ta_ph);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_ta_ph = bevt_50_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_62_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(2003505383);
if (bevt_61_ta_ph == null) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 655*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 655*/ {
bevt_65_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bemd_0(2003505383);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_1(-257664443, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 655*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 655*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 655*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 655*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_66_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_67_ta_ph);
bevt_66_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 656*/
 else /* Line: 657*/ {
bevt_69_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_68_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_69_ta_ph);
bevt_68_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 658*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_70_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_71_ta_ph);
bevt_70_ta_ph.bem_addValue_1(bevp_nl);
bevt_78_ta_ph = bem_overrideMtdDecGet_0();
bevt_77_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_76_ta_ph = bevt_77_ta_ph.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_ta_ph = bevt_73_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_72_ta_ph.bem_addValue_1(bevp_nl);
bevt_84_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_83_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_85_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_89_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_90_ta_ph);
bevt_91_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_88_ta_ph = bevt_89_ta_ph.bem_addValue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_87_ta_ph = bevt_88_ta_ph.bem_addValue_1(bevt_92_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_95_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_96_ta_ph);
bevt_94_ta_ph = bevt_95_ta_ph.bem_addValue_1(bevl_tinst);
bevt_97_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_93_ta_ph = bevt_94_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_98_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_99_ta_ph);
bevt_98_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 21, 22, 23, 27, 29, 30, 31, 32, 33, 37, 41, 41, 42, 42, 42, 44, 44, 46, 46, 46, 46, 46, 46, 48, 48, 49, 49, 51, 51, 53, 53, 53, 53, 53, 53, 53, 55, 55, 57, 57, 59, 59, 62, 62, 64, 64, 66, 68, 70, 72, 74, 74, 74, 75, 75, 76, 76, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 85, 86, 86, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 91, 91, 91, 91, 93, 93, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 100, 100, 100, 104, 106, 107, 108, 108, 109, 113, 113, 117, 117, 121, 121, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 128, 130, 130, 130, 130, 130, 130, 132, 132, 132, 132, 132, 132, 132, 132, 132, 132, 134, 136, 136, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 146, 146, 146, 146, 147, 149, 149, 151, 155, 155, 155, 155, 156, 156, 157, 159, 159, 163, 163, 163, 163, 163, 163, 163, 163, 167, 167, 167, 167, 168, 168, 168, 170, 176, 176, 176, 176, 176, 178, 178, 178, 178, 178, 178, 178, 178, 180, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 188, 193, 193, 193, 194, 195, 195, 195, 195, 195, 195, 197, 197, 197, 197, 197, 197, 197, 197, 197, 197, 201, 201, 201, 202, 202, 202, 202, 202, 204, 204, 204, 204, 204, 204, 204, 209, 209, 210, 212, 212, 212, 213, 215, 218, 218, 218, 218, 218, 218, 218, 218, 223, 223, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 228, 228, 228, 228, 228, 228, 228, 228, 228, 230, 230, 230, 234, 234, 234, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 235, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 239, 243, 243, 243, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 252, 252, 252, 252, 252, 253, 253, 253, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 258, 263, 264, 265, 265, 266, 272, 272, 272, 272, 276, 276, 280, 280, 285, 285, 289, 289, 293, 293, 297, 297, 297, 304, 305, 0, 305, 305, 305, 305, 305, 0, 0, 306, 308, 308, 308, 309, 309, 309, 310, 313, 316, 321, 322, 322, 324, 324, 328, 329, 330, 330, 331, 336, 338, 339, 339, 340, 341, 342, 342, 343, 343, 343, 344, 350, 351, 351, 351, 352, 352, 352, 352, 352, 352, 352, 352, 352, 353, 353, 353, 353, 354, 354, 354, 356, 360, 360, 360, 360, 360, 360, 361, 362, 362, 362, 362, 362, 362, 363, 363, 364, 364, 364, 364, 365, 365, 366, 366, 367, 367, 368, 368, 369, 371, 372, 372, 372, 372, 372, 372, 372, 372, 373, 373, 374, 374, 374, 375, 376, 376, 0, 376, 376, 378, 380, 380, 382, 382, 382, 382, 385, 385, 387, 387, 387, 388, 388, 391, 391, 392, 392, 392, 393, 394, 394, 0, 394, 394, 395, 397, 399, 399, 401, 401, 401, 401, 405, 405, 407, 407, 409, 409, 409, 409, 409, 409, 410, 410, 410, 411, 411, 411, 411, 411, 411, 413, 413, 413, 413, 413, 413, 415, 415, 417, 417, 417, 417, 417, 417, 418, 418, 419, 419, 419, 420, 420, 423, 423, 424, 424, 436, 436, 437, 438, 438, 438, 438, 438, 438, 438, 439, 439, 439, 439, 439, 439, 439, 440, 440, 441, 441, 442, 442, 442, 442, 442, 443, 443, 443, 445, 445, 445, 446, 446, 446, 448, 448, 448, 450, 450, 450, 450, 0, 450, 450, 452, 452, 453, 453, 453, 454, 454, 456, 460, 460, 463, 463, 464, 464, 470, 470, 470, 472, 472, 472, 472, 0, 472, 472, 474, 474, 475, 475, 475, 476, 476, 478, 481, 481, 481, 483, 483, 483, 483, 0, 483, 483, 485, 485, 486, 486, 486, 487, 487, 489, 496, 497, 502, 502, 503, 504, 504, 504, 504, 504, 505, 505, 505, 507, 507, 507, 509, 509, 511, 511, 511, 513, 513, 513, 513, 0, 513, 513, 515, 515, 516, 516, 516, 517, 517, 519, 523, 523, 524, 525, 525, 525, 526, 526, 526, 526, 0, 526, 526, 527, 527, 528, 528, 528, 529, 529, 530, 530, 531, 537, 542, 543, 545, 545, 547, 547, 549, 549, 549, 550, 551, 551, 551, 552, 555, 556, 561, 561, 565, 565, 569, 569, 573, 573, 573, 574, 574, 574, 574, 574, 580, 580, 581, 583, 583, 583, 583, 585, 586, 0, 586, 586, 587, 589, 591, 591, 593, 593, 593, 593, 593, 593, 598, 598, 598, 603, 605, 605, 605, 605, 605, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 607, 609, 613, 613, 614, 614, 614, 614, 615, 619, 619, 620, 620, 620, 620, 621, 621, 621, 621, 625, 625, 625, 629, 629, 629, 630, 630, 630, 631, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 634, 635, 635, 636, 636, 639, 639, 639, 639, 639, 639, 639, 641, 641, 641, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 649, 649, 649, 649, 649, 649, 652, 652, 652, 654, 654, 654, 654, 654, 654, 654, 654, 654, 654, 654, 654, 655, 655, 655, 655, 0, 655, 655, 655, 0, 0, 656, 656, 656, 658, 658, 658, 660, 661, 664, 664, 664, 666, 666, 666, 666, 666, 666, 666, 666, 666, 666, 666, 666, 667, 667, 667, 669, 669, 669, 671, 673, 673, 673, 673, 673, 673, 673, 675, 675, 675, 675, 675, 675, 677, 677, 677, 683, 683, 683, 683, 683, 684, 684, 684, 684, 684, 686, 691, 691, 692, 692, 692, 692, 693, 693, 693, 693, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 183, 248, 253, 254, 255, 256, 259, 260, 262, 263, 264, 265, 266, 267, 268, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 287, 288, 289, 290, 291, 292, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 306, 307, 308, 309, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 337, 338, 339, 340, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 420, 421, 422, 423, 424, 425, 429, 430, 434, 435, 439, 440, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 519, 520, 521, 526, 527, 530, 531, 532, 533, 535, 538, 539, 540, 541, 543, 546, 547, 551, 561, 562, 563, 564, 566, 567, 568, 570, 571, 581, 582, 583, 584, 585, 586, 587, 588, 598, 599, 600, 601, 603, 604, 605, 608, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 745, 746, 751, 752, 753, 754, 755, 756, 759, 760, 761, 762, 763, 764, 765, 783, 784, 786, 789, 790, 791, 793, 796, 799, 800, 801, 802, 803, 804, 805, 806, 810, 811, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 902, 903, 904, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 941, 978, 979, 980, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1017, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1095, 1100, 1101, 1102, 1103, 1104, 1111, 1112, 1113, 1114, 1118, 1119, 1123, 1124, 1128, 1129, 1133, 1134, 1138, 1139, 1144, 1145, 1146, 1162, 1163, 1165, 1168, 1169, 1170, 1171, 1176, 1177, 1180, 1184, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1195, 1197, 1205, 1207, 1208, 1210, 1211, 1217, 1219, 1220, 1221, 1222, 1233, 1235, 1236, 1237, 1238, 1239, 1240, 1245, 1246, 1247, 1248, 1249, 1272, 1273, 1274, 1275, 1277, 1278, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1294, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1431, 1432, 1433, 1433, 1436, 1438, 1440, 1443, 1444, 1446, 1447, 1448, 1449, 1456, 1457, 1458, 1459, 1460, 1462, 1463, 1465, 1466, 1467, 1468, 1469, 1471, 1472, 1473, 1473, 1476, 1478, 1479, 1482, 1485, 1486, 1488, 1489, 1490, 1491, 1499, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1513, 1514, 1515, 1516, 1517, 1518, 1521, 1522, 1523, 1524, 1525, 1526, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1618, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1651, 1652, 1653, 1654, 1656, 1657, 1658, 1659, 1660, 1661, 1662, 1663, 1664, 1666, 1667, 1668, 1669, 1669, 1672, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1689, 1690, 1691, 1692, 1693, 1694, 1695, 1696, 1697, 1699, 1700, 1701, 1702, 1702, 1705, 1707, 1708, 1709, 1710, 1711, 1712, 1713, 1714, 1715, 1722, 1723, 1724, 1726, 1727, 1728, 1729, 1729, 1732, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1753, 1754, 1797, 1802, 1803, 1804, 1805, 1806, 1807, 1812, 1813, 1814, 1815, 1817, 1818, 1819, 1820, 1821, 1822, 1823, 1824, 1826, 1827, 1828, 1829, 1829, 1832, 1834, 1835, 1836, 1837, 1838, 1839, 1840, 1841, 1842, 1849, 1850, 1851, 1852, 1853, 1854, 1856, 1857, 1858, 1859, 1859, 1862, 1864, 1865, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1882, 1893, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1903, 1904, 1905, 1906, 1907, 1909, 1910, 1915, 1916, 1920, 1921, 1926, 1927, 1938, 1939, 1940, 1942, 1943, 1944, 1945, 1946, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1978, 1978, 1981, 1983, 1984, 1987, 1990, 1991, 1993, 1994, 1995, 1996, 1997, 1998, 2005, 2006, 2007, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2037, 2038, 2039, 2040, 2041, 2042, 2043, 2044, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2071, 2072, 2073, 2074, 2075, 2076, 2077, 2078, 2079, 2080, 2085, 2086, 2087, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2221, 2222, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2270, 2275, 2276, 2279, 2280, 2281, 2283, 2286, 2290, 2291, 2292, 2295, 2296, 2297, 2299, 2300, 2301, 2302, 2303, 2304, 2305, 2306, 2307, 2308, 2309, 2310, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2350, 2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359, 2360, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2385, 2388, 2392, 2395, 2399, 2402, 2406, 2409, 2413, 2416, 2420, 2423, 2427, 2430, 2434, 2437, 2441, 2444, 2448, 2451, 2455, 2458};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 168
new 0 17 168
assign 1 18 169
new 0 18 169
assign 1 19 170
new 0 19 170
assign 1 21 171
new 0 21 171
assign 1 22 172
new 0 22 172
assign 1 23 173
new 0 23 173
new 1 27 174
assign 1 29 175
new 0 29 175
assign 1 30 176
new 0 30 176
assign 1 31 177
new 0 31 177
assign 1 32 178
new 0 32 178
assign 1 33 179
new 0 33 179
addValue 1 37 183
assign 1 41 248
def 1 41 253
assign 1 42 254
libNameGet 0 42 254
assign 1 42 255
relEmitName 1 42 255
assign 1 42 256
extend 1 42 256
assign 1 44 259
new 0 44 259
assign 1 44 260
extend 1 44 260
assign 1 46 262
new 0 46 262
assign 1 46 263
emitNameGet 0 46 263
assign 1 46 264
addValue 1 46 264
assign 1 46 265
addValue 1 46 265
assign 1 46 266
new 0 46 266
assign 1 46 267
addValue 1 46 267
assign 1 48 268
def 1 48 273
assign 1 49 274
new 0 49 274
addValue 1 49 275
assign 1 51 276
new 0 51 276
addValue 1 51 277
assign 1 53 278
new 0 53 278
assign 1 53 279
addValue 1 53 279
assign 1 53 280
libNameGet 0 53 280
assign 1 53 281
relEmitName 1 53 281
assign 1 53 282
addValue 1 53 282
assign 1 53 283
new 0 53 283
addValue 1 53 284
assign 1 55 287
new 0 55 287
addValue 1 55 288
assign 1 57 289
new 0 57 289
addValue 1 57 290
assign 1 59 291
new 0 59 291
addValue 1 59 292
assign 1 62 294
new 0 62 294
addValue 1 62 295
assign 1 64 296
new 0 64 296
addValue 1 64 297
write 1 66 298
write 1 68 299
write 1 70 300
clear 0 72 301
assign 1 74 302
emitChecksGet 0 74 302
assign 1 74 303
new 0 74 303
assign 1 74 304
has 1 74 304
assign 1 75 306
new 0 75 306
write 1 75 307
assign 1 76 308
new 0 76 308
write 1 76 309
assign 1 78 311
new 0 78 311
write 1 78 312
assign 1 79 313
new 0 79 313
assign 1 79 314
emitNameGet 0 79 314
assign 1 79 315
add 1 79 315
assign 1 79 316
new 0 79 316
assign 1 79 317
add 1 79 317
assign 1 79 318
getHeaderInitialInst 1 79 318
assign 1 79 319
add 1 79 319
assign 1 79 320
new 0 79 320
assign 1 79 321
add 1 79 321
write 1 79 322
assign 1 80 323
new 0 80 323
write 1 80 324
assign 1 81 325
new 0 81 325
write 1 81 326
assign 1 82 327
new 0 82 327
write 1 82 328
assign 1 83 329
new 0 83 329
write 1 83 330
assign 1 84 331
new 0 84 331
write 1 84 332
assign 1 85 333
emitChecksGet 0 85 333
assign 1 85 334
new 0 85 334
assign 1 85 335
has 1 85 335
assign 1 86 337
new 0 86 337
write 1 86 338
assign 1 87 339
new 0 87 339
write 1 87 340
assign 1 89 342
new 0 89 342
assign 1 89 343
emitNameGet 0 89 343
assign 1 89 344
add 1 89 344
assign 1 89 345
new 0 89 345
assign 1 89 346
add 1 89 346
write 1 89 347
assign 1 91 348
new 0 91 348
assign 1 91 349
emitNameGet 0 91 349
assign 1 91 350
add 1 91 350
assign 1 91 351
new 0 91 351
assign 1 91 352
add 1 91 352
write 1 91 353
assign 1 93 354
new 0 93 354
return 1 93 355
assign 1 97 385
overrideMtdDecGet 0 97 385
assign 1 97 386
addValue 1 97 386
assign 1 97 387
getClassConfig 1 97 387
assign 1 97 388
libNameGet 0 97 388
assign 1 97 389
relEmitName 1 97 389
assign 1 97 390
addValue 1 97 390
assign 1 97 391
new 0 97 391
assign 1 97 392
addValue 1 97 392
assign 1 97 393
emitNameGet 0 97 393
assign 1 97 394
addValue 1 97 394
assign 1 97 395
new 0 97 395
assign 1 97 396
addValue 1 97 396
assign 1 97 397
addValue 1 97 397
assign 1 97 398
new 0 97 398
assign 1 97 399
addValue 1 97 399
addValue 1 97 400
assign 1 98 401
new 0 98 401
assign 1 98 402
addValue 1 98 402
assign 1 98 403
heldGet 0 98 403
assign 1 98 404
namepathGet 0 98 404
assign 1 98 405
getClassConfig 1 98 405
assign 1 98 406
libNameGet 0 98 406
assign 1 98 407
relEmitName 1 98 407
assign 1 98 408
addValue 1 98 408
assign 1 98 409
new 0 98 409
assign 1 98 410
addValue 1 98 410
addValue 1 98 411
assign 1 100 412
new 0 100 412
assign 1 100 413
addValue 1 100 413
addValue 1 100 414
assign 1 104 420
new 0 104 420
write 1 106 421
clear 0 107 422
assign 1 108 423
new 0 108 423
write 1 108 424
return 1 109 425
assign 1 113 429
new 0 113 429
return 1 113 430
assign 1 117 434
new 0 117 434
return 1 117 435
assign 1 121 439
new 0 121 439
return 1 121 440
assign 1 126 470
addValue 1 126 470
assign 1 126 471
libNameGet 0 126 471
assign 1 126 472
relEmitName 1 126 472
assign 1 126 473
addValue 1 126 473
assign 1 126 474
new 0 126 474
assign 1 126 475
addValue 1 126 475
assign 1 126 476
emitNameGet 0 126 476
assign 1 126 477
addValue 1 126 477
assign 1 126 478
new 0 126 478
assign 1 126 479
addValue 1 126 479
assign 1 126 480
addValue 1 126 480
assign 1 126 481
new 0 126 481
addValue 1 126 482
addValue 1 128 483
assign 1 130 484
new 0 130 484
assign 1 130 485
addValue 1 130 485
assign 1 130 486
addValue 1 130 486
assign 1 130 487
new 0 130 487
assign 1 130 488
addValue 1 130 488
addValue 1 130 489
assign 1 132 490
new 0 132 490
assign 1 132 491
addValue 1 132 491
assign 1 132 492
libNameGet 0 132 492
assign 1 132 493
relEmitName 1 132 493
assign 1 132 494
addValue 1 132 494
assign 1 132 495
new 0 132 495
assign 1 132 496
addValue 1 132 496
assign 1 132 497
addValue 1 132 497
assign 1 132 498
new 0 132 498
addValue 1 132 499
addValue 1 134 500
assign 1 136 501
new 0 136 501
addValue 1 136 502
assign 1 142 519
typenameGet 0 142 519
assign 1 142 520
NULLGet 0 142 520
assign 1 142 521
equals 1 142 526
assign 1 143 527
new 0 143 527
assign 1 144 530
heldGet 0 144 530
assign 1 144 531
nameGet 0 144 531
assign 1 144 532
new 0 144 532
assign 1 144 533
equals 1 144 533
assign 1 145 535
new 0 145 535
assign 1 146 538
heldGet 0 146 538
assign 1 146 539
nameGet 0 146 539
assign 1 146 540
new 0 146 540
assign 1 146 541
equals 1 146 541
assign 1 147 543
new 0 147 543
assign 1 149 546
heldGet 0 149 546
assign 1 149 547
nameForVar 1 149 547
return 1 151 551
assign 1 155 561
heldGet 0 155 561
assign 1 155 562
nameGet 0 155 562
assign 1 155 563
new 0 155 563
assign 1 155 564
equals 1 155 564
assign 1 156 566
new 0 156 566
assign 1 156 567
add 1 156 567
return 1 157 568
assign 1 159 570
formCallTarg 1 159 570
return 1 159 571
assign 1 163 581
new 0 163 581
assign 1 163 582
addValue 1 163 582
assign 1 163 583
secondGet 0 163 583
assign 1 163 584
formTarg 1 163 584
assign 1 163 585
addValue 1 163 585
assign 1 163 586
new 0 163 586
assign 1 163 587
addValue 1 163 587
addValue 1 163 588
assign 1 167 598
heldGet 0 167 598
assign 1 167 599
langsGet 0 167 599
assign 1 167 600
new 0 167 600
assign 1 167 601
has 1 167 601
assign 1 168 603
heldGet 0 168 603
assign 1 168 604
textGet 0 168 604
addValue 1 168 605
handleClassEmit 1 170 608
assign 1 176 650
new 0 176 650
assign 1 176 651
emitNameGet 0 176 651
assign 1 176 652
add 1 176 652
assign 1 176 653
new 0 176 653
assign 1 176 654
add 1 176 654
assign 1 178 655
new 0 178 655
assign 1 178 656
typeEmitNameGet 0 178 656
assign 1 178 657
add 1 178 657
assign 1 178 658
new 0 178 658
assign 1 178 659
add 1 178 659
assign 1 178 660
add 1 178 660
assign 1 178 661
new 0 178 661
assign 1 178 662
add 1 178 662
addClassHeader 1 180 663
assign 1 182 664
new 0 182 664
assign 1 184 665
typeEmitNameGet 0 184 665
assign 1 184 666
addValue 1 184 666
assign 1 184 667
new 0 184 667
assign 1 184 668
addValue 1 184 668
assign 1 184 669
emitNameGet 0 184 669
assign 1 184 670
addValue 1 184 670
assign 1 184 671
new 0 184 671
assign 1 184 672
addValue 1 184 672
assign 1 184 673
addValue 1 184 673
assign 1 184 674
new 0 184 674
addValue 1 184 675
assign 1 186 676
new 0 186 676
assign 1 186 677
addValue 1 186 677
assign 1 186 678
typeEmitNameGet 0 186 678
assign 1 186 679
addValue 1 186 679
assign 1 186 680
new 0 186 680
assign 1 186 681
addValue 1 186 681
assign 1 186 682
emitNameGet 0 186 682
assign 1 186 683
addValue 1 186 683
assign 1 186 684
new 0 186 684
assign 1 186 685
emitNameGet 0 186 685
assign 1 186 686
add 1 186 686
assign 1 186 687
new 0 186 687
assign 1 186 688
add 1 186 688
addValue 1 186 689
return 1 188 690
assign 1 193 710
new 0 193 710
assign 1 193 711
toString 0 193 711
assign 1 193 712
add 1 193 712
incrementValue 0 194 713
assign 1 195 714
new 0 195 714
assign 1 195 715
addValue 1 195 715
assign 1 195 716
addValue 1 195 716
assign 1 195 717
new 0 195 717
assign 1 195 718
addValue 1 195 718
addValue 1 195 719
assign 1 197 720
containedGet 0 197 720
assign 1 197 721
firstGet 0 197 721
assign 1 197 722
containedGet 0 197 722
assign 1 197 723
firstGet 0 197 723
assign 1 197 724
new 0 197 724
assign 1 197 725
add 1 197 725
assign 1 197 726
new 0 197 726
assign 1 197 727
add 1 197 727
assign 1 197 728
finalAssign 4 197 728
addValue 1 197 729
assign 1 201 745
isTypedGet 0 201 745
assign 1 201 746
not 0 201 751
assign 1 202 752
libNameGet 0 202 752
assign 1 202 753
relEmitName 1 202 753
assign 1 202 754
addValue 1 202 754
assign 1 202 755
new 0 202 755
addValue 1 202 756
assign 1 204 759
namepathGet 0 204 759
assign 1 204 760
getClassConfig 1 204 760
assign 1 204 761
libNameGet 0 204 761
assign 1 204 762
relEmitName 1 204 762
assign 1 204 763
addValue 1 204 763
assign 1 204 764
new 0 204 764
addValue 1 204 765
assign 1 209 783
new 0 209 783
assign 1 209 784
equals 1 209 784
assign 1 210 786
new 0 210 786
assign 1 212 789
emitChecksGet 0 212 789
assign 1 212 790
new 0 212 790
assign 1 212 791
has 1 212 791
assign 1 213 793
new 0 213 793
assign 1 215 796
new 0 215 796
assign 1 218 799
new 0 218 799
assign 1 218 800
add 1 218 800
assign 1 218 801
libNameGet 0 218 801
assign 1 218 802
relEmitName 1 218 802
assign 1 218 803
add 1 218 803
assign 1 218 804
new 0 218 804
assign 1 218 805
add 1 218 805
return 1 218 806
assign 1 223 810
new 0 223 810
return 1 223 811
assign 1 227 838
overrideMtdDecGet 0 227 838
assign 1 227 839
addValue 1 227 839
assign 1 227 840
new 0 227 840
assign 1 227 841
addValue 1 227 841
assign 1 227 842
emitNameGet 0 227 842
assign 1 227 843
addValue 1 227 843
assign 1 227 844
new 0 227 844
assign 1 227 845
addValue 1 227 845
assign 1 227 846
addValue 1 227 846
assign 1 227 847
new 0 227 847
assign 1 227 848
addValue 1 227 848
assign 1 227 849
addValue 1 227 849
assign 1 227 850
new 0 227 850
assign 1 227 851
addValue 1 227 851
addValue 1 227 852
assign 1 228 853
new 0 228 853
assign 1 228 854
addValue 1 228 854
assign 1 228 855
addValue 1 228 855
assign 1 228 856
new 0 228 856
assign 1 228 857
addValue 1 228 857
assign 1 228 858
addValue 1 228 858
assign 1 228 859
new 0 228 859
assign 1 228 860
addValue 1 228 860
addValue 1 228 861
assign 1 230 862
new 0 230 862
assign 1 230 863
addValue 1 230 863
addValue 1 230 864
assign 1 234 902
emitChecksGet 0 234 902
assign 1 234 903
new 0 234 903
assign 1 234 904
has 1 234 904
assign 1 235 906
new 0 235 906
assign 1 235 907
libNameGet 0 235 907
assign 1 235 908
relEmitName 1 235 908
assign 1 235 909
add 1 235 909
assign 1 235 910
new 0 235 910
assign 1 235 911
add 1 235 911
assign 1 235 912
libNameGet 0 235 912
assign 1 235 913
relEmitName 1 235 913
assign 1 235 914
add 1 235 914
assign 1 235 915
new 0 235 915
assign 1 235 916
add 1 235 916
assign 1 235 917
heldGet 0 235 917
assign 1 235 918
literalValueGet 0 235 918
assign 1 235 919
add 1 235 919
assign 1 235 920
new 0 235 920
assign 1 235 921
add 1 235 921
assign 1 237 924
new 0 237 924
assign 1 237 925
libNameGet 0 237 925
assign 1 237 926
relEmitName 1 237 926
assign 1 237 927
add 1 237 927
assign 1 237 928
new 0 237 928
assign 1 237 929
add 1 237 929
assign 1 237 930
libNameGet 0 237 930
assign 1 237 931
relEmitName 1 237 931
assign 1 237 932
add 1 237 932
assign 1 237 933
new 0 237 933
assign 1 237 934
add 1 237 934
assign 1 237 935
heldGet 0 237 935
assign 1 237 936
literalValueGet 0 237 936
assign 1 237 937
add 1 237 937
assign 1 237 938
new 0 237 938
assign 1 237 939
add 1 237 939
return 1 239 941
assign 1 243 978
emitChecksGet 0 243 978
assign 1 243 979
new 0 243 979
assign 1 243 980
has 1 243 980
assign 1 244 982
new 0 244 982
assign 1 244 983
libNameGet 0 244 983
assign 1 244 984
relEmitName 1 244 984
assign 1 244 985
add 1 244 985
assign 1 244 986
new 0 244 986
assign 1 244 987
add 1 244 987
assign 1 244 988
libNameGet 0 244 988
assign 1 244 989
relEmitName 1 244 989
assign 1 244 990
add 1 244 990
assign 1 244 991
new 0 244 991
assign 1 244 992
add 1 244 992
assign 1 244 993
heldGet 0 244 993
assign 1 244 994
literalValueGet 0 244 994
assign 1 244 995
add 1 244 995
assign 1 244 996
new 0 244 996
assign 1 244 997
add 1 244 997
assign 1 246 1000
new 0 246 1000
assign 1 246 1001
libNameGet 0 246 1001
assign 1 246 1002
relEmitName 1 246 1002
assign 1 246 1003
add 1 246 1003
assign 1 246 1004
new 0 246 1004
assign 1 246 1005
add 1 246 1005
assign 1 246 1006
libNameGet 0 246 1006
assign 1 246 1007
relEmitName 1 246 1007
assign 1 246 1008
add 1 246 1008
assign 1 246 1009
new 0 246 1009
assign 1 246 1010
add 1 246 1010
assign 1 246 1011
heldGet 0 246 1011
assign 1 246 1012
literalValueGet 0 246 1012
assign 1 246 1013
add 1 246 1013
assign 1 246 1014
new 0 246 1014
assign 1 246 1015
add 1 246 1015
return 1 248 1017
assign 1 252 1055
new 0 252 1055
assign 1 252 1056
add 1 252 1056
assign 1 252 1057
new 0 252 1057
assign 1 252 1058
add 1 252 1058
assign 1 252 1059
add 1 252 1059
assign 1 253 1060
emitChecksGet 0 253 1060
assign 1 253 1061
new 0 253 1061
assign 1 253 1062
has 1 253 1062
assign 1 254 1064
new 0 254 1064
assign 1 254 1065
libNameGet 0 254 1065
assign 1 254 1066
relEmitName 1 254 1066
assign 1 254 1067
add 1 254 1067
assign 1 254 1068
new 0 254 1068
assign 1 254 1069
add 1 254 1069
assign 1 254 1070
libNameGet 0 254 1070
assign 1 254 1071
relEmitName 1 254 1071
assign 1 254 1072
add 1 254 1072
assign 1 254 1073
new 0 254 1073
assign 1 254 1074
add 1 254 1074
assign 1 254 1075
add 1 254 1075
assign 1 254 1076
new 0 254 1076
assign 1 254 1077
add 1 254 1077
assign 1 256 1080
new 0 256 1080
assign 1 256 1081
libNameGet 0 256 1081
assign 1 256 1082
relEmitName 1 256 1082
assign 1 256 1083
add 1 256 1083
assign 1 256 1084
new 0 256 1084
assign 1 256 1085
add 1 256 1085
assign 1 256 1086
libNameGet 0 256 1086
assign 1 256 1087
relEmitName 1 256 1087
assign 1 256 1088
add 1 256 1088
assign 1 256 1089
new 0 256 1089
assign 1 256 1090
add 1 256 1090
assign 1 256 1091
add 1 256 1091
assign 1 256 1092
new 0 256 1092
assign 1 256 1093
add 1 256 1093
return 1 258 1095
getCode 2 263 1100
assign 1 264 1101
toHexString 1 264 1101
assign 1 265 1102
new 0 265 1102
addValue 1 265 1103
addValue 1 266 1104
assign 1 272 1111
new 0 272 1111
assign 1 272 1112
add 1 272 1112
assign 1 272 1113
add 1 272 1113
return 1 272 1114
assign 1 276 1118
new 0 276 1118
return 1 276 1119
assign 1 280 1123
new 0 280 1123
return 1 280 1124
assign 1 285 1128
new 0 285 1128
return 1 285 1129
assign 1 289 1133
new 0 289 1133
return 1 289 1134
assign 1 293 1138
new 0 293 1138
return 1 293 1139
assign 1 297 1144
new 0 297 1144
assign 1 297 1145
add 1 297 1145
return 1 297 1146
assign 1 304 1162
assign 1 305 1163
singleCCGet 0 305 1163
assign 1 0 1165
assign 1 305 1168
classPathGet 0 305 1168
assign 1 305 1169
fileGet 0 305 1169
assign 1 305 1170
existsGet 0 305 1170
assign 1 305 1171
not 0 305 1176
assign 1 0 1177
assign 1 0 1180
return 1 306 1184
assign 1 308 1187
classPathGet 0 308 1187
assign 1 308 1188
fileGet 0 308 1188
assign 1 308 1189
lastUpdatedGet 0 308 1189
assign 1 309 1190
fromFileGet 0 309 1190
assign 1 309 1191
fileGet 0 309 1191
assign 1 309 1192
lastUpdatedGet 0 309 1192
assign 1 310 1193
greater 1 310 1193
return 1 313 1195
assign 1 316 1197
assign 1 321 1205
singleCCGet 0 321 1205
assign 1 322 1207
getLibOutput 0 322 1207
return 1 322 1208
assign 1 324 1210
getClassOutput 0 324 1210
return 1 324 1211
assign 1 328 1217
singleCCGet 0 328 1217
assign 1 329 1219
new 0 329 1219
assign 1 330 1220
countLines 1 330 1220
addValue 1 330 1221
write 1 331 1222
assign 1 336 1233
singleCCGet 0 336 1233
assign 1 338 1235
new 0 338 1235
assign 1 339 1236
countLines 1 339 1236
addValue 1 339 1237
write 1 340 1238
close 0 341 1239
assign 1 342 1240
def 1 342 1245
assign 1 343 1246
pathGet 0 343 1246
assign 1 343 1247
fileGet 0 343 1247
lastUpdatedSet 1 343 1248
assign 1 344 1249
assign 1 350 1272
new 0 350 1272
assign 1 351 1273
emitChecksGet 0 351 1273
assign 1 351 1274
new 0 351 1274
assign 1 351 1275
has 1 351 1275
assign 1 352 1277
new 0 352 1277
assign 1 352 1278
addValue 1 352 1278
assign 1 352 1279
addValue 1 352 1279
assign 1 352 1280
new 0 352 1280
assign 1 352 1281
addValue 1 352 1281
assign 1 352 1282
addValue 1 352 1282
assign 1 352 1283
new 0 352 1283
assign 1 352 1284
addValue 1 352 1284
addValue 1 352 1285
assign 1 353 1286
addValue 1 353 1286
assign 1 353 1287
new 0 353 1287
assign 1 353 1288
addValue 1 353 1288
addValue 1 353 1289
assign 1 354 1290
new 0 354 1290
assign 1 354 1291
addValue 1 354 1291
addValue 1 354 1292
return 1 356 1294
assign 1 360 1388
new 0 360 1388
assign 1 360 1389
typeEmitNameGet 0 360 1389
assign 1 360 1390
add 1 360 1390
assign 1 360 1391
new 0 360 1391
assign 1 360 1392
add 1 360 1392
write 1 360 1393
assign 1 361 1394
new 0 361 1394
assign 1 362 1395
new 0 362 1395
assign 1 362 1396
addValue 1 362 1396
assign 1 362 1397
typeEmitNameGet 0 362 1397
assign 1 362 1398
addValue 1 362 1398
assign 1 362 1399
new 0 362 1399
addValue 1 362 1400
assign 1 363 1401
new 0 363 1401
addValue 1 363 1402
assign 1 364 1403
typeEmitNameGet 0 364 1403
assign 1 364 1404
addValue 1 364 1404
assign 1 364 1405
new 0 364 1405
addValue 1 364 1406
assign 1 365 1407
new 0 365 1407
addValue 1 365 1408
assign 1 366 1409
new 0 366 1409
addValue 1 366 1410
assign 1 367 1411
new 0 367 1411
addValue 1 367 1412
assign 1 368 1413
new 0 368 1413
addValue 1 368 1414
write 1 369 1415
assign 1 371 1416
new 0 371 1416
assign 1 372 1417
typeEmitNameGet 0 372 1417
assign 1 372 1418
addValue 1 372 1418
assign 1 372 1419
new 0 372 1419
assign 1 372 1420
addValue 1 372 1420
assign 1 372 1421
typeEmitNameGet 0 372 1421
assign 1 372 1422
addValue 1 372 1422
assign 1 372 1423
new 0 372 1423
addValue 1 372 1424
assign 1 373 1425
new 0 373 1425
addValue 1 373 1426
assign 1 374 1427
emitChecksGet 0 374 1427
assign 1 374 1428
new 0 374 1428
assign 1 374 1429
has 1 374 1429
assign 1 375 1431
new 0 375 1431
assign 1 376 1432
mtdListGet 0 376 1432
assign 1 376 1433
iteratorGet 0 0 1433
assign 1 376 1436
hasNextGet 0 376 1436
assign 1 376 1438
nextGet 0 376 1438
assign 1 378 1440
new 0 378 1440
assign 1 380 1443
new 0 380 1443
addValue 1 380 1444
assign 1 382 1446
addValue 1 382 1446
assign 1 382 1447
nameGet 0 382 1447
assign 1 382 1448
addValue 1 382 1448
addValue 1 382 1449
assign 1 385 1456
new 0 385 1456
addValue 1 385 1457
assign 1 387 1458
emitChecksGet 0 387 1458
assign 1 387 1459
new 0 387 1459
assign 1 387 1460
has 1 387 1460
assign 1 388 1462
new 0 388 1462
addValue 1 388 1463
assign 1 391 1465
new 0 391 1465
addValue 1 391 1466
assign 1 392 1467
emitChecksGet 0 392 1467
assign 1 392 1468
new 0 392 1468
assign 1 392 1469
has 1 392 1469
assign 1 393 1471
new 0 393 1471
assign 1 394 1472
ptyListGet 0 394 1472
assign 1 394 1473
iteratorGet 0 0 1473
assign 1 394 1476
hasNextGet 0 394 1476
assign 1 394 1478
nextGet 0 394 1478
assign 1 395 1479
isSlotGet 0 395 1479
assign 1 397 1482
new 0 397 1482
assign 1 399 1485
new 0 399 1485
addValue 1 399 1486
assign 1 401 1488
addValue 1 401 1488
assign 1 401 1489
nameGet 0 401 1489
assign 1 401 1490
addValue 1 401 1490
addValue 1 401 1491
assign 1 405 1499
new 0 405 1499
addValue 1 405 1500
assign 1 407 1501
new 0 407 1501
addValue 1 407 1502
assign 1 409 1503
new 0 409 1503
assign 1 409 1504
addValue 1 409 1504
assign 1 409 1505
typeEmitNameGet 0 409 1505
assign 1 409 1506
addValue 1 409 1506
assign 1 409 1507
new 0 409 1507
addValue 1 409 1508
assign 1 410 1509
emitNameGet 0 410 1509
assign 1 410 1510
new 0 410 1510
assign 1 410 1511
equals 1 410 1511
assign 1 411 1513
new 0 411 1513
assign 1 411 1514
addValue 1 411 1514
assign 1 411 1515
emitNameGet 0 411 1515
assign 1 411 1516
addValue 1 411 1516
assign 1 411 1517
new 0 411 1517
addValue 1 411 1518
assign 1 413 1521
new 0 413 1521
assign 1 413 1522
addValue 1 413 1522
assign 1 413 1523
emitNameGet 0 413 1523
assign 1 413 1524
addValue 1 413 1524
assign 1 413 1525
new 0 413 1525
addValue 1 413 1526
assign 1 415 1528
new 0 415 1528
addValue 1 415 1529
assign 1 417 1530
new 0 417 1530
assign 1 417 1531
addValue 1 417 1531
assign 1 417 1532
typeEmitNameGet 0 417 1532
assign 1 417 1533
addValue 1 417 1533
assign 1 417 1534
new 0 417 1534
addValue 1 417 1535
assign 1 418 1536
new 0 418 1536
addValue 1 418 1537
assign 1 419 1538
new 0 419 1538
assign 1 419 1539
genMark 1 419 1539
addValue 1 419 1540
assign 1 420 1541
new 0 420 1541
addValue 1 420 1542
assign 1 423 1543
getClassOutput 0 423 1543
write 1 423 1544
assign 1 424 1545
countLines 1 424 1545
addValue 1 424 1546
assign 1 436 1618
undef 1 436 1623
assign 1 437 1624
libNameGet 0 437 1624
assign 1 438 1625
new 0 438 1625
assign 1 438 1626
sizeGet 0 438 1626
assign 1 438 1627
add 1 438 1627
assign 1 438 1628
new 0 438 1628
assign 1 438 1629
add 1 438 1629
assign 1 438 1630
add 1 438 1630
assign 1 438 1631
add 1 438 1631
assign 1 439 1632
new 0 439 1632
assign 1 439 1633
sizeGet 0 439 1633
assign 1 439 1634
add 1 439 1634
assign 1 439 1635
new 0 439 1635
assign 1 439 1636
add 1 439 1636
assign 1 439 1637
add 1 439 1637
assign 1 439 1638
add 1 439 1638
assign 1 440 1639
parentGet 0 440 1639
assign 1 440 1640
addStep 1 440 1640
assign 1 441 1641
parentGet 0 441 1641
assign 1 441 1642
addStep 1 441 1642
assign 1 442 1643
parentGet 0 442 1643
assign 1 442 1644
fileGet 0 442 1644
assign 1 442 1645
existsGet 0 442 1645
assign 1 442 1646
not 0 442 1651
assign 1 443 1652
parentGet 0 443 1652
assign 1 443 1653
fileGet 0 443 1653
makeDirs 0 443 1654
assign 1 445 1656
fileGet 0 445 1656
assign 1 445 1657
writerGet 0 445 1657
assign 1 445 1658
open 0 445 1658
assign 1 446 1659
fileGet 0 446 1659
assign 1 446 1660
writerGet 0 446 1660
assign 1 446 1661
open 0 446 1661
assign 1 448 1662
paramsGet 0 448 1662
assign 1 448 1663
new 0 448 1663
assign 1 448 1664
has 1 448 1664
assign 1 450 1666
paramsGet 0 450 1666
assign 1 450 1667
new 0 450 1667
assign 1 450 1668
get 1 450 1668
assign 1 450 1669
iteratorGet 0 0 1669
assign 1 450 1672
hasNextGet 0 450 1672
assign 1 450 1674
nextGet 0 450 1674
assign 1 452 1675
apNew 1 452 1675
assign 1 452 1676
fileGet 0 452 1676
assign 1 453 1677
readerGet 0 453 1677
assign 1 453 1678
open 0 453 1678
assign 1 453 1679
readString 0 453 1679
assign 1 454 1680
readerGet 0 454 1680
close 0 454 1681
write 1 456 1682
assign 1 460 1689
new 0 460 1689
write 1 460 1690
assign 1 463 1691
new 0 463 1691
write 1 463 1692
assign 1 464 1693
new 0 464 1693
write 1 464 1694
assign 1 470 1695
paramsGet 0 470 1695
assign 1 470 1696
new 0 470 1696
assign 1 470 1697
has 1 470 1697
assign 1 472 1699
paramsGet 0 472 1699
assign 1 472 1700
new 0 472 1700
assign 1 472 1701
get 1 472 1701
assign 1 472 1702
iteratorGet 0 0 1702
assign 1 472 1705
hasNextGet 0 472 1705
assign 1 472 1707
nextGet 0 472 1707
assign 1 474 1708
apNew 1 474 1708
assign 1 474 1709
fileGet 0 474 1709
assign 1 475 1710
readerGet 0 475 1710
assign 1 475 1711
open 0 475 1711
assign 1 475 1712
readString 0 475 1712
assign 1 476 1713
readerGet 0 476 1713
close 0 476 1714
write 1 478 1715
assign 1 481 1722
paramsGet 0 481 1722
assign 1 481 1723
new 0 481 1723
assign 1 481 1724
has 1 481 1724
assign 1 483 1726
paramsGet 0 483 1726
assign 1 483 1727
new 0 483 1727
assign 1 483 1728
get 1 483 1728
assign 1 483 1729
iteratorGet 0 0 1729
assign 1 483 1732
hasNextGet 0 483 1732
assign 1 483 1734
nextGet 0 483 1734
assign 1 485 1735
apNew 1 485 1735
assign 1 485 1736
fileGet 0 485 1736
assign 1 486 1737
readerGet 0 486 1737
assign 1 486 1738
open 0 486 1738
assign 1 486 1739
readString 0 486 1739
assign 1 487 1740
readerGet 0 487 1740
close 0 487 1741
write 1 489 1742
begin 1 496 1753
prepHeaderOutput 0 497 1754
assign 1 502 1797
undef 1 502 1802
assign 1 503 1803
new 0 503 1803
assign 1 504 1804
parentGet 0 504 1804
assign 1 504 1805
fileGet 0 504 1805
assign 1 504 1806
existsGet 0 504 1806
assign 1 504 1807
not 0 504 1812
assign 1 505 1813
parentGet 0 505 1813
assign 1 505 1814
fileGet 0 505 1814
makeDirs 0 505 1815
assign 1 507 1817
fileGet 0 507 1817
assign 1 507 1818
writerGet 0 507 1818
assign 1 507 1819
open 0 507 1819
assign 1 509 1820
new 0 509 1820
write 1 509 1821
assign 1 511 1822
paramsGet 0 511 1822
assign 1 511 1823
new 0 511 1823
assign 1 511 1824
has 1 511 1824
assign 1 513 1826
paramsGet 0 513 1826
assign 1 513 1827
new 0 513 1827
assign 1 513 1828
get 1 513 1828
assign 1 513 1829
iteratorGet 0 0 1829
assign 1 513 1832
hasNextGet 0 513 1832
assign 1 513 1834
nextGet 0 513 1834
assign 1 515 1835
apNew 1 515 1835
assign 1 515 1836
fileGet 0 515 1836
assign 1 516 1837
readerGet 0 516 1837
assign 1 516 1838
open 0 516 1838
assign 1 516 1839
readString 0 516 1839
assign 1 517 1840
readerGet 0 517 1840
close 0 517 1841
write 1 519 1842
assign 1 523 1849
new 0 523 1849
write 1 523 1850
increment 0 524 1851
assign 1 525 1852
paramsGet 0 525 1852
assign 1 525 1853
new 0 525 1853
assign 1 525 1854
has 1 525 1854
assign 1 526 1856
paramsGet 0 526 1856
assign 1 526 1857
new 0 526 1857
assign 1 526 1858
get 1 526 1858
assign 1 526 1859
iteratorGet 0 0 1859
assign 1 526 1862
hasNextGet 0 526 1862
assign 1 526 1864
nextGet 0 526 1864
assign 1 527 1865
apNew 1 527 1865
assign 1 527 1866
fileGet 0 527 1866
assign 1 528 1867
readerGet 0 528 1867
assign 1 528 1868
open 0 528 1868
assign 1 528 1869
readString 0 528 1869
assign 1 529 1870
readerGet 0 529 1870
close 0 529 1871
assign 1 530 1872
countLines 1 530 1872
addValue 1 530 1873
write 1 531 1874
return 1 537 1882
close 0 542 1893
assign 1 543 1894
assign 1 545 1895
new 0 545 1895
write 1 545 1896
assign 1 547 1897
new 0 547 1897
write 1 547 1898
assign 1 549 1899
emitChecksGet 0 549 1899
assign 1 549 1900
new 0 549 1900
assign 1 549 1901
has 1 549 1901
assign 1 550 1903
new 0 550 1903
assign 1 551 1904
new 0 551 1904
assign 1 551 1905
addValue 1 551 1905
addValue 1 551 1906
write 1 552 1907
close 0 555 1909
close 0 556 1910
assign 1 561 1915
new 0 561 1915
return 1 561 1916
assign 1 565 1920
new 0 565 1920
addValue 1 565 1921
assign 1 569 1926
new 0 569 1926
addValue 1 569 1927
assign 1 573 1938
emitChecksGet 0 573 1938
assign 1 573 1939
new 0 573 1939
assign 1 573 1940
has 1 573 1940
assign 1 574 1942
new 0 574 1942
assign 1 574 1943
addValue 1 574 1943
assign 1 574 1944
addValue 1 574 1944
assign 1 574 1945
new 0 574 1945
addValue 1 574 1946
assign 1 580 1970
heldGet 0 580 1970
assign 1 580 1971
synGet 0 580 1971
assign 1 581 1972
ptyListGet 0 581 1972
assign 1 583 1973
emitNameGet 0 583 1973
assign 1 583 1974
addValue 1 583 1974
assign 1 583 1975
new 0 583 1975
addValue 1 583 1976
assign 1 585 1977
new 0 585 1977
assign 1 586 1978
iteratorGet 0 0 1978
assign 1 586 1981
hasNextGet 0 586 1981
assign 1 586 1983
nextGet 0 586 1983
assign 1 587 1984
isSlotGet 0 587 1984
assign 1 589 1987
new 0 589 1987
assign 1 591 1990
new 0 591 1990
addValue 1 591 1991
assign 1 593 1993
addValue 1 593 1993
assign 1 593 1994
new 0 593 1994
assign 1 593 1995
addValue 1 593 1995
assign 1 593 1996
nameGet 0 593 1996
assign 1 593 1997
addValue 1 593 1997
addValue 1 593 1998
assign 1 598 2005
new 0 598 2005
assign 1 598 2006
addValue 1 598 2006
addValue 1 598 2007
assign 1 603 2027
new 0 603 2027
assign 1 605 2028
new 0 605 2028
assign 1 605 2029
emitNameGet 0 605 2029
assign 1 605 2030
add 1 605 2030
assign 1 605 2031
new 0 605 2031
assign 1 605 2032
add 1 605 2032
assign 1 607 2033
emitNameGet 0 607 2033
assign 1 607 2034
addValue 1 607 2034
assign 1 607 2035
new 0 607 2035
assign 1 607 2036
addValue 1 607 2036
assign 1 607 2037
emitNameGet 0 607 2037
assign 1 607 2038
addValue 1 607 2038
assign 1 607 2039
new 0 607 2039
assign 1 607 2040
addValue 1 607 2040
assign 1 607 2041
addValue 1 607 2041
assign 1 607 2042
new 0 607 2042
addValue 1 607 2043
return 1 609 2044
assign 1 613 2053
libNameGet 0 613 2053
assign 1 613 2054
relEmitName 1 613 2054
assign 1 614 2055
new 0 614 2055
assign 1 614 2056
add 1 614 2056
assign 1 614 2057
new 0 614 2057
assign 1 614 2058
add 1 614 2058
return 1 615 2059
assign 1 619 2071
libNameGet 0 619 2071
assign 1 619 2072
relEmitName 1 619 2072
assign 1 620 2073
new 0 620 2073
assign 1 620 2074
add 1 620 2074
assign 1 620 2075
new 0 620 2075
assign 1 620 2076
add 1 620 2076
assign 1 621 2077
new 0 621 2077
assign 1 621 2078
add 1 621 2078
assign 1 621 2079
add 1 621 2079
return 1 621 2080
assign 1 625 2085
new 0 625 2085
assign 1 625 2086
add 1 625 2086
return 1 625 2087
assign 1 629 2195
getClassConfig 1 629 2195
assign 1 629 2196
libNameGet 0 629 2196
assign 1 629 2197
relEmitName 1 629 2197
assign 1 630 2198
heldGet 0 630 2198
assign 1 630 2199
namepathGet 0 630 2199
assign 1 630 2200
getClassConfig 1 630 2200
assign 1 631 2201
getInitialInst 1 631 2201
assign 1 633 2202
overrideMtdDecGet 0 633 2202
assign 1 633 2203
addValue 1 633 2203
assign 1 633 2204
new 0 633 2204
assign 1 633 2205
addValue 1 633 2205
assign 1 633 2206
emitNameGet 0 633 2206
assign 1 633 2207
addValue 1 633 2207
assign 1 633 2208
new 0 633 2208
assign 1 633 2209
addValue 1 633 2209
assign 1 633 2210
addValue 1 633 2210
assign 1 633 2211
new 0 633 2211
assign 1 633 2212
addValue 1 633 2212
assign 1 633 2213
addValue 1 633 2213
assign 1 633 2214
new 0 633 2214
assign 1 633 2215
addValue 1 633 2215
addValue 1 633 2216
assign 1 634 2217
new 0 634 2217
assign 1 635 2218
emitNameGet 0 635 2218
assign 1 635 2219
notEquals 1 635 2219
assign 1 636 2221
new 0 636 2221
assign 1 636 2222
formCast 3 636 2222
assign 1 639 2224
addValue 1 639 2224
assign 1 639 2225
new 0 639 2225
assign 1 639 2226
addValue 1 639 2226
assign 1 639 2227
addValue 1 639 2227
assign 1 639 2228
new 0 639 2228
assign 1 639 2229
addValue 1 639 2229
addValue 1 639 2230
assign 1 641 2231
new 0 641 2231
assign 1 641 2232
addValue 1 641 2232
addValue 1 641 2233
assign 1 644 2234
overrideMtdDecGet 0 644 2234
assign 1 644 2235
addValue 1 644 2235
assign 1 644 2236
addValue 1 644 2236
assign 1 644 2237
new 0 644 2237
assign 1 644 2238
addValue 1 644 2238
assign 1 644 2239
emitNameGet 0 644 2239
assign 1 644 2240
addValue 1 644 2240
assign 1 644 2241
new 0 644 2241
assign 1 644 2242
addValue 1 644 2242
assign 1 644 2243
addValue 1 644 2243
assign 1 644 2244
new 0 644 2244
assign 1 644 2245
addValue 1 644 2245
addValue 1 644 2246
assign 1 649 2247
new 0 649 2247
assign 1 649 2248
addValue 1 649 2248
assign 1 649 2249
addValue 1 649 2249
assign 1 649 2250
new 0 649 2250
assign 1 649 2251
addValue 1 649 2251
addValue 1 649 2252
assign 1 652 2253
new 0 652 2253
assign 1 652 2254
addValue 1 652 2254
addValue 1 652 2255
assign 1 654 2256
overrideMtdDecGet 0 654 2256
assign 1 654 2257
addValue 1 654 2257
assign 1 654 2258
new 0 654 2258
assign 1 654 2259
addValue 1 654 2259
assign 1 654 2260
emitNameGet 0 654 2260
assign 1 654 2261
addValue 1 654 2261
assign 1 654 2262
new 0 654 2262
assign 1 654 2263
addValue 1 654 2263
assign 1 654 2264
addValue 1 654 2264
assign 1 654 2265
new 0 654 2265
assign 1 654 2266
addValue 1 654 2266
addValue 1 654 2267
assign 1 655 2268
heldGet 0 655 2268
assign 1 655 2269
extendsGet 0 655 2269
assign 1 655 2270
undef 1 655 2275
assign 1 0 2276
assign 1 655 2279
heldGet 0 655 2279
assign 1 655 2280
extendsGet 0 655 2280
assign 1 655 2281
equals 1 655 2281
assign 1 0 2283
assign 1 0 2286
assign 1 656 2290
new 0 656 2290
assign 1 656 2291
addValue 1 656 2291
addValue 1 656 2292
assign 1 658 2295
new 0 658 2295
assign 1 658 2296
addValue 1 658 2296
addValue 1 658 2297
addValue 1 660 2299
clear 0 661 2300
assign 1 664 2301
new 0 664 2301
assign 1 664 2302
addValue 1 664 2302
addValue 1 664 2303
assign 1 666 2304
overrideMtdDecGet 0 666 2304
assign 1 666 2305
addValue 1 666 2305
assign 1 666 2306
new 0 666 2306
assign 1 666 2307
addValue 1 666 2307
assign 1 666 2308
emitNameGet 0 666 2308
assign 1 666 2309
addValue 1 666 2309
assign 1 666 2310
new 0 666 2310
assign 1 666 2311
addValue 1 666 2311
assign 1 666 2312
addValue 1 666 2312
assign 1 666 2313
new 0 666 2313
assign 1 666 2314
addValue 1 666 2314
addValue 1 666 2315
assign 1 667 2316
new 0 667 2316
assign 1 667 2317
addValue 1 667 2317
addValue 1 667 2318
assign 1 669 2319
new 0 669 2319
assign 1 669 2320
addValue 1 669 2320
addValue 1 669 2321
assign 1 671 2322
getTypeInst 1 671 2322
assign 1 673 2323
new 0 673 2323
assign 1 673 2324
addValue 1 673 2324
assign 1 673 2325
emitNameGet 0 673 2325
assign 1 673 2326
addValue 1 673 2326
assign 1 673 2327
new 0 673 2327
assign 1 673 2328
addValue 1 673 2328
addValue 1 673 2329
assign 1 675 2330
new 0 675 2330
assign 1 675 2331
addValue 1 675 2331
assign 1 675 2332
addValue 1 675 2332
assign 1 675 2333
new 0 675 2333
assign 1 675 2334
addValue 1 675 2334
addValue 1 675 2335
assign 1 677 2336
new 0 677 2336
assign 1 677 2337
addValue 1 677 2337
addValue 1 677 2338
assign 1 683 2350
new 0 683 2350
assign 1 683 2351
add 1 683 2351
assign 1 683 2352
new 0 683 2352
assign 1 683 2353
add 1 683 2353
write 1 683 2354
assign 1 684 2355
new 0 684 2355
assign 1 684 2356
add 1 684 2356
assign 1 684 2357
new 0 684 2357
assign 1 684 2358
add 1 684 2358
write 1 684 2359
emitLib 0 686 2360
assign 1 691 2373
libNameGet 0 691 2373
assign 1 691 2374
relEmitName 1 691 2374
assign 1 692 2375
new 0 692 2375
assign 1 692 2376
add 1 692 2376
assign 1 692 2377
new 0 692 2377
assign 1 692 2378
add 1 692 2378
assign 1 693 2379
new 0 693 2379
assign 1 693 2380
add 1 693 2380
assign 1 693 2381
add 1 693 2381
return 1 693 2382
return 1 0 2385
assign 1 0 2388
return 1 0 2392
assign 1 0 2395
return 1 0 2399
assign 1 0 2402
return 1 0 2406
assign 1 0 2409
return 1 0 2413
assign 1 0 2416
return 1 0 2420
assign 1 0 2423
return 1 0 2427
assign 1 0 2430
return 1 0 2434
assign 1 0 2437
return 1 0 2441
assign 1 0 2444
return 1 0 2448
assign 1 0 2451
return 1 0 2455
assign 1 0 2458
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -842174414: return bem_maxSpillArgsLenGet_0();
case 1563023391: return bem_preClassGet_0();
case -479088429: return bem_classCallsGet_0();
case -464274831: return bem_instanceEqualGet_0();
case 92759149: return bem_csynGet_0();
case -1098635384: return bem_smnlcsGet_0();
case -550778756: return bem_qGet_0();
case -107675124: return bem_instOfGet_0();
case -1337802702: return bem_doEmit_0();
case -1580417896: return bem_deopGet_0();
case 572942595: return bem_create_0();
case 1576391522: return bem_baseSmtdDecGet_0();
case -1433082250: return bem_lastMethodBodySizeGet_0();
case 1660691500: return bem_propDecGet_0();
case 492402303: return bem_beginNs_0();
case -1644685203: return bem_shlibeGet_0();
case 2041237129: return bem_deowGet_0();
case -2021786039: return bem_overrideMtdDecGet_0();
case 1077092133: return bem_baseMtdDecGet_0();
case -1225845477: return bem_covariantReturnsGet_0();
case -1808863306: return bem_classesInDepthOrderGet_0();
case -1747504218: return bem_inClassGet_0();
case 593600550: return bem_toString_0();
case 2118574777: return bem_constGet_0();
case -1088779047: return bem_mnodeGet_0();
case 1742904023: return bem_buildGet_0();
case 377909304: return bem_buildClassInfo_0();
case -1150888958: return bem_headExtGet_0();
case -473565714: return bem_initialDecGet_0();
case 1344351423: return bem_gcMarksGet_0();
case -830092599: return bem_ntypesGet_0();
case -1640809610: return bem_boolTypeGet_0();
case -29382659: return bem_writeBET_0();
case 1957007343: return bem_emitLib_0();
case -235372539: return bem_afterCast_0();
case 1802236174: return bem_newDecGet_0();
case -643803600: return bem_intNpGet_0();
case 220731140: return bem_methodsGet_0();
case 1496650433: return bem_lastMethodsSizeGet_0();
case 916511308: return bem_print_0();
case -134171401: return bem_boolNpGet_0();
case -1092464524: return bem_nameToIdPathGet_0();
case -1621043779: return bem_trueValueGet_0();
case -529087053: return bem_invpGet_0();
case -593179039: return bem_hashGet_0();
case -1436535291: return bem_inFilePathedGet_0();
case -93730680: return bem_buildCreate_0();
case 661229218: return bem_classEndGet_0();
case 1421119965: return bem_saveSyns_0();
case 1927062381: return bem_buildInitial_0();
case 90811774: return bem_classConfGet_0();
case -105495106: return bem_scvpGet_0();
case -296696183: return bem_lineCountGet_0();
case 1384547436: return bem_maxDynArgsGet_0();
case -389120297: return bem_preClassOutput_0();
case -1974285733: return bem_classHeadersGet_0();
case 1853948313: return bem_deonGet_0();
case 600321552: return bem_setOutputTimeGet_0();
case 516342665: return bem_smnlecsGet_0();
case 1888624041: return bem_propertyDecsGet_0();
case -929282480: return bem_idToNameGet_0();
case 1472228653: return bem_callNamesGet_0();
case -1635801782: return bem_fullLibEmitNameGet_0();
case 2023291228: return bem_getClassOutput_0();
case 1243297989: return bem_belslitsGet_0();
case 1304976611: return bem_objectCcGet_0();
case -557172869: return bem_fileExtGet_0();
case -269318132: return bem_endNs_0();
case -33356755: return bem_transGet_0();
case -8508210: return bem_classEmitsGet_0();
case 1439270064: return bem_saveIds_0();
case -410583285: return bem_lastCallGet_0();
case 1134574585: return bem_boolCcGet_0();
case -1186528459: return bem_lastMethodsLinesGet_0();
case -1125513683: return bem_getLibOutput_0();
case -62324912: return bem_spropDecGet_0();
case -1007757125: return bem_emitLangGet_0();
case 908392315: return bem_instanceNotEqualGet_0();
case -1867678068: return bem_floatNpGet_0();
case -1802001012: return bem_stringNpGet_0();
case 779510467: return bem_useDynMethodsGet_0();
case 733983974: return bem_nameToIdGet_0();
case -316167854: return bem_cnodeGet_0();
case -1942079604: return bem_objectNpGet_0();
case -1611079151: return bem_exceptDecGet_0();
case 1757997629: return bem_ccCacheGet_0();
case -509281348: return bem_new_0();
case -999073190: return bem_nlGet_0();
case 1964269806: return bem_typeDecGet_0();
case -297022358: return bem_libEmitNameGet_0();
case 1690325984: return bem_methodCatchGet_0();
case 54697229: return bem_classHeadBodyGet_0();
case -1128741483: return bem_superCallsGet_0();
case 2021957733: return bem_heowGet_0();
case -1941488754: return bem_synEmitPathGet_0();
case 1377393171: return bem_iteratorGet_0();
case 1031650463: return bem_returnTypeGet_0();
case -1919366883: return bem_loadIds_0();
case -100741834: return bem_lastMethodBodyLinesGet_0();
case -1143860682: return bem_buildPropList_0();
case -1185722199: return bem_mainOutsideNsGet_0();
case -1436588716: return bem_copy_0();
case 1729706035: return bem_superNameGet_0();
case 1661302291: return bem_falseValueGet_0();
case -714598263: return bem_mainEndGet_0();
case 1202612685: return bem_parentConfGet_0();
case 1749667450: return bem_libEmitPathGet_0();
case -855176284: return bem_runtimeInitGet_0();
case 2004043873: return bem_onceDecsGet_0();
case -554715026: return bem_methodBodyGet_0();
case -314156481: return bem_prepHeaderOutput_0();
case 1691985781: return bem_randGet_0();
case 2003646831: return bem_mainStartGet_0();
case 788771827: return bem_heonGet_0();
case -406427064: return bem_mainInClassGet_0();
case -1714497055: return bem_idToNamePathGet_0();
case 473503192: return bem_nativeCSlotsGet_0();
case -1610000005: return bem_heopGet_0();
case -1987566143: return bem_ccMethodsGet_0();
case 992469363: return bem_methodCallsGet_0();
case 1141439822: return bem_nullValueGet_0();
case -1117295410: return bem_dynMethodsGet_0();
case -1161229044: return bem_msynGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 187038508: return bem_preClassSet_1(bevd_0);
case 1350908520: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 167554075: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1132397886: return bem_classesInDepthOrderSet_1(bevd_0);
case -1239385327: return bem_undef_1(bevd_0);
case -1214456993: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -287643108: return bem_deopSet_1(bevd_0);
case 740081825: return bem_notEquals_1(bevd_0);
case 1580178633: return bem_idToNameSet_1(bevd_0);
case -1410398479: return bem_lastMethodBodySizeSet_1(bevd_0);
case -898451317: return bem_methodCallsSet_1(bevd_0);
case -1718369094: return bem_trueValueSet_1(bevd_0);
case -1118077405: return bem_synEmitPathSet_1(bevd_0);
case -651084528: return bem_instOfSet_1(bevd_0);
case 1245042803: return bem_methodsSet_1(bevd_0);
case 1793004133: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1874807960: return bem_msynSet_1(bevd_0);
case 1008582343: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1918546308: return bem_nameToIdSet_1(bevd_0);
case -1546435571: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1499945151: return bem_shlibeSet_1(bevd_0);
case -1759367774: return bem_fullLibEmitNameSet_1(bevd_0);
case 1963482048: return bem_lastMethodsLinesSet_1(bevd_0);
case 676384239: return bem_floatNpSet_1(bevd_0);
case 487388797: return bem_heowSet_1(bevd_0);
case 152454017: return bem_def_1(bevd_0);
case 657458251: return bem_onceDecsSet_1(bevd_0);
case -684818523: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1874882310: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -902462867: return bem_classConfSet_1(bevd_0);
case -174777273: return bem_nlSet_1(bevd_0);
case 1973594863: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -2111440306: return bem_methodBodySet_1(bevd_0);
case 1767752600: return bem_classHeadersSet_1(bevd_0);
case -1471223660: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 93152968: return bem_fileExtSet_1(bevd_0);
case 470778783: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1027353802: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1406789603: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 105327910: return bem_falseValueSet_1(bevd_0);
case -1819682386: return bem_randSet_1(bevd_0);
case 1057755516: return bem_lineCountSet_1(bevd_0);
case -885379501: return bem_libEmitNameSet_1(bevd_0);
case -1633963528: return bem_maxDynArgsSet_1(bevd_0);
case -1116278553: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 499839279: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1829328017: return bem_heonSet_1(bevd_0);
case 409759068: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1872523372: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1496215653: return bem_returnTypeSet_1(bevd_0);
case 1753266721: return bem_intNpSet_1(bevd_0);
case 1442839527: return bem_inClassSet_1(bevd_0);
case 1793850747: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1461476268: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1490966740: return bem_copyTo_1(bevd_0);
case -262828205: return bem_invpSet_1(bevd_0);
case -1550806262: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1685092075: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case -1130625629: return bem_qSet_1(bevd_0);
case 608788503: return bem_dynMethodsSet_1(bevd_0);
case 1809271333: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -225299585: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1573708121: return bem_lastCallSet_1(bevd_0);
case 154074191: return bem_stringNpSet_1(bevd_0);
case 1675414103: return bem_boolNpSet_1(bevd_0);
case 1829516969: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 751705064: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -2048604678: return bem_boolCcSet_1(bevd_0);
case -257664443: return bem_equals_1(bevd_0);
case 1629059833: return bem_propertyDecsSet_1(bevd_0);
case -1288910127: return bem_methodCatchSet_1(bevd_0);
case 580377949: return bem_belslitsSet_1(bevd_0);
case 622994737: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1068863371: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 617605031: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -140140499: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1272196427: return bem_classHeadBodySet_1(bevd_0);
case 1299917123: return bem_cnodeSet_1(bevd_0);
case 454497094: return bem_classCallsSet_1(bevd_0);
case 928389621: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1848583900: return bem_callNamesSet_1(bevd_0);
case 1028904411: return bem_instanceNotEqualSet_1(bevd_0);
case 1566658628: return bem_objectCcSet_1(bevd_0);
case -1814022395: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1768811332: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -709489163: return bem_end_1(bevd_0);
case -1350849067: return bem_ccMethodsSet_1(bevd_0);
case 1980815313: return bem_inFilePathedSet_1(bevd_0);
case -326391637: return bem_constSet_1(bevd_0);
case -1664043865: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1666808356: return bem_lastMethodsSizeSet_1(bevd_0);
case -235995816: return bem_nameToIdPathSet_1(bevd_0);
case 195945534: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1786903547: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1727336330: return bem_nullValueSet_1(bevd_0);
case -908947041: return bem_deonSet_1(bevd_0);
case -1084461931: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1565877504: return bem_objectNpSet_1(bevd_0);
case 830993732: return bem_begin_1(bevd_0);
case 650717189: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1945143143: return bem_instanceEqualSet_1(bevd_0);
case 1337950292: return bem_idToNamePathSet_1(bevd_0);
case 1790583949: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -864835947: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 415341189: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1972573071: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1147932358: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1867445186: return bem_csynSet_1(bevd_0);
case -452238768: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 990922741: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1247942881: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1012905628: return bem_setOutputTimeSet_1(bevd_0);
case -1459618911: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -597184975: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 950863217: return bem_scvpSet_1(bevd_0);
case -1106067544: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 958004197: return bem_heopSet_1(bevd_0);
case 1218446290: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 809288000: return bem_classEmitsSet_1(bevd_0);
case 1107597561: return bem_transSet_1(bevd_0);
case -1944321913: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1675063474: return bem_buildSet_1(bevd_0);
case 1670550876: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1764060861: return bem_mnodeSet_1(bevd_0);
case 1372702350: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1167536123: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -910596451: return bem_exceptDecSet_1(bevd_0);
case -1671367739: return bem_headExtSet_1(bevd_0);
case -1058639715: return bem_nativeCSlotsSet_1(bevd_0);
case 697627155: return bem_gcMarksSet_1(bevd_0);
case 510837743: return bem_deowSet_1(bevd_0);
case -282440212: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 431048155: return bem_superCallsSet_1(bevd_0);
case -682786826: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 83055169: return bem_smnlecsSet_1(bevd_0);
case -469242080: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 214788439: return bem_parentConfSet_1(bevd_0);
case 293572513: return bem_smnlcsSet_1(bevd_0);
case 1378138640: return bem_ntypesSet_1(bevd_0);
case -1298675443: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -274224230: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1207948568: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 711333747: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1915735138: return bem_libEmitPathSet_1(bevd_0);
case -1934361023: return bem_emitLangSet_1(bevd_0);
case -1341388197: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1775320153: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -469387631: return bem_ccCacheSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 426315431: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2087906856: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 8353367: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -840314986: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628920596: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -466247487: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1167164271: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2028229465: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1606608446: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 704366194: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 376456972: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 529653897: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 677704745: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -183499135: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 380768478: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1898474211: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -2112678640: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1395098844: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -778588790: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -171050141: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1669860485: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1054146823: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -2142259933: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -2136335622: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -451074960: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
