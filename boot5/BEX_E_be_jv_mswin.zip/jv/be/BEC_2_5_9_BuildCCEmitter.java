package be;
/* IO:File: source/build/CCEmitter.be */
public final class BEC_2_5_9_BuildCCEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x6E,0x6F,0x53,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x6E,0x6F,0x52,0x66,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x74,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x62,0x65,0x76,0x74,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x61,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x62,0x65,0x76,0x61,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x62,0x65,0x71,0x2D,0x3E,0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x62,0x65,0x76,0x6B,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_5_9_BuildCCEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (new BEC_2_4_6_TextString()).bem_new_0();
super.bem_new_1(beva__build);
bevp_invp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) throws Throwable {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
if (bevp_parentConf == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_3_ta_ph = bevp_build.bem_libNameGet_0();
bevt_2_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_3_ta_ph);
bevl_extends = bem_extend_1(bevt_2_ta_ph);
} /* Line: 48*/
 else /* Line: 49*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_4_ta_ph);
} /* Line: 50*/
bevt_7_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevl_extends);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = bevt_5_ta_ph.bem_addValue_1(bevt_9_ta_ph);
if (bevp_parentConf == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_12_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_14_ta_ph = bevl_begin.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_17_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_13_ta_ph.bem_addValue_1(bevt_18_ta_ph);
} /* Line: 59*/
 else /* Line: 60*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
} /* Line: 65*/
bevt_22_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_23_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_25_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (!(bevt_24_ta_ph.bevi_bool))/* Line: 80*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_27_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_28_ta_ph);
} /* Line: 82*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevp_heow.bem_write_1(bevt_29_ta_ph);
bevt_34_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_35_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_36_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_36_ta_ph);
bevt_37_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_37_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_38_ta_ph);
bevp_heow.bem_write_1(bevt_30_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (bevt_43_ta_ph.bevi_bool)/* Line: 90*/ {
bevt_47_ta_ph = beva_csyn.bem_hasDefaultGet_0();
if (bevt_47_ta_ph.bevi_bool) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 90*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 90*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 90*/
 else /* Line: 90*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 90*/ {
bevt_48_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_48_ta_ph);
} /* Line: 91*/
bevt_50_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_51_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevt_49_ta_ph = bevt_50_ta_ph.bem_has_1(bevt_51_ta_ph);
if (!(bevt_49_ta_ph.bevi_bool))/* Line: 93*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevp_heow.bem_write_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevp_heow.bem_write_1(bevt_53_ta_ph);
} /* Line: 95*/
bevt_56_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_57_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_55_ta_ph = bevt_56_ta_ph.bem_add_1(bevt_57_ta_ph);
bevt_58_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_54_ta_ph = bevt_55_ta_ph.bem_add_1(bevt_58_ta_ph);
bevp_heow.bem_write_1(bevt_54_ta_ph);
bevt_61_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_62_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_60_ta_ph = bevt_61_ta_ph.bem_add_1(bevt_62_ta_ph);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_59_ta_ph = bevt_60_ta_ph.bem_add_1(bevt_63_ta_ph);
bevp_deow.bem_write_1(bevt_59_ta_ph);
bevt_64_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_64_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_17_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(1191699374);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_25_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_14_ta_ph = bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_20_ta_ph = bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 150*/ {
bevl_tcall = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 151*/
 else /* Line: 150*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1433239121);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(764483733, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 152*/ {
bevl_tcall = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
} /* Line: 153*/
 else /* Line: 150*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1433239121);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(764483733, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 154*/ {
bevl_tcall = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
} /* Line: 155*/
 else /* Line: 156*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 157*/
} /* Line: 150*/
} /* Line: 150*/
return bevl_tcall;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_4_6_TextString bevl_prefix = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isTmpVarGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 165*/ {
if (bevp_ccHs.bevi_bool)/* Line: 166*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
} /* Line: 167*/
if (bevp_ccSs.bevi_bool)/* Line: 169*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
} /* Line: 170*/
} /* Line: 169*/
 else /* Line: 165*/ {
bevt_1_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 172*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
} /* Line: 173*/
 else /* Line: 165*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 174*/ {
if (bevp_ccHs.bevi_bool)/* Line: 175*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
} /* Line: 176*/
if (bevp_ccSs.bevi_bool)/* Line: 178*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
} /* Line: 179*/
} /* Line: 178*/
 else /* Line: 181*/ {
if (bevp_ccHs.bevi_bool)/* Line: 182*/ {
bevl_prefix = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
} /* Line: 183*/
if (bevp_ccSs.bevi_bool)/* Line: 185*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
} /* Line: 186*/
} /* Line: 185*/
} /* Line: 165*/
} /* Line: 165*/
bevt_4_ta_ph = beva_v.bem_nameGet_0();
bevt_3_ta_ph = bevl_prefix.bem_add_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_decNameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_4_6_TextString bevl_prefix = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_0_ta_ph = beva_v.bem_isTmpVarGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 196*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
} /* Line: 197*/
 else /* Line: 196*/ {
bevt_1_ta_ph = beva_v.bem_isPropertyGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 198*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
} /* Line: 199*/
 else /* Line: 196*/ {
bevt_2_ta_ph = beva_v.bem_isArgGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 200*/ {
if (bevp_ccSs.bevi_bool)/* Line: 201*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
} /* Line: 202*/
if (bevp_ccHs.bevi_bool)/* Line: 204*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
} /* Line: 205*/
} /* Line: 204*/
 else /* Line: 207*/ {
bevl_prefix = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
} /* Line: 208*/
} /* Line: 196*/
} /* Line: 196*/
bevt_4_ta_ph = beva_v.bem_nameGet_0();
bevt_3_ta_ph = bevl_prefix.bem_add_1(bevt_4_ta_ph);
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1433239121);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(764483733, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 215*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 217*/
bevt_5_ta_ph = super.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_2_ta_ph = bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(659318180);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(793234925, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 227*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-169923863);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 228*/
 else /* Line: 229*/ {
super.bem_handleClassEmit_1(beva_node);
} /* Line: 230*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_24_ta_ph = bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_22_ta_ph = bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(57632507);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1359638132);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 261*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 262*/
 else /* Line: 263*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 264*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) throws Throwable {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 269*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
} /* Line: 270*/
 else /* Line: 271*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 272*/ {
bevl_ccall = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
} /* Line: 273*/
 else /* Line: 274*/ {
bevl_ccall = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
} /* Line: 275*/
} /* Line: 272*/
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_afterCast_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_18_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
bevt_16_ta_ph = bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_14_ta_ph = bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_22_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 294*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-29561186);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 295*/
 else /* Line: 296*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-29561186);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 297*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 303*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_newcc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_libNameGet_0();
bevt_12_ta_ph = beva_newcc.bem_relEmitName_1(bevt_13_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-29561186);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_newCall = bevt_3_ta_ph.bem_add_1(bevt_17_ta_ph);
} /* Line: 304*/
 else /* Line: 305*/ {
bevt_23_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_25_ta_ph = bevp_build.bem_libNameGet_0();
bevt_24_ta_ph = beva_newcc.bem_relEmitName_1(bevt_25_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = bevp_build.bem_libNameGet_0();
bevt_27_ta_ph = beva_newcc.bem_relEmitName_1(bevt_28_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = beva_node.bem_heldGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-29561186);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_newCall = bevt_18_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 306*/
return bevl_newCall;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_litArgs = bevt_0_ta_ph.bem_add_1(beva_sdec);
bevt_5_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 313*/ {
bevt_12_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_14_ta_ph = bevp_build.bem_libNameGet_0();
bevt_13_ta_ph = beva_newcc.bem_relEmitName_1(bevt_14_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_17_ta_ph = bevp_build.bem_libNameGet_0();
bevt_16_ta_ph = beva_newcc.bem_relEmitName_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_litArgs);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_newCall = bevt_7_ta_ph.bem_add_1(bevt_19_ta_ph);
} /* Line: 314*/
 else /* Line: 315*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_27_ta_ph = bevp_build.bem_libNameGet_0();
bevt_26_ta_ph = beva_newcc.bem_relEmitName_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = bevp_build.bem_libNameGet_0();
bevt_29_ta_ph = beva_newcc.bem_relEmitName_1(bevt_30_ta_ph);
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevl_litArgs);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_newCall = bevt_20_ta_ph.bem_add_1(bevt_32_ta_ph);
} /* Line: 316*/
return bevl_newCall;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainInClassGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_preClassOutput_0() throws Throwable {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 365*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 365*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 365*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 365*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 365*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 365*/ {
return this;
} /* Line: 366*/
 else /* Line: 367*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-119158218);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(-453422261);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 370*/ {
return this;
} /* Line: 373*/
bevp_setOutputTime = bevl_outts;
} /* Line: 376*/
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 381*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 382*/
bevt_2_ta_ph = super.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 388*/ {
bevl_clns = (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 391*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 396*/ {
bevl_clend = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 402*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 404*/
} /* Line: 402*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) throws Throwable {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 411*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevt_7_ta_ph = bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_14_ta_ph = bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 414*/
return bevl_bet;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_writeBET_0() throws Throwable {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_4_ContainerList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_4_ContainerList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
bevt_4_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevl_beh.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_beh.bem_addValue_1(bevt_19_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_23_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_22_ta_ph = bevl_bet.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_21_ta_ph = bevt_22_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevt_20_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevl_bet.bem_addValue_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (!(bevt_28_ta_ph.bevi_bool))/* Line: 434*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_31_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 436*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 436*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(694276667);
if (bevl_firstmnsyn.bevi_bool)/* Line: 437*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 438*/
 else /* Line: 439*/ {
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevl_bet.bem_addValue_1(bevt_33_ta_ph);
} /* Line: 440*/
bevt_35_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_36_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_36_ta_ph);
bevt_34_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 442*/
 else /* Line: 436*/ {
break;
} /* Line: 436*/
} /* Line: 436*/
} /* Line: 436*/
bevt_37_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevl_bet.bem_addValue_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_40_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_38_ta_ph = bevt_39_ta_ph.bem_has_1(bevt_40_ta_ph);
if (!(bevt_38_ta_ph.bevi_bool))/* Line: 447*/ {
bevt_41_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
} /* Line: 448*/
bevt_42_ta_ph = (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_45_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (!(bevt_43_ta_ph.bevi_bool))/* Line: 452*/ {
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_46_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 454*/ {
bevt_47_ta_ph = bevt_1_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 454*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(694276667);
bevt_48_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_48_ta_ph.bevi_bool))/* Line: 455*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 456*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 457*/
 else /* Line: 458*/ {
bevt_49_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevl_bet.bem_addValue_1(bevt_49_ta_ph);
} /* Line: 459*/
bevt_51_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_52_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_52_ta_ph);
bevt_50_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 461*/
} /* Line: 455*/
 else /* Line: 454*/ {
break;
} /* Line: 454*/
} /* Line: 454*/
} /* Line: 454*/
bevt_53_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevl_bet.bem_addValue_1(bevt_54_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_56_ta_ph = bevl_bet.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_55_ta_ph = bevt_56_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_55_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_61_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_62_ta_ph = (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_60_ta_ph = bevt_61_ta_ph.bem_equals_1(bevt_62_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 470*/ {
bevt_65_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_64_ta_ph = bevl_bet.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bem_addValue_1(bevt_66_ta_ph);
bevt_67_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevt_63_ta_ph.bem_addValue_1(bevt_67_ta_ph);
} /* Line: 471*/
 else /* Line: 472*/ {
bevt_70_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_69_ta_ph = bevl_bet.bem_addValue_1(bevt_70_ta_ph);
bevt_71_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_72_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevt_68_ta_ph.bem_addValue_1(bevt_72_ta_ph);
} /* Line: 473*/
bevt_73_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevl_bet.bem_addValue_1(bevt_73_ta_ph);
bevt_76_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_75_ta_ph = bevl_bet.bem_addValue_1(bevt_76_ta_ph);
bevt_77_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevt_74_ta_ph.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_80_ta_ph = bem_genMark_1(bevt_81_ta_ph);
bevl_bet.bem_addValue_1(bevt_80_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevl_bet.bem_addValue_1(bevt_82_ta_ph);
bevt_83_ta_ph = bem_getClassOutput_0();
bevt_83_ta_ph.bem_write_1(bevl_bet);
bevt_84_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_84_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_45_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_56_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 496*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_8_ta_ph = bevl_libName.bem_lengthGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_14_ta_ph = bevl_libName.bem_lengthGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 502*/ {
bevt_23_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 503*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(-1763039450);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(-1763039450);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 508*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 510*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 510*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(694276667);
bevt_35_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(-1763039450);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(-114451538);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(1033890087);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 516*/
 else /* Line: 510*/ {
break;
} /* Line: 510*/
} /* Line: 510*/
} /* Line: 510*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevp_deow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_43_ta_ph = bevp_build.bem_paramsGet_0();
bevt_44_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_42_ta_ph = bevt_43_ta_ph.bem_has_1(bevt_44_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 530*/ {
bevt_46_ta_ph = bevp_build.bem_paramsGet_0();
bevt_47_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_45_ta_ph = bevt_46_ta_ph.bem_get_1(bevt_47_ta_ph);
bevt_1_ta_loop = bevt_45_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 532*/ {
bevt_48_ta_ph = bevt_1_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 532*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(694276667);
bevt_49_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_49_ta_ph.bem_fileGet_0();
bevt_51_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bemd_0(-1763039450);
bevl_inc = (BEC_2_4_6_TextString) bevt_50_ta_ph.bemd_0(-114451538);
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_52_ta_ph.bemd_0(1033890087);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 538*/
 else /* Line: 532*/ {
break;
} /* Line: 532*/
} /* Line: 532*/
} /* Line: 532*/
bevt_54_ta_ph = bevp_build.bem_paramsGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_53_ta_ph = bevt_54_ta_ph.bem_has_1(bevt_55_ta_ph);
if (bevt_53_ta_ph.bevi_bool)/* Line: 541*/ {
bevt_57_ta_ph = bevp_build.bem_paramsGet_0();
bevt_58_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_56_ta_ph = bevt_57_ta_ph.bem_get_1(bevt_58_ta_ph);
bevt_2_ta_loop = bevt_56_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 543*/ {
bevt_59_ta_ph = bevt_2_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 543*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(694276667);
bevt_60_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_60_ta_ph.bem_fileGet_0();
bevt_62_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(-1763039450);
bevl_inc = (BEC_2_4_6_TextString) bevt_61_ta_ph.bemd_0(-114451538);
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_63_ta_ph.bemd_0(1033890087);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 549*/
 else /* Line: 543*/ {
break;
} /* Line: 543*/
} /* Line: 543*/
} /* Line: 543*/
} /* Line: 541*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 562*/ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 564*/ {
bevt_8_ta_ph = bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 565*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(-1763039450);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 571*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 573*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 573*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(694276667);
bevt_19_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-1763039450);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(-114451538);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(1033890087);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 579*/
 else /* Line: 573*/ {
break;
} /* Line: 573*/
} /* Line: 573*/
} /* Line: 573*/
bevt_23_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bevi_int++;
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 585*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 586*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 586*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(694276667);
bevt_31_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(-1763039450);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(-114451538);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(1033890087);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 591*/
 else /* Line: 586*/ {
break;
} /* Line: 586*/
} /* Line: 586*/
} /* Line: 586*/
} /* Line: 585*/
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 609*/ {
bevl_mh = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_5_ta_ph = bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 612*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_lstringStartCi_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 633*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_4_ta_ph = beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 634*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(377877471);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 646*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-610732203);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 646*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(694276667);
bevt_6_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_6_ta_ph.bevi_bool))/* Line: 647*/ {
if (bevl_first.bevi_bool)/* Line: 648*/ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 649*/
 else /* Line: 650*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 651*/
bevt_10_ta_ph = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_8_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 653*/
} /* Line: 647*/
 else /* Line: 646*/ {
break;
} /* Line: 646*/
} /* Line: 646*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_14_ta_ph);
bevt_13_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_runtimeInitGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildInitial_0() throws Throwable {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_6_6_SystemObject bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_4_6_TextString bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_6_TextString bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
bevt_2_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_3_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_2_ta_ph.bem_relEmitName_1(bevt_3_ta_ph);
bevt_5_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(1191699374);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_4_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_14_ta_ph = bem_overrideMtdDecGet_0();
bevt_13_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_10_ta_ph = bevt_11_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevl_oname);
bevt_18_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_21_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_20_ta_ph.bevi_bool)/* Line: 695*/ {
bevt_22_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_22_ta_ph, bevl_asnr);
} /* Line: 696*/
bevt_26_ta_ph = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_27_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_25_ta_ph = bevt_26_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_24_ta_ph = bevt_25_ta_ph.bem_addValue_1(bevl_asnr);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_23_ta_ph = bevt_24_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_23_ta_ph.bem_addValue_1(bevp_nl);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_29_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_30_ta_ph);
bevt_29_ta_ph.bem_addValue_1(bevp_nl);
bevt_38_ta_ph = bem_overrideMtdDecGet_0();
bevt_37_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_38_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bem_addValue_1(bevl_oname);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_41_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_33_ta_ph = bevt_34_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_32_ta_ph = bevt_33_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_31_ta_ph = bevt_32_ta_ph.bem_addValue_1(bevt_42_ta_ph);
bevt_31_ta_ph.bem_addValue_1(bevp_nl);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevt_45_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_46_ta_ph);
bevt_44_ta_ph = bevt_45_ta_ph.bem_addValue_1(bevl_stinst);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_43_ta_ph = bevt_44_ta_ph.bem_addValue_1(bevt_47_ta_ph);
bevt_43_ta_ph.bem_addValue_1(bevp_nl);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_48_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_49_ta_ph);
bevt_48_ta_ph.bem_addValue_1(bevp_nl);
bevt_56_ta_ph = bem_overrideMtdDecGet_0();
bevt_55_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_54_ta_ph = bevt_55_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_53_ta_ph = bevt_54_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_59_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_52_ta_ph = bevt_53_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_51_ta_ph = bevt_52_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_50_ta_ph = bevt_51_ta_ph.bem_addValue_1(bevt_60_ta_ph);
bevt_50_ta_ph.bem_addValue_1(bevp_nl);
bevt_63_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_62_ta_ph = bevt_63_ta_ph.bemd_0(-403456126);
if (bevt_62_ta_ph == null) {
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 715*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 715*/ {
bevt_66_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_65_ta_ph = bevt_66_ta_ph.bemd_0(-403456126);
bevt_64_ta_ph = bevt_65_ta_ph.bemd_1(764483733, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 715*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 715*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 715*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 715*/ {
bevt_68_ta_ph = (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_67_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_68_ta_ph);
bevt_67_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 716*/
 else /* Line: 717*/ {
bevt_70_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_69_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_70_ta_ph);
bevt_69_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 718*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_71_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_72_ta_ph);
bevt_71_ta_ph.bem_addValue_1(bevp_nl);
bevt_79_ta_ph = bem_overrideMtdDecGet_0();
bevt_78_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_77_ta_ph = bevt_78_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_76_ta_ph = bevt_77_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_82_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_75_ta_ph = bevt_76_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_74_ta_ph = bevt_75_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_83_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_73_ta_ph = bevt_74_ta_ph.bem_addValue_1(bevt_83_ta_ph);
bevt_73_ta_ph.bem_addValue_1(bevp_nl);
bevt_85_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_84_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_85_ta_ph);
bevt_84_ta_ph.bem_addValue_1(bevp_nl);
bevt_87_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_86_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_87_ta_ph);
bevt_86_ta_ph.bem_addValue_1(bevp_nl);
bevt_89_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_90_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevt_88_ta_ph = bevt_89_ta_ph.bem_has_1(bevt_90_ta_ph);
if (bevt_88_ta_ph.bevi_bool)/* Line: 731*/ {
bevt_94_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(377877471);
bevt_92_ta_ph = bevt_93_ta_ph.bemd_0(-2029838453);
bevt_91_ta_ph = bevt_92_ta_ph.bemd_0(942395349);
if (((BEC_2_5_4_LogicBool) bevt_91_ta_ph).bevi_bool)/* Line: 731*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 731*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 731*/
 else /* Line: 731*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (!(bevt_1_ta_anchor.bevi_bool))/* Line: 731*/ {
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_98_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_97_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_98_ta_ph);
bevt_99_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_96_ta_ph = bevt_97_ta_ph.bem_addValue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_95_ta_ph = bevt_96_ta_ph.bem_addValue_1(bevt_100_ta_ph);
bevt_95_ta_ph.bem_addValue_1(bevp_nl);
bevt_104_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_103_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_104_ta_ph);
bevt_102_ta_ph = bevt_103_ta_ph.bem_addValue_1(bevl_tinst);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_101_ta_ph = bevt_102_ta_ph.bem_addValue_1(bevt_105_ta_ph);
bevt_101_ta_ph.bem_addValue_1(bevp_nl);
bevt_107_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_106_ta_ph = bevp_ccMethods.bem_addValue_1(bevt_107_ta_ph);
bevt_106_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 738*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_emitLib_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
super.bem_emitLib_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() throws Throwable {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() throws Throwable {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() throws Throwable {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() throws Throwable {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() throws Throwable {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() throws Throwable {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() throws Throwable {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() throws Throwable {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() throws Throwable {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() throws Throwable {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 24, 25, 27, 28, 29, 33, 35, 36, 37, 38, 39, 43, 47, 47, 48, 48, 48, 50, 50, 52, 52, 52, 52, 52, 52, 54, 54, 55, 55, 57, 57, 59, 59, 59, 59, 59, 59, 59, 61, 61, 63, 63, 65, 65, 68, 68, 70, 70, 72, 74, 76, 78, 80, 80, 80, 81, 81, 82, 82, 84, 84, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 86, 86, 87, 87, 88, 88, 89, 89, 90, 90, 90, 90, 90, 90, 0, 0, 0, 91, 91, 93, 93, 93, 94, 94, 95, 95, 97, 97, 97, 97, 97, 97, 99, 99, 99, 99, 99, 99, 101, 101, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 105, 106, 106, 106, 106, 106, 106, 106, 106, 106, 106, 106, 108, 108, 108, 112, 114, 115, 116, 116, 117, 121, 121, 125, 125, 129, 129, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 136, 138, 138, 138, 138, 138, 138, 140, 140, 140, 140, 140, 140, 140, 140, 140, 140, 142, 144, 144, 150, 150, 150, 150, 151, 152, 152, 152, 152, 153, 154, 154, 154, 154, 155, 157, 157, 159, 165, 167, 170, 172, 173, 174, 176, 179, 183, 186, 189, 189, 189, 196, 197, 198, 199, 200, 202, 205, 208, 210, 210, 210, 215, 215, 215, 215, 216, 216, 217, 219, 219, 223, 223, 223, 223, 223, 223, 223, 223, 227, 227, 227, 227, 228, 228, 228, 230, 236, 236, 236, 236, 236, 238, 238, 238, 238, 238, 238, 238, 238, 240, 242, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 253, 253, 253, 254, 255, 255, 255, 255, 255, 255, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 261, 261, 261, 262, 262, 262, 262, 262, 264, 264, 264, 264, 264, 264, 264, 269, 269, 270, 272, 272, 272, 273, 275, 278, 278, 278, 278, 278, 278, 278, 278, 283, 283, 287, 287, 287, 287, 287, 287, 287, 287, 287, 287, 287, 287, 287, 287, 287, 288, 288, 288, 288, 288, 288, 288, 288, 288, 290, 290, 290, 294, 294, 294, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 299, 303, 303, 303, 304, 304, 304, 304, 304, 304, 304, 304, 304, 304, 304, 304, 304, 304, 304, 304, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 306, 308, 312, 312, 312, 312, 312, 313, 313, 313, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 318, 323, 324, 325, 325, 326, 332, 332, 332, 332, 336, 336, 340, 340, 345, 345, 349, 349, 353, 353, 357, 357, 357, 364, 365, 0, 365, 365, 365, 365, 365, 0, 0, 366, 368, 368, 368, 369, 369, 369, 370, 373, 376, 381, 382, 382, 384, 384, 388, 389, 390, 390, 391, 396, 398, 399, 399, 400, 401, 402, 402, 403, 403, 403, 404, 410, 411, 411, 411, 412, 412, 412, 412, 412, 412, 412, 412, 412, 413, 413, 413, 413, 414, 414, 414, 416, 420, 420, 420, 420, 420, 420, 421, 422, 422, 422, 422, 422, 422, 423, 423, 424, 424, 424, 424, 425, 425, 426, 426, 427, 427, 428, 428, 429, 431, 432, 432, 432, 432, 432, 432, 432, 432, 433, 433, 434, 434, 434, 435, 436, 436, 0, 436, 436, 438, 440, 440, 442, 442, 442, 442, 445, 445, 447, 447, 447, 448, 448, 451, 451, 452, 452, 452, 453, 454, 454, 0, 454, 454, 455, 457, 459, 459, 461, 461, 461, 461, 465, 465, 467, 467, 469, 469, 469, 469, 469, 469, 470, 470, 470, 471, 471, 471, 471, 471, 471, 473, 473, 473, 473, 473, 473, 475, 475, 477, 477, 477, 477, 477, 477, 478, 478, 479, 479, 479, 480, 480, 483, 483, 484, 484, 496, 496, 497, 498, 498, 498, 498, 498, 498, 498, 499, 499, 499, 499, 499, 499, 499, 500, 500, 501, 501, 502, 502, 502, 502, 502, 503, 503, 503, 505, 505, 505, 506, 506, 506, 508, 508, 508, 510, 510, 510, 510, 0, 510, 510, 512, 512, 513, 513, 513, 514, 514, 516, 520, 520, 523, 523, 524, 524, 530, 530, 530, 532, 532, 532, 532, 0, 532, 532, 534, 534, 535, 535, 535, 536, 536, 538, 541, 541, 541, 543, 543, 543, 543, 0, 543, 543, 545, 545, 546, 546, 546, 547, 547, 549, 556, 557, 562, 562, 563, 564, 564, 564, 564, 564, 565, 565, 565, 567, 567, 567, 569, 569, 571, 571, 571, 573, 573, 573, 573, 0, 573, 573, 575, 575, 576, 576, 576, 577, 577, 579, 583, 583, 584, 585, 585, 585, 586, 586, 586, 586, 0, 586, 586, 587, 587, 588, 588, 588, 589, 589, 590, 590, 591, 597, 602, 603, 605, 605, 607, 607, 609, 609, 609, 610, 611, 611, 611, 612, 615, 616, 621, 621, 625, 625, 629, 629, 633, 633, 633, 634, 634, 634, 634, 634, 640, 640, 641, 643, 643, 643, 643, 645, 646, 0, 646, 646, 647, 649, 651, 651, 653, 653, 653, 653, 653, 653, 658, 658, 658, 663, 665, 665, 665, 665, 665, 667, 667, 667, 667, 667, 667, 667, 667, 667, 667, 667, 669, 673, 673, 674, 674, 674, 674, 675, 679, 679, 680, 680, 680, 680, 681, 681, 681, 681, 685, 685, 685, 689, 689, 689, 690, 690, 690, 691, 693, 693, 693, 693, 693, 693, 693, 693, 693, 693, 693, 693, 693, 693, 693, 694, 695, 695, 696, 696, 699, 699, 699, 699, 699, 699, 699, 701, 701, 701, 704, 704, 704, 704, 704, 704, 704, 704, 704, 704, 704, 704, 704, 709, 709, 709, 709, 709, 709, 712, 712, 712, 714, 714, 714, 714, 714, 714, 714, 714, 714, 714, 714, 714, 715, 715, 715, 715, 0, 715, 715, 715, 0, 0, 716, 716, 716, 718, 718, 718, 720, 721, 724, 724, 724, 726, 726, 726, 726, 726, 726, 726, 726, 726, 726, 726, 726, 727, 727, 727, 729, 729, 729, 731, 731, 731, 731, 731, 731, 731, 0, 0, 0, 732, 734, 734, 734, 734, 734, 734, 734, 736, 736, 736, 736, 736, 736, 738, 738, 738, 745, 745, 745, 745, 745, 746, 746, 746, 746, 746, 748, 753, 753, 754, 754, 754, 754, 755, 755, 755, 755, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 190, 261, 266, 267, 268, 269, 272, 273, 275, 276, 277, 278, 279, 280, 281, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 300, 301, 302, 303, 304, 305, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 319, 320, 321, 322, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 348, 349, 354, 355, 358, 362, 365, 366, 368, 369, 370, 372, 373, 374, 375, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 455, 456, 457, 458, 459, 460, 464, 465, 469, 470, 474, 475, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 554, 555, 556, 561, 562, 565, 566, 567, 568, 570, 573, 574, 575, 576, 578, 581, 582, 586, 595, 598, 601, 605, 607, 610, 613, 616, 621, 624, 629, 630, 631, 640, 642, 645, 647, 650, 653, 656, 660, 664, 665, 666, 676, 677, 678, 679, 681, 682, 683, 685, 686, 696, 697, 698, 699, 700, 701, 702, 703, 713, 714, 715, 716, 718, 719, 720, 723, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 860, 861, 866, 867, 868, 869, 870, 871, 874, 875, 876, 877, 878, 879, 880, 898, 899, 901, 904, 905, 906, 908, 911, 914, 915, 916, 917, 918, 919, 920, 921, 925, 926, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 1017, 1018, 1019, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1056, 1093, 1094, 1095, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1132, 1170, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1210, 1215, 1216, 1217, 1218, 1219, 1226, 1227, 1228, 1229, 1233, 1234, 1238, 1239, 1243, 1244, 1248, 1249, 1253, 1254, 1259, 1260, 1261, 1277, 1278, 1280, 1283, 1284, 1285, 1286, 1291, 1292, 1295, 1299, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1310, 1312, 1320, 1322, 1323, 1325, 1326, 1332, 1334, 1335, 1336, 1337, 1348, 1350, 1351, 1352, 1353, 1354, 1355, 1360, 1361, 1362, 1363, 1364, 1387, 1388, 1389, 1390, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1409, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1546, 1547, 1548, 1548, 1551, 1553, 1555, 1558, 1559, 1561, 1562, 1563, 1564, 1571, 1572, 1573, 1574, 1575, 1577, 1578, 1580, 1581, 1582, 1583, 1584, 1586, 1587, 1588, 1588, 1591, 1593, 1594, 1597, 1600, 1601, 1603, 1604, 1605, 1606, 1614, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1628, 1629, 1630, 1631, 1632, 1633, 1636, 1637, 1638, 1639, 1640, 1641, 1643, 1644, 1645, 1646, 1647, 1648, 1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661, 1733, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1766, 1767, 1768, 1769, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1781, 1782, 1783, 1784, 1784, 1787, 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1804, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1814, 1815, 1816, 1817, 1817, 1820, 1822, 1823, 1824, 1825, 1826, 1827, 1828, 1829, 1830, 1837, 1838, 1839, 1841, 1842, 1843, 1844, 1844, 1847, 1849, 1850, 1851, 1852, 1853, 1854, 1855, 1856, 1857, 1868, 1869, 1912, 1917, 1918, 1919, 1920, 1921, 1922, 1927, 1928, 1929, 1930, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1941, 1942, 1943, 1944, 1944, 1947, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1964, 1965, 1966, 1967, 1968, 1969, 1971, 1972, 1973, 1974, 1974, 1977, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1997, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2018, 2019, 2020, 2021, 2022, 2024, 2025, 2030, 2031, 2035, 2036, 2041, 2042, 2053, 2054, 2055, 2057, 2058, 2059, 2060, 2061, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2093, 2096, 2098, 2099, 2102, 2105, 2106, 2108, 2109, 2110, 2111, 2112, 2113, 2120, 2121, 2122, 2142, 2143, 2144, 2145, 2146, 2147, 2148, 2149, 2150, 2151, 2152, 2153, 2154, 2155, 2156, 2157, 2158, 2159, 2168, 2169, 2170, 2171, 2172, 2173, 2174, 2186, 2187, 2188, 2189, 2190, 2191, 2192, 2193, 2194, 2195, 2200, 2201, 2202, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2344, 2345, 2347, 2348, 2349, 2350, 2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359, 2360, 2361, 2362, 2363, 2364, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2384, 2385, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2398, 2399, 2402, 2403, 2404, 2406, 2409, 2413, 2414, 2415, 2418, 2419, 2420, 2422, 2423, 2424, 2425, 2426, 2427, 2428, 2429, 2430, 2431, 2432, 2433, 2434, 2435, 2436, 2437, 2438, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2449, 2450, 2451, 2452, 2454, 2457, 2461, 2464, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480, 2493, 2494, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502, 2503, 2516, 2517, 2518, 2519, 2520, 2521, 2522, 2523, 2524, 2525, 2528, 2531, 2535, 2538, 2542, 2545, 2549, 2552, 2556, 2559, 2563, 2566, 2570, 2573, 2577, 2580, 2584, 2587, 2591, 2594, 2598, 2601};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 23 175
new 0 23 175
assign 1 24 176
new 0 24 176
assign 1 25 177
new 0 25 177
assign 1 27 178
new 0 27 178
assign 1 28 179
new 0 28 179
assign 1 29 180
new 0 29 180
new 1 33 181
assign 1 35 182
new 0 35 182
assign 1 36 183
new 0 36 183
assign 1 37 184
new 0 37 184
assign 1 38 185
new 0 38 185
assign 1 39 186
new 0 39 186
addValue 1 43 190
assign 1 47 261
def 1 47 266
assign 1 48 267
libNameGet 0 48 267
assign 1 48 268
relEmitName 1 48 268
assign 1 48 269
extend 1 48 269
assign 1 50 272
new 0 50 272
assign 1 50 273
extend 1 50 273
assign 1 52 275
new 0 52 275
assign 1 52 276
emitNameGet 0 52 276
assign 1 52 277
addValue 1 52 277
assign 1 52 278
addValue 1 52 278
assign 1 52 279
new 0 52 279
assign 1 52 280
addValue 1 52 280
assign 1 54 281
def 1 54 286
assign 1 55 287
new 0 55 287
addValue 1 55 288
assign 1 57 289
new 0 57 289
addValue 1 57 290
assign 1 59 291
new 0 59 291
assign 1 59 292
addValue 1 59 292
assign 1 59 293
libNameGet 0 59 293
assign 1 59 294
relEmitName 1 59 294
assign 1 59 295
addValue 1 59 295
assign 1 59 296
new 0 59 296
addValue 1 59 297
assign 1 61 300
new 0 61 300
addValue 1 61 301
assign 1 63 302
new 0 63 302
addValue 1 63 303
assign 1 65 304
new 0 65 304
addValue 1 65 305
assign 1 68 307
new 0 68 307
addValue 1 68 308
assign 1 70 309
new 0 70 309
addValue 1 70 310
write 1 72 311
write 1 74 312
write 1 76 313
clear 0 78 314
assign 1 80 315
emitChecksGet 0 80 315
assign 1 80 316
new 0 80 316
assign 1 80 317
has 1 80 317
assign 1 81 319
new 0 81 319
write 1 81 320
assign 1 82 321
new 0 82 321
write 1 82 322
assign 1 84 324
new 0 84 324
write 1 84 325
assign 1 85 326
new 0 85 326
assign 1 85 327
emitNameGet 0 85 327
assign 1 85 328
add 1 85 328
assign 1 85 329
new 0 85 329
assign 1 85 330
add 1 85 330
assign 1 85 331
getHeaderInitialInst 1 85 331
assign 1 85 332
add 1 85 332
assign 1 85 333
new 0 85 333
assign 1 85 334
add 1 85 334
write 1 85 335
assign 1 86 336
new 0 86 336
write 1 86 337
assign 1 87 338
new 0 87 338
write 1 87 339
assign 1 88 340
new 0 88 340
write 1 88 341
assign 1 89 342
new 0 89 342
write 1 89 343
assign 1 90 344
emitChecksGet 0 90 344
assign 1 90 345
new 0 90 345
assign 1 90 346
has 1 90 346
assign 1 90 348
hasDefaultGet 0 90 348
assign 1 90 349
not 0 90 354
assign 1 0 355
assign 1 0 358
assign 1 0 362
assign 1 91 365
new 0 91 365
write 1 91 366
assign 1 93 368
emitChecksGet 0 93 368
assign 1 93 369
new 0 93 369
assign 1 93 370
has 1 93 370
assign 1 94 372
new 0 94 372
write 1 94 373
assign 1 95 374
new 0 95 374
write 1 95 375
assign 1 97 377
new 0 97 377
assign 1 97 378
emitNameGet 0 97 378
assign 1 97 379
add 1 97 379
assign 1 97 380
new 0 97 380
assign 1 97 381
add 1 97 381
write 1 97 382
assign 1 99 383
new 0 99 383
assign 1 99 384
emitNameGet 0 99 384
assign 1 99 385
add 1 99 385
assign 1 99 386
new 0 99 386
assign 1 99 387
add 1 99 387
write 1 99 388
assign 1 101 389
new 0 101 389
return 1 101 390
assign 1 105 420
overrideMtdDecGet 0 105 420
assign 1 105 421
addValue 1 105 421
assign 1 105 422
getClassConfig 1 105 422
assign 1 105 423
libNameGet 0 105 423
assign 1 105 424
relEmitName 1 105 424
assign 1 105 425
addValue 1 105 425
assign 1 105 426
new 0 105 426
assign 1 105 427
addValue 1 105 427
assign 1 105 428
emitNameGet 0 105 428
assign 1 105 429
addValue 1 105 429
assign 1 105 430
new 0 105 430
assign 1 105 431
addValue 1 105 431
assign 1 105 432
addValue 1 105 432
assign 1 105 433
new 0 105 433
assign 1 105 434
addValue 1 105 434
addValue 1 105 435
assign 1 106 436
new 0 106 436
assign 1 106 437
addValue 1 106 437
assign 1 106 438
heldGet 0 106 438
assign 1 106 439
namepathGet 0 106 439
assign 1 106 440
getClassConfig 1 106 440
assign 1 106 441
libNameGet 0 106 441
assign 1 106 442
relEmitName 1 106 442
assign 1 106 443
addValue 1 106 443
assign 1 106 444
new 0 106 444
assign 1 106 445
addValue 1 106 445
addValue 1 106 446
assign 1 108 447
new 0 108 447
assign 1 108 448
addValue 1 108 448
addValue 1 108 449
assign 1 112 455
new 0 112 455
write 1 114 456
clear 0 115 457
assign 1 116 458
new 0 116 458
write 1 116 459
return 1 117 460
assign 1 121 464
new 0 121 464
return 1 121 465
assign 1 125 469
new 0 125 469
return 1 125 470
assign 1 129 474
new 0 129 474
return 1 129 475
assign 1 134 505
addValue 1 134 505
assign 1 134 506
libNameGet 0 134 506
assign 1 134 507
relEmitName 1 134 507
assign 1 134 508
addValue 1 134 508
assign 1 134 509
new 0 134 509
assign 1 134 510
addValue 1 134 510
assign 1 134 511
emitNameGet 0 134 511
assign 1 134 512
addValue 1 134 512
assign 1 134 513
new 0 134 513
assign 1 134 514
addValue 1 134 514
assign 1 134 515
addValue 1 134 515
assign 1 134 516
new 0 134 516
addValue 1 134 517
addValue 1 136 518
assign 1 138 519
new 0 138 519
assign 1 138 520
addValue 1 138 520
assign 1 138 521
addValue 1 138 521
assign 1 138 522
new 0 138 522
assign 1 138 523
addValue 1 138 523
addValue 1 138 524
assign 1 140 525
new 0 140 525
assign 1 140 526
addValue 1 140 526
assign 1 140 527
libNameGet 0 140 527
assign 1 140 528
relEmitName 1 140 528
assign 1 140 529
addValue 1 140 529
assign 1 140 530
new 0 140 530
assign 1 140 531
addValue 1 140 531
assign 1 140 532
addValue 1 140 532
assign 1 140 533
new 0 140 533
addValue 1 140 534
addValue 1 142 535
assign 1 144 536
new 0 144 536
addValue 1 144 537
assign 1 150 554
typenameGet 0 150 554
assign 1 150 555
NULLGet 0 150 555
assign 1 150 556
equals 1 150 561
assign 1 151 562
new 0 151 562
assign 1 152 565
heldGet 0 152 565
assign 1 152 566
nameGet 0 152 566
assign 1 152 567
new 0 152 567
assign 1 152 568
equals 1 152 568
assign 1 153 570
new 0 153 570
assign 1 154 573
heldGet 0 154 573
assign 1 154 574
nameGet 0 154 574
assign 1 154 575
new 0 154 575
assign 1 154 576
equals 1 154 576
assign 1 155 578
new 0 155 578
assign 1 157 581
heldGet 0 157 581
assign 1 157 582
nameForVar 1 157 582
return 1 159 586
assign 1 165 595
isTmpVarGet 0 165 595
assign 1 167 598
new 0 167 598
assign 1 170 601
new 0 170 601
assign 1 172 605
isPropertyGet 0 172 605
assign 1 173 607
new 0 173 607
assign 1 174 610
isArgGet 0 174 610
assign 1 176 613
new 0 176 613
assign 1 179 616
new 0 179 616
assign 1 183 621
new 0 183 621
assign 1 186 624
new 0 186 624
assign 1 189 629
nameGet 0 189 629
assign 1 189 630
add 1 189 630
return 1 189 631
assign 1 196 640
isTmpVarGet 0 196 640
assign 1 197 642
new 0 197 642
assign 1 198 645
isPropertyGet 0 198 645
assign 1 199 647
new 0 199 647
assign 1 200 650
isArgGet 0 200 650
assign 1 202 653
new 0 202 653
assign 1 205 656
new 0 205 656
assign 1 208 660
new 0 208 660
assign 1 210 664
nameGet 0 210 664
assign 1 210 665
add 1 210 665
return 1 210 666
assign 1 215 676
heldGet 0 215 676
assign 1 215 677
nameGet 0 215 677
assign 1 215 678
new 0 215 678
assign 1 215 679
equals 1 215 679
assign 1 216 681
new 0 216 681
assign 1 216 682
add 1 216 682
return 1 217 683
assign 1 219 685
formCallTarg 1 219 685
return 1 219 686
assign 1 223 696
new 0 223 696
assign 1 223 697
addValue 1 223 697
assign 1 223 698
secondGet 0 223 698
assign 1 223 699
formTarg 1 223 699
assign 1 223 700
addValue 1 223 700
assign 1 223 701
new 0 223 701
assign 1 223 702
addValue 1 223 702
addValue 1 223 703
assign 1 227 713
heldGet 0 227 713
assign 1 227 714
langsGet 0 227 714
assign 1 227 715
new 0 227 715
assign 1 227 716
has 1 227 716
assign 1 228 718
heldGet 0 228 718
assign 1 228 719
textGet 0 228 719
addValue 1 228 720
handleClassEmit 1 230 723
assign 1 236 765
new 0 236 765
assign 1 236 766
emitNameGet 0 236 766
assign 1 236 767
add 1 236 767
assign 1 236 768
new 0 236 768
assign 1 236 769
add 1 236 769
assign 1 238 770
new 0 238 770
assign 1 238 771
typeEmitNameGet 0 238 771
assign 1 238 772
add 1 238 772
assign 1 238 773
new 0 238 773
assign 1 238 774
add 1 238 774
assign 1 238 775
add 1 238 775
assign 1 238 776
new 0 238 776
assign 1 238 777
add 1 238 777
addClassHeader 1 240 778
assign 1 242 779
new 0 242 779
assign 1 244 780
typeEmitNameGet 0 244 780
assign 1 244 781
addValue 1 244 781
assign 1 244 782
new 0 244 782
assign 1 244 783
addValue 1 244 783
assign 1 244 784
emitNameGet 0 244 784
assign 1 244 785
addValue 1 244 785
assign 1 244 786
new 0 244 786
assign 1 244 787
addValue 1 244 787
assign 1 244 788
addValue 1 244 788
assign 1 244 789
new 0 244 789
addValue 1 244 790
assign 1 246 791
new 0 246 791
assign 1 246 792
addValue 1 246 792
assign 1 246 793
typeEmitNameGet 0 246 793
assign 1 246 794
addValue 1 246 794
assign 1 246 795
new 0 246 795
assign 1 246 796
addValue 1 246 796
assign 1 246 797
emitNameGet 0 246 797
assign 1 246 798
addValue 1 246 798
assign 1 246 799
new 0 246 799
assign 1 246 800
emitNameGet 0 246 800
assign 1 246 801
add 1 246 801
assign 1 246 802
new 0 246 802
assign 1 246 803
add 1 246 803
addValue 1 246 804
return 1 248 805
assign 1 253 825
new 0 253 825
assign 1 253 826
toString 0 253 826
assign 1 253 827
add 1 253 827
incrementValue 0 254 828
assign 1 255 829
new 0 255 829
assign 1 255 830
addValue 1 255 830
assign 1 255 831
addValue 1 255 831
assign 1 255 832
new 0 255 832
assign 1 255 833
addValue 1 255 833
addValue 1 255 834
assign 1 257 835
containedGet 0 257 835
assign 1 257 836
firstGet 0 257 836
assign 1 257 837
containedGet 0 257 837
assign 1 257 838
firstGet 0 257 838
assign 1 257 839
new 0 257 839
assign 1 257 840
add 1 257 840
assign 1 257 841
new 0 257 841
assign 1 257 842
add 1 257 842
assign 1 257 843
finalAssign 4 257 843
addValue 1 257 844
assign 1 261 860
isTypedGet 0 261 860
assign 1 261 861
not 0 261 866
assign 1 262 867
libNameGet 0 262 867
assign 1 262 868
relEmitName 1 262 868
assign 1 262 869
addValue 1 262 869
assign 1 262 870
new 0 262 870
addValue 1 262 871
assign 1 264 874
namepathGet 0 264 874
assign 1 264 875
getClassConfig 1 264 875
assign 1 264 876
libNameGet 0 264 876
assign 1 264 877
relEmitName 1 264 877
assign 1 264 878
addValue 1 264 878
assign 1 264 879
new 0 264 879
addValue 1 264 880
assign 1 269 898
new 0 269 898
assign 1 269 899
equals 1 269 899
assign 1 270 901
new 0 270 901
assign 1 272 904
emitChecksGet 0 272 904
assign 1 272 905
new 0 272 905
assign 1 272 906
has 1 272 906
assign 1 273 908
new 0 273 908
assign 1 275 911
new 0 275 911
assign 1 278 914
new 0 278 914
assign 1 278 915
add 1 278 915
assign 1 278 916
libNameGet 0 278 916
assign 1 278 917
relEmitName 1 278 917
assign 1 278 918
add 1 278 918
assign 1 278 919
new 0 278 919
assign 1 278 920
add 1 278 920
return 1 278 921
assign 1 283 925
new 0 283 925
return 1 283 926
assign 1 287 953
overrideMtdDecGet 0 287 953
assign 1 287 954
addValue 1 287 954
assign 1 287 955
new 0 287 955
assign 1 287 956
addValue 1 287 956
assign 1 287 957
emitNameGet 0 287 957
assign 1 287 958
addValue 1 287 958
assign 1 287 959
new 0 287 959
assign 1 287 960
addValue 1 287 960
assign 1 287 961
addValue 1 287 961
assign 1 287 962
new 0 287 962
assign 1 287 963
addValue 1 287 963
assign 1 287 964
addValue 1 287 964
assign 1 287 965
new 0 287 965
assign 1 287 966
addValue 1 287 966
addValue 1 287 967
assign 1 288 968
new 0 288 968
assign 1 288 969
addValue 1 288 969
assign 1 288 970
addValue 1 288 970
assign 1 288 971
new 0 288 971
assign 1 288 972
addValue 1 288 972
assign 1 288 973
addValue 1 288 973
assign 1 288 974
new 0 288 974
assign 1 288 975
addValue 1 288 975
addValue 1 288 976
assign 1 290 977
new 0 290 977
assign 1 290 978
addValue 1 290 978
addValue 1 290 979
assign 1 294 1017
emitChecksGet 0 294 1017
assign 1 294 1018
new 0 294 1018
assign 1 294 1019
has 1 294 1019
assign 1 295 1021
new 0 295 1021
assign 1 295 1022
libNameGet 0 295 1022
assign 1 295 1023
relEmitName 1 295 1023
assign 1 295 1024
add 1 295 1024
assign 1 295 1025
new 0 295 1025
assign 1 295 1026
add 1 295 1026
assign 1 295 1027
libNameGet 0 295 1027
assign 1 295 1028
relEmitName 1 295 1028
assign 1 295 1029
add 1 295 1029
assign 1 295 1030
new 0 295 1030
assign 1 295 1031
add 1 295 1031
assign 1 295 1032
heldGet 0 295 1032
assign 1 295 1033
literalValueGet 0 295 1033
assign 1 295 1034
add 1 295 1034
assign 1 295 1035
new 0 295 1035
assign 1 295 1036
add 1 295 1036
assign 1 297 1039
new 0 297 1039
assign 1 297 1040
libNameGet 0 297 1040
assign 1 297 1041
relEmitName 1 297 1041
assign 1 297 1042
add 1 297 1042
assign 1 297 1043
new 0 297 1043
assign 1 297 1044
add 1 297 1044
assign 1 297 1045
libNameGet 0 297 1045
assign 1 297 1046
relEmitName 1 297 1046
assign 1 297 1047
add 1 297 1047
assign 1 297 1048
new 0 297 1048
assign 1 297 1049
add 1 297 1049
assign 1 297 1050
heldGet 0 297 1050
assign 1 297 1051
literalValueGet 0 297 1051
assign 1 297 1052
add 1 297 1052
assign 1 297 1053
new 0 297 1053
assign 1 297 1054
add 1 297 1054
return 1 299 1056
assign 1 303 1093
emitChecksGet 0 303 1093
assign 1 303 1094
new 0 303 1094
assign 1 303 1095
has 1 303 1095
assign 1 304 1097
new 0 304 1097
assign 1 304 1098
libNameGet 0 304 1098
assign 1 304 1099
relEmitName 1 304 1099
assign 1 304 1100
add 1 304 1100
assign 1 304 1101
new 0 304 1101
assign 1 304 1102
add 1 304 1102
assign 1 304 1103
libNameGet 0 304 1103
assign 1 304 1104
relEmitName 1 304 1104
assign 1 304 1105
add 1 304 1105
assign 1 304 1106
new 0 304 1106
assign 1 304 1107
add 1 304 1107
assign 1 304 1108
heldGet 0 304 1108
assign 1 304 1109
literalValueGet 0 304 1109
assign 1 304 1110
add 1 304 1110
assign 1 304 1111
new 0 304 1111
assign 1 304 1112
add 1 304 1112
assign 1 306 1115
new 0 306 1115
assign 1 306 1116
libNameGet 0 306 1116
assign 1 306 1117
relEmitName 1 306 1117
assign 1 306 1118
add 1 306 1118
assign 1 306 1119
new 0 306 1119
assign 1 306 1120
add 1 306 1120
assign 1 306 1121
libNameGet 0 306 1121
assign 1 306 1122
relEmitName 1 306 1122
assign 1 306 1123
add 1 306 1123
assign 1 306 1124
new 0 306 1124
assign 1 306 1125
add 1 306 1125
assign 1 306 1126
heldGet 0 306 1126
assign 1 306 1127
literalValueGet 0 306 1127
assign 1 306 1128
add 1 306 1128
assign 1 306 1129
new 0 306 1129
assign 1 306 1130
add 1 306 1130
return 1 308 1132
assign 1 312 1170
new 0 312 1170
assign 1 312 1171
add 1 312 1171
assign 1 312 1172
new 0 312 1172
assign 1 312 1173
add 1 312 1173
assign 1 312 1174
add 1 312 1174
assign 1 313 1175
emitChecksGet 0 313 1175
assign 1 313 1176
new 0 313 1176
assign 1 313 1177
has 1 313 1177
assign 1 314 1179
new 0 314 1179
assign 1 314 1180
libNameGet 0 314 1180
assign 1 314 1181
relEmitName 1 314 1181
assign 1 314 1182
add 1 314 1182
assign 1 314 1183
new 0 314 1183
assign 1 314 1184
add 1 314 1184
assign 1 314 1185
libNameGet 0 314 1185
assign 1 314 1186
relEmitName 1 314 1186
assign 1 314 1187
add 1 314 1187
assign 1 314 1188
new 0 314 1188
assign 1 314 1189
add 1 314 1189
assign 1 314 1190
add 1 314 1190
assign 1 314 1191
new 0 314 1191
assign 1 314 1192
add 1 314 1192
assign 1 316 1195
new 0 316 1195
assign 1 316 1196
libNameGet 0 316 1196
assign 1 316 1197
relEmitName 1 316 1197
assign 1 316 1198
add 1 316 1198
assign 1 316 1199
new 0 316 1199
assign 1 316 1200
add 1 316 1200
assign 1 316 1201
libNameGet 0 316 1201
assign 1 316 1202
relEmitName 1 316 1202
assign 1 316 1203
add 1 316 1203
assign 1 316 1204
new 0 316 1204
assign 1 316 1205
add 1 316 1205
assign 1 316 1206
add 1 316 1206
assign 1 316 1207
new 0 316 1207
assign 1 316 1208
add 1 316 1208
return 1 318 1210
getCode 2 323 1215
assign 1 324 1216
toHexString 1 324 1216
assign 1 325 1217
new 0 325 1217
addValue 1 325 1218
addValue 1 326 1219
assign 1 332 1226
new 0 332 1226
assign 1 332 1227
add 1 332 1227
assign 1 332 1228
add 1 332 1228
return 1 332 1229
assign 1 336 1233
new 0 336 1233
return 1 336 1234
assign 1 340 1238
new 0 340 1238
return 1 340 1239
assign 1 345 1243
new 0 345 1243
return 1 345 1244
assign 1 349 1248
new 0 349 1248
return 1 349 1249
assign 1 353 1253
new 0 353 1253
return 1 353 1254
assign 1 357 1259
new 0 357 1259
assign 1 357 1260
add 1 357 1260
return 1 357 1261
assign 1 364 1277
assign 1 365 1278
singleCCGet 0 365 1278
assign 1 0 1280
assign 1 365 1283
classPathGet 0 365 1283
assign 1 365 1284
fileGet 0 365 1284
assign 1 365 1285
existsGet 0 365 1285
assign 1 365 1286
not 0 365 1291
assign 1 0 1292
assign 1 0 1295
return 1 366 1299
assign 1 368 1302
classPathGet 0 368 1302
assign 1 368 1303
fileGet 0 368 1303
assign 1 368 1304
lastUpdatedGet 0 368 1304
assign 1 369 1305
fromFileGet 0 369 1305
assign 1 369 1306
fileGet 0 369 1306
assign 1 369 1307
lastUpdatedGet 0 369 1307
assign 1 370 1308
greater 1 370 1308
return 1 373 1310
assign 1 376 1312
assign 1 381 1320
singleCCGet 0 381 1320
assign 1 382 1322
getLibOutput 0 382 1322
return 1 382 1323
assign 1 384 1325
getClassOutput 0 384 1325
return 1 384 1326
assign 1 388 1332
singleCCGet 0 388 1332
assign 1 389 1334
new 0 389 1334
assign 1 390 1335
countLines 1 390 1335
addValue 1 390 1336
write 1 391 1337
assign 1 396 1348
singleCCGet 0 396 1348
assign 1 398 1350
new 0 398 1350
assign 1 399 1351
countLines 1 399 1351
addValue 1 399 1352
write 1 400 1353
close 0 401 1354
assign 1 402 1355
def 1 402 1360
assign 1 403 1361
pathGet 0 403 1361
assign 1 403 1362
fileGet 0 403 1362
lastUpdatedSet 1 403 1363
assign 1 404 1364
assign 1 410 1387
new 0 410 1387
assign 1 411 1388
emitChecksGet 0 411 1388
assign 1 411 1389
new 0 411 1389
assign 1 411 1390
has 1 411 1390
assign 1 412 1392
new 0 412 1392
assign 1 412 1393
addValue 1 412 1393
assign 1 412 1394
addValue 1 412 1394
assign 1 412 1395
new 0 412 1395
assign 1 412 1396
addValue 1 412 1396
assign 1 412 1397
addValue 1 412 1397
assign 1 412 1398
new 0 412 1398
assign 1 412 1399
addValue 1 412 1399
addValue 1 412 1400
assign 1 413 1401
addValue 1 413 1401
assign 1 413 1402
new 0 413 1402
assign 1 413 1403
addValue 1 413 1403
addValue 1 413 1404
assign 1 414 1405
new 0 414 1405
assign 1 414 1406
addValue 1 414 1406
addValue 1 414 1407
return 1 416 1409
assign 1 420 1503
new 0 420 1503
assign 1 420 1504
typeEmitNameGet 0 420 1504
assign 1 420 1505
add 1 420 1505
assign 1 420 1506
new 0 420 1506
assign 1 420 1507
add 1 420 1507
write 1 420 1508
assign 1 421 1509
new 0 421 1509
assign 1 422 1510
new 0 422 1510
assign 1 422 1511
addValue 1 422 1511
assign 1 422 1512
typeEmitNameGet 0 422 1512
assign 1 422 1513
addValue 1 422 1513
assign 1 422 1514
new 0 422 1514
addValue 1 422 1515
assign 1 423 1516
new 0 423 1516
addValue 1 423 1517
assign 1 424 1518
typeEmitNameGet 0 424 1518
assign 1 424 1519
addValue 1 424 1519
assign 1 424 1520
new 0 424 1520
addValue 1 424 1521
assign 1 425 1522
new 0 425 1522
addValue 1 425 1523
assign 1 426 1524
new 0 426 1524
addValue 1 426 1525
assign 1 427 1526
new 0 427 1526
addValue 1 427 1527
assign 1 428 1528
new 0 428 1528
addValue 1 428 1529
write 1 429 1530
assign 1 431 1531
new 0 431 1531
assign 1 432 1532
typeEmitNameGet 0 432 1532
assign 1 432 1533
addValue 1 432 1533
assign 1 432 1534
new 0 432 1534
assign 1 432 1535
addValue 1 432 1535
assign 1 432 1536
typeEmitNameGet 0 432 1536
assign 1 432 1537
addValue 1 432 1537
assign 1 432 1538
new 0 432 1538
addValue 1 432 1539
assign 1 433 1540
new 0 433 1540
addValue 1 433 1541
assign 1 434 1542
emitChecksGet 0 434 1542
assign 1 434 1543
new 0 434 1543
assign 1 434 1544
has 1 434 1544
assign 1 435 1546
new 0 435 1546
assign 1 436 1547
mtdListGet 0 436 1547
assign 1 436 1548
iteratorGet 0 0 1548
assign 1 436 1551
hasNextGet 0 436 1551
assign 1 436 1553
nextGet 0 436 1553
assign 1 438 1555
new 0 438 1555
assign 1 440 1558
new 0 440 1558
addValue 1 440 1559
assign 1 442 1561
addValue 1 442 1561
assign 1 442 1562
nameGet 0 442 1562
assign 1 442 1563
addValue 1 442 1563
addValue 1 442 1564
assign 1 445 1571
new 0 445 1571
addValue 1 445 1572
assign 1 447 1573
emitChecksGet 0 447 1573
assign 1 447 1574
new 0 447 1574
assign 1 447 1575
has 1 447 1575
assign 1 448 1577
new 0 448 1577
addValue 1 448 1578
assign 1 451 1580
new 0 451 1580
addValue 1 451 1581
assign 1 452 1582
emitChecksGet 0 452 1582
assign 1 452 1583
new 0 452 1583
assign 1 452 1584
has 1 452 1584
assign 1 453 1586
new 0 453 1586
assign 1 454 1587
ptyListGet 0 454 1587
assign 1 454 1588
iteratorGet 0 0 1588
assign 1 454 1591
hasNextGet 0 454 1591
assign 1 454 1593
nextGet 0 454 1593
assign 1 455 1594
isSlotGet 0 455 1594
assign 1 457 1597
new 0 457 1597
assign 1 459 1600
new 0 459 1600
addValue 1 459 1601
assign 1 461 1603
addValue 1 461 1603
assign 1 461 1604
nameGet 0 461 1604
assign 1 461 1605
addValue 1 461 1605
addValue 1 461 1606
assign 1 465 1614
new 0 465 1614
addValue 1 465 1615
assign 1 467 1616
new 0 467 1616
addValue 1 467 1617
assign 1 469 1618
new 0 469 1618
assign 1 469 1619
addValue 1 469 1619
assign 1 469 1620
typeEmitNameGet 0 469 1620
assign 1 469 1621
addValue 1 469 1621
assign 1 469 1622
new 0 469 1622
addValue 1 469 1623
assign 1 470 1624
emitNameGet 0 470 1624
assign 1 470 1625
new 0 470 1625
assign 1 470 1626
equals 1 470 1626
assign 1 471 1628
new 0 471 1628
assign 1 471 1629
addValue 1 471 1629
assign 1 471 1630
emitNameGet 0 471 1630
assign 1 471 1631
addValue 1 471 1631
assign 1 471 1632
new 0 471 1632
addValue 1 471 1633
assign 1 473 1636
new 0 473 1636
assign 1 473 1637
addValue 1 473 1637
assign 1 473 1638
emitNameGet 0 473 1638
assign 1 473 1639
addValue 1 473 1639
assign 1 473 1640
new 0 473 1640
addValue 1 473 1641
assign 1 475 1643
new 0 475 1643
addValue 1 475 1644
assign 1 477 1645
new 0 477 1645
assign 1 477 1646
addValue 1 477 1646
assign 1 477 1647
typeEmitNameGet 0 477 1647
assign 1 477 1648
addValue 1 477 1648
assign 1 477 1649
new 0 477 1649
addValue 1 477 1650
assign 1 478 1651
new 0 478 1651
addValue 1 478 1652
assign 1 479 1653
new 0 479 1653
assign 1 479 1654
genMark 1 479 1654
addValue 1 479 1655
assign 1 480 1656
new 0 480 1656
addValue 1 480 1657
assign 1 483 1658
getClassOutput 0 483 1658
write 1 483 1659
assign 1 484 1660
countLines 1 484 1660
addValue 1 484 1661
assign 1 496 1733
undef 1 496 1738
assign 1 497 1739
libNameGet 0 497 1739
assign 1 498 1740
new 0 498 1740
assign 1 498 1741
lengthGet 0 498 1741
assign 1 498 1742
add 1 498 1742
assign 1 498 1743
new 0 498 1743
assign 1 498 1744
add 1 498 1744
assign 1 498 1745
add 1 498 1745
assign 1 498 1746
add 1 498 1746
assign 1 499 1747
new 0 499 1747
assign 1 499 1748
lengthGet 0 499 1748
assign 1 499 1749
add 1 499 1749
assign 1 499 1750
new 0 499 1750
assign 1 499 1751
add 1 499 1751
assign 1 499 1752
add 1 499 1752
assign 1 499 1753
add 1 499 1753
assign 1 500 1754
parentGet 0 500 1754
assign 1 500 1755
addStep 1 500 1755
assign 1 501 1756
parentGet 0 501 1756
assign 1 501 1757
addStep 1 501 1757
assign 1 502 1758
parentGet 0 502 1758
assign 1 502 1759
fileGet 0 502 1759
assign 1 502 1760
existsGet 0 502 1760
assign 1 502 1761
not 0 502 1766
assign 1 503 1767
parentGet 0 503 1767
assign 1 503 1768
fileGet 0 503 1768
makeDirs 0 503 1769
assign 1 505 1771
fileGet 0 505 1771
assign 1 505 1772
writerGet 0 505 1772
assign 1 505 1773
open 0 505 1773
assign 1 506 1774
fileGet 0 506 1774
assign 1 506 1775
writerGet 0 506 1775
assign 1 506 1776
open 0 506 1776
assign 1 508 1777
paramsGet 0 508 1777
assign 1 508 1778
new 0 508 1778
assign 1 508 1779
has 1 508 1779
assign 1 510 1781
paramsGet 0 510 1781
assign 1 510 1782
new 0 510 1782
assign 1 510 1783
get 1 510 1783
assign 1 510 1784
iteratorGet 0 0 1784
assign 1 510 1787
hasNextGet 0 510 1787
assign 1 510 1789
nextGet 0 510 1789
assign 1 512 1790
apNew 1 512 1790
assign 1 512 1791
fileGet 0 512 1791
assign 1 513 1792
readerGet 0 513 1792
assign 1 513 1793
open 0 513 1793
assign 1 513 1794
readString 0 513 1794
assign 1 514 1795
readerGet 0 514 1795
close 0 514 1796
write 1 516 1797
assign 1 520 1804
new 0 520 1804
write 1 520 1805
assign 1 523 1806
new 0 523 1806
write 1 523 1807
assign 1 524 1808
new 0 524 1808
write 1 524 1809
assign 1 530 1810
paramsGet 0 530 1810
assign 1 530 1811
new 0 530 1811
assign 1 530 1812
has 1 530 1812
assign 1 532 1814
paramsGet 0 532 1814
assign 1 532 1815
new 0 532 1815
assign 1 532 1816
get 1 532 1816
assign 1 532 1817
iteratorGet 0 0 1817
assign 1 532 1820
hasNextGet 0 532 1820
assign 1 532 1822
nextGet 0 532 1822
assign 1 534 1823
apNew 1 534 1823
assign 1 534 1824
fileGet 0 534 1824
assign 1 535 1825
readerGet 0 535 1825
assign 1 535 1826
open 0 535 1826
assign 1 535 1827
readString 0 535 1827
assign 1 536 1828
readerGet 0 536 1828
close 0 536 1829
write 1 538 1830
assign 1 541 1837
paramsGet 0 541 1837
assign 1 541 1838
new 0 541 1838
assign 1 541 1839
has 1 541 1839
assign 1 543 1841
paramsGet 0 543 1841
assign 1 543 1842
new 0 543 1842
assign 1 543 1843
get 1 543 1843
assign 1 543 1844
iteratorGet 0 0 1844
assign 1 543 1847
hasNextGet 0 543 1847
assign 1 543 1849
nextGet 0 543 1849
assign 1 545 1850
apNew 1 545 1850
assign 1 545 1851
fileGet 0 545 1851
assign 1 546 1852
readerGet 0 546 1852
assign 1 546 1853
open 0 546 1853
assign 1 546 1854
readString 0 546 1854
assign 1 547 1855
readerGet 0 547 1855
close 0 547 1856
write 1 549 1857
begin 1 556 1868
prepHeaderOutput 0 557 1869
assign 1 562 1912
undef 1 562 1917
assign 1 563 1918
new 0 563 1918
assign 1 564 1919
parentGet 0 564 1919
assign 1 564 1920
fileGet 0 564 1920
assign 1 564 1921
existsGet 0 564 1921
assign 1 564 1922
not 0 564 1927
assign 1 565 1928
parentGet 0 565 1928
assign 1 565 1929
fileGet 0 565 1929
makeDirs 0 565 1930
assign 1 567 1932
fileGet 0 567 1932
assign 1 567 1933
writerGet 0 567 1933
assign 1 567 1934
open 0 567 1934
assign 1 569 1935
new 0 569 1935
write 1 569 1936
assign 1 571 1937
paramsGet 0 571 1937
assign 1 571 1938
new 0 571 1938
assign 1 571 1939
has 1 571 1939
assign 1 573 1941
paramsGet 0 573 1941
assign 1 573 1942
new 0 573 1942
assign 1 573 1943
get 1 573 1943
assign 1 573 1944
iteratorGet 0 0 1944
assign 1 573 1947
hasNextGet 0 573 1947
assign 1 573 1949
nextGet 0 573 1949
assign 1 575 1950
apNew 1 575 1950
assign 1 575 1951
fileGet 0 575 1951
assign 1 576 1952
readerGet 0 576 1952
assign 1 576 1953
open 0 576 1953
assign 1 576 1954
readString 0 576 1954
assign 1 577 1955
readerGet 0 577 1955
close 0 577 1956
write 1 579 1957
assign 1 583 1964
new 0 583 1964
write 1 583 1965
incrementValue 0 584 1966
assign 1 585 1967
paramsGet 0 585 1967
assign 1 585 1968
new 0 585 1968
assign 1 585 1969
has 1 585 1969
assign 1 586 1971
paramsGet 0 586 1971
assign 1 586 1972
new 0 586 1972
assign 1 586 1973
get 1 586 1973
assign 1 586 1974
iteratorGet 0 0 1974
assign 1 586 1977
hasNextGet 0 586 1977
assign 1 586 1979
nextGet 0 586 1979
assign 1 587 1980
apNew 1 587 1980
assign 1 587 1981
fileGet 0 587 1981
assign 1 588 1982
readerGet 0 588 1982
assign 1 588 1983
open 0 588 1983
assign 1 588 1984
readString 0 588 1984
assign 1 589 1985
readerGet 0 589 1985
close 0 589 1986
assign 1 590 1987
countLines 1 590 1987
addValue 1 590 1988
write 1 591 1989
return 1 597 1997
close 0 602 2008
assign 1 603 2009
assign 1 605 2010
new 0 605 2010
write 1 605 2011
assign 1 607 2012
new 0 607 2012
write 1 607 2013
assign 1 609 2014
emitChecksGet 0 609 2014
assign 1 609 2015
new 0 609 2015
assign 1 609 2016
has 1 609 2016
assign 1 610 2018
new 0 610 2018
assign 1 611 2019
new 0 611 2019
assign 1 611 2020
addValue 1 611 2020
addValue 1 611 2021
write 1 612 2022
close 0 615 2024
close 0 616 2025
assign 1 621 2030
new 0 621 2030
return 1 621 2031
assign 1 625 2035
new 0 625 2035
addValue 1 625 2036
assign 1 629 2041
new 0 629 2041
addValue 1 629 2042
assign 1 633 2053
emitChecksGet 0 633 2053
assign 1 633 2054
new 0 633 2054
assign 1 633 2055
has 1 633 2055
assign 1 634 2057
new 0 634 2057
assign 1 634 2058
addValue 1 634 2058
assign 1 634 2059
addValue 1 634 2059
assign 1 634 2060
new 0 634 2060
addValue 1 634 2061
assign 1 640 2085
heldGet 0 640 2085
assign 1 640 2086
synGet 0 640 2086
assign 1 641 2087
ptyListGet 0 641 2087
assign 1 643 2088
emitNameGet 0 643 2088
assign 1 643 2089
addValue 1 643 2089
assign 1 643 2090
new 0 643 2090
addValue 1 643 2091
assign 1 645 2092
new 0 645 2092
assign 1 646 2093
iteratorGet 0 0 2093
assign 1 646 2096
hasNextGet 0 646 2096
assign 1 646 2098
nextGet 0 646 2098
assign 1 647 2099
isSlotGet 0 647 2099
assign 1 649 2102
new 0 649 2102
assign 1 651 2105
new 0 651 2105
addValue 1 651 2106
assign 1 653 2108
addValue 1 653 2108
assign 1 653 2109
new 0 653 2109
assign 1 653 2110
addValue 1 653 2110
assign 1 653 2111
nameGet 0 653 2111
assign 1 653 2112
addValue 1 653 2112
addValue 1 653 2113
assign 1 658 2120
new 0 658 2120
assign 1 658 2121
addValue 1 658 2121
addValue 1 658 2122
assign 1 663 2142
new 0 663 2142
assign 1 665 2143
new 0 665 2143
assign 1 665 2144
emitNameGet 0 665 2144
assign 1 665 2145
add 1 665 2145
assign 1 665 2146
new 0 665 2146
assign 1 665 2147
add 1 665 2147
assign 1 667 2148
emitNameGet 0 667 2148
assign 1 667 2149
addValue 1 667 2149
assign 1 667 2150
new 0 667 2150
assign 1 667 2151
addValue 1 667 2151
assign 1 667 2152
emitNameGet 0 667 2152
assign 1 667 2153
addValue 1 667 2153
assign 1 667 2154
new 0 667 2154
assign 1 667 2155
addValue 1 667 2155
assign 1 667 2156
addValue 1 667 2156
assign 1 667 2157
new 0 667 2157
addValue 1 667 2158
return 1 669 2159
assign 1 673 2168
libNameGet 0 673 2168
assign 1 673 2169
relEmitName 1 673 2169
assign 1 674 2170
new 0 674 2170
assign 1 674 2171
add 1 674 2171
assign 1 674 2172
new 0 674 2172
assign 1 674 2173
add 1 674 2173
return 1 675 2174
assign 1 679 2186
libNameGet 0 679 2186
assign 1 679 2187
relEmitName 1 679 2187
assign 1 680 2188
new 0 680 2188
assign 1 680 2189
add 1 680 2189
assign 1 680 2190
new 0 680 2190
assign 1 680 2191
add 1 680 2191
assign 1 681 2192
new 0 681 2192
assign 1 681 2193
add 1 681 2193
assign 1 681 2194
add 1 681 2194
return 1 681 2195
assign 1 685 2200
new 0 685 2200
assign 1 685 2201
add 1 685 2201
return 1 685 2202
assign 1 689 2318
getClassConfig 1 689 2318
assign 1 689 2319
libNameGet 0 689 2319
assign 1 689 2320
relEmitName 1 689 2320
assign 1 690 2321
heldGet 0 690 2321
assign 1 690 2322
namepathGet 0 690 2322
assign 1 690 2323
getClassConfig 1 690 2323
assign 1 691 2324
getInitialInst 1 691 2324
assign 1 693 2325
overrideMtdDecGet 0 693 2325
assign 1 693 2326
addValue 1 693 2326
assign 1 693 2327
new 0 693 2327
assign 1 693 2328
addValue 1 693 2328
assign 1 693 2329
emitNameGet 0 693 2329
assign 1 693 2330
addValue 1 693 2330
assign 1 693 2331
new 0 693 2331
assign 1 693 2332
addValue 1 693 2332
assign 1 693 2333
addValue 1 693 2333
assign 1 693 2334
new 0 693 2334
assign 1 693 2335
addValue 1 693 2335
assign 1 693 2336
addValue 1 693 2336
assign 1 693 2337
new 0 693 2337
assign 1 693 2338
addValue 1 693 2338
addValue 1 693 2339
assign 1 694 2340
new 0 694 2340
assign 1 695 2341
emitNameGet 0 695 2341
assign 1 695 2342
notEquals 1 695 2342
assign 1 696 2344
new 0 696 2344
assign 1 696 2345
formCast 3 696 2345
assign 1 699 2347
addValue 1 699 2347
assign 1 699 2348
new 0 699 2348
assign 1 699 2349
addValue 1 699 2349
assign 1 699 2350
addValue 1 699 2350
assign 1 699 2351
new 0 699 2351
assign 1 699 2352
addValue 1 699 2352
addValue 1 699 2353
assign 1 701 2354
new 0 701 2354
assign 1 701 2355
addValue 1 701 2355
addValue 1 701 2356
assign 1 704 2357
overrideMtdDecGet 0 704 2357
assign 1 704 2358
addValue 1 704 2358
assign 1 704 2359
addValue 1 704 2359
assign 1 704 2360
new 0 704 2360
assign 1 704 2361
addValue 1 704 2361
assign 1 704 2362
emitNameGet 0 704 2362
assign 1 704 2363
addValue 1 704 2363
assign 1 704 2364
new 0 704 2364
assign 1 704 2365
addValue 1 704 2365
assign 1 704 2366
addValue 1 704 2366
assign 1 704 2367
new 0 704 2367
assign 1 704 2368
addValue 1 704 2368
addValue 1 704 2369
assign 1 709 2370
new 0 709 2370
assign 1 709 2371
addValue 1 709 2371
assign 1 709 2372
addValue 1 709 2372
assign 1 709 2373
new 0 709 2373
assign 1 709 2374
addValue 1 709 2374
addValue 1 709 2375
assign 1 712 2376
new 0 712 2376
assign 1 712 2377
addValue 1 712 2377
addValue 1 712 2378
assign 1 714 2379
overrideMtdDecGet 0 714 2379
assign 1 714 2380
addValue 1 714 2380
assign 1 714 2381
new 0 714 2381
assign 1 714 2382
addValue 1 714 2382
assign 1 714 2383
emitNameGet 0 714 2383
assign 1 714 2384
addValue 1 714 2384
assign 1 714 2385
new 0 714 2385
assign 1 714 2386
addValue 1 714 2386
assign 1 714 2387
addValue 1 714 2387
assign 1 714 2388
new 0 714 2388
assign 1 714 2389
addValue 1 714 2389
addValue 1 714 2390
assign 1 715 2391
heldGet 0 715 2391
assign 1 715 2392
extendsGet 0 715 2392
assign 1 715 2393
undef 1 715 2398
assign 1 0 2399
assign 1 715 2402
heldGet 0 715 2402
assign 1 715 2403
extendsGet 0 715 2403
assign 1 715 2404
equals 1 715 2404
assign 1 0 2406
assign 1 0 2409
assign 1 716 2413
new 0 716 2413
assign 1 716 2414
addValue 1 716 2414
addValue 1 716 2415
assign 1 718 2418
new 0 718 2418
assign 1 718 2419
addValue 1 718 2419
addValue 1 718 2420
addValue 1 720 2422
clear 0 721 2423
assign 1 724 2424
new 0 724 2424
assign 1 724 2425
addValue 1 724 2425
addValue 1 724 2426
assign 1 726 2427
overrideMtdDecGet 0 726 2427
assign 1 726 2428
addValue 1 726 2428
assign 1 726 2429
new 0 726 2429
assign 1 726 2430
addValue 1 726 2430
assign 1 726 2431
emitNameGet 0 726 2431
assign 1 726 2432
addValue 1 726 2432
assign 1 726 2433
new 0 726 2433
assign 1 726 2434
addValue 1 726 2434
assign 1 726 2435
addValue 1 726 2435
assign 1 726 2436
new 0 726 2436
assign 1 726 2437
addValue 1 726 2437
addValue 1 726 2438
assign 1 727 2439
new 0 727 2439
assign 1 727 2440
addValue 1 727 2440
addValue 1 727 2441
assign 1 729 2442
new 0 729 2442
assign 1 729 2443
addValue 1 729 2443
addValue 1 729 2444
assign 1 731 2445
emitChecksGet 0 731 2445
assign 1 731 2446
new 0 731 2446
assign 1 731 2447
has 1 731 2447
assign 1 731 2449
heldGet 0 731 2449
assign 1 731 2450
synGet 0 731 2450
assign 1 731 2451
hasDefaultGet 0 731 2451
assign 1 731 2452
not 0 731 2452
assign 1 0 2454
assign 1 0 2457
assign 1 0 2461
assign 1 732 2464
getTypeInst 1 732 2464
assign 1 734 2465
new 0 734 2465
assign 1 734 2466
addValue 1 734 2466
assign 1 734 2467
emitNameGet 0 734 2467
assign 1 734 2468
addValue 1 734 2468
assign 1 734 2469
new 0 734 2469
assign 1 734 2470
addValue 1 734 2470
addValue 1 734 2471
assign 1 736 2472
new 0 736 2472
assign 1 736 2473
addValue 1 736 2473
assign 1 736 2474
addValue 1 736 2474
assign 1 736 2475
new 0 736 2475
assign 1 736 2476
addValue 1 736 2476
addValue 1 736 2477
assign 1 738 2478
new 0 738 2478
assign 1 738 2479
addValue 1 738 2479
addValue 1 738 2480
assign 1 745 2493
new 0 745 2493
assign 1 745 2494
add 1 745 2494
assign 1 745 2495
new 0 745 2495
assign 1 745 2496
add 1 745 2496
write 1 745 2497
assign 1 746 2498
new 0 746 2498
assign 1 746 2499
add 1 746 2499
assign 1 746 2500
new 0 746 2500
assign 1 746 2501
add 1 746 2501
write 1 746 2502
emitLib 0 748 2503
assign 1 753 2516
libNameGet 0 753 2516
assign 1 753 2517
relEmitName 1 753 2517
assign 1 754 2518
new 0 754 2518
assign 1 754 2519
add 1 754 2519
assign 1 754 2520
new 0 754 2520
assign 1 754 2521
add 1 754 2521
assign 1 755 2522
new 0 755 2522
assign 1 755 2523
add 1 755 2523
assign 1 755 2524
add 1 755 2524
return 1 755 2525
return 1 0 2528
assign 1 0 2531
return 1 0 2535
assign 1 0 2538
return 1 0 2542
assign 1 0 2545
return 1 0 2549
assign 1 0 2552
return 1 0 2556
assign 1 0 2559
return 1 0 2563
assign 1 0 2566
return 1 0 2570
assign 1 0 2573
return 1 0 2577
assign 1 0 2580
return 1 0 2584
assign 1 0 2587
return 1 0 2591
assign 1 0 2594
return 1 0 2598
assign 1 0 2601
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1115883602: return bem_gcMarksGet_0();
case 1506888014: return bem_lastMethodsSizeGet_0();
case 450249311: return bem_fileExtGet_0();
case -314467828: return bem_deowGet_0();
case 1610898134: return bem_newDecGet_0();
case 1229984818: return bem_prepHeaderOutput_0();
case 1386318456: return bem_ccMethodsGet_0();
case -796445589: return bem_initialDecGet_0();
case 1789874565: return bem_lastMethodBodyLinesGet_0();
case 1172373244: return bem_smnlecsGet_0();
case -1288614193: return bem_buildCreate_0();
case -890072975: return bem_emitLib_0();
case -1251189415: return bem_toString_0();
case -651061238: return bem_inFilePathedGet_0();
case 651546310: return bem_classesInDepthOrderGet_0();
case -341701962: return bem_iteratorGet_0();
case 1409945303: return bem_classEndGet_0();
case 1092011499: return bem_deonGet_0();
case 801704638: return bem_dynMethodsGet_0();
case 1905515480: return bem_shlibeGet_0();
case 1182042355: return bem_spropDecGet_0();
case -741405277: return bem_heopGet_0();
case -1012414135: return bem_lastCallGet_0();
case 1769291946: return bem_objectNpGet_0();
case 170495811: return bem_inClassGet_0();
case -1226127604: return bem_idToNameGet_0();
case -488962284: return bem_nameToIdGet_0();
case -361495888: return bem_invpGet_0();
case -1429562718: return bem_methodCallsGet_0();
case -638075294: return bem_libEmitPathGet_0();
case 1371228147: return bem_msynGet_0();
case -255785093: return bem_preClassOutput_0();
case 2005565409: return bem_saveSyns_0();
case -688306701: return bem_methodBodyGet_0();
case -1841352664: return bem_idToNamePathGet_0();
case 246555205: return bem_beginNs_0();
case 282417426: return bem_buildClassInfo_0();
case -614537705: return bem_heonGet_0();
case 989868268: return bem_onceDecsGet_0();
case -573967702: return bem_headExtGet_0();
case 1734159100: return bem_new_0();
case 1647522167: return bem_classEmitsGet_0();
case 1324410811: return bem_instOfGet_0();
case -1606625180: return bem_mainStartGet_0();
case 1773663882: return bem_classHeadBodyGet_0();
case -1447496341: return bem_typeDecGet_0();
case 2036227171: return bem_ntypesGet_0();
case -62576395: return bem_maxSpillArgsLenGet_0();
case -2035172682: return bem_callNamesGet_0();
case 1993152072: return bem_getClassOutput_0();
case 591844439: return bem_nativeCSlotsGet_0();
case -512633872: return bem_instanceNotEqualGet_0();
case -93985655: return bem_lineCountGet_0();
case -1573248275: return bem_buildInitial_0();
case 1172427555: return bem_writeBET_0();
case -1410283490: return bem_runtimeInitGet_0();
case 1608907891: return bem_transGet_0();
case 1143805973: return bem_classCallsGet_0();
case 763959483: return bem_afterCast_0();
case 2032089000: return bem_lastMethodBodySizeGet_0();
case 1024083692: return bem_mainOutsideNsGet_0();
case 1335762390: return bem_heowGet_0();
case 1061327424: return bem_deopGet_0();
case 376847917: return bem_preClassGet_0();
case -1378154513: return bem_copy_0();
case 1116748653: return bem_fullLibEmitNameGet_0();
case 262046854: return bem_constGet_0();
case 727488022: return bem_nlGet_0();
case 1484794108: return bem_lastMethodsLinesGet_0();
case 1637598756: return bem_classConfGet_0();
case 246999280: return bem_csynGet_0();
case 2066545313: return bem_covariantReturnsGet_0();
case 203063003: return bem_classHeadersGet_0();
case 1743555235: return bem_trueValueGet_0();
case -1019679947: return bem_nullValueGet_0();
case -579745913: return bem_emitLangGet_0();
case 1394706579: return bem_hashGet_0();
case 1965996760: return bem_loadIds_0();
case -104942805: return bem_saveIds_0();
case -997586754: return bem_falseValueGet_0();
case 2114610862: return bem_exceptDecGet_0();
case 1225322446: return bem_belslitsGet_0();
case 1221422031: return bem_mainInClassGet_0();
case 1676954780: return bem_smnlcsGet_0();
case -596336275: return bem_randGet_0();
case -1868791417: return bem_create_0();
case 1270531315: return bem_baseSmtdDecGet_0();
case -1285299552: return bem_buildGet_0();
case -1078613349: return bem_boolTypeGet_0();
case -244630983: return bem_synEmitPathGet_0();
case -943126602: return bem_boolNpGet_0();
case -1881650164: return bem_instanceEqualGet_0();
case -88857688: return bem_buildPropList_0();
case 1073787382: return bem_libEmitNameGet_0();
case -408326528: return bem_baseMtdDecGet_0();
case 1336415159: return bem_methodCatchGet_0();
case -237893947: return bem_nameToIdPathGet_0();
case 329702319: return bem_mnodeGet_0();
case -1853968066: return bem_intNpGet_0();
case -941763616: return bem_returnTypeGet_0();
case -878125624: return bem_superCallsGet_0();
case 1528558850: return bem_propDecGet_0();
case 1548237579: return bem_ccCacheGet_0();
case 1168236049: return bem_methodsGet_0();
case -166177306: return bem_superNameGet_0();
case -2036771304: return bem_doEmit_0();
case 1605334997: return bem_boolCcGet_0();
case 45733581: return bem_overrideMtdDecGet_0();
case -1058314822: return bem_maxDynArgsGet_0();
case -257425544: return bem_useDynMethodsGet_0();
case 281574172: return bem_objectCcGet_0();
case -139910581: return bem_mainEndGet_0();
case 67619757: return bem_getLibOutput_0();
case -1866424860: return bem_cnodeGet_0();
case -414921194: return bem_floatNpGet_0();
case -1683185781: return bem_setOutputTimeGet_0();
case 196413951: return bem_stringNpGet_0();
case 2061659995: return bem_scvpGet_0();
case 557797471: return bem_qGet_0();
case -1814960936: return bem_propertyDecsGet_0();
case 70321383: return bem_parentConfGet_0();
case -1492973205: return bem_print_0();
case 1159508285: return bem_endNs_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1981905333: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 978619689: return bem_libEmitPathSet_1(bevd_0);
case -1756833207: return bem_scvpSet_1(bevd_0);
case 1463439918: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -699121079: return bem_mnodeSet_1(bevd_0);
case 1696437204: return bem_lastCallSet_1(bevd_0);
case -1096307126: return bem_floatNpSet_1(bevd_0);
case 1975532571: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1003243682: return bem_constSet_1(bevd_0);
case 1261117139: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1699624392: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -1346787957: return bem_intNpSet_1(bevd_0);
case 1731488409: return bem_preClassSet_1(bevd_0);
case -179928598: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1396675845: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -506861245: return bem_callNamesSet_1(bevd_0);
case 1302436873: return bem_methodBodySet_1(bevd_0);
case 224732862: return bem_notEquals_1(bevd_0);
case 404631763: return bem_undef_1(bevd_0);
case 1600023186: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1253945682: return bem_begin_1(bevd_0);
case -411927871: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1845052964: return bem_decNameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -786090573: return bem_shlibeSet_1(bevd_0);
case -1132681892: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1432264282: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -588831157: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 719904088: return bem_libEmitNameSet_1(bevd_0);
case -774087692: return bem_methodCatchSet_1(bevd_0);
case -1717111226: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1621579941: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 42000341: return bem_maxDynArgsSet_1(bevd_0);
case 1187781082: return bem_instanceEqualSet_1(bevd_0);
case 1817842930: return bem_deonSet_1(bevd_0);
case 324025998: return bem_gcMarksSet_1(bevd_0);
case -589620627: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -132935417: return bem_end_1(bevd_0);
case -71155228: return bem_returnTypeSet_1(bevd_0);
case -288398778: return bem_methodsSet_1(bevd_0);
case 552683967: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -260919302: return bem_cnodeSet_1(bevd_0);
case 1146894354: return bem_falseValueSet_1(bevd_0);
case -1403715281: return bem_heowSet_1(bevd_0);
case -2068739571: return bem_idToNameSet_1(bevd_0);
case 1408141849: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1696280270: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1169120561: return bem_stringNpSet_1(bevd_0);
case -1504859590: return bem_copyTo_1(bevd_0);
case 1823434263: return bem_parentConfSet_1(bevd_0);
case 445715030: return bem_exceptDecSet_1(bevd_0);
case -1514508347: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1234270163: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 559794907: return bem_nullValueSet_1(bevd_0);
case 430386429: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1918233851: return bem_propertyDecsSet_1(bevd_0);
case -1708716158: return bem_idToNamePathSet_1(bevd_0);
case 593603658: return bem_invpSet_1(bevd_0);
case -217662895: return bem_csynSet_1(bevd_0);
case -684593188: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1612552746: return bem_boolNpSet_1(bevd_0);
case -1540368706: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1871964605: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -620779725: return bem_heopSet_1(bevd_0);
case -41647352: return bem_def_1(bevd_0);
case -1091244413: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case -1331157873: return bem_deopSet_1(bevd_0);
case -1954519951: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 488883159: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1658087404: return bem_fullLibEmitNameSet_1(bevd_0);
case -1968789873: return bem_deowSet_1(bevd_0);
case 130720240: return bem_superCallsSet_1(bevd_0);
case -1465446038: return bem_emitLangSet_1(bevd_0);
case 937004919: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1631269669: return bem_heonSet_1(bevd_0);
case 1641169084: return bem_dynMethodsSet_1(bevd_0);
case -666468412: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1043382319: return bem_objectCcSet_1(bevd_0);
case 577794171: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1877853377: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 79182074: return bem_instOfSet_1(bevd_0);
case -1696719800: return bem_trueValueSet_1(bevd_0);
case -1827509360: return bem_ccCacheSet_1(bevd_0);
case 1334598974: return bem_maxSpillArgsLenSet_1(bevd_0);
case 212925280: return bem_print_1(bevd_0);
case 366577827: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1230189676: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 811109117: return bem_fileExtSet_1(bevd_0);
case -2047638046: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1765867757: return bem_ntypesSet_1(bevd_0);
case -2032111682: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -2004798794: return bem_ccMethodsSet_1(bevd_0);
case -1720921895: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1422373387: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -1157205401: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1073986865: return bem_smnlecsSet_1(bevd_0);
case -1317459657: return bem_lastMethodsSizeSet_1(bevd_0);
case 377923833: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1304158233: return bem_inFilePathedSet_1(bevd_0);
case 1596207863: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -652289078: return bem_inClassSet_1(bevd_0);
case -331570436: return bem_nativeCSlotsSet_1(bevd_0);
case 1870549720: return bem_boolCcSet_1(bevd_0);
case -1721163369: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1306954666: return bem_classHeadBodySet_1(bevd_0);
case -742922089: return bem_classesInDepthOrderSet_1(bevd_0);
case -149311170: return bem_lineCountSet_1(bevd_0);
case 625395063: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 716383035: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 976363111: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1821726923: return bem_instanceNotEqualSet_1(bevd_0);
case -1148925431: return bem_buildSet_1(bevd_0);
case -274268228: return bem_randSet_1(bevd_0);
case -2045857094: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1401059826: return bem_nameToIdPathSet_1(bevd_0);
case -446625061: return bem_classConfSet_1(bevd_0);
case 968740105: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1895483632: return bem_methodCallsSet_1(bevd_0);
case -234768748: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 872336902: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 216626618: return bem_classEmitsSet_1(bevd_0);
case 1635433528: return bem_qSet_1(bevd_0);
case 339430394: return bem_headExtSet_1(bevd_0);
case 1211730305: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 91316219: return bem_lastMethodsLinesSet_1(bevd_0);
case 971941446: return bem_synEmitPathSet_1(bevd_0);
case -1991620791: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 6638885: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 717750370: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 764483733: return bem_equals_1(bevd_0);
case -1261571564: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -358885259: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -868315421: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1643162700: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2072293701: return bem_smnlcsSet_1(bevd_0);
case -900873857: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1702210381: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -125157779: return bem_classCallsSet_1(bevd_0);
case -1310086164: return bem_setOutputTimeSet_1(bevd_0);
case -1512946160: return bem_objectNpSet_1(bevd_0);
case 527125383: return bem_msynSet_1(bevd_0);
case -182773038: return bem_nameToIdSet_1(bevd_0);
case -160511052: return bem_onceDecsSet_1(bevd_0);
case 919112599: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 129839717: return bem_classHeadersSet_1(bevd_0);
case -23786256: return bem_transSet_1(bevd_0);
case 2014793784: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1480954537: return bem_belslitsSet_1(bevd_0);
case 2052974547: return bem_nlSet_1(bevd_0);
case 1198897776: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1536385514: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 2144156567: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1502142684: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1905295327: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1825504548: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -653582648: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 717909815: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -861820000: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1553980312: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -936765995: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1609650525: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -418624509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1423582782: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1278849241: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 403802724: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1528831582: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 988050649: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1191465775: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1358939412: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1491870510: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -453017102: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2132025192: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -277502126: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -436503809: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 493688145: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCCEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
