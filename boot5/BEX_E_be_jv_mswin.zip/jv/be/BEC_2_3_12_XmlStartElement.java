package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_12_XmlStartElement extends BEC_2_3_3_XmlTag {
public BEC_2_3_12_XmlStartElement() { }
private static byte[] becc_BEC_2_3_12_XmlStartElement_clname = {0x58,0x6D,0x6C,0x3A,0x53,0x74,0x61,0x72,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_12_XmlStartElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_1 = {0x20};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_2 = {0x3D};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_3 = {0x2F,0x3E};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_4 = {0x3E};
public static BEC_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_inst;

public static BET_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_6_TextString bevp_attName;
public BEC_2_9_3_ContainerMap bevp_attributes;
public BEC_2_3_12_XmlStartElement bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_addAttributeName_1(BEC_2_4_6_TextString beva_pname) throws Throwable {
bevp_attName = beva_pname;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_addAttributeValue_1(BEC_2_4_6_TextString beva_pval) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_attributes == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 43*/ {
bevp_attributes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 44*/
bevp_attributes.bem_put_2(bevp_attName, beva_pval);
bevp_attName = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_6_6_SystemObject bevl_entry = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_7_TextStrings bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_0));
bevt_1_ta_ph = bevl_accum.bem_addValue_1(bevt_2_ta_ph);
bevt_1_ta_ph.bem_addValue_1(bevp_name);
if (bevp_attributes == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 53*/ {
bevt_4_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_4_ta_ph.bem_quoteGet_0();
bevt_0_ta_loop = bevp_attributes.bem_mapIteratorGet_0();
while (true)
/* Line: 55*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 55*/ {
bevl_entry = bevt_0_ta_loop.bem_nextGet_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_1));
bevt_10_ta_ph = bevl_accum.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevl_entry.bemd_0(-1630383708);
bevt_9_ta_ph = bevt_10_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_2));
bevt_8_ta_ph = bevt_9_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_addValue_1(bevl_q);
bevt_14_ta_ph = bevl_entry.bemd_0(1703402206);
bevt_6_ta_ph = bevt_7_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevl_q);
} /* Line: 56*/
 else /* Line: 55*/ {
break;
} /* Line: 55*/
} /* Line: 55*/
} /* Line: 55*/
if (bevp_isClosed.bevi_bool)/* Line: 59*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_3_12_XmlStartElement_bels_3));
bevl_accum.bem_addValue_1(bevt_15_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_4));
bevl_accum.bem_addValue_1(bevt_16_ta_ph);
} /* Line: 62*/
bevt_17_ta_ph = bevl_accum.bem_extractString_0();
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_attNameGet_0() throws Throwable {
return bevp_attName;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_attributesGet_0() throws Throwable {
return bevp_attributes;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attributesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 43, 43, 44, 46, 47, 51, 52, 52, 52, 53, 53, 54, 54, 55, 0, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 60, 60, 62, 62, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 29, 34, 35, 37, 38, 63, 64, 65, 66, 67, 72, 73, 74, 75, 75, 78, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 98, 99, 102, 103, 105, 106, 109, 112, 116, 119, 123, 126, 130, 133};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 24
assign 1 43 29
undef 1 43 34
assign 1 44 35
new 0 44 35
put 2 46 37
assign 1 47 38
assign 1 51 63
new 0 51 63
assign 1 52 64
new 0 52 64
assign 1 52 65
addValue 1 52 65
addValue 1 52 66
assign 1 53 67
def 1 53 72
assign 1 54 73
new 0 54 73
assign 1 54 74
quoteGet 0 54 74
assign 1 55 75
mapIteratorGet 0 0 75
assign 1 55 78
hasNextGet 0 55 78
assign 1 55 80
nextGet 0 55 80
assign 1 56 81
new 0 56 81
assign 1 56 82
addValue 1 56 82
assign 1 56 83
keyGet 0 56 83
assign 1 56 84
addValue 1 56 84
assign 1 56 85
new 0 56 85
assign 1 56 86
addValue 1 56 86
assign 1 56 87
addValue 1 56 87
assign 1 56 88
valueGet 0 56 88
assign 1 56 89
addValue 1 56 89
addValue 1 56 90
assign 1 60 98
new 0 60 98
addValue 1 60 99
assign 1 62 102
new 0 62 102
addValue 1 62 103
assign 1 64 105
extractString 0 64 105
return 1 64 106
return 1 0 109
assign 1 0 112
return 1 0 116
assign 1 0 119
return 1 0 123
assign 1 0 126
return 1 0 130
assign 1 0 133
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1636456239: return bem_toString_0();
case 380367774: return bem_attributesGet_0();
case 188603276: return bem_hashGet_0();
case -443724522: return bem_new_0();
case 1820870224: return bem_create_0();
case 805105517: return bem_attNameGet_0();
case 1883051716: return bem_iteratorGet_0();
case -112950834: return bem_print_0();
case -1164945535: return bem_copy_0();
case 734887695: return bem_nameGet_0();
case -1946686764: return bem_isClosedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1412041271: return bem_equals_1(bevd_0);
case -1417803331: return bem_def_1(bevd_0);
case 31166843: return bem_attNameSet_1(bevd_0);
case 1176467171: return bem_copyTo_1(bevd_0);
case 548963783: return bem_notEquals_1(bevd_0);
case -891385060: return bem_isClosedSet_1(bevd_0);
case -50710587: return bem_attributesSet_1(bevd_0);
case 1081226855: return bem_undef_1(bevd_0);
case -159847224: return bem_addAttributeValue_1((BEC_2_4_6_TextString) bevd_0);
case 5224370: return bem_nameSet_1(bevd_0);
case -126650047: return bem_addAttributeName_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1430289246: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1422268862: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -545467895: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1368412142: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_3_12_XmlStartElement_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_12_XmlStartElement_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_12_XmlStartElement();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst = (BEC_2_3_12_XmlStartElement) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_type;
}
}
