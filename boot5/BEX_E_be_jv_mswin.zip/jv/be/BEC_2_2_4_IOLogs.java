package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_4_IOLogs extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOLogs() { }
private static byte[] becc_BEC_2_2_4_IOLogs_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67,0x73};
private static byte[] becc_BEC_2_2_4_IOLogs_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
public static BEC_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_inst;

public static BET_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_type;

public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_9_3_ContainerSet bevp_overrides;
public BEC_2_9_3_ContainerMap bevp_loggers;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_4_3_MathInt bevp_defaultOutputLevel;
public BEC_2_4_3_MathInt bevp_defaultLevel;
public BEC_2_2_4_IOLogs bem_default_0() throws Throwable {
bevp_debug = (new BEC_2_4_3_MathInt(400));
bevp_info = (new BEC_2_4_3_MathInt(300));
bevp_warn = (new BEC_2_4_3_MathInt(200));
bevp_error = (new BEC_2_4_3_MathInt(100));
bevp_fatal = (new BEC_2_4_3_MathInt(0));
bevp_overrides = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_loggers = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_defaultOutputLevel = bevp_error;
bevp_defaultLevel = bevp_info;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_setDefaultLevels_2(BEC_2_4_3_MathInt beva__defaultOutputLevel, BEC_2_4_3_MathInt beva__defaultLevel) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
try  /* Line: 33 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = beva__defaultOutputLevel;
bevp_defaultLevel = beva__defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 37 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_kv.bemd_0(-1156474324);
bevt_2_tmpany_phold = bevp_overrides.bem_has_1(bevt_3_tmpany_phold);
if (!(bevt_2_tmpany_phold.bevi_bool)) /* Line: 38 */ {
bevt_4_tmpany_phold = bevl_kv.bemd_0(-2000049957);
bevt_4_tmpany_phold.bemd_2(-1247543583, bevp_defaultOutputLevel, bevp_defaultLevel);
} /* Line: 39 */
} /* Line: 38 */
 else  /* Line: 37 */ {
break;
} /* Line: 37 */
} /* Line: 37 */
bevp_lock.bem_unlock_0();
} /* Line: 42 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 44 */
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putKeyLevels_3(BEC_2_4_6_TextString beva_key, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 49 */ {
bevp_lock.bem_lock_0();
bevp_overrides.bem_put_1(beva_key);
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_2(beva_level, beva_outputLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_log.bem_levelSet_1(beva_level);
bevl_log.bem_outputLevelSet_1(beva_outputLevel);
} /* Line: 62 */
bevp_lock.bem_unlock_0();
} /* Line: 64 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 66 */
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putLevels_3(BEC_2_6_6_SystemObject beva_inst, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_inst.bemd_0(-464967776);
bem_putKeyLevels_3((BEC_2_4_6_TextString) bevt_0_tmpany_phold , beva_level, beva_outputLevel);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_getKey_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 77 */ {
bevp_lock.bem_lock_0();
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_2(bevp_defaultOutputLevel, bevp_defaultLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 82 */
bevp_lock.bem_unlock_0();
} /* Line: 84 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 86 */
return bevl_log;
} /*method end*/
public BEC_2_2_3_IOLog bem_get_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_inst.bemd_0(-464967776);
bevt_0_tmpany_phold = bem_getKey_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOn_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
try  /* Line: 96 */ {
bevp_lock.bem_lock_0();
bevl_log = bem_get_1(beva_inst);
bevt_0_tmpany_phold = bevl_log.bem_levelGet_0();
bevt_1_tmpany_phold = bevl_log.bem_levelGet_0();
bem_putLevels_3(beva_inst, bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevp_lock.bem_unlock_0();
} /* Line: 102 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 104 */
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOnAll_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
try  /* Line: 109 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = bevp_defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 113 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_kv.bemd_0(-2000049957);
bevt_2_tmpany_phold.bemd_1(-1859026703, bevp_defaultOutputLevel);
bevt_3_tmpany_phold = bevl_kv.bemd_0(-2000049957);
bevt_3_tmpany_phold.bemd_1(156514599, bevp_defaultLevel);
} /* Line: 115 */
 else  /* Line: 113 */ {
break;
} /* Line: 113 */
} /* Line: 113 */
bevp_lock.bem_unlock_0();
} /* Line: 118 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 120 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public final BEC_2_4_3_MathInt bem_debugGetDirect_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_2_4_IOLogs bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_debugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_infoGet_0() throws Throwable {
return bevp_info;
} /*method end*/
public final BEC_2_4_3_MathInt bem_infoGetDirect_0() throws Throwable {
return bevp_info;
} /*method end*/
public BEC_2_2_4_IOLogs bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_infoSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_warnGet_0() throws Throwable {
return bevp_warn;
} /*method end*/
public final BEC_2_4_3_MathInt bem_warnGetDirect_0() throws Throwable {
return bevp_warn;
} /*method end*/
public BEC_2_2_4_IOLogs bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_warnSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public final BEC_2_4_3_MathInt bem_errorGetDirect_0() throws Throwable {
return bevp_error;
} /*method end*/
public BEC_2_2_4_IOLogs bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_errorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_fatalGet_0() throws Throwable {
return bevp_fatal;
} /*method end*/
public final BEC_2_4_3_MathInt bem_fatalGetDirect_0() throws Throwable {
return bevp_fatal;
} /*method end*/
public BEC_2_2_4_IOLogs bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_fatalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_overridesGet_0() throws Throwable {
return bevp_overrides;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_overridesGetDirect_0() throws Throwable {
return bevp_overrides;
} /*method end*/
public BEC_2_2_4_IOLogs bem_overridesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_overridesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_loggersGet_0() throws Throwable {
return bevp_loggers;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_loggersGetDirect_0() throws Throwable {
return bevp_loggers;
} /*method end*/
public BEC_2_2_4_IOLogs bem_loggersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_loggersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_2_2_4_IOLogs bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultOutputLevelGet_0() throws Throwable {
return bevp_defaultOutputLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_defaultOutputLevelGetDirect_0() throws Throwable {
return bevp_defaultOutputLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultOutputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_defaultOutputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultLevelGet_0() throws Throwable {
return bevp_defaultLevel;
} /*method end*/
public final BEC_2_4_3_MathInt bem_defaultLevelGetDirect_0() throws Throwable {
return bevp_defaultLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_2_4_IOLogs bem_defaultLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 20, 21, 22, 23, 24, 26, 27, 34, 35, 36, 37, 0, 37, 37, 38, 38, 39, 39, 42, 44, 50, 51, 56, 57, 57, 58, 59, 61, 62, 64, 66, 72, 72, 78, 79, 80, 80, 81, 82, 84, 86, 88, 92, 92, 92, 97, 99, 100, 100, 100, 102, 104, 110, 112, 113, 0, 113, 113, 114, 114, 115, 115, 118, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 43, 44, 45, 46, 46, 49, 51, 52, 53, 55, 56, 63, 67, 76, 77, 78, 79, 84, 85, 86, 89, 90, 92, 96, 102, 103, 111, 112, 113, 118, 119, 120, 122, 126, 128, 133, 134, 135, 143, 144, 145, 146, 147, 148, 152, 164, 165, 166, 166, 169, 171, 172, 173, 174, 175, 181, 185, 190, 193, 196, 200, 204, 207, 210, 214, 218, 221, 224, 228, 232, 235, 238, 242, 246, 249, 252, 256, 260, 263, 266, 270, 274, 277, 280, 284, 288, 291, 294, 298, 302, 305, 308, 312, 316, 319, 322, 326};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 22
new 0 17 22
assign 1 18 23
new 0 18 23
assign 1 19 24
new 0 19 24
assign 1 20 25
new 0 20 25
assign 1 21 26
new 0 21 26
assign 1 22 27
new 0 22 27
assign 1 23 28
new 0 23 28
assign 1 24 29
new 0 24 29
assign 1 26 30
assign 1 27 31
lock 0 34 43
assign 1 35 44
assign 1 36 45
assign 1 37 46
mapIteratorGet 0 0 46
assign 1 37 49
hasNextGet 0 37 49
assign 1 37 51
nextGet 0 37 51
assign 1 38 52
keyGet 0 38 52
assign 1 38 53
has 1 38 53
assign 1 39 55
valueGet 0 39 55
setLevels 2 39 56
unlock 0 42 63
unlock 0 44 67
lock 0 50 76
put 1 51 77
assign 1 56 78
get 1 56 78
assign 1 57 79
undef 1 57 84
assign 1 58 85
new 2 58 85
put 2 59 86
levelSet 1 61 89
outputLevelSet 1 62 90
unlock 0 64 92
unlock 0 66 96
assign 1 72 102
classNameGet 0 72 102
putKeyLevels 3 72 103
lock 0 78 111
assign 1 79 112
get 1 79 112
assign 1 80 113
undef 1 80 118
assign 1 81 119
new 2 81 119
put 2 82 120
unlock 0 84 122
unlock 0 86 126
return 1 88 128
assign 1 92 133
classNameGet 0 92 133
assign 1 92 134
getKey 1 92 134
return 1 92 135
lock 0 97 143
assign 1 99 144
get 1 99 144
assign 1 100 145
levelGet 0 100 145
assign 1 100 146
levelGet 0 100 146
putLevels 3 100 147
unlock 0 102 148
unlock 0 104 152
lock 0 110 164
assign 1 112 165
assign 1 113 166
mapIteratorGet 0 0 166
assign 1 113 169
hasNextGet 0 113 169
assign 1 113 171
nextGet 0 113 171
assign 1 114 172
valueGet 0 114 172
outputLevelSet 1 114 173
assign 1 115 174
valueGet 0 115 174
levelSet 1 115 175
unlock 0 118 181
unlock 0 120 185
return 1 0 190
return 1 0 193
assign 1 0 196
assign 1 0 200
return 1 0 204
return 1 0 207
assign 1 0 210
assign 1 0 214
return 1 0 218
return 1 0 221
assign 1 0 224
assign 1 0 228
return 1 0 232
return 1 0 235
assign 1 0 238
assign 1 0 242
return 1 0 246
return 1 0 249
assign 1 0 252
assign 1 0 256
return 1 0 260
return 1 0 263
assign 1 0 266
assign 1 0 270
return 1 0 274
return 1 0 277
assign 1 0 280
assign 1 0 284
return 1 0 288
return 1 0 291
assign 1 0 294
assign 1 0 298
return 1 0 302
return 1 0 305
assign 1 0 308
assign 1 0 312
return 1 0 316
return 1 0 319
assign 1 0 322
assign 1 0 326
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1493395107: return bem_loggersGet_0();
case -919772434: return bem_serializeToString_0();
case 1928293906: return bem_once_0();
case 619304343: return bem_hashGet_0();
case 1623987490: return bem_serializeContents_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case -657863794: return bem_debugGet_0();
case 515011248: return bem_debugGetDirect_0();
case -1683424624: return bem_overridesGetDirect_0();
case 868760417: return bem_serializationIteratorGet_0();
case -2098643899: return bem_warnGetDirect_0();
case -1836757512: return bem_copy_0();
case 1452564531: return bem_toString_0();
case -757699318: return bem_iteratorGet_0();
case -977356120: return bem_fieldNamesGet_0();
case 104803017: return bem_defaultOutputLevelGet_0();
case 1605752359: return bem_many_0();
case 438244040: return bem_create_0();
case 1576417178: return bem_new_0();
case -1833832635: return bem_lockGet_0();
case -197180620: return bem_echo_0();
case 1148186102: return bem_toAny_0();
case 1245222883: return bem_loggersGetDirect_0();
case 109075966: return bem_turnOnAll_0();
case 141983605: return bem_sourceFileNameGet_0();
case -464967776: return bem_classNameGet_0();
case 999325767: return bem_warnGet_0();
case -1392560126: return bem_default_0();
case 360229920: return bem_overridesGet_0();
case -657577719: return bem_defaultLevelGetDirect_0();
case -1772395224: return bem_lockGetDirect_0();
case -2010136346: return bem_fatalGetDirect_0();
case 500389220: return bem_print_0();
case -345333998: return bem_defaultOutputLevelGetDirect_0();
case -1025191431: return bem_fatalGet_0();
case -1316711526: return bem_infoGetDirect_0();
case -1310458946: return bem_errorGet_0();
case -2060092547: return bem_infoGet_0();
case -978724962: return bem_tagGet_0();
case -1216603195: return bem_errorGetDirect_0();
case -2056835921: return bem_defaultLevelGet_0();
case -1895797969: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2080355933: return bem_defined_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case -1438983644: return bem_debugSetDirect_1(bevd_0);
case -608626772: return bem_defaultLevelSetDirect_1(bevd_0);
case 1536684593: return bem_defaultOutputLevelSet_1(bevd_0);
case -339638984: return bem_fatalSet_1(bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1362971262: return bem_get_1(bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case 931098625: return bem_infoSetDirect_1(bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case 506738294: return bem_warnSet_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case 371729912: return bem_loggersSet_1(bevd_0);
case 836363187: return bem_defaultOutputLevelSetDirect_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case -1464258870: return bem_lockSetDirect_1(bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case 1934535900: return bem_turnOn_1(bevd_0);
case -1108234145: return bem_lockSet_1(bevd_0);
case -69641605: return bem_debugSet_1(bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case 1525331364: return bem_errorSet_1(bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1048339253: return bem_warnSetDirect_1(bevd_0);
case 103606250: return bem_loggersSetDirect_1(bevd_0);
case -863620511: return bem_getKey_1((BEC_2_4_6_TextString) bevd_0);
case 611890773: return bem_defaultLevelSet_1(bevd_0);
case 1504498980: return bem_overridesSet_1(bevd_0);
case -1733544515: return bem_overridesSetDirect_1(bevd_0);
case 1466122374: return bem_infoSet_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1603583502: return bem_fatalSetDirect_1(bevd_0);
case 1831431269: return bem_errorSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2059683396: return bem_setDefaultLevels_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1900658565: return bem_putLevels_3(bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1042074382: return bem_putKeyLevels_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOLogs_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_4_IOLogs_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOLogs();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst = (BEC_2_2_4_IOLogs) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_type;
}
}
