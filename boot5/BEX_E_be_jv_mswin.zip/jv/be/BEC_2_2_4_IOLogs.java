package be;
/* IO:File: source/extended/Log.be */
public class BEC_2_2_4_IOLogs extends BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOLogs() { }
private static byte[] becc_BEC_2_2_4_IOLogs_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67,0x73};
private static byte[] becc_BEC_2_2_4_IOLogs_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
public static BEC_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_inst;
public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_9_3_ContainerSet bevp_overrides;
public BEC_2_9_3_ContainerMap bevp_loggers;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_4_3_MathInt bevp_defaultOutputLevel;
public BEC_2_4_3_MathInt bevp_defaultLevel;
public BEC_2_2_4_IOLogs bem_default_0() throws Throwable {
bevp_debug = (new BEC_2_4_3_MathInt(400));
bevp_info = (new BEC_2_4_3_MathInt(300));
bevp_warn = (new BEC_2_4_3_MathInt(200));
bevp_error = (new BEC_2_4_3_MathInt(100));
bevp_fatal = (new BEC_2_4_3_MathInt(0));
bevp_overrides = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_loggers = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_defaultOutputLevel = bevp_error;
bevp_defaultLevel = bevp_info;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_setDefaultLevels_2(BEC_2_4_3_MathInt beva__defaultOutputLevel, BEC_2_4_3_MathInt beva__defaultLevel) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
try  /* Line: 33 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = beva__defaultOutputLevel;
bevp_defaultLevel = beva__defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 37 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_kv.bemd_0(-158405299);
bevt_2_tmpany_phold = bevp_overrides.bem_has_1(bevt_3_tmpany_phold);
if (!(bevt_2_tmpany_phold.bevi_bool)) /* Line: 38 */ {
bevt_4_tmpany_phold = bevl_kv.bemd_0(404129680);
bevt_4_tmpany_phold.bemd_2(1588651315, bevp_defaultOutputLevel, bevp_defaultLevel);
} /* Line: 39 */
} /* Line: 38 */
 else  /* Line: 37 */ {
break;
} /* Line: 37 */
} /* Line: 37 */
bevp_lock.bem_unlock_0();
} /* Line: 42 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 44 */
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putKeyLevels_3(BEC_2_4_6_TextString beva_key, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 49 */ {
bevp_lock.bem_lock_0();
bevp_overrides.bem_put_1(beva_key);
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_2(beva_level, beva_outputLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_log.bem_levelSet_1(beva_level);
bevl_log.bem_outputLevelSet_1(beva_outputLevel);
} /* Line: 62 */
bevp_lock.bem_unlock_0();
} /* Line: 64 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 66 */
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_putLevels_3(BEC_2_6_6_SystemObject beva_inst, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_inst.bemd_0(-7634332);
bem_putKeyLevels_3((BEC_2_4_6_TextString) bevt_0_tmpany_phold , beva_level, beva_outputLevel);
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_getKey_1(BEC_2_4_6_TextString beva_key) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 77 */ {
bevp_lock.bem_lock_0();
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevl_log = (new BEC_2_2_3_IOLog()).bem_new_2(bevp_defaultOutputLevel, bevp_defaultLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 82 */
bevp_lock.bem_unlock_0();
} /* Line: 84 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 86 */
return bevl_log;
} /*method end*/
public BEC_2_2_3_IOLog bem_get_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_inst.bemd_0(-7634332);
bevt_0_tmpany_phold = bem_getKey_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOn_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
try  /* Line: 96 */ {
bevp_lock.bem_lock_0();
bevl_log = bem_get_1(beva_inst);
bevt_0_tmpany_phold = bevl_log.bem_levelGet_0();
bevt_1_tmpany_phold = bevl_log.bem_levelGet_0();
bem_putLevels_3(beva_inst, bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevp_lock.bem_unlock_0();
} /* Line: 102 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 104 */
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_turnOnAll_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
try  /* Line: 109 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = bevp_defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 113 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_kv.bemd_0(404129680);
bevt_2_tmpany_phold.bemd_1(-688113429, bevp_defaultOutputLevel);
bevt_3_tmpany_phold = bevl_kv.bemd_0(404129680);
bevt_3_tmpany_phold.bemd_1(2094803196, bevp_defaultLevel);
} /* Line: 115 */
 else  /* Line: 113 */ {
break;
} /* Line: 113 */
} /* Line: 113 */
bevp_lock.bem_unlock_0();
} /* Line: 118 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 120 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_debugGet_0() throws Throwable {
return bevp_debug;
} /*method end*/
public BEC_2_2_4_IOLogs bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_infoGet_0() throws Throwable {
return bevp_info;
} /*method end*/
public BEC_2_2_4_IOLogs bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_warnGet_0() throws Throwable {
return bevp_warn;
} /*method end*/
public BEC_2_2_4_IOLogs bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_errorGet_0() throws Throwable {
return bevp_error;
} /*method end*/
public BEC_2_2_4_IOLogs bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_fatalGet_0() throws Throwable {
return bevp_fatal;
} /*method end*/
public BEC_2_2_4_IOLogs bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_overridesGet_0() throws Throwable {
return bevp_overrides;
} /*method end*/
public BEC_2_2_4_IOLogs bem_overridesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_loggersGet_0() throws Throwable {
return bevp_loggers;
} /*method end*/
public BEC_2_2_4_IOLogs bem_loggersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_2_2_4_IOLogs bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultOutputLevelGet_0() throws Throwable {
return bevp_defaultOutputLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultOutputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultLevelGet_0() throws Throwable {
return bevp_defaultLevel;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 20, 21, 22, 23, 24, 26, 27, 34, 35, 36, 37, 0, 37, 37, 38, 38, 39, 39, 42, 44, 50, 51, 56, 57, 57, 58, 59, 61, 62, 64, 66, 72, 72, 78, 79, 80, 80, 81, 82, 84, 86, 88, 92, 92, 92, 97, 99, 100, 100, 100, 102, 104, 110, 112, 113, 0, 113, 113, 114, 114, 115, 115, 118, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 40, 41, 42, 43, 43, 46, 48, 49, 50, 52, 53, 60, 64, 73, 74, 75, 76, 81, 82, 83, 86, 87, 89, 93, 99, 100, 108, 109, 110, 115, 116, 117, 119, 123, 125, 130, 131, 132, 140, 141, 142, 143, 144, 145, 149, 161, 162, 163, 163, 166, 168, 169, 170, 171, 172, 178, 182, 187, 190, 194, 197, 201, 204, 208, 211, 215, 218, 222, 225, 229, 232, 236, 239, 243, 246, 250, 253};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 19
new 0 17 19
assign 1 18 20
new 0 18 20
assign 1 19 21
new 0 19 21
assign 1 20 22
new 0 20 22
assign 1 21 23
new 0 21 23
assign 1 22 24
new 0 22 24
assign 1 23 25
new 0 23 25
assign 1 24 26
new 0 24 26
assign 1 26 27
assign 1 27 28
lock 0 34 40
assign 1 35 41
assign 1 36 42
assign 1 37 43
mapIteratorGet 0 0 43
assign 1 37 46
hasNextGet 0 37 46
assign 1 37 48
nextGet 0 37 48
assign 1 38 49
keyGet 0 38 49
assign 1 38 50
has 1 38 50
assign 1 39 52
valueGet 0 39 52
setLevels 2 39 53
unlock 0 42 60
unlock 0 44 64
lock 0 50 73
put 1 51 74
assign 1 56 75
get 1 56 75
assign 1 57 76
undef 1 57 81
assign 1 58 82
new 2 58 82
put 2 59 83
levelSet 1 61 86
outputLevelSet 1 62 87
unlock 0 64 89
unlock 0 66 93
assign 1 72 99
classNameGet 0 72 99
putKeyLevels 3 72 100
lock 0 78 108
assign 1 79 109
get 1 79 109
assign 1 80 110
undef 1 80 115
assign 1 81 116
new 2 81 116
put 2 82 117
unlock 0 84 119
unlock 0 86 123
return 1 88 125
assign 1 92 130
classNameGet 0 92 130
assign 1 92 131
getKey 1 92 131
return 1 92 132
lock 0 97 140
assign 1 99 141
get 1 99 141
assign 1 100 142
levelGet 0 100 142
assign 1 100 143
levelGet 0 100 143
putLevels 3 100 144
unlock 0 102 145
unlock 0 104 149
lock 0 110 161
assign 1 112 162
assign 1 113 163
mapIteratorGet 0 0 163
assign 1 113 166
hasNextGet 0 113 166
assign 1 113 168
nextGet 0 113 168
assign 1 114 169
valueGet 0 114 169
outputLevelSet 1 114 170
assign 1 115 171
valueGet 0 115 171
levelSet 1 115 172
unlock 0 118 178
unlock 0 120 182
return 1 0 187
assign 1 0 190
return 1 0 194
assign 1 0 197
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
return 1 0 215
assign 1 0 218
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
return 1 0 243
assign 1 0 246
return 1 0 250
assign 1 0 253
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -149632320: return bem_toAny_0();
case -1671448721: return bem_defaultOutputLevelGet_0();
case -530273479: return bem_turnOnAll_0();
case -93701646: return bem_fieldIteratorGet_0();
case -748319096: return bem_print_0();
case -29400896: return bem_create_0();
case -1353281478: return bem_overridesGet_0();
case -1052800757: return bem_echo_0();
case -801589503: return bem_tagGet_0();
case -794227383: return bem_copy_0();
case -1196398392: return bem_debugGet_0();
case 427829962: return bem_fatalGet_0();
case 1114713212: return bem_lockGet_0();
case 861710738: return bem_many_0();
case -7634332: return bem_classNameGet_0();
case 900978335: return bem_serializeToString_0();
case 313469553: return bem_default_0();
case -126081578: return bem_warnGet_0();
case 1338975369: return bem_sourceFileNameGet_0();
case -14402816: return bem_serializeContents_0();
case -1674098047: return bem_once_0();
case 347663588: return bem_loggersGet_0();
case -1701242685: return bem_serializationIteratorGet_0();
case 1252968942: return bem_errorGet_0();
case -258597009: return bem_hashGet_0();
case -51803385: return bem_toString_0();
case -124916815: return bem_new_0();
case 435112145: return bem_defaultLevelGet_0();
case -1749103224: return bem_iteratorGet_0();
case -467186719: return bem_deserializeClassNameGet_0();
case -1458642345: return bem_infoGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 789053380: return bem_errorSet_1(bevd_0);
case 1518481031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -983540661: return bem_undefined_1(bevd_0);
case -73997568: return bem_equals_1(bevd_0);
case -105367385: return bem_overridesSet_1(bevd_0);
case -1396560732: return bem_get_1(bevd_0);
case -587977955: return bem_defaultLevelSet_1(bevd_0);
case -1273059988: return bem_getKey_1((BEC_2_4_6_TextString) bevd_0);
case -1913995542: return bem_debugSet_1(bevd_0);
case 1970850163: return bem_sameType_1(bevd_0);
case -96689966: return bem_infoSet_1(bevd_0);
case 616348580: return bem_undef_1(bevd_0);
case -271716565: return bem_copyTo_1(bevd_0);
case -2092712540: return bem_def_1(bevd_0);
case -1820492018: return bem_lockSet_1(bevd_0);
case 642489795: return bem_otherType_1(bevd_0);
case -93273669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 550176080: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 70869241: return bem_loggersSet_1(bevd_0);
case -20159434: return bem_sameClass_1(bevd_0);
case 729197176: return bem_turnOn_1(bevd_0);
case -218714893: return bem_otherClass_1(bevd_0);
case -1391202250: return bem_defined_1(bevd_0);
case 506876533: return bem_defaultOutputLevelSet_1(bevd_0);
case 2036979549: return bem_notEquals_1(bevd_0);
case 1118013404: return bem_fatalSet_1(bevd_0);
case -1474467614: return bem_sameObject_1(bevd_0);
case 226940097: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2015668497: return bem_warnSet_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 2093180987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 292502272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -559676920: return bem_setDefaultLevels_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -66460559: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1031466779: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2131321099: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1367679335: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -323049121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callCase) {
case 498616047: return bem_putLevels_3(bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1283575036: return bem_putKeyLevels_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callCase, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOLogs_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_4_IOLogs_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_4_IOLogs();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst = (BEC_2_2_4_IOLogs) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst;
}
}
