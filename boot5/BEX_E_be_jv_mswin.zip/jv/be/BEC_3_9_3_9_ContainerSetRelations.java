package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_9_ContainerSetRelations extends BEC_2_6_6_SystemObject {
public BEC_3_9_3_9_ContainerSetRelations() { }
private static byte[] becc_BEC_3_9_3_9_ContainerSetRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_9_ContainerSetRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_9_ContainerSetRelations bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;

public static BET_3_9_3_9_ContainerSetRelations bece_BEC_3_9_3_9_ContainerSetRelations_bevs_type;

public BEC_3_9_3_9_ContainerSetRelations bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_0(-1515347213);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_1(-2120701530, beva_l);
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {68, 68, 72, 72};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 68 19
hashGet 0 68 19
return 1 68 20
assign 1 72 24
equals 1 72 24
return 1 72 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1515347213: return bem_hashGet_0();
case 507602572: return bem_once_0();
case 631342118: return bem_deserializeClassNameGet_0();
case -862155694: return bem_copy_0();
case -1370019545: return bem_serializeToString_0();
case -583954274: return bem_default_0();
case -647428547: return bem_fieldIteratorGet_0();
case 1379664484: return bem_toAny_0();
case -688295882: return bem_tagGet_0();
case -1814630541: return bem_classNameGet_0();
case 562477328: return bem_serializationIteratorGet_0();
case 886168102: return bem_many_0();
case 899271096: return bem_new_0();
case -542639344: return bem_toString_0();
case 1884909798: return bem_create_0();
case -1906660880: return bem_print_0();
case -973290132: return bem_iteratorGet_0();
case 1688744619: return bem_serializeContents_0();
case -1067099981: return bem_fieldNamesGet_0();
case -21012660: return bem_sourceFileNameGet_0();
case -1648627766: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2120701530: return bem_equals_1(bevd_0);
case -241199401: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1715866358: return bem_notEquals_1(bevd_0);
case -345992202: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 216018244: return bem_copyTo_1(bevd_0);
case 1183248968: return bem_getHash_1(bevd_0);
case -734789597: return bem_undefined_1(bevd_0);
case 1116925492: return bem_sameType_1(bevd_0);
case 1280914604: return bem_otherClass_1(bevd_0);
case 1744917313: return bem_defined_1(bevd_0);
case 1142143738: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 898034411: return bem_sameClass_1(bevd_0);
case 2001300007: return bem_sameObject_1(bevd_0);
case -914794223: return bem_undef_1(bevd_0);
case 1402754792: return bem_def_1(bevd_0);
case 1820085236: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1349849963: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -603725496: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1784313817: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1506940745: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1630879145: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2028721987: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1923163327: return bem_isEqual_2(bevd_0, bevd_1);
case 1485133109: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2011759429: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_3_9_ContainerSetRelations_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_9_ContainerSetRelations_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_9_ContainerSetRelations();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst = (BEC_3_9_3_9_ContainerSetRelations) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_type;
}
}
