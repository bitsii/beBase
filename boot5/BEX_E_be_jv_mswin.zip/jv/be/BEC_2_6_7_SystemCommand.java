package be;
/* IO:File: source/extended/Command.be */
public final class BEC_2_6_7_SystemCommand extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
public static BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;
public BEC_2_4_6_TextString bevp_command;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) throws Throwable {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;

      bevi_p = Runtime.getRuntime().exec(bevp_command.bems_toJvString());
      return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() throws Throwable {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 93 */ {
return bevp_outputReader;
} /* Line: 94 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.getInputStream();
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 114 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() throws Throwable {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 43, 44, 44, 82, 86, 93, 93, 94, 96, 107, 108, 112, 112, 113, 114, 119, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 18, 19, 20, 34, 37, 42, 47, 48, 50, 53, 54, 58, 63, 64, 65, 70, 76, 79, 83, 86};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 13
new 1 43 18
assign 1 44 19
run 0 44 19
return 1 44 20
return 1 82 34
run 0 86 37
assign 1 93 42
def 1 93 47
return 1 94 48
assign 1 96 50
new 0 96 50
extOpen 0 107 53
return 1 108 54
assign 1 112 58
def 1 112 63
close 0 113 64
assign 1 114 65
closeOutput 0 119 70
return 1 0 76
assign 1 0 79
return 1 0 83
assign 1 0 86
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 386788561: return bem_new_0();
case -935771084: return bem_sourceFileNameGet_0();
case -261636586: return bem_classNameGet_0();
case -1620819332: return bem_once_0();
case -745372360: return bem_run_0();
case 1637405965: return bem_toString_0();
case -1975952737: return bem_tagGet_0();
case -1197182710: return bem_serializeToString_0();
case -845934681: return bem_outputReaderGet_0();
case 582818432: return bem_create_0();
case 1342246094: return bem_print_0();
case 168705805: return bem_iteratorGet_0();
case -117420215: return bem_serializeContents_0();
case 1638167394: return bem_open_0();
case 65678538: return bem_echo_0();
case -292869221: return bem_commandGet_0();
case 866679447: return bem_serializationIteratorGet_0();
case 1053098123: return bem_hashGet_0();
case 2092326455: return bem_many_0();
case 211356755: return bem_closeOutput_0();
case 1449516553: return bem_copy_0();
case 845917022: return bem_fieldIteratorGet_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -1712633963: return bem_toAny_0();
case -1998749864: return bem_outputGet_0();
case 838087558: return bem_close_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1921133350: return bem_defined_1(bevd_0);
case 707881002: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case 141639857: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case -191471764: return bem_commandSet_1(bevd_0);
case -1316732066: return bem_outputReaderSet_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
}
