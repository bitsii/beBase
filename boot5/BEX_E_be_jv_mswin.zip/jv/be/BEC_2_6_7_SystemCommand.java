package be;
/* IO:File: source/extended/Command.be */
public final class BEC_2_6_7_SystemCommand extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
public static BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) throws Throwable {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;

      bevi_p = Runtime.getRuntime().exec(bevp_command.bems_toJvString());
      return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() throws Throwable {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 93 */ {
return bevp_outputReader;
} /* Line: 94 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.getInputStream();
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 114 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() throws Throwable {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() throws Throwable {
return bevp_command;
} /*method end*/
public final BEC_2_4_6_TextString bem_commandGetDirect_0() throws Throwable {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public final BEC_3_2_4_6_IOFileReader bem_outputReaderGetDirect_0() throws Throwable {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_7_SystemCommand bem_outputReaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {38, 43, 44, 44, 82, 86, 93, 93, 94, 96, 107, 108, 112, 112, 113, 114, 119, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 21, 22, 23, 37, 40, 45, 50, 51, 53, 56, 57, 61, 66, 67, 68, 73, 79, 82, 85, 89, 93, 96, 99, 103};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 38 16
new 1 43 21
assign 1 44 22
run 0 44 22
return 1 44 23
return 1 82 37
run 0 86 40
assign 1 93 45
def 1 93 50
return 1 94 51
assign 1 96 53
new 0 96 53
extOpen 0 107 56
return 1 108 57
assign 1 112 61
def 1 112 66
close 0 113 67
assign 1 114 68
closeOutput 0 119 73
return 1 0 79
return 1 0 82
assign 1 0 85
assign 1 0 89
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -2063692354: return bem_toAny_0();
case 1638354094: return bem_run_0();
case -1001035230: return bem_closeOutput_0();
case 1154111609: return bem_serializeToString_0();
case -867540373: return bem_sourceFileNameGet_0();
case -1206807373: return bem_echo_0();
case 845843737: return bem_copy_0();
case 936108049: return bem_fieldNamesGet_0();
case -45870993: return bem_hashGet_0();
case -2060052900: return bem_classNameGet_0();
case 1639062936: return bem_create_0();
case 1173227505: return bem_once_0();
case -1021119130: return bem_close_0();
case -653615460: return bem_fieldIteratorGet_0();
case -1905553041: return bem_outputReaderGetDirect_0();
case 376367511: return bem_toString_0();
case 1089524457: return bem_open_0();
case -1981751368: return bem_commandGetDirect_0();
case 1042227348: return bem_print_0();
case 695019909: return bem_new_0();
case 702386781: return bem_serializationIteratorGet_0();
case -1788326649: return bem_iteratorGet_0();
case -325735562: return bem_commandGet_0();
case 1006581994: return bem_outputReaderGet_0();
case -2131583456: return bem_outputGet_0();
case 542454679: return bem_tagGet_0();
case -835256918: return bem_deserializeClassNameGet_0();
case 584319597: return bem_serializeContents_0();
case 434703584: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1253472481: return bem_copyTo_1(bevd_0);
case 699166467: return bem_sameClass_1(bevd_0);
case -1438256358: return bem_otherType_1(bevd_0);
case -1549754120: return bem_commandSet_1(bevd_0);
case -1253948557: return bem_otherClass_1(bevd_0);
case 585390927: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -671092537: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -886160285: return bem_notEquals_1(bevd_0);
case 1689281313: return bem_defined_1(bevd_0);
case -670346435: return bem_sameObject_1(bevd_0);
case -1490110704: return bem_outputReaderSetDirect_1(bevd_0);
case 380820433: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 301362299: return bem_undef_1(bevd_0);
case -2031145791: return bem_def_1(bevd_0);
case 1471682945: return bem_commandSetDirect_1(bevd_0);
case 471926371: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2039403626: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -2130755695: return bem_equals_1(bevd_0);
case -1569160884: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1738623736: return bem_sameType_1(bevd_0);
case -2051650170: return bem_outputReaderSet_1(bevd_0);
case 604219486: return bem_undefined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1353806938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1092172708: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1390495691: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1588508948: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 167635781: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1229766114: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 39825618: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemCommand();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
