package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_4_4_TextGlob extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
public static BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;

public static BET_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_type;

public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tok = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_ph.bemd_0(106295944);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bem_caseMatch_4(bevl_node, beva_input, bevt_2_ta_ph, null);
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) throws Throwable {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
if (beva_node == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1051*/ {
bevt_2_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1052*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1053*/
 else /* Line: 1054*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 1055*/
} /* Line: 1052*/
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_4_TextGlob_bels_1));
bevt_5_ta_ph = bevl_val.bem_equals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1059*/ {
bevt_7_ta_ph = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_ta_ph;
} /* Line: 1060*/
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_4_TextGlob_bels_2));
bevt_8_ta_ph = bevl_val.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 1062*/ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1064*/ {
bevt_13_ta_ph = beva_node.bem_nextGet_0();
bevt_12_ta_ph = bem_caseMatch_4(bevt_13_ta_ph, beva_input, beva_pos, null);
return bevt_12_ta_ph;
} /* Line: 1064*/
 else /* Line: 1064*/ {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_14_ta_ph;
} /* Line: 1064*/
} /* Line: 1064*/
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1067*/ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 1068*/ {
bevt_18_ta_ph = beva_node.bem_nextGet_0();
bevt_20_ta_ph = bevl_val.bem_sizeGet_0();
bevt_19_ta_ph = beva_pos.bem_add_1(bevt_20_ta_ph);
bevt_17_ta_ph = bem_caseMatch_4(bevt_18_ta_ph, beva_input, bevt_19_ta_ph, null);
return bevt_17_ta_ph;
} /* Line: 1069*/
 else /* Line: 1070*/ {
if (beva_lpos == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1071*/ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 1072*/
} /* Line: 1071*/
} /* Line: 1068*/
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_22_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
/* Line: 1083*/ {
bevt_1_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1083*/ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool)/* Line: 1085*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1085*/
bevt_4_ta_ph = bevl_lpos.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1086*/ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 1088*/
 else /* Line: 1089*/ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 1090*/
} /* Line: 1086*/
 else /* Line: 1083*/ {
break;
} /* Line: 1083*/
} /* Line: 1083*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_globGet_0() throws Throwable {
return bevp_glob;
} /*method end*/
public final BEC_2_4_6_TextString bem_globGetDirect_0() throws Throwable {
return bevp_glob;
} /*method end*/
public final BEC_2_4_4_TextGlob bem_globSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_glob = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() throws Throwable {
return bevp_splits;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_splitsGetDirect_0() throws Throwable {
return bevp_splits;
} /*method end*/
public BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_4_TextGlob bem_splitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1028, 1032, 1032, 1032, 1033, 1035, 1036, 1046, 1046, 1047, 1047, 1047, 1051, 1051, 1052, 1052, 1052, 1053, 1053, 1055, 1055, 1058, 1059, 1059, 1060, 1060, 1062, 1062, 1063, 1064, 1064, 1064, 1064, 1064, 1064, 1064, 1064, 1066, 1067, 1067, 1068, 1068, 1069, 1069, 1069, 1069, 1069, 1071, 1071, 1072, 1076, 1076, 1080, 1081, 1083, 1083, 1083, 1084, 1085, 1085, 1086, 1086, 1086, 1087, 1088, 1090, 1093, 1093, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 27, 28, 29, 30, 31, 32, 40, 41, 42, 43, 44, 72, 77, 78, 79, 84, 85, 86, 89, 90, 93, 94, 95, 97, 98, 100, 101, 103, 104, 105, 110, 111, 112, 113, 116, 117, 120, 121, 126, 127, 132, 133, 134, 135, 136, 137, 140, 145, 146, 150, 151, 163, 164, 167, 168, 173, 174, 176, 177, 179, 180, 185, 186, 187, 190, 197, 198, 201, 204, 207, 211, 214, 217, 221};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
globSet 1 1028 19
assign 1 1032 27
new 0 1032 27
assign 1 1032 28
new 0 1032 28
assign 1 1032 29
new 2 1032 29
assign 1 1033 30
tokenize 1 1033 30
assign 1 1035 31
assign 1 1036 32
assign 1 1046 40
iteratorGet 0 1046 40
assign 1 1046 41
nextNodeGet 0 1046 41
assign 1 1047 42
new 0 1047 42
assign 1 1047 43
caseMatch 4 1047 43
return 1 1047 44
assign 1 1051 72
undef 1 1051 77
assign 1 1052 78
sizeGet 0 1052 78
assign 1 1052 79
equals 1 1052 84
assign 1 1053 85
new 0 1053 85
return 1 1053 86
assign 1 1055 89
new 0 1055 89
return 1 1055 90
assign 1 1058 93
heldGet 0 1058 93
assign 1 1059 94
new 0 1059 94
assign 1 1059 95
equals 1 1059 95
assign 1 1060 97
starMatch 3 1060 97
return 1 1060 98
assign 1 1062 100
new 0 1062 100
assign 1 1062 101
equals 1 1062 101
assign 1 1063 103
increment 0 1063 103
assign 1 1064 104
sizeGet 0 1064 104
assign 1 1064 105
lesserEquals 1 1064 110
assign 1 1064 111
nextGet 0 1064 111
assign 1 1064 112
caseMatch 4 1064 112
return 1 1064 113
assign 1 1064 116
new 0 1064 116
return 1 1064 117
assign 1 1066 120
find 2 1066 120
assign 1 1067 121
def 1 1067 126
assign 1 1068 127
equals 1 1068 132
assign 1 1069 133
nextGet 0 1069 133
assign 1 1069 134
sizeGet 0 1069 134
assign 1 1069 135
add 1 1069 135
assign 1 1069 136
caseMatch 4 1069 136
return 1 1069 137
assign 1 1071 140
def 1 1071 145
firstSet 1 1072 146
assign 1 1076 150
new 0 1076 150
return 1 1076 151
assign 1 1080 163
nextGet 0 1080 163
assign 1 1081 164
new 0 1081 164
assign 1 1083 167
sizeGet 0 1083 167
assign 1 1083 168
lesserEquals 1 1083 173
assign 1 1084 174
caseMatch 4 1084 174
assign 1 1085 176
new 0 1085 176
return 1 1085 177
assign 1 1086 179
firstGet 0 1086 179
assign 1 1086 180
def 1 1086 185
assign 1 1087 186
firstGet 0 1087 186
firstSet 1 1088 187
assign 1 1090 190
increment 0 1090 190
assign 1 1093 197
new 0 1093 197
return 1 1093 198
return 1 0 201
return 1 0 204
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1950883809: return bem_splitsGet_0();
case -568575955: return bem_hashGet_0();
case -220602072: return bem_echo_0();
case 774721401: return bem_serializeToString_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -674491561: return bem_sourceFileNameGet_0();
case -829315536: return bem_classNameGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case 234248288: return bem_copy_0();
case 612102428: return bem_globGet_0();
case -437991849: return bem_toString_0();
case -763928014: return bem_create_0();
case -419834598: return bem_print_0();
case -2109060100: return bem_splitsGetDirect_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -18123974: return bem_new_0();
case 1087832621: return bem_tagGet_0();
case 2087607686: return bem_iteratorGet_0();
case -311580506: return bem_globGetDirect_0();
case 1126911928: return bem_serializeContents_0();
case -1454950260: return bem_fieldIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 152976103: return bem_splitsSet_1(bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 1562268946: return bem_globSetDirect_1(bevd_0);
case -1565488086: return bem_splitsSetDirect_1(bevd_0);
case -880161360: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case 665180175: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case -643713889: return bem_notEquals_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -26112674: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 956838706: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 2137879418: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_4_4_TextGlob_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_TextGlob();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_type;
}
}
