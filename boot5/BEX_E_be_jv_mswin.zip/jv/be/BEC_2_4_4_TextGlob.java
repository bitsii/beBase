package be;
/* IO:File: source/base/Tokenize.be */
public class BEC_2_4_4_TextGlob extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_1, 1));
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_2, 1));
public static BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;
public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tok = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_phold.bemd_0(1697904941);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = bem_caseMatch_4(bevl_node, beva_input, bevt_2_tmpany_phold, null);
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) throws Throwable {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
if (beva_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_2_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 126 */
 else  /* Line: 127 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 128 */
} /* Line: 125 */
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_0;
bevt_5_tmpany_phold = bevl_val.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_7_tmpany_phold = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_tmpany_phold;
} /* Line: 133 */
bevt_9_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_1;
bevt_8_tmpany_phold = bevl_val.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 135 */ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_13_tmpany_phold = beva_node.bem_nextGet_0();
bevt_12_tmpany_phold = bem_caseMatch_4(bevt_13_tmpany_phold, beva_input, beva_pos, null);
return bevt_12_tmpany_phold;
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_14_tmpany_phold;
} /* Line: 137 */
} /* Line: 137 */
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 140 */ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_18_tmpany_phold = beva_node.bem_nextGet_0();
bevt_20_tmpany_phold = bevl_val.bem_sizeGet_0();
bevt_19_tmpany_phold = beva_pos.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bem_caseMatch_4(bevt_18_tmpany_phold, beva_input, bevt_19_tmpany_phold, null);
return bevt_17_tmpany_phold;
} /* Line: 142 */
 else  /* Line: 143 */ {
if (beva_lpos == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 144 */ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 145 */
} /* Line: 144 */
} /* Line: 141 */
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_22_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
 /* Line: 156 */ {
bevt_1_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool) /* Line: 158 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 158 */
bevt_4_tmpany_phold = bevl_lpos.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 159 */ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 161 */
 else  /* Line: 162 */ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 163 */
} /* Line: 159 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_globGet_0() throws Throwable {
return bevp_glob;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() throws Throwable {
return bevp_splits;
} /*method end*/
public BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {101, 105, 105, 105, 106, 108, 109, 119, 119, 120, 120, 120, 124, 124, 125, 125, 125, 126, 126, 128, 128, 131, 132, 132, 133, 133, 135, 135, 136, 137, 137, 137, 137, 137, 137, 137, 137, 139, 140, 140, 141, 141, 142, 142, 142, 142, 142, 144, 144, 145, 149, 149, 153, 154, 156, 156, 156, 157, 158, 158, 159, 159, 159, 160, 161, 163, 166, 166, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 24, 25, 26, 27, 28, 29, 37, 38, 39, 40, 41, 69, 74, 75, 76, 81, 82, 83, 86, 87, 90, 91, 92, 94, 95, 97, 98, 100, 101, 102, 107, 108, 109, 110, 113, 114, 117, 118, 123, 124, 129, 130, 131, 132, 133, 134, 137, 142, 143, 147, 148, 160, 161, 164, 165, 170, 171, 173, 174, 176, 177, 182, 183, 184, 187, 194, 195, 198, 201, 204};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
globSet 1 101 16
assign 1 105 24
new 0 105 24
assign 1 105 25
new 0 105 25
assign 1 105 26
new 2 105 26
assign 1 106 27
tokenize 1 106 27
assign 1 108 28
assign 1 109 29
assign 1 119 37
iteratorGet 0 119 37
assign 1 119 38
nextNodeGet 0 119 38
assign 1 120 39
new 0 120 39
assign 1 120 40
caseMatch 4 120 40
return 1 120 41
assign 1 124 69
undef 1 124 74
assign 1 125 75
sizeGet 0 125 75
assign 1 125 76
equals 1 125 81
assign 1 126 82
new 0 126 82
return 1 126 83
assign 1 128 86
new 0 128 86
return 1 128 87
assign 1 131 90
heldGet 0 131 90
assign 1 132 91
new 0 132 91
assign 1 132 92
equals 1 132 92
assign 1 133 94
starMatch 3 133 94
return 1 133 95
assign 1 135 97
new 0 135 97
assign 1 135 98
equals 1 135 98
assign 1 136 100
increment 0 136 100
assign 1 137 101
sizeGet 0 137 101
assign 1 137 102
lesserEquals 1 137 107
assign 1 137 108
nextGet 0 137 108
assign 1 137 109
caseMatch 4 137 109
return 1 137 110
assign 1 137 113
new 0 137 113
return 1 137 114
assign 1 139 117
find 2 139 117
assign 1 140 118
def 1 140 123
assign 1 141 124
equals 1 141 129
assign 1 142 130
nextGet 0 142 130
assign 1 142 131
sizeGet 0 142 131
assign 1 142 132
add 1 142 132
assign 1 142 133
caseMatch 4 142 133
return 1 142 134
assign 1 144 137
def 1 144 142
firstSet 1 145 143
assign 1 149 147
new 0 149 147
return 1 149 148
assign 1 153 160
nextGet 0 153 160
assign 1 154 161
new 0 154 161
assign 1 156 164
sizeGet 0 156 164
assign 1 156 165
lesserEquals 1 156 170
assign 1 157 171
caseMatch 4 157 171
assign 1 158 173
new 0 158 173
return 1 158 174
assign 1 159 176
firstGet 0 159 176
assign 1 159 177
def 1 159 182
assign 1 160 183
firstGet 0 160 183
firstSet 1 161 184
assign 1 163 187
increment 0 163 187
assign 1 166 194
new 0 166 194
return 1 166 195
return 1 0 198
return 1 0 201
assign 1 0 204
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2092326455: return bem_many_0();
case 65678538: return bem_echo_0();
case -1620819332: return bem_once_0();
case -933929337: return bem_splitsGet_0();
case 1342246094: return bem_print_0();
case -117420215: return bem_serializeContents_0();
case -1197182710: return bem_serializeToString_0();
case 1637405965: return bem_toString_0();
case -261636586: return bem_classNameGet_0();
case 1053098123: return bem_hashGet_0();
case -1975952737: return bem_tagGet_0();
case 386788561: return bem_new_0();
case 866679447: return bem_serializationIteratorGet_0();
case 168705805: return bem_iteratorGet_0();
case 845917022: return bem_fieldIteratorGet_0();
case 582818432: return bem_create_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -630286987: return bem_globGet_0();
case -1712633963: return bem_toAny_0();
case -935771084: return bem_sourceFileNameGet_0();
case 1449516553: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -774980483: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case 1601196044: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case -1921133350: return bem_defined_1(bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1695837331: return bem_splitsSet_1(bevd_0);
case 707881002: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1906053347: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1850396500: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_4_TextGlob_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_TextGlob();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
}
