package be;
/* IO:File: source/base/Tokenize.be */
public class BEC_2_4_4_TextGlob extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_1, 1));
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_2, 1));
public static BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;

public static BET_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_type;

public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_tok = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_phold.bemd_0(-565612986);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = bem_caseMatch_4(bevl_node, beva_input, bevt_2_tmpany_phold, null);
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) throws Throwable {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
if (beva_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_2_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 125 */
 else  /* Line: 126 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 127 */
} /* Line: 124 */
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_0;
bevt_5_tmpany_phold = bevl_val.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_7_tmpany_phold = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_tmpany_phold;
} /* Line: 132 */
bevt_9_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_1;
bevt_8_tmpany_phold = bevl_val.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 134 */ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_13_tmpany_phold = beva_node.bem_nextGet_0();
bevt_12_tmpany_phold = bem_caseMatch_4(bevt_13_tmpany_phold, beva_input, beva_pos, null);
return bevt_12_tmpany_phold;
} /* Line: 136 */
 else  /* Line: 136 */ {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_14_tmpany_phold;
} /* Line: 136 */
} /* Line: 136 */
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 139 */ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 140 */ {
bevt_18_tmpany_phold = beva_node.bem_nextGet_0();
bevt_20_tmpany_phold = bevl_val.bem_sizeGet_0();
bevt_19_tmpany_phold = beva_pos.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bem_caseMatch_4(bevt_18_tmpany_phold, beva_input, bevt_19_tmpany_phold, null);
return bevt_17_tmpany_phold;
} /* Line: 141 */
 else  /* Line: 142 */ {
if (beva_lpos == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 143 */ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 144 */
} /* Line: 143 */
} /* Line: 140 */
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_22_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
 /* Line: 155 */ {
bevt_1_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool) /* Line: 157 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 157 */
bevt_4_tmpany_phold = bevl_lpos.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 158 */ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 160 */
 else  /* Line: 161 */ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 162 */
} /* Line: 158 */
 else  /* Line: 155 */ {
break;
} /* Line: 155 */
} /* Line: 155 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_globGet_0() throws Throwable {
return bevp_glob;
} /*method end*/
public final BEC_2_4_6_TextString bem_globGetDirect_0() throws Throwable {
return bevp_glob;
} /*method end*/
public final BEC_2_4_4_TextGlob bem_globSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_glob = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() throws Throwable {
return bevp_splits;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_splitsGetDirect_0() throws Throwable {
return bevp_splits;
} /*method end*/
public BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_4_TextGlob bem_splitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {100, 104, 104, 104, 105, 107, 108, 118, 118, 119, 119, 119, 123, 123, 124, 124, 124, 125, 125, 127, 127, 130, 131, 131, 132, 132, 134, 134, 135, 136, 136, 136, 136, 136, 136, 136, 136, 138, 139, 139, 140, 140, 141, 141, 141, 141, 141, 143, 143, 144, 148, 148, 152, 153, 155, 155, 155, 156, 157, 157, 158, 158, 158, 159, 160, 162, 165, 165, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 27, 28, 29, 30, 31, 32, 40, 41, 42, 43, 44, 72, 77, 78, 79, 84, 85, 86, 89, 90, 93, 94, 95, 97, 98, 100, 101, 103, 104, 105, 110, 111, 112, 113, 116, 117, 120, 121, 126, 127, 132, 133, 134, 135, 136, 137, 140, 145, 146, 150, 151, 163, 164, 167, 168, 173, 174, 176, 177, 179, 180, 185, 186, 187, 190, 197, 198, 201, 204, 207, 211, 214, 217, 221};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
globSet 1 100 19
assign 1 104 27
new 0 104 27
assign 1 104 28
new 0 104 28
assign 1 104 29
new 2 104 29
assign 1 105 30
tokenize 1 105 30
assign 1 107 31
assign 1 108 32
assign 1 118 40
iteratorGet 0 118 40
assign 1 118 41
nextNodeGet 0 118 41
assign 1 119 42
new 0 119 42
assign 1 119 43
caseMatch 4 119 43
return 1 119 44
assign 1 123 72
undef 1 123 77
assign 1 124 78
sizeGet 0 124 78
assign 1 124 79
equals 1 124 84
assign 1 125 85
new 0 125 85
return 1 125 86
assign 1 127 89
new 0 127 89
return 1 127 90
assign 1 130 93
heldGet 0 130 93
assign 1 131 94
new 0 131 94
assign 1 131 95
equals 1 131 95
assign 1 132 97
starMatch 3 132 97
return 1 132 98
assign 1 134 100
new 0 134 100
assign 1 134 101
equals 1 134 101
assign 1 135 103
increment 0 135 103
assign 1 136 104
sizeGet 0 136 104
assign 1 136 105
lesserEquals 1 136 110
assign 1 136 111
nextGet 0 136 111
assign 1 136 112
caseMatch 4 136 112
return 1 136 113
assign 1 136 116
new 0 136 116
return 1 136 117
assign 1 138 120
find 2 138 120
assign 1 139 121
def 1 139 126
assign 1 140 127
equals 1 140 132
assign 1 141 133
nextGet 0 141 133
assign 1 141 134
sizeGet 0 141 134
assign 1 141 135
add 1 141 135
assign 1 141 136
caseMatch 4 141 136
return 1 141 137
assign 1 143 140
def 1 143 145
firstSet 1 144 146
assign 1 148 150
new 0 148 150
return 1 148 151
assign 1 152 163
nextGet 0 152 163
assign 1 153 164
new 0 153 164
assign 1 155 167
sizeGet 0 155 167
assign 1 155 168
lesserEquals 1 155 173
assign 1 156 174
caseMatch 4 156 174
assign 1 157 176
new 0 157 176
return 1 157 177
assign 1 158 179
firstGet 0 158 179
assign 1 158 180
def 1 158 185
assign 1 159 186
firstGet 0 159 186
firstSet 1 160 187
assign 1 162 190
increment 0 162 190
assign 1 165 197
new 0 165 197
return 1 165 198
return 1 0 201
return 1 0 204
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -738439163: return bem_copy_0();
case 2084331281: return bem_new_0();
case 690609043: return bem_print_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case -1522610135: return bem_serializeToString_0();
case -576502505: return bem_create_0();
case 247075507: return bem_fieldNamesGet_0();
case 320622940: return bem_echo_0();
case 484635838: return bem_tagGet_0();
case 1969080256: return bem_once_0();
case 101762581: return bem_serializeContents_0();
case -1431261112: return bem_globGet_0();
case 1315466522: return bem_splitsGet_0();
case 1551415145: return bem_toAny_0();
case 645211302: return bem_iteratorGet_0();
case -1966626789: return bem_hashGet_0();
case -357139526: return bem_many_0();
case 97839759: return bem_globGetDirect_0();
case -1976081006: return bem_splitsGetDirect_0();
case 983736684: return bem_serializationIteratorGet_0();
case -1313098664: return bem_toString_0();
case -753430171: return bem_fieldIteratorGet_0();
case -2005156683: return bem_classNameGet_0();
case -890719598: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2123695769: return bem_splitsSetDirect_1(bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case -1904387760: return bem_globSetDirect_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1719727855: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case 411819087: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case -1865671550: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1690714996: return bem_splitsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -297050562: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1207052203: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_4_TextGlob_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_TextGlob();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_type;
}
}
