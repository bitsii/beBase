package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildPtySyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildPtySyn() { }
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x74,0x79,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_0 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_2 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_3 = {0x6D,0x65,0x6D,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_4 = {0x61,0x6E,0x79};
public static BEC_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_inst;

public static BET_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_type;

public BEC_2_4_3_MathInt bevp_mpos;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_6_BuildVarSyn bevp_memSyn;
public BEC_2_5_4_LogicBool bevp_isSlot;
public BEC_2_5_6_BuildPtySyn bem_new_2(BEC_2_6_6_SystemObject beva_vnode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_5_3_BuildVar bevl_v = null;
bevl_v = (BEC_2_5_3_BuildVar) beva_vnode.bemd_0(-1906134035);
bevp_name = bevl_v.bem_nameGet_0();
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_memSyn = (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1(bevl_v);
bevp_isSlot = bevl_v.bem_isSlotGet_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_0_ta_ph.bem_newlineGet_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_6_BuildPtySyn_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_nl);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildPtySyn_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevl_nl);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevl_toRet = bevt_1_ta_ph.bem_add_1(bevl_nl);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildPtySyn_bels_2));
bevt_9_ta_ph = bevl_toRet.bemd_1(311290374, bevt_10_ta_ph);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(311290374, bevl_nl);
bevt_11_ta_ph = bevp_origin.bem_toString_0();
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(311290374, bevt_11_ta_ph);
bevl_toRet = bevt_7_ta_ph.bemd_1(311290374, bevl_nl);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildPtySyn_bels_3));
bevt_12_ta_ph = bevl_toRet.bemd_1(311290374, bevt_13_ta_ph);
bevl_toRet = bevt_12_ta_ph.bemd_1(311290374, bevl_nl);
bevt_14_ta_ph = bevp_memSyn.bem_isTypedGet_0();
if (bevt_14_ta_ph.bevi_bool)/* Line: 522*/ {
bevt_17_ta_ph = bevp_memSyn.bem_namepathGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_toString_0();
bevt_15_ta_ph = bevl_toRet.bemd_1(311290374, bevt_16_ta_ph);
bevl_toRet = bevt_15_ta_ph.bemd_1(311290374, bevl_nl);
} /* Line: 523*/
 else /* Line: 524*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildPtySyn_bels_4));
bevt_18_ta_ph = bevl_toRet.bemd_1(311290374, bevt_19_ta_ph);
bevl_toRet = bevt_18_ta_ph.bemd_1(311290374, bevl_nl);
} /* Line: 525*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_mposGet_0() throws Throwable {
return bevp_mpos;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_mposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_memSynGet_0() throws Throwable {
return bevp_memSyn;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_memSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSlotGet_0() throws Throwable {
return bevp_isSlot;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_isSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {506, 510, 511, 512, 513, 518, 518, 519, 519, 519, 519, 519, 519, 519, 520, 520, 520, 520, 520, 520, 521, 521, 521, 522, 523, 523, 523, 523, 525, 525, 525, 527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 25, 26, 27, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 73, 74, 75, 76, 79, 80, 81, 83, 86, 89, 93, 96, 100, 103, 107, 110, 114, 117};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 506 23
heldGet 0 506 23
assign 1 510 24
nameGet 0 510 24
assign 1 511 25
assign 1 512 26
anyNew 1 512 26
assign 1 513 27
isSlotGet 0 513 27
assign 1 518 53
new 0 518 53
assign 1 518 54
newlineGet 0 518 54
assign 1 519 55
new 0 519 55
assign 1 519 56
add 1 519 56
assign 1 519 57
new 0 519 57
assign 1 519 58
add 1 519 58
assign 1 519 59
add 1 519 59
assign 1 519 60
add 1 519 60
assign 1 519 61
add 1 519 61
assign 1 520 62
new 0 520 62
assign 1 520 63
add 1 520 63
assign 1 520 64
add 1 520 64
assign 1 520 65
toString 0 520 65
assign 1 520 66
add 1 520 66
assign 1 520 67
add 1 520 67
assign 1 521 68
new 0 521 68
assign 1 521 69
add 1 521 69
assign 1 521 70
add 1 521 70
assign 1 522 71
isTypedGet 0 522 71
assign 1 523 73
namepathGet 0 523 73
assign 1 523 74
toString 0 523 74
assign 1 523 75
add 1 523 75
assign 1 523 76
add 1 523 76
assign 1 525 79
new 0 525 79
assign 1 525 80
add 1 525 80
assign 1 525 81
add 1 525 81
return 1 527 83
return 1 0 86
assign 1 0 89
return 1 0 93
assign 1 0 96
return 1 0 100
assign 1 0 103
return 1 0 107
assign 1 0 110
return 1 0 114
assign 1 0 117
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -443343999: return bem_create_0();
case -1628849159: return bem_isSlotGet_0();
case -1983878186: return bem_new_0();
case 13717429: return bem_toString_0();
case -123880973: return bem_copy_0();
case 1438192594: return bem_hashGet_0();
case -443483612: return bem_originGet_0();
case 1816156026: return bem_memSynGet_0();
case -2141099741: return bem_mposGet_0();
case 621334352: return bem_print_0();
case -1003281216: return bem_iteratorGet_0();
case -508927184: return bem_nameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1355165899: return bem_copyTo_1(bevd_0);
case 1713177550: return bem_undef_1(bevd_0);
case -1552236208: return bem_mposSet_1(bevd_0);
case -731871147: return bem_def_1(bevd_0);
case -182879054: return bem_notEquals_1(bevd_0);
case -1184232290: return bem_memSynSet_1(bevd_0);
case 2044248774: return bem_isSlotSet_1(bevd_0);
case -1390323212: return bem_originSet_1(bevd_0);
case 301931194: return bem_equals_1(bevd_0);
case -889763720: return bem_nameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1473620469: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1378156325: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1808641530: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -433881604: return bem_new_2(bevd_0, bevd_1);
case 1548431016: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildPtySyn_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildPtySyn_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildPtySyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst = (BEC_2_5_6_BuildPtySyn) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_type;
}
}
