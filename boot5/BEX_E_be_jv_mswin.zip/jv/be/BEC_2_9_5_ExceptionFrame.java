package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_9_5_ExceptionFrame extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ExceptionFrame() { }
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clname = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x46,0x72,0x61,0x6D,0x65};
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x46,0x72,0x61,0x6D,0x65,0x3E,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_1 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_2 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_7 = {0x0A};
public static BEC_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_inst;

public static BET_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_type;

public BEC_2_4_6_TextString bevp_klassName;
public BEC_2_4_6_TextString bevp_methodName;
public BEC_2_4_6_TextString bevp_emitFileName;
public BEC_2_4_3_MathInt bevp_emitLine;
public BEC_2_4_6_TextString bevp_fileName;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_9_5_ExceptionFrame bem_new_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__emitFileName, BEC_2_4_3_MathInt beva__emitLine) throws Throwable {
bevp_klassName = beva__klassName;
bevp_methodName = beva__methodName;
bevp_emitFileName = beva__emitFileName;
bevp_emitLine = beva__emitLine;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_extractLine_0() throws Throwable {
BEC_2_6_16_SystemExceptionBuilder bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_16_SystemExceptionBuilder) BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
bevp_line = bevt_0_ta_ph.bem_getLineForEmitLine_2(bevp_klassName, bevp_emitLine);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString(17, bece_BEC_2_9_5_ExceptionFrame_bels_0));
bevt_0_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_9_5_ExceptionFrame_bels_1));
bevl_res.bem_addValue_1(bevt_0_ta_ph);
if (bevp_klassName == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 267*/ {
bevl_res.bem_addValue_1(bevp_klassName);
} /* Line: 267*/
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_9_5_ExceptionFrame_bels_2));
bevl_res.bem_addValue_1(bevt_2_ta_ph);
if (bevp_methodName == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 269*/ {
bevl_res.bem_addValue_1(bevp_methodName);
} /* Line: 269*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_9_5_ExceptionFrame_bels_3));
bevl_res.bem_addValue_1(bevt_4_ta_ph);
if (bevp_fileName == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 271*/ {
bevl_res.bem_addValue_1(bevp_fileName);
} /* Line: 271*/
bevt_6_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_9_5_ExceptionFrame_bels_4));
bevl_res.bem_addValue_1(bevt_6_ta_ph);
if (bevp_line == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_8_ta_ph = bevp_line.bem_toString_0();
bevl_res.bem_addValue_1(bevt_8_ta_ph);
} /* Line: 273*/
bevt_9_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_5));
bevl_res.bem_addValue_1(bevt_9_ta_ph);
if (bevp_emitFileName == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 275*/ {
bevl_res.bem_addValue_1(bevp_emitFileName);
} /* Line: 275*/
bevt_11_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_6));
bevl_res.bem_addValue_1(bevt_11_ta_ph);
if (bevp_emitLine == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_13_ta_ph = bevp_emitLine.bem_toString_0();
bevl_res.bem_addValue_1(bevt_13_ta_ph);
} /* Line: 277*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_9_5_ExceptionFrame_bels_7));
bevl_res.bem_addValue_1(bevt_14_ta_ph);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public final BEC_2_4_6_TextString bem_klassNameGetDirect_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public final BEC_2_4_6_TextString bem_methodNameGetDirect_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitFileNameGet_0() throws Throwable {
return bevp_emitFileName;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitFileNameGetDirect_0() throws Throwable {
return bevp_emitFileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_emitFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitLineGet_0() throws Throwable {
return bevp_emitLine;
} /*method end*/
public final BEC_2_4_3_MathInt bem_emitLineGetDirect_0() throws Throwable {
return bevp_emitLine;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitLineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_emitLineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public final BEC_2_4_6_TextString bem_fileNameGetDirect_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public final BEC_2_4_3_MathInt bem_lineGetDirect_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_5_ExceptionFrame bem_lineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {245, 246, 247, 248, 261, 261, 265, 266, 266, 267, 267, 267, 268, 268, 269, 269, 269, 270, 270, 271, 271, 271, 272, 272, 273, 273, 273, 273, 274, 274, 275, 275, 275, 276, 276, 277, 277, 277, 277, 278, 278, 279, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 29, 34, 35, 55, 56, 57, 58, 63, 64, 66, 67, 68, 73, 74, 76, 77, 78, 83, 84, 86, 87, 88, 93, 94, 95, 97, 98, 99, 104, 105, 107, 108, 109, 114, 115, 116, 118, 119, 120, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 245 26
assign 1 246 27
assign 1 247 28
assign 1 248 29
assign 1 261 34
new 0 261 34
assign 1 261 35
getLineForEmitLine 2 261 35
assign 1 265 55
new 0 265 55
assign 1 266 56
new 0 266 56
addValue 1 266 57
assign 1 267 58
def 1 267 63
addValue 1 267 64
assign 1 268 66
new 0 268 66
addValue 1 268 67
assign 1 269 68
def 1 269 73
addValue 1 269 74
assign 1 270 76
new 0 270 76
addValue 1 270 77
assign 1 271 78
def 1 271 83
addValue 1 271 84
assign 1 272 86
new 0 272 86
addValue 1 272 87
assign 1 273 88
def 1 273 93
assign 1 273 94
toString 0 273 94
addValue 1 273 95
assign 1 274 97
new 0 274 97
addValue 1 274 98
assign 1 275 99
def 1 275 104
addValue 1 275 105
assign 1 276 107
new 0 276 107
addValue 1 276 108
assign 1 277 109
def 1 277 114
assign 1 277 115
toString 0 277 115
addValue 1 277 116
assign 1 278 118
new 0 278 118
addValue 1 278 119
return 1 279 120
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -721312392: return bem_methodNameGet_0();
case -568575955: return bem_hashGet_0();
case -220602072: return bem_echo_0();
case 774721401: return bem_serializeToString_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -1683504798: return bem_emitFileNameGetDirect_0();
case -674491561: return bem_sourceFileNameGet_0();
case 2018474900: return bem_emitFileNameGet_0();
case -829315536: return bem_classNameGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case -561315226: return bem_lineGet_0();
case 234248288: return bem_copy_0();
case -437991849: return bem_toString_0();
case -763928014: return bem_create_0();
case -419834598: return bem_print_0();
case -230610085: return bem_fileNameGetDirect_0();
case -111824747: return bem_emitLineGet_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -1566042097: return bem_extractLine_0();
case -18123974: return bem_new_0();
case -1829052735: return bem_klassNameGet_0();
case 1087832621: return bem_tagGet_0();
case 433620537: return bem_methodNameGetDirect_0();
case 2087607686: return bem_iteratorGet_0();
case 625526242: return bem_fileNameGet_0();
case -1356160227: return bem_emitLineGetDirect_0();
case 1126911928: return bem_serializeContents_0();
case -1608824988: return bem_klassNameGetDirect_0();
case -1454950260: return bem_fieldIteratorGet_0();
case 1082866231: return bem_lineGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -643713889: return bem_notEquals_1(bevd_0);
case -410432498: return bem_klassNameSetDirect_1(bevd_0);
case -1331091124: return bem_emitLineSet_1(bevd_0);
case -2040022422: return bem_fileNameSet_1(bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case 1997201967: return bem_emitLineSetDirect_1(bevd_0);
case 1451290722: return bem_methodNameSet_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case 326674677: return bem_lineSet_1(bevd_0);
case -1409108040: return bem_fileNameSetDirect_1(bevd_0);
case 1744009274: return bem_emitFileNameSetDirect_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case -1871138621: return bem_emitFileNameSet_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case 97024700: return bem_klassNameSet_1(bevd_0);
case -1224526220: return bem_methodNameSetDirect_1(bevd_0);
case -1531465868: return bem_lineSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1865650516: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ExceptionFrame_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_5_ExceptionFrame_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ExceptionFrame();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst = (BEC_2_9_5_ExceptionFrame) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_type;
}
}
