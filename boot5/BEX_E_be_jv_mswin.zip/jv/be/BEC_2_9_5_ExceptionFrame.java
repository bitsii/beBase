package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_9_5_ExceptionFrame extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ExceptionFrame() { }
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clname = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x46,0x72,0x61,0x6D,0x65};
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x46,0x72,0x61,0x6D,0x65,0x3E,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_1 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_2 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_7 = {0x0A};
public static BEC_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_inst;

public static BET_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_type;

public BEC_2_4_6_TextString bevp_klassName;
public BEC_2_4_6_TextString bevp_methodName;
public BEC_2_4_6_TextString bevp_emitFileName;
public BEC_2_4_3_MathInt bevp_emitLine;
public BEC_2_4_6_TextString bevp_fileName;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_9_5_ExceptionFrame bem_new_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__emitFileName, BEC_2_4_3_MathInt beva__emitLine) throws Throwable {
bevp_klassName = beva__klassName;
bevp_methodName = beva__methodName;
bevp_emitFileName = beva__emitFileName;
bevp_emitLine = beva__emitLine;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_extractLine_0() throws Throwable {
BEC_2_6_16_SystemExceptionBuilder bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_16_SystemExceptionBuilder) BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
bevp_line = bevt_0_ta_ph.bem_getLineForEmitLine_2(bevp_klassName, bevp_emitLine);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevl_res = (new BEC_2_4_6_TextString(17, bece_BEC_2_9_5_ExceptionFrame_bels_0));
bevt_0_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_9_5_ExceptionFrame_bels_1));
bevl_res.bem_addValue_1(bevt_0_ta_ph);
if (bevp_klassName == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_res.bem_addValue_1(bevp_klassName);
} /* Line: 258*/
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_9_5_ExceptionFrame_bels_2));
bevl_res.bem_addValue_1(bevt_2_ta_ph);
if (bevp_methodName == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 260*/ {
bevl_res.bem_addValue_1(bevp_methodName);
} /* Line: 260*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_9_5_ExceptionFrame_bels_3));
bevl_res.bem_addValue_1(bevt_4_ta_ph);
if (bevp_fileName == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 262*/ {
bevl_res.bem_addValue_1(bevp_fileName);
} /* Line: 262*/
bevt_6_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_9_5_ExceptionFrame_bels_4));
bevl_res.bem_addValue_1(bevt_6_ta_ph);
if (bevp_line == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 264*/ {
bevt_8_ta_ph = bevp_line.bem_toString_0();
bevl_res.bem_addValue_1(bevt_8_ta_ph);
} /* Line: 264*/
bevt_9_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_5));
bevl_res.bem_addValue_1(bevt_9_ta_ph);
if (bevp_emitFileName == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 266*/ {
bevl_res.bem_addValue_1(bevp_emitFileName);
} /* Line: 266*/
bevt_11_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_6));
bevl_res.bem_addValue_1(bevt_11_ta_ph);
if (bevp_emitLine == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 268*/ {
bevt_13_ta_ph = bevp_emitLine.bem_toString_0();
bevl_res.bem_addValue_1(bevt_13_ta_ph);
} /* Line: 268*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_9_5_ExceptionFrame_bels_7));
bevl_res.bem_addValue_1(bevt_14_ta_ph);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitFileNameGet_0() throws Throwable {
return bevp_emitFileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitLineGet_0() throws Throwable {
return bevp_emitLine;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitLineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGet_0() throws Throwable {
return bevp_line;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {236, 237, 238, 239, 252, 252, 256, 257, 257, 258, 258, 258, 259, 259, 260, 260, 260, 261, 261, 262, 262, 262, 263, 263, 264, 264, 264, 264, 265, 265, 266, 266, 266, 267, 267, 268, 268, 268, 268, 269, 269, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 27, 28, 29, 34, 35, 55, 56, 57, 58, 63, 64, 66, 67, 68, 73, 74, 76, 77, 78, 83, 84, 86, 87, 88, 93, 94, 95, 97, 98, 99, 104, 105, 107, 108, 109, 114, 115, 116, 118, 119, 120, 123, 126, 130, 133, 137, 140, 144, 147, 151, 154, 158, 161};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 236 26
assign 1 237 27
assign 1 238 28
assign 1 239 29
assign 1 252 34
new 0 252 34
assign 1 252 35
getLineForEmitLine 2 252 35
assign 1 256 55
new 0 256 55
assign 1 257 56
new 0 257 56
addValue 1 257 57
assign 1 258 58
def 1 258 63
addValue 1 258 64
assign 1 259 66
new 0 259 66
addValue 1 259 67
assign 1 260 68
def 1 260 73
addValue 1 260 74
assign 1 261 76
new 0 261 76
addValue 1 261 77
assign 1 262 78
def 1 262 83
addValue 1 262 84
assign 1 263 86
new 0 263 86
addValue 1 263 87
assign 1 264 88
def 1 264 93
assign 1 264 94
toString 0 264 94
addValue 1 264 95
assign 1 265 97
new 0 265 97
addValue 1 265 98
assign 1 266 99
def 1 266 104
addValue 1 266 105
assign 1 267 107
new 0 267 107
addValue 1 267 108
assign 1 268 109
def 1 268 114
assign 1 268 115
toString 0 268 115
addValue 1 268 116
assign 1 269 118
new 0 269 118
addValue 1 269 119
return 1 270 120
return 1 0 123
assign 1 0 126
return 1 0 130
assign 1 0 133
return 1 0 137
assign 1 0 140
return 1 0 144
assign 1 0 147
return 1 0 151
assign 1 0 154
return 1 0 158
assign 1 0 161
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2006813550: return bem_print_0();
case -343641898: return bem_klassNameGet_0();
case 2121263782: return bem_emitLineGet_0();
case -753678241: return bem_toString_0();
case 537905812: return bem_extractLine_0();
case 782047985: return bem_methodNameGet_0();
case 142227109: return bem_copy_0();
case 1883105734: return bem_create_0();
case -2072460600: return bem_fileNameGet_0();
case -1202199849: return bem_new_0();
case 1653976958: return bem_iteratorGet_0();
case -733772191: return bem_emitFileNameGet_0();
case 135466177: return bem_hashGet_0();
case 1551502556: return bem_lineGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 388121757: return bem_copyTo_1(bevd_0);
case -2104029535: return bem_undef_1(bevd_0);
case 72201968: return bem_equals_1(bevd_0);
case 1456028789: return bem_klassNameSet_1(bevd_0);
case 413616696: return bem_notEquals_1(bevd_0);
case -1300646703: return bem_lineSet_1(bevd_0);
case 821497226: return bem_emitLineSet_1(bevd_0);
case 317788441: return bem_fileNameSet_1(bevd_0);
case 482599590: return bem_def_1(bevd_0);
case 1685385096: return bem_emitFileNameSet_1(bevd_0);
case -103408206: return bem_methodNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -938062108: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -771677452: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -544842910: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 844231596: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 611639816: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ExceptionFrame_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_5_ExceptionFrame_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ExceptionFrame();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst = (BEC_2_9_5_ExceptionFrame) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_type;
}
}
