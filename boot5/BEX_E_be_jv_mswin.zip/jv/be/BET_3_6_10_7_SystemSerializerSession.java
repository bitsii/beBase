package be;
public class BET_3_6_10_7_SystemSerializerSession extends BETS_Object {
public BET_3_6_10_7_SystemSerializerSession() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "classTagMapGet_0", "classTagMapSet_1", "classTagCountGet_0", "classTagCountSet_1", "serialCountGet_0", "serialCountSet_1", "uniqueGet_0", "uniqueSet_1", "instWriterGet_0", "instWriterSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "classTagMap", "classTagCount", "serialCount", "unique", "instWriter" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_6_10_7_SystemSerializerSession();
}
}
