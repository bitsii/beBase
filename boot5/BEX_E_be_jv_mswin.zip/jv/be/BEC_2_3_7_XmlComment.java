package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_7_XmlComment extends BEC_2_3_3_XmlTag {
public BEC_2_3_7_XmlComment() { }
private static byte[] becc_BEC_2_3_7_XmlComment_clname = {0x58,0x6D,0x6C,0x3A,0x43,0x6F,0x6D,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_7_XmlComment_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_7_XmlComment bece_BEC_2_3_7_XmlComment_bevs_inst;

public static BET_2_3_7_XmlComment bece_BEC_2_3_7_XmlComment_bevs_type;

public BEC_2_4_6_TextString bevp_contents;
public BEC_2_3_7_XmlComment bem_new_1(BEC_2_4_6_TextString beva__contents) throws Throwable {
bevp_contents = beva__contents;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_2_4_6_TextString bem_contentsGet_0() throws Throwable {
return bevp_contents;
} /*method end*/
public final BEC_2_4_6_TextString bem_contentsGetDirect_0() throws Throwable {
return bevp_contents;
} /*method end*/
public BEC_2_3_7_XmlComment bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contents = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_3_7_XmlComment bem_contentsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_contents = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {97, 102, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 17, 20, 23, 26, 30};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 97 13
return 1 102 17
return 1 0 20
return 1 0 23
assign 1 0 26
assign 1 0 30
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 641839943: return bem_toAny_0();
case -881577546: return bem_classNameGet_0();
case -2031839191: return bem_serializationIteratorGet_0();
case -2026540930: return bem_contentsGet_0();
case 148544119: return bem_toString_0();
case 1782351683: return bem_serializeContents_0();
case 569361306: return bem_iteratorGet_0();
case 971841201: return bem_fieldIteratorGet_0();
case 393738758: return bem_serializeToString_0();
case 2146604653: return bem_new_0();
case 1099447992: return bem_fieldNamesGet_0();
case -124285366: return bem_once_0();
case -634018133: return bem_tagGet_0();
case -1750720088: return bem_hashGet_0();
case -224465120: return bem_sourceFileNameGet_0();
case 2144693643: return bem_deserializeClassNameGet_0();
case -653750385: return bem_create_0();
case 908678857: return bem_print_0();
case -1777719432: return bem_contentsGetDirect_0();
case -2007275567: return bem_many_0();
case -212742483: return bem_echo_0();
case -1092510954: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1703616583: return bem_notEquals_1(bevd_0);
case -1224829738: return bem_contentsSetDirect_1(bevd_0);
case -872115670: return bem_defined_1(bevd_0);
case -1928510621: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -249326151: return bem_copyTo_1(bevd_0);
case 1367146792: return bem_sameClass_1(bevd_0);
case 326949551: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1730397553: return bem_undef_1(bevd_0);
case -884607798: return bem_def_1(bevd_0);
case -359346681: return bem_sameType_1(bevd_0);
case 1446250233: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1236734559: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 389340449: return bem_otherType_1(bevd_0);
case 338229476: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1586811529: return bem_undefined_1(bevd_0);
case -1565662060: return bem_sameObject_1(bevd_0);
case -1519516879: return bem_equals_1(bevd_0);
case -448360789: return bem_otherClass_1(bevd_0);
case 1396531004: return bem_contentsSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 29395685: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 827793836: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1899980628: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1061986002: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1194360433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -454033656: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 696322560: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_3_7_XmlComment_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_7_XmlComment_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_7_XmlComment();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_7_XmlComment.bece_BEC_2_3_7_XmlComment_bevs_inst = (BEC_2_3_7_XmlComment) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_7_XmlComment.bece_BEC_2_3_7_XmlComment_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_7_XmlComment.bece_BEC_2_3_7_XmlComment_bevs_type;
}
}
