package be;
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_2 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_11_BuildClassConfig_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_11_BuildClassConfig_bels_2, 4));
public static BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_tmpany_phold = bevp_emitPath.bem_copy_0();
bevt_3_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_1_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_2_tmpany_phold.bem_addStep_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_1_tmpany_phold.bem_addStep_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_5_tmpany_phold = bevp_emitName.bem_add_1(bevt_6_tmpany_phold);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bem_addStep_1(bevt_5_tmpany_phold);
bevt_9_tmpany_phold = bevp_emitPath.bem_copy_0();
bevt_10_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_9_tmpany_phold.bem_addStep_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_12_tmpany_phold = bevp_typeEmitName.bem_add_1(bevt_13_tmpany_phold);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_addStep_1(bevt_12_tmpany_phold);
bevp_classDir = bevp_classPath.bem_parentGet_0();
bevt_14_tmpany_phold = bevp_classDir.bem_copy_0();
bevt_16_tmpany_phold = bece_BEC_2_5_11_BuildClassConfig_bevo_0;
bevt_15_tmpany_phold = bevp_emitName.bem_add_1(bevt_16_tmpany_phold);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_tmpany_phold.bem_addStep_1(bevt_15_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_npGetDirect_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNameGetDirect_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGet_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() throws Throwable {
return bevp_nameSpace;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGet_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitNameGetDirect_0() throws Throwable {
return bevp_emitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGet_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() throws Throwable {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGet_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public final BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() throws Throwable {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGet_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() throws Throwable {
return bevp_classPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGet_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() throws Throwable {
return bevp_typePath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGet_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() throws Throwable {
return bevp_classDir;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGet_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() throws Throwable {
return bevp_synPath;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {2356, 2357, 2358, 2359, 2361, 2362, 2363, 2364, 2365, 2365, 2365, 2365, 2365, 2365, 2365, 2365, 2366, 2366, 2366, 2366, 2366, 2366, 2366, 2366, 2367, 2368, 2368, 2368, 2368, 2375, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 77, 80, 83, 86, 90, 94, 97, 100, 104, 108, 111, 114, 118, 122, 125, 128, 132, 136, 139, 142, 146, 150, 153, 156, 160, 164, 167, 170, 174, 178, 181, 184, 188, 192, 195, 198, 202, 206, 209, 212, 216, 220, 223, 226, 230, 234, 237, 240, 244};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 2356 45
assign 1 2357 46
assign 1 2358 47
assign 1 2359 48
assign 1 2361 49
getNameSpace 1 2361 49
assign 1 2362 50
getEmitName 1 2362 50
assign 1 2363 51
getTypeEmitName 1 2363 51
assign 1 2364 52
getFullEmitName 2 2364 52
assign 1 2365 53
copy 0 2365 53
assign 1 2365 54
emitLangGet 0 2365 54
assign 1 2365 55
addStep 1 2365 55
assign 1 2365 56
new 0 2365 56
assign 1 2365 57
addStep 1 2365 57
assign 1 2365 58
fileExtGet 0 2365 58
assign 1 2365 59
add 1 2365 59
assign 1 2365 60
addStep 1 2365 60
assign 1 2366 61
copy 0 2366 61
assign 1 2366 62
emitLangGet 0 2366 62
assign 1 2366 63
addStep 1 2366 63
assign 1 2366 64
new 0 2366 64
assign 1 2366 65
addStep 1 2366 65
assign 1 2366 66
fileExtGet 0 2366 66
assign 1 2366 67
add 1 2366 67
assign 1 2366 68
addStep 1 2366 68
assign 1 2367 69
parentGet 0 2367 69
assign 1 2368 70
copy 0 2368 70
assign 1 2368 71
new 0 2368 71
assign 1 2368 72
add 1 2368 72
assign 1 2368 73
addStep 1 2368 73
return 1 2375 77
return 1 0 80
return 1 0 83
assign 1 0 86
assign 1 0 90
return 1 0 94
return 1 0 97
assign 1 0 100
assign 1 0 104
return 1 0 108
return 1 0 111
assign 1 0 114
assign 1 0 118
return 1 0 122
return 1 0 125
assign 1 0 128
assign 1 0 132
return 1 0 136
return 1 0 139
assign 1 0 142
assign 1 0 146
return 1 0 150
return 1 0 153
assign 1 0 156
assign 1 0 160
return 1 0 164
return 1 0 167
assign 1 0 170
assign 1 0 174
return 1 0 178
return 1 0 181
assign 1 0 184
assign 1 0 188
return 1 0 192
return 1 0 195
assign 1 0 198
assign 1 0 202
return 1 0 206
return 1 0 209
assign 1 0 212
assign 1 0 216
return 1 0 220
return 1 0 223
assign 1 0 226
assign 1 0 230
return 1 0 234
return 1 0 237
assign 1 0 240
assign 1 0 244
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1923816180: return bem_create_0();
case -1439363594: return bem_npGetDirect_0();
case 1173113987: return bem_classPathGetDirect_0();
case -1861812622: return bem_typeEmitNameGet_0();
case 674241091: return bem_iteratorGet_0();
case 506313706: return bem_emitterGetDirect_0();
case 1733866514: return bem_typePathGet_0();
case -436452411: return bem_fullEmitNameGet_0();
case 144701447: return bem_typeEmitNameGetDirect_0();
case 2007801397: return bem_classDirGetDirect_0();
case -538312537: return bem_fieldIteratorGet_0();
case 2141382986: return bem_classPathGet_0();
case 1120458206: return bem_libNameGetDirect_0();
case 241856681: return bem_typePathGetDirect_0();
case 1250893833: return bem_emitPathGetDirect_0();
case -312557248: return bem_copy_0();
case 845177749: return bem_nameSpaceGetDirect_0();
case -2054180438: return bem_tagGet_0();
case -740958985: return bem_echo_0();
case 1536894185: return bem_synPathGet_0();
case -1159042326: return bem_npGet_0();
case -68548270: return bem_nameSpaceGet_0();
case 1544079043: return bem_many_0();
case -904008064: return bem_serializationIteratorGet_0();
case -2061299989: return bem_fullEmitNameGetDirect_0();
case -2000869502: return bem_deserializeClassNameGet_0();
case -1345920383: return bem_serializeToString_0();
case -1370488335: return bem_toString_0();
case -905609052: return bem_libNameGet_0();
case 609467946: return bem_synPathGetDirect_0();
case -1852066203: return bem_emitterGet_0();
case 1921834118: return bem_sourceFileNameGet_0();
case 1766858631: return bem_emitNameGet_0();
case -898304671: return bem_fieldNamesGet_0();
case -1823294951: return bem_emitNameGetDirect_0();
case -1836675075: return bem_hashGet_0();
case 193069652: return bem_emitPathGet_0();
case -1463210484: return bem_new_0();
case 410834870: return bem_classDirGet_0();
case 2077899298: return bem_print_0();
case -1223303034: return bem_serializeContents_0();
case 1144594612: return bem_toAny_0();
case -93449420: return bem_once_0();
case 1316670529: return bem_classNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1910409322: return bem_libNameSet_1(bevd_0);
case -1755509471: return bem_otherClass_1(bevd_0);
case 1411392795: return bem_undefined_1(bevd_0);
case 1363791972: return bem_emitNameSet_1(bevd_0);
case 1169327234: return bem_classDirSet_1(bevd_0);
case -1086398098: return bem_defined_1(bevd_0);
case -124226052: return bem_typeEmitNameSet_1(bevd_0);
case -588775114: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 810440740: return bem_typePathSet_1(bevd_0);
case 942435111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 532034178: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1120344169: return bem_def_1(bevd_0);
case 227582862: return bem_fullEmitNameSet_1(bevd_0);
case 1136905977: return bem_undef_1(bevd_0);
case 1636832437: return bem_synPathSet_1(bevd_0);
case 380263496: return bem_typePathSetDirect_1(bevd_0);
case 1893585148: return bem_sameType_1(bevd_0);
case -640296056: return bem_notEquals_1(bevd_0);
case 1305486032: return bem_equals_1(bevd_0);
case -1456610015: return bem_classPathSet_1(bevd_0);
case -1789317501: return bem_synPathSetDirect_1(bevd_0);
case -362710625: return bem_npSetDirect_1(bevd_0);
case -2021410028: return bem_classPathSetDirect_1(bevd_0);
case -1306816572: return bem_emitPathSet_1(bevd_0);
case 1254749217: return bem_fullEmitNameSetDirect_1(bevd_0);
case -1747337072: return bem_classDirSetDirect_1(bevd_0);
case -227789211: return bem_copyTo_1(bevd_0);
case 928449607: return bem_typeEmitNameSetDirect_1(bevd_0);
case 675409179: return bem_sameObject_1(bevd_0);
case 370753869: return bem_nameSpaceSet_1(bevd_0);
case 1761949929: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1801531052: return bem_emitPathSetDirect_1(bevd_0);
case -257057695: return bem_otherType_1(bevd_0);
case 21235347: return bem_emitNameSetDirect_1(bevd_0);
case -488080037: return bem_emitterSet_1(bevd_0);
case -430269689: return bem_nameSpaceSetDirect_1(bevd_0);
case -1308897008: return bem_emitterSetDirect_1(bevd_0);
case -164720496: return bem_sameClass_1(bevd_0);
case 640683329: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 7609245: return bem_npSet_1(bevd_0);
case -511836069: return bem_libNameSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -882013396: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 265265077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1327331293: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -305196806: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 341335680: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2006332895: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1214675142: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 952297214: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildClassConfig();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
