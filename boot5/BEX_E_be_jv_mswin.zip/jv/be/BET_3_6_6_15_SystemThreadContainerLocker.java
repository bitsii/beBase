package be;
public class BET_3_6_6_15_SystemThreadContainerLocker extends BETS_Object {
public BET_3_6_6_15_SystemThreadContainerLocker() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "contains_1", "contains_2", "get_0", "get_1", "getAndClear_1", "get_2", "addValue_1", "putReturn_1", "put_1", "putReturn_2", "put_2", "testAndPut_3", "getSet_0", "getMap_0", "getMap_1", "putIfAbsent_2", "getOrPut_2", "put_3", "remove_1", "remove_2", "lengthGet_0", "isEmptyGet_0", "copyContainer_0", "clear_0", "close_0", "lockGet_0", "lockSet_1", "containerGet_0", "containerSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "lock", "container" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
}
