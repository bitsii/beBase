package be;
/* IO:File: source/base/Functions.be */
public final class BEC_2_8_6_FunctionMapper extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_FunctionMapper() { }
private static byte[] becc_BEC_2_8_6_FunctionMapper_clname = {0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x3A,0x4D,0x61,0x70,0x70,0x65,0x72};
private static byte[] becc_BEC_2_8_6_FunctionMapper_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_inst;
public BEC_2_8_6_FunctionMapper bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapCopy_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_input.bemd_0(901060004);
bevt_0_tmpany_phold = bem_map_2(bevt_1_tmpany_phold, beva_action);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_map_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemObject beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_input.bemd_0(-612311095);
bem_mapIterator_2(bevt_0_tmpany_phold, (BEC_2_6_6_SystemMethod) beva_action );
return beva_input;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_mapIterator_2(BEC_2_6_6_SystemObject beva_iter, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[2];
while (true)
 /* Line: 24 */ {
bevt_0_tmpany_phold = beva_iter.bemd_0(1044268871);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 24 */ {
bevt_2_tmpany_phold = beva_iter.bemd_0(-1274688402);
bevd_x[0] = bevt_2_tmpany_phold;
bevt_1_tmpany_phold = beva_action.bem_forwardCall_2(new BEC_2_4_6_TextString("apply".getBytes("UTF-8")), (new BEC_2_9_4_ContainerList(bevd_x, 1)).bem_copy_0());
beva_iter.bemd_1(2989800, bevt_1_tmpany_phold);
} /* Line: 25 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 15, 15, 19, 19, 20, 24, 25, 25, 25};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 23, 24, 25, 34, 36, 37, 39};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 15 17
copy 0 15 17
assign 1 15 18
map 2 15 18
return 1 15 19
assign 1 19 23
iteratorGet 0 19 23
mapIterator 2 19 24
return 1 20 25
assign 1 24 34
hasNextGet 0 24 34
assign 1 25 36
nextGet 0 25 36
assign 1 25 37
apply 1 25 37
currentSet 1 25 39
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 627086221: return bem_once_0();
case -1194864649: return bem_toString_0();
case -570363758: return bem_serializationIteratorGet_0();
case 730619711: return bem_many_0();
case 305137971: return bem_classNameGet_0();
case 436412028: return bem_sourceFileNameGet_0();
case 1359373450: return bem_echo_0();
case 1087786397: return bem_deserializeClassNameGet_0();
case 901060004: return bem_copy_0();
case -1550372712: return bem_serializeToString_0();
case 1234289396: return bem_tagGet_0();
case -1601492406: return bem_new_0();
case -612311095: return bem_iteratorGet_0();
case 741511465: return bem_print_0();
case -1997449793: return bem_default_0();
case -961535531: return bem_hashGet_0();
case -1988392847: return bem_fieldIteratorGet_0();
case 144613256: return bem_serializeContents_0();
case 1278732754: return bem_create_0();
case 1387595522: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 661372330: return bem_equals_1(bevd_0);
case -1903482804: return bem_otherClass_1(bevd_0);
case -1568064603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1633632376: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -309742024: return bem_def_1(bevd_0);
case -1001249520: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1067421305: return bem_notEquals_1(bevd_0);
case 266931166: return bem_undef_1(bevd_0);
case -596533003: return bem_otherType_1(bevd_0);
case 1717289899: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1718194680: return bem_undefined_1(bevd_0);
case -2049241562: return bem_sameObject_1(bevd_0);
case 457153382: return bem_copyTo_1(bevd_0);
case 1420318580: return bem_sameType_1(bevd_0);
case -686450804: return bem_defined_1(bevd_0);
case -1023168427: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1461540614: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513720300: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1831287605: return bem_mapIterator_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case 1924582691: return bem_map_2(bevd_0, bevd_1);
case 224164494: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1761291710: return bem_mapCopy_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case -2129126272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88269440: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -366737409: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -666768572: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_FunctionMapper_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_8_6_FunctionMapper_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_FunctionMapper();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst = (BEC_2_8_6_FunctionMapper) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst;
}
}
