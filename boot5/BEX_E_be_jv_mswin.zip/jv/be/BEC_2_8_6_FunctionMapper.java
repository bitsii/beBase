package be;
/* IO:File: source/base/Functions.be */
public final class BEC_2_8_6_FunctionMapper extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_FunctionMapper() { }
private static byte[] becc_BEC_2_8_6_FunctionMapper_clname = {0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x3A,0x4D,0x61,0x70,0x70,0x65,0x72};
private static byte[] becc_BEC_2_8_6_FunctionMapper_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_inst;

public static BET_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_type;

public BEC_2_8_6_FunctionMapper bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapCopy_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = beva_input.bemd_0(-1508036637);
bevt_0_ta_ph = bem_map_2(bevt_1_ta_ph, beva_action);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_map_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemObject beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_input.bemd_0(38127485);
bem_mapIterator_2(bevt_0_ta_ph, (BEC_2_6_6_SystemMethod) beva_action );
return beva_input;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_mapIterator_2(BEC_2_6_6_SystemObject beva_iter, BEC_2_6_6_SystemMethod beva_action) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[2];
while (true)
/* Line: 23*/ {
bevt_0_ta_ph = beva_iter.bemd_0(1757263953);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 23*/ {
bevt_2_ta_ph = beva_iter.bemd_0(1982151412);
bevd_x[0] = bevt_2_ta_ph;
bevt_1_ta_ph = beva_action.bem_forwardCall_2(new BEC_2_4_6_TextString("apply".getBytes("UTF-8")), (new BEC_2_9_4_ContainerList(bevd_x, 1)).bem_copy_0());
beva_iter.bemd_1(400909945, bevt_1_ta_ph);
} /* Line: 24*/
 else /* Line: 23*/ {
break;
} /* Line: 23*/
} /* Line: 23*/
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {14, 14, 14, 18, 18, 19, 23, 24, 24, 24};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 22, 26, 27, 28, 37, 39, 40, 42};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 14 20
copy 0 14 20
assign 1 14 21
map 2 14 21
return 1 14 22
assign 1 18 26
iteratorGet 0 18 26
mapIterator 2 18 27
return 1 19 28
assign 1 23 37
hasNextGet 0 23 37
assign 1 24 39
nextGet 0 24 39
assign 1 24 40
apply 1 24 40
currentSet 1 24 42
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 38127485: return bem_iteratorGet_0();
case 854710191: return bem_create_0();
case 636345: return bem_print_0();
case 2061432375: return bem_tagGet_0();
case -1849826772: return bem_default_0();
case 1847639727: return bem_new_0();
case 793589441: return bem_classNameGet_0();
case -1331374769: return bem_toString_0();
case -1818293830: return bem_fieldNamesGet_0();
case -1508036637: return bem_copy_0();
case -22788464: return bem_hashGet_0();
case -593469656: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -502376443: return bem_equals_1(bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1859069410: return bem_map_2(bevd_0, bevd_1);
case -1607844348: return bem_mapIterator_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1883181662: return bem_mapCopy_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_FunctionMapper_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_8_6_FunctionMapper_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_FunctionMapper();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst = (BEC_2_8_6_FunctionMapper) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_type;
}
}
