package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 871 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 873 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 876 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 882 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-1711091481, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 884 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 887 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 894 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-1542627669, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 896 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 899 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 906 */ {
bevl_r = bevp_container.bemd_0(1910877822);
bevp_lock.bem_unlock_0();
} /* Line: 908 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 911 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 918 */ {
bevl_r = bevp_container.bemd_1(-1364853423, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 920 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 923 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 930 */ {
bevl_r = bevp_container.bemd_1(-1364853423, beva_key);
bevp_container.bemd_1(164156228, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 933 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 936 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 943 */ {
bevl_r = bevp_container.bemd_2(-145914506, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 945 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 948 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 955 */ {
bevp_container.bemd_1(-589022088, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 957 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 960 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 966 */ {
bevl_r = bevp_container.bemd_1(-1134659376, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 968 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 971 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 978 */ {
bevp_container.bemd_1(-1134659376, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 980 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 983 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevl_r = bevp_container.bemd_2(1922480642, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1001 */ {
bevp_container.bemd_2(1922480642, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1003 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1006 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1012 */ {
bevl_rc = bevp_container.bemd_3(1999231684, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1014 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1017 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSet_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1024 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-237700715);
bevp_lock.bem_unlock_0();
} /* Line: 1026 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1029 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1036 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(632871398);
bevp_lock.bem_unlock_0();
} /* Line: 1038 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1041 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1048 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(477809776, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 1050 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1053 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1060 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1711091481, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1061 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 1062 */
 else  /* Line: 1063 */ {
bevp_container.bemd_2(1922480642, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 1065 */
bevp_lock.bem_unlock_0();
} /* Line: 1067 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1070 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1077 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1711091481, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1078 */ {
bevl_result = bevp_container.bemd_1(-1364853423, beva_key);
} /* Line: 1079 */
 else  /* Line: 1080 */ {
bevp_container.bemd_2(1922480642, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1082 */
bevp_lock.bem_unlock_0();
} /* Line: 1084 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1087 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1094 */ {
bevp_container.bemd_3(-1615970541, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1096 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1099 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1105 */ {
bevl_r = bevp_container.bemd_1(164156228, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1107 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1110 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1117 */ {
bevl_r = bevp_container.bemd_2(-1028765799, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1119 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1122 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1129 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(278720698);
bevp_lock.bem_unlock_0();
} /* Line: 1131 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1134 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1141 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-921815851);
bevp_lock.bem_unlock_0();
} /* Line: 1143 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1146 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1153 */ {
bevl_r = bevp_container.bemd_0(-862155694);
bevp_lock.bem_unlock_0();
} /* Line: 1155 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1158 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1165 */ {
bevp_container.bemd_0(1854534437);
bevp_lock.bem_unlock_0();
} /* Line: 1167 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1170 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1176 */ {
bevp_container.bemd_0(-338991492);
bevp_lock.bem_unlock_0();
} /* Line: 1178 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1181 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {867, 870, 872, 873, 875, 876, 881, 883, 884, 886, 887, 889, 893, 895, 896, 898, 899, 901, 905, 907, 908, 910, 911, 913, 917, 919, 920, 922, 923, 925, 929, 931, 932, 933, 935, 936, 938, 942, 944, 945, 947, 948, 950, 954, 956, 957, 959, 960, 965, 967, 968, 970, 971, 973, 977, 979, 980, 982, 983, 988, 990, 991, 993, 994, 996, 1000, 1002, 1003, 1005, 1006, 1011, 1013, 1014, 1016, 1017, 1019, 1023, 1025, 1026, 1028, 1029, 1031, 1035, 1037, 1038, 1040, 1041, 1043, 1047, 1049, 1050, 1052, 1053, 1055, 1059, 1061, 1062, 1064, 1065, 1067, 1069, 1070, 1072, 1076, 1078, 1079, 1081, 1082, 1084, 1086, 1087, 1089, 1093, 1095, 1096, 1098, 1099, 1104, 1106, 1107, 1109, 1110, 1112, 1116, 1118, 1119, 1121, 1122, 1124, 1128, 1130, 1131, 1133, 1134, 1136, 1140, 1142, 1143, 1145, 1146, 1148, 1152, 1154, 1155, 1157, 1158, 1160, 1164, 1166, 1167, 1169, 1170, 1175, 1177, 1178, 1180, 1181, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 241, 243, 244, 248, 249, 251, 257, 259, 261, 264, 265, 267, 271, 272, 274, 280, 282, 284, 287, 288, 290, 294, 295, 297, 301, 303, 304, 308, 309, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 376, 378, 379, 383, 384, 386, 390, 392, 393, 397, 398, 404, 406, 407, 411, 412, 417, 420, 423, 427, 431, 434, 437, 441};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 867 17
new 0 867 17
lock 0 870 18
assign 1 872 20
unlock 0 873 21
unlock 0 875 25
throw 1 876 26
lock 0 881 33
assign 1 883 35
has 1 883 35
unlock 0 884 36
unlock 0 886 40
throw 1 887 41
return 1 889 43
lock 0 893 48
assign 1 895 50
has 2 895 50
unlock 0 896 51
unlock 0 898 55
throw 1 899 56
return 1 901 58
lock 0 905 63
assign 1 907 65
get 0 907 65
unlock 0 908 66
unlock 0 910 70
throw 1 911 71
return 1 913 73
lock 0 917 78
assign 1 919 80
get 1 919 80
unlock 0 920 81
unlock 0 922 85
throw 1 923 86
return 1 925 88
lock 0 929 93
assign 1 931 95
get 1 931 95
delete 1 932 96
unlock 0 933 97
unlock 0 935 101
throw 1 936 102
return 1 938 104
lock 0 942 109
assign 1 944 111
get 2 944 111
unlock 0 945 112
unlock 0 947 116
throw 1 948 117
return 1 950 119
lock 0 954 123
addValue 1 956 125
unlock 0 957 126
unlock 0 959 130
throw 1 960 131
lock 0 965 138
assign 1 967 140
put 1 967 140
unlock 0 968 141
unlock 0 970 145
throw 1 971 146
return 1 973 148
lock 0 977 152
put 1 979 154
unlock 0 980 155
unlock 0 982 159
throw 1 983 160
lock 0 988 167
assign 1 990 169
put 2 990 169
unlock 0 991 170
unlock 0 993 174
throw 1 994 175
return 1 996 177
lock 0 1000 181
put 2 1002 183
unlock 0 1003 184
unlock 0 1005 188
throw 1 1006 189
lock 0 1011 196
assign 1 1013 198
testAndPut 3 1013 198
unlock 0 1014 199
unlock 0 1016 203
throw 1 1017 204
return 1 1019 206
lock 0 1023 211
assign 1 1025 213
getSet 0 1025 213
unlock 0 1026 214
unlock 0 1028 218
throw 1 1029 219
return 1 1031 221
lock 0 1035 226
assign 1 1037 228
getMap 0 1037 228
unlock 0 1038 229
unlock 0 1040 233
throw 1 1041 234
return 1 1043 236
lock 0 1047 241
assign 1 1049 243
getMap 1 1049 243
unlock 0 1050 244
unlock 0 1052 248
throw 1 1053 249
return 1 1055 251
lock 0 1059 257
assign 1 1061 259
has 1 1061 259
assign 1 1062 261
new 0 1062 261
put 2 1064 264
assign 1 1065 265
new 0 1065 265
unlock 0 1067 267
unlock 0 1069 271
throw 1 1070 272
return 1 1072 274
lock 0 1076 280
assign 1 1078 282
has 1 1078 282
assign 1 1079 284
get 1 1079 284
put 2 1081 287
assign 1 1082 288
unlock 0 1084 290
unlock 0 1086 294
throw 1 1087 295
return 1 1089 297
lock 0 1093 301
put 3 1095 303
unlock 0 1096 304
unlock 0 1098 308
throw 1 1099 309
lock 0 1104 316
assign 1 1106 318
delete 1 1106 318
unlock 0 1107 319
unlock 0 1109 323
throw 1 1110 324
return 1 1112 326
lock 0 1116 331
assign 1 1118 333
delete 2 1118 333
unlock 0 1119 334
unlock 0 1121 338
throw 1 1122 339
return 1 1124 341
lock 0 1128 346
assign 1 1130 348
sizeGet 0 1130 348
unlock 0 1131 349
unlock 0 1133 353
throw 1 1134 354
return 1 1136 356
lock 0 1140 361
assign 1 1142 363
isEmptyGet 0 1142 363
unlock 0 1143 364
unlock 0 1145 368
throw 1 1146 369
return 1 1148 371
lock 0 1152 376
assign 1 1154 378
copy 0 1154 378
unlock 0 1155 379
unlock 0 1157 383
throw 1 1158 384
return 1 1160 386
lock 0 1164 390
clear 0 1166 392
unlock 0 1167 393
unlock 0 1169 397
throw 1 1170 398
lock 0 1175 404
close 0 1177 406
unlock 0 1178 407
unlock 0 1180 411
throw 1 1181 412
return 1 0 417
return 1 0 420
assign 1 0 423
assign 1 0 427
return 1 0 431
return 1 0 434
assign 1 0 437
assign 1 0 441
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -921815851: return bem_isEmptyGet_0();
case -1515347213: return bem_hashGet_0();
case -677030259: return bem_copyContainer_0();
case -442242561: return bem_lockGetDirect_0();
case 507602572: return bem_once_0();
case 631342118: return bem_deserializeClassNameGet_0();
case -862155694: return bem_copy_0();
case -1370019545: return bem_serializeToString_0();
case -647428547: return bem_fieldIteratorGet_0();
case 1379664484: return bem_toAny_0();
case -688295882: return bem_tagGet_0();
case -237700715: return bem_getSet_0();
case 1854534437: return bem_clear_0();
case -760305947: return bem_containerGetDirect_0();
case -1814630541: return bem_classNameGet_0();
case 562477328: return bem_serializationIteratorGet_0();
case -338991492: return bem_close_0();
case 886168102: return bem_many_0();
case 899271096: return bem_new_0();
case 278720698: return bem_sizeGet_0();
case -542639344: return bem_toString_0();
case 1884909798: return bem_create_0();
case -1906660880: return bem_print_0();
case -1639090317: return bem_lockGet_0();
case 632871398: return bem_getMap_0();
case 197504093: return bem_containerGet_0();
case -973290132: return bem_iteratorGet_0();
case 1688744619: return bem_serializeContents_0();
case -1067099981: return bem_fieldNamesGet_0();
case -21012660: return bem_sourceFileNameGet_0();
case 1910877822: return bem_get_0();
case -1648627766: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2120701530: return bem_equals_1(bevd_0);
case 1889384701: return bem_getAndClear_1(bevd_0);
case 161743964: return bem_containerSet_1(bevd_0);
case -241199401: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1715866358: return bem_notEquals_1(bevd_0);
case -1364853423: return bem_get_1(bevd_0);
case -345992202: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 216018244: return bem_copyTo_1(bevd_0);
case -1711091481: return bem_has_1(bevd_0);
case 164156228: return bem_delete_1(bevd_0);
case -734789597: return bem_undefined_1(bevd_0);
case 1116925492: return bem_sameType_1(bevd_0);
case -1987778332: return bem_containerSetDirect_1(bevd_0);
case -589022088: return bem_addValue_1(bevd_0);
case 1232632175: return bem_lockSetDirect_1(bevd_0);
case -1028156837: return bem_new_1(bevd_0);
case 2094021784: return bem_lockSet_1(bevd_0);
case 477809776: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1280914604: return bem_otherClass_1(bevd_0);
case 1744917313: return bem_defined_1(bevd_0);
case 1142143738: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1879978064: return bem_putReturn_1(bevd_0);
case 898034411: return bem_sameClass_1(bevd_0);
case 2001300007: return bem_sameObject_1(bevd_0);
case -914794223: return bem_undef_1(bevd_0);
case -1134659376: return bem_put_1(bevd_0);
case 1402754792: return bem_def_1(bevd_0);
case 1820085236: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1349849963: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1028765799: return bem_delete_2(bevd_0, bevd_1);
case 1506940745: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -916940628: return bem_putReturn_2(bevd_0, bevd_1);
case -2011759429: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -494323920: return bem_getOrPut_2(bevd_0, bevd_1);
case 1630879145: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1542627669: return bem_has_2(bevd_0, bevd_1);
case -603725496: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1922480642: return bem_put_2(bevd_0, bevd_1);
case -2028721987: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1784313817: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1485133109: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1936821493: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -145914506: return bem_get_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1615970541: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 1999231684: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
