package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 794 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 796 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 799 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 805 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-1819804128, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 807 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 810 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 817 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(1772226612, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 819 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 822 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 829 */ {
bevl_r = bevp_container.bemd_0(1465633438);
bevp_lock.bem_unlock_0();
} /* Line: 831 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 834 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 841 */ {
bevl_r = bevp_container.bemd_1(1918557419, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 843 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 846 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 853 */ {
bevl_r = bevp_container.bemd_1(1918557419, beva_key);
bevp_container.bemd_1(-51670039, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 856 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 859 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 866 */ {
bevl_r = bevp_container.bemd_2(1900193567, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 868 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 871 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 878 */ {
bevp_container.bemd_1(-828035892, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 880 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 883 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 889 */ {
bevl_r = bevp_container.bemd_1(-1081154514, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 891 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 894 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 901 */ {
bevp_container.bemd_1(-1081154514, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 903 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 906 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 912 */ {
bevl_r = bevp_container.bemd_2(-1807009954, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 914 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 917 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 924 */ {
bevp_container.bemd_2(-1807009954, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 926 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 929 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 935 */ {
bevl_rc = bevp_container.bemd_3(-788652783, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 937 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 940 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 947 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(514562690);
bevp_lock.bem_unlock_0();
} /* Line: 949 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 952 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 959 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-939771635, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 961 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 964 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 971 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1819804128, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 972 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 973 */
 else  /* Line: 974 */ {
bevp_container.bemd_2(-1807009954, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 976 */
bevp_lock.bem_unlock_0();
} /* Line: 978 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 981 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 988 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1819804128, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 989 */ {
bevl_result = bevp_container.bemd_1(1918557419, beva_key);
} /* Line: 990 */
 else  /* Line: 991 */ {
bevp_container.bemd_2(-1807009954, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 993 */
bevp_lock.bem_unlock_0();
} /* Line: 995 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 998 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1005 */ {
bevp_container.bemd_3(1442970249, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1007 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1010 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1016 */ {
bevl_r = bevp_container.bemd_1(-51670039, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1018 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1021 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1028 */ {
bevl_r = bevp_container.bemd_2(342715085, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1030 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1033 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1040 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-1071812965);
bevp_lock.bem_unlock_0();
} /* Line: 1042 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1045 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1052 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-42976430);
bevp_lock.bem_unlock_0();
} /* Line: 1054 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1057 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1064 */ {
bevl_r = bevp_container.bemd_0(-2074204580);
bevp_lock.bem_unlock_0();
} /* Line: 1066 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1069 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1076 */ {
bevp_container.bemd_0(1487653446);
bevp_lock.bem_unlock_0();
} /* Line: 1078 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1081 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1087 */ {
bevp_container.bemd_0(775617472);
bevp_lock.bem_unlock_0();
} /* Line: 1089 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1092 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public final BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_containerGetDirect_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {790, 793, 795, 796, 798, 799, 804, 806, 807, 809, 810, 812, 816, 818, 819, 821, 822, 824, 828, 830, 831, 833, 834, 836, 840, 842, 843, 845, 846, 848, 852, 854, 855, 856, 858, 859, 861, 865, 867, 868, 870, 871, 873, 877, 879, 880, 882, 883, 888, 890, 891, 893, 894, 896, 900, 902, 903, 905, 906, 911, 913, 914, 916, 917, 919, 923, 925, 926, 928, 929, 934, 936, 937, 939, 940, 942, 946, 948, 949, 951, 952, 954, 958, 960, 961, 963, 964, 966, 970, 972, 973, 975, 976, 978, 980, 981, 983, 987, 989, 990, 992, 993, 995, 997, 998, 1000, 1004, 1006, 1007, 1009, 1010, 1015, 1017, 1018, 1020, 1021, 1023, 1027, 1029, 1030, 1032, 1033, 1035, 1039, 1041, 1042, 1044, 1045, 1047, 1051, 1053, 1054, 1056, 1057, 1059, 1063, 1065, 1066, 1068, 1069, 1071, 1075, 1077, 1078, 1080, 1081, 1086, 1088, 1089, 1091, 1092, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 20, 21, 25, 26, 33, 35, 36, 40, 41, 43, 48, 50, 51, 55, 56, 58, 63, 65, 66, 70, 71, 73, 78, 80, 81, 85, 86, 88, 93, 95, 96, 97, 101, 102, 104, 109, 111, 112, 116, 117, 119, 123, 125, 126, 130, 131, 138, 140, 141, 145, 146, 148, 152, 154, 155, 159, 160, 167, 169, 170, 174, 175, 177, 181, 183, 184, 188, 189, 196, 198, 199, 203, 204, 206, 211, 213, 214, 218, 219, 221, 226, 228, 229, 233, 234, 236, 242, 244, 246, 249, 250, 252, 256, 257, 259, 265, 267, 269, 272, 273, 275, 279, 280, 282, 286, 288, 289, 293, 294, 301, 303, 304, 308, 309, 311, 316, 318, 319, 323, 324, 326, 331, 333, 334, 338, 339, 341, 346, 348, 349, 353, 354, 356, 361, 363, 364, 368, 369, 371, 375, 377, 378, 382, 383, 389, 391, 392, 396, 397, 402, 405, 408, 412, 416, 419, 422, 426};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 790 17
new 0 790 17
lock 0 793 18
assign 1 795 20
unlock 0 796 21
unlock 0 798 25
throw 1 799 26
lock 0 804 33
assign 1 806 35
has 1 806 35
unlock 0 807 36
unlock 0 809 40
throw 1 810 41
return 1 812 43
lock 0 816 48
assign 1 818 50
has 2 818 50
unlock 0 819 51
unlock 0 821 55
throw 1 822 56
return 1 824 58
lock 0 828 63
assign 1 830 65
get 0 830 65
unlock 0 831 66
unlock 0 833 70
throw 1 834 71
return 1 836 73
lock 0 840 78
assign 1 842 80
get 1 842 80
unlock 0 843 81
unlock 0 845 85
throw 1 846 86
return 1 848 88
lock 0 852 93
assign 1 854 95
get 1 854 95
delete 1 855 96
unlock 0 856 97
unlock 0 858 101
throw 1 859 102
return 1 861 104
lock 0 865 109
assign 1 867 111
get 2 867 111
unlock 0 868 112
unlock 0 870 116
throw 1 871 117
return 1 873 119
lock 0 877 123
addValue 1 879 125
unlock 0 880 126
unlock 0 882 130
throw 1 883 131
lock 0 888 138
assign 1 890 140
put 1 890 140
unlock 0 891 141
unlock 0 893 145
throw 1 894 146
return 1 896 148
lock 0 900 152
put 1 902 154
unlock 0 903 155
unlock 0 905 159
throw 1 906 160
lock 0 911 167
assign 1 913 169
put 2 913 169
unlock 0 914 170
unlock 0 916 174
throw 1 917 175
return 1 919 177
lock 0 923 181
put 2 925 183
unlock 0 926 184
unlock 0 928 188
throw 1 929 189
lock 0 934 196
assign 1 936 198
testAndPut 3 936 198
unlock 0 937 199
unlock 0 939 203
throw 1 940 204
return 1 942 206
lock 0 946 211
assign 1 948 213
getMap 0 948 213
unlock 0 949 214
unlock 0 951 218
throw 1 952 219
return 1 954 221
lock 0 958 226
assign 1 960 228
getMap 1 960 228
unlock 0 961 229
unlock 0 963 233
throw 1 964 234
return 1 966 236
lock 0 970 242
assign 1 972 244
has 1 972 244
assign 1 973 246
new 0 973 246
put 2 975 249
assign 1 976 250
new 0 976 250
unlock 0 978 252
unlock 0 980 256
throw 1 981 257
return 1 983 259
lock 0 987 265
assign 1 989 267
has 1 989 267
assign 1 990 269
get 1 990 269
put 2 992 272
assign 1 993 273
unlock 0 995 275
unlock 0 997 279
throw 1 998 280
return 1 1000 282
lock 0 1004 286
put 3 1006 288
unlock 0 1007 289
unlock 0 1009 293
throw 1 1010 294
lock 0 1015 301
assign 1 1017 303
delete 1 1017 303
unlock 0 1018 304
unlock 0 1020 308
throw 1 1021 309
return 1 1023 311
lock 0 1027 316
assign 1 1029 318
delete 2 1029 318
unlock 0 1030 319
unlock 0 1032 323
throw 1 1033 324
return 1 1035 326
lock 0 1039 331
assign 1 1041 333
sizeGet 0 1041 333
unlock 0 1042 334
unlock 0 1044 338
throw 1 1045 339
return 1 1047 341
lock 0 1051 346
assign 1 1053 348
isEmptyGet 0 1053 348
unlock 0 1054 349
unlock 0 1056 353
throw 1 1057 354
return 1 1059 356
lock 0 1063 361
assign 1 1065 363
copy 0 1065 363
unlock 0 1066 364
unlock 0 1068 368
throw 1 1069 369
return 1 1071 371
lock 0 1075 375
clear 0 1077 377
unlock 0 1078 378
unlock 0 1080 382
throw 1 1081 383
lock 0 1086 389
close 0 1088 391
unlock 0 1089 392
unlock 0 1091 396
throw 1 1092 397
return 1 0 402
return 1 0 405
assign 1 0 408
assign 1 0 412
return 1 0 416
return 1 0 419
assign 1 0 422
assign 1 0 426
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -405092541: return bem_copyContainer_0();
case -1920210020: return bem_once_0();
case -670803938: return bem_sourceFileNameGet_0();
case -1768205182: return bem_serializationIteratorGet_0();
case 1993705736: return bem_serializeContents_0();
case -878171847: return bem_lockGet_0();
case -212193921: return bem_tagGet_0();
case -461072455: return bem_toString_0();
case -41333960: return bem_deserializeClassNameGet_0();
case 514562690: return bem_getMap_0();
case 577093211: return bem_many_0();
case 1465633438: return bem_get_0();
case -2074204580: return bem_copy_0();
case -1425389541: return bem_new_0();
case 1821082307: return bem_print_0();
case 775617472: return bem_close_0();
case -1103678979: return bem_lockGetDirect_0();
case -42976430: return bem_isEmptyGet_0();
case -2107653327: return bem_fieldIteratorGet_0();
case -1239099963: return bem_containerGetDirect_0();
case -511250160: return bem_fieldNamesGet_0();
case 1800445194: return bem_create_0();
case -102149480: return bem_serializeToString_0();
case 296622746: return bem_classNameGet_0();
case -19384722: return bem_toAny_0();
case -1071812965: return bem_sizeGet_0();
case 1482277663: return bem_echo_0();
case 361790008: return bem_hashGet_0();
case -900282026: return bem_containerGet_0();
case 1487653446: return bem_clear_0();
case -314408008: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2110248602: return bem_undefined_1(bevd_0);
case 1458366559: return bem_containerSet_1(bevd_0);
case -1398560259: return bem_otherType_1(bevd_0);
case 219377084: return bem_lockSet_1(bevd_0);
case -1463366211: return bem_def_1(bevd_0);
case -320284120: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -155631619: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1918557419: return bem_get_1(bevd_0);
case -1819804128: return bem_has_1(bevd_0);
case -939771635: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -676548815: return bem_undef_1(bevd_0);
case -158683449: return bem_getAndClear_1(bevd_0);
case -828035892: return bem_addValue_1(bevd_0);
case -1192710672: return bem_equals_1(bevd_0);
case 242004544: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1908940247: return bem_otherClass_1(bevd_0);
case -1272397031: return bem_sameClass_1(bevd_0);
case -1161197989: return bem_sameType_1(bevd_0);
case 1389268037: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1026739914: return bem_defined_1(bevd_0);
case 764373340: return bem_copyTo_1(bevd_0);
case -1987055831: return bem_notEquals_1(bevd_0);
case 726972503: return bem_new_1(bevd_0);
case -51670039: return bem_delete_1(bevd_0);
case 499942082: return bem_lockSetDirect_1(bevd_0);
case -1081154514: return bem_put_1(bevd_0);
case 450918310: return bem_containerSetDirect_1(bevd_0);
case -1567535449: return bem_sameObject_1(bevd_0);
case 1362567826: return bem_putReturn_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 220461512: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1807009954: return bem_put_2(bevd_0, bevd_1);
case -1354452916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1773886690: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021501378: return bem_putReturn_2(bevd_0, bevd_1);
case 278898562: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -830320987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 764231776: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1900193567: return bem_get_2(bevd_0, bevd_1);
case 734303971: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -1362301077: return bem_getOrPut_2(bevd_0, bevd_1);
case -711906439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 342715085: return bem_delete_2(bevd_0, bevd_1);
case 1772226612: return bem_has_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -788652783: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case 1442970249: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
