package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_4_ContainerPair extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerPair() { }
private static byte[] becc_BEC_2_9_4_ContainerPair_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x50,0x61,0x69,0x72};
private static byte[] becc_BEC_2_9_4_ContainerPair_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_inst;

public static BET_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_type;

public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_6_6_SystemObject bevp_second;
public BEC_2_9_4_ContainerPair bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_new_2(BEC_2_6_6_SystemObject beva__first, BEC_2_6_6_SystemObject beva__second) throws Throwable {
bevp_first = beva__first;
bevp_second = beva__second;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGet_0() throws Throwable {
return bevp_second;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_secondSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_second = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {37, 38, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 22, 25, 29, 32};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 37 17
assign 1 38 18
return 1 0 22
assign 1 0 25
return 1 0 29
assign 1 0 32
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1394834757: return bem_new_0();
case 1900805838: return bem_iteratorGet_0();
case -953648774: return bem_create_0();
case -201610096: return bem_hashGet_0();
case -1310297232: return bem_secondGet_0();
case -1035398654: return bem_copy_0();
case 1679318778: return bem_toString_0();
case 2037179274: return bem_firstGet_0();
case -1550354971: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -313527528: return bem_print_1(bevd_0);
case -1715921186: return bem_def_1(bevd_0);
case 1706064170: return bem_firstSet_1(bevd_0);
case -1173110479: return bem_secondSet_1(bevd_0);
case -873014888: return bem_undef_1(bevd_0);
case -769543545: return bem_copyTo_1(bevd_0);
case 580052299: return bem_notEquals_1(bevd_0);
case 914891998: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1502429166: return bem_new_2(bevd_0, bevd_1);
case -222789624: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1703451725: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1657225406: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 979775573: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerPair_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_4_ContainerPair_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerPair();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst = (BEC_2_9_4_ContainerPair) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_type;
}
}
