package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitRewind extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_1, 11));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_2, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_3, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_6, 27));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_8, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_9, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_10 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_10, 17));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_11 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_11, 10));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_12 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_3_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_83_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_86_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevt_12_tmpany_phold = beva_node.bem_heldGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1859343223);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 349 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 349 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 349 */
 else  /* Line: 349 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 349 */ {
bevt_15_tmpany_phold = beva_node.bem_containerGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevt_20_tmpany_phold = beva_node.bem_containerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-126251885);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(-1386227183, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 351 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 351 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 351 */
 else  /* Line: 351 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 351 */ {
bevt_22_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 351 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 351 */
 else  /* Line: 351 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 351 */ {
bevt_26_tmpany_phold = beva_node.bem_containedGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_firstGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(1767414697);
bevt_27_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-1386227183, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 353 */ {
bevt_31_tmpany_phold = beva_node.bem_containedGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_firstGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-1566200462);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-1322133419);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 353 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 353 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 353 */
 else  /* Line: 353 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 353 */ {
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-1566200462);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_tmpany_phold.bemd_0(1431969603);
bevt_35_tmpany_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_lastGet_0();
bevt_39_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0;
bevt_40_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1;
bevt_38_tmpany_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpany_phold, bevt_40_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_lowerValue_0();
bevt_42_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_41_tmpany_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2;
bevl_fgin = bevt_36_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpany_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3;
bevt_45_tmpany_phold = bevl_fgin.bem_add_1(bevt_46_tmpany_phold);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_tmpany_phold.bem_get_1(bevt_45_tmpany_phold);
if (bevl_fgms == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 360 */ {
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_48_tmpany_phold.bemd_1(-926209529, bevl_fgin);
bevt_49_tmpany_phold = beva_node.bem_heldGet_0();
bevt_51_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4;
bevt_50_tmpany_phold = bevl_fgin.bem_add_1(bevt_51_tmpany_phold);
bevt_49_tmpany_phold.bemd_1(-1081780161, bevt_50_tmpany_phold);
} /* Line: 363 */
} /* Line: 360 */
} /* Line: 353 */
} /* Line: 351 */
bevt_53_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_tmpany_phold.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 368 */ {
bevp_inClass = beva_node;
bevt_55_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpany_phold.bemd_0(1431969603);
bevt_56_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpany_phold.bemd_0(-54618753);
} /* Line: 371 */
bevt_58_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_59_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 375 */
 else  /* Line: 373 */ {
bevt_61_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpany_phold.bevi_int == bevt_62_tmpany_phold.bevi_int) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 376 */ {
bevt_64_tmpany_phold = beva_node.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-762661635);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 376 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 376 */ {
bevt_66_tmpany_phold = beva_node.bem_heldGet_0();
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(-851335829);
bevt_67_tmpany_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(-426553489, bevt_65_tmpany_phold, bevt_67_tmpany_phold);
bevt_69_tmpany_phold = beva_node.bem_heldGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(-851335829);
bevl_ll = bevp_rmap.bemd_1(1362971262, bevt_68_tmpany_phold);
if (bevl_ll == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 379 */ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = beva_node.bem_heldGet_0();
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(-851335829);
bevp_rmap.bemd_2(-426553489, bevt_71_tmpany_phold, bevl_ll);
} /* Line: 381 */
bevl_ll.bemd_1(-1956247108, beva_node);
} /* Line: 383 */
 else  /* Line: 373 */ {
bevt_74_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_tmpany_phold.bevi_int == bevt_75_tmpany_phold.bevi_int) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_77_tmpany_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 384 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 384 */
 else  /* Line: 384 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 384 */ {
bevt_80_tmpany_phold = beva_node.bem_containerGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_containerGet_0();
if (bevt_79_tmpany_phold == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 384 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 384 */
 else  /* Line: 384 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 384 */ {
bevt_84_tmpany_phold = beva_node.bem_containerGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bem_containerGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_typenameGet_0();
bevt_85_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_tmpany_phold.bevi_int == bevt_85_tmpany_phold.bevi_int) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 384 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 384 */
 else  /* Line: 384 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 384 */ {
bem_processTmps_0();
} /* Line: 386 */
} /* Line: 373 */
} /* Line: 373 */
bevt_86_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpany_phold;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 400 */ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool) /* Line: 400 */ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(1242819172);
while (true)
 /* Line: 402 */ {
bevt_9_tmpany_phold = bevl_i.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 402 */ {
bevl_nv = bevl_i.bemd_0(-968892996);
bevt_11_tmpany_phold = bevl_nv.bemd_0(-1322133419);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-912093780);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 405 */ {
bevl_nvname = bevl_nv.bemd_0(-851335829);
bevl_ll = bevp_rmap.bemd_1(1362971262, bevl_nvname);
bevt_0_tmpany_loop = bevl_ll.bemd_0(-757699318);
while (true)
 /* Line: 410 */ {
bevt_12_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 410 */ {
bevl_k = bevt_0_tmpany_loop.bemd_0(-968892996);
bevt_13_tmpany_phold = bevl_k.bemd_0(1313933671);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_16_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1767414697);
bevt_17_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_1(-1386227183, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
 else  /* Line: 411 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_21_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-1566200462);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-126251885);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_4));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-1386227183, bevt_22_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
 else  /* Line: 411 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_26_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-491099350);
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(1767414697);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-1386227183, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
 else  /* Line: 411 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_28_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevl_tcall = bevt_28_tmpany_phold.bemd_0(-491099350);
bevl_targNp = null;
bevt_31_tmpany_phold = bevl_tcall.bemd_0(-1566200462);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(825133507);
if (bevt_30_tmpany_phold == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevt_32_tmpany_phold = bevl_tcall.bemd_0(-1566200462);
bevl_targNp = bevt_32_tmpany_phold.bemd_0(825133507);
} /* Line: 416 */
 else  /* Line: 417 */ {
bevt_33_tmpany_phold = bevl_tcall.bemd_0(-1783416586);
bevl_targ = bevt_33_tmpany_phold.bemd_0(2054607897);
bevt_35_tmpany_phold = bevl_targ.bemd_0(-1566200462);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(93569342);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 422 */ {
bevl_tany = bevl_targ.bemd_0(-1566200462);
} /* Line: 423 */
 else  /* Line: 424 */ {
bevt_37_tmpany_phold = bevp_inClassSyn.bemd_0(-170971854);
bevt_39_tmpany_phold = bevl_targ.bemd_0(-1566200462);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(-851335829);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(1362971262, bevt_38_tmpany_phold);
bevl_tany = bevt_36_tmpany_phold.bemd_0(-353668749);
} /* Line: 425 */
bevt_40_tmpany_phold = bevl_tany.bemd_0(-1322133419);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 428 */ {
bevl_targNp = bevl_tany.bemd_0(1431969603);
} /* Line: 429 */
} /* Line: 428 */
if (bevl_targNp == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_44_tmpany_phold = bevl_tcall.bemd_0(-1566200462);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(-851335829);
bevl_mtdc = bevt_42_tmpany_phold.bem_get_1(bevt_43_tmpany_phold);
if (bevl_mtdc == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 436 */ {
bevl_oany = bevl_mtdc.bemd_0(-1375973283);
if (bevl_oany == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevt_47_tmpany_phold = bevl_oany.bemd_0(-1322133419);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 439 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 439 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 439 */
 else  /* Line: 439 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 439 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_tmpany_phold = bevl_oany.bemd_0(-1524408288);
if (((BEC_2_5_4_LogicBool) bevt_48_tmpany_phold).bevi_bool) /* Line: 442 */ {
bevl_nv.bemd_1(-266688333, bevl_targNp);
} /* Line: 443 */
 else  /* Line: 444 */ {
bevt_49_tmpany_phold = bevl_oany.bemd_0(1431969603);
bevl_nv.bemd_1(-266688333, bevt_49_tmpany_phold);
} /* Line: 445 */
bevt_50_tmpany_phold = bevl_oany.bemd_0(-1322133419);
bevl_nv.bemd_1(-1710314751, bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bevp_inClass.bemd_0(-1566200462);
bevt_52_tmpany_phold = bevl_nv.bemd_0(1431969603);
bevt_51_tmpany_phold.bemd_1(1666038174, bevt_52_tmpany_phold);
bevt_55_tmpany_phold = bevl_nv.bemd_0(1431969603);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1452564531);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_1(-1386227183, bevt_56_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_53_tmpany_phold).bevi_bool) /* Line: 449 */ {
bevt_58_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5;
bevt_59_tmpany_phold = bevl_oany.bemd_0(-1524408288);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold.bem_print_0();
} /* Line: 449 */
} /* Line: 449 */
} /* Line: 439 */
 else  /* Line: 436 */ {
bevt_62_tmpany_phold = bevl_tcall.bemd_0(-1566200462);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-126251885);
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_7));
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_1(177273835, bevt_63_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 451 */ {
bevt_64_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_65_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_tmpany_phold.bem_get_1(bevt_65_tmpany_phold);
if (bevl_fcms == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_69_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_toString_0();
bevt_70_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7;
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_notEquals_1(bevt_70_tmpany_phold);
if (bevt_67_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 453 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 453 */
 else  /* Line: 453 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 453 */ {
bevt_71_tmpany_phold = bevl_tcall.bemd_0(-1566200462);
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_71_tmpany_phold.bemd_1(-455845304, bevt_72_tmpany_phold);
} /* Line: 454 */
 else  /* Line: 455 */ {
bevt_77_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8;
bevt_79_tmpany_phold = bevl_tcall.bemd_0(-1566200462);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-851335829);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_add_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9;
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_add_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = bevl_targNp.bemd_0(1452564531);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 456 */
} /* Line: 453 */
} /* Line: 436 */
} /* Line: 436 */
} /* Line: 432 */
 else  /* Line: 411 */ {
bevt_82_tmpany_phold = bevl_k.bemd_0(1313933671);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_85_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bemd_0(1767414697);
bevt_86_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_1(-1386227183, bevt_86_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_83_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_90_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(-1566200462);
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bemd_0(-126251885);
bevt_91_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_12));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bemd_1(-1386227183, bevt_91_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_95_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_0(-491099350);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(1767414697);
bevt_96_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(-1386227183, bevt_96_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_98_tmpany_phold = bevl_k.bemd_0(-1838234759);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_0(-491099350);
bevl_targ = bevt_97_tmpany_phold.bemd_0(-1566200462);
bevt_99_tmpany_phold = bevl_targ.bemd_0(-1322133419);
if (((BEC_2_5_4_LogicBool) bevt_99_tmpany_phold).bevi_bool) /* Line: 465 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_tmpany_phold = bevl_targ.bemd_0(-1322133419);
bevl_nv.bemd_1(-1710314751, bevt_100_tmpany_phold);
bevt_101_tmpany_phold = bevl_targ.bemd_0(1431969603);
bevl_nv.bemd_1(-266688333, bevt_101_tmpany_phold);
} /* Line: 470 */
} /* Line: 465 */
} /* Line: 411 */
} /* Line: 411 */
 else  /* Line: 410 */ {
break;
} /* Line: 410 */
} /* Line: 410 */
} /* Line: 410 */
} /* Line: 405 */
 else  /* Line: 402 */ {
break;
} /* Line: 402 */
} /* Line: 402 */
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_tvmapGetDirect_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_tvmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_rmapGetDirect_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_rmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_inClassGetDirect_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_inClassNpGetDirect_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_inClassSynGetDirect_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nlGetDirect_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitRewind bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {349, 349, 349, 349, 349, 349, 0, 0, 0, 351, 351, 351, 351, 351, 351, 351, 351, 351, 351, 0, 0, 0, 351, 0, 0, 0, 353, 353, 353, 353, 353, 353, 353, 353, 353, 0, 0, 0, 354, 354, 354, 354, 355, 355, 356, 356, 356, 356, 356, 356, 356, 356, 356, 358, 359, 359, 359, 359, 360, 360, 362, 362, 363, 363, 363, 363, 368, 368, 368, 368, 369, 370, 370, 371, 371, 373, 373, 373, 373, 374, 375, 376, 376, 376, 376, 376, 376, 0, 0, 0, 377, 377, 377, 377, 378, 378, 378, 379, 379, 380, 381, 381, 381, 383, 384, 384, 384, 384, 384, 384, 384, 0, 0, 0, 384, 384, 384, 384, 0, 0, 0, 384, 384, 384, 384, 384, 384, 0, 0, 0, 386, 388, 388, 392, 401, 402, 402, 403, 405, 405, 408, 409, 410, 0, 410, 410, 411, 411, 411, 411, 411, 0, 0, 0, 411, 411, 411, 411, 411, 0, 0, 0, 411, 411, 411, 411, 411, 0, 0, 0, 413, 413, 414, 415, 415, 415, 415, 416, 416, 418, 418, 422, 422, 423, 425, 425, 425, 425, 425, 428, 429, 432, 432, 434, 435, 435, 435, 435, 436, 436, 438, 439, 439, 439, 0, 0, 0, 440, 442, 443, 445, 445, 447, 447, 448, 448, 448, 449, 449, 449, 449, 449, 449, 449, 449, 451, 451, 451, 451, 452, 452, 452, 453, 453, 453, 453, 453, 453, 0, 0, 0, 454, 454, 454, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 462, 462, 462, 462, 462, 0, 0, 0, 462, 462, 462, 462, 462, 0, 0, 0, 462, 462, 462, 462, 462, 0, 0, 0, 463, 463, 463, 465, 467, 469, 469, 470, 470, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {138, 139, 140, 145, 146, 147, 149, 152, 156, 159, 160, 161, 162, 167, 168, 169, 170, 171, 172, 174, 177, 181, 184, 186, 189, 193, 196, 197, 198, 199, 200, 202, 203, 204, 205, 207, 210, 214, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 242, 243, 244, 245, 246, 247, 248, 253, 254, 255, 260, 261, 262, 263, 264, 265, 267, 268, 269, 274, 275, 276, 279, 280, 281, 286, 287, 288, 290, 293, 297, 300, 301, 302, 303, 304, 305, 306, 307, 312, 313, 314, 315, 316, 318, 321, 322, 323, 328, 329, 330, 335, 336, 339, 343, 346, 347, 348, 353, 354, 357, 361, 364, 365, 366, 367, 368, 373, 374, 377, 381, 384, 388, 389, 508, 512, 513, 516, 518, 519, 520, 522, 523, 524, 524, 527, 529, 530, 532, 533, 534, 535, 537, 540, 544, 547, 548, 549, 550, 551, 553, 556, 560, 563, 564, 565, 566, 567, 569, 572, 576, 579, 580, 581, 582, 583, 584, 589, 590, 591, 594, 595, 596, 597, 599, 602, 603, 604, 605, 606, 608, 610, 613, 618, 619, 620, 621, 622, 623, 624, 629, 630, 631, 636, 637, 639, 642, 646, 649, 650, 652, 655, 656, 658, 659, 660, 661, 662, 663, 664, 665, 666, 668, 669, 670, 671, 676, 677, 678, 679, 681, 682, 683, 684, 689, 690, 691, 692, 693, 695, 698, 702, 705, 706, 707, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 726, 728, 729, 730, 731, 733, 736, 740, 743, 744, 745, 746, 747, 749, 752, 756, 759, 760, 761, 762, 763, 765, 768, 772, 775, 776, 777, 778, 780, 781, 782, 783, 784, 807, 810, 813, 817, 821, 824, 827, 831, 835, 838, 841, 845, 849, 852, 855, 859, 863, 866, 869, 873, 877, 880, 883, 887, 891, 894, 897, 901};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 349 138
typenameGet 0 349 138
assign 1 349 139
CALLGet 0 349 139
assign 1 349 140
equals 1 349 145
assign 1 349 146
heldGet 0 349 146
assign 1 349 147
wasForeachGennedGet 0 349 147
assign 1 0 149
assign 1 0 152
assign 1 0 156
assign 1 351 159
containerGet 0 351 159
assign 1 351 160
typenameGet 0 351 160
assign 1 351 161
CALLGet 0 351 161
assign 1 351 162
equals 1 351 167
assign 1 351 168
containerGet 0 351 168
assign 1 351 169
heldGet 0 351 169
assign 1 351 170
orgNameGet 0 351 170
assign 1 351 171
new 0 351 171
assign 1 351 172
equals 1 351 172
assign 1 0 174
assign 1 0 177
assign 1 0 181
assign 1 351 184
isSecondGet 0 351 184
assign 1 0 186
assign 1 0 189
assign 1 0 193
assign 1 353 196
containedGet 0 353 196
assign 1 353 197
firstGet 0 353 197
assign 1 353 198
typenameGet 0 353 198
assign 1 353 199
VARGet 0 353 199
assign 1 353 200
equals 1 353 200
assign 1 353 202
containedGet 0 353 202
assign 1 353 203
firstGet 0 353 203
assign 1 353 204
heldGet 0 353 204
assign 1 353 205
isTypedGet 0 353 205
assign 1 0 207
assign 1 0 210
assign 1 0 214
assign 1 354 217
containedGet 0 354 217
assign 1 354 218
firstGet 0 354 218
assign 1 354 219
heldGet 0 354 219
assign 1 354 220
namepathGet 0 354 220
assign 1 355 221
stepsGet 0 355 221
assign 1 355 222
lastGet 0 355 222
assign 1 356 223
new 0 356 223
assign 1 356 224
new 0 356 224
assign 1 356 225
substring 2 356 225
assign 1 356 226
lowerValue 0 356 226
assign 1 356 227
new 0 356 227
assign 1 356 228
substring 1 356 228
assign 1 356 229
add 1 356 229
assign 1 356 230
new 0 356 230
assign 1 356 231
add 1 356 231
assign 1 358 232
getSynNp 1 358 232
assign 1 359 233
mtdMapGet 0 359 233
assign 1 359 234
new 0 359 234
assign 1 359 235
add 1 359 235
assign 1 359 236
get 1 359 236
assign 1 360 237
def 1 360 242
assign 1 362 243
heldGet 0 362 243
orgNameSet 1 362 244
assign 1 363 245
heldGet 0 363 245
assign 1 363 246
new 0 363 246
assign 1 363 247
add 1 363 247
nameSet 1 363 248
assign 1 368 253
typenameGet 0 368 253
assign 1 368 254
CLASSGet 0 368 254
assign 1 368 255
equals 1 368 260
assign 1 369 261
assign 1 370 262
heldGet 0 370 262
assign 1 370 263
namepathGet 0 370 263
assign 1 371 264
heldGet 0 371 264
assign 1 371 265
synGet 0 371 265
assign 1 373 267
typenameGet 0 373 267
assign 1 373 268
METHODGet 0 373 268
assign 1 373 269
equals 1 373 274
assign 1 374 275
new 0 374 275
assign 1 375 276
new 0 375 276
assign 1 376 279
typenameGet 0 376 279
assign 1 376 280
VARGet 0 376 280
assign 1 376 281
equals 1 376 286
assign 1 376 287
heldGet 0 376 287
assign 1 376 288
autoTypeGet 0 376 288
assign 1 0 290
assign 1 0 293
assign 1 0 297
assign 1 377 300
heldGet 0 377 300
assign 1 377 301
nameGet 0 377 301
assign 1 377 302
heldGet 0 377 302
put 2 377 303
assign 1 378 304
heldGet 0 378 304
assign 1 378 305
nameGet 0 378 305
assign 1 378 306
get 1 378 306
assign 1 379 307
undef 1 379 312
assign 1 380 313
new 0 380 313
assign 1 381 314
heldGet 0 381 314
assign 1 381 315
nameGet 0 381 315
put 2 381 316
addValue 1 383 318
assign 1 384 321
typenameGet 0 384 321
assign 1 384 322
RBRACESGet 0 384 322
assign 1 384 323
equals 1 384 328
assign 1 384 329
containerGet 0 384 329
assign 1 384 330
def 1 384 335
assign 1 0 336
assign 1 0 339
assign 1 0 343
assign 1 384 346
containerGet 0 384 346
assign 1 384 347
containerGet 0 384 347
assign 1 384 348
def 1 384 353
assign 1 0 354
assign 1 0 357
assign 1 0 361
assign 1 384 364
containerGet 0 384 364
assign 1 384 365
containerGet 0 384 365
assign 1 384 366
typenameGet 0 384 366
assign 1 384 367
METHODGet 0 384 367
assign 1 384 368
equals 1 384 373
assign 1 0 374
assign 1 0 377
assign 1 0 381
processTmps 0 386 384
assign 1 388 388
nextDescendGet 0 388 388
return 1 388 389
assign 1 392 508
new 0 392 508
assign 1 401 512
new 0 401 512
assign 1 402 513
valueIteratorGet 0 402 513
assign 1 402 516
hasNextGet 0 402 516
assign 1 403 518
nextGet 0 403 518
assign 1 405 519
isTypedGet 0 405 519
assign 1 405 520
not 0 405 520
assign 1 408 522
nameGet 0 408 522
assign 1 409 523
get 1 409 523
assign 1 410 524
iteratorGet 0 0 524
assign 1 410 527
hasNextGet 0 410 527
assign 1 410 529
nextGet 0 410 529
assign 1 411 530
isFirstGet 0 411 530
assign 1 411 532
containerGet 0 411 532
assign 1 411 533
typenameGet 0 411 533
assign 1 411 534
CALLGet 0 411 534
assign 1 411 535
equals 1 411 535
assign 1 0 537
assign 1 0 540
assign 1 0 544
assign 1 411 547
containerGet 0 411 547
assign 1 411 548
heldGet 0 411 548
assign 1 411 549
orgNameGet 0 411 549
assign 1 411 550
new 0 411 550
assign 1 411 551
equals 1 411 551
assign 1 0 553
assign 1 0 556
assign 1 0 560
assign 1 411 563
containerGet 0 411 563
assign 1 411 564
secondGet 0 411 564
assign 1 411 565
typenameGet 0 411 565
assign 1 411 566
CALLGet 0 411 566
assign 1 411 567
equals 1 411 567
assign 1 0 569
assign 1 0 572
assign 1 0 576
assign 1 413 579
containerGet 0 413 579
assign 1 413 580
secondGet 0 413 580
assign 1 414 581
assign 1 415 582
heldGet 0 415 582
assign 1 415 583
newNpGet 0 415 583
assign 1 415 584
def 1 415 589
assign 1 416 590
heldGet 0 416 590
assign 1 416 591
newNpGet 0 416 591
assign 1 418 594
containedGet 0 418 594
assign 1 418 595
firstGet 0 418 595
assign 1 422 596
heldGet 0 422 596
assign 1 422 597
isDeclaredGet 0 422 597
assign 1 423 599
heldGet 0 423 599
assign 1 425 602
ptyMapGet 0 425 602
assign 1 425 603
heldGet 0 425 603
assign 1 425 604
nameGet 0 425 604
assign 1 425 605
get 1 425 605
assign 1 425 606
memSynGet 0 425 606
assign 1 428 608
isTypedGet 0 428 608
assign 1 429 610
namepathGet 0 429 610
assign 1 432 613
def 1 432 618
assign 1 434 619
getSynNp 1 434 619
assign 1 435 620
mtdMapGet 0 435 620
assign 1 435 621
heldGet 0 435 621
assign 1 435 622
nameGet 0 435 622
assign 1 435 623
get 1 435 623
assign 1 436 624
def 1 436 629
assign 1 438 630
rsynGet 0 438 630
assign 1 439 631
def 1 439 636
assign 1 439 637
isTypedGet 0 439 637
assign 1 0 639
assign 1 0 642
assign 1 0 646
assign 1 440 649
new 0 440 649
assign 1 442 650
isSelfGet 0 442 650
namepathSet 1 443 652
assign 1 445 655
namepathGet 0 445 655
namepathSet 1 445 656
assign 1 447 658
isTypedGet 0 447 658
isTypedSet 1 447 659
assign 1 448 660
heldGet 0 448 660
assign 1 448 661
namepathGet 0 448 661
addUsed 1 448 662
assign 1 449 663
namepathGet 0 449 663
assign 1 449 664
toString 0 449 664
assign 1 449 665
new 0 449 665
assign 1 449 666
equals 1 449 666
assign 1 449 668
new 0 449 668
assign 1 449 669
isSelfGet 0 449 669
assign 1 449 670
add 1 449 670
print 0 449 671
assign 1 451 676
heldGet 0 451 676
assign 1 451 677
orgNameGet 0 451 677
assign 1 451 678
new 0 451 678
assign 1 451 679
notEquals 1 451 679
assign 1 452 681
mtdMapGet 0 452 681
assign 1 452 682
new 0 452 682
assign 1 452 683
get 1 452 683
assign 1 453 684
def 1 453 689
assign 1 453 690
originGet 0 453 690
assign 1 453 691
toString 0 453 691
assign 1 453 692
new 0 453 692
assign 1 453 693
notEquals 1 453 693
assign 1 0 695
assign 1 0 698
assign 1 0 702
assign 1 454 705
heldGet 0 454 705
assign 1 454 706
new 0 454 706
isForwardSet 1 454 707
assign 1 456 710
new 0 456 710
assign 1 456 711
heldGet 0 456 711
assign 1 456 712
nameGet 0 456 712
assign 1 456 713
add 1 456 713
assign 1 456 714
new 0 456 714
assign 1 456 715
add 1 456 715
assign 1 456 716
toString 0 456 716
assign 1 456 717
add 1 456 717
assign 1 456 718
new 2 456 718
throw 1 456 719
assign 1 462 726
isFirstGet 0 462 726
assign 1 462 728
containerGet 0 462 728
assign 1 462 729
typenameGet 0 462 729
assign 1 462 730
CALLGet 0 462 730
assign 1 462 731
equals 1 462 731
assign 1 0 733
assign 1 0 736
assign 1 0 740
assign 1 462 743
containerGet 0 462 743
assign 1 462 744
heldGet 0 462 744
assign 1 462 745
orgNameGet 0 462 745
assign 1 462 746
new 0 462 746
assign 1 462 747
equals 1 462 747
assign 1 0 749
assign 1 0 752
assign 1 0 756
assign 1 462 759
containerGet 0 462 759
assign 1 462 760
secondGet 0 462 760
assign 1 462 761
typenameGet 0 462 761
assign 1 462 762
VARGet 0 462 762
assign 1 462 763
equals 1 462 763
assign 1 0 765
assign 1 0 768
assign 1 0 772
assign 1 463 775
containerGet 0 463 775
assign 1 463 776
secondGet 0 463 776
assign 1 463 777
heldGet 0 463 777
assign 1 465 778
isTypedGet 0 465 778
assign 1 467 780
new 0 467 780
assign 1 469 781
isTypedGet 0 469 781
isTypedSet 1 469 782
assign 1 470 783
namepathGet 0 470 783
namepathSet 1 470 784
return 1 0 807
return 1 0 810
assign 1 0 813
assign 1 0 817
return 1 0 821
return 1 0 824
assign 1 0 827
assign 1 0 831
return 1 0 835
return 1 0 838
assign 1 0 841
assign 1 0 845
return 1 0 849
return 1 0 852
assign 1 0 855
assign 1 0 859
return 1 0 863
return 1 0 866
assign 1 0 869
assign 1 0 873
return 1 0 877
return 1 0 880
assign 1 0 883
assign 1 0 887
return 1 0 891
return 1 0 894
assign 1 0 897
assign 1 0 901
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1452564531: return bem_toString_0();
case -977356120: return bem_fieldNamesGet_0();
case 1623987490: return bem_serializeContents_0();
case 771367616: return bem_transGet_0();
case 525149966: return bem_tvmapGet_0();
case -594965064: return bem_nlGetDirect_0();
case 734156196: return bem_buildGetDirect_0();
case -846849383: return bem_inClassSynGet_0();
case -1836757512: return bem_copy_0();
case -464967776: return bem_classNameGet_0();
case 1928293906: return bem_once_0();
case 1243871762: return bem_inClassNpGet_0();
case 1834941563: return bem_constGetDirect_0();
case -756845329: return bem_inClassGet_0();
case -991356432: return bem_emitterGet_0();
case 1362132920: return bem_inClassNpGetDirect_0();
case 1441814457: return bem_ntypesGet_0();
case 1148186102: return bem_toAny_0();
case 619304343: return bem_hashGet_0();
case -197180620: return bem_echo_0();
case -1895797969: return bem_fieldIteratorGet_0();
case -757699318: return bem_iteratorGet_0();
case 438244040: return bem_create_0();
case -1443684972: return bem_rmapGetDirect_0();
case -554738332: return bem_rmapGet_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case 1173648123: return bem_nlGet_0();
case 500389220: return bem_print_0();
case 745503722: return bem_inClassGetDirect_0();
case -919772434: return bem_serializeToString_0();
case -682644568: return bem_tvmapGetDirect_0();
case 393443790: return bem_constGet_0();
case 1941268102: return bem_ntypesGetDirect_0();
case -978724962: return bem_tagGet_0();
case 868760417: return bem_serializationIteratorGet_0();
case 1000076890: return bem_transGetDirect_0();
case 1605752359: return bem_many_0();
case 141983605: return bem_sourceFileNameGet_0();
case 1576417178: return bem_new_0();
case 1926766499: return bem_inClassSynGetDirect_0();
case 1725230912: return bem_emitterGetDirect_0();
case 1925396050: return bem_buildGet_0();
case -1604840093: return bem_processTmps_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -85996132: return bem_rmapSetDirect_1(bevd_0);
case 2046170279: return bem_rmapSet_1(bevd_0);
case -152665287: return bem_ntypesSet_1(bevd_0);
case -2080355933: return bem_defined_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case -1087428326: return bem_constSetDirect_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1828535917: return bem_emitterSetDirect_1(bevd_0);
case 637090852: return bem_tvmapSet_1(bevd_0);
case -1623076338: return bem_buildSetDirect_1(bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case 1339738173: return bem_inClassSynSet_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case 184984359: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case 2008315742: return bem_transSetDirect_1(bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case 1514981906: return bem_constSet_1(bevd_0);
case -1550095708: return bem_end_1(bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -12198567: return bem_tvmapSetDirect_1(bevd_0);
case 599885158: return bem_begin_1(bevd_0);
case -1442514461: return bem_nlSetDirect_1(bevd_0);
case -1213270934: return bem_inClassNpSet_1(bevd_0);
case 1123185311: return bem_ntypesSetDirect_1(bevd_0);
case -2114298334: return bem_emitterSet_1(bevd_0);
case 943380603: return bem_inClassSet_1(bevd_0);
case 940817591: return bem_transSet_1(bevd_0);
case 180212318: return bem_inClassSynSetDirect_1(bevd_0);
case -863342792: return bem_inClassNpSetDirect_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 339010255: return bem_nlSet_1(bevd_0);
case -346513329: return bem_buildSet_1(bevd_0);
case 1788589935: return bem_inClassSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
