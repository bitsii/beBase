package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitRewind extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
public static BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_3_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_BuildNode bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_5_4_BuildNode bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_34_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_5_4_LogicBool bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_5_4_LogicBool bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_5_4_BuildNode bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_5_4_BuildNode bevt_79_ta_ph = null;
BEC_2_5_4_BuildNode bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_5_4_BuildNode bevt_83_ta_ph = null;
BEC_2_5_4_BuildNode bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_5_4_BuildNode bevt_86_ta_ph = null;
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 250*/ {
bevt_12_ta_ph = beva_node.bem_heldGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(1842908936);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 250*/
 else /* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 250*/ {
bevt_15_ta_ph = beva_node.bem_containerGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_typenameGet_0();
bevt_16_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_ta_ph.bevi_int == bevt_16_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 252*/ {
bevt_20_ta_ph = beva_node.bem_containerGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_heldGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-227704026);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(-559238061, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 252*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 252*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 252*/
 else /* Line: 252*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 252*/ {
bevt_22_ta_ph = beva_node.bem_isSecondGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 252*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 252*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 252*/
 else /* Line: 252*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 252*/ {
bevt_26_ta_ph = beva_node.bem_containedGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_firstGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(-1471974163);
bevt_27_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(-559238061, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 254*/ {
bevt_31_ta_ph = beva_node.bem_containedGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_firstGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(-1830329539);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-1119453338);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 254*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 254*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 254*/
 else /* Line: 254*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 254*/ {
bevt_34_ta_ph = beva_node.bem_containedGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(-1830329539);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_ta_ph.bemd_0(-1462096677);
bevt_35_ta_ph = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_lastGet_0();
bevt_39_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_40_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_38_ta_ph = bevl_fgcn.bem_substring_2(bevt_39_ta_ph, bevt_40_ta_ph);
bevt_37_ta_ph = bevt_38_ta_ph.bem_lowerValue_0();
bevt_42_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_41_ta_ph = bevl_fgcn.bem_substring_1(bevt_42_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_6_BuildVisitRewind_bels_1));
bevl_fgin = bevt_36_ta_ph.bem_add_1(bevt_43_ta_ph);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_ta_ph = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_45_ta_ph = bevl_fgin.bem_add_1(bevt_46_ta_ph);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_ta_ph.bem_get_1(bevt_45_ta_ph);
if (bevl_fgms == null) {
bevt_47_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_47_ta_ph.bevi_bool)/* Line: 261*/ {
bevt_48_ta_ph = beva_node.bem_heldGet_0();
bevt_48_ta_ph.bemd_1(-1431251922, bevl_fgin);
bevt_49_ta_ph = beva_node.bem_heldGet_0();
bevt_51_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_50_ta_ph = bevl_fgin.bem_add_1(bevt_51_ta_ph);
bevt_49_ta_ph.bemd_1(1035482217, bevt_50_ta_ph);
} /* Line: 264*/
} /* Line: 261*/
} /* Line: 254*/
} /* Line: 252*/
bevt_53_ta_ph = beva_node.bem_typenameGet_0();
bevt_54_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_ta_ph.bevi_int == bevt_54_ta_ph.bevi_int) {
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 269*/ {
bevp_inClass = beva_node;
bevt_55_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_ta_ph.bemd_0(-1462096677);
bevt_56_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_ta_ph.bemd_0(55108584);
} /* Line: 272*/
bevt_58_ta_ph = beva_node.bem_typenameGet_0();
bevt_59_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_ta_ph.bevi_int == bevt_59_ta_ph.bevi_int) {
bevt_57_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_57_ta_ph.bevi_bool)/* Line: 274*/ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 276*/
 else /* Line: 274*/ {
bevt_61_ta_ph = beva_node.bem_typenameGet_0();
bevt_62_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_61_ta_ph.bevi_int == bevt_62_ta_ph.bevi_int) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_64_ta_ph = beva_node.bem_heldGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(1207622806);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 277*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 277*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 277*/
 else /* Line: 277*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 277*/ {
bevt_66_ta_ph = beva_node.bem_heldGet_0();
bevt_65_ta_ph = bevt_66_ta_ph.bemd_0(1912951938);
bevt_67_ta_ph = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(833587755, bevt_65_ta_ph, bevt_67_ta_ph);
bevt_69_ta_ph = beva_node.bem_heldGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bemd_0(1912951938);
bevl_ll = bevp_rmap.bemd_1(1147496195, bevt_68_ta_ph);
if (bevl_ll == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 280*/ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_ta_ph = beva_node.bem_heldGet_0();
bevt_71_ta_ph = bevt_72_ta_ph.bemd_0(1912951938);
bevp_rmap.bemd_2(833587755, bevt_71_ta_ph, bevl_ll);
} /* Line: 282*/
bevl_ll.bemd_1(1835118420, beva_node);
} /* Line: 284*/
 else /* Line: 274*/ {
bevt_74_ta_ph = beva_node.bem_typenameGet_0();
bevt_75_ta_ph = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_ta_ph.bevi_int == bevt_75_ta_ph.bevi_int) {
bevt_73_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_73_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_77_ta_ph = beva_node.bem_containerGet_0();
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 285*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 285*/
 else /* Line: 285*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 285*/ {
bevt_80_ta_ph = beva_node.bem_containerGet_0();
bevt_79_ta_ph = bevt_80_ta_ph.bem_containerGet_0();
if (bevt_79_ta_ph == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 285*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 285*/
 else /* Line: 285*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 285*/ {
bevt_84_ta_ph = beva_node.bem_containerGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_containerGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bem_typenameGet_0();
bevt_85_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_ta_ph.bevi_int == bevt_85_ta_ph.bevi_int) {
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_81_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 285*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 285*/
 else /* Line: 285*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 285*/ {
bem_processTmps_0();
} /* Line: 287*/
} /* Line: 274*/
} /* Line: 274*/
bevt_86_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_86_ta_ph;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_6_6_SystemObject bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_6_6_SystemObject bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 301*/ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool)/* Line: 301*/ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(-445197381);
while (true)
/* Line: 303*/ {
bevt_9_ta_ph = bevl_i.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 303*/ {
bevl_nv = bevl_i.bemd_0(1149836311);
bevt_11_ta_ph = bevl_nv.bemd_0(-1119453338);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(787218599);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 306*/ {
bevl_nvname = bevl_nv.bemd_0(1912951938);
bevl_ll = bevp_rmap.bemd_1(1147496195, bevl_nvname);
bevt_0_ta_loop = bevl_ll.bemd_0(1140404476);
while (true)
/* Line: 311*/ {
bevt_12_ta_ph = bevt_0_ta_loop.bemd_0(-174956569);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 311*/ {
bevl_k = bevt_0_ta_loop.bemd_0(1149836311);
bevt_13_ta_ph = bevl_k.bemd_0(-663320484);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 312*/ {
bevt_16_ta_ph = bevl_k.bemd_0(304683696);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-1471974163);
bevt_17_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bemd_1(-559238061, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 312*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 312*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 312*/
 else /* Line: 312*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 312*/ {
bevt_21_ta_ph = bevl_k.bemd_0(304683696);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-1830329539);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-227704026);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-559238061, bevt_22_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 312*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 312*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 312*/
 else /* Line: 312*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 312*/ {
bevt_26_ta_ph = bevl_k.bemd_0(304683696);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(508943773);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(-1471974163);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(-559238061, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 312*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 312*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 312*/
 else /* Line: 312*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 312*/ {
bevt_28_ta_ph = bevl_k.bemd_0(304683696);
bevl_tcall = bevt_28_ta_ph.bemd_0(508943773);
bevl_targNp = null;
bevt_31_ta_ph = bevl_tcall.bemd_0(-1830329539);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(1729428979);
if (bevt_30_ta_ph == null) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_32_ta_ph = bevl_tcall.bemd_0(-1830329539);
bevl_targNp = bevt_32_ta_ph.bemd_0(1729428979);
} /* Line: 317*/
 else /* Line: 318*/ {
bevt_33_ta_ph = bevl_tcall.bemd_0(-1850385927);
bevl_targ = bevt_33_ta_ph.bemd_0(-1350805026);
bevt_35_ta_ph = bevl_targ.bemd_0(-1830329539);
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(2072097285);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 320*/ {
bevl_tany = bevl_targ.bemd_0(-1830329539);
} /* Line: 321*/
 else /* Line: 322*/ {
bevt_37_ta_ph = bevp_inClassSyn.bemd_0(-1488745602);
bevt_39_ta_ph = bevl_targ.bemd_0(-1830329539);
bevt_38_ta_ph = bevt_39_ta_ph.bemd_0(1912951938);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(1147496195, bevt_38_ta_ph);
bevl_tany = bevt_36_ta_ph.bemd_0(894276367);
} /* Line: 323*/
bevt_40_ta_ph = bevl_tany.bemd_0(-1119453338);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 326*/ {
bevl_targNp = bevl_tany.bemd_0(-1462096677);
} /* Line: 327*/
} /* Line: 326*/
if (bevl_targNp == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 330*/ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_44_ta_ph = bevl_tcall.bemd_0(-1830329539);
bevt_43_ta_ph = bevt_44_ta_ph.bemd_0(1912951938);
bevl_mtdc = bevt_42_ta_ph.bem_get_1(bevt_43_ta_ph);
if (bevl_mtdc == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 334*/ {
bevl_oany = bevl_mtdc.bemd_0(-397929141);
if (bevl_oany == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 337*/ {
bevt_47_ta_ph = bevl_oany.bemd_0(-1119453338);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 337*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 337*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 337*/
 else /* Line: 337*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 337*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_ta_ph = bevl_oany.bemd_0(1927396741);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 340*/ {
bevl_nv.bemd_1(-153463398, bevl_targNp);
} /* Line: 341*/
 else /* Line: 342*/ {
bevt_49_ta_ph = bevl_oany.bemd_0(-1462096677);
bevl_nv.bemd_1(-153463398, bevt_49_ta_ph);
} /* Line: 343*/
bevt_50_ta_ph = bevl_oany.bemd_0(-1119453338);
bevl_nv.bemd_1(-1120392262, bevt_50_ta_ph);
bevt_51_ta_ph = bevp_inClass.bemd_0(-1830329539);
bevt_52_ta_ph = bevl_nv.bemd_0(-1462096677);
bevt_51_ta_ph.bemd_1(-1309029435, bevt_52_ta_ph);
bevt_55_ta_ph = bevl_nv.bemd_0(-1462096677);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(-82017130);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_3));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(-559238061, bevt_56_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 347*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(27, bece_BEC_3_5_5_6_BuildVisitRewind_bels_4));
bevt_59_ta_ph = bevl_oany.bemd_0(1927396741);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevt_59_ta_ph);
bevt_57_ta_ph.bem_print_0();
} /* Line: 347*/
} /* Line: 347*/
} /* Line: 337*/
 else /* Line: 334*/ {
bevt_62_ta_ph = bevl_tcall.bemd_0(-1830329539);
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(-227704026);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_60_ta_ph = bevt_61_ta_ph.bemd_1(-850371892, bevt_63_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_60_ta_ph).bevi_bool)/* Line: 349*/ {
bevt_64_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_6));
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_ta_ph.bem_get_1(bevt_65_ta_ph);
if (bevl_fcms == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_69_ta_ph = bevl_fcms.bem_originGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_toString_0();
bevt_70_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_7));
bevt_67_ta_ph = bevt_68_ta_ph.bem_notEquals_1(bevt_70_ta_ph);
if (bevt_67_ta_ph.bevi_bool)/* Line: 351*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 351*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 351*/
 else /* Line: 351*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 351*/ {
bevt_71_ta_ph = bevl_tcall.bemd_0(-1830329539);
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
bevt_71_ta_ph.bemd_1(-140538581, bevt_72_ta_ph);
} /* Line: 352*/
 else /* Line: 353*/ {
bevt_77_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_3_5_5_6_BuildVisitRewind_bels_8));
bevt_79_ta_ph = bevl_tcall.bemd_0(-1830329539);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(1912951938);
bevt_76_ta_ph = bevt_77_ta_ph.bem_add_1(bevt_78_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitRewind_bels_9));
bevt_75_ta_ph = bevt_76_ta_ph.bem_add_1(bevt_80_ta_ph);
bevt_81_ta_ph = bevl_targNp.bemd_0(-82017130);
bevt_74_ta_ph = bevt_75_ta_ph.bem_add_1(bevt_81_ta_ph);
bevt_73_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_ta_ph, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_ta_ph);
} /* Line: 354*/
} /* Line: 351*/
} /* Line: 334*/
} /* Line: 334*/
} /* Line: 330*/
 else /* Line: 312*/ {
bevt_82_ta_ph = bevl_k.bemd_0(-663320484);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_85_ta_ph = bevl_k.bemd_0(304683696);
bevt_84_ta_ph = bevt_85_ta_ph.bemd_0(-1471974163);
bevt_86_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_1(-559238061, bevt_86_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_83_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 360*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 360*/
 else /* Line: 360*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 360*/ {
bevt_90_ta_ph = bevl_k.bemd_0(304683696);
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(-1830329539);
bevt_88_ta_ph = bevt_89_ta_ph.bemd_0(-227704026);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_87_ta_ph = bevt_88_ta_ph.bemd_1(-559238061, bevt_91_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 360*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 360*/
 else /* Line: 360*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 360*/ {
bevt_95_ta_ph = bevl_k.bemd_0(304683696);
bevt_94_ta_ph = bevt_95_ta_ph.bemd_0(508943773);
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(-1471974163);
bevt_96_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_92_ta_ph = bevt_93_ta_ph.bemd_1(-559238061, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_92_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 360*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 360*/
 else /* Line: 360*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 360*/ {
bevt_98_ta_ph = bevl_k.bemd_0(304683696);
bevt_97_ta_ph = bevt_98_ta_ph.bemd_0(508943773);
bevl_targ = bevt_97_ta_ph.bemd_0(-1830329539);
bevt_99_ta_ph = bevl_targ.bemd_0(-1119453338);
if (((BEC_2_5_4_LogicBool) bevt_99_ta_ph).bevi_bool)/* Line: 363*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_ta_ph = bevl_targ.bemd_0(-1119453338);
bevl_nv.bemd_1(-1120392262, bevt_100_ta_ph);
bevt_101_ta_ph = bevl_targ.bemd_0(-1462096677);
bevl_nv.bemd_1(-153463398, bevt_101_ta_ph);
} /* Line: 368*/
} /* Line: 363*/
} /* Line: 312*/
} /* Line: 312*/
 else /* Line: 311*/ {
break;
} /* Line: 311*/
} /* Line: 311*/
} /* Line: 311*/
} /* Line: 306*/
 else /* Line: 303*/ {
break;
} /* Line: 303*/
} /* Line: 303*/
} /* Line: 303*/
 else /* Line: 301*/ {
break;
} /* Line: 301*/
} /* Line: 301*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tvmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClass = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nl = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {250, 250, 250, 250, 250, 250, 0, 0, 0, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 0, 0, 0, 252, 0, 0, 0, 254, 254, 254, 254, 254, 254, 254, 254, 254, 0, 0, 0, 255, 255, 255, 255, 256, 256, 257, 257, 257, 257, 257, 257, 257, 257, 257, 259, 260, 260, 260, 260, 261, 261, 263, 263, 264, 264, 264, 264, 269, 269, 269, 269, 270, 271, 271, 272, 272, 274, 274, 274, 274, 275, 276, 277, 277, 277, 277, 277, 277, 0, 0, 0, 278, 278, 278, 278, 279, 279, 279, 280, 280, 281, 282, 282, 282, 284, 285, 285, 285, 285, 285, 285, 285, 0, 0, 0, 285, 285, 285, 285, 0, 0, 0, 285, 285, 285, 285, 285, 285, 0, 0, 0, 287, 289, 289, 293, 302, 303, 303, 304, 306, 306, 309, 310, 311, 0, 311, 311, 312, 312, 312, 312, 312, 0, 0, 0, 312, 312, 312, 312, 312, 0, 0, 0, 312, 312, 312, 312, 312, 0, 0, 0, 314, 314, 315, 316, 316, 316, 316, 317, 317, 319, 319, 320, 320, 321, 323, 323, 323, 323, 323, 326, 327, 330, 330, 332, 333, 333, 333, 333, 334, 334, 336, 337, 337, 337, 0, 0, 0, 338, 340, 341, 343, 343, 345, 345, 346, 346, 346, 347, 347, 347, 347, 347, 347, 347, 347, 349, 349, 349, 349, 350, 350, 350, 351, 351, 351, 351, 351, 351, 0, 0, 0, 352, 352, 352, 354, 354, 354, 354, 354, 354, 354, 354, 354, 354, 360, 360, 360, 360, 360, 0, 0, 0, 360, 360, 360, 360, 360, 0, 0, 0, 360, 360, 360, 360, 360, 0, 0, 0, 361, 361, 361, 363, 365, 367, 367, 368, 368, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {125, 126, 127, 132, 133, 134, 136, 139, 143, 146, 147, 148, 149, 154, 155, 156, 157, 158, 159, 161, 164, 168, 171, 173, 176, 180, 183, 184, 185, 186, 187, 189, 190, 191, 192, 194, 197, 201, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 229, 230, 231, 232, 233, 234, 235, 240, 241, 242, 247, 248, 249, 250, 251, 252, 254, 255, 256, 261, 262, 263, 266, 267, 268, 273, 274, 275, 277, 280, 284, 287, 288, 289, 290, 291, 292, 293, 294, 299, 300, 301, 302, 303, 305, 308, 309, 310, 315, 316, 317, 322, 323, 326, 330, 333, 334, 335, 340, 341, 344, 348, 351, 352, 353, 354, 355, 360, 361, 364, 368, 371, 375, 376, 495, 499, 500, 503, 505, 506, 507, 509, 510, 511, 511, 514, 516, 517, 519, 520, 521, 522, 524, 527, 531, 534, 535, 536, 537, 538, 540, 543, 547, 550, 551, 552, 553, 554, 556, 559, 563, 566, 567, 568, 569, 570, 571, 576, 577, 578, 581, 582, 583, 584, 586, 589, 590, 591, 592, 593, 595, 597, 600, 605, 606, 607, 608, 609, 610, 611, 616, 617, 618, 623, 624, 626, 629, 633, 636, 637, 639, 642, 643, 645, 646, 647, 648, 649, 650, 651, 652, 653, 655, 656, 657, 658, 663, 664, 665, 666, 668, 669, 670, 671, 676, 677, 678, 679, 680, 682, 685, 689, 692, 693, 694, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 713, 715, 716, 717, 718, 720, 723, 727, 730, 731, 732, 733, 734, 736, 739, 743, 746, 747, 748, 749, 750, 752, 755, 759, 762, 763, 764, 765, 767, 768, 769, 770, 771, 794, 797, 801, 804, 808, 811, 815, 818, 822, 825, 829, 832, 836, 839};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 250 125
typenameGet 0 250 125
assign 1 250 126
CALLGet 0 250 126
assign 1 250 127
equals 1 250 132
assign 1 250 133
heldGet 0 250 133
assign 1 250 134
wasForeachGennedGet 0 250 134
assign 1 0 136
assign 1 0 139
assign 1 0 143
assign 1 252 146
containerGet 0 252 146
assign 1 252 147
typenameGet 0 252 147
assign 1 252 148
CALLGet 0 252 148
assign 1 252 149
equals 1 252 154
assign 1 252 155
containerGet 0 252 155
assign 1 252 156
heldGet 0 252 156
assign 1 252 157
orgNameGet 0 252 157
assign 1 252 158
new 0 252 158
assign 1 252 159
equals 1 252 159
assign 1 0 161
assign 1 0 164
assign 1 0 168
assign 1 252 171
isSecondGet 0 252 171
assign 1 0 173
assign 1 0 176
assign 1 0 180
assign 1 254 183
containedGet 0 254 183
assign 1 254 184
firstGet 0 254 184
assign 1 254 185
typenameGet 0 254 185
assign 1 254 186
VARGet 0 254 186
assign 1 254 187
equals 1 254 187
assign 1 254 189
containedGet 0 254 189
assign 1 254 190
firstGet 0 254 190
assign 1 254 191
heldGet 0 254 191
assign 1 254 192
isTypedGet 0 254 192
assign 1 0 194
assign 1 0 197
assign 1 0 201
assign 1 255 204
containedGet 0 255 204
assign 1 255 205
firstGet 0 255 205
assign 1 255 206
heldGet 0 255 206
assign 1 255 207
namepathGet 0 255 207
assign 1 256 208
stepsGet 0 256 208
assign 1 256 209
lastGet 0 256 209
assign 1 257 210
new 0 257 210
assign 1 257 211
new 0 257 211
assign 1 257 212
substring 2 257 212
assign 1 257 213
lowerValue 0 257 213
assign 1 257 214
new 0 257 214
assign 1 257 215
substring 1 257 215
assign 1 257 216
add 1 257 216
assign 1 257 217
new 0 257 217
assign 1 257 218
add 1 257 218
assign 1 259 219
getSynNp 1 259 219
assign 1 260 220
mtdMapGet 0 260 220
assign 1 260 221
new 0 260 221
assign 1 260 222
add 1 260 222
assign 1 260 223
get 1 260 223
assign 1 261 224
def 1 261 229
assign 1 263 230
heldGet 0 263 230
orgNameSet 1 263 231
assign 1 264 232
heldGet 0 264 232
assign 1 264 233
new 0 264 233
assign 1 264 234
add 1 264 234
nameSet 1 264 235
assign 1 269 240
typenameGet 0 269 240
assign 1 269 241
CLASSGet 0 269 241
assign 1 269 242
equals 1 269 247
assign 1 270 248
assign 1 271 249
heldGet 0 271 249
assign 1 271 250
namepathGet 0 271 250
assign 1 272 251
heldGet 0 272 251
assign 1 272 252
synGet 0 272 252
assign 1 274 254
typenameGet 0 274 254
assign 1 274 255
METHODGet 0 274 255
assign 1 274 256
equals 1 274 261
assign 1 275 262
new 0 275 262
assign 1 276 263
new 0 276 263
assign 1 277 266
typenameGet 0 277 266
assign 1 277 267
VARGet 0 277 267
assign 1 277 268
equals 1 277 273
assign 1 277 274
heldGet 0 277 274
assign 1 277 275
autoTypeGet 0 277 275
assign 1 0 277
assign 1 0 280
assign 1 0 284
assign 1 278 287
heldGet 0 278 287
assign 1 278 288
nameGet 0 278 288
assign 1 278 289
heldGet 0 278 289
put 2 278 290
assign 1 279 291
heldGet 0 279 291
assign 1 279 292
nameGet 0 279 292
assign 1 279 293
get 1 279 293
assign 1 280 294
undef 1 280 299
assign 1 281 300
new 0 281 300
assign 1 282 301
heldGet 0 282 301
assign 1 282 302
nameGet 0 282 302
put 2 282 303
addValue 1 284 305
assign 1 285 308
typenameGet 0 285 308
assign 1 285 309
RBRACESGet 0 285 309
assign 1 285 310
equals 1 285 315
assign 1 285 316
containerGet 0 285 316
assign 1 285 317
def 1 285 322
assign 1 0 323
assign 1 0 326
assign 1 0 330
assign 1 285 333
containerGet 0 285 333
assign 1 285 334
containerGet 0 285 334
assign 1 285 335
def 1 285 340
assign 1 0 341
assign 1 0 344
assign 1 0 348
assign 1 285 351
containerGet 0 285 351
assign 1 285 352
containerGet 0 285 352
assign 1 285 353
typenameGet 0 285 353
assign 1 285 354
METHODGet 0 285 354
assign 1 285 355
equals 1 285 360
assign 1 0 361
assign 1 0 364
assign 1 0 368
processTmps 0 287 371
assign 1 289 375
nextDescendGet 0 289 375
return 1 289 376
assign 1 293 495
new 0 293 495
assign 1 302 499
new 0 302 499
assign 1 303 500
valueIteratorGet 0 303 500
assign 1 303 503
hasNextGet 0 303 503
assign 1 304 505
nextGet 0 304 505
assign 1 306 506
isTypedGet 0 306 506
assign 1 306 507
not 0 306 507
assign 1 309 509
nameGet 0 309 509
assign 1 310 510
get 1 310 510
assign 1 311 511
iteratorGet 0 0 511
assign 1 311 514
hasNextGet 0 311 514
assign 1 311 516
nextGet 0 311 516
assign 1 312 517
isFirstGet 0 312 517
assign 1 312 519
containerGet 0 312 519
assign 1 312 520
typenameGet 0 312 520
assign 1 312 521
CALLGet 0 312 521
assign 1 312 522
equals 1 312 522
assign 1 0 524
assign 1 0 527
assign 1 0 531
assign 1 312 534
containerGet 0 312 534
assign 1 312 535
heldGet 0 312 535
assign 1 312 536
orgNameGet 0 312 536
assign 1 312 537
new 0 312 537
assign 1 312 538
equals 1 312 538
assign 1 0 540
assign 1 0 543
assign 1 0 547
assign 1 312 550
containerGet 0 312 550
assign 1 312 551
secondGet 0 312 551
assign 1 312 552
typenameGet 0 312 552
assign 1 312 553
CALLGet 0 312 553
assign 1 312 554
equals 1 312 554
assign 1 0 556
assign 1 0 559
assign 1 0 563
assign 1 314 566
containerGet 0 314 566
assign 1 314 567
secondGet 0 314 567
assign 1 315 568
assign 1 316 569
heldGet 0 316 569
assign 1 316 570
newNpGet 0 316 570
assign 1 316 571
def 1 316 576
assign 1 317 577
heldGet 0 317 577
assign 1 317 578
newNpGet 0 317 578
assign 1 319 581
containedGet 0 319 581
assign 1 319 582
firstGet 0 319 582
assign 1 320 583
heldGet 0 320 583
assign 1 320 584
isDeclaredGet 0 320 584
assign 1 321 586
heldGet 0 321 586
assign 1 323 589
ptyMapGet 0 323 589
assign 1 323 590
heldGet 0 323 590
assign 1 323 591
nameGet 0 323 591
assign 1 323 592
get 1 323 592
assign 1 323 593
memSynGet 0 323 593
assign 1 326 595
isTypedGet 0 326 595
assign 1 327 597
namepathGet 0 327 597
assign 1 330 600
def 1 330 605
assign 1 332 606
getSynNp 1 332 606
assign 1 333 607
mtdMapGet 0 333 607
assign 1 333 608
heldGet 0 333 608
assign 1 333 609
nameGet 0 333 609
assign 1 333 610
get 1 333 610
assign 1 334 611
def 1 334 616
assign 1 336 617
rsynGet 0 336 617
assign 1 337 618
def 1 337 623
assign 1 337 624
isTypedGet 0 337 624
assign 1 0 626
assign 1 0 629
assign 1 0 633
assign 1 338 636
new 0 338 636
assign 1 340 637
isSelfGet 0 340 637
namepathSet 1 341 639
assign 1 343 642
namepathGet 0 343 642
namepathSet 1 343 643
assign 1 345 645
isTypedGet 0 345 645
isTypedSet 1 345 646
assign 1 346 647
heldGet 0 346 647
assign 1 346 648
namepathGet 0 346 648
addUsed 1 346 649
assign 1 347 650
namepathGet 0 347 650
assign 1 347 651
toString 0 347 651
assign 1 347 652
new 0 347 652
assign 1 347 653
equals 1 347 653
assign 1 347 655
new 0 347 655
assign 1 347 656
isSelfGet 0 347 656
assign 1 347 657
add 1 347 657
print 0 347 658
assign 1 349 663
heldGet 0 349 663
assign 1 349 664
orgNameGet 0 349 664
assign 1 349 665
new 0 349 665
assign 1 349 666
notEquals 1 349 666
assign 1 350 668
mtdMapGet 0 350 668
assign 1 350 669
new 0 350 669
assign 1 350 670
get 1 350 670
assign 1 351 671
def 1 351 676
assign 1 351 677
originGet 0 351 677
assign 1 351 678
toString 0 351 678
assign 1 351 679
new 0 351 679
assign 1 351 680
notEquals 1 351 680
assign 1 0 682
assign 1 0 685
assign 1 0 689
assign 1 352 692
heldGet 0 352 692
assign 1 352 693
new 0 352 693
isForwardSet 1 352 694
assign 1 354 697
new 0 354 697
assign 1 354 698
heldGet 0 354 698
assign 1 354 699
nameGet 0 354 699
assign 1 354 700
add 1 354 700
assign 1 354 701
new 0 354 701
assign 1 354 702
add 1 354 702
assign 1 354 703
toString 0 354 703
assign 1 354 704
add 1 354 704
assign 1 354 705
new 2 354 705
throw 1 354 706
assign 1 360 713
isFirstGet 0 360 713
assign 1 360 715
containerGet 0 360 715
assign 1 360 716
typenameGet 0 360 716
assign 1 360 717
CALLGet 0 360 717
assign 1 360 718
equals 1 360 718
assign 1 0 720
assign 1 0 723
assign 1 0 727
assign 1 360 730
containerGet 0 360 730
assign 1 360 731
heldGet 0 360 731
assign 1 360 732
orgNameGet 0 360 732
assign 1 360 733
new 0 360 733
assign 1 360 734
equals 1 360 734
assign 1 0 736
assign 1 0 739
assign 1 0 743
assign 1 360 746
containerGet 0 360 746
assign 1 360 747
secondGet 0 360 747
assign 1 360 748
typenameGet 0 360 748
assign 1 360 749
VARGet 0 360 749
assign 1 360 750
equals 1 360 750
assign 1 0 752
assign 1 0 755
assign 1 0 759
assign 1 361 762
containerGet 0 361 762
assign 1 361 763
secondGet 0 361 763
assign 1 361 764
heldGet 0 361 764
assign 1 363 765
isTypedGet 0 363 765
assign 1 365 767
new 0 365 767
assign 1 367 768
isTypedGet 0 367 768
isTypedSet 1 367 769
assign 1 368 770
namepathGet 0 368 770
namepathSet 1 368 771
return 1 0 794
assign 1 0 797
return 1 0 801
assign 1 0 804
return 1 0 808
assign 1 0 811
return 1 0 815
assign 1 0 818
return 1 0 822
assign 1 0 825
return 1 0 829
assign 1 0 832
return 1 0 836
assign 1 0 839
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1039803795: return bem_processTmps_0();
case 1140404476: return bem_iteratorGet_0();
case 1521305638: return bem_inClassSynGet_0();
case 416881831: return bem_copy_0();
case -1644535650: return bem_tvmapGet_0();
case -2131679183: return bem_inClassNpGet_0();
case -82017130: return bem_toString_0();
case 153130764: return bem_print_0();
case -316738093: return bem_rmapGet_0();
case 1534931236: return bem_constGet_0();
case 1314272582: return bem_ntypesGet_0();
case 324521155: return bem_create_0();
case 1799353425: return bem_emitterGet_0();
case -187492472: return bem_new_0();
case 49505741: return bem_nlGet_0();
case -138398773: return bem_buildGet_0();
case -159849764: return bem_hashGet_0();
case 1566815588: return bem_transGet_0();
case -574874716: return bem_inClassGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 91747582: return bem_inClassSet_1(bevd_0);
case -850371892: return bem_notEquals_1(bevd_0);
case 1368071643: return bem_begin_1(bevd_0);
case 442454347: return bem_tvmapSet_1(bevd_0);
case 861523673: return bem_end_1(bevd_0);
case -1556386074: return bem_buildSet_1(bevd_0);
case -1229272393: return bem_ntypesSet_1(bevd_0);
case -325206129: return bem_nlSet_1(bevd_0);
case -1949443930: return bem_emitterSet_1(bevd_0);
case -559238061: return bem_equals_1(bevd_0);
case -1574865868: return bem_inClassNpSet_1(bevd_0);
case 1267419746: return bem_def_1(bevd_0);
case 62749260: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 234994144: return bem_inClassSynSet_1(bevd_0);
case -393105689: return bem_undef_1(bevd_0);
case -413865189: return bem_transSet_1(bevd_0);
case 1336352814: return bem_copyTo_1(bevd_0);
case 931847870: return bem_rmapSet_1(bevd_0);
case -738090810: return bem_constSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2109827654: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1822328732: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 347449110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -911952501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
