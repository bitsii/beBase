package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitRewind extends BEC_3_5_5_9_BuildVisitChkIfEmit {
public BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
public static BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_3_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_BuildNode bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_5_4_BuildNode bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_3_MathInt bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_5_4_LogicBool bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_5_4_LogicBool bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_5_4_BuildNode bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_5_4_BuildNode bevt_83_ta_ph = null;
BEC_2_5_4_BuildNode bevt_84_ta_ph = null;
BEC_2_5_4_LogicBool bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_5_4_BuildNode bevt_87_ta_ph = null;
BEC_2_5_4_BuildNode bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_5_4_BuildNode bevt_90_ta_ph = null;
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 295*/ {
bevt_11_ta_ph = bem_acceptIfEmit_1(beva_node);
return (BEC_2_5_4_BuildNode) bevt_11_ta_ph;
} /* Line: 296*/
bevt_13_ta_ph = beva_node.bem_typenameGet_0();
bevt_14_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_13_ta_ph.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 298*/ {
bevt_16_ta_ph = beva_node.bem_heldGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-1241466783);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 298*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 298*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 298*/
 else /* Line: 298*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 298*/ {
bevt_19_ta_ph = beva_node.bem_containerGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bem_typenameGet_0();
bevt_20_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_18_ta_ph.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_24_ta_ph = beva_node.bem_containerGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bem_heldGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(1236761075);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(-1433542779, bevt_25_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 300*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_26_ta_ph = beva_node.bem_isSecondGet_0();
if (bevt_26_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_30_ta_ph = beva_node.bem_containedGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(818419601);
bevt_31_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_27_ta_ph = bevt_28_ta_ph.bemd_1(-1433542779, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 302*/ {
bevt_35_ta_ph = beva_node.bem_containedGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bem_firstGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bemd_0(1851661563);
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(-61061249);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 302*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 302*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 302*/
 else /* Line: 302*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 302*/ {
bevt_38_ta_ph = beva_node.bem_containedGet_0();
bevt_37_ta_ph = bevt_38_ta_ph.bem_firstGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(1851661563);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_36_ta_ph.bemd_0(-40164505);
bevt_39_ta_ph = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_39_ta_ph.bem_lastGet_0();
bevt_43_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_44_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_42_ta_ph = bevl_fgcn.bem_substring_2(bevt_43_ta_ph, bevt_44_ta_ph);
bevt_41_ta_ph = bevt_42_ta_ph.bem_lowerValue_0();
bevt_46_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_45_ta_ph = bevl_fgcn.bem_substring_1(bevt_46_ta_ph);
bevt_40_ta_ph = bevt_41_ta_ph.bem_add_1(bevt_45_ta_ph);
bevt_47_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_6_BuildVisitRewind_bels_1));
bevl_fgin = bevt_40_ta_ph.bem_add_1(bevt_47_ta_ph);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_48_ta_ph = bevl_fgsy.bem_mtdMapGet_0();
bevt_50_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_49_ta_ph = bevl_fgin.bem_add_1(bevt_50_ta_ph);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_48_ta_ph.bem_get_1(bevt_49_ta_ph);
if (bevl_fgms == null) {
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 309*/ {
bevt_52_ta_ph = beva_node.bem_heldGet_0();
bevt_52_ta_ph.bemd_1(488129051, bevl_fgin);
bevt_53_ta_ph = beva_node.bem_heldGet_0();
bevt_55_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_54_ta_ph = bevl_fgin.bem_add_1(bevt_55_ta_ph);
bevt_53_ta_ph.bemd_1(422361622, bevt_54_ta_ph);
} /* Line: 312*/
} /* Line: 309*/
} /* Line: 302*/
} /* Line: 300*/
bevt_57_ta_ph = beva_node.bem_typenameGet_0();
bevt_58_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_57_ta_ph.bevi_int == bevt_58_ta_ph.bevi_int) {
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 317*/ {
bevp_inClass = beva_node;
bevt_59_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_59_ta_ph.bemd_0(-40164505);
bevt_60_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_60_ta_ph.bemd_0(864675864);
} /* Line: 320*/
bevt_62_ta_ph = beva_node.bem_typenameGet_0();
bevt_63_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_62_ta_ph.bevi_int == bevt_63_ta_ph.bevi_int) {
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 322*/ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 324*/
 else /* Line: 322*/ {
bevt_65_ta_ph = beva_node.bem_typenameGet_0();
bevt_66_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_65_ta_ph.bevi_int == bevt_66_ta_ph.bevi_int) {
bevt_64_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_64_ta_ph.bevi_bool)/* Line: 325*/ {
bevt_68_ta_ph = beva_node.bem_heldGet_0();
bevt_67_ta_ph = bevt_68_ta_ph.bemd_0(-1909509907);
if (((BEC_2_5_4_LogicBool) bevt_67_ta_ph).bevi_bool)/* Line: 325*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 325*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 325*/
 else /* Line: 325*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 325*/ {
bevt_70_ta_ph = beva_node.bem_heldGet_0();
bevt_69_ta_ph = bevt_70_ta_ph.bemd_0(-752973622);
bevt_71_ta_ph = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(736084808, bevt_69_ta_ph, bevt_71_ta_ph);
bevt_73_ta_ph = beva_node.bem_heldGet_0();
bevt_72_ta_ph = bevt_73_ta_ph.bemd_0(-752973622);
bevl_ll = bevp_rmap.bemd_1(-929839053, bevt_72_ta_ph);
if (bevl_ll == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 328*/ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_76_ta_ph = beva_node.bem_heldGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bemd_0(-752973622);
bevp_rmap.bemd_2(736084808, bevt_75_ta_ph, bevl_ll);
} /* Line: 330*/
bevl_ll.bemd_1(-366572201, beva_node);
} /* Line: 332*/
 else /* Line: 322*/ {
bevt_78_ta_ph = beva_node.bem_typenameGet_0();
bevt_79_ta_ph = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_78_ta_ph.bevi_int == bevt_79_ta_ph.bevi_int) {
bevt_77_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_77_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_77_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_81_ta_ph = beva_node.bem_containerGet_0();
if (bevt_81_ta_ph == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 333*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 333*/
 else /* Line: 333*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 333*/ {
bevt_84_ta_ph = beva_node.bem_containerGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_containerGet_0();
if (bevt_83_ta_ph == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 333*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 333*/
 else /* Line: 333*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 333*/ {
bevt_88_ta_ph = beva_node.bem_containerGet_0();
bevt_87_ta_ph = bevt_88_ta_ph.bem_containerGet_0();
bevt_86_ta_ph = bevt_87_ta_ph.bem_typenameGet_0();
bevt_89_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_86_ta_ph.bevi_int == bevt_89_ta_ph.bevi_int) {
bevt_85_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_85_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_85_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 333*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 333*/
 else /* Line: 333*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 333*/ {
bem_processTmps_0();
} /* Line: 335*/
} /* Line: 322*/
} /* Line: 322*/
bevt_90_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_90_ta_ph;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_6_6_SystemObject bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_6_6_SystemObject bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 349*/ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool)/* Line: 349*/ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(383008204);
while (true)
/* Line: 351*/ {
bevt_9_ta_ph = bevl_i.bemd_0(738965128);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 351*/ {
bevl_nv = bevl_i.bemd_0(293228087);
bevt_11_ta_ph = bevl_nv.bemd_0(-61061249);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(1810575250);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 354*/ {
bevl_nvname = bevl_nv.bemd_0(-752973622);
bevl_ll = bevp_rmap.bemd_1(-929839053, bevl_nvname);
bevt_0_ta_loop = bevl_ll.bemd_0(66953015);
while (true)
/* Line: 359*/ {
bevt_12_ta_ph = bevt_0_ta_loop.bemd_0(738965128);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 359*/ {
bevl_k = bevt_0_ta_loop.bemd_0(293228087);
bevt_13_ta_ph = bevl_k.bemd_0(-1973919641);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_16_ta_ph = bevl_k.bemd_0(-1936293836);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(818419601);
bevt_17_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bemd_1(-1433542779, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 360*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 360*/
 else /* Line: 360*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 360*/ {
bevt_21_ta_ph = bevl_k.bemd_0(-1936293836);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(1851661563);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(1236761075);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-1433542779, bevt_22_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 360*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 360*/
 else /* Line: 360*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 360*/ {
bevt_26_ta_ph = bevl_k.bemd_0(-1936293836);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(2038210307);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(818419601);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(-1433542779, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 360*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 360*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 360*/
 else /* Line: 360*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 360*/ {
bevt_28_ta_ph = bevl_k.bemd_0(-1936293836);
bevl_tcall = bevt_28_ta_ph.bemd_0(2038210307);
bevl_targNp = null;
bevt_31_ta_ph = bevl_tcall.bemd_0(1851661563);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-1942981700);
if (bevt_30_ta_ph == null) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 364*/ {
bevt_32_ta_ph = bevl_tcall.bemd_0(1851661563);
bevl_targNp = bevt_32_ta_ph.bemd_0(-1942981700);
} /* Line: 365*/
 else /* Line: 366*/ {
bevt_33_ta_ph = bevl_tcall.bemd_0(460401996);
bevl_targ = bevt_33_ta_ph.bemd_0(210958999);
bevt_35_ta_ph = bevl_targ.bemd_0(1851661563);
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(-255722265);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 368*/ {
bevl_tany = bevl_targ.bemd_0(1851661563);
} /* Line: 369*/
 else /* Line: 370*/ {
bevt_37_ta_ph = bevp_inClassSyn.bemd_0(-11993920);
bevt_39_ta_ph = bevl_targ.bemd_0(1851661563);
bevt_38_ta_ph = bevt_39_ta_ph.bemd_0(-752973622);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(-929839053, bevt_38_ta_ph);
bevl_tany = bevt_36_ta_ph.bemd_0(1549292086);
} /* Line: 371*/
bevt_40_ta_ph = bevl_tany.bemd_0(-61061249);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 374*/ {
bevl_targNp = bevl_tany.bemd_0(-40164505);
} /* Line: 375*/
} /* Line: 374*/
if (bevl_targNp == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 378*/ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_44_ta_ph = bevl_tcall.bemd_0(1851661563);
bevt_43_ta_ph = bevt_44_ta_ph.bemd_0(-752973622);
bevl_mtdc = bevt_42_ta_ph.bem_get_1(bevt_43_ta_ph);
if (bevl_mtdc == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 382*/ {
bevl_oany = bevl_mtdc.bemd_0(-1867747200);
if (bevl_oany == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 385*/ {
bevt_47_ta_ph = bevl_oany.bemd_0(-61061249);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 385*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 385*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 385*/
 else /* Line: 385*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 385*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_ta_ph = bevl_oany.bemd_0(1649805267);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 388*/ {
bevl_nv.bemd_1(503038555, bevl_targNp);
} /* Line: 389*/
 else /* Line: 390*/ {
bevt_49_ta_ph = bevl_oany.bemd_0(-40164505);
bevl_nv.bemd_1(503038555, bevt_49_ta_ph);
} /* Line: 391*/
bevt_50_ta_ph = bevl_oany.bemd_0(-61061249);
bevl_nv.bemd_1(-1680197374, bevt_50_ta_ph);
bevt_51_ta_ph = bevp_inClass.bemd_0(1851661563);
bevt_52_ta_ph = bevl_nv.bemd_0(-40164505);
bevt_51_ta_ph.bemd_1(-882109529, bevt_52_ta_ph);
bevt_55_ta_ph = bevl_nv.bemd_0(-40164505);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(789336479);
bevt_56_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_3));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(-1433542779, bevt_56_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 395*/ {
bevt_58_ta_ph = (new BEC_2_4_6_TextString(27, bece_BEC_3_5_5_6_BuildVisitRewind_bels_4));
bevt_59_ta_ph = bevl_oany.bemd_0(1649805267);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevt_59_ta_ph);
bevt_57_ta_ph.bem_print_0();
} /* Line: 395*/
} /* Line: 395*/
} /* Line: 385*/
 else /* Line: 382*/ {
bevt_62_ta_ph = bevl_tcall.bemd_0(1851661563);
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(1236761075);
bevt_63_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_60_ta_ph = bevt_61_ta_ph.bemd_1(1481679760, bevt_63_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_60_ta_ph).bevi_bool)/* Line: 397*/ {
bevt_64_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_65_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_6));
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_ta_ph.bem_get_1(bevt_65_ta_ph);
if (bevl_fcms == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 399*/ {
bevt_69_ta_ph = bevl_fcms.bem_originGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_toString_0();
bevt_70_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_7));
bevt_67_ta_ph = bevt_68_ta_ph.bem_notEquals_1(bevt_70_ta_ph);
if (bevt_67_ta_ph.bevi_bool)/* Line: 399*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 399*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 399*/
 else /* Line: 399*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 399*/ {
bevt_71_ta_ph = bevl_tcall.bemd_0(1851661563);
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
bevt_71_ta_ph.bemd_1(651633449, bevt_72_ta_ph);
} /* Line: 400*/
 else /* Line: 401*/ {
bevt_77_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_3_5_5_6_BuildVisitRewind_bels_8));
bevt_79_ta_ph = bevl_tcall.bemd_0(1851661563);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(-752973622);
bevt_76_ta_ph = bevt_77_ta_ph.bem_add_1(bevt_78_ta_ph);
bevt_80_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitRewind_bels_9));
bevt_75_ta_ph = bevt_76_ta_ph.bem_add_1(bevt_80_ta_ph);
bevt_81_ta_ph = bevl_targNp.bemd_0(789336479);
bevt_74_ta_ph = bevt_75_ta_ph.bem_add_1(bevt_81_ta_ph);
bevt_73_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_ta_ph, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_ta_ph);
} /* Line: 402*/
} /* Line: 399*/
} /* Line: 382*/
} /* Line: 382*/
} /* Line: 378*/
 else /* Line: 360*/ {
bevt_82_ta_ph = bevl_k.bemd_0(-1973919641);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 408*/ {
bevt_85_ta_ph = bevl_k.bemd_0(-1936293836);
bevt_84_ta_ph = bevt_85_ta_ph.bemd_0(818419601);
bevt_86_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_1(-1433542779, bevt_86_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_83_ta_ph).bevi_bool)/* Line: 408*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 408*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 408*/
 else /* Line: 408*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 408*/ {
bevt_90_ta_ph = bevl_k.bemd_0(-1936293836);
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(1851661563);
bevt_88_ta_ph = bevt_89_ta_ph.bemd_0(1236761075);
bevt_91_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_87_ta_ph = bevt_88_ta_ph.bemd_1(-1433542779, bevt_91_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 408*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 408*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 408*/
 else /* Line: 408*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 408*/ {
bevt_95_ta_ph = bevl_k.bemd_0(-1936293836);
bevt_94_ta_ph = bevt_95_ta_ph.bemd_0(2038210307);
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(818419601);
bevt_96_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_92_ta_ph = bevt_93_ta_ph.bemd_1(-1433542779, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_92_ta_ph).bevi_bool)/* Line: 408*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 408*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 408*/
 else /* Line: 408*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 408*/ {
bevt_98_ta_ph = bevl_k.bemd_0(-1936293836);
bevt_97_ta_ph = bevt_98_ta_ph.bemd_0(2038210307);
bevl_targ = bevt_97_ta_ph.bemd_0(1851661563);
bevt_99_ta_ph = bevl_targ.bemd_0(-61061249);
if (((BEC_2_5_4_LogicBool) bevt_99_ta_ph).bevi_bool)/* Line: 411*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_ta_ph = bevl_targ.bemd_0(-61061249);
bevl_nv.bemd_1(-1680197374, bevt_100_ta_ph);
bevt_101_ta_ph = bevl_targ.bemd_0(-40164505);
bevl_nv.bemd_1(503038555, bevt_101_ta_ph);
} /* Line: 416*/
} /* Line: 411*/
} /* Line: 360*/
} /* Line: 360*/
 else /* Line: 359*/ {
break;
} /* Line: 359*/
} /* Line: 359*/
} /* Line: 359*/
} /* Line: 354*/
 else /* Line: 351*/ {
break;
} /* Line: 351*/
} /* Line: 351*/
} /* Line: 351*/
 else /* Line: 349*/ {
break;
} /* Line: 349*/
} /* Line: 349*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tvmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClass = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nl = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {295, 295, 295, 295, 296, 296, 298, 298, 298, 298, 298, 298, 0, 0, 0, 300, 300, 300, 300, 300, 300, 300, 300, 300, 300, 0, 0, 0, 300, 0, 0, 0, 302, 302, 302, 302, 302, 302, 302, 302, 302, 0, 0, 0, 303, 303, 303, 303, 304, 304, 305, 305, 305, 305, 305, 305, 305, 305, 305, 307, 308, 308, 308, 308, 309, 309, 311, 311, 312, 312, 312, 312, 317, 317, 317, 317, 318, 319, 319, 320, 320, 322, 322, 322, 322, 323, 324, 325, 325, 325, 325, 325, 325, 0, 0, 0, 326, 326, 326, 326, 327, 327, 327, 328, 328, 329, 330, 330, 330, 332, 333, 333, 333, 333, 333, 333, 333, 0, 0, 0, 333, 333, 333, 333, 0, 0, 0, 333, 333, 333, 333, 333, 333, 0, 0, 0, 335, 337, 337, 341, 350, 351, 351, 352, 354, 354, 357, 358, 359, 0, 359, 359, 360, 360, 360, 360, 360, 0, 0, 0, 360, 360, 360, 360, 360, 0, 0, 0, 360, 360, 360, 360, 360, 0, 0, 0, 362, 362, 363, 364, 364, 364, 364, 365, 365, 367, 367, 368, 368, 369, 371, 371, 371, 371, 371, 374, 375, 378, 378, 380, 381, 381, 381, 381, 382, 382, 384, 385, 385, 385, 0, 0, 0, 386, 388, 389, 391, 391, 393, 393, 394, 394, 394, 395, 395, 395, 395, 395, 395, 395, 395, 397, 397, 397, 397, 398, 398, 398, 399, 399, 399, 399, 399, 399, 0, 0, 0, 400, 400, 400, 402, 402, 402, 402, 402, 402, 402, 402, 402, 402, 408, 408, 408, 408, 408, 0, 0, 0, 408, 408, 408, 408, 408, 0, 0, 0, 408, 408, 408, 408, 408, 0, 0, 0, 409, 409, 409, 411, 413, 415, 415, 416, 416, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {129, 130, 131, 136, 137, 138, 140, 141, 142, 147, 148, 149, 151, 154, 158, 161, 162, 163, 164, 169, 170, 171, 172, 173, 174, 176, 179, 183, 186, 188, 191, 195, 198, 199, 200, 201, 202, 204, 205, 206, 207, 209, 212, 216, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 244, 245, 246, 247, 248, 249, 250, 255, 256, 257, 262, 263, 264, 265, 266, 267, 269, 270, 271, 276, 277, 278, 281, 282, 283, 288, 289, 290, 292, 295, 299, 302, 303, 304, 305, 306, 307, 308, 309, 314, 315, 316, 317, 318, 320, 323, 324, 325, 330, 331, 332, 337, 338, 341, 345, 348, 349, 350, 355, 356, 359, 363, 366, 367, 368, 369, 370, 375, 376, 379, 383, 386, 390, 391, 510, 514, 515, 518, 520, 521, 522, 524, 525, 526, 526, 529, 531, 532, 534, 535, 536, 537, 539, 542, 546, 549, 550, 551, 552, 553, 555, 558, 562, 565, 566, 567, 568, 569, 571, 574, 578, 581, 582, 583, 584, 585, 586, 591, 592, 593, 596, 597, 598, 599, 601, 604, 605, 606, 607, 608, 610, 612, 615, 620, 621, 622, 623, 624, 625, 626, 631, 632, 633, 638, 639, 641, 644, 648, 651, 652, 654, 657, 658, 660, 661, 662, 663, 664, 665, 666, 667, 668, 670, 671, 672, 673, 678, 679, 680, 681, 683, 684, 685, 686, 691, 692, 693, 694, 695, 697, 700, 704, 707, 708, 709, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 728, 730, 731, 732, 733, 735, 738, 742, 745, 746, 747, 748, 749, 751, 754, 758, 761, 762, 763, 764, 765, 767, 770, 774, 777, 778, 779, 780, 782, 783, 784, 785, 786, 809, 812, 816, 819, 823, 826, 830, 833, 837, 840, 844, 847, 851, 854};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 295 129
typenameGet 0 295 129
assign 1 295 130
IFEMITGet 0 295 130
assign 1 295 131
equals 1 295 136
assign 1 296 137
acceptIfEmit 1 296 137
return 1 296 138
assign 1 298 140
typenameGet 0 298 140
assign 1 298 141
CALLGet 0 298 141
assign 1 298 142
equals 1 298 147
assign 1 298 148
heldGet 0 298 148
assign 1 298 149
wasForeachGennedGet 0 298 149
assign 1 0 151
assign 1 0 154
assign 1 0 158
assign 1 300 161
containerGet 0 300 161
assign 1 300 162
typenameGet 0 300 162
assign 1 300 163
CALLGet 0 300 163
assign 1 300 164
equals 1 300 169
assign 1 300 170
containerGet 0 300 170
assign 1 300 171
heldGet 0 300 171
assign 1 300 172
orgNameGet 0 300 172
assign 1 300 173
new 0 300 173
assign 1 300 174
equals 1 300 174
assign 1 0 176
assign 1 0 179
assign 1 0 183
assign 1 300 186
isSecondGet 0 300 186
assign 1 0 188
assign 1 0 191
assign 1 0 195
assign 1 302 198
containedGet 0 302 198
assign 1 302 199
firstGet 0 302 199
assign 1 302 200
typenameGet 0 302 200
assign 1 302 201
VARGet 0 302 201
assign 1 302 202
equals 1 302 202
assign 1 302 204
containedGet 0 302 204
assign 1 302 205
firstGet 0 302 205
assign 1 302 206
heldGet 0 302 206
assign 1 302 207
isTypedGet 0 302 207
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 303 219
containedGet 0 303 219
assign 1 303 220
firstGet 0 303 220
assign 1 303 221
heldGet 0 303 221
assign 1 303 222
namepathGet 0 303 222
assign 1 304 223
stepsGet 0 304 223
assign 1 304 224
lastGet 0 304 224
assign 1 305 225
new 0 305 225
assign 1 305 226
new 0 305 226
assign 1 305 227
substring 2 305 227
assign 1 305 228
lowerValue 0 305 228
assign 1 305 229
new 0 305 229
assign 1 305 230
substring 1 305 230
assign 1 305 231
add 1 305 231
assign 1 305 232
new 0 305 232
assign 1 305 233
add 1 305 233
assign 1 307 234
getSynNp 1 307 234
assign 1 308 235
mtdMapGet 0 308 235
assign 1 308 236
new 0 308 236
assign 1 308 237
add 1 308 237
assign 1 308 238
get 1 308 238
assign 1 309 239
def 1 309 244
assign 1 311 245
heldGet 0 311 245
orgNameSet 1 311 246
assign 1 312 247
heldGet 0 312 247
assign 1 312 248
new 0 312 248
assign 1 312 249
add 1 312 249
nameSet 1 312 250
assign 1 317 255
typenameGet 0 317 255
assign 1 317 256
CLASSGet 0 317 256
assign 1 317 257
equals 1 317 262
assign 1 318 263
assign 1 319 264
heldGet 0 319 264
assign 1 319 265
namepathGet 0 319 265
assign 1 320 266
heldGet 0 320 266
assign 1 320 267
synGet 0 320 267
assign 1 322 269
typenameGet 0 322 269
assign 1 322 270
METHODGet 0 322 270
assign 1 322 271
equals 1 322 276
assign 1 323 277
new 0 323 277
assign 1 324 278
new 0 324 278
assign 1 325 281
typenameGet 0 325 281
assign 1 325 282
VARGet 0 325 282
assign 1 325 283
equals 1 325 288
assign 1 325 289
heldGet 0 325 289
assign 1 325 290
autoTypeGet 0 325 290
assign 1 0 292
assign 1 0 295
assign 1 0 299
assign 1 326 302
heldGet 0 326 302
assign 1 326 303
nameGet 0 326 303
assign 1 326 304
heldGet 0 326 304
put 2 326 305
assign 1 327 306
heldGet 0 327 306
assign 1 327 307
nameGet 0 327 307
assign 1 327 308
get 1 327 308
assign 1 328 309
undef 1 328 314
assign 1 329 315
new 0 329 315
assign 1 330 316
heldGet 0 330 316
assign 1 330 317
nameGet 0 330 317
put 2 330 318
addValue 1 332 320
assign 1 333 323
typenameGet 0 333 323
assign 1 333 324
RBRACESGet 0 333 324
assign 1 333 325
equals 1 333 330
assign 1 333 331
containerGet 0 333 331
assign 1 333 332
def 1 333 337
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 333 348
containerGet 0 333 348
assign 1 333 349
containerGet 0 333 349
assign 1 333 350
def 1 333 355
assign 1 0 356
assign 1 0 359
assign 1 0 363
assign 1 333 366
containerGet 0 333 366
assign 1 333 367
containerGet 0 333 367
assign 1 333 368
typenameGet 0 333 368
assign 1 333 369
METHODGet 0 333 369
assign 1 333 370
equals 1 333 375
assign 1 0 376
assign 1 0 379
assign 1 0 383
processTmps 0 335 386
assign 1 337 390
nextDescendGet 0 337 390
return 1 337 391
assign 1 341 510
new 0 341 510
assign 1 350 514
new 0 350 514
assign 1 351 515
valueIteratorGet 0 351 515
assign 1 351 518
hasNextGet 0 351 518
assign 1 352 520
nextGet 0 352 520
assign 1 354 521
isTypedGet 0 354 521
assign 1 354 522
not 0 354 522
assign 1 357 524
nameGet 0 357 524
assign 1 358 525
get 1 358 525
assign 1 359 526
iteratorGet 0 0 526
assign 1 359 529
hasNextGet 0 359 529
assign 1 359 531
nextGet 0 359 531
assign 1 360 532
isFirstGet 0 360 532
assign 1 360 534
containerGet 0 360 534
assign 1 360 535
typenameGet 0 360 535
assign 1 360 536
CALLGet 0 360 536
assign 1 360 537
equals 1 360 537
assign 1 0 539
assign 1 0 542
assign 1 0 546
assign 1 360 549
containerGet 0 360 549
assign 1 360 550
heldGet 0 360 550
assign 1 360 551
orgNameGet 0 360 551
assign 1 360 552
new 0 360 552
assign 1 360 553
equals 1 360 553
assign 1 0 555
assign 1 0 558
assign 1 0 562
assign 1 360 565
containerGet 0 360 565
assign 1 360 566
secondGet 0 360 566
assign 1 360 567
typenameGet 0 360 567
assign 1 360 568
CALLGet 0 360 568
assign 1 360 569
equals 1 360 569
assign 1 0 571
assign 1 0 574
assign 1 0 578
assign 1 362 581
containerGet 0 362 581
assign 1 362 582
secondGet 0 362 582
assign 1 363 583
assign 1 364 584
heldGet 0 364 584
assign 1 364 585
newNpGet 0 364 585
assign 1 364 586
def 1 364 591
assign 1 365 592
heldGet 0 365 592
assign 1 365 593
newNpGet 0 365 593
assign 1 367 596
containedGet 0 367 596
assign 1 367 597
firstGet 0 367 597
assign 1 368 598
heldGet 0 368 598
assign 1 368 599
isDeclaredGet 0 368 599
assign 1 369 601
heldGet 0 369 601
assign 1 371 604
ptyMapGet 0 371 604
assign 1 371 605
heldGet 0 371 605
assign 1 371 606
nameGet 0 371 606
assign 1 371 607
get 1 371 607
assign 1 371 608
memSynGet 0 371 608
assign 1 374 610
isTypedGet 0 374 610
assign 1 375 612
namepathGet 0 375 612
assign 1 378 615
def 1 378 620
assign 1 380 621
getSynNp 1 380 621
assign 1 381 622
mtdMapGet 0 381 622
assign 1 381 623
heldGet 0 381 623
assign 1 381 624
nameGet 0 381 624
assign 1 381 625
get 1 381 625
assign 1 382 626
def 1 382 631
assign 1 384 632
rsynGet 0 384 632
assign 1 385 633
def 1 385 638
assign 1 385 639
isTypedGet 0 385 639
assign 1 0 641
assign 1 0 644
assign 1 0 648
assign 1 386 651
new 0 386 651
assign 1 388 652
isSelfGet 0 388 652
namepathSet 1 389 654
assign 1 391 657
namepathGet 0 391 657
namepathSet 1 391 658
assign 1 393 660
isTypedGet 0 393 660
isTypedSet 1 393 661
assign 1 394 662
heldGet 0 394 662
assign 1 394 663
namepathGet 0 394 663
addUsed 1 394 664
assign 1 395 665
namepathGet 0 395 665
assign 1 395 666
toString 0 395 666
assign 1 395 667
new 0 395 667
assign 1 395 668
equals 1 395 668
assign 1 395 670
new 0 395 670
assign 1 395 671
isSelfGet 0 395 671
assign 1 395 672
add 1 395 672
print 0 395 673
assign 1 397 678
heldGet 0 397 678
assign 1 397 679
orgNameGet 0 397 679
assign 1 397 680
new 0 397 680
assign 1 397 681
notEquals 1 397 681
assign 1 398 683
mtdMapGet 0 398 683
assign 1 398 684
new 0 398 684
assign 1 398 685
get 1 398 685
assign 1 399 686
def 1 399 691
assign 1 399 692
originGet 0 399 692
assign 1 399 693
toString 0 399 693
assign 1 399 694
new 0 399 694
assign 1 399 695
notEquals 1 399 695
assign 1 0 697
assign 1 0 700
assign 1 0 704
assign 1 400 707
heldGet 0 400 707
assign 1 400 708
new 0 400 708
isForwardSet 1 400 709
assign 1 402 712
new 0 402 712
assign 1 402 713
heldGet 0 402 713
assign 1 402 714
nameGet 0 402 714
assign 1 402 715
add 1 402 715
assign 1 402 716
new 0 402 716
assign 1 402 717
add 1 402 717
assign 1 402 718
toString 0 402 718
assign 1 402 719
add 1 402 719
assign 1 402 720
new 2 402 720
throw 1 402 721
assign 1 408 728
isFirstGet 0 408 728
assign 1 408 730
containerGet 0 408 730
assign 1 408 731
typenameGet 0 408 731
assign 1 408 732
CALLGet 0 408 732
assign 1 408 733
equals 1 408 733
assign 1 0 735
assign 1 0 738
assign 1 0 742
assign 1 408 745
containerGet 0 408 745
assign 1 408 746
heldGet 0 408 746
assign 1 408 747
orgNameGet 0 408 747
assign 1 408 748
new 0 408 748
assign 1 408 749
equals 1 408 749
assign 1 0 751
assign 1 0 754
assign 1 0 758
assign 1 408 761
containerGet 0 408 761
assign 1 408 762
secondGet 0 408 762
assign 1 408 763
typenameGet 0 408 763
assign 1 408 764
VARGet 0 408 764
assign 1 408 765
equals 1 408 765
assign 1 0 767
assign 1 0 770
assign 1 0 774
assign 1 409 777
containerGet 0 409 777
assign 1 409 778
secondGet 0 409 778
assign 1 409 779
heldGet 0 409 779
assign 1 411 780
isTypedGet 0 411 780
assign 1 413 782
new 0 413 782
assign 1 415 783
isTypedGet 0 415 783
isTypedSet 1 415 784
assign 1 416 785
namepathGet 0 416 785
namepathSet 1 416 786
return 1 0 809
assign 1 0 812
return 1 0 816
assign 1 0 819
return 1 0 823
assign 1 0 826
return 1 0 830
assign 1 0 833
return 1 0 837
assign 1 0 840
return 1 0 844
assign 1 0 847
return 1 0 851
assign 1 0 854
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2078565233: return bem_emitterGet_0();
case 789336479: return bem_toString_0();
case 784610327: return bem_buildGet_0();
case -643635560: return bem_inClassSynGet_0();
case 164501841: return bem_ntypesGet_0();
case -1062524217: return bem_create_0();
case 44114534: return bem_nlGet_0();
case 1000052795: return bem_hashGet_0();
case 66953015: return bem_iteratorGet_0();
case 934884796: return bem_transGet_0();
case -946279007: return bem_tvmapGet_0();
case 2065944448: return bem_constGet_0();
case -2087126981: return bem_processTmps_0();
case 2000478246: return bem_rmapGet_0();
case 401546844: return bem_copy_0();
case -251818580: return bem_inClassNpGet_0();
case -2117173126: return bem_new_0();
case -1934249204: return bem_print_0();
case 724269263: return bem_inClassGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 340281309: return bem_buildSet_1(bevd_0);
case -2092045843: return bem_rmapSet_1(bevd_0);
case -181970790: return bem_ntypesSet_1(bevd_0);
case -1936766817: return bem_def_1(bevd_0);
case -75109176: return bem_inClassNpSet_1(bevd_0);
case 295243406: return bem_tvmapSet_1(bevd_0);
case 1307562699: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1303657077: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2031785230: return bem_inClassSynSet_1(bevd_0);
case -1452071763: return bem_copyTo_1(bevd_0);
case 1825279481: return bem_undef_1(bevd_0);
case 925473201: return bem_nlSet_1(bevd_0);
case -1280174550: return bem_inClassSet_1(bevd_0);
case -936354540: return bem_end_1(bevd_0);
case 486658923: return bem_transSet_1(bevd_0);
case 1481679760: return bem_notEquals_1(bevd_0);
case 1803852079: return bem_emitterSet_1(bevd_0);
case 1755900437: return bem_begin_1(bevd_0);
case -1433542779: return bem_equals_1(bevd_0);
case 987506121: return bem_constSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1895247931: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 572178426: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1090949571: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -76193545: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
