package be;
/* IO:File: source/build/Pass9.be */
public final class BEC_3_5_5_5_BuildVisitPass9 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_2 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_3 = {0x47,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_4 = {0x70,0x75,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_5 = {0x67,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_6 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_7 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_8 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_9 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_10 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_11 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_12 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static BEC_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;

public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_5_4_BuildNode bevl_linn = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lany = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_23_ta_ph = null;
BEC_2_5_4_BuildNode bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_5_4_BuildNode bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_5_4_BuildNode bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_5_4_BuildNode bevt_45_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_5_4_BuildNode bevt_50_ta_ph = null;
BEC_2_5_4_BuildNode bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_5_4_BuildNode bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_3_MathInt bevt_56_ta_ph = null;
BEC_2_5_4_LogicBool bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_5_4_BuildNode bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_5_4_BuildNode bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_BuildNode bevt_68_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_5_4_BuildNode bevt_73_ta_ph = null;
BEC_2_5_4_BuildNode bevt_74_ta_ph = null;
BEC_2_5_4_BuildNode bevt_75_ta_ph = null;
BEC_2_5_4_BuildNode bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_5_4_BuildNode bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_3_MathInt bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_4_3_MathInt bevt_93_ta_ph = null;
BEC_2_4_3_MathInt bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_3_MathInt bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_3_MathInt bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_3_MathInt bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_4_3_MathInt bevt_109_ta_ph = null;
BEC_2_4_3_MathInt bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_3_MathInt bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_4_3_MathInt bevt_115_ta_ph = null;
BEC_2_4_3_MathInt bevt_116_ta_ph = null;
BEC_2_4_3_MathInt bevt_117_ta_ph = null;
BEC_2_4_3_MathInt bevt_118_ta_ph = null;
BEC_2_4_3_MathInt bevt_119_ta_ph = null;
BEC_2_5_4_LogicBool bevt_120_ta_ph = null;
BEC_2_6_6_SystemObject bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_6_6_SystemObject bevt_123_ta_ph = null;
BEC_2_4_6_TextString bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_3_MathInt bevt_126_ta_ph = null;
BEC_2_4_3_MathInt bevt_127_ta_ph = null;
BEC_2_4_3_MathInt bevt_128_ta_ph = null;
BEC_2_6_6_SystemObject bevt_129_ta_ph = null;
BEC_2_5_4_LogicBool bevt_130_ta_ph = null;
BEC_2_4_3_MathInt bevt_131_ta_ph = null;
BEC_2_4_3_MathInt bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_134_ta_ph = null;
BEC_2_6_6_SystemObject bevt_135_ta_ph = null;
BEC_2_6_6_SystemObject bevt_136_ta_ph = null;
BEC_2_6_6_SystemObject bevt_137_ta_ph = null;
BEC_2_4_3_MathInt bevt_138_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_139_ta_ph = null;
BEC_2_4_6_TextString bevt_140_ta_ph = null;
BEC_2_6_6_SystemObject bevt_141_ta_ph = null;
BEC_2_6_6_SystemObject bevt_142_ta_ph = null;
BEC_2_6_6_SystemObject bevt_143_ta_ph = null;
BEC_2_6_6_SystemObject bevt_144_ta_ph = null;
BEC_2_4_3_MathInt bevt_145_ta_ph = null;
BEC_2_4_3_MathInt bevt_146_ta_ph = null;
BEC_2_4_3_MathInt bevt_147_ta_ph = null;
BEC_2_5_4_LogicBool bevt_148_ta_ph = null;
BEC_2_6_6_SystemObject bevt_149_ta_ph = null;
BEC_2_6_6_SystemObject bevt_150_ta_ph = null;
BEC_2_4_3_MathInt bevt_151_ta_ph = null;
BEC_2_4_3_MathInt bevt_152_ta_ph = null;
BEC_2_4_3_MathInt bevt_153_ta_ph = null;
BEC_2_5_4_BuildNode bevt_154_ta_ph = null;
bevt_7_ta_ph = beva_node.bem_typenameGet_0();
bevt_8_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_7_ta_ph.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 30*/ {
beva_node.bem_initContained_0();
bevt_9_ta_ph = beva_node.bem_containedGet_0();
bevl_it = bevt_9_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 35*/ {
bevt_10_ta_ph = bevl_it.bemd_0(88707603);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 35*/ {
bevl_i = bevl_it.bemd_0(99596078);
bevt_12_ta_ph = bevl_i.bemd_0(-527558076);
bevt_13_ta_ph = bevp_ntypes.bem_PARENSGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(-229960022, bevt_13_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 38*/ {
bevt_16_ta_ph = bevl_i.bemd_0(1282288993);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1660531166);
if (bevt_15_ta_ph == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_18_ta_ph = bevl_i.bemd_0(1282288993);
bevt_17_ta_ph = bevt_18_ta_ph.bemd_0(385767243);
bevl_i.bemd_1(541728813, bevt_17_ta_ph);
bevl_i.bemd_0(1789188861);
} /* Line: 41*/
 else /* Line: 42*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(44, bece_BEC_3_5_5_5_BuildVisitPass9_bels_0));
bevt_22_ta_ph = bevl_i.bemd_0(1282288993);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(1376202907);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(-437991849);
bevl_estr = bevt_19_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_23_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BECS_ThrowBack(bevt_23_ta_ph);
} /* Line: 44*/
} /* Line: 39*/
} /* Line: 38*/
 else /* Line: 35*/ {
break;
} /* Line: 35*/
} /* Line: 35*/
bevt_24_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_24_ta_ph;
} /* Line: 48*/
 else /* Line: 30*/ {
bevt_26_ta_ph = beva_node.bem_typenameGet_0();
bevt_27_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_26_ta_ph.bevi_int == bevt_27_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 49*/ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
bevl_c.bemd_1(1098845862, bevt_28_ta_ph);
bevt_31_ta_ph = beva_node.bem_containerGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_typenameGet_0();
bevt_32_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_ta_ph.bevi_int == bevt_32_ta_ph.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 56*/ {
bevt_36_ta_ph = beva_node.bem_containerGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_heldGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(1027189297);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_33_ta_ph = bevt_34_ta_ph.bemd_1(-229960022, bevt_37_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 56*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 56*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 56*/
 else /* Line: 56*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 56*/ {
bevt_38_ta_ph = beva_node.bem_isFirstGet_0();
if (bevt_38_ta_ph.bevi_bool)/* Line: 56*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 56*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 56*/
 else /* Line: 56*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 56*/ {
bevt_39_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevl_c.bemd_1(-1760640825, bevt_39_ta_ph);
} /* Line: 57*/
 else /* Line: 58*/ {
bevt_40_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_3));
bevl_c.bemd_1(-1760640825, bevt_40_ta_ph);
} /* Line: 59*/
bevt_41_ta_ph = bevl_ac.bemd_0(1027189297);
bevl_c.bemd_1(691915948, bevt_41_ta_ph);
bevl_c.bemd_0(-1423832566);
bevt_43_ta_ph = bevl_c.bemd_0(833916467);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevt_42_ta_ph = bevt_43_ta_ph.bemd_1(-229960022, bevt_44_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 63*/ {
bevt_45_ta_ph = beva_node.bem_containerGet_0();
bevt_45_ta_ph.bem_heldSet_1(bevl_c);
bevt_46_ta_ph = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_46_ta_ph.bem_firstGet_0();
bevt_47_ta_ph = bevl_ntarg.bemd_0(-527558076);
beva_node.bem_typenameSet_1(bevt_47_ta_ph);
bevt_48_ta_ph = bevl_ntarg.bemd_0(1445327493);
beva_node.bem_heldSet_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevl_ntarg.bemd_0(1282288993);
beva_node.bem_containedSet_1(bevt_49_ta_ph);
bevt_51_ta_ph = beva_node.bem_containerGet_0();
bevt_50_ta_ph = bevt_51_ta_ph.bem_nextDescendGet_0();
return bevt_50_ta_ph;
} /* Line: 70*/
 else /* Line: 71*/ {
bevt_52_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_52_ta_ph);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 73*/
bevt_53_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_53_ta_ph;
} /* Line: 75*/
 else /* Line: 30*/ {
bevt_55_ta_ph = beva_node.bem_typenameGet_0();
bevt_56_ta_ph = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_55_ta_ph.bevi_int == bevt_56_ta_ph.bevi_int) {
bevt_54_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_54_ta_ph.bevi_bool)/* Line: 76*/ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_59_ta_ph = beva_node.bem_containerGet_0();
bevt_58_ta_ph = bevt_59_ta_ph.bem_typenameGet_0();
bevt_60_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_58_ta_ph.bevi_int == bevt_60_ta_ph.bevi_int) {
bevt_57_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_57_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_64_ta_ph = beva_node.bem_containerGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bem_heldGet_0();
bevt_62_ta_ph = bevt_63_ta_ph.bemd_0(1027189297);
bevt_65_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_61_ta_ph = bevt_62_ta_ph.bemd_1(-229960022, bevt_65_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 80*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 80*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 80*/
 else /* Line: 80*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 80*/ {
bevt_66_ta_ph = beva_node.bem_isFirstGet_0();
if (bevt_66_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 80*/
 else /* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 80*/ {
bevl_isPut = be.BECS_Runtime.boolTrue;
} /* Line: 82*/
 else /* Line: 83*/ {
bevl_isPut = be.BECS_Runtime.boolFalse;
} /* Line: 85*/
if (((BEC_2_5_4_LogicBool) bevl_isPut).bevi_bool)/* Line: 87*/ {
bevt_67_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_4));
bevl_c.bemd_1(691915948, bevt_67_ta_ph);
bevt_68_ta_ph = beva_node.bem_containerGet_0();
bevt_68_ta_ph.bem_heldSet_1(bevl_c);
bevt_69_ta_ph = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_69_ta_ph.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(1965640279);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_70_ta_ph = bevl_ntarg.bemd_0(-527558076);
beva_node.bem_typenameSet_1(bevt_70_ta_ph);
bevt_71_ta_ph = bevl_ntarg.bemd_0(1445327493);
beva_node.bem_heldSet_1(bevt_71_ta_ph);
bevt_72_ta_ph = bevl_ntarg.bemd_0(1282288993);
beva_node.bem_containedSet_1(bevt_72_ta_ph);
bevt_73_ta_ph = beva_node.bem_containerGet_0();
bevt_73_ta_ph.bem_addValue_1(bevl_narg2);
bevt_74_ta_ph = beva_node.bem_containerGet_0();
bevt_74_ta_ph.bem_addValue_1(bevl_narg3);
bevt_76_ta_ph = beva_node.bem_containerGet_0();
bevt_75_ta_ph = bevt_76_ta_ph.bem_nextDescendGet_0();
return bevt_75_ta_ph;
} /* Line: 105*/
 else /* Line: 106*/ {
bevt_77_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_5));
bevl_c.bemd_1(691915948, bevt_77_ta_ph);
bevt_78_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_78_ta_ph);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 113*/
bevt_79_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_79_ta_ph;
} /* Line: 115*/
} /* Line: 30*/
} /* Line: 30*/
bevt_81_ta_ph = beva_node.bem_typenameGet_0();
bevt_82_ta_ph = bevp_ntypes.bem_FORGet_0();
if (bevt_81_ta_ph.bevi_int == bevt_82_ta_ph.bevi_int) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 117*/ {
bevt_85_ta_ph = beva_node.bem_containedGet_0();
bevt_84_ta_ph = bevt_85_ta_ph.bem_firstGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_0(1282288993);
bevl_linn = (BEC_2_5_4_BuildNode) bevt_83_ta_ph.bemd_0(385767243);
bevt_87_ta_ph = bevl_linn.bem_typenameGet_0();
bevt_88_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_87_ta_ph.bevi_int == bevt_88_ta_ph.bevi_int) {
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 120*/ {
bevt_90_ta_ph = bevl_linn.bem_heldGet_0();
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(1186812006);
if (((BEC_2_5_4_LogicBool) bevt_89_ta_ph).bevi_bool)/* Line: 120*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 120*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 120*/
 else /* Line: 120*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 120*/ {
bevt_91_ta_ph = bevp_ntypes.bem_FOREACHGet_0();
beva_node.bem_typenameSet_1(bevt_91_ta_ph);
} /* Line: 122*/
} /* Line: 120*/
bevt_93_ta_ph = beva_node.bem_typenameGet_0();
bevt_94_ta_ph = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_93_ta_ph.bevi_int == bevt_94_ta_ph.bevi_int) {
bevt_92_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_92_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_95_ta_ph = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_95_ta_ph);
bevt_96_ta_ph = beva_node.bem_containedGet_0();
bevl_pnode = bevt_96_ta_ph.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_97_ta_ph = bevl_pnode.bemd_0(1282288993);
bevl_lin = bevt_97_ta_ph.bemd_0(385767243);
bevt_98_ta_ph = bevl_lin.bemd_0(1282288993);
bevl_lany = bevt_98_ta_ph.bemd_0(385767243);
bevl_toit = bevl_lin.bemd_0(-803988646);
bevl_pnode.bemd_1(1792763184, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(1154526965, beva_node);
bevt_99_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(-336968946, bevt_99_ta_ph);
bevt_100_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass9_bels_6));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_100_ta_ph, bevp_build);
bevl_tmpn.bemd_1(-701315059, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_101_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(-336968946, bevt_101_ta_ph);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(-701315059, bevl_gic);
bevt_102_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass9_bels_7));
bevl_gic.bemd_1(691915948, bevt_102_ta_ph);
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(1778197464, bevt_103_ta_ph);
bevl_gin.bemd_1(484846534, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1154526965, beva_node);
bevt_104_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(-336968946, bevt_104_ta_ph);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(-701315059, bevl_asc);
bevt_105_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevl_asc.bemd_1(691915948, bevt_105_ta_ph);
bevl_asn.bemd_1(484846534, bevl_tmpn);
bevl_asn.bemd_1(484846534, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn );
bevl_tmpn.bemd_0(-561980568);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1154526965, beva_node);
bevt_106_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(-336968946, bevt_106_ta_ph);
bevl_tmpnt.bemd_1(-701315059, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(1154526965, beva_node);
bevt_107_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(-336968946, bevt_107_ta_ph);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(-701315059, bevl_tcc);
bevt_108_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass9_bels_8));
bevl_tcc.bemd_1(691915948, bevt_108_ta_ph);
bevl_tcn.bemd_1(484846534, bevl_tmpnt);
bevl_pnode.bemd_1(484846534, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(1154526965, beva_node);
bevt_109_ta_ph = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(-336968946, bevt_109_ta_ph);
bevl_tmpng.bemd_1(-701315059, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(1154526965, beva_node);
bevt_110_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(-336968946, bevt_110_ta_ph);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(-701315059, bevl_iagc);
bevt_111_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass9_bels_9));
bevl_iagc.bemd_1(691915948, bevt_111_ta_ph);
bevl_iagn.bemd_1(484846534, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(1154526965, beva_node);
bevt_112_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(-336968946, bevt_112_ta_ph);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(-701315059, bevl_iasc);
bevt_113_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevl_iasc.bemd_1(691915948, bevt_113_ta_ph);
bevl_iasn.bemd_1(484846534, bevl_lany);
bevl_iasn.bemd_1(484846534, bevl_iagn);
bevl_brnode.bemd_1(428570072, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 215*/
bevt_115_ta_ph = beva_node.bem_typenameGet_0();
bevt_116_ta_ph = bevp_ntypes.bem_WHILEGet_0();
if (bevt_115_ta_ph.bevi_int == bevt_116_ta_ph.bevi_int) {
bevt_114_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_114_ta_ph.bevi_bool)/* Line: 217*/ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1154526965, beva_node);
bevt_117_ta_ph = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-336968946, bevt_117_ta_ph);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1154526965, beva_node);
bevt_118_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-336968946, bevt_118_ta_ph);
bevl_lnode.bemd_1(484846534, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_119_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-336968946, bevt_119_ta_ph);
bevl_lbrnode.bemd_1(484846534, bevl_loopif);
bevt_121_ta_ph = beva_node.bem_heldGet_0();
if (bevt_121_ta_ph == null) {
bevt_120_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_120_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_120_ta_ph.bevi_bool)/* Line: 229*/ {
bevt_123_ta_ph = beva_node.bem_heldGet_0();
bevt_124_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass9_bels_10));
bevt_122_ta_ph = bevt_123_ta_ph.bemd_1(-229960022, bevt_124_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_122_ta_ph).bevi_bool)/* Line: 229*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 229*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 229*/
 else /* Line: 229*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 229*/ {
bevt_125_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_11));
bevl_loopif.bemd_1(-701315059, bevt_125_ta_ph);
} /* Line: 230*/
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1154526965, beva_node);
bevt_126_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-336968946, bevt_126_ta_ph);
bevl_loopif.bemd_1(484846534, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1154526965, beva_node);
bevt_127_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-336968946, bevt_127_ta_ph);
bevl_enode.bemd_1(484846534, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1154526965, beva_node);
bevt_128_ta_ph = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-336968946, bevt_128_ta_ph);
bevl_brnode.bemd_1(484846534, bevl_bnode);
bevt_129_ta_ph = bevl_lnode.bemd_0(-1390299978);
return (BEC_2_5_4_BuildNode) bevt_129_ta_ph;
} /* Line: 244*/
 else /* Line: 217*/ {
bevt_131_ta_ph = beva_node.bem_typenameGet_0();
bevt_132_ta_ph = bevp_ntypes.bem_FORGet_0();
if (bevt_131_ta_ph.bevi_int == bevt_132_ta_ph.bevi_int) {
bevt_130_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_130_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_130_ta_ph.bevi_bool)/* Line: 245*/ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1154526965, beva_node);
bevt_133_ta_ph = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(-336968946, bevt_133_ta_ph);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevt_134_ta_ph = beva_node.bem_containedGet_0();
bevl_pnode = bevt_134_ta_ph.bem_firstGet_0();
bevl_pnode.bemd_0(1789188861);
bevt_137_ta_ph = bevl_pnode.bemd_0(1282288993);
bevt_136_ta_ph = bevt_137_ta_ph.bemd_0(1376202907);
bevt_138_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_135_ta_ph = bevt_136_ta_ph.bemd_1(1546459187, bevt_138_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_135_ta_ph).bevi_bool)/* Line: 252*/ {
bevt_140_ta_ph = (new BEC_2_4_6_TextString(55, bece_BEC_3_5_5_5_BuildVisitPass9_bels_12));
bevt_139_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_140_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_139_ta_ph);
} /* Line: 253*/
bevt_141_ta_ph = bevl_pnode.bemd_0(1282288993);
bevl_init = bevt_141_ta_ph.bemd_0(385767243);
bevl_cond = bevl_pnode.bemd_0(-803988646);
bevl_atStep = null;
bevt_144_ta_ph = bevl_pnode.bemd_0(1282288993);
bevt_143_ta_ph = bevt_144_ta_ph.bemd_0(1376202907);
bevt_145_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_142_ta_ph = bevt_143_ta_ph.bemd_1(1968185000, bevt_145_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_142_ta_ph).bevi_bool)/* Line: 258*/ {
bevl_atStep = bevl_pnode.bemd_0(1817512742);
bevl_atStep.bemd_0(1789188861);
} /* Line: 260*/
bevl_init.bemd_0(1789188861);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lnode.bemd_1(541728813, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1154526965, beva_node);
bevt_146_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(-336968946, bevt_146_ta_ph);
bevl_lnode.bemd_1(484846534, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(1154526965, beva_node);
bevt_147_ta_ph = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(-336968946, bevt_147_ta_ph);
bevl_loopif.bemd_1(-1693062488, beva_node);
if (bevl_atStep == null) {
bevt_148_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_148_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_148_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_150_ta_ph = bevl_loopif.bemd_0(1282288993);
bevt_149_ta_ph = bevt_150_ta_ph.bemd_0(385767243);
bevt_149_ta_ph.bemd_1(484846534, bevl_atStep);
} /* Line: 276*/
bevl_loopif.bemd_1(428570072, bevl_pnode);
bevl_lbrnode.bemd_1(484846534, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1154526965, beva_node);
bevt_151_ta_ph = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-336968946, bevt_151_ta_ph);
bevl_loopif.bemd_1(484846534, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1154526965, beva_node);
bevt_152_ta_ph = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(-336968946, bevt_152_ta_ph);
bevl_enode.bemd_1(484846534, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1154526965, beva_node);
bevt_153_ta_ph = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(-336968946, bevt_153_ta_ph);
bevl_brnode.bemd_1(484846534, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 293*/
} /* Line: 217*/
bevt_154_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_154_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {30, 30, 30, 30, 34, 35, 35, 35, 37, 38, 38, 38, 39, 39, 39, 39, 40, 40, 40, 41, 43, 43, 43, 43, 43, 44, 44, 48, 48, 49, 49, 49, 49, 53, 54, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 0, 0, 0, 56, 0, 0, 0, 57, 57, 59, 59, 61, 61, 62, 63, 63, 63, 64, 64, 65, 65, 67, 67, 68, 68, 69, 69, 70, 70, 70, 72, 72, 73, 75, 75, 76, 76, 76, 76, 78, 79, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 0, 0, 0, 80, 0, 0, 0, 82, 85, 88, 88, 89, 89, 90, 90, 93, 94, 96, 97, 99, 99, 100, 100, 101, 101, 103, 103, 104, 104, 105, 105, 105, 111, 111, 112, 112, 113, 115, 115, 117, 117, 117, 117, 119, 119, 119, 119, 120, 120, 120, 120, 120, 120, 0, 0, 0, 122, 122, 125, 125, 125, 125, 126, 126, 127, 127, 128, 129, 129, 130, 130, 131, 132, 151, 152, 153, 153, 154, 154, 155, 157, 158, 158, 159, 160, 161, 161, 162, 162, 163, 165, 166, 167, 167, 168, 169, 170, 170, 171, 172, 174, 175, 177, 178, 179, 179, 180, 182, 183, 184, 184, 185, 186, 187, 187, 188, 190, 192, 193, 194, 194, 195, 197, 198, 199, 199, 200, 201, 202, 202, 203, 205, 206, 207, 207, 208, 209, 210, 210, 211, 212, 214, 215, 217, 217, 217, 217, 218, 219, 220, 220, 221, 222, 223, 224, 224, 225, 226, 227, 227, 228, 229, 229, 229, 229, 229, 229, 0, 0, 0, 230, 230, 232, 233, 234, 234, 235, 236, 237, 238, 238, 239, 240, 241, 242, 242, 243, 244, 244, 245, 245, 245, 245, 246, 247, 248, 248, 249, 250, 250, 251, 252, 252, 252, 252, 253, 253, 253, 255, 255, 256, 257, 258, 258, 258, 258, 259, 260, 262, 264, 265, 267, 268, 269, 269, 270, 271, 272, 273, 273, 274, 275, 275, 276, 276, 276, 278, 279, 280, 281, 282, 282, 283, 284, 285, 286, 286, 287, 288, 289, 290, 290, 291, 293, 295, 295};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {218, 219, 220, 225, 226, 227, 228, 231, 233, 234, 235, 236, 238, 239, 240, 245, 246, 247, 248, 249, 252, 253, 254, 255, 256, 257, 258, 266, 267, 270, 271, 272, 277, 278, 279, 280, 281, 282, 283, 284, 285, 290, 291, 292, 293, 294, 295, 297, 300, 304, 307, 309, 312, 316, 319, 320, 323, 324, 326, 327, 328, 329, 330, 331, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 348, 349, 350, 352, 353, 356, 357, 358, 363, 364, 365, 366, 367, 368, 369, 374, 375, 376, 377, 378, 379, 381, 384, 388, 391, 393, 396, 400, 403, 406, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 434, 435, 436, 437, 438, 440, 441, 445, 446, 447, 452, 453, 454, 455, 456, 457, 458, 459, 464, 465, 466, 468, 471, 475, 478, 479, 482, 483, 484, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 572, 573, 574, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 600, 601, 602, 603, 605, 608, 612, 615, 616, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 637, 638, 639, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 658, 659, 660, 662, 663, 664, 665, 666, 667, 668, 669, 671, 672, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 692, 693, 694, 695, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 717, 718};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 30 218
typenameGet 0 30 218
assign 1 30 219
CALLGet 0 30 219
assign 1 30 220
equals 1 30 225
initContained 0 34 226
assign 1 35 227
containedGet 0 35 227
assign 1 35 228
iteratorGet 0 35 228
assign 1 35 231
hasNextGet 0 35 231
assign 1 37 233
nextGet 0 37 233
assign 1 38 234
typenameGet 0 38 234
assign 1 38 235
PARENSGet 0 38 235
assign 1 38 236
equals 1 38 236
assign 1 39 238
containedGet 0 39 238
assign 1 39 239
firstNodeGet 0 39 239
assign 1 39 240
def 1 39 245
assign 1 40 246
containedGet 0 40 246
assign 1 40 247
firstGet 0 40 247
beforeInsert 1 40 248
delete 0 41 249
assign 1 43 252
new 0 43 252
assign 1 43 253
containedGet 0 43 253
assign 1 43 254
lengthGet 0 43 254
assign 1 43 255
toString 0 43 255
assign 1 43 256
add 1 43 256
assign 1 44 257
new 2 44 257
throw 1 44 258
assign 1 48 266
nextDescendGet 0 48 266
return 1 48 267
assign 1 49 270
typenameGet 0 49 270
assign 1 49 271
ACCESSORGet 0 49 271
assign 1 49 272
equals 1 49 277
assign 1 53 278
heldGet 0 53 278
assign 1 54 279
new 0 54 279
assign 1 55 280
new 0 55 280
wasAccessorSet 1 55 281
assign 1 56 282
containerGet 0 56 282
assign 1 56 283
typenameGet 0 56 283
assign 1 56 284
CALLGet 0 56 284
assign 1 56 285
equals 1 56 290
assign 1 56 291
containerGet 0 56 291
assign 1 56 292
heldGet 0 56 292
assign 1 56 293
nameGet 0 56 293
assign 1 56 294
new 0 56 294
assign 1 56 295
equals 1 56 295
assign 1 0 297
assign 1 0 300
assign 1 0 304
assign 1 56 307
isFirstGet 0 56 307
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 57 319
new 0 57 319
accessorTypeSet 1 57 320
assign 1 59 323
new 0 59 323
accessorTypeSet 1 59 324
assign 1 61 326
nameGet 0 61 326
nameSet 1 61 327
toAccessorName 0 62 328
assign 1 63 329
accessorTypeGet 0 63 329
assign 1 63 330
new 0 63 330
assign 1 63 331
equals 1 63 331
assign 1 64 333
containerGet 0 64 333
heldSet 1 64 334
assign 1 65 335
containedGet 0 65 335
assign 1 65 336
firstGet 0 65 336
assign 1 67 337
typenameGet 0 67 337
typenameSet 1 67 338
assign 1 68 339
heldGet 0 68 339
heldSet 1 68 340
assign 1 69 341
containedGet 0 69 341
containedSet 1 69 342
assign 1 70 343
containerGet 0 70 343
assign 1 70 344
nextDescendGet 0 70 344
return 1 70 345
assign 1 72 348
CALLGet 0 72 348
typenameSet 1 72 349
heldSet 1 73 350
assign 1 75 352
nextDescendGet 0 75 352
return 1 75 353
assign 1 76 356
typenameGet 0 76 356
assign 1 76 357
IDXACCGet 0 76 357
assign 1 76 358
equals 1 76 363
assign 1 78 364
heldGet 0 78 364
assign 1 79 365
new 0 79 365
assign 1 80 366
containerGet 0 80 366
assign 1 80 367
typenameGet 0 80 367
assign 1 80 368
CALLGet 0 80 368
assign 1 80 369
equals 1 80 374
assign 1 80 375
containerGet 0 80 375
assign 1 80 376
heldGet 0 80 376
assign 1 80 377
nameGet 0 80 377
assign 1 80 378
new 0 80 378
assign 1 80 379
equals 1 80 379
assign 1 0 381
assign 1 0 384
assign 1 0 388
assign 1 80 391
isFirstGet 0 80 391
assign 1 0 393
assign 1 0 396
assign 1 0 400
assign 1 82 403
new 0 82 403
assign 1 85 406
new 0 85 406
assign 1 88 409
new 0 88 409
nameSet 1 88 410
assign 1 89 411
containerGet 0 89 411
heldSet 1 89 412
assign 1 90 413
containedGet 0 90 413
assign 1 90 414
firstGet 0 90 414
assign 1 93 415
nextPeerGet 0 93 415
assign 1 94 416
nextPeerGet 0 94 416
delete 0 96 417
delete 0 97 418
assign 1 99 419
typenameGet 0 99 419
typenameSet 1 99 420
assign 1 100 421
heldGet 0 100 421
heldSet 1 100 422
assign 1 101 423
containedGet 0 101 423
containedSet 1 101 424
assign 1 103 425
containerGet 0 103 425
addValue 1 103 426
assign 1 104 427
containerGet 0 104 427
addValue 1 104 428
assign 1 105 429
containerGet 0 105 429
assign 1 105 430
nextDescendGet 0 105 430
return 1 105 431
assign 1 111 434
new 0 111 434
nameSet 1 111 435
assign 1 112 436
CALLGet 0 112 436
typenameSet 1 112 437
heldSet 1 113 438
assign 1 115 440
nextDescendGet 0 115 440
return 1 115 441
assign 1 117 445
typenameGet 0 117 445
assign 1 117 446
FORGet 0 117 446
assign 1 117 447
equals 1 117 452
assign 1 119 453
containedGet 0 119 453
assign 1 119 454
firstGet 0 119 454
assign 1 119 455
containedGet 0 119 455
assign 1 119 456
firstGet 0 119 456
assign 1 120 457
typenameGet 0 120 457
assign 1 120 458
CALLGet 0 120 458
assign 1 120 459
equals 1 120 464
assign 1 120 465
heldGet 0 120 465
assign 1 120 466
wasOperGet 0 120 466
assign 1 0 468
assign 1 0 471
assign 1 0 475
assign 1 122 478
FOREACHGet 0 122 478
typenameSet 1 122 479
assign 1 125 482
typenameGet 0 125 482
assign 1 125 483
FOREACHGet 0 125 483
assign 1 125 484
equals 1 125 489
assign 1 126 490
WHILEGet 0 126 490
typenameSet 1 126 491
assign 1 127 492
containedGet 0 127 492
assign 1 127 493
firstGet 0 127 493
assign 1 128 494
secondGet 0 128 494
assign 1 129 495
containedGet 0 129 495
assign 1 129 496
firstGet 0 129 496
assign 1 130 497
containedGet 0 130 497
assign 1 130 498
firstGet 0 130 498
assign 1 131 499
secondGet 0 131 499
containedSet 1 132 500
assign 1 151 501
new 1 151 501
copyLoc 1 152 502
assign 1 153 503
VARGet 0 153 503
typenameSet 1 153 504
assign 1 154 505
new 0 154 505
assign 1 154 506
tmpVar 2 154 506
heldSet 1 155 507
assign 1 157 508
new 1 157 508
assign 1 158 509
CALLGet 0 158 509
typenameSet 1 158 510
assign 1 159 511
new 0 159 511
heldSet 1 160 512
assign 1 161 513
new 0 161 513
nameSet 1 161 514
assign 1 162 515
new 0 162 515
wasForeachGennedSet 1 162 516
addValue 1 163 517
assign 1 165 518
new 1 165 518
copyLoc 1 166 519
assign 1 167 520
CALLGet 0 167 520
typenameSet 1 167 521
assign 1 168 522
new 0 168 522
heldSet 1 169 523
assign 1 170 524
new 0 170 524
nameSet 1 170 525
addValue 1 171 526
addValue 1 172 527
beforeInsert 1 174 528
addVariable 0 175 529
assign 1 177 530
new 1 177 530
copyLoc 1 178 531
assign 1 179 532
VARGet 0 179 532
typenameSet 1 179 533
heldSet 1 180 534
assign 1 182 535
new 1 182 535
copyLoc 1 183 536
assign 1 184 537
CALLGet 0 184 537
typenameSet 1 184 538
assign 1 185 539
new 0 185 539
heldSet 1 186 540
assign 1 187 541
new 0 187 541
nameSet 1 187 542
addValue 1 188 543
addValue 1 190 544
assign 1 192 545
new 1 192 545
copyLoc 1 193 546
assign 1 194 547
VARGet 0 194 547
typenameSet 1 194 548
heldSet 1 195 549
assign 1 197 550
new 1 197 550
copyLoc 1 198 551
assign 1 199 552
CALLGet 0 199 552
typenameSet 1 199 553
assign 1 200 554
new 0 200 554
heldSet 1 201 555
assign 1 202 556
new 0 202 556
nameSet 1 202 557
addValue 1 203 558
assign 1 205 559
new 1 205 559
copyLoc 1 206 560
assign 1 207 561
CALLGet 0 207 561
typenameSet 1 207 562
assign 1 208 563
new 0 208 563
heldSet 1 209 564
assign 1 210 565
new 0 210 565
nameSet 1 210 566
addValue 1 211 567
addValue 1 212 568
prepend 1 214 569
return 1 215 570
assign 1 217 572
typenameGet 0 217 572
assign 1 217 573
WHILEGet 0 217 573
assign 1 217 574
equals 1 217 579
assign 1 218 580
new 1 218 580
copyLoc 1 219 581
assign 1 220 582
LOOPGet 0 220 582
typenameSet 1 220 583
replaceWith 1 221 584
assign 1 222 585
new 1 222 585
copyLoc 1 223 586
assign 1 224 587
BRACESGet 0 224 587
typenameSet 1 224 588
addValue 1 225 589
assign 1 226 590
assign 1 227 591
IFGet 0 227 591
typenameSet 1 227 592
addValue 1 228 593
assign 1 229 594
heldGet 0 229 594
assign 1 229 595
def 1 229 600
assign 1 229 601
heldGet 0 229 601
assign 1 229 602
new 0 229 602
assign 1 229 603
equals 1 229 603
assign 1 0 605
assign 1 0 608
assign 1 0 612
assign 1 230 615
new 0 230 615
heldSet 1 230 616
assign 1 232 618
new 1 232 618
copyLoc 1 233 619
assign 1 234 620
ELSEGet 0 234 620
typenameSet 1 234 621
addValue 1 235 622
assign 1 236 623
new 1 236 623
copyLoc 1 237 624
assign 1 238 625
BRACESGet 0 238 625
typenameSet 1 238 626
addValue 1 239 627
assign 1 240 628
new 1 240 628
copyLoc 1 241 629
assign 1 242 630
BREAKGet 0 242 630
typenameSet 1 242 631
addValue 1 243 632
assign 1 244 633
nextDescendGet 0 244 633
return 1 244 634
assign 1 245 637
typenameGet 0 245 637
assign 1 245 638
FORGet 0 245 638
assign 1 245 639
equals 1 245 644
assign 1 246 645
new 1 246 645
copyLoc 1 247 646
assign 1 248 647
LOOPGet 0 248 647
typenameSet 1 248 648
replaceWith 1 249 649
assign 1 250 650
containedGet 0 250 650
assign 1 250 651
firstGet 0 250 651
delete 0 251 652
assign 1 252 653
containedGet 0 252 653
assign 1 252 654
lengthGet 0 252 654
assign 1 252 655
new 0 252 655
assign 1 252 656
lesser 1 252 656
assign 1 253 658
new 0 253 658
assign 1 253 659
new 2 253 659
throw 1 253 660
assign 1 255 662
containedGet 0 255 662
assign 1 255 663
firstGet 0 255 663
assign 1 256 664
secondGet 0 256 664
assign 1 257 665
assign 1 258 666
containedGet 0 258 666
assign 1 258 667
lengthGet 0 258 667
assign 1 258 668
new 0 258 668
assign 1 258 669
greater 1 258 669
assign 1 259 671
thirdGet 0 259 671
delete 0 260 672
delete 0 262 674
replaceWith 1 264 675
beforeInsert 1 265 676
assign 1 267 677
new 1 267 677
copyLoc 1 268 678
assign 1 269 679
BRACESGet 0 269 679
typenameSet 1 269 680
addValue 1 270 681
assign 1 271 682
new 1 271 682
copyLoc 1 272 683
assign 1 273 684
IFGet 0 273 684
typenameSet 1 273 685
takeContents 1 274 686
assign 1 275 687
def 1 275 692
assign 1 276 693
containedGet 0 276 693
assign 1 276 694
firstGet 0 276 694
addValue 1 276 695
prepend 1 278 697
addValue 1 279 698
assign 1 280 699
new 1 280 699
copyLoc 1 281 700
assign 1 282 701
ELSEGet 0 282 701
typenameSet 1 282 702
addValue 1 283 703
assign 1 284 704
new 1 284 704
copyLoc 1 285 705
assign 1 286 706
BRACESGet 0 286 706
typenameSet 1 286 707
addValue 1 287 708
assign 1 288 709
new 1 288 709
copyLoc 1 289 710
assign 1 290 711
BREAKGet 0 290 711
typenameSet 1 290 712
addValue 1 291 713
return 1 293 714
assign 1 295 717
nextDescendGet 0 295 717
return 1 295 718
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 377494376: return bem_ntypesGetDirect_0();
case -655401869: return bem_constGetDirect_0();
case -568575955: return bem_hashGet_0();
case -220602072: return bem_echo_0();
case 774721401: return bem_serializeToString_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -674491561: return bem_sourceFileNameGet_0();
case -796904857: return bem_constGet_0();
case -829315536: return bem_classNameGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case 234248288: return bem_copy_0();
case 1494870453: return bem_ntypesGet_0();
case -437991849: return bem_toString_0();
case -763928014: return bem_create_0();
case -419834598: return bem_print_0();
case -551161654: return bem_buildGet_0();
case -118656390: return bem_transGet_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -18123974: return bem_new_0();
case 1087832621: return bem_tagGet_0();
case 2087607686: return bem_iteratorGet_0();
case 1126911928: return bem_serializeContents_0();
case -1454950260: return bem_fieldIteratorGet_0();
case 781730956: return bem_transGetDirect_0();
case 252323320: return bem_buildGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 537891098: return bem_end_1(bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 217821575: return bem_constSet_1(bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case -602593322: return bem_transSetDirect_1(bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case -1888869199: return bem_begin_1(bevd_0);
case 1124461780: return bem_buildSetDirect_1(bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case -1194055511: return bem_ntypesSetDirect_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case -643713889: return bem_notEquals_1(bevd_0);
case -1719515961: return bem_ntypesSet_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case 1029538574: return bem_constSetDirect_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1801182313: return bem_transSet_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case -1762610657: return bem_buildSet_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -209706136: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass9_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass9_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst = (BEC_3_5_5_5_BuildVisitPass9) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;
}
}
