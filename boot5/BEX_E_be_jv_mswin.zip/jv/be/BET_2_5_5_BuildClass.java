package be;
public class BET_2_5_5_BuildClass extends BETS_Object {
public BET_2_5_5_BuildClass() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "addUsed_1", "addEmit_1", "extendsGet_0", "extendsSet_1", "emitsGet_0", "emitsSet_1", "nameGet_0", "nameSet_1", "namepathGet_0", "namepathSet_1", "synGet_0", "synSet_1", "fromFileGet_0", "fromFileSet_1", "libNameGet_0", "libNameSet_1", "methodsGet_0", "methodsSet_1", "orderedMethodsGet_0", "orderedMethodsSet_1", "usedGet_0", "usedSet_1", "anyMapGet_0", "anyMapSet_1", "orderedVarsGet_0", "orderedVarsSet_1", "isFinalGet_0", "isFinalSet_1", "isLocalGet_0", "isLocalSet_1", "isNotNullGet_0", "isNotNullSet_1", "freeFirstSlotGet_0", "freeFirstSlotSet_1", "firstSlotNativeGet_0", "firstSlotNativeSet_1", "nativeSlotsGet_0", "nativeSlotsSet_1", "isListGet_0", "isListSet_1", "onceEvalCountGet_0", "onceEvalCountSet_1", "referencedPropertiesGet_0", "referencedPropertiesSet_1", "shouldWriteGet_0", "shouldWriteSet_1", "belsCountGet_0", "belsCountSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "extends", "emits", "name", "namepath", "syn", "fromFile", "libName", "methods", "orderedMethods", "used", "anyMap", "orderedVars", "isFinal", "isLocal", "isNotNull", "freeFirstSlot", "firstSlotNative", "nativeSlots", "isList", "onceEvalCount", "referencedProperties", "shouldWrite", "belsCount" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_5_BuildClass();
}
}
