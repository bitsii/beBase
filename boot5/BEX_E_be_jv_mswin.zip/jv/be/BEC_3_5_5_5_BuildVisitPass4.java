package be;
/* IO:File: source/build/Pass4.be */
public final class BEC_3_5_5_5_BuildVisitPass4 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass4() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass4_bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static BEC_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;

public BEC_3_5_5_5_BuildVisitPass4 bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_6_TextString bevl_nps = null;
BEC_2_5_4_BuildNode bevl_nxn = null;
BEC_2_5_4_BuildNode bevl_nxnn = null;
BEC_2_5_4_BuildNode bevl_first = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 21 */ {
bevt_5_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_5_tmpany_phold.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 21 */ {
if (bevl_nnode == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 21 */ {
bevt_9_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 21 */ {
if (bevl_nps == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_nps = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 23 */
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevl_nps.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_17_tmpany_phold = bevl_nxn.bem_typenameGet_0();
bevt_18_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_17_tmpany_phold.bevi_int != bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_3_5_5_5_BuildVisitPass4_bels_0));
bevt_19_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_20_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 28 */
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 31 */ {
beva_node.bem_delete_0();
} /* Line: 32 */
 else  /* Line: 33 */ {
bevl_first = beva_node;
} /* Line: 34 */
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 38 */
 else  /* Line: 21 */ {
break;
} /* Line: 21 */
} /* Line: 21 */
if (bevl_first == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_23_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_tmpany_phold);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_28_tmpany_phold = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_tmpany_phold);
beva_node.bem_delete_0();
} /* Line: 45 */
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_tmpany_phold = bevl_first.bem_nextDescendGet_0();
return bevt_29_tmpany_phold;
} /* Line: 49 */
bevt_30_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 20, 21, 21, 21, 21, 21, 21, 0, 0, 0, 21, 21, 21, 21, 0, 0, 0, 22, 22, 23, 25, 25, 25, 25, 26, 27, 27, 0, 27, 27, 27, 27, 0, 0, 28, 28, 28, 30, 31, 31, 32, 34, 36, 37, 38, 40, 40, 41, 41, 42, 43, 43, 43, 43, 43, 43, 0, 0, 0, 44, 44, 45, 47, 48, 49, 49, 51, 51};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 54, 57, 58, 59, 64, 65, 70, 71, 74, 78, 81, 82, 83, 88, 89, 92, 96, 99, 104, 105, 107, 108, 109, 110, 111, 112, 117, 118, 121, 122, 123, 128, 129, 132, 136, 137, 138, 140, 141, 146, 147, 150, 152, 153, 154, 160, 165, 166, 167, 168, 169, 174, 175, 176, 177, 182, 183, 186, 190, 193, 194, 195, 197, 198, 199, 200, 202, 203};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 16 13
assign 1 20 54
nextPeerGet 0 20 54
assign 1 21 57
typenameGet 0 21 57
assign 1 21 58
IDGet 0 21 58
assign 1 21 59
equals 1 21 64
assign 1 21 65
def 1 21 70
assign 1 0 71
assign 1 0 74
assign 1 0 78
assign 1 21 81
typenameGet 0 21 81
assign 1 21 82
COLONGet 0 21 82
assign 1 21 83
equals 1 21 88
assign 1 0 89
assign 1 0 92
assign 1 0 96
assign 1 22 99
undef 1 22 104
assign 1 23 105
new 0 23 105
assign 1 25 107
heldGet 0 25 107
assign 1 25 108
add 1 25 108
assign 1 25 109
heldGet 0 25 109
assign 1 25 110
add 1 25 110
assign 1 26 111
nextPeerGet 0 26 111
assign 1 27 112
undef 1 27 117
assign 1 0 118
assign 1 27 121
typenameGet 0 27 121
assign 1 27 122
IDGet 0 27 122
assign 1 27 123
notEquals 1 27 128
assign 1 0 129
assign 1 0 132
assign 1 28 136
new 0 28 136
assign 1 28 137
new 2 28 137
throw 1 28 138
assign 1 30 140
nextPeerGet 0 30 140
assign 1 31 141
def 1 31 146
delete 0 32 147
assign 1 34 150
delete 0 36 152
assign 1 37 153
assign 1 38 154
assign 1 40 160
def 1 40 165
assign 1 41 166
NAMEPATHGet 0 41 166
typenameSet 1 41 167
assign 1 42 168
new 0 42 168
assign 1 43 169
def 1 43 174
assign 1 43 175
typenameGet 0 43 175
assign 1 43 176
IDGet 0 43 176
assign 1 43 177
equals 1 43 182
assign 1 0 183
assign 1 0 186
assign 1 0 190
assign 1 44 193
heldGet 0 44 193
assign 1 44 194
add 1 44 194
delete 0 45 195
fromString 1 47 197
heldSet 1 48 198
assign 1 49 199
nextDescendGet 0 49 199
return 1 49 200
assign 1 51 202
nextDescendGet 0 51 202
return 1 51 203
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1452564531: return bem_toString_0();
case -977356120: return bem_fieldNamesGet_0();
case 1623987490: return bem_serializeContents_0();
case 771367616: return bem_transGet_0();
case 734156196: return bem_buildGetDirect_0();
case -1836757512: return bem_copy_0();
case -464967776: return bem_classNameGet_0();
case 1928293906: return bem_once_0();
case 1834941563: return bem_constGetDirect_0();
case 1441814457: return bem_ntypesGet_0();
case 1148186102: return bem_toAny_0();
case 619304343: return bem_hashGet_0();
case -197180620: return bem_echo_0();
case -1895797969: return bem_fieldIteratorGet_0();
case -757699318: return bem_iteratorGet_0();
case 438244040: return bem_create_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case 500389220: return bem_print_0();
case -919772434: return bem_serializeToString_0();
case 393443790: return bem_constGet_0();
case 1941268102: return bem_ntypesGetDirect_0();
case -978724962: return bem_tagGet_0();
case 868760417: return bem_serializationIteratorGet_0();
case 1000076890: return bem_transGetDirect_0();
case 1605752359: return bem_many_0();
case 141983605: return bem_sourceFileNameGet_0();
case 1576417178: return bem_new_0();
case 1925396050: return bem_buildGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2008315742: return bem_transSetDirect_1(bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -346513329: return bem_buildSet_1(bevd_0);
case 599885158: return bem_begin_1(bevd_0);
case -152665287: return bem_ntypesSet_1(bevd_0);
case 1514981906: return bem_constSet_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case -1087428326: return bem_constSetDirect_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case -1623076338: return bem_buildSetDirect_1(bevd_0);
case 940817591: return bem_transSet_1(bevd_0);
case -1550095708: return bem_end_1(bevd_0);
case 184984359: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case -2080355933: return bem_defined_1(bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1123185311: return bem_ntypesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass4_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass4_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass4();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst = (BEC_3_5_5_5_BuildVisitPass4) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;
}
}
