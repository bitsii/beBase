package be;
/* IO:File: source/build/Pass4.be */
public final class BEC_3_5_5_5_BuildVisitPass4 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass4() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass4_bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static BEC_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;

public BEC_3_5_5_5_BuildVisitPass4 bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_6_TextString bevl_nps = null;
BEC_2_5_4_BuildNode bevl_nxn = null;
BEC_2_5_4_BuildNode bevl_nxnn = null;
BEC_2_5_4_BuildNode bevl_first = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_BuildNode bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
/* Line: 26*/ {
bevt_5_ta_ph = beva_node.bem_typenameGet_0();
bevt_6_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_5_ta_ph.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 26*/ {
if (bevl_nnode == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 26*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 26*/
 else /* Line: 26*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 26*/ {
bevt_9_ta_ph = bevl_nnode.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_COLONGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 26*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 26*/
 else /* Line: 26*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 26*/ {
if (bevl_nps == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 27*/ {
bevl_nps = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 28*/
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevl_nps.bem_add_1(bevt_13_ta_ph);
bevt_14_ta_ph = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_ta_ph.bem_add_1(bevt_14_ta_ph);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 32*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 32*/ {
bevt_17_ta_ph = bevl_nxn.bem_typenameGet_0();
bevt_18_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_17_ta_ph.bevi_int != bevt_18_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 32*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 32*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 32*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 32*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_3_5_5_5_BuildVisitPass4_bels_0));
bevt_19_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_20_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_19_ta_ph);
} /* Line: 33*/
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 36*/ {
beva_node.bem_remove_0();
} /* Line: 37*/
 else /* Line: 38*/ {
bevl_first = beva_node;
} /* Line: 39*/
bevl_nnode.bem_remove_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 43*/
 else /* Line: 26*/ {
break;
} /* Line: 26*/
} /* Line: 26*/
if (bevl_first == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_23_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_ta_ph);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_26_ta_ph = beva_node.bem_typenameGet_0();
bevt_27_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_26_ta_ph.bevi_int == bevt_27_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 48*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 48*/
 else /* Line: 48*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 48*/ {
bevt_28_ta_ph = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_ta_ph);
beva_node.bem_remove_0();
} /* Line: 50*/
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_ta_ph = bevl_first.bem_nextDescendGet_0();
return bevt_29_ta_ph;
} /* Line: 54*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 25, 26, 26, 26, 26, 26, 26, 0, 0, 0, 26, 26, 26, 26, 0, 0, 0, 27, 27, 28, 30, 30, 30, 30, 31, 32, 32, 0, 32, 32, 32, 32, 0, 0, 33, 33, 33, 35, 36, 36, 37, 39, 41, 42, 43, 45, 45, 46, 46, 47, 48, 48, 48, 48, 48, 48, 0, 0, 0, 49, 49, 50, 52, 53, 54, 54, 56, 56};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 54, 57, 58, 59, 64, 65, 70, 71, 74, 78, 81, 82, 83, 88, 89, 92, 96, 99, 104, 105, 107, 108, 109, 110, 111, 112, 117, 118, 121, 122, 123, 128, 129, 132, 136, 137, 138, 140, 141, 146, 147, 150, 152, 153, 154, 160, 165, 166, 167, 168, 169, 174, 175, 176, 177, 182, 183, 186, 190, 193, 194, 195, 197, 198, 199, 200, 202, 203};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 21 13
assign 1 25 54
nextPeerGet 0 25 54
assign 1 26 57
typenameGet 0 26 57
assign 1 26 58
IDGet 0 26 58
assign 1 26 59
equals 1 26 64
assign 1 26 65
def 1 26 70
assign 1 0 71
assign 1 0 74
assign 1 0 78
assign 1 26 81
typenameGet 0 26 81
assign 1 26 82
COLONGet 0 26 82
assign 1 26 83
equals 1 26 88
assign 1 0 89
assign 1 0 92
assign 1 0 96
assign 1 27 99
undef 1 27 104
assign 1 28 105
new 0 28 105
assign 1 30 107
heldGet 0 30 107
assign 1 30 108
add 1 30 108
assign 1 30 109
heldGet 0 30 109
assign 1 30 110
add 1 30 110
assign 1 31 111
nextPeerGet 0 31 111
assign 1 32 112
undef 1 32 117
assign 1 0 118
assign 1 32 121
typenameGet 0 32 121
assign 1 32 122
IDGet 0 32 122
assign 1 32 123
notEquals 1 32 128
assign 1 0 129
assign 1 0 132
assign 1 33 136
new 0 33 136
assign 1 33 137
new 2 33 137
throw 1 33 138
assign 1 35 140
nextPeerGet 0 35 140
assign 1 36 141
def 1 36 146
remove 0 37 147
assign 1 39 150
remove 0 41 152
assign 1 42 153
assign 1 43 154
assign 1 45 160
def 1 45 165
assign 1 46 166
NAMEPATHGet 0 46 166
typenameSet 1 46 167
assign 1 47 168
new 0 47 168
assign 1 48 169
def 1 48 174
assign 1 48 175
typenameGet 0 48 175
assign 1 48 176
IDGet 0 48 176
assign 1 48 177
equals 1 48 182
assign 1 0 183
assign 1 0 186
assign 1 0 190
assign 1 49 193
heldGet 0 49 193
assign 1 49 194
add 1 49 194
remove 0 50 195
fromString 1 52 197
heldSet 1 53 198
assign 1 54 199
nextDescendGet 0 54 199
return 1 54 200
assign 1 56 202
nextDescendGet 0 56 202
return 1 56 203
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1045256597: return bem_new_0();
case -1348914949: return bem_buildGet_0();
case 1043863121: return bem_constGet_0();
case 1389378690: return bem_iteratorGet_0();
case -1225636174: return bem_toString_0();
case -308470073: return bem_hashGet_0();
case 1661802748: return bem_print_0();
case 1431165396: return bem_ntypesGet_0();
case 1000772956: return bem_transGet_0();
case -355124364: return bem_create_0();
case 1375409336: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1410683219: return bem_notEquals_1(bevd_0);
case 370009006: return bem_ntypesSet_1(bevd_0);
case -136479842: return bem_buildSet_1(bevd_0);
case 56051856: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2119998280: return bem_undef_1(bevd_0);
case 1024858296: return bem_copyTo_1(bevd_0);
case 158845737: return bem_constSet_1(bevd_0);
case 207992556: return bem_def_1(bevd_0);
case 789789310: return bem_print_1(bevd_0);
case 145823261: return bem_equals_1(bevd_0);
case 1773296708: return bem_begin_1(bevd_0);
case -93528922: return bem_end_1(bevd_0);
case 160232648: return bem_transSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1648212160: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 195884639: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1847574000: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 369351178: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass4_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass4_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass4();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst = (BEC_3_5_5_5_BuildVisitPass4) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;
}
}
