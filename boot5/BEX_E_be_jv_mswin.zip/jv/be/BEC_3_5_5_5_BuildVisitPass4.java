package be;
/* IO:File: source/build/Pass4.be */
public final class BEC_3_5_5_5_BuildVisitPass4 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass4() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass4_bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static BEC_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;

public static BET_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;

public BEC_3_5_5_5_BuildVisitPass4 bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_6_TextString bevl_nps = null;
BEC_2_5_4_BuildNode bevl_nxn = null;
BEC_2_5_4_BuildNode bevl_nxnn = null;
BEC_2_5_4_BuildNode bevl_first = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_BuildNode bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
/* Line: 20*/ {
bevt_5_ta_ph = beva_node.bem_typenameGet_0();
bevt_6_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_5_ta_ph.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 20*/ {
if (bevl_nnode == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 20*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 20*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 20*/
 else /* Line: 20*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 20*/ {
bevt_9_ta_ph = bevl_nnode.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_COLONGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 20*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 20*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 20*/
 else /* Line: 20*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 20*/ {
if (bevl_nps == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 21*/ {
bevl_nps = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 22*/
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevl_nps.bem_add_1(bevt_13_ta_ph);
bevt_14_ta_ph = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_ta_ph.bem_add_1(bevt_14_ta_ph);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 26*/ {
bevt_17_ta_ph = bevl_nxn.bem_typenameGet_0();
bevt_18_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_17_ta_ph.bevi_int != bevt_18_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 26*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 26*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 26*/ {
bevt_20_ta_ph = (new BEC_2_4_6_TextString(19, bece_BEC_3_5_5_5_BuildVisitPass4_bels_0));
bevt_19_ta_ph = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_20_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_19_ta_ph);
} /* Line: 27*/
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 30*/ {
beva_node.bem_delete_0();
} /* Line: 31*/
 else /* Line: 32*/ {
bevl_first = beva_node;
} /* Line: 33*/
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 37*/
 else /* Line: 20*/ {
break;
} /* Line: 20*/
} /* Line: 20*/
if (bevl_first == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_23_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_ta_ph);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_26_ta_ph = beva_node.bem_typenameGet_0();
bevt_27_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_26_ta_ph.bevi_int == bevt_27_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 42*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 42*/
 else /* Line: 42*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 42*/ {
bevt_28_ta_ph = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_ta_ph);
beva_node.bem_delete_0();
} /* Line: 44*/
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_ta_ph = bevl_first.bem_nextDescendGet_0();
return bevt_29_ta_ph;
} /* Line: 48*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 19, 20, 20, 20, 20, 20, 20, 0, 0, 0, 20, 20, 20, 20, 0, 0, 0, 21, 21, 22, 24, 24, 24, 24, 25, 26, 26, 0, 26, 26, 26, 26, 0, 0, 27, 27, 27, 29, 30, 30, 31, 33, 35, 36, 37, 39, 39, 40, 40, 41, 42, 42, 42, 42, 42, 42, 0, 0, 0, 43, 43, 44, 46, 47, 48, 48, 50, 50};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 54, 57, 58, 59, 64, 65, 70, 71, 74, 78, 81, 82, 83, 88, 89, 92, 96, 99, 104, 105, 107, 108, 109, 110, 111, 112, 117, 118, 121, 122, 123, 128, 129, 132, 136, 137, 138, 140, 141, 146, 147, 150, 152, 153, 154, 160, 165, 166, 167, 168, 169, 174, 175, 176, 177, 182, 183, 186, 190, 193, 194, 195, 197, 198, 199, 200, 202, 203};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 15 13
assign 1 19 54
nextPeerGet 0 19 54
assign 1 20 57
typenameGet 0 20 57
assign 1 20 58
IDGet 0 20 58
assign 1 20 59
equals 1 20 64
assign 1 20 65
def 1 20 70
assign 1 0 71
assign 1 0 74
assign 1 0 78
assign 1 20 81
typenameGet 0 20 81
assign 1 20 82
COLONGet 0 20 82
assign 1 20 83
equals 1 20 88
assign 1 0 89
assign 1 0 92
assign 1 0 96
assign 1 21 99
undef 1 21 104
assign 1 22 105
new 0 22 105
assign 1 24 107
heldGet 0 24 107
assign 1 24 108
add 1 24 108
assign 1 24 109
heldGet 0 24 109
assign 1 24 110
add 1 24 110
assign 1 25 111
nextPeerGet 0 25 111
assign 1 26 112
undef 1 26 117
assign 1 0 118
assign 1 26 121
typenameGet 0 26 121
assign 1 26 122
IDGet 0 26 122
assign 1 26 123
notEquals 1 26 128
assign 1 0 129
assign 1 0 132
assign 1 27 136
new 0 27 136
assign 1 27 137
new 2 27 137
throw 1 27 138
assign 1 29 140
nextPeerGet 0 29 140
assign 1 30 141
def 1 30 146
delete 0 31 147
assign 1 33 150
delete 0 35 152
assign 1 36 153
assign 1 37 154
assign 1 39 160
def 1 39 165
assign 1 40 166
NAMEPATHGet 0 40 166
typenameSet 1 40 167
assign 1 41 168
new 0 41 168
assign 1 42 169
def 1 42 174
assign 1 42 175
typenameGet 0 42 175
assign 1 42 176
IDGet 0 42 176
assign 1 42 177
equals 1 42 182
assign 1 0 183
assign 1 0 186
assign 1 0 190
assign 1 43 193
heldGet 0 43 193
assign 1 43 194
add 1 43 194
delete 0 44 195
fromString 1 46 197
heldSet 1 47 198
assign 1 48 199
nextDescendGet 0 48 199
return 1 48 200
assign 1 50 202
nextDescendGet 0 50 202
return 1 50 203
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 254283761: return bem_classNameGet_0();
case 32986096: return bem_tagGet_0();
case -1385380140: return bem_constGet_0();
case 1337499076: return bem_fieldIteratorGet_0();
case -434766936: return bem_many_0();
case -1193538733: return bem_echo_0();
case 151131677: return bem_buildGetDirect_0();
case 1993725787: return bem_buildGet_0();
case -1667230363: return bem_new_0();
case -2068645774: return bem_toString_0();
case 656174411: return bem_iteratorGet_0();
case 1258540231: return bem_print_0();
case 1724284574: return bem_constGetDirect_0();
case 840272884: return bem_ntypesGet_0();
case 181316061: return bem_serializeContents_0();
case 1891960843: return bem_transGet_0();
case 1333189262: return bem_copy_0();
case -1134589630: return bem_serializeToString_0();
case 1887791078: return bem_toAny_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 238716313: return bem_once_0();
case -1916545082: return bem_hashGet_0();
case -1418943130: return bem_ntypesGetDirect_0();
case 470335985: return bem_fieldNamesGet_0();
case 465992683: return bem_transGetDirect_0();
case 1422294520: return bem_create_0();
case 1433312714: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1290216463: return bem_def_1(bevd_0);
case -608231493: return bem_buildSetDirect_1(bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case -570491086: return bem_transSetDirect_1(bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1914536347: return bem_transSet_1(bevd_0);
case -483224371: return bem_end_1(bevd_0);
case -1024351632: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case 129810800: return bem_ntypesSet_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case 1641712379: return bem_buildSet_1(bevd_0);
case 1892842053: return bem_constSetDirect_1(bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 100560712: return bem_constSet_1(bevd_0);
case 1675566006: return bem_begin_1(bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case 2099765945: return bem_ntypesSetDirect_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass4_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass4_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass4();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst = (BEC_3_5_5_5_BuildVisitPass4) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;
}
}
