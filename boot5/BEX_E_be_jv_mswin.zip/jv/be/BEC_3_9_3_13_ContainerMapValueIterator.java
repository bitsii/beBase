package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_13_ContainerMapValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_13_ContainerMapValueIterator() { }
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;

public static BET_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_tr = super.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 585*/ {
bevt_1_ta_ph = bevl_tr.bemd_0(1676954041);
return bevt_1_ta_ph;
} /* Line: 586*/
return bevl_tr;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {584, 585, 585, 586, 586, 588};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 21, 22, 23, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 584 15
nextGet 0 584 15
assign 1 585 16
def 1 585 21
assign 1 586 22
valueGet 0 586 22
return 1 586 23
return 1 588 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -593469656: return bem_sourceFileNameGet_0();
case -1818293830: return bem_fieldNamesGet_0();
case 793589441: return bem_classNameGet_0();
case -1621725343: return bem_bucketsGet_0();
case 2061432375: return bem_tagGet_0();
case 1847639727: return bem_new_0();
case -1331374769: return bem_toString_0();
case 1757263953: return bem_hasNextGet_0();
case -675209112: return bem_delete_0();
case 15786277: return bem_currentGetDirect_0();
case 636345: return bem_print_0();
case 854710191: return bem_create_0();
case -1740213654: return bem_currentGet_0();
case -22788464: return bem_hashGet_0();
case 1739213981: return bem_bucketsGetDirect_0();
case 1314388618: return bem_containerGet_0();
case 1982151412: return bem_nextGet_0();
case 1726896959: return bem_setGet_0();
case -852531685: return bem_setGetDirect_0();
case -1508036637: return bem_copy_0();
case -1232819452: return bem_moduGetDirect_0();
case 1800929528: return bem_nodeIteratorIteratorGet_0();
case -1302738888: return bem_moduGet_0();
case 38127485: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -502376443: return bem_equals_1(bevd_0);
case -2070635974: return bem_setSet_1(bevd_0);
case 1318108394: return bem_moduSetDirect_1(bevd_0);
case 1790420379: return bem_setSetDirect_1(bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case -404287636: return bem_moduSet_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case -784981258: return bem_bucketsSet_1(bevd_0);
case -1835589679: return bem_bucketsSetDirect_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case 400909945: return bem_currentSet_1(bevd_0);
case -785087004: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
case 70054218: return bem_currentSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_9_3_13_ContainerMapValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_13_ContainerMapValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst = (BEC_3_9_3_13_ContainerMapValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;
}
}
