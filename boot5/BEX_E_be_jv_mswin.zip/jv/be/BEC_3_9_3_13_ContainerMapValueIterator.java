package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_13_ContainerMapValueIterator extends BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_13_ContainerMapValueIterator() { }
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x56,0x61,0x6C,0x75,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;

public static BET_3_9_3_13_ContainerMapValueIterator bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;

public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_tr = super.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_1_tmpany_phold = bevl_tr.bemd_0(-2132757034);
return bevt_1_tmpany_phold;
} /* Line: 632 */
return bevl_tr;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {630, 631, 631, 632, 632, 634};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 21, 22, 23, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 630 15
nextGet 0 630 15
assign 1 631 16
def 1 631 21
assign 1 632 22
valueGet 0 632 22
return 1 632 23
return 1 634 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -357139526: return bem_many_0();
case -2005156683: return bem_classNameGet_0();
case 1551415145: return bem_toAny_0();
case -787200963: return bem_slotsGet_0();
case -890719598: return bem_sourceFileNameGet_0();
case -54679326: return bem_moduGetDirect_0();
case -1313098664: return bem_toString_0();
case 1916596958: return bem_moduGet_0();
case -738439163: return bem_copy_0();
case 320622940: return bem_echo_0();
case -371315307: return bem_delete_0();
case -958181001: return bem_currentGet_0();
case -798580985: return bem_setGet_0();
case 606484116: return bem_hasNextGet_0();
case 101762581: return bem_serializeContents_0();
case 1370127288: return bem_setGetDirect_0();
case 983736684: return bem_serializationIteratorGet_0();
case -1522610135: return bem_serializeToString_0();
case 1864318209: return bem_slotsGetDirect_0();
case -1292021236: return bem_nextGet_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case 484635838: return bem_tagGet_0();
case -753430171: return bem_fieldIteratorGet_0();
case -1966626789: return bem_hashGet_0();
case 247075507: return bem_fieldNamesGet_0();
case 1969080256: return bem_once_0();
case 1844156293: return bem_nodeIteratorIteratorGet_0();
case 2084331281: return bem_new_0();
case 645211302: return bem_iteratorGet_0();
case -576502505: return bem_create_0();
case 999374457: return bem_currentGetDirect_0();
case 62919235: return bem_containerGet_0();
case 690609043: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -670773723: return bem_sameType_1(bevd_0);
case -1670439249: return bem_slotsSetDirect_1(bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 263695983: return bem_setSet_1(bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1538009659: return bem_moduSet_1(bevd_0);
case 1980686481: return bem_slotsSet_1(bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case -559803890: return bem_notEquals_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case -1756603829: return bem_currentSet_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case 1056446711: return bem_setSetDirect_1(bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1865671550: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case -1649593771: return bem_moduSetDirect_1(bevd_0);
case 441071981: return bem_currentSetDirect_1(bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_3_9_3_13_ContainerMapValueIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_13_ContainerMapValueIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_13_ContainerMapValueIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst = (BEC_3_9_3_13_ContainerMapValueIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_13_ContainerMapValueIterator.bece_BEC_3_9_3_13_ContainerMapValueIterator_bevs_type;
}
}
