package be;
public class BET_2_4_7_TextStrings extends BETS_Object {
public BET_2_4_7_TextStrings() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "default_0", "join_2", "joinBuffer_2", "strip_1", "commonPrefix_2", "anyEmpty_1", "isEmpty_1", "notEmpty_1", "zeroGet_0", "zeroSet_1", "spaceGet_0", "spaceSet_1", "emptyGet_0", "emptySet_1", "quoteGet_0", "quoteSet_1", "tabGet_0", "tabSet_1", "dosNewlineGet_0", "dosNewlineSet_1", "unixNewlineGet_0", "unixNewlineSet_1", "newlineGet_0", "newlineSet_1", "crGet_0", "crSet_1", "lfGet_0", "lfSet_1", "colonGet_0", "colonSet_1", "wsGet_0", "wsSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "zero", "space", "empty", "quote", "tab", "dosNewline", "unixNewline", "newline", "cr", "lf", "colon", "ws" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_7_TextStrings();
}
}
