package be;
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_7_ContainerMapMapNode extends BEC_3_9_3_7_ContainerSetSetNode {
public BEC_3_9_3_7_ContainerMapMapNode() { }
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4D,0x61,0x70,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;

public static BET_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;

public BEC_2_6_6_SystemObject bevp_value;
public BEC_3_9_3_7_ContainerMapMapNode bem_new_3(BEC_2_6_6_SystemObject beva__hval, BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) throws Throwable {
super.bem_new_3(beva__hval, beva__key, beva__value);
bevp_value = beva__value;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerMapMapNode bem_putTo_2(BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) throws Throwable {
bevp_key = beva__key;
bevp_value = beva__value;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFrom_0() throws Throwable {
return bevp_value;
} /*method end*/
public BEC_2_6_6_SystemObject bem_valueGet_0() throws Throwable {
return bevp_value;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_valueGetDirect_0() throws Throwable {
return bevp_value;
} /*method end*/
public BEC_3_9_3_7_ContainerMapMapNode bem_valueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_value = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_3_7_ContainerMapMapNode bem_valueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_value = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {40, 43, 49, 50, 54, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 23, 26, 29, 32, 36};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 3 40 13
assign 1 43 14
assign 1 49 18
assign 1 50 19
return 1 54 23
return 1 0 26
return 1 0 29
assign 1 0 32
assign 1 0 36
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1851036145: return bem_serializationIteratorGet_0();
case -1087766017: return bem_serializeToString_0();
case -1101326644: return bem_serializeContents_0();
case -596604149: return bem_hvalGetDirect_0();
case 322973431: return bem_print_0();
case 305613993: return bem_sourceFileNameGet_0();
case 828966204: return bem_valueGet_0();
case 2050059376: return bem_iteratorGet_0();
case -753644705: return bem_hashGet_0();
case -396718722: return bem_hvalGet_0();
case -410783155: return bem_new_0();
case -1189970947: return bem_keyGet_0();
case -43502949: return bem_toAny_0();
case -909675958: return bem_create_0();
case 291309239: return bem_once_0();
case 123150312: return bem_valueGetDirect_0();
case -1569222986: return bem_fieldIteratorGet_0();
case 1794044715: return bem_getFrom_0();
case 597357534: return bem_tagGet_0();
case 625547167: return bem_toString_0();
case 678571136: return bem_many_0();
case -545885409: return bem_fieldNamesGet_0();
case -304415890: return bem_classNameGet_0();
case 43657144: return bem_keyGetDirect_0();
case -381740729: return bem_deserializeClassNameGet_0();
case 364235321: return bem_echo_0();
case 1461724031: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case 1585232824: return bem_keySet_1(bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case -1372868044: return bem_keySetDirect_1(bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case 467056358: return bem_hvalSetDirect_1(bevd_0);
case -1137865567: return bem_valueSetDirect_1(bevd_0);
case 1473391571: return bem_valueSet_1(bevd_0);
case 1926673077: return bem_hvalSet_1(bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 227414014: return bem_putTo_2(bevd_0, bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 757936205: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_9_3_7_ContainerMapMapNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_7_ContainerMapMapNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_3_7_ContainerMapMapNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst = (BEC_3_9_3_7_ContainerMapMapNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;
}
}
