package be;
/* IO:File: source/base/Stack.be */
public class BEC_3_9_5_4_ContainerStackNode extends BEC_2_6_6_SystemObject {
public BEC_3_9_5_4_ContainerStackNode() { }
private static byte[] becc_BEC_3_9_5_4_ContainerStackNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_5_4_ContainerStackNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_3_9_5_4_ContainerStackNode bece_BEC_3_9_5_4_ContainerStackNode_bevs_inst;

public static BET_3_9_5_4_ContainerStackNode bece_BEC_3_9_5_4_ContainerStackNode_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_next;
public BEC_3_9_5_4_ContainerStackNode bevp_prior;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_5_4_ContainerStackNode bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_nextGet_0() throws Throwable {
return bevp_next;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_nextGetDirect_0() throws Throwable {
return bevp_next;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_nextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_next = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_nextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_next = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_priorGet_0() throws Throwable {
return bevp_prior;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_priorGetDirect_0() throws Throwable {
return bevp_prior;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_priorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prior = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_priorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prior = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldGetDirect_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_held = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 21, 24, 28, 32, 35, 38, 42, 46, 49, 52, 56};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
return 1 0 18
return 1 0 21
assign 1 0 24
assign 1 0 28
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1649954317: return bem_serializeToString_0();
case -429437759: return bem_sourceFileNameGet_0();
case 57159682: return bem_new_0();
case -1947306340: return bem_nextGet_0();
case 602097122: return bem_deserializeClassNameGet_0();
case 2117639469: return bem_echo_0();
case -284999675: return bem_toAny_0();
case -2069102102: return bem_toString_0();
case 55315205: return bem_many_0();
case -1232907801: return bem_iteratorGet_0();
case -1605431584: return bem_tagGet_0();
case 321704245: return bem_print_0();
case -1561145816: return bem_hashGet_0();
case -1437550559: return bem_serializeContents_0();
case -1055677288: return bem_fieldIteratorGet_0();
case 1644000934: return bem_copy_0();
case 1584535515: return bem_nextGetDirect_0();
case -471411300: return bem_priorGet_0();
case 1029860087: return bem_fieldNamesGet_0();
case -365679348: return bem_heldGetDirect_0();
case -1200745202: return bem_heldGet_0();
case -1677419910: return bem_create_0();
case 1215735159: return bem_classNameGet_0();
case 1974641849: return bem_priorGetDirect_0();
case 1129503343: return bem_once_0();
case 444831026: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -740299402: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1719096215: return bem_defined_1(bevd_0);
case 650080222: return bem_notEquals_1(bevd_0);
case -1910866455: return bem_priorSetDirect_1(bevd_0);
case -756536057: return bem_otherClass_1(bevd_0);
case 2051970465: return bem_nextSet_1(bevd_0);
case 208310867: return bem_def_1(bevd_0);
case 428398671: return bem_nextSetDirect_1(bevd_0);
case -97426471: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1988005274: return bem_sameObject_1(bevd_0);
case 1484718882: return bem_copyTo_1(bevd_0);
case -1171471101: return bem_heldSetDirect_1(bevd_0);
case 1602696702: return bem_equals_1(bevd_0);
case -962669917: return bem_otherType_1(bevd_0);
case -514631328: return bem_priorSet_1(bevd_0);
case 1366553936: return bem_undef_1(bevd_0);
case -1371671937: return bem_undefined_1(bevd_0);
case 493426545: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1422291148: return bem_sameClass_1(bevd_0);
case 1178220548: return bem_sameType_1(bevd_0);
case 1521573585: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1901148596: return bem_heldSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1950811501: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1959141176: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281973651: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -12510800: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220358760: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 36705687: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -533377424: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_9_5_4_ContainerStackNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_9_5_4_ContainerStackNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_5_4_ContainerStackNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_5_4_ContainerStackNode.bece_BEC_3_9_5_4_ContainerStackNode_bevs_inst = (BEC_3_9_5_4_ContainerStackNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_5_4_ContainerStackNode.bece_BEC_3_9_5_4_ContainerStackNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_5_4_ContainerStackNode.bece_BEC_3_9_5_4_ContainerStackNode_bevs_type;
}
}
