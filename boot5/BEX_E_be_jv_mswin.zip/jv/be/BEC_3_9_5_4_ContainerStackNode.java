package be;
/* IO:File: source/base/Stack.be */
public class BEC_3_9_5_4_ContainerStackNode extends BEC_2_6_6_SystemObject {
public BEC_3_9_5_4_ContainerStackNode() { }
private static byte[] becc_BEC_3_9_5_4_ContainerStackNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_5_4_ContainerStackNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_3_9_5_4_ContainerStackNode bece_BEC_3_9_5_4_ContainerStackNode_bevs_inst;

public static BET_3_9_5_4_ContainerStackNode bece_BEC_3_9_5_4_ContainerStackNode_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_next;
public BEC_3_9_5_4_ContainerStackNode bevp_prior;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_5_4_ContainerStackNode bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_nextGet_0() throws Throwable {
return bevp_next;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_nextGetDirect_0() throws Throwable {
return bevp_next;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_nextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_next = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_nextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_next = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_priorGet_0() throws Throwable {
return bevp_prior;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_priorGetDirect_0() throws Throwable {
return bevp_prior;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_priorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prior = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_priorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_prior = (BEC_3_9_5_4_ContainerStackNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_heldGetDirect_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_3_9_5_4_ContainerStackNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 21, 24, 28, 32, 35, 38, 42, 46, 49, 52, 56};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
return 1 0 18
return 1 0 21
assign 1 0 24
assign 1 0 28
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1581478205: return bem_iteratorGet_0();
case 1940605188: return bem_priorGet_0();
case 448996129: return bem_classNameGet_0();
case 1620426785: return bem_fieldIteratorGet_0();
case -1243764713: return bem_sourceFileNameGet_0();
case -1752732439: return bem_heldGetDirect_0();
case -1564435804: return bem_new_0();
case 760457360: return bem_nextGet_0();
case -2046304502: return bem_create_0();
case 923155795: return bem_nextGetDirect_0();
case 487655943: return bem_hashGet_0();
case 440169444: return bem_tagGet_0();
case -1633309881: return bem_echo_0();
case 1998804429: return bem_deserializeClassNameGet_0();
case -2033056683: return bem_serializeToString_0();
case 1753870972: return bem_priorGetDirect_0();
case -1624889671: return bem_copy_0();
case -1318471451: return bem_toString_0();
case -737828887: return bem_serializeContents_0();
case 1483871301: return bem_print_0();
case 1177953347: return bem_fieldNamesGet_0();
case -1142809906: return bem_serializationIteratorGet_0();
case 736468783: return bem_heldGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1690489710: return bem_nextSetDirect_1(bevd_0);
case -1125735465: return bem_priorSetDirect_1(bevd_0);
case 2030577110: return bem_priorSet_1(bevd_0);
case 1655576193: return bem_undef_1(bevd_0);
case 1748352749: return bem_heldSet_1(bevd_0);
case 368768089: return bem_nextSet_1(bevd_0);
case 1724702365: return bem_copyTo_1(bevd_0);
case -1900502363: return bem_def_1(bevd_0);
case -1801363800: return bem_sameType_1(bevd_0);
case 1276126874: return bem_otherType_1(bevd_0);
case -776802815: return bem_notEquals_1(bevd_0);
case -1217337757: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -40889849: return bem_equals_1(bevd_0);
case 965946056: return bem_sameClass_1(bevd_0);
case 887328988: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -48526213: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 797054525: return bem_heldSetDirect_1(bevd_0);
case -1767763000: return bem_sameObject_1(bevd_0);
case -1601506198: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -180551001: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -984805442: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 162928067: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -336527550: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1644303351: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_9_5_4_ContainerStackNode_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_3_9_5_4_ContainerStackNode_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_5_4_ContainerStackNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_5_4_ContainerStackNode.bece_BEC_3_9_5_4_ContainerStackNode_bevs_inst = (BEC_3_9_5_4_ContainerStackNode) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_5_4_ContainerStackNode.bece_BEC_3_9_5_4_ContainerStackNode_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_9_5_4_ContainerStackNode.bece_BEC_3_9_5_4_ContainerStackNode_bevs_type;
}
}
