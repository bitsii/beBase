package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeHex extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeHex() { }
private static byte[] becc_BEC_2_6_3_EncodeHex_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x65,0x78};
private static byte[] becc_BEC_2_6_3_EncodeHex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_3_EncodeHex_bels_0 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x68,0x65,0x78,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeHex_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeHex_bels_0, 26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_6 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_inst;

public static BET_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_type;

public BEC_2_6_3_EncodeHex bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl_ac = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_cur = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_0;
bevt_1_tmpany_phold = bevl_ssz.bem_multiply_1(bevt_2_tmpany_phold);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
bevl_pos = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 20 */ {
if (bevl_pos.bevi_int < bevl_ssz.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 20 */ {
beva_str.bem_getCode_2(bevl_pos, bevl_ac);
bevt_4_tmpany_phold = bevl_ac.bem_toHexString_1(bevl_cur);
bevl_r.bem_addValue_1(bevt_4_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 20 */
 else  /* Line: 20 */ {
break;
} /* Line: 20 */
} /* Line: 20 */
return bevl_r;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pta = null;
BEC_2_4_6_TextString bevl_ptb = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_1;
if (bevl_ssz.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 29 */ {
return beva_str;
} /* Line: 30 */
bevt_4_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_2;
bevt_3_tmpany_phold = bevl_ssz.bem_modulus_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_3;
if (bevt_3_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 32 */ {
bevt_8_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_4;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_ssz);
bevt_6_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 33 */
bevt_9_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_cur = (new BEC_2_4_6_TextString()).bem_new_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_5;
bevt_10_tmpany_phold = bevl_ssz.bem_divide_1(bevt_11_tmpany_phold);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_6;
bevt_12_tmpany_phold = bevl_ssz.bem_divide_1(bevt_13_tmpany_phold);
bevl_r.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_14_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_pta = (new BEC_2_4_6_TextString()).bem_new_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_ptb = (new BEC_2_4_6_TextString()).bem_new_1(bevt_15_tmpany_phold);
bevl_pos = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 42 */ {
bevt_16_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevl_tb.bem_next_1(bevl_pta);
bevl_tb.bem_next_1(bevl_ptb);
bevt_18_tmpany_phold = bevl_pta.bem_add_1(bevl_ptb);
bevt_17_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpany_phold);
bevl_r.bem_setCodeUnchecked_2(bevl_pos, bevt_17_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 46 */
 else  /* Line: 42 */ {
break;
} /* Line: 42 */
} /* Line: 42 */
return bevl_r;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 17, 18, 19, 19, 19, 20, 20, 20, 21, 22, 22, 20, 24, 28, 29, 29, 29, 30, 32, 32, 32, 32, 32, 33, 33, 33, 33, 35, 35, 36, 36, 36, 37, 37, 37, 38, 39, 39, 40, 40, 41, 42, 43, 44, 45, 45, 45, 46, 48};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {38, 39, 40, 41, 42, 43, 44, 45, 48, 53, 54, 55, 56, 57, 63, 92, 93, 94, 99, 100, 102, 103, 104, 105, 110, 111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 134, 135, 136, 137, 138, 139, 145};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 38
new 0 16 38
assign 1 17 39
new 0 17 39
assign 1 17 40
new 1 17 40
assign 1 18 41
sizeGet 0 18 41
assign 1 19 42
new 0 19 42
assign 1 19 43
multiply 1 19 43
assign 1 19 44
new 1 19 44
assign 1 20 45
new 0 20 45
assign 1 20 48
lesser 1 20 53
getCode 2 21 54
assign 1 22 55
toHexString 1 22 55
addValue 1 22 56
incrementValue 0 20 57
return 1 24 63
assign 1 28 92
sizeGet 0 28 92
assign 1 29 93
new 0 29 93
assign 1 29 94
lesser 1 29 99
return 1 30 100
assign 1 32 102
new 0 32 102
assign 1 32 103
modulus 1 32 103
assign 1 32 104
new 0 32 104
assign 1 32 105
notEquals 1 32 110
assign 1 33 111
new 0 33 111
assign 1 33 112
add 1 33 112
assign 1 33 113
new 1 33 113
throw 1 33 114
assign 1 35 116
new 0 35 116
assign 1 35 117
new 1 35 117
assign 1 36 118
new 0 36 118
assign 1 36 119
divide 1 36 119
assign 1 36 120
new 1 36 120
assign 1 37 121
new 0 37 121
assign 1 37 122
divide 1 37 122
sizeSet 1 37 123
assign 1 38 124
new 1 38 124
assign 1 39 125
new 0 39 125
assign 1 39 126
new 1 39 126
assign 1 40 127
new 0 40 127
assign 1 40 128
new 1 40 128
assign 1 41 129
new 0 41 129
assign 1 42 132
hasNextGet 0 42 132
next 1 43 134
next 1 44 135
assign 1 45 136
add 1 45 136
assign 1 45 137
hexNew 1 45 137
setCodeUnchecked 2 45 138
incrementValue 0 46 139
return 1 48 145
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -738439163: return bem_copy_0();
case 2084331281: return bem_new_0();
case 690609043: return bem_print_0();
case -2035186982: return bem_deserializeClassNameGet_0();
case -1522610135: return bem_serializeToString_0();
case -576502505: return bem_create_0();
case 247075507: return bem_fieldNamesGet_0();
case 320622940: return bem_echo_0();
case 484635838: return bem_tagGet_0();
case 1969080256: return bem_once_0();
case 101762581: return bem_serializeContents_0();
case 1551415145: return bem_toAny_0();
case 645211302: return bem_iteratorGet_0();
case -1966626789: return bem_hashGet_0();
case -357139526: return bem_many_0();
case 983736684: return bem_serializationIteratorGet_0();
case 1954228088: return bem_default_0();
case -1313098664: return bem_toString_0();
case -753430171: return bem_fieldIteratorGet_0();
case -2005156683: return bem_classNameGet_0();
case -890719598: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -559803890: return bem_notEquals_1(bevd_0);
case 1910152431: return bem_sameClass_1(bevd_0);
case -473700926: return bem_sameObject_1(bevd_0);
case 1896874275: return bem_otherType_1(bevd_0);
case -902039612: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1876359344: return bem_equals_1(bevd_0);
case -1154436290: return bem_defined_1(bevd_0);
case 758604875: return bem_def_1(bevd_0);
case -270136413: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case -2062507408: return bem_undef_1(bevd_0);
case -670773723: return bem_sameType_1(bevd_0);
case -1078272144: return bem_undefined_1(bevd_0);
case 217714273: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1478212774: return bem_copyTo_1(bevd_0);
case 2112095476: return bem_otherClass_1(bevd_0);
case 2108792600: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1965533312: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1206543614: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1242523227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1600509677: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 651135504: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1800551052: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1224280394: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1480151031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299689611: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeHex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeHex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeHex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst = (BEC_2_6_3_EncodeHex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_type;
}
}
