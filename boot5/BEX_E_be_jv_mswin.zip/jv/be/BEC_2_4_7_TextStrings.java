package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_5 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_7_TextStrings_bels_6 = {};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_6, 0));
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_4));
bevp_lineSplitter = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(-1817966493);
bevt_1_tmpany_phold = bevl_i.bemd_0(2096550402);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-907968257);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1215 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1216 */
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(-2029555311);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1220 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(2096550402);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 1220 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(-2029555311);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1222 */
 else  /* Line: 1220 */ {
break;
} /* Line: 1220 */
} /* Line: 1220 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1232 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1232 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1234 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1235 */ {
bevl_end.bevi_int++;
} /* Line: 1236 */
 else  /* Line: 1237 */ {
bevl_beg.bevi_int++;
} /* Line: 1238 */
} /* Line: 1235 */
 else  /* Line: 1240 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1242 */
} /* Line: 1234 */
 else  /* Line: 1232 */ {
break;
} /* Line: 1232 */
} /* Line: 1232 */
if (bevl_foundChar.bevi_bool) /* Line: 1245 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1246 */
 else  /* Line: 1247 */ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_5));
} /* Line: 1248 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1254 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1254 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1254 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1254 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1254 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1254 */ {
return null;
} /* Line: 1254 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1260 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1260 */ {
bevl_ai.bemd_1(-1298631985, bevl_av);
bevl_bi.bemd_1(-1298631985, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1263 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1264 */
bevl_i.bevi_int++;
} /* Line: 1260 */
 else  /* Line: 1260 */ {
break;
} /* Line: 1260 */
} /* Line: 1260 */
bevt_11_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(-1817966493);
while (true)
 /* Line: 1271 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(2096550402);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 1271 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-2029555311);
bevt_2_tmpany_phold = bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1272 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1273 */
} /* Line: 1272 */
 else  /* Line: 1271 */ {
break;
} /* Line: 1271 */
} /* Line: 1271 */
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1280 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1280 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1280 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1280 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1280 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1280 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1281 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1287 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1287 */
 else  /* Line: 1287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1287 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1288 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public final BEC_2_4_6_TextString bem_emptyGetDirect_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public final BEC_2_4_6_TextString bem_tabGetDirect_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_wsGetDirect_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1189, 1190, 1191, 1191, 1192, 1192, 1193, 1194, 1196, 1196, 1197, 1198, 1199, 1200, 1203, 1204, 1205, 1206, 1210, 1210, 1214, 1215, 1215, 1216, 1216, 1218, 1219, 1219, 1220, 1221, 1222, 1222, 1224, 1228, 1229, 1230, 1231, 1232, 1233, 1234, 1236, 1238, 1241, 1241, 1242, 1246, 1246, 1246, 1248, 1250, 1254, 1254, 0, 1254, 1254, 0, 0, 1254, 1255, 1255, 1255, 1255, 1256, 1257, 1258, 1259, 1260, 1260, 1260, 1261, 1262, 1263, 1264, 1264, 1264, 1260, 1267, 1267, 1267, 1271, 0, 1271, 1271, 1272, 1273, 1273, 1276, 1276, 1280, 1280, 0, 1280, 1280, 1280, 1280, 0, 0, 1281, 1281, 1283, 1283, 1287, 1287, 1287, 1287, 0, 0, 0, 1288, 1288, 1290, 1290, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 63, 64, 75, 76, 77, 79, 80, 82, 83, 84, 87, 89, 90, 91, 97, 111, 112, 113, 114, 117, 119, 120, 123, 126, 130, 131, 132, 140, 141, 142, 145, 147, 168, 173, 174, 177, 182, 183, 186, 190, 192, 193, 194, 195, 196, 197, 198, 199, 200, 203, 208, 209, 210, 211, 213, 214, 215, 217, 223, 224, 225, 234, 234, 237, 239, 240, 242, 243, 250, 251, 261, 266, 267, 270, 271, 272, 277, 278, 281, 285, 286, 288, 289, 298, 303, 304, 305, 307, 310, 314, 317, 318, 320, 321, 324, 327, 330, 334, 338, 341, 344, 348, 352, 355, 358, 362, 366, 369, 372, 376, 380, 383, 386, 390, 394, 397, 400, 404, 408, 411, 414, 418, 422, 425, 428, 432, 436, 439, 442, 446, 450, 453, 456, 460, 464, 467, 470, 474, 478, 481, 484, 488};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1189 41
new 0 1189 41
assign 1 1190 42
new 0 1190 42
assign 1 1191 43
new 0 1191 43
assign 1 1191 44
codeNew 1 1191 44
assign 1 1192 45
new 0 1192 45
assign 1 1192 46
codeNew 1 1192 46
assign 1 1193 47
new 0 1193 47
assign 1 1194 48
new 0 1194 48
assign 1 1196 49
new 0 1196 49
assign 1 1196 50
codeNew 1 1196 50
assign 1 1197 51
new 0 1197 51
assign 1 1198 52
new 0 1198 52
assign 1 1199 53
new 1 1199 53
assign 1 1200 54
new 0 1200 54
put 1 1203 55
put 1 1204 56
put 1 1205 57
put 1 1206 58
assign 1 1210 63
joinBuffer 2 1210 63
return 1 1210 64
assign 1 1214 75
iteratorGet 0 1214 75
assign 1 1215 76
hasNextGet 0 1215 76
assign 1 1215 77
not 0 1215 77
assign 1 1216 79
new 0 1216 79
return 1 1216 80
assign 1 1218 82
new 0 1218 82
assign 1 1219 83
nextGet 0 1219 83
addValue 1 1219 84
assign 1 1220 87
hasNextGet 0 1220 87
addValue 1 1221 89
assign 1 1222 90
nextGet 0 1222 90
addValue 1 1222 91
return 1 1224 97
assign 1 1228 111
new 0 1228 111
assign 1 1229 112
new 0 1229 112
assign 1 1230 113
new 0 1230 113
assign 1 1231 114
mbiterGet 0 1231 114
assign 1 1232 117
hasNextGet 0 1232 117
assign 1 1233 119
nextGet 0 1233 119
assign 1 1234 120
has 1 1234 120
incrementValue 0 1236 123
incrementValue 0 1238 126
assign 1 1241 130
new 0 1241 130
setValue 1 1241 131
assign 1 1242 132
new 0 1242 132
assign 1 1246 140
sizeGet 0 1246 140
assign 1 1246 141
subtract 1 1246 141
assign 1 1246 142
substring 2 1246 142
assign 1 1248 145
new 0 1248 145
return 1 1250 147
assign 1 1254 168
undef 1 1254 173
assign 1 0 174
assign 1 1254 177
undef 1 1254 182
assign 1 0 183
assign 1 0 186
return 1 1254 190
assign 1 1255 192
new 0 1255 192
assign 1 1255 193
sizeGet 0 1255 193
assign 1 1255 194
sizeGet 0 1255 194
assign 1 1255 195
min 2 1255 195
assign 1 1256 196
biterGet 0 1256 196
assign 1 1257 197
biterGet 0 1257 197
assign 1 1258 198
new 0 1258 198
assign 1 1259 199
new 0 1259 199
assign 1 1260 200
new 0 1260 200
assign 1 1260 203
lesser 1 1260 208
next 1 1261 209
next 1 1262 210
assign 1 1263 211
notEquals 1 1263 211
assign 1 1264 213
new 0 1264 213
assign 1 1264 214
substring 2 1264 214
return 1 1264 215
incrementValue 0 1260 217
assign 1 1267 223
new 0 1267 223
assign 1 1267 224
substring 2 1267 224
return 1 1267 225
assign 1 1271 234
iteratorGet 0 0 234
assign 1 1271 237
hasNextGet 0 1271 237
assign 1 1271 239
nextGet 0 1271 239
assign 1 1272 240
isEmpty 1 1272 240
assign 1 1273 242
new 0 1273 242
return 1 1273 243
assign 1 1276 250
new 0 1276 250
return 1 1276 251
assign 1 1280 261
undef 1 1280 266
assign 1 0 267
assign 1 1280 270
sizeGet 0 1280 270
assign 1 1280 271
new 0 1280 271
assign 1 1280 272
lesser 1 1280 277
assign 1 0 278
assign 1 0 281
assign 1 1281 285
new 0 1281 285
return 1 1281 286
assign 1 1283 288
new 0 1283 288
return 1 1283 289
assign 1 1287 298
def 1 1287 303
assign 1 1287 304
new 0 1287 304
assign 1 1287 305
notEquals 1 1287 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 1288 317
new 0 1288 317
return 1 1288 318
assign 1 1290 320
new 0 1290 320
return 1 1290 321
return 1 0 324
return 1 0 327
assign 1 0 330
assign 1 0 334
return 1 0 338
return 1 0 341
assign 1 0 344
assign 1 0 348
return 1 0 352
return 1 0 355
assign 1 0 358
assign 1 0 362
return 1 0 366
return 1 0 369
assign 1 0 372
assign 1 0 376
return 1 0 380
return 1 0 383
assign 1 0 386
assign 1 0 390
return 1 0 394
return 1 0 397
assign 1 0 400
assign 1 0 404
return 1 0 408
return 1 0 411
assign 1 0 414
assign 1 0 418
return 1 0 422
return 1 0 425
assign 1 0 428
assign 1 0 432
return 1 0 436
return 1 0 439
assign 1 0 442
assign 1 0 446
return 1 0 450
return 1 0 453
assign 1 0 456
assign 1 0 460
return 1 0 464
return 1 0 467
assign 1 0 470
assign 1 0 474
return 1 0 478
return 1 0 481
assign 1 0 484
assign 1 0 488
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -298761545: return bem_wsGetDirect_0();
case -201292676: return bem_create_0();
case -506301237: return bem_tabGetDirect_0();
case -2065475128: return bem_tagGet_0();
case -1968901261: return bem_colonGet_0();
case -507248646: return bem_toString_0();
case -479220991: return bem_echo_0();
case 67894489: return bem_sourceFileNameGet_0();
case -1455307952: return bem_lfGet_0();
case 1509454415: return bem_fieldNamesGet_0();
case -755857848: return bem_serializeToString_0();
case -1311839516: return bem_emptyGet_0();
case 1469451236: return bem_lfGetDirect_0();
case -842698583: return bem_print_0();
case 792990363: return bem_lineSplitterGetDirect_0();
case -853065569: return bem_dosNewlineGetDirect_0();
case 1741468409: return bem_unixNewlineGetDirect_0();
case -1011972693: return bem_classNameGet_0();
case -1312089850: return bem_serializationIteratorGet_0();
case 313316334: return bem_quoteGetDirect_0();
case 751429880: return bem_lineSplitterGet_0();
case 116405623: return bem_once_0();
case 838598675: return bem_deserializeClassNameGet_0();
case -537231128: return bem_default_0();
case -1837957928: return bem_crGet_0();
case 2027881489: return bem_new_0();
case -1817966493: return bem_iteratorGet_0();
case 66023749: return bem_copy_0();
case 1767145499: return bem_toAny_0();
case -1301303410: return bem_unixNewlineGet_0();
case 1880418594: return bem_many_0();
case 405773824: return bem_tabGet_0();
case 184118275: return bem_newlineGet_0();
case -1529975078: return bem_wsGet_0();
case 1996836904: return bem_spaceGetDirect_0();
case -176892220: return bem_dosNewlineGet_0();
case 1334238154: return bem_hashGet_0();
case -1315331363: return bem_newlineGetDirect_0();
case 614529942: return bem_quoteGet_0();
case -1560059449: return bem_crGetDirect_0();
case 1894047741: return bem_spaceGet_0();
case 1292255745: return bem_fieldIteratorGet_0();
case 554515774: return bem_colonGetDirect_0();
case 2047856226: return bem_emptyGetDirect_0();
case 1319463124: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 931801515: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1054348096: return bem_crSetDirect_1(bevd_0);
case -1922688096: return bem_anyEmpty_1(bevd_0);
case -890367556: return bem_undefined_1(bevd_0);
case 358154948: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1667173439: return bem_newlineSet_1(bevd_0);
case 1201016043: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1783216988: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -1932586343: return bem_colonSet_1(bevd_0);
case -589510836: return bem_colonSetDirect_1(bevd_0);
case 1902941795: return bem_defined_1(bevd_0);
case -1457990770: return bem_wsSet_1(bevd_0);
case -1156427997: return bem_spaceSetDirect_1(bevd_0);
case 1317453949: return bem_sameClass_1(bevd_0);
case -64044850: return bem_tabSet_1(bevd_0);
case 824292706: return bem_sameType_1(bevd_0);
case 1145352238: return bem_spaceSet_1(bevd_0);
case 268053743: return bem_lfSet_1(bevd_0);
case -1508117625: return bem_otherClass_1(bevd_0);
case 440989655: return bem_copyTo_1(bevd_0);
case -1890627721: return bem_notEquals_1(bevd_0);
case -1674451327: return bem_lineSplitterSetDirect_1(bevd_0);
case -1328502463: return bem_equals_1(bevd_0);
case -2128846113: return bem_tabSetDirect_1(bevd_0);
case -737237761: return bem_sameObject_1(bevd_0);
case 1014907467: return bem_lfSetDirect_1(bevd_0);
case 1109484816: return bem_dosNewlineSet_1(bevd_0);
case 534726363: return bem_lineSplitterSet_1(bevd_0);
case -1056961314: return bem_unixNewlineSet_1(bevd_0);
case 236521366: return bem_def_1(bevd_0);
case -1483817890: return bem_undef_1(bevd_0);
case 294864107: return bem_emptySet_1(bevd_0);
case -1159833031: return bem_wsSetDirect_1(bevd_0);
case -1201297683: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -1781450717: return bem_quoteSet_1(bevd_0);
case 1328462886: return bem_quoteSetDirect_1(bevd_0);
case 856934471: return bem_dosNewlineSetDirect_1(bevd_0);
case -2056533008: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1751676394: return bem_otherType_1(bevd_0);
case -1968558358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -393793995: return bem_newlineSetDirect_1(bevd_0);
case 1555862781: return bem_emptySetDirect_1(bevd_0);
case 1584896302: return bem_crSet_1(bevd_0);
case 2043733194: return bem_unixNewlineSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 77948450: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1008558996: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 139476281: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1704645214: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1221915514: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 42075544: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1195966778: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -393762612: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -778494517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1737168375: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
