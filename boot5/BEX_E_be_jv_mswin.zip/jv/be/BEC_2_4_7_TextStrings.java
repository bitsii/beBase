package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_5 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_7_TextStrings_bels_6 = {};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_6, 0));
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_4));
bevp_lineSplitter = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(-757699318);
bevt_1_tmpany_phold = bevl_i.bemd_0(-376656161);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-912093780);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1235 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1236 */
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(-968892996);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1240 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 1240 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(-968892996);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1242 */
 else  /* Line: 1240 */ {
break;
} /* Line: 1240 */
} /* Line: 1240 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1252 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1252 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1254 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1255 */ {
bevl_end.bevi_int++;
} /* Line: 1256 */
 else  /* Line: 1257 */ {
bevl_beg.bevi_int++;
} /* Line: 1258 */
} /* Line: 1255 */
 else  /* Line: 1260 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1262 */
} /* Line: 1254 */
 else  /* Line: 1252 */ {
break;
} /* Line: 1252 */
} /* Line: 1252 */
if (bevl_foundChar.bevi_bool) /* Line: 1265 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1266 */
 else  /* Line: 1267 */ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_5));
} /* Line: 1268 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1274 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1274 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1274 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1274 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1274 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1274 */ {
return null;
} /* Line: 1274 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1280 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1280 */ {
bevl_ai.bemd_1(978713440, bevl_av);
bevl_bi.bemd_1(978713440, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1283 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1284 */
bevl_i.bevi_int++;
} /* Line: 1280 */
 else  /* Line: 1280 */ {
break;
} /* Line: 1280 */
} /* Line: 1280 */
bevt_11_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(-757699318);
while (true)
 /* Line: 1291 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-376656161);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 1291 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-968892996);
bevt_2_tmpany_phold = bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1292 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1293 */
} /* Line: 1292 */
 else  /* Line: 1291 */ {
break;
} /* Line: 1291 */
} /* Line: 1291 */
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1300 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1300 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1300 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1300 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1301 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1307 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1307 */
 else  /* Line: 1307 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1307 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1308 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public final BEC_2_4_6_TextString bem_emptyGetDirect_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public final BEC_2_4_6_TextString bem_tabGetDirect_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_wsGetDirect_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1209, 1210, 1211, 1211, 1212, 1212, 1213, 1214, 1216, 1216, 1217, 1218, 1219, 1220, 1223, 1224, 1225, 1226, 1230, 1230, 1234, 1235, 1235, 1236, 1236, 1238, 1239, 1239, 1240, 1241, 1242, 1242, 1244, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1256, 1258, 1261, 1261, 1262, 1266, 1266, 1266, 1268, 1270, 1274, 1274, 0, 1274, 1274, 0, 0, 1274, 1275, 1275, 1275, 1275, 1276, 1277, 1278, 1279, 1280, 1280, 1280, 1281, 1282, 1283, 1284, 1284, 1284, 1280, 1287, 1287, 1287, 1291, 0, 1291, 1291, 1292, 1293, 1293, 1296, 1296, 1300, 1300, 0, 1300, 1300, 1300, 1300, 0, 0, 1301, 1301, 1303, 1303, 1307, 1307, 1307, 1307, 0, 0, 0, 1308, 1308, 1310, 1310, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 63, 64, 75, 76, 77, 79, 80, 82, 83, 84, 87, 89, 90, 91, 97, 111, 112, 113, 114, 117, 119, 120, 123, 126, 130, 131, 132, 140, 141, 142, 145, 147, 168, 173, 174, 177, 182, 183, 186, 190, 192, 193, 194, 195, 196, 197, 198, 199, 200, 203, 208, 209, 210, 211, 213, 214, 215, 217, 223, 224, 225, 234, 234, 237, 239, 240, 242, 243, 250, 251, 261, 266, 267, 270, 271, 272, 277, 278, 281, 285, 286, 288, 289, 298, 303, 304, 305, 307, 310, 314, 317, 318, 320, 321, 324, 327, 330, 334, 338, 341, 344, 348, 352, 355, 358, 362, 366, 369, 372, 376, 380, 383, 386, 390, 394, 397, 400, 404, 408, 411, 414, 418, 422, 425, 428, 432, 436, 439, 442, 446, 450, 453, 456, 460, 464, 467, 470, 474, 478, 481, 484, 488};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1209 41
new 0 1209 41
assign 1 1210 42
new 0 1210 42
assign 1 1211 43
new 0 1211 43
assign 1 1211 44
codeNew 1 1211 44
assign 1 1212 45
new 0 1212 45
assign 1 1212 46
codeNew 1 1212 46
assign 1 1213 47
new 0 1213 47
assign 1 1214 48
new 0 1214 48
assign 1 1216 49
new 0 1216 49
assign 1 1216 50
codeNew 1 1216 50
assign 1 1217 51
new 0 1217 51
assign 1 1218 52
new 0 1218 52
assign 1 1219 53
new 1 1219 53
assign 1 1220 54
new 0 1220 54
put 1 1223 55
put 1 1224 56
put 1 1225 57
put 1 1226 58
assign 1 1230 63
joinBuffer 2 1230 63
return 1 1230 64
assign 1 1234 75
iteratorGet 0 1234 75
assign 1 1235 76
hasNextGet 0 1235 76
assign 1 1235 77
not 0 1235 77
assign 1 1236 79
new 0 1236 79
return 1 1236 80
assign 1 1238 82
new 0 1238 82
assign 1 1239 83
nextGet 0 1239 83
addValue 1 1239 84
assign 1 1240 87
hasNextGet 0 1240 87
addValue 1 1241 89
assign 1 1242 90
nextGet 0 1242 90
addValue 1 1242 91
return 1 1244 97
assign 1 1248 111
new 0 1248 111
assign 1 1249 112
new 0 1249 112
assign 1 1250 113
new 0 1250 113
assign 1 1251 114
mbiterGet 0 1251 114
assign 1 1252 117
hasNextGet 0 1252 117
assign 1 1253 119
nextGet 0 1253 119
assign 1 1254 120
has 1 1254 120
incrementValue 0 1256 123
incrementValue 0 1258 126
assign 1 1261 130
new 0 1261 130
setValue 1 1261 131
assign 1 1262 132
new 0 1262 132
assign 1 1266 140
sizeGet 0 1266 140
assign 1 1266 141
subtract 1 1266 141
assign 1 1266 142
substring 2 1266 142
assign 1 1268 145
new 0 1268 145
return 1 1270 147
assign 1 1274 168
undef 1 1274 173
assign 1 0 174
assign 1 1274 177
undef 1 1274 182
assign 1 0 183
assign 1 0 186
return 1 1274 190
assign 1 1275 192
new 0 1275 192
assign 1 1275 193
sizeGet 0 1275 193
assign 1 1275 194
sizeGet 0 1275 194
assign 1 1275 195
min 2 1275 195
assign 1 1276 196
biterGet 0 1276 196
assign 1 1277 197
biterGet 0 1277 197
assign 1 1278 198
new 0 1278 198
assign 1 1279 199
new 0 1279 199
assign 1 1280 200
new 0 1280 200
assign 1 1280 203
lesser 1 1280 208
next 1 1281 209
next 1 1282 210
assign 1 1283 211
notEquals 1 1283 211
assign 1 1284 213
new 0 1284 213
assign 1 1284 214
substring 2 1284 214
return 1 1284 215
incrementValue 0 1280 217
assign 1 1287 223
new 0 1287 223
assign 1 1287 224
substring 2 1287 224
return 1 1287 225
assign 1 1291 234
iteratorGet 0 0 234
assign 1 1291 237
hasNextGet 0 1291 237
assign 1 1291 239
nextGet 0 1291 239
assign 1 1292 240
isEmpty 1 1292 240
assign 1 1293 242
new 0 1293 242
return 1 1293 243
assign 1 1296 250
new 0 1296 250
return 1 1296 251
assign 1 1300 261
undef 1 1300 266
assign 1 0 267
assign 1 1300 270
sizeGet 0 1300 270
assign 1 1300 271
new 0 1300 271
assign 1 1300 272
lesser 1 1300 277
assign 1 0 278
assign 1 0 281
assign 1 1301 285
new 0 1301 285
return 1 1301 286
assign 1 1303 288
new 0 1303 288
return 1 1303 289
assign 1 1307 298
def 1 1307 303
assign 1 1307 304
new 0 1307 304
assign 1 1307 305
notEquals 1 1307 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 1308 317
new 0 1308 317
return 1 1308 318
assign 1 1310 320
new 0 1310 320
return 1 1310 321
return 1 0 324
return 1 0 327
assign 1 0 330
assign 1 0 334
return 1 0 338
return 1 0 341
assign 1 0 344
assign 1 0 348
return 1 0 352
return 1 0 355
assign 1 0 358
assign 1 0 362
return 1 0 366
return 1 0 369
assign 1 0 372
assign 1 0 376
return 1 0 380
return 1 0 383
assign 1 0 386
assign 1 0 390
return 1 0 394
return 1 0 397
assign 1 0 400
assign 1 0 404
return 1 0 408
return 1 0 411
assign 1 0 414
assign 1 0 418
return 1 0 422
return 1 0 425
assign 1 0 428
assign 1 0 432
return 1 0 436
return 1 0 439
assign 1 0 442
assign 1 0 446
return 1 0 450
return 1 0 453
assign 1 0 456
assign 1 0 460
return 1 0 464
return 1 0 467
assign 1 0 470
assign 1 0 474
return 1 0 478
return 1 0 481
assign 1 0 484
assign 1 0 488
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -919772434: return bem_serializeToString_0();
case 642070524: return bem_lfGet_0();
case 1928293906: return bem_once_0();
case 619304343: return bem_hashGet_0();
case 11282728: return bem_unixNewlineGetDirect_0();
case 1623987490: return bem_serializeContents_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case -6225362: return bem_colonGetDirect_0();
case 868760417: return bem_serializationIteratorGet_0();
case -1836757512: return bem_copy_0();
case 1452564531: return bem_toString_0();
case -757699318: return bem_iteratorGet_0();
case -2036660777: return bem_lineSplitterGet_0();
case -426748589: return bem_tabGetDirect_0();
case -977356120: return bem_fieldNamesGet_0();
case 695404569: return bem_colonGet_0();
case 1605752359: return bem_many_0();
case 363694257: return bem_crGet_0();
case 438244040: return bem_create_0();
case 1576417178: return bem_new_0();
case 1540701856: return bem_newlineGetDirect_0();
case -197180620: return bem_echo_0();
case 1148186102: return bem_toAny_0();
case -788466745: return bem_quoteGet_0();
case 141983605: return bem_sourceFileNameGet_0();
case -464967776: return bem_classNameGet_0();
case -1520760089: return bem_crGetDirect_0();
case 1477327553: return bem_emptyGetDirect_0();
case 1812290526: return bem_dosNewlineGet_0();
case -1392560126: return bem_default_0();
case 1904467727: return bem_wsGetDirect_0();
case 1835552039: return bem_emptyGet_0();
case -2043275614: return bem_newlineGet_0();
case 500389220: return bem_print_0();
case 311903593: return bem_dosNewlineGetDirect_0();
case -1755286835: return bem_lfGetDirect_0();
case 125698124: return bem_tabGet_0();
case 1680191403: return bem_spaceGet_0();
case -978724962: return bem_tagGet_0();
case -1621348100: return bem_wsGet_0();
case -1090937688: return bem_quoteGetDirect_0();
case -1895797969: return bem_fieldIteratorGet_0();
case 1729452675: return bem_lineSplitterGetDirect_0();
case -1877580916: return bem_unixNewlineGet_0();
case -1549652002: return bem_spaceGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 265585672: return bem_dosNewlineSet_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case 20041106: return bem_tabSetDirect_1(bevd_0);
case 1683373983: return bem_crSetDirect_1(bevd_0);
case -1145983358: return bem_lineSplitterSetDirect_1(bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2098577860: return bem_wsSetDirect_1(bevd_0);
case 1645821851: return bem_quoteSetDirect_1(bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case -359692434: return bem_lfSetDirect_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case -75056595: return bem_newlineSetDirect_1(bevd_0);
case -255403389: return bem_lineSplitterSet_1(bevd_0);
case 728620706: return bem_crSet_1(bevd_0);
case 1376268468: return bem_unixNewlineSetDirect_1(bevd_0);
case -1032559787: return bem_anyEmpty_1(bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case -813077352: return bem_emptySetDirect_1(bevd_0);
case -2113742259: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1640744793: return bem_wsSet_1(bevd_0);
case 2098222421: return bem_spaceSetDirect_1(bevd_0);
case 1678986152: return bem_colonSetDirect_1(bevd_0);
case -1925047504: return bem_tabSet_1(bevd_0);
case 165856803: return bem_unixNewlineSet_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case -1202384671: return bem_spaceSet_1(bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1699509988: return bem_emptySet_1(bevd_0);
case -768928417: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -834444306: return bem_quoteSet_1(bevd_0);
case -2119072580: return bem_colonSet_1(bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case -1324271977: return bem_dosNewlineSetDirect_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case -445596629: return bem_lfSet_1(bevd_0);
case 2140743337: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -2080355933: return bem_defined_1(bevd_0);
case 399101659: return bem_newlineSet_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1119650013: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1689848238: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1831519352: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
