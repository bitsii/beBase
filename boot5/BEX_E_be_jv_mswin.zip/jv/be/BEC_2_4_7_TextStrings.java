package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_4, 0));
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_lineSplitter = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(656174411);
bevt_1_ta_ph = bevl_i.bemd_0(-639931739);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1550076237);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1289*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1290*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(1817051966);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1294*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1294*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(1817051966);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1296*/
 else /* Line: 1294*/ {
break;
} /* Line: 1294*/
} /* Line: 1294*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1306*/ {
bevt_0_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 1306*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_ta_ph = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_ta_ph.bevi_bool)/* Line: 1308*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1309*/ {
bevl_end.bevi_int++;
} /* Line: 1310*/
 else /* Line: 1311*/ {
bevl_beg.bevi_int++;
} /* Line: 1312*/
} /* Line: 1309*/
 else /* Line: 1314*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1316*/
} /* Line: 1308*/
 else /* Line: 1306*/ {
break;
} /* Line: 1306*/
} /* Line: 1306*/
if (bevl_foundChar.bevi_bool)/* Line: 1319*/ {
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_ta_ph);
} /* Line: 1320*/
 else /* Line: 1321*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1322*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1328*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1328*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1328*/ {
return null;
} /* Line: 1328*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1334*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1334*/ {
bevl_ai.bemd_1(-1963039772, bevl_av);
bevl_bi.bemd_1(-1963039772, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1337*/ {
bevt_9_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1338*/
bevl_i.bevi_int++;
} /* Line: 1334*/
 else /* Line: 1334*/ {
break;
} /* Line: 1334*/
} /* Line: 1334*/
bevt_11_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(656174411);
while (true)
/* Line: 1345*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-639931739);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1345*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(1817051966);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1346*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1347*/
} /* Line: 1346*/
 else /* Line: 1345*/ {
break;
} /* Line: 1345*/
} /* Line: 1345*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1354*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1354*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1354*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1355*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_3_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_ta_ph = beva_value.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1361*/
 else /* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1361*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1362*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public final BEC_2_4_6_TextString bem_emptyGetDirect_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public final BEC_2_4_6_TextString bem_tabGetDirect_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public final BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() throws Throwable {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_wsGetDirect_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1263, 1264, 1265, 1265, 1266, 1266, 1267, 1268, 1270, 1270, 1271, 1272, 1273, 1274, 1277, 1278, 1279, 1280, 1284, 1284, 1288, 1289, 1289, 1290, 1290, 1292, 1293, 1293, 1294, 1295, 1296, 1296, 1298, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1310, 1312, 1315, 1315, 1316, 1320, 1320, 1320, 1322, 1324, 1328, 1328, 0, 1328, 1328, 0, 0, 1328, 1329, 1329, 1329, 1329, 1330, 1331, 1332, 1333, 1334, 1334, 1334, 1335, 1336, 1337, 1338, 1338, 1338, 1334, 1341, 1341, 1341, 1345, 0, 1345, 1345, 1346, 1347, 1347, 1350, 1350, 1354, 1354, 0, 1354, 1354, 1354, 1354, 0, 0, 1355, 1355, 1357, 1357, 1361, 1361, 1361, 1361, 0, 0, 0, 1362, 1362, 1364, 1364, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 61, 62, 73, 74, 75, 77, 78, 80, 81, 82, 85, 87, 88, 89, 95, 109, 110, 111, 112, 115, 117, 118, 121, 124, 128, 129, 130, 138, 139, 140, 143, 145, 166, 171, 172, 175, 180, 181, 184, 188, 190, 191, 192, 193, 194, 195, 196, 197, 198, 201, 206, 207, 208, 209, 211, 212, 213, 215, 221, 222, 223, 232, 232, 235, 237, 238, 240, 241, 248, 249, 259, 264, 265, 268, 269, 270, 275, 276, 279, 283, 284, 286, 287, 296, 301, 302, 303, 305, 308, 312, 315, 316, 318, 319, 322, 325, 328, 332, 336, 339, 342, 346, 350, 353, 356, 360, 364, 367, 370, 374, 378, 381, 384, 388, 392, 395, 398, 402, 406, 409, 412, 416, 420, 423, 426, 430, 434, 437, 440, 444, 448, 451, 454, 458, 462, 465, 468, 472, 476, 479, 482, 486};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1263 39
new 0 1263 39
assign 1 1264 40
new 0 1264 40
assign 1 1265 41
new 0 1265 41
assign 1 1265 42
codeNew 1 1265 42
assign 1 1266 43
new 0 1266 43
assign 1 1266 44
codeNew 1 1266 44
assign 1 1267 45
new 0 1267 45
assign 1 1268 46
new 0 1268 46
assign 1 1270 47
new 0 1270 47
assign 1 1270 48
codeNew 1 1270 48
assign 1 1271 49
new 0 1271 49
assign 1 1272 50
new 0 1272 50
assign 1 1273 51
new 1 1273 51
assign 1 1274 52
new 0 1274 52
put 1 1277 53
put 1 1278 54
put 1 1279 55
put 1 1280 56
assign 1 1284 61
joinBuffer 2 1284 61
return 1 1284 62
assign 1 1288 73
iteratorGet 0 1288 73
assign 1 1289 74
hasNextGet 0 1289 74
assign 1 1289 75
not 0 1289 75
assign 1 1290 77
new 0 1290 77
return 1 1290 78
assign 1 1292 80
new 0 1292 80
assign 1 1293 81
nextGet 0 1293 81
addValue 1 1293 82
assign 1 1294 85
hasNextGet 0 1294 85
addValue 1 1295 87
assign 1 1296 88
nextGet 0 1296 88
addValue 1 1296 89
return 1 1298 95
assign 1 1302 109
new 0 1302 109
assign 1 1303 110
new 0 1303 110
assign 1 1304 111
new 0 1304 111
assign 1 1305 112
mbiterGet 0 1305 112
assign 1 1306 115
hasNextGet 0 1306 115
assign 1 1307 117
nextGet 0 1307 117
assign 1 1308 118
has 1 1308 118
incrementValue 0 1310 121
incrementValue 0 1312 124
assign 1 1315 128
new 0 1315 128
setValue 1 1315 129
assign 1 1316 130
new 0 1316 130
assign 1 1320 138
sizeGet 0 1320 138
assign 1 1320 139
subtract 1 1320 139
assign 1 1320 140
substring 2 1320 140
assign 1 1322 143
new 0 1322 143
return 1 1324 145
assign 1 1328 166
undef 1 1328 171
assign 1 0 172
assign 1 1328 175
undef 1 1328 180
assign 1 0 181
assign 1 0 184
return 1 1328 188
assign 1 1329 190
new 0 1329 190
assign 1 1329 191
sizeGet 0 1329 191
assign 1 1329 192
sizeGet 0 1329 192
assign 1 1329 193
min 2 1329 193
assign 1 1330 194
biterGet 0 1330 194
assign 1 1331 195
biterGet 0 1331 195
assign 1 1332 196
new 0 1332 196
assign 1 1333 197
new 0 1333 197
assign 1 1334 198
new 0 1334 198
assign 1 1334 201
lesser 1 1334 206
next 1 1335 207
next 1 1336 208
assign 1 1337 209
notEquals 1 1337 209
assign 1 1338 211
new 0 1338 211
assign 1 1338 212
substring 2 1338 212
return 1 1338 213
incrementValue 0 1334 215
assign 1 1341 221
new 0 1341 221
assign 1 1341 222
substring 2 1341 222
return 1 1341 223
assign 1 1345 232
iteratorGet 0 0 232
assign 1 1345 235
hasNextGet 0 1345 235
assign 1 1345 237
nextGet 0 1345 237
assign 1 1346 238
isEmpty 1 1346 238
assign 1 1347 240
new 0 1347 240
return 1 1347 241
assign 1 1350 248
new 0 1350 248
return 1 1350 249
assign 1 1354 259
undef 1 1354 264
assign 1 0 265
assign 1 1354 268
sizeGet 0 1354 268
assign 1 1354 269
new 0 1354 269
assign 1 1354 270
lesser 1 1354 275
assign 1 0 276
assign 1 0 279
assign 1 1355 283
new 0 1355 283
return 1 1355 284
assign 1 1357 286
new 0 1357 286
return 1 1357 287
assign 1 1361 296
def 1 1361 301
assign 1 1361 302
new 0 1361 302
assign 1 1361 303
notEquals 1 1361 303
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 1362 315
new 0 1362 315
return 1 1362 316
assign 1 1364 318
new 0 1364 318
return 1 1364 319
return 1 0 322
return 1 0 325
assign 1 0 328
assign 1 0 332
return 1 0 336
return 1 0 339
assign 1 0 342
assign 1 0 346
return 1 0 350
return 1 0 353
assign 1 0 356
assign 1 0 360
return 1 0 364
return 1 0 367
assign 1 0 370
assign 1 0 374
return 1 0 378
return 1 0 381
assign 1 0 384
assign 1 0 388
return 1 0 392
return 1 0 395
assign 1 0 398
assign 1 0 402
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
return 1 0 434
return 1 0 437
assign 1 0 440
assign 1 0 444
return 1 0 448
return 1 0 451
assign 1 0 454
assign 1 0 458
return 1 0 462
return 1 0 465
assign 1 0 468
assign 1 0 472
return 1 0 476
return 1 0 479
assign 1 0 482
assign 1 0 486
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 181316061: return bem_serializeContents_0();
case -324185690: return bem_wsGetDirect_0();
case -1904449087: return bem_lfGet_0();
case -212200476: return bem_tabGet_0();
case -1667230363: return bem_new_0();
case 1422294520: return bem_create_0();
case 656174411: return bem_iteratorGet_0();
case 602946146: return bem_quoteGet_0();
case -1394302703: return bem_colonGetDirect_0();
case 203483001: return bem_wsGet_0();
case 879964228: return bem_newlineGet_0();
case 1333189262: return bem_copy_0();
case 2089256478: return bem_crGetDirect_0();
case -62303276: return bem_dosNewlineGetDirect_0();
case 1887791078: return bem_toAny_0();
case 1104438617: return bem_serializationIteratorGet_0();
case 262658837: return bem_default_0();
case -434766936: return bem_many_0();
case 1258540231: return bem_print_0();
case -1293804761: return bem_colonGet_0();
case -1676070560: return bem_quoteGetDirect_0();
case -1134589630: return bem_serializeToString_0();
case 1337499076: return bem_fieldIteratorGet_0();
case -557795747: return bem_crGet_0();
case 468213427: return bem_newlineGetDirect_0();
case 1719683485: return bem_lineSplitterGetDirect_0();
case 238716313: return bem_once_0();
case -795525687: return bem_lineSplitterGet_0();
case -1193538733: return bem_echo_0();
case -1420115637: return bem_spaceGet_0();
case 437959120: return bem_emptyGetDirect_0();
case 2070121114: return bem_unixNewlineGetDirect_0();
case 470335985: return bem_fieldNamesGet_0();
case -622849069: return bem_dosNewlineGet_0();
case 1777640360: return bem_emptyGet_0();
case -2068645774: return bem_toString_0();
case -1030382289: return bem_tabGetDirect_0();
case 254283761: return bem_classNameGet_0();
case -1324510206: return bem_lfGetDirect_0();
case 1433312714: return bem_deserializeClassNameGet_0();
case 32986096: return bem_tagGet_0();
case -1279093521: return bem_unixNewlineGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 2056954789: return bem_spaceGetDirect_0();
case -1916545082: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 270879073: return bem_quoteSet_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case -1253785775: return bem_unixNewlineSet_1(bevd_0);
case 1374493979: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case 1158016650: return bem_newlineSet_1(bevd_0);
case -588682562: return bem_tabSet_1(bevd_0);
case -1317959013: return bem_emptySetDirect_1(bevd_0);
case -1630265260: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1322839245: return bem_lfSetDirect_1(bevd_0);
case 1505010901: return bem_colonSet_1(bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case 1290216463: return bem_def_1(bevd_0);
case 1399677878: return bem_emptySet_1(bevd_0);
case 853448267: return bem_dosNewlineSetDirect_1(bevd_0);
case -1294248330: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 980841770: return bem_lineSplitterSetDirect_1(bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case -1094150413: return bem_spaceSet_1(bevd_0);
case 2043493280: return bem_quoteSetDirect_1(bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 890991530: return bem_newlineSetDirect_1(bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -1741196387: return bem_colonSetDirect_1(bevd_0);
case 821642115: return bem_spaceSetDirect_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case 1778296473: return bem_wsSetDirect_1(bevd_0);
case 2146221216: return bem_dosNewlineSet_1(bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case 49383954: return bem_crSet_1(bevd_0);
case 1612880355: return bem_unixNewlineSetDirect_1(bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 414259648: return bem_tabSetDirect_1(bevd_0);
case -1158127620: return bem_lineSplitterSet_1(bevd_0);
case -1187465808: return bem_wsSet_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case -899984872: return bem_anyEmpty_1(bevd_0);
case 1353572161: return bem_lfSet_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
case -1454421813: return bem_crSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1405037783: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -418305738: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -448963625: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
