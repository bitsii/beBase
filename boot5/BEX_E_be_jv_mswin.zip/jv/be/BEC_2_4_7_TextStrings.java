package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(2087607686);
bevt_1_ta_ph = bevl_i.bemd_0(88707603);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-25850764);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1268*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1269*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(99596078);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1273*/ {
bevt_4_ta_ph = bevl_i.bemd_0(88707603);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1273*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(99596078);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1275*/
 else /* Line: 1273*/ {
break;
} /* Line: 1273*/
} /* Line: 1273*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1285*/ {
bevt_0_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 1285*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_ta_ph = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_ta_ph.bevi_bool)/* Line: 1287*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1288*/ {
bevl_end.bevi_int++;
} /* Line: 1289*/
 else /* Line: 1290*/ {
bevl_beg.bevi_int++;
} /* Line: 1291*/
} /* Line: 1288*/
 else /* Line: 1293*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1295*/
} /* Line: 1287*/
 else /* Line: 1285*/ {
break;
} /* Line: 1285*/
} /* Line: 1285*/
if (bevl_foundChar.bevi_bool)/* Line: 1298*/ {
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_ta_ph);
} /* Line: 1299*/
 else /* Line: 1300*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1301*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1307*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1307*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1307*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1307*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1307*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1307*/ {
return null;
} /* Line: 1307*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1313*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1313*/ {
bevl_ai.bemd_1(-450002341, bevl_av);
bevl_bi.bemd_1(-450002341, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1316*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1317*/
bevl_i.bevi_int++;
} /* Line: 1313*/
 else /* Line: 1313*/ {
break;
} /* Line: 1313*/
} /* Line: 1313*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(2087607686);
while (true)
/* Line: 1324*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(88707603);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1324*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(99596078);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1325*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1326*/
} /* Line: 1325*/
 else /* Line: 1324*/ {
break;
} /* Line: 1324*/
} /* Line: 1324*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1333*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1333*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1333*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1333*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1333*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1333*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1334*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1340*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
bevt_2_ta_ph = beva_value.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1340*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1340*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1340*/
 else /* Line: 1340*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1340*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1341*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public final BEC_2_4_3_MathInt bem_zeroGetDirect_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public final BEC_2_4_6_TextString bem_emptyGetDirect_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public final BEC_2_4_6_TextString bem_tabGetDirect_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_wsGetDirect_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1242, 1243, 1244, 1245, 1245, 1246, 1246, 1247, 1248, 1250, 1250, 1251, 1252, 1253, 1256, 1257, 1258, 1259, 1263, 1263, 1267, 1268, 1268, 1269, 1269, 1271, 1272, 1272, 1273, 1274, 1275, 1275, 1277, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1289, 1291, 1294, 1294, 1295, 1299, 1299, 1299, 1301, 1303, 1307, 1307, 0, 1307, 1307, 0, 0, 1307, 1308, 1308, 1308, 1308, 1309, 1310, 1311, 1312, 1313, 1313, 1313, 1314, 1315, 1316, 1317, 1317, 1317, 1313, 1320, 1320, 1320, 1324, 0, 1324, 1324, 1325, 1326, 1326, 1329, 1329, 1333, 1333, 0, 1333, 1333, 1333, 1333, 0, 0, 1334, 1334, 1336, 1336, 1340, 1340, 1340, 1340, 0, 0, 0, 1341, 1341, 1343, 1343, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 57, 58, 69, 70, 71, 73, 74, 76, 77, 78, 81, 83, 84, 85, 91, 105, 106, 107, 108, 111, 113, 114, 117, 120, 124, 125, 126, 134, 135, 136, 139, 141, 162, 167, 168, 171, 176, 177, 180, 184, 186, 187, 188, 189, 190, 191, 192, 193, 194, 197, 202, 203, 204, 205, 207, 208, 209, 211, 217, 218, 219, 228, 228, 231, 233, 234, 236, 237, 244, 245, 255, 260, 261, 264, 265, 266, 271, 272, 275, 279, 280, 282, 283, 292, 297, 298, 299, 301, 304, 308, 311, 312, 314, 315, 318, 321, 324, 328, 332, 335, 338, 342, 346, 349, 352, 356, 360, 363, 366, 370, 374, 377, 380, 384, 388, 391, 394, 398, 402, 405, 408, 412, 416, 419, 422, 426, 430, 433, 436, 440, 444, 447, 450, 454, 458, 461, 464, 468, 472, 475, 478, 482};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1242 35
new 0 1242 35
assign 1 1243 36
new 0 1243 36
assign 1 1244 37
new 0 1244 37
assign 1 1245 38
new 0 1245 38
assign 1 1245 39
codeNew 1 1245 39
assign 1 1246 40
new 0 1246 40
assign 1 1246 41
codeNew 1 1246 41
assign 1 1247 42
new 0 1247 42
assign 1 1248 43
new 0 1248 43
assign 1 1250 44
new 0 1250 44
assign 1 1250 45
codeNew 1 1250 45
assign 1 1251 46
new 0 1251 46
assign 1 1252 47
new 0 1252 47
assign 1 1253 48
new 0 1253 48
put 1 1256 49
put 1 1257 50
put 1 1258 51
put 1 1259 52
assign 1 1263 57
joinBuffer 2 1263 57
return 1 1263 58
assign 1 1267 69
iteratorGet 0 1267 69
assign 1 1268 70
hasNextGet 0 1268 70
assign 1 1268 71
not 0 1268 71
assign 1 1269 73
new 0 1269 73
return 1 1269 74
assign 1 1271 76
new 0 1271 76
assign 1 1272 77
nextGet 0 1272 77
addValue 1 1272 78
assign 1 1273 81
hasNextGet 0 1273 81
addValue 1 1274 83
assign 1 1275 84
nextGet 0 1275 84
addValue 1 1275 85
return 1 1277 91
assign 1 1281 105
new 0 1281 105
assign 1 1282 106
new 0 1282 106
assign 1 1283 107
new 0 1283 107
assign 1 1284 108
mbiterGet 0 1284 108
assign 1 1285 111
hasNextGet 0 1285 111
assign 1 1286 113
nextGet 0 1286 113
assign 1 1287 114
has 1 1287 114
incrementValue 0 1289 117
incrementValue 0 1291 120
assign 1 1294 124
new 0 1294 124
setValue 1 1294 125
assign 1 1295 126
new 0 1295 126
assign 1 1299 134
sizeGet 0 1299 134
assign 1 1299 135
subtract 1 1299 135
assign 1 1299 136
substring 2 1299 136
assign 1 1301 139
new 0 1301 139
return 1 1303 141
assign 1 1307 162
undef 1 1307 167
assign 1 0 168
assign 1 1307 171
undef 1 1307 176
assign 1 0 177
assign 1 0 180
return 1 1307 184
assign 1 1308 186
new 0 1308 186
assign 1 1308 187
sizeGet 0 1308 187
assign 1 1308 188
sizeGet 0 1308 188
assign 1 1308 189
min 2 1308 189
assign 1 1309 190
biterGet 0 1309 190
assign 1 1310 191
biterGet 0 1310 191
assign 1 1311 192
new 0 1311 192
assign 1 1312 193
new 0 1312 193
assign 1 1313 194
new 0 1313 194
assign 1 1313 197
lesser 1 1313 202
next 1 1314 203
next 1 1315 204
assign 1 1316 205
notEquals 1 1316 205
assign 1 1317 207
new 0 1317 207
assign 1 1317 208
substring 2 1317 208
return 1 1317 209
incrementValue 0 1313 211
assign 1 1320 217
new 0 1320 217
assign 1 1320 218
substring 2 1320 218
return 1 1320 219
assign 1 1324 228
iteratorGet 0 0 228
assign 1 1324 231
hasNextGet 0 1324 231
assign 1 1324 233
nextGet 0 1324 233
assign 1 1325 234
isEmpty 1 1325 234
assign 1 1326 236
new 0 1326 236
return 1 1326 237
assign 1 1329 244
new 0 1329 244
return 1 1329 245
assign 1 1333 255
undef 1 1333 260
assign 1 0 261
assign 1 1333 264
sizeGet 0 1333 264
assign 1 1333 265
new 0 1333 265
assign 1 1333 266
lesser 1 1333 271
assign 1 0 272
assign 1 0 275
assign 1 1334 279
new 0 1334 279
return 1 1334 280
assign 1 1336 282
new 0 1336 282
return 1 1336 283
assign 1 1340 292
def 1 1340 297
assign 1 1340 298
new 0 1340 298
assign 1 1340 299
notEquals 1 1340 299
assign 1 0 301
assign 1 0 304
assign 1 0 308
assign 1 1341 311
new 0 1341 311
return 1 1341 312
assign 1 1343 314
new 0 1343 314
return 1 1343 315
return 1 0 318
return 1 0 321
assign 1 0 324
assign 1 0 328
return 1 0 332
return 1 0 335
assign 1 0 338
assign 1 0 342
return 1 0 346
return 1 0 349
assign 1 0 352
assign 1 0 356
return 1 0 360
return 1 0 363
assign 1 0 366
assign 1 0 370
return 1 0 374
return 1 0 377
assign 1 0 380
assign 1 0 384
return 1 0 388
return 1 0 391
assign 1 0 394
assign 1 0 398
return 1 0 402
return 1 0 405
assign 1 0 408
assign 1 0 412
return 1 0 416
return 1 0 419
assign 1 0 422
assign 1 0 426
return 1 0 430
return 1 0 433
assign 1 0 436
assign 1 0 440
return 1 0 444
return 1 0 447
assign 1 0 450
assign 1 0 454
return 1 0 458
return 1 0 461
assign 1 0 464
assign 1 0 468
return 1 0 472
return 1 0 475
assign 1 0 478
assign 1 0 482
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2116503968: return bem_spaceGet_0();
case 1087832621: return bem_tagGet_0();
case -544926676: return bem_zeroGetDirect_0();
case 451204: return bem_lfGet_0();
case -18123974: return bem_new_0();
case -763928014: return bem_create_0();
case -372088004: return bem_wsGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case -1319037156: return bem_crGet_0();
case -2136286009: return bem_zeroGet_0();
case 881754957: return bem_deserializeClassNameGet_0();
case 774721401: return bem_serializeToString_0();
case 606165403: return bem_wsGetDirect_0();
case 489301767: return bem_emptyGet_0();
case 151978736: return bem_tabGetDirect_0();
case 234248288: return bem_copy_0();
case -1670540422: return bem_unixNewlineGetDirect_0();
case -568575955: return bem_hashGet_0();
case -220602072: return bem_echo_0();
case -294274039: return bem_emptyGetDirect_0();
case 1125796530: return bem_newlineGetDirect_0();
case -674491561: return bem_sourceFileNameGet_0();
case -1857961182: return bem_quoteGet_0();
case 1398523223: return bem_spaceGetDirect_0();
case -1374345213: return bem_tabGet_0();
case 1445947833: return bem_dosNewlineGet_0();
case -829315536: return bem_classNameGet_0();
case 923007296: return bem_colonGet_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -2058838609: return bem_dosNewlineGetDirect_0();
case 870688735: return bem_quoteGetDirect_0();
case -1454950260: return bem_fieldIteratorGet_0();
case -998006748: return bem_unixNewlineGet_0();
case 1126911928: return bem_serializeContents_0();
case 2087607686: return bem_iteratorGet_0();
case -1350802630: return bem_default_0();
case 976707764: return bem_colonGetDirect_0();
case -437991849: return bem_toString_0();
case -2060942095: return bem_crGetDirect_0();
case -419834598: return bem_print_0();
case -637574699: return bem_lfGetDirect_0();
case 92992373: return bem_newlineGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1164605638: return bem_colonSetDirect_1(bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case -643713889: return bem_notEquals_1(bevd_0);
case 329122719: return bem_zeroSetDirect_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case 358895437: return bem_emptySet_1(bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 754662913: return bem_emptySetDirect_1(bevd_0);
case 1809170382: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -1572969631: return bem_spaceSetDirect_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case 1413644187: return bem_crSetDirect_1(bevd_0);
case -1197224914: return bem_dosNewlineSetDirect_1(bevd_0);
case 1304354229: return bem_crSet_1(bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 190677151: return bem_lfSetDirect_1(bevd_0);
case -419122040: return bem_spaceSet_1(bevd_0);
case 1243407126: return bem_unixNewlineSetDirect_1(bevd_0);
case 673173923: return bem_quoteSet_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case 1770058350: return bem_colonSet_1(bevd_0);
case -870351389: return bem_tabSet_1(bevd_0);
case 164683990: return bem_lfSet_1(bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1063644230: return bem_zeroSet_1(bevd_0);
case -1607017727: return bem_anyEmpty_1(bevd_0);
case 412310584: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -1182025758: return bem_wsSet_1(bevd_0);
case -1037755764: return bem_tabSetDirect_1(bevd_0);
case 276280137: return bem_newlineSet_1(bevd_0);
case -1075427448: return bem_quoteSetDirect_1(bevd_0);
case 1366737308: return bem_wsSetDirect_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
case 710541582: return bem_newlineSetDirect_1(bevd_0);
case -2141447146: return bem_dosNewlineSet_1(bevd_0);
case 1229228913: return bem_unixNewlineSet_1(bevd_0);
case 1926300208: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -485147067: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 154678206: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1505468874: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
