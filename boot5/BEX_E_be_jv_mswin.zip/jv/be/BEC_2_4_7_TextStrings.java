package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_9_3_ContainerSet bevp_ws;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_ws = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(38127485);
bevt_1_ta_ph = bevl_i.bemd_0(1757263953);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(771598018);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1270*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1271*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(1982151412);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1275*/ {
bevt_4_ta_ph = bevl_i.bemd_0(1757263953);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1275*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(1982151412);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1277*/
 else /* Line: 1275*/ {
break;
} /* Line: 1275*/
} /* Line: 1275*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1287*/ {
bevt_0_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 1287*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_ta_ph = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_ta_ph.bevi_bool)/* Line: 1289*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1290*/ {
bevl_end.bevi_int++;
} /* Line: 1291*/
 else /* Line: 1292*/ {
bevl_beg.bevi_int++;
} /* Line: 1293*/
} /* Line: 1290*/
 else /* Line: 1295*/ {
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1297*/
} /* Line: 1289*/
 else /* Line: 1287*/ {
break;
} /* Line: 1287*/
} /* Line: 1287*/
if (bevl_foundChar.bevi_bool)/* Line: 1300*/ {
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_ta_ph);
} /* Line: 1301*/
 else /* Line: 1302*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1303*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1309*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1309*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1309*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1309*/ {
return null;
} /* Line: 1309*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1315*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1315*/ {
bevl_ai.bemd_1(235669122, bevl_av);
bevl_bi.bemd_1(235669122, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1318*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1319*/
bevl_i.bevi_int++;
} /* Line: 1315*/
 else /* Line: 1315*/ {
break;
} /* Line: 1315*/
} /* Line: 1315*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(38127485);
while (true)
/* Line: 1326*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(1757263953);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1326*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(1982151412);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1327*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1328*/
} /* Line: 1327*/
 else /* Line: 1326*/ {
break;
} /* Line: 1326*/
} /* Line: 1326*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1335*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1335*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1335*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1335*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1335*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1335*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1336*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1342*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1342*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1342*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1342*/
 else /* Line: 1342*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1342*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1343*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public final BEC_2_4_3_MathInt bem_zeroGetDirect_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public final BEC_2_4_6_TextString bem_spaceGetDirect_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public final BEC_2_4_6_TextString bem_emptyGetDirect_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public final BEC_2_4_6_TextString bem_quoteGetDirect_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public final BEC_2_4_6_TextString bem_tabGetDirect_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public final BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public final BEC_2_4_6_TextString bem_crGetDirect_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public final BEC_2_4_6_TextString bem_lfGetDirect_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public final BEC_2_4_6_TextString bem_colonGetDirect_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() throws Throwable {
return bevp_ws;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_wsGetDirect_0() throws Throwable {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1244, 1245, 1246, 1247, 1247, 1248, 1248, 1249, 1250, 1252, 1252, 1253, 1254, 1255, 1258, 1259, 1260, 1261, 1265, 1265, 1269, 1270, 1270, 1271, 1271, 1273, 1274, 1274, 1275, 1276, 1277, 1277, 1279, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1291, 1293, 1296, 1296, 1297, 1301, 1301, 1301, 1303, 1305, 1309, 1309, 0, 1309, 1309, 0, 0, 1309, 1310, 1310, 1310, 1310, 1311, 1312, 1313, 1314, 1315, 1315, 1315, 1316, 1317, 1318, 1319, 1319, 1319, 1315, 1322, 1322, 1322, 1326, 0, 1326, 1326, 1327, 1328, 1328, 1331, 1331, 1335, 1335, 0, 1335, 1335, 1335, 1335, 0, 0, 1336, 1336, 1338, 1338, 1342, 1342, 1342, 1342, 1342, 1342, 0, 0, 0, 1343, 1343, 1345, 1345, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 57, 58, 69, 70, 71, 73, 74, 76, 77, 78, 81, 83, 84, 85, 91, 105, 106, 107, 108, 111, 113, 114, 117, 120, 124, 125, 126, 134, 135, 136, 139, 141, 162, 167, 168, 171, 176, 177, 180, 184, 186, 187, 188, 189, 190, 191, 192, 193, 194, 197, 202, 203, 204, 205, 207, 208, 209, 211, 217, 218, 219, 228, 228, 231, 233, 234, 236, 237, 244, 245, 255, 260, 261, 264, 265, 266, 271, 272, 275, 279, 280, 282, 283, 293, 298, 299, 300, 301, 306, 307, 310, 314, 317, 318, 320, 321, 324, 327, 330, 334, 338, 341, 344, 348, 352, 355, 358, 362, 366, 369, 372, 376, 380, 383, 386, 390, 394, 397, 400, 404, 408, 411, 414, 418, 422, 425, 428, 432, 436, 439, 442, 446, 450, 453, 456, 460, 464, 467, 470, 474, 478, 481, 484, 488};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1244 35
new 0 1244 35
assign 1 1245 36
new 0 1245 36
assign 1 1246 37
new 0 1246 37
assign 1 1247 38
new 0 1247 38
assign 1 1247 39
codeNew 1 1247 39
assign 1 1248 40
new 0 1248 40
assign 1 1248 41
codeNew 1 1248 41
assign 1 1249 42
new 0 1249 42
assign 1 1250 43
new 0 1250 43
assign 1 1252 44
new 0 1252 44
assign 1 1252 45
codeNew 1 1252 45
assign 1 1253 46
new 0 1253 46
assign 1 1254 47
new 0 1254 47
assign 1 1255 48
new 0 1255 48
put 1 1258 49
put 1 1259 50
put 1 1260 51
put 1 1261 52
assign 1 1265 57
joinBuffer 2 1265 57
return 1 1265 58
assign 1 1269 69
iteratorGet 0 1269 69
assign 1 1270 70
hasNextGet 0 1270 70
assign 1 1270 71
not 0 1270 71
assign 1 1271 73
new 0 1271 73
return 1 1271 74
assign 1 1273 76
new 0 1273 76
assign 1 1274 77
nextGet 0 1274 77
addValue 1 1274 78
assign 1 1275 81
hasNextGet 0 1275 81
addValue 1 1276 83
assign 1 1277 84
nextGet 0 1277 84
addValue 1 1277 85
return 1 1279 91
assign 1 1283 105
new 0 1283 105
assign 1 1284 106
new 0 1284 106
assign 1 1285 107
new 0 1285 107
assign 1 1286 108
mbiterGet 0 1286 108
assign 1 1287 111
hasNextGet 0 1287 111
assign 1 1288 113
nextGet 0 1288 113
assign 1 1289 114
has 1 1289 114
incrementValue 0 1291 117
incrementValue 0 1293 120
assign 1 1296 124
new 0 1296 124
setValue 1 1296 125
assign 1 1297 126
new 0 1297 126
assign 1 1301 134
sizeGet 0 1301 134
assign 1 1301 135
subtract 1 1301 135
assign 1 1301 136
substring 2 1301 136
assign 1 1303 139
new 0 1303 139
return 1 1305 141
assign 1 1309 162
undef 1 1309 167
assign 1 0 168
assign 1 1309 171
undef 1 1309 176
assign 1 0 177
assign 1 0 180
return 1 1309 184
assign 1 1310 186
new 0 1310 186
assign 1 1310 187
sizeGet 0 1310 187
assign 1 1310 188
sizeGet 0 1310 188
assign 1 1310 189
min 2 1310 189
assign 1 1311 190
biterGet 0 1311 190
assign 1 1312 191
biterGet 0 1312 191
assign 1 1313 192
new 0 1313 192
assign 1 1314 193
new 0 1314 193
assign 1 1315 194
new 0 1315 194
assign 1 1315 197
lesser 1 1315 202
next 1 1316 203
next 1 1317 204
assign 1 1318 205
notEquals 1 1318 205
assign 1 1319 207
new 0 1319 207
assign 1 1319 208
substring 2 1319 208
return 1 1319 209
incrementValue 0 1315 211
assign 1 1322 217
new 0 1322 217
assign 1 1322 218
substring 2 1322 218
return 1 1322 219
assign 1 1326 228
iteratorGet 0 0 228
assign 1 1326 231
hasNextGet 0 1326 231
assign 1 1326 233
nextGet 0 1326 233
assign 1 1327 234
isEmpty 1 1327 234
assign 1 1328 236
new 0 1328 236
return 1 1328 237
assign 1 1331 244
new 0 1331 244
return 1 1331 245
assign 1 1335 255
undef 1 1335 260
assign 1 0 261
assign 1 1335 264
sizeGet 0 1335 264
assign 1 1335 265
new 0 1335 265
assign 1 1335 266
lesser 1 1335 271
assign 1 0 272
assign 1 0 275
assign 1 1336 279
new 0 1336 279
return 1 1336 280
assign 1 1338 282
new 0 1338 282
return 1 1338 283
assign 1 1342 293
def 1 1342 298
assign 1 1342 299
sizeGet 0 1342 299
assign 1 1342 300
new 0 1342 300
assign 1 1342 301
greater 1 1342 306
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 1343 317
new 0 1343 317
return 1 1343 318
assign 1 1345 320
new 0 1345 320
return 1 1345 321
return 1 0 324
return 1 0 327
assign 1 0 330
assign 1 0 334
return 1 0 338
return 1 0 341
assign 1 0 344
assign 1 0 348
return 1 0 352
return 1 0 355
assign 1 0 358
assign 1 0 362
return 1 0 366
return 1 0 369
assign 1 0 372
assign 1 0 376
return 1 0 380
return 1 0 383
assign 1 0 386
assign 1 0 390
return 1 0 394
return 1 0 397
assign 1 0 400
assign 1 0 404
return 1 0 408
return 1 0 411
assign 1 0 414
assign 1 0 418
return 1 0 422
return 1 0 425
assign 1 0 428
assign 1 0 432
return 1 0 436
return 1 0 439
assign 1 0 442
assign 1 0 446
return 1 0 450
return 1 0 453
assign 1 0 456
assign 1 0 460
return 1 0 464
return 1 0 467
assign 1 0 470
assign 1 0 474
return 1 0 478
return 1 0 481
assign 1 0 484
assign 1 0 488
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -593469656: return bem_sourceFileNameGet_0();
case -490006297: return bem_tabGetDirect_0();
case -1818293830: return bem_fieldNamesGet_0();
case 793589441: return bem_classNameGet_0();
case 508746763: return bem_newlineGetDirect_0();
case -340103430: return bem_spaceGet_0();
case 2061432375: return bem_tagGet_0();
case 860164789: return bem_quoteGet_0();
case -1863185811: return bem_crGet_0();
case 1847639727: return bem_new_0();
case 1980238543: return bem_zeroGet_0();
case -2127157564: return bem_tabGet_0();
case -1331374769: return bem_toString_0();
case 7663773: return bem_wsGetDirect_0();
case -1793645346: return bem_newlineGet_0();
case 1755324533: return bem_dosNewlineGet_0();
case 636345: return bem_print_0();
case 854710191: return bem_create_0();
case 1162475802: return bem_crGetDirect_0();
case 779255115: return bem_unixNewlineGet_0();
case 1971092152: return bem_dosNewlineGetDirect_0();
case 1691993081: return bem_colonGet_0();
case -580580010: return bem_unixNewlineGetDirect_0();
case -22788464: return bem_hashGet_0();
case -1564878824: return bem_spaceGetDirect_0();
case -455220974: return bem_emptyGetDirect_0();
case -1849826772: return bem_default_0();
case 1660417485: return bem_colonGetDirect_0();
case 437287452: return bem_emptyGet_0();
case 1123084759: return bem_lfGetDirect_0();
case -903076825: return bem_wsGet_0();
case 1001793512: return bem_quoteGetDirect_0();
case -1508036637: return bem_copy_0();
case 1931946497: return bem_lfGet_0();
case 1162937268: return bem_zeroGetDirect_0();
case 38127485: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1040197847: return bem_newlineSet_1(bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
case -1009013855: return bem_lfSet_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
case 2063198252: return bem_zeroSet_1(bevd_0);
case 2080267162: return bem_wsSetDirect_1(bevd_0);
case -1843549219: return bem_crSet_1(bevd_0);
case -502376443: return bem_equals_1(bevd_0);
case -237207519: return bem_zeroSetDirect_1(bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case -206516307: return bem_tabSet_1(bevd_0);
case -532482642: return bem_tabSetDirect_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case 1660666934: return bem_lfSetDirect_1(bevd_0);
case -1908086809: return bem_dosNewlineSetDirect_1(bevd_0);
case -2074226470: return bem_spaceSet_1(bevd_0);
case 470660383: return bem_anyEmpty_1(bevd_0);
case -195873651: return bem_emptySetDirect_1(bevd_0);
case -37586414: return bem_quoteSetDirect_1(bevd_0);
case 1420144499: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -1017189318: return bem_spaceSetDirect_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
case -2032724871: return bem_unixNewlineSetDirect_1(bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case -575823295: return bem_crSetDirect_1(bevd_0);
case -1784829422: return bem_wsSet_1(bevd_0);
case -579962844: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 468265859: return bem_quoteSet_1(bevd_0);
case -1397755521: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -879369695: return bem_emptySet_1(bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case -319551191: return bem_dosNewlineSet_1(bevd_0);
case 2012342557: return bem_colonSet_1(bevd_0);
case 1908617526: return bem_colonSetDirect_1(bevd_0);
case 1534884965: return bem_newlineSetDirect_1(bevd_0);
case 286570285: return bem_unixNewlineSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1694012075: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -459977116: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -541277383: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
