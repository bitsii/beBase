package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_7_TextStrings extends BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_7_TextStrings bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (new BEC_2_4_3_MathInt(0));
bevp_space = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(34));
bevp_quote = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(9));
bevp_tab = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(13));
bevp_cr = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(245203492);
bevt_1_ta_ph = bevl_i.bemd_0(-542409727);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(2060369684);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1286*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1287*/
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(698381837);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1291*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-542409727);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1291*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(698381837);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1293*/
 else /* Line: 1291*/ {
break;
} /* Line: 1291*/
} /* Line: 1291*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_beg = (new BEC_2_4_3_MathInt(0));
bevl_end = (new BEC_2_4_3_MathInt(0));
bevl_foundChar = be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1303*/ {
bevt_3_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 1303*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_4_ta_ph = bevl_step.bem_equals_1(bevp_space);
if (bevt_4_ta_ph.bevi_bool)/* Line: 1305*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1305*/ {
bevt_5_ta_ph = bevl_step.bem_equals_1(bevp_tab);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1305*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1305*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1305*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1305*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1305*/ {
bevt_6_ta_ph = bevl_step.bem_equals_1(bevp_cr);
if (bevt_6_ta_ph.bevi_bool)/* Line: 1305*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1305*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1305*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 1305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1305*/ {
bevt_7_ta_ph = bevl_step.bem_equals_1(bevp_unixNewline);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1305*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1305*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1305*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1306*/ {
bevl_end.bevi_int++;
} /* Line: 1307*/
 else /* Line: 1308*/ {
bevl_beg.bevi_int++;
} /* Line: 1309*/
} /* Line: 1306*/
 else /* Line: 1311*/ {
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_8_ta_ph.bevi_int;
bevl_foundChar = be.BECS_Runtime.boolTrue;
} /* Line: 1313*/
} /* Line: 1305*/
 else /* Line: 1303*/ {
break;
} /* Line: 1303*/
} /* Line: 1303*/
if (bevl_foundChar.bevi_bool)/* Line: 1316*/ {
bevt_10_ta_ph = beva_str.bem_sizeGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_9_ta_ph);
} /* Line: 1317*/
 else /* Line: 1318*/ {
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1319*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) throws Throwable {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1325*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1325*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1325*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1325*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1325*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1325*/ {
return null;
} /* Line: 1325*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1331*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1331*/ {
bevl_ai.bemd_1(-1516999654, bevl_av);
bevl_bi.bemd_1(-1516999654, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1334*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1335*/
bevl_i.bevi_int++;
} /* Line: 1331*/
 else /* Line: 1331*/ {
break;
} /* Line: 1331*/
} /* Line: 1331*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) throws Throwable {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(245203492);
while (true)
/* Line: 1342*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-542409727);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1342*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(698381837);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1343*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1344*/
} /* Line: 1343*/
 else /* Line: 1342*/ {
break;
} /* Line: 1342*/
} /* Line: 1342*/
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1351*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1351*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1351*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1351*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1351*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1351*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1352*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1358*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1358*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1358*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1358*/
 else /* Line: 1358*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1358*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1359*/
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() throws Throwable {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() throws Throwable {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() throws Throwable {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() throws Throwable {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() throws Throwable {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() throws Throwable {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() throws Throwable {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() throws Throwable {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() throws Throwable {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() throws Throwable {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1266, 1267, 1268, 1269, 1269, 1270, 1270, 1271, 1272, 1274, 1274, 1275, 1276, 1281, 1281, 1285, 1286, 1286, 1287, 1287, 1289, 1290, 1290, 1291, 1292, 1293, 1293, 1295, 1299, 1300, 1301, 1302, 1303, 1304, 1305, 0, 1305, 0, 0, 0, 1305, 0, 0, 0, 1305, 0, 0, 1307, 1309, 1312, 1312, 1313, 1317, 1317, 1317, 1319, 1321, 1325, 1325, 0, 1325, 1325, 0, 0, 1325, 1326, 1326, 1326, 1326, 1327, 1328, 1329, 1330, 1331, 1331, 1331, 1332, 1333, 1334, 1335, 1335, 1335, 1331, 1338, 1338, 1338, 1342, 0, 1342, 1342, 1343, 1344, 1344, 1347, 1347, 1351, 1351, 0, 1351, 1351, 1351, 1351, 0, 0, 1352, 1352, 1354, 1354, 1358, 1358, 1358, 1358, 1358, 1358, 0, 0, 0, 1359, 1359, 1361, 1361, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 51, 52, 63, 64, 65, 67, 68, 70, 71, 72, 75, 77, 78, 79, 85, 105, 106, 107, 108, 111, 113, 114, 116, 119, 121, 124, 128, 131, 133, 136, 140, 143, 145, 148, 153, 156, 160, 161, 162, 170, 171, 172, 175, 177, 198, 203, 204, 207, 212, 213, 216, 220, 222, 223, 224, 225, 226, 227, 228, 229, 230, 233, 238, 239, 240, 241, 243, 244, 245, 247, 253, 254, 255, 264, 264, 267, 269, 270, 272, 273, 280, 281, 291, 296, 297, 300, 301, 302, 307, 308, 311, 315, 316, 318, 319, 329, 334, 335, 336, 337, 342, 343, 346, 350, 353, 354, 356, 357, 360, 363, 367, 370, 374, 377, 381, 384, 388, 391, 395, 398, 402, 405, 409, 412, 416, 419, 423, 426, 430, 433};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1266 34
new 0 1266 34
assign 1 1267 35
new 0 1267 35
assign 1 1268 36
new 0 1268 36
assign 1 1269 37
new 0 1269 37
assign 1 1269 38
codeNew 1 1269 38
assign 1 1270 39
new 0 1270 39
assign 1 1270 40
codeNew 1 1270 40
assign 1 1271 41
new 0 1271 41
assign 1 1272 42
new 0 1272 42
assign 1 1274 43
new 0 1274 43
assign 1 1274 44
codeNew 1 1274 44
assign 1 1275 45
new 0 1275 45
assign 1 1276 46
new 0 1276 46
assign 1 1281 51
joinBuffer 2 1281 51
return 1 1281 52
assign 1 1285 63
iteratorGet 0 1285 63
assign 1 1286 64
hasNextGet 0 1286 64
assign 1 1286 65
not 0 1286 65
assign 1 1287 67
new 0 1287 67
return 1 1287 68
assign 1 1289 70
new 0 1289 70
assign 1 1290 71
nextGet 0 1290 71
addValue 1 1290 72
assign 1 1291 75
hasNextGet 0 1291 75
addValue 1 1292 77
assign 1 1293 78
nextGet 0 1293 78
addValue 1 1293 79
return 1 1295 85
assign 1 1299 105
new 0 1299 105
assign 1 1300 106
new 0 1300 106
assign 1 1301 107
new 0 1301 107
assign 1 1302 108
mbiterGet 0 1302 108
assign 1 1303 111
hasNextGet 0 1303 111
assign 1 1304 113
nextGet 0 1304 113
assign 1 1305 114
equals 1 1305 114
assign 1 0 116
assign 1 1305 119
equals 1 1305 119
assign 1 0 121
assign 1 0 124
assign 1 0 128
assign 1 1305 131
equals 1 1305 131
assign 1 0 133
assign 1 0 136
assign 1 0 140
assign 1 1305 143
equals 1 1305 143
assign 1 0 145
assign 1 0 148
incrementValue 0 1307 153
incrementValue 0 1309 156
assign 1 1312 160
new 0 1312 160
setValue 1 1312 161
assign 1 1313 162
new 0 1313 162
assign 1 1317 170
sizeGet 0 1317 170
assign 1 1317 171
subtract 1 1317 171
assign 1 1317 172
substring 2 1317 172
assign 1 1319 175
new 0 1319 175
return 1 1321 177
assign 1 1325 198
undef 1 1325 203
assign 1 0 204
assign 1 1325 207
undef 1 1325 212
assign 1 0 213
assign 1 0 216
return 1 1325 220
assign 1 1326 222
new 0 1326 222
assign 1 1326 223
sizeGet 0 1326 223
assign 1 1326 224
sizeGet 0 1326 224
assign 1 1326 225
min 2 1326 225
assign 1 1327 226
biterGet 0 1327 226
assign 1 1328 227
biterGet 0 1328 227
assign 1 1329 228
new 0 1329 228
assign 1 1330 229
new 0 1330 229
assign 1 1331 230
new 0 1331 230
assign 1 1331 233
lesser 1 1331 238
next 1 1332 239
next 1 1333 240
assign 1 1334 241
notEquals 1 1334 241
assign 1 1335 243
new 0 1335 243
assign 1 1335 244
substring 2 1335 244
return 1 1335 245
incrementValue 0 1331 247
assign 1 1338 253
new 0 1338 253
assign 1 1338 254
substring 2 1338 254
return 1 1338 255
assign 1 1342 264
iteratorGet 0 0 264
assign 1 1342 267
hasNextGet 0 1342 267
assign 1 1342 269
nextGet 0 1342 269
assign 1 1343 270
isEmpty 1 1343 270
assign 1 1344 272
new 0 1344 272
return 1 1344 273
assign 1 1347 280
new 0 1347 280
return 1 1347 281
assign 1 1351 291
undef 1 1351 296
assign 1 0 297
assign 1 1351 300
sizeGet 0 1351 300
assign 1 1351 301
new 0 1351 301
assign 1 1351 302
lesser 1 1351 307
assign 1 0 308
assign 1 0 311
assign 1 1352 315
new 0 1352 315
return 1 1352 316
assign 1 1354 318
new 0 1354 318
return 1 1354 319
assign 1 1358 329
def 1 1358 334
assign 1 1358 335
sizeGet 0 1358 335
assign 1 1358 336
new 0 1358 336
assign 1 1358 337
greater 1 1358 342
assign 1 0 343
assign 1 0 346
assign 1 0 350
assign 1 1359 353
new 0 1359 353
return 1 1359 354
assign 1 1361 356
new 0 1361 356
return 1 1361 357
return 1 0 360
assign 1 0 363
return 1 0 367
assign 1 0 370
return 1 0 374
assign 1 0 377
return 1 0 381
assign 1 0 384
return 1 0 388
assign 1 0 391
return 1 0 395
assign 1 0 398
return 1 0 402
assign 1 0 405
return 1 0 409
assign 1 0 412
return 1 0 416
assign 1 0 419
return 1 0 423
assign 1 0 426
return 1 0 430
assign 1 0 433
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1238499046: return bem_hashGet_0();
case -1574253938: return bem_zeroGet_0();
case 1481127434: return bem_unixNewlineGet_0();
case -1015862089: return bem_emptyGet_0();
case -1924693366: return bem_copy_0();
case 592950024: return bem_print_0();
case 1964453348: return bem_quoteGet_0();
case 2093609367: return bem_create_0();
case 245203492: return bem_iteratorGet_0();
case -1927181629: return bem_default_0();
case -1903326749: return bem_spaceGet_0();
case -2032570452: return bem_tabGet_0();
case -1825234285: return bem_colonGet_0();
case 1617243662: return bem_crGet_0();
case 644438727: return bem_dosNewlineGet_0();
case -1197979036: return bem_new_0();
case 1614890172: return bem_newlineGet_0();
case 1909120093: return bem_toString_0();
case 1905788253: return bem_lfGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -18723050: return bem_lfSet_1(bevd_0);
case 1979727359: return bem_newlineSet_1(bevd_0);
case 1247582250: return bem_unixNewlineSet_1(bevd_0);
case -1861550977: return bem_tabSet_1(bevd_0);
case 441346402: return bem_equals_1(bevd_0);
case -1308882044: return bem_notEquals_1(bevd_0);
case 2111055900: return bem_copyTo_1(bevd_0);
case -1801772852: return bem_crSet_1(bevd_0);
case 1330423529: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1322914868: return bem_dosNewlineSet_1(bevd_0);
case -74089210: return bem_anyEmpty_1(bevd_0);
case 1960085836: return bem_zeroSet_1(bevd_0);
case -2137764638: return bem_spaceSet_1(bevd_0);
case -704174333: return bem_quoteSet_1(bevd_0);
case 1476558396: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -2118434388: return bem_undef_1(bevd_0);
case -975062314: return bem_colonSet_1(bevd_0);
case -1510905343: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1513933004: return bem_def_1(bevd_0);
case -1705252573: return bem_emptySet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1494021191: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -974323752: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1048933061: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1921786219: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1886463238: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 166604406: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1099747159: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_7_TextStrings();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
