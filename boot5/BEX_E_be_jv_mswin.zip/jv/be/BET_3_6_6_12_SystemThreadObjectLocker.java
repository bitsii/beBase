package be;
public class BET_3_6_6_12_SystemThreadObjectLocker extends BETS_Object {
public BET_3_6_6_12_SystemThreadObjectLocker() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "oGet_0", "getAndClear_0", "setIfClear_1", "oSet_1", "objectGet_0", "objectSet_1", "lockGet_0", "lockSet_1", "objGet_0", "objSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "lock", "obj" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
}
