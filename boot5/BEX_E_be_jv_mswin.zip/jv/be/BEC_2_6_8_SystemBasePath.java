package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_ta_ph.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_8_SystemBasePath bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_7_TextStrings bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_other.bemd_0(61118389);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-420475689, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 103*/ {
bevt_4_ta_ph = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_ta_ph;
} /* Line: 104*/
bevt_5_ta_ph = beva_other.bemd_0(1218403304);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 106*/ {
bevt_6_ta_ph = beva_other.bemd_0(1333189262);
return (BEC_2_6_8_SystemBasePath) bevt_6_ta_ph;
} /* Line: 107*/
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_ta_ph = beva_other.bemd_0(61118389);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_ta_ph.bemd_1(-1141950399, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 111*/ {
bevt_8_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 111*/ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 113*/
 else /* Line: 111*/ {
break;
} /* Line: 111*/
} /* Line: 111*/
bevt_9_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_ta_ph.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = bem_copy_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_ta_ph);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 129*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 129*/ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_3_ta_ph = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_ta_ph);
} /* Line: 131*/
 else /* Line: 132*/ {
bevl_i.bem_nextGet_0();
} /* Line: 133*/
bevl_c = bevl_c.bem_increment_0();
} /* Line: 135*/
 else /* Line: 129*/ {
break;
} /* Line: 129*/
} /* Line: 129*/
bevt_4_ta_ph = bem_isAbsoluteGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 137*/ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 138*/
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (bevp_path == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_4_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_sizeGet_0();
bevt_5_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_ta_ph.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 144*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 144*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 144*/
bevt_9_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_ta_ph = bevp_path.bem_getPoint_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_equals_1(bevp_separator);
if (bevt_7_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 146*/
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_1_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 153*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_isAbsoluteGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 158*/ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 159*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 164*/ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 169*/ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 169*/ {
if (bevl_next == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 170*/ {
break;
} /* Line: 170*/
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 169*/
 else /* Line: 169*/ {
break;
} /* Line: 169*/
} /* Line: 169*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 175*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 187*/ {
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_ta_ph.bem_emptyGet_0();
} /* Line: 188*/
 else /* Line: 189*/ {
bevt_3_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_ta_ph = bevl_fp.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_ta_ph, bevt_4_ta_ph);
} /* Line: 190*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
/* Line: 196*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 196*/ {
bevt_1_ta_ph = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_ta_ph);
} /* Line: 197*/
 else /* Line: 196*/ {
break;
} /* Line: 196*/
} /* Line: 196*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_addStep_1(beva_step);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_3_ta_ph = beva_x.bemd_1(-1041366691, this);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_5_ta_ph = beva_x.bemd_0(61118389);
bevt_4_ta_ph = bevp_path.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 237*/
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_subPath_2(beva_start, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 248*/ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 249*/
 else /* Line: 250*/ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 251*/
bevl_res = bem_create_0();
bevl_res.bemd_1(-1094638411, bevp_separator);
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-1960774772, bevt_1_ta_ph);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_2_4_6_TextString bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {64, 64, 68, 69, 73, 77, 81, 81, 85, 86, 86, 87, 91, 91, 95, 95, 95, 99, 99, 99, 103, 103, 103, 103, 104, 104, 106, 107, 107, 109, 110, 110, 111, 111, 112, 113, 115, 115, 116, 117, 119, 123, 124, 125, 125, 126, 127, 128, 129, 129, 130, 130, 131, 131, 133, 135, 137, 138, 140, 144, 144, 0, 144, 144, 144, 144, 144, 0, 0, 144, 144, 145, 145, 145, 146, 146, 148, 148, 152, 153, 153, 153, 158, 158, 158, 159, 164, 164, 164, 165, 166, 168, 169, 169, 169, 170, 170, 171, 172, 173, 169, 175, 180, 181, 182, 186, 187, 187, 188, 188, 190, 190, 190, 190, 195, 196, 196, 197, 197, 199, 203, 203, 207, 208, 209, 210, 214, 215, 216, 216, 217, 221, 221, 225, 225, 229, 229, 229, 236, 236, 0, 236, 0, 0, 0, 236, 236, 0, 0, 237, 237, 239, 239, 243, 243, 247, 248, 248, 249, 251, 253, 254, 255, 255, 255, 256, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 28, 29, 33, 37, 41, 42, 48, 49, 50, 51, 55, 56, 61, 62, 63, 68, 69, 70, 89, 90, 91, 92, 94, 95, 97, 99, 100, 102, 103, 104, 105, 108, 110, 111, 117, 118, 119, 120, 121, 134, 135, 136, 137, 138, 139, 140, 141, 144, 146, 151, 152, 153, 156, 158, 164, 166, 168, 183, 188, 189, 192, 193, 194, 195, 200, 201, 204, 208, 209, 211, 212, 213, 215, 216, 218, 219, 225, 227, 228, 229, 236, 237, 242, 243, 256, 257, 262, 263, 264, 265, 266, 269, 274, 275, 280, 283, 284, 285, 286, 292, 298, 299, 300, 310, 311, 316, 317, 318, 321, 322, 323, 324, 333, 334, 337, 339, 340, 346, 351, 352, 356, 357, 358, 359, 365, 366, 367, 368, 369, 373, 374, 378, 379, 384, 385, 390, 401, 406, 407, 410, 412, 415, 419, 422, 423, 425, 428, 432, 433, 435, 436, 440, 441, 450, 451, 456, 457, 460, 462, 463, 464, 465, 466, 467, 470, 473, 476, 480, 484, 487, 490, 494};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 64 23
new 0 64 23
new 1 64 24
assign 1 68 28
new 0 68 28
fromString 1 69 29
assign 1 73 33
return 1 77 37
assign 1 81 41
toStringWithSeparator 1 81 41
return 1 81 42
assign 1 85 48
split 1 85 48
assign 1 86 49
new 0 86 49
assign 1 86 50
join 2 86 50
return 1 87 51
assign 1 91 55
split 1 91 55
return 1 91 56
assign 1 95 61
split 1 95 61
assign 1 95 62
firstGet 0 95 62
return 1 95 63
assign 1 99 68
split 1 99 68
assign 1 99 69
lastGet 0 99 69
return 1 99 70
assign 1 103 89
pathGet 0 103 89
assign 1 103 90
new 0 103 90
assign 1 103 91
emptyGet 0 103 91
assign 1 103 92
equals 1 103 92
assign 1 104 94
copy 0 104 94
return 1 104 95
assign 1 106 97
isAbsoluteGet 0 106 97
assign 1 107 99
copy 0 107 99
return 1 107 100
assign 1 109 102
split 1 109 102
assign 1 110 103
pathGet 0 110 103
assign 1 110 104
split 1 110 104
assign 1 111 105
linkedListIteratorGet 0 111 105
assign 1 111 108
hasNextGet 0 111 108
assign 1 112 110
nextGet 0 112 110
addValue 1 113 111
assign 1 115 117
new 0 115 117
assign 1 115 118
join 2 115 118
assign 1 116 119
copy 0 116 119
assign 1 117 120
fromString 1 117 120
return 1 119 121
assign 1 123 134
split 1 123 134
assign 1 124 135
copy 0 124 135
assign 1 125 136
new 0 125 136
pathSet 1 125 137
assign 1 126 138
lengthGet 0 126 138
assign 1 127 139
decrement 0 127 139
assign 1 128 140
new 0 128 140
assign 1 129 141
linkedListIteratorGet 0 129 141
assign 1 129 144
hasNextGet 0 129 144
assign 1 130 146
lesser 1 130 151
assign 1 131 152
nextGet 0 131 152
addStep 1 131 153
nextGet 0 133 156
assign 1 135 158
increment 0 135 158
assign 1 137 164
isAbsoluteGet 0 137 164
makeAbsolute 0 138 166
return 1 140 168
assign 1 144 183
undef 1 144 188
assign 1 0 189
assign 1 144 192
toString 0 144 192
assign 1 144 193
sizeGet 0 144 193
assign 1 144 194
new 0 144 194
assign 1 144 195
lesser 1 144 200
assign 1 0 201
assign 1 0 204
assign 1 144 208
new 0 144 208
return 1 144 209
assign 1 145 211
new 0 145 211
assign 1 145 212
getPoint 1 145 212
assign 1 145 213
equals 1 145 213
assign 1 146 215
new 0 146 215
return 1 146 216
assign 1 148 218
new 0 148 218
return 1 148 219
assign 1 152 225
isAbsoluteGet 0 152 225
assign 1 153 227
new 0 153 227
assign 1 153 228
sizeGet 0 153 228
assign 1 153 229
substring 2 153 229
assign 1 158 236
isAbsoluteGet 0 158 236
assign 1 158 237
not 0 158 242
assign 1 159 243
add 1 159 243
assign 1 164 256
new 0 164 256
assign 1 164 257
greater 1 164 262
makeNonAbsolute 0 165 263
assign 1 166 264
split 1 166 264
assign 1 168 265
firstNodeGet 0 168 265
assign 1 169 266
new 0 169 266
assign 1 169 269
lesser 1 169 274
assign 1 170 275
undef 1 170 280
assign 1 171 283
assign 1 172 284
nextGet 0 172 284
delete 0 173 285
assign 1 169 286
increment 0 169 286
assign 1 175 292
join 2 175 292
assign 1 180 298
split 1 180 298
addValue 1 181 299
assign 1 182 300
join 2 182 300
assign 1 186 310
find 1 186 310
assign 1 187 311
undef 1 187 316
assign 1 188 317
new 0 188 317
assign 1 188 318
emptyGet 0 188 318
assign 1 190 321
new 0 190 321
assign 1 190 322
add 1 190 322
assign 1 190 323
sizeGet 0 190 323
assign 1 190 324
substring 2 190 324
assign 1 195 333
split 1 195 333
assign 1 196 334
linkedListIteratorGet 0 196 334
assign 1 196 337
hasNextGet 0 196 337
assign 1 197 339
nextGet 0 197 339
addValue 1 197 340
assign 1 199 346
join 2 199 346
assign 1 203 351
addStep 1 203 351
return 1 203 352
assign 1 207 356
split 1 207 356
addValue 1 208 357
addValue 1 209 358
assign 1 210 359
join 2 210 359
assign 1 214 365
create 0 214 365
copyTo 1 215 366
assign 1 216 367
copy 0 216 367
pathSet 1 216 368
return 1 217 369
assign 1 221 373
split 1 221 373
return 1 221 374
assign 1 225 378
hashGet 0 225 378
return 1 225 379
assign 1 229 384
equals 1 229 384
assign 1 229 385
not 0 229 390
return 1 229 390
assign 1 236 401
undef 1 236 406
assign 1 0 407
assign 1 236 410
otherType 1 236 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 236 422
pathGet 0 236 422
assign 1 236 423
notEquals 1 236 423
assign 1 0 425
assign 1 0 428
assign 1 237 432
new 0 237 432
return 1 237 433
assign 1 239 435
new 0 239 435
return 1 239 436
assign 1 243 440
subPath 2 243 440
return 1 243 441
assign 1 247 450
stepsGet 0 247 450
assign 1 248 451
undef 1 248 456
assign 1 249 457
subList 1 249 457
assign 1 251 460
subList 2 251 460
assign 1 253 462
create 0 253 462
separatorSet 1 254 463
assign 1 255 464
new 0 255 464
assign 1 255 465
join 2 255 465
pathSet 1 255 466
return 1 256 467
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 470335985: return bem_fieldNamesGet_0();
case -434766936: return bem_many_0();
case 32986096: return bem_tagGet_0();
case 70657623: return bem_parentGet_0();
case -684520083: return bem_separatorGetDirect_0();
case -1051030088: return bem_makeNonAbsolute_0();
case -1193538733: return bem_echo_0();
case -1400762554: return bem_stepListGet_0();
case 2098539146: return bem_separatorGet_0();
case 656174411: return bem_iteratorGet_0();
case -2068645774: return bem_toString_0();
case 614110581: return bem_firstStepGet_0();
case 1104438617: return bem_serializationIteratorGet_0();
case 254283761: return bem_classNameGet_0();
case 1337499076: return bem_fieldIteratorGet_0();
case 238716313: return bem_once_0();
case -712823221: return bem_deleteFirstStep_0();
case 1887791078: return bem_toAny_0();
case -810892117: return bem_sourceFileNameGet_0();
case -1667230363: return bem_new_0();
case -1134589630: return bem_serializeToString_0();
case 181316061: return bem_serializeContents_0();
case 1258540231: return bem_print_0();
case 591945900: return bem_stepsGet_0();
case 1218403304: return bem_isAbsoluteGet_0();
case 1433312714: return bem_deserializeClassNameGet_0();
case -1916545082: return bem_hashGet_0();
case 1333189262: return bem_copy_0();
case 1652989577: return bem_makeAbsolute_0();
case 61118389: return bem_pathGet_0();
case -195342417: return bem_lastStepGet_0();
case 1422294520: return bem_create_0();
case 1027290019: return bem_pathGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1290216463: return bem_def_1(bevd_0);
case -1580110729: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -1094638411: return bem_separatorSet_1(bevd_0);
case -1424160786: return bem_pathSetDirect_1(bevd_0);
case 661204989: return bem_separatorSetDirect_1(bevd_0);
case 1717526290: return bem_addStep_1(bevd_0);
case -403900682: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 418775426: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1649428537: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1960774772: return bem_pathSet_1(bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case -1271610697: return bem_addSteps_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case 1948301764: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 440608122: return bem_add_1(bevd_0);
case 1760817887: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1575740613: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1591100764: return bem_addSteps_2(bevd_0, bevd_1);
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2110717065: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
