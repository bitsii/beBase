package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(-1141120157);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1328502463, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 370 */ {
bevt_4_tmpany_phold = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 371 */
bevt_5_tmpany_phold = beva_other.bemd_0(1532552764);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 373 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(66023749);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 374 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(-1141120157);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(1108184101, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 378 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 378 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 380 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = bem_copy_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 396 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 396 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 398 */
 else  /* Line: 399 */ {
bevl_i.bem_nextGet_0();
} /* Line: 400 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 402 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
bevt_4_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 405 */
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 411 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 411 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 411 */
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 413 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 420 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 425 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 426 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 431 */ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 436 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 436 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 437 */ {
break;
} /* Line: 437 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 436 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 442 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 454 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 455 */
 else  /* Line: 456 */ {
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 457 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 463 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 463 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 464 */
 else  /* Line: 463 */ {
break;
} /* Line: 463 */
} /* Line: 463 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(1751676394, this);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 503 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 503 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 503 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(-1141120157);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 503 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 503 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 503 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 504 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 515 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 516 */
 else  /* Line: 517 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 518 */
bevl_res = bem_create_0();
bevl_res.bemd_1(1809764085, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(1189457440, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_2_4_6_TextString bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {331, 331, 335, 336, 340, 344, 348, 348, 352, 353, 353, 354, 358, 358, 362, 362, 362, 366, 366, 366, 370, 370, 370, 370, 371, 371, 373, 374, 374, 376, 377, 377, 378, 378, 379, 380, 382, 382, 383, 384, 386, 390, 391, 392, 392, 393, 394, 395, 396, 396, 397, 397, 398, 398, 400, 402, 404, 405, 407, 411, 411, 0, 411, 411, 411, 411, 411, 0, 0, 411, 411, 412, 412, 412, 413, 413, 415, 415, 419, 420, 420, 420, 425, 425, 425, 426, 431, 431, 431, 432, 433, 435, 436, 436, 436, 437, 437, 438, 439, 440, 436, 442, 447, 448, 449, 453, 454, 454, 455, 455, 457, 457, 457, 457, 462, 463, 463, 464, 464, 466, 470, 470, 474, 475, 476, 477, 481, 482, 483, 483, 484, 488, 488, 492, 492, 496, 496, 496, 503, 503, 0, 503, 0, 0, 0, 503, 503, 0, 0, 504, 504, 506, 506, 510, 510, 514, 515, 515, 516, 518, 520, 521, 522, 522, 522, 523, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 28, 29, 33, 37, 41, 42, 48, 49, 50, 51, 55, 56, 61, 62, 63, 68, 69, 70, 89, 90, 91, 92, 94, 95, 97, 99, 100, 102, 103, 104, 105, 108, 110, 111, 117, 118, 119, 120, 121, 134, 135, 136, 137, 138, 139, 140, 141, 144, 146, 151, 152, 153, 156, 158, 164, 166, 168, 183, 188, 189, 192, 193, 194, 195, 200, 201, 204, 208, 209, 211, 212, 213, 215, 216, 218, 219, 225, 227, 228, 229, 236, 237, 242, 243, 256, 257, 262, 263, 264, 265, 266, 269, 274, 275, 280, 283, 284, 285, 286, 292, 298, 299, 300, 310, 311, 316, 317, 318, 321, 322, 323, 324, 333, 334, 337, 339, 340, 346, 351, 352, 356, 357, 358, 359, 365, 366, 367, 368, 369, 373, 374, 378, 379, 384, 385, 390, 401, 406, 407, 410, 412, 415, 419, 422, 423, 425, 428, 432, 433, 435, 436, 440, 441, 450, 451, 456, 457, 460, 462, 463, 464, 465, 466, 467, 470, 473, 476, 480, 484, 487, 490, 494};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 331 23
new 0 331 23
new 1 331 24
assign 1 335 28
new 0 335 28
fromString 1 336 29
assign 1 340 33
return 1 344 37
assign 1 348 41
toStringWithSeparator 1 348 41
return 1 348 42
assign 1 352 48
split 1 352 48
assign 1 353 49
new 0 353 49
assign 1 353 50
join 2 353 50
return 1 354 51
assign 1 358 55
split 1 358 55
return 1 358 56
assign 1 362 61
split 1 362 61
assign 1 362 62
firstGet 0 362 62
return 1 362 63
assign 1 366 68
split 1 366 68
assign 1 366 69
lastGet 0 366 69
return 1 366 70
assign 1 370 89
pathGet 0 370 89
assign 1 370 90
new 0 370 90
assign 1 370 91
emptyGet 0 370 91
assign 1 370 92
equals 1 370 92
assign 1 371 94
copy 0 371 94
return 1 371 95
assign 1 373 97
isAbsoluteGet 0 373 97
assign 1 374 99
copy 0 374 99
return 1 374 100
assign 1 376 102
split 1 376 102
assign 1 377 103
pathGet 0 377 103
assign 1 377 104
split 1 377 104
assign 1 378 105
linkedListIteratorGet 0 378 105
assign 1 378 108
hasNextGet 0 378 108
assign 1 379 110
nextGet 0 379 110
addValue 1 380 111
assign 1 382 117
new 0 382 117
assign 1 382 118
join 2 382 118
assign 1 383 119
copy 0 383 119
assign 1 384 120
fromString 1 384 120
return 1 386 121
assign 1 390 134
split 1 390 134
assign 1 391 135
copy 0 391 135
assign 1 392 136
new 0 392 136
pathSet 1 392 137
assign 1 393 138
lengthGet 0 393 138
assign 1 394 139
decrement 0 394 139
assign 1 395 140
new 0 395 140
assign 1 396 141
linkedListIteratorGet 0 396 141
assign 1 396 144
hasNextGet 0 396 144
assign 1 397 146
lesser 1 397 151
assign 1 398 152
nextGet 0 398 152
addStep 1 398 153
nextGet 0 400 156
assign 1 402 158
increment 0 402 158
assign 1 404 164
isAbsoluteGet 0 404 164
makeAbsolute 0 405 166
return 1 407 168
assign 1 411 183
undef 1 411 188
assign 1 0 189
assign 1 411 192
toString 0 411 192
assign 1 411 193
sizeGet 0 411 193
assign 1 411 194
new 0 411 194
assign 1 411 195
lesser 1 411 200
assign 1 0 201
assign 1 0 204
assign 1 411 208
new 0 411 208
return 1 411 209
assign 1 412 211
new 0 412 211
assign 1 412 212
getPoint 1 412 212
assign 1 412 213
equals 1 412 213
assign 1 413 215
new 0 413 215
return 1 413 216
assign 1 415 218
new 0 415 218
return 1 415 219
assign 1 419 225
isAbsoluteGet 0 419 225
assign 1 420 227
new 0 420 227
assign 1 420 228
sizeGet 0 420 228
assign 1 420 229
substring 2 420 229
assign 1 425 236
isAbsoluteGet 0 425 236
assign 1 425 237
not 0 425 242
assign 1 426 243
add 1 426 243
assign 1 431 256
new 0 431 256
assign 1 431 257
greater 1 431 262
makeNonAbsolute 0 432 263
assign 1 433 264
split 1 433 264
assign 1 435 265
firstNodeGet 0 435 265
assign 1 436 266
new 0 436 266
assign 1 436 269
lesser 1 436 274
assign 1 437 275
undef 1 437 280
assign 1 438 283
assign 1 439 284
nextGet 0 439 284
delete 0 440 285
assign 1 436 286
increment 0 436 286
assign 1 442 292
join 2 442 292
assign 1 447 298
split 1 447 298
addValue 1 448 299
assign 1 449 300
join 2 449 300
assign 1 453 310
find 1 453 310
assign 1 454 311
undef 1 454 316
assign 1 455 317
new 0 455 317
assign 1 455 318
emptyGet 0 455 318
assign 1 457 321
new 0 457 321
assign 1 457 322
add 1 457 322
assign 1 457 323
sizeGet 0 457 323
assign 1 457 324
substring 2 457 324
assign 1 462 333
split 1 462 333
assign 1 463 334
linkedListIteratorGet 0 463 334
assign 1 463 337
hasNextGet 0 463 337
assign 1 464 339
nextGet 0 464 339
addValue 1 464 340
assign 1 466 346
join 2 466 346
assign 1 470 351
addStep 1 470 351
return 1 470 352
assign 1 474 356
split 1 474 356
addValue 1 475 357
addValue 1 476 358
assign 1 477 359
join 2 477 359
assign 1 481 365
create 0 481 365
copyTo 1 482 366
assign 1 483 367
copy 0 483 367
pathSet 1 483 368
return 1 484 369
assign 1 488 373
split 1 488 373
return 1 488 374
assign 1 492 378
hashGet 0 492 378
return 1 492 379
assign 1 496 384
equals 1 496 384
assign 1 496 385
not 0 496 390
return 1 496 390
assign 1 503 401
undef 1 503 406
assign 1 0 407
assign 1 503 410
otherType 1 503 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 503 422
pathGet 0 503 422
assign 1 503 423
notEquals 1 503 423
assign 1 0 425
assign 1 0 428
assign 1 504 432
new 0 504 432
return 1 504 433
assign 1 506 435
new 0 506 435
return 1 506 436
assign 1 510 440
subPath 2 510 440
return 1 510 441
assign 1 514 450
stepsGet 0 514 450
assign 1 515 451
undef 1 515 456
assign 1 516 457
subList 1 516 457
assign 1 518 460
subList 2 518 460
assign 1 520 462
create 0 520 462
separatorSet 1 521 463
assign 1 522 464
new 0 522 464
assign 1 522 465
join 2 522 465
pathSet 1 522 466
return 1 523 467
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -201292676: return bem_create_0();
case -156109891: return bem_parentGet_0();
case -2065475128: return bem_tagGet_0();
case -507248646: return bem_toString_0();
case -479220991: return bem_echo_0();
case 319478737: return bem_deleteFirstStep_0();
case 67894489: return bem_sourceFileNameGet_0();
case 1509454415: return bem_fieldNamesGet_0();
case -755857848: return bem_serializeToString_0();
case 1532552764: return bem_isAbsoluteGet_0();
case -1745405359: return bem_stepListGet_0();
case -1618628693: return bem_stepsGet_0();
case 1358579678: return bem_makeNonAbsolute_0();
case -842698583: return bem_print_0();
case -920142015: return bem_firstStepGet_0();
case -1011972693: return bem_classNameGet_0();
case 836704992: return bem_lastStepGet_0();
case -1312089850: return bem_serializationIteratorGet_0();
case 116405623: return bem_once_0();
case 838598675: return bem_deserializeClassNameGet_0();
case 2027881489: return bem_new_0();
case -1817966493: return bem_iteratorGet_0();
case 66023749: return bem_copy_0();
case 1767145499: return bem_toAny_0();
case 1880418594: return bem_many_0();
case 2081238553: return bem_separatorGet_0();
case -1641731884: return bem_pathGetDirect_0();
case 1334238154: return bem_hashGet_0();
case 437785032: return bem_makeAbsolute_0();
case -1141120157: return bem_pathGet_0();
case 1292255745: return bem_fieldIteratorGet_0();
case 970354456: return bem_separatorGetDirect_0();
case 1319463124: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1902941795: return bem_defined_1(bevd_0);
case 1201016043: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2009694921: return bem_pathSetDirect_1(bevd_0);
case 1422786748: return bem_add_1(bevd_0);
case 358154948: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 931801515: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1888223055: return bem_separatorSetDirect_1(bevd_0);
case -1968558358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1317453949: return bem_sameClass_1(bevd_0);
case 236521366: return bem_def_1(bevd_0);
case 244256421: return bem_addStep_1(bevd_0);
case -1697072029: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1673202568: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 2036500364: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -890367556: return bem_undefined_1(bevd_0);
case 1791518724: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1328502463: return bem_equals_1(bevd_0);
case -2095135331: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 440989655: return bem_copyTo_1(bevd_0);
case 1751676394: return bem_otherType_1(bevd_0);
case -1890627721: return bem_notEquals_1(bevd_0);
case -1483817890: return bem_undef_1(bevd_0);
case 824292706: return bem_sameType_1(bevd_0);
case 1265388615: return bem_addSteps_1(bevd_0);
case -737237761: return bem_sameObject_1(bevd_0);
case 1189457440: return bem_pathSet_1(bevd_0);
case -697364376: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1508117625: return bem_otherClass_1(bevd_0);
case 1809764085: return bem_separatorSet_1(bevd_0);
case -1683368194: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 77948450: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1008558996: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 139476281: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1704645214: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1221915514: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1204528413: return bem_addSteps_2(bevd_0, bevd_1);
case -1905592610: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -778494517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1737168375: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
