package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevl_fpath = bem_stepListGet_0();
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_ta_ph.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_9_TextTokenizer bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_tokenize_1(bevp_path);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_stepListGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_stepListGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_8_SystemBasePath bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_7_TextStrings bevt_8_ta_ph = null;
bevt_1_ta_ph = beva_other.bemd_0(166840448);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1684495724, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 89*/ {
bevt_4_ta_ph = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_ta_ph;
} /* Line: 90*/
bevt_5_ta_ph = beva_other.bemd_0(-1285100593);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 92*/ {
bevt_6_ta_ph = beva_other.bemd_0(1907231669);
return (BEC_2_6_8_SystemBasePath) bevt_6_ta_ph;
} /* Line: 93*/
bevl_fpath = bem_stepListGet_0();
bevl_spath = (BEC_2_9_10_ContainerLinkedList) beva_other.bemd_0(-943840063);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 97*/ {
bevt_7_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 97*/ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 99*/
 else /* Line: 97*/ {
break;
} /* Line: 97*/
} /* Line: 97*/
bevt_8_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_8_ta_ph.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_fpath = bem_stepListGet_0();
bevl_rpath = bem_copy_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_ta_ph);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_rpl = bevl_rpl.bem_subtract_1(bevt_1_ta_ph);
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 115*/ {
bevt_2_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 115*/ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 116*/ {
bevt_4_ta_ph = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_4_ta_ph);
} /* Line: 117*/
 else /* Line: 118*/ {
bevl_i.bem_nextGet_0();
} /* Line: 119*/
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_c = bevl_c.bem_add_1(bevt_5_ta_ph);
} /* Line: 121*/
 else /* Line: 115*/ {
break;
} /* Line: 115*/
} /* Line: 115*/
bevt_6_ta_ph = bem_isAbsoluteGet_0();
if (bevt_6_ta_ph.bevi_bool)/* Line: 123*/ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 124*/
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (bevp_path == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 130*/ {
bevt_4_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_lengthGet_0();
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 130*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 130*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 130*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 130*/
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bevp_path.bem_getPoint_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_equals_1(bevp_separator);
if (bevt_7_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 132*/
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 138*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevp_path.bem_lengthGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 139*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_isAbsoluteGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 144*/ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 145*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_howMany.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 150*/ {
bem_makeNonAbsolute_0();
bevl_fpath = bem_stepListGet_0();
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 155*/ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 155*/ {
if (bevl_next == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 156*/ {
break;
} /* Line: 156*/
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_remove_0();
bevl_i.bevi_int++;
} /* Line: 155*/
 else /* Line: 155*/ {
break;
} /* Line: 155*/
} /* Line: 155*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 161*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bem_stepListGet_0();
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_ta_ph.bem_emptyGet_0();
} /* Line: 174*/
 else /* Line: 175*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevl_fp.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_path.bem_lengthGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_ta_ph, bevt_4_ta_ph);
} /* Line: 176*/
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_fpath = bem_stepListGet_0();
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
/* Line: 182*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 182*/ {
bevt_1_ta_ph = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_ta_ph);
} /* Line: 183*/
 else /* Line: 182*/ {
break;
} /* Line: 182*/
} /* Line: 182*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_addStep_1(beva_step);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bem_stepListGet_0();
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_stepListGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_4_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_3_ta_ph = bevt_4_ta_ph.bem_otherType_2(beva_x, this);
if (bevt_3_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_6_ta_ph = beva_x.bemd_0(166840448);
bevt_5_ta_ph = bevp_path.bem_notEquals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 220*/
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_subPath_2(beva_start, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 231*/ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 232*/
 else /* Line: 233*/ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 234*/
bevl_res = bem_create_0();
bevl_res.bemd_1(-699178641, bevp_separator);
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(90082456, bevt_1_ta_ph);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 50, 54, 55, 59, 63, 67, 67, 71, 72, 72, 73, 77, 77, 77, 81, 81, 81, 85, 85, 85, 89, 89, 89, 89, 90, 90, 92, 93, 93, 95, 96, 97, 97, 98, 99, 101, 101, 102, 103, 105, 109, 110, 111, 111, 112, 113, 113, 114, 115, 115, 116, 116, 117, 117, 119, 121, 121, 123, 124, 126, 130, 130, 0, 130, 130, 130, 130, 130, 0, 0, 130, 130, 131, 131, 131, 132, 132, 134, 134, 138, 139, 139, 139, 144, 144, 144, 145, 150, 150, 150, 151, 152, 154, 155, 155, 155, 156, 156, 157, 158, 159, 155, 161, 166, 167, 168, 172, 173, 173, 174, 174, 176, 176, 176, 176, 181, 182, 182, 183, 183, 185, 189, 189, 193, 194, 195, 196, 200, 201, 202, 202, 203, 207, 207, 211, 211, 215, 215, 215, 219, 219, 0, 219, 219, 0, 0, 0, 219, 219, 0, 0, 220, 220, 222, 222, 226, 226, 230, 231, 231, 232, 234, 236, 237, 238, 238, 238, 239, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {18, 19, 23, 24, 28, 32, 36, 37, 43, 44, 45, 46, 51, 52, 53, 58, 59, 60, 65, 66, 67, 85, 86, 87, 88, 90, 91, 93, 95, 96, 98, 99, 100, 103, 105, 106, 112, 113, 114, 115, 116, 131, 132, 133, 134, 135, 136, 137, 138, 139, 142, 144, 149, 150, 151, 154, 156, 157, 163, 165, 167, 182, 187, 188, 191, 192, 193, 194, 199, 200, 203, 207, 208, 210, 211, 212, 214, 215, 217, 218, 224, 226, 227, 228, 235, 236, 241, 242, 255, 256, 261, 262, 263, 264, 265, 268, 273, 274, 279, 282, 283, 284, 285, 291, 297, 298, 299, 309, 310, 315, 316, 317, 320, 321, 322, 323, 332, 333, 336, 338, 339, 345, 350, 351, 355, 356, 357, 358, 364, 365, 366, 367, 368, 372, 373, 377, 378, 383, 384, 389, 401, 406, 407, 410, 411, 413, 416, 420, 423, 424, 426, 429, 433, 434, 436, 437, 441, 442, 451, 452, 457, 458, 461, 463, 464, 465, 466, 467, 468, 471, 474, 478, 481};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 18
new 0 50 18
new 1 50 19
assign 1 54 23
new 0 54 23
fromString 1 55 24
assign 1 59 28
return 1 63 32
assign 1 67 36
toStringWithSeparator 1 67 36
return 1 67 37
assign 1 71 43
stepListGet 0 71 43
assign 1 72 44
new 0 72 44
assign 1 72 45
join 2 72 45
return 1 73 46
assign 1 77 51
new 1 77 51
assign 1 77 52
tokenize 1 77 52
return 1 77 53
assign 1 81 58
stepListGet 0 81 58
assign 1 81 59
firstGet 0 81 59
return 1 81 60
assign 1 85 65
stepListGet 0 85 65
assign 1 85 66
lastGet 0 85 66
return 1 85 67
assign 1 89 85
pathGet 0 89 85
assign 1 89 86
new 0 89 86
assign 1 89 87
emptyGet 0 89 87
assign 1 89 88
equals 1 89 88
assign 1 90 90
copy 0 90 90
return 1 90 91
assign 1 92 93
isAbsoluteGet 0 92 93
assign 1 93 95
copy 0 93 95
return 1 93 96
assign 1 95 98
stepListGet 0 95 98
assign 1 96 99
stepListGet 0 96 99
assign 1 97 100
linkedListIteratorGet 0 97 100
assign 1 97 103
hasNextGet 0 97 103
assign 1 98 105
nextGet 0 98 105
addValue 1 99 106
assign 1 101 112
new 0 101 112
assign 1 101 113
join 2 101 113
assign 1 102 114
copy 0 102 114
assign 1 103 115
fromString 1 103 115
return 1 105 116
assign 1 109 131
stepListGet 0 109 131
assign 1 110 132
copy 0 110 132
assign 1 111 133
new 0 111 133
pathSet 1 111 134
assign 1 112 135
lengthGet 0 112 135
assign 1 113 136
new 0 113 136
assign 1 113 137
subtract 1 113 137
assign 1 114 138
new 0 114 138
assign 1 115 139
linkedListIteratorGet 0 115 139
assign 1 115 142
hasNextGet 0 115 142
assign 1 116 144
lesser 1 116 149
assign 1 117 150
nextGet 0 117 150
addStep 1 117 151
nextGet 0 119 154
assign 1 121 156
new 0 121 156
assign 1 121 157
add 1 121 157
assign 1 123 163
isAbsoluteGet 0 123 163
makeAbsolute 0 124 165
return 1 126 167
assign 1 130 182
undef 1 130 187
assign 1 0 188
assign 1 130 191
toString 0 130 191
assign 1 130 192
lengthGet 0 130 192
assign 1 130 193
new 0 130 193
assign 1 130 194
lesser 1 130 199
assign 1 0 200
assign 1 0 203
assign 1 130 207
new 0 130 207
return 1 130 208
assign 1 131 210
new 0 131 210
assign 1 131 211
getPoint 1 131 211
assign 1 131 212
equals 1 131 212
assign 1 132 214
new 0 132 214
return 1 132 215
assign 1 134 217
new 0 134 217
return 1 134 218
assign 1 138 224
isAbsoluteGet 0 138 224
assign 1 139 226
new 0 139 226
assign 1 139 227
lengthGet 0 139 227
assign 1 139 228
substring 2 139 228
assign 1 144 235
isAbsoluteGet 0 144 235
assign 1 144 236
not 0 144 241
assign 1 145 242
add 1 145 242
assign 1 150 255
new 0 150 255
assign 1 150 256
greater 1 150 261
makeNonAbsolute 0 151 262
assign 1 152 263
stepListGet 0 152 263
assign 1 154 264
firstNodeGet 0 154 264
assign 1 155 265
new 0 155 265
assign 1 155 268
lesser 1 155 273
assign 1 156 274
undef 1 156 279
assign 1 157 282
assign 1 158 283
nextGet 0 158 283
remove 0 159 284
incrementValue 0 155 285
assign 1 161 291
join 2 161 291
assign 1 166 297
stepListGet 0 166 297
addValue 1 167 298
assign 1 168 299
join 2 168 299
assign 1 172 309
find 1 172 309
assign 1 173 310
undef 1 173 315
assign 1 174 316
new 0 174 316
assign 1 174 317
emptyGet 0 174 317
assign 1 176 320
new 0 176 320
assign 1 176 321
add 1 176 321
assign 1 176 322
lengthGet 0 176 322
assign 1 176 323
substring 2 176 323
assign 1 181 332
stepListGet 0 181 332
assign 1 182 333
linkedListIteratorGet 0 182 333
assign 1 182 336
hasNextGet 0 182 336
assign 1 183 338
nextGet 0 183 338
addValue 1 183 339
assign 1 185 345
join 2 185 345
assign 1 189 350
addStep 1 189 350
return 1 189 351
assign 1 193 355
stepListGet 0 193 355
addValue 1 194 356
addValue 1 195 357
assign 1 196 358
join 2 196 358
assign 1 200 364
create 0 200 364
copyTo 1 201 365
assign 1 202 366
copy 0 202 366
pathSet 1 202 367
return 1 203 368
assign 1 207 372
stepListGet 0 207 372
return 1 207 373
assign 1 211 377
hashGet 0 211 377
return 1 211 378
assign 1 215 383
equals 1 215 383
assign 1 215 384
not 0 215 389
return 1 215 389
assign 1 219 401
undef 1 219 406
assign 1 0 407
assign 1 219 410
new 0 219 410
assign 1 219 411
otherType 2 219 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 219 423
pathGet 0 219 423
assign 1 219 424
notEquals 1 219 424
assign 1 0 426
assign 1 0 429
assign 1 220 433
new 0 220 433
return 1 220 434
assign 1 222 436
new 0 222 436
return 1 222 437
assign 1 226 441
subPath 2 226 441
return 1 226 442
assign 1 230 451
stepsGet 0 230 451
assign 1 231 452
undef 1 231 457
assign 1 232 458
subList 1 232 458
assign 1 234 461
subList 2 234 461
assign 1 236 463
create 0 236 463
separatorSet 1 237 464
assign 1 238 465
new 0 238 465
assign 1 238 466
join 2 238 466
pathSet 1 238 467
return 1 239 468
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -753874803: return bem_parentGet_0();
case 1002576215: return bem_stepsGet_0();
case -1646234581: return bem_toString_0();
case -943840063: return bem_stepListGet_0();
case 166840448: return bem_pathGet_0();
case -612513485: return bem_iteratorGet_0();
case 1958005956: return bem_create_0();
case 1907231669: return bem_copy_0();
case 194410309: return bem_new_0();
case 1094942992: return bem_deleteFirstStep_0();
case -1197964270: return bem_separatorGet_0();
case 1394643411: return bem_hashGet_0();
case 792288964: return bem_lastStepGet_0();
case -1285100593: return bem_isAbsoluteGet_0();
case -2055407646: return bem_makeNonAbsolute_0();
case -2080588698: return bem_makeAbsolute_0();
case 809264885: return bem_print_0();
case 391150679: return bem_firstStepGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 90082456: return bem_pathSet_1(bevd_0);
case 18789665: return bem_def_1(bevd_0);
case 631508268: return bem_addSteps_1(bevd_0);
case -1573167369: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 1883853164: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -753304497: return bem_add_1(bevd_0);
case 1629594916: return bem_notEquals_1(bevd_0);
case -699178641: return bem_separatorSet_1(bevd_0);
case 1191144848: return bem_addStep_1(bevd_0);
case 1684495724: return bem_equals_1(bevd_0);
case 188874323: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 865785432: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -428246641: return bem_copyTo_1(bevd_0);
case -712939838: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1097615570: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1987652456: return bem_undef_1(bevd_0);
case -261357173: return bem_print_1(bevd_0);
case 167158084: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 74525409: return bem_addSteps_2(bevd_0, bevd_1);
case -1205907737: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -742465129: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 485507476: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1409585564: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1654953222: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
