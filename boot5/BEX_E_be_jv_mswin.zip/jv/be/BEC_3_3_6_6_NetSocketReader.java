package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader extends BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1439777293: return bem_hashGet_0();
case -1476019175: return bem_toString_0();
case 188236437: return bem_readBuffer_0();
case -782930029: return bem_readBufferLine_0();
case 1935136194: return bem_classNameGet_0();
case 742371580: return bem_serializeToString_0();
case 1516161879: return bem_fieldNamesGet_0();
case 1447706341: return bem_blockSizeGetDirect_0();
case -1750213491: return bem_sourceFileNameGet_0();
case 655049860: return bem_isClosedGetDirect_0();
case -2070113098: return bem_create_0();
case -1938405231: return bem_readStringClose_0();
case -61288189: return bem_serializationIteratorGet_0();
case -1448868238: return bem_readString_0();
case -618774982: return bem_byteReaderGet_0();
case 1660533487: return bem_serializeContents_0();
case 144022910: return bem_vfileGetDirect_0();
case 1202344364: return bem_deserializeClassNameGet_0();
case -127605128: return bem_extOpen_0();
case 1730802409: return bem_echo_0();
case 1326542704: return bem_tagGet_0();
case -948982310: return bem_many_0();
case -396818886: return bem_close_0();
case 1070146794: return bem_toAny_0();
case 450230894: return bem_print_0();
case 713265783: return bem_blockSizeGet_0();
case 623957818: return bem_once_0();
case 56968208: return bem_vfileGet_0();
case 2051107343: return bem_isClosedGet_0();
case -2073027086: return bem_fieldIteratorGet_0();
case -897350462: return bem_iteratorGet_0();
case 1172450247: return bem_copy_0();
case -1556712456: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2097532659: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -9859284: return bem_blockSizeSetDirect_1(bevd_0);
case -1515217902: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1885394542: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -793385811: return bem_notEquals_1(bevd_0);
case -278236853: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 576740876: return bem_sameType_1(bevd_0);
case -2100846780: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 442825588: return bem_otherClass_1(bevd_0);
case 346840696: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1955801134: return bem_defined_1(bevd_0);
case 1818387158: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1798664639: return bem_undefined_1(bevd_0);
case -957438933: return bem_undef_1(bevd_0);
case -1429851340: return bem_isClosedSetDirect_1(bevd_0);
case -299391132: return bem_equals_1(bevd_0);
case 1294280556: return bem_otherType_1(bevd_0);
case -2143234356: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -778138033: return bem_blockSizeSet_1(bevd_0);
case 1035756454: return bem_vfileSet_1(bevd_0);
case -1143999728: return bem_def_1(bevd_0);
case -527408757: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 650255571: return bem_vfileSetDirect_1(bevd_0);
case 534786196: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 459214857: return bem_isClosedSet_1(bevd_0);
case -889117799: return bem_copyTo_1(bevd_0);
case -1331484847: return bem_sameClass_1(bevd_0);
case -583734547: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 689182857: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 508060454: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736450169: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 64048650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1652676802: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743787834: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -80988829: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1347048779: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1044357781: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 747935504: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
