package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader extends BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 885738063: return bem_vfileGetDirect_0();
case 1739946035: return bem_readDiscardClose_0();
case -1056040173: return bem_blockSizeGetDirect_0();
case 487655943: return bem_hashGet_0();
case 1473635449: return bem_extOpen_0();
case -1250410804: return bem_readDiscard_0();
case -737828887: return bem_serializeContents_0();
case 1177953347: return bem_fieldNamesGet_0();
case -1318471451: return bem_toString_0();
case 1620426785: return bem_fieldIteratorGet_0();
case 1500331013: return bem_readBuffer_0();
case 2001045300: return bem_blockSizeGet_0();
case 30517201: return bem_vfileGet_0();
case 365122488: return bem_isClosedGet_0();
case -1243764713: return bem_sourceFileNameGet_0();
case 458752985: return bem_readString_0();
case 440169444: return bem_tagGet_0();
case 1998804429: return bem_deserializeClassNameGet_0();
case -2046304502: return bem_create_0();
case 1483871301: return bem_print_0();
case 448996129: return bem_classNameGet_0();
case -1633309881: return bem_echo_0();
case 1490571146: return bem_isClosedGetDirect_0();
case -1624889671: return bem_copy_0();
case -1564435804: return bem_new_0();
case 1123303708: return bem_byteReaderGet_0();
case -1142809906: return bem_serializationIteratorGet_0();
case -539525929: return bem_close_0();
case 1581478205: return bem_iteratorGet_0();
case -33242840: return bem_readBufferLine_0();
case -502024501: return bem_readStringClose_0();
case -2033056683: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -123304739: return bem_vfileSetDirect_1(bevd_0);
case -1601506198: return bem_otherClass_1(bevd_0);
case 1724702365: return bem_copyTo_1(bevd_0);
case -1217337757: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1900502363: return bem_def_1(bevd_0);
case 164974119: return bem_isClosedSet_1(bevd_0);
case -1801363800: return bem_sameType_1(bevd_0);
case 714413924: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1110642088: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 965946056: return bem_sameClass_1(bevd_0);
case 1107454429: return bem_blockSizeSet_1(bevd_0);
case -1961620016: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -1455347724: return bem_vfileSet_1(bevd_0);
case -614712711: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1655576193: return bem_undef_1(bevd_0);
case 887328988: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1276126874: return bem_otherType_1(bevd_0);
case -48526213: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 309229541: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1589896817: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1295655542: return bem_blockSizeSetDirect_1(bevd_0);
case -279659801: return bem_isClosedSetDirect_1(bevd_0);
case -1767763000: return bem_sameObject_1(bevd_0);
case -776802815: return bem_notEquals_1(bevd_0);
case -40889849: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -180551001: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -984805442: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 162928067: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -336527550: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1644303351: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1958583648: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1523818061: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 61798183: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
