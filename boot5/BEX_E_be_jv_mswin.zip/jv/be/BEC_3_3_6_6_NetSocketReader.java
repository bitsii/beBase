package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader extends BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1868839122: return bem_blockSizeGetDirect_0();
case -102149480: return bem_serializeToString_0();
case 1482277663: return bem_echo_0();
case -1009057211: return bem_readBuffer_0();
case -1452121821: return bem_isClosedGetDirect_0();
case 2022892861: return bem_byteReaderGet_0();
case 551620439: return bem_vfileGet_0();
case -568872705: return bem_readStringClose_0();
case -41333960: return bem_deserializeClassNameGet_0();
case -2107653327: return bem_fieldIteratorGet_0();
case -314408008: return bem_iteratorGet_0();
case 1821082307: return bem_print_0();
case 1658050823: return bem_blockSizeGet_0();
case -511250160: return bem_fieldNamesGet_0();
case 577093211: return bem_many_0();
case 775617472: return bem_close_0();
case -1425389541: return bem_new_0();
case -670803938: return bem_sourceFileNameGet_0();
case 361790008: return bem_hashGet_0();
case -1920210020: return bem_once_0();
case -1489233610: return bem_extOpen_0();
case 1800445194: return bem_create_0();
case 856499898: return bem_vfileGetDirect_0();
case 296622746: return bem_classNameGet_0();
case -19384722: return bem_toAny_0();
case -1768205182: return bem_serializationIteratorGet_0();
case -2074204580: return bem_copy_0();
case 1702722957: return bem_readBufferLine_0();
case -461072455: return bem_toString_0();
case 1993705736: return bem_serializeContents_0();
case -212193921: return bem_tagGet_0();
case -1956912263: return bem_readString_0();
case 1981813514: return bem_isClosedGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 264755501: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1581137443: return bem_blockSizeSet_1(bevd_0);
case 1389268037: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -837815458: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1567535449: return bem_sameObject_1(bevd_0);
case 764373340: return bem_copyTo_1(bevd_0);
case -1987055831: return bem_notEquals_1(bevd_0);
case -2110248602: return bem_undefined_1(bevd_0);
case -1192710672: return bem_equals_1(bevd_0);
case 242004544: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1466482634: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -534656230: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1669994973: return bem_vfileSetDirect_1(bevd_0);
case -676548815: return bem_undef_1(bevd_0);
case -155631619: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1026739914: return bem_defined_1(bevd_0);
case 883351097: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -998366557: return bem_blockSizeSetDirect_1(bevd_0);
case 979197653: return bem_vfileSet_1(bevd_0);
case -1161197989: return bem_sameType_1(bevd_0);
case -1698518658: return bem_isClosedSet_1(bevd_0);
case -320284120: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1302247727: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -1463366211: return bem_def_1(bevd_0);
case -1908940247: return bem_otherClass_1(bevd_0);
case -703853755: return bem_isClosedSetDirect_1(bevd_0);
case -1398560259: return bem_otherType_1(bevd_0);
case -1272397031: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 764231776: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -830320987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -711906439: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1354452916: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1773886690: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1269395056: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 220461512: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 278898562: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1534011050: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1333771618: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
