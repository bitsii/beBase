package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader extends BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 322973431: return bem_print_0();
case -43502949: return bem_toAny_0();
case 291309239: return bem_once_0();
case -753644705: return bem_hashGet_0();
case 597357534: return bem_tagGet_0();
case -304415890: return bem_classNameGet_0();
case -1869003680: return bem_byteReaderGet_0();
case 1157301587: return bem_close_0();
case 479292151: return bem_readBufferLine_0();
case 1429146322: return bem_isClosedGetDirect_0();
case 1617633427: return bem_blockSizeGetDirect_0();
case 364235321: return bem_echo_0();
case 971822467: return bem_extOpen_0();
case -924344556: return bem_vfileGetDirect_0();
case -2132142484: return bem_vfileGet_0();
case -381740729: return bem_deserializeClassNameGet_0();
case -1569222986: return bem_fieldIteratorGet_0();
case -545885409: return bem_fieldNamesGet_0();
case -1087766017: return bem_serializeToString_0();
case -909675958: return bem_create_0();
case 979990386: return bem_readBuffer_0();
case 2074266301: return bem_blockSizeGet_0();
case 978833082: return bem_readStringClose_0();
case 305613993: return bem_sourceFileNameGet_0();
case 678571136: return bem_many_0();
case 2050059376: return bem_iteratorGet_0();
case 41741112: return bem_isClosedGet_0();
case 1851036145: return bem_serializationIteratorGet_0();
case 625547167: return bem_toString_0();
case -1780819108: return bem_readDiscard_0();
case -410783155: return bem_new_0();
case 1461724031: return bem_copy_0();
case -1101326644: return bem_serializeContents_0();
case 1971213138: return bem_readString_0();
case 486553642: return bem_readDiscardClose_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1919579319: return bem_isClosedSet_1(bevd_0);
case -1336918489: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case 1736818893: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 624034541: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case -920356799: return bem_blockSizeSet_1(bevd_0);
case -1648245094: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1775975192: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case -1044251552: return bem_vfileSet_1(bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case -219052996: return bem_vfileSetDirect_1(bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
case 934852927: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -507533686: return bem_blockSizeSetDirect_1(bevd_0);
case 949946770: return bem_isClosedSetDirect_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -587279589: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1417970511: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 2029842564: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
