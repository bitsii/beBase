package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader extends BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -616437991: return bem_vfileGet_0();
case 1018929608: return bem_iteratorGet_0();
case 617077171: return bem_byteReaderGet_0();
case -278676308: return bem_copy_0();
case -1734622773: return bem_blockSizeGet_0();
case -989279639: return bem_toString_0();
case 1349825318: return bem_hashGet_0();
case -451225196: return bem_readDiscardClose_0();
case 1486356623: return bem_new_0();
case 1073551348: return bem_extOpen_0();
case -1434879509: return bem_close_0();
case 1041690009: return bem_create_0();
case 480409314: return bem_readString_0();
case 1497579429: return bem_readStringClose_0();
case 1771552103: return bem_readBuffer_0();
case -780576950: return bem_isClosedGet_0();
case 2127199289: return bem_readDiscard_0();
case -1846934490: return bem_readBufferLine_0();
case -2075471997: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -224749728: return bem_vfileSet_1(bevd_0);
case -307455795: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 2147243357: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 429997543: return bem_undef_1(bevd_0);
case 1763300239: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -723481642: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 2001366394: return bem_def_1(bevd_0);
case 1826376252: return bem_copyTo_1(bevd_0);
case -1283958111: return bem_notEquals_1(bevd_0);
case -1090873121: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -2083866377: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1512419731: return bem_blockSizeSet_1(bevd_0);
case 964719406: return bem_equals_1(bevd_0);
case -205829710: return bem_isClosedSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -873382988: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1261192257: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -825340533: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -664771192: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 864744165: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1034557923: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1059882876: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_3_6_6_NetSocketReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
