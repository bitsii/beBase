package be;
public class BET_3_9_10_8_ContainerLinkedListIterator extends BETS_Object {
public BET_3_9_10_8_ContainerLinkedListIterator() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_1", "containerGet_0", "hasCurrentGet_0", "hasNextGet_0", "nextSet_1", "nextNodeGet_0", "currentNodeGet_0", "currentNodeSet_1", "currentGet_0", "currentSet_1", "nextGet_0", "skip_1", "listGet_0", "listSet_1", "currNodeGet_0", "currNodeSet_1", "startingGet_0", "startingSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "list", "currNode", "starting" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_9_10_8_ContainerLinkedListIterator();
}
}
