package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_7_TemplateReplace extends BEC_2_6_6_SystemObject {
public BEC_2_8_7_TemplateReplace() { }
private static byte[] becc_BEC_2_8_7_TemplateReplace_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_BEC_2_8_7_TemplateReplace_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_1 = {0x3F,0x3E};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_2 = {0x20};
public static BEC_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_inst;

public static BET_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_steps;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_append;
public BEC_2_8_6_TemplateRunner bevp_runner;
public BEC_2_8_7_TemplateReplace bem_new_0() throws Throwable {
bevp_append = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_load_2(beva_template, null);
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_2(BEC_2_4_6_TextString beva_template, BEC_2_8_6_TemplateRunner beva__runner) throws Throwable {
BEC_2_4_6_TextString bevl_blStart = null;
BEC_2_4_6_TextString bevl_blEnd = null;
BEC_2_5_4_LogicBool bevl_onStart = null;
BEC_2_5_4_LogicBool bevl_nextIsCall = null;
BEC_2_4_6_TextString bevl_delim = null;
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_4_6_TextString bevl_payload = null;
BEC_2_9_10_ContainerLinkedList bevl_payloads = null;
BEC_2_7_8_ReplaceCallStep bevl_rcs = null;
BEC_2_4_6_TextString bevl_paypart = null;
BEC_2_7_7_ReplaceRunStep bevl_rs = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_9_TextTokenizer bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (new BEC_2_4_6_TextString(4, bece_BEC_2_8_7_TemplateReplace_bels_0));
bevl_blEnd = (new BEC_2_4_6_TextString(2, bece_BEC_2_8_7_TemplateReplace_bels_1));
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
/* Line: 88*/ {
if (bevl_i == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 88*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 89*/ {
if (bevl_nextIsCall.bevi_bool)/* Line: 90*/ {
bevt_3_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_strip_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_8_7_TemplateReplace_bels_2));
bevt_4_ta_ph = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_5_ta_ph);
bevl_payloads = (BEC_2_9_10_ContainerLinkedList) bevt_4_ta_ph.bem_tokenize_1(bevl_payload);
if (bevp_runner == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 93*/ {
bevl_rcs = (new BEC_2_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 97*/
 else /* Line: 98*/ {
bevt_0_ta_loop = bevl_payloads.bem_linkedListIteratorGet_0();
while (true)
/* Line: 100*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 100*/ {
bevl_paypart = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_rs = (new BEC_2_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 102*/
 else /* Line: 100*/ {
break;
} /* Line: 100*/
} /* Line: 100*/
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 104*/
} /* Line: 93*/
 else /* Line: 106*/ {
bevt_9_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_8_ta_ph = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_9_ta_ph);
bevl_splits.bem_addValue_1(bevt_8_ta_ph);
} /* Line: 107*/
} /* Line: 90*/
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool)/* Line: 111*/ {
bevl_onStart = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = be.BECS_Runtime.boolTrue;
} /* Line: 115*/
 else /* Line: 116*/ {
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 119*/
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 121*/
 else /* Line: 88*/ {
break;
} /* Line: 88*/
} /* Line: 88*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 123*/ {
bevt_12_ta_ph = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_11_ta_ph = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_12_ta_ph);
bevl_splits.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 124*/
bevp_steps = bevl_splits;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_accept_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_out) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
/* Line: 131*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(935059941);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 131*/ {
bevl_s = bevl_iter.bemd_0(498054450);
if (bevp_append.bevi_bool)/* Line: 133*/ {
bevt_1_ta_ph = bevl_s.bemd_1(-2094170743, beva_inst);
beva_out.bemd_1(762300875, bevt_1_ta_ph);
} /* Line: 134*/
} /* Line: 133*/
 else /* Line: 131*/ {
break;
} /* Line: 131*/
} /* Line: 131*/
return beva_out;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
return bevp_steps;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_stepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_appendGet_0() throws Throwable {
return bevp_append;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_appendSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runnerGet_0() throws Throwable {
return bevp_runner;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_runnerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {64, 71, 75, 76, 78, 79, 80, 81, 83, 84, 85, 86, 87, 88, 88, 89, 89, 91, 91, 92, 92, 92, 93, 93, 95, 96, 97, 100, 0, 100, 100, 101, 102, 104, 107, 107, 107, 110, 112, 113, 114, 115, 117, 118, 119, 121, 123, 123, 124, 124, 124, 126, 130, 131, 132, 134, 134, 137, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 23, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 67, 72, 73, 78, 80, 81, 82, 83, 84, 85, 90, 91, 92, 93, 96, 96, 99, 101, 102, 103, 109, 113, 114, 115, 118, 120, 121, 122, 123, 126, 127, 128, 130, 136, 141, 142, 143, 144, 146, 154, 157, 159, 161, 162, 169, 172, 175, 179, 182, 186, 189, 193, 196};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 64 19
new 0 64 19
load 2 71 23
assign 1 75 54
assign 1 76 55
sizeGet 0 76 55
assign 1 78 56
new 0 78 56
assign 1 79 57
new 0 79 57
assign 1 80 58
new 0 80 58
assign 1 81 59
new 0 81 59
assign 1 83 60
assign 1 84 61
new 0 84 61
assign 1 85 62
new 0 85 62
assign 1 86 63
find 2 86 63
assign 1 87 64
sizeGet 0 87 64
assign 1 88 67
def 1 88 72
assign 1 89 73
greater 1 89 78
assign 1 91 80
substring 2 91 80
assign 1 91 81
strip 0 91 81
assign 1 92 82
new 0 92 82
assign 1 92 83
new 1 92 83
assign 1 92 84
tokenize 1 92 84
assign 1 93 85
undef 1 93 90
assign 1 95 91
new 1 95 91
addValue 1 96 92
assign 1 97 93
new 0 97 93
assign 1 100 96
linkedListIteratorGet 0 0 96
assign 1 100 99
hasNextGet 0 100 99
assign 1 100 101
nextGet 0 100 101
assign 1 101 102
new 2 101 102
addValue 1 102 103
assign 1 104 109
new 0 104 109
assign 1 107 113
substring 2 107 113
assign 1 107 114
new 1 107 114
addValue 1 107 115
assign 1 110 118
add 1 110 118
assign 1 112 120
new 0 112 120
assign 1 113 121
assign 1 114 122
sizeGet 0 114 122
assign 1 115 123
new 0 115 123
assign 1 117 126
new 0 117 126
assign 1 118 127
assign 1 119 128
sizeGet 0 119 128
assign 1 121 130
find 2 121 130
assign 1 123 136
lesser 1 123 141
assign 1 124 142
substring 2 124 142
assign 1 124 143
new 1 124 143
addValue 1 124 144
assign 1 126 146
assign 1 130 154
iteratorGet 0 130 154
assign 1 131 157
hasNextGet 0 131 157
assign 1 132 159
nextGet 0 132 159
assign 1 134 161
handle 1 134 161
write 1 134 162
return 1 137 169
return 1 0 172
assign 1 0 175
return 1 0 179
assign 1 0 182
return 1 0 186
assign 1 0 189
return 1 0 193
assign 1 0 196
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 749584012: return bem_hashGet_0();
case 740774521: return bem_print_0();
case -813823710: return bem_iteratorGet_0();
case 279017063: return bem_copy_0();
case 1337268080: return bem_create_0();
case 705455449: return bem_sizeGet_0();
case 935276474: return bem_runnerGet_0();
case -1204561292: return bem_stepsGet_0();
case 1568049382: return bem_appendGet_0();
case -287453828: return bem_new_0();
case -1162278176: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2141326693: return bem_stepsSet_1(bevd_0);
case 61295817: return bem_appendSet_1(bevd_0);
case -60837636: return bem_def_1(bevd_0);
case -962222626: return bem_runnerSet_1(bevd_0);
case -286545109: return bem_notEquals_1(bevd_0);
case -611791626: return bem_sizeSet_1(bevd_0);
case -1232318468: return bem_equals_1(bevd_0);
case -917009475: return bem_undef_1(bevd_0);
case -1600575656: return bem_copyTo_1(bevd_0);
case -577983998: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -539426492: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -706931313: return bem_accept_2(bevd_0, bevd_1);
case -533312375: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -306114529: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -551967809: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -379250782: return bem_load_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_8_6_TemplateRunner) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_8_7_TemplateReplace_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_7_TemplateReplace_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_7_TemplateReplace();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst = (BEC_2_8_7_TemplateReplace) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_type;
}
}
