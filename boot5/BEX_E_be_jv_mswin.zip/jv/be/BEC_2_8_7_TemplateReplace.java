package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_7_TemplateReplace extends BEC_2_6_6_SystemObject {
public BEC_2_8_7_TemplateReplace() { }
private static byte[] becc_BEC_2_8_7_TemplateReplace_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_BEC_2_8_7_TemplateReplace_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_1 = {0x3F,0x3E};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_2 = {0x20};
public static BEC_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_inst;

public static BET_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_steps;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_append;
public BEC_2_8_6_TemplateRunner bevp_runner;
public BEC_2_8_7_TemplateReplace bem_new_0() throws Throwable {
bevp_append = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_load_2(beva_template, null);
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_2(BEC_2_4_6_TextString beva_template, BEC_2_8_6_TemplateRunner beva__runner) throws Throwable {
BEC_2_4_6_TextString bevl_blStart = null;
BEC_2_4_6_TextString bevl_blEnd = null;
BEC_2_5_4_LogicBool bevl_onStart = null;
BEC_2_5_4_LogicBool bevl_nextIsCall = null;
BEC_2_4_6_TextString bevl_delim = null;
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_4_6_TextString bevl_payload = null;
BEC_2_9_10_ContainerLinkedList bevl_payloads = null;
BEC_2_7_8_ReplaceCallStep bevl_rcs = null;
BEC_2_4_6_TextString bevl_paypart = null;
BEC_2_7_7_ReplaceRunStep bevl_rs = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_9_TextTokenizer bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (new BEC_2_4_6_TextString(4, bece_BEC_2_8_7_TemplateReplace_bels_0));
bevl_blEnd = (new BEC_2_4_6_TextString(2, bece_BEC_2_8_7_TemplateReplace_bels_1));
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
/* Line: 82*/ {
if (bevl_i == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 82*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 83*/ {
if (bevl_nextIsCall.bevi_bool)/* Line: 84*/ {
bevt_3_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_strip_0();
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_8_7_TemplateReplace_bels_2));
bevt_4_ta_ph = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_5_ta_ph);
bevl_payloads = (BEC_2_9_10_ContainerLinkedList) bevt_4_ta_ph.bem_tokenize_1(bevl_payload);
if (bevp_runner == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 87*/ {
bevl_rcs = (new BEC_2_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 91*/
 else /* Line: 92*/ {
bevt_0_ta_loop = bevl_payloads.bem_linkedListIteratorGet_0();
while (true)
/* Line: 94*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 94*/ {
bevl_paypart = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_rs = (new BEC_2_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 96*/
 else /* Line: 94*/ {
break;
} /* Line: 94*/
} /* Line: 94*/
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 98*/
} /* Line: 87*/
 else /* Line: 100*/ {
bevt_9_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_8_ta_ph = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_9_ta_ph);
bevl_splits.bem_addValue_1(bevt_8_ta_ph);
} /* Line: 101*/
} /* Line: 84*/
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool)/* Line: 105*/ {
bevl_onStart = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = be.BECS_Runtime.boolTrue;
} /* Line: 109*/
 else /* Line: 110*/ {
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 113*/
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 115*/
 else /* Line: 82*/ {
break;
} /* Line: 82*/
} /* Line: 82*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 117*/ {
bevt_12_ta_ph = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_11_ta_ph = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_12_ta_ph);
bevl_splits.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 118*/
bevp_steps = bevl_splits;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_accept_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_out) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
/* Line: 125*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(1795368709);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 125*/ {
bevl_s = bevl_iter.bemd_0(39409994);
if (bevp_append.bevi_bool)/* Line: 127*/ {
bevt_1_ta_ph = bevl_s.bemd_1(-1143723910, beva_inst);
beva_out.bemd_1(1502220220, bevt_1_ta_ph);
} /* Line: 128*/
} /* Line: 127*/
 else /* Line: 125*/ {
break;
} /* Line: 125*/
} /* Line: 125*/
return beva_out;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
return bevp_steps;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_stepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_appendGet_0() throws Throwable {
return bevp_append;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_appendSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runnerGet_0() throws Throwable {
return bevp_runner;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_runnerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {58, 65, 69, 70, 72, 73, 74, 75, 77, 78, 79, 80, 81, 82, 82, 83, 83, 85, 85, 86, 86, 86, 87, 87, 89, 90, 91, 94, 0, 94, 94, 95, 96, 98, 101, 101, 101, 104, 106, 107, 108, 109, 111, 112, 113, 115, 117, 117, 118, 118, 118, 120, 124, 125, 126, 128, 128, 131, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 23, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 67, 72, 73, 78, 80, 81, 82, 83, 84, 85, 90, 91, 92, 93, 96, 96, 99, 101, 102, 103, 109, 113, 114, 115, 118, 120, 121, 122, 123, 126, 127, 128, 130, 136, 141, 142, 143, 144, 146, 154, 157, 159, 161, 162, 169, 172, 175, 179, 182, 186, 189, 193, 196};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 58 19
new 0 58 19
load 2 65 23
assign 1 69 54
assign 1 70 55
sizeGet 0 70 55
assign 1 72 56
new 0 72 56
assign 1 73 57
new 0 73 57
assign 1 74 58
new 0 74 58
assign 1 75 59
new 0 75 59
assign 1 77 60
assign 1 78 61
new 0 78 61
assign 1 79 62
new 0 79 62
assign 1 80 63
find 2 80 63
assign 1 81 64
sizeGet 0 81 64
assign 1 82 67
def 1 82 72
assign 1 83 73
greater 1 83 78
assign 1 85 80
substring 2 85 80
assign 1 85 81
strip 0 85 81
assign 1 86 82
new 0 86 82
assign 1 86 83
new 1 86 83
assign 1 86 84
tokenize 1 86 84
assign 1 87 85
undef 1 87 90
assign 1 89 91
new 1 89 91
addValue 1 90 92
assign 1 91 93
new 0 91 93
assign 1 94 96
linkedListIteratorGet 0 0 96
assign 1 94 99
hasNextGet 0 94 99
assign 1 94 101
nextGet 0 94 101
assign 1 95 102
new 2 95 102
addValue 1 96 103
assign 1 98 109
new 0 98 109
assign 1 101 113
substring 2 101 113
assign 1 101 114
new 1 101 114
addValue 1 101 115
assign 1 104 118
add 1 104 118
assign 1 106 120
new 0 106 120
assign 1 107 121
assign 1 108 122
sizeGet 0 108 122
assign 1 109 123
new 0 109 123
assign 1 111 126
new 0 111 126
assign 1 112 127
assign 1 113 128
sizeGet 0 113 128
assign 1 115 130
find 2 115 130
assign 1 117 136
lesser 1 117 141
assign 1 118 142
substring 2 118 142
assign 1 118 143
new 1 118 143
addValue 1 118 144
assign 1 120 146
assign 1 124 154
iteratorGet 0 124 154
assign 1 125 157
hasNextGet 0 125 157
assign 1 126 159
nextGet 0 126 159
assign 1 128 161
handle 1 128 161
write 1 128 162
return 1 131 169
return 1 0 172
assign 1 0 175
return 1 0 179
assign 1 0 182
return 1 0 186
assign 1 0 189
return 1 0 193
assign 1 0 196
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -216140457: return bem_stepsGet_0();
case 1123564946: return bem_create_0();
case -1288085492: return bem_copy_0();
case 900720046: return bem_tagGet_0();
case -39207367: return bem_sizeGet_0();
case -547430364: return bem_toString_0();
case -330424784: return bem_hashGet_0();
case -372838528: return bem_new_0();
case 1296887765: return bem_classNameGet_0();
case 324152124: return bem_print_0();
case 417170865: return bem_runnerGet_0();
case 1315317601: return bem_fieldNamesGet_0();
case -571631666: return bem_appendGet_0();
case 884317404: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1290374989: return bem_undef_1(bevd_0);
case 1912890932: return bem_equals_1(bevd_0);
case 2046794310: return bem_runnerSet_1(bevd_0);
case 592595513: return bem_sameType_1(bevd_0);
case -1541611901: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -1825986767: return bem_otherType_1(bevd_0);
case -326004565: return bem_sizeSet_1(bevd_0);
case 1925943973: return bem_appendSet_1(bevd_0);
case 1863587245: return bem_notEquals_1(bevd_0);
case -2119494398: return bem_def_1(bevd_0);
case -1799609678: return bem_sameObject_1(bevd_0);
case -158673770: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2066430331: return bem_stepsSet_1(bevd_0);
case 1862342797: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1154474937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1719469512: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 934078589: return bem_load_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_8_6_TemplateRunner) bevd_1);
case 3383792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -601625846: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 261957440: return bem_accept_2(bevd_0, bevd_1);
case 826572174: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_8_7_TemplateReplace_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_7_TemplateReplace_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_7_TemplateReplace();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst = (BEC_2_8_7_TemplateReplace) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_type;
}
}
