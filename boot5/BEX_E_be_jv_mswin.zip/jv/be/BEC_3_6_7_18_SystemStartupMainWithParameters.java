package be;
/* IO:File: source/extended/Startup.be */
public class BEC_3_6_7_18_SystemStartupMainWithParameters extends BEC_2_6_6_SystemObject {
public BEC_3_6_7_18_SystemStartupMainWithParameters() { }
private static byte[] becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x3A,0x4D,0x61,0x69,0x6E,0x57,0x69,0x74,0x68,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
public static BEC_3_6_7_18_SystemStartupMainWithParameters bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst;

public static BET_3_6_7_18_SystemStartupMainWithParameters bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_type;

public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_3_ta_ph = null;
bevt_3_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_main_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_6_10_SystemParameters beva_params) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_2_ta_ph = beva_params.bem_orderedGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bevt_2_ta_ph.bem_get_1(bevt_3_ta_ph);
bevt_0_ta_ph = bem_createInstance_1((BEC_2_4_6_TextString) bevt_1_ta_ph );
bevl_x = bevt_0_ta_ph.bemd_0(1847639727);
bevt_4_ta_ph = bevl_x.bemd_1(-1514072873, beva_params);
return bevt_4_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {309, 309, 309, 309, 309, 316, 316, 316, 316, 316, 317, 317};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 20, 29, 30, 31, 32, 33, 34, 35};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 309 16
new 0 309 16
assign 1 309 17
argsGet 0 309 17
assign 1 309 18
new 1 309 18
assign 1 309 19
main 1 309 19
return 1 309 20
assign 1 316 29
orderedGet 0 316 29
assign 1 316 30
new 0 316 30
assign 1 316 31
get 1 316 31
assign 1 316 32
createInstance 1 316 32
assign 1 316 33
new 0 316 33
assign 1 317 34
main 1 317 34
return 1 317 35
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 38127485: return bem_iteratorGet_0();
case -1634438305: return bem_main_0();
case 854710191: return bem_create_0();
case 636345: return bem_print_0();
case 2061432375: return bem_tagGet_0();
case 1847639727: return bem_new_0();
case 793589441: return bem_classNameGet_0();
case -1331374769: return bem_toString_0();
case -1818293830: return bem_fieldNamesGet_0();
case -1508036637: return bem_copy_0();
case -22788464: return bem_hashGet_0();
case -593469656: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -502376443: return bem_equals_1(bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1514072873: return bem_main_1((BEC_2_6_10_SystemParameters) bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(33, becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_7_18_SystemStartupMainWithParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_7_18_SystemStartupMainWithParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst = (BEC_3_6_7_18_SystemStartupMainWithParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_6_7_18_SystemStartupMainWithParameters.bece_BEC_3_6_7_18_SystemStartupMainWithParameters_bevs_type;
}
}
