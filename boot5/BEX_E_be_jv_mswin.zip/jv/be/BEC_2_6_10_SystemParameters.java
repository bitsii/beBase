package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x2D,0x2D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x2D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_6 = {0x3D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_7 = {0x23,0x2D,0x2D};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_8 = {0x23};
public static BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_initialArgs;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public BEC_2_6_10_SystemParameters bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevp_initialArgs = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_args = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toJson_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_9_4_ContainerMaps bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_10_JsonMarshaller bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[7];
bevt_0_ta_ph = (BEC_2_9_4_ContainerMaps) BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevd_x[0] = bevt_1_ta_ph;
bevd_x[1] = bevp_args;
bevd_x[2] = bevt_2_ta_ph;
bevd_x[3] = bevp_params;
bevd_x[4] = bevt_3_ta_ph;
bevd_x[5] = bevp_ordered;
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_ta_ph.bem_forwardCall_2(new BEC_2_4_6_TextString("from".getBytes("UTF-8")), (new BEC_2_9_4_ContainerList(bevd_x, 6)).bem_copy_0());
bevt_5_ta_ph = (new BEC_2_4_10_JsonMarshaller()).bem_new_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_marshall_1(bevl_jsm);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fromJson_1(BEC_2_4_6_TextString beva_jsms) throws Throwable {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_4_12_JsonUnmarshaller bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_12_JsonUnmarshaller()).bem_new_0();
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_ta_ph.bem_unmarshall_1(beva_jsms);
bevt_1_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevp_args = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevp_params = (BEC_2_9_3_ContainerMap) bevl_jsm.bem_get_1(bevt_2_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevp_ordered = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fromJsonFile_1(BEC_2_2_4_IOFile beva_jsf) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_2_ta_ph = beva_jsf.bem_readerGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1287088203);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-352709573);
bem_fromJson_1((BEC_2_4_6_TextString) bevt_0_ta_ph );
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_toJsonFile_1(BEC_2_2_4_IOFile beva_jsf) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = beva_jsf.bem_writerGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1287088203);
bevt_2_ta_ph = bem_toJson_0();
bevt_0_ta_ph.bemd_1(2143726304, bevt_2_ta_ph);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addValue_1(BEC_2_6_10_SystemParameters beva_p) throws Throwable {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_9_10_ContainerLinkedList bevl_cp = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_9_4_ContainerList bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_p.bem_argsGet_0();
bevp_args.bem_addValue_1(bevt_1_ta_ph);
bevt_2_ta_ph = beva_p.bem_orderedGet_0();
bevp_ordered.bem_addValue_1(bevt_2_ta_ph);
bevt_3_ta_ph = beva_p.bem_paramsGet_0();
bevt_0_ta_loop = bevt_3_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 146*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 146*/ {
bevl_kv = bevt_0_ta_loop.bemd_0(900728463);
bevt_5_ta_ph = bevl_kv.bemd_0(-770575040);
bevl_cp = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevt_5_ta_ph);
if (bevl_cp == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 148*/ {
bevt_7_ta_ph = bevl_kv.bemd_0(2122847983);
bevl_cp.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 149*/
 else /* Line: 150*/ {
bevt_8_ta_ph = bevl_kv.bemd_0(-770575040);
bevt_9_ta_ph = bevl_kv.bemd_0(2122847983);
bevp_params.bem_put_2(bevt_8_ta_ph, bevt_9_ta_ph);
} /* Line: 151*/
} /* Line: 148*/
 else /* Line: 146*/ {
break;
} /* Line: 146*/
} /* Line: 146*/
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
bem_new_0();
bevp_initialArgs = beva__args;
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
if (bevp_preProcessor == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 163*/ {
bevl_ii = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 164*/ {
bevt_7_ta_ph = beva__args.bemd_0(1499089390);
bevt_6_ta_ph = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_ta_ph );
if (bevt_6_ta_ph.bevi_bool)/* Line: 164*/ {
bevt_9_ta_ph = beva__args.bemd_1(1379140839, bevl_ii);
bevt_8_ta_ph = bevp_preProcessor.bemd_1(1235148147, bevt_9_ta_ph);
beva__args.bemd_2(1177333270, bevl_ii, bevt_8_ta_ph);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 164*/
 else /* Line: 164*/ {
break;
} /* Line: 164*/
} /* Line: 164*/
} /* Line: 164*/
bevp_args = bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
bevt_0_ta_loop = beva__args.bemd_0(326916018);
while (true)
/* Line: 171*/ {
bevt_10_ta_ph = bevt_0_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 171*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(900728463);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_ta_ph = bevl_i.bem_sizeGet_0();
bevt_13_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_12_ta_ph.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 175*/ {
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_15_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_fa = bevl_i.bem_substring_2(bevt_14_ta_ph, bevt_15_ta_ph);
bevt_17_ta_ph = bevl_i.bem_sizeGet_0();
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_17_ta_ph.bevi_int > bevt_18_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 177*/ {
bevt_19_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_20_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_fb = bevl_i.bem_substring_2(bevt_19_ta_ph, bevt_20_ta_ph);
bevt_22_ta_ph = bevl_i.bem_sizeGet_0();
bevt_23_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevt_22_ta_ph.bevi_int > bevt_23_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 179*/ {
bevt_24_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_25_ta_ph = (new BEC_2_4_3_MathInt(3));
bevl_fc = bevl_i.bem_substring_2(bevt_24_ta_ph, bevt_25_ta_ph);
} /* Line: 180*/
} /* Line: 179*/
} /* Line: 177*/
if (bevl_pname == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 184*/ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 185*/ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 186*/
bevl_pname = null;
bevl_pnameComment = be.BECS_Runtime.boolFalse;
} /* Line: 189*/
 else /* Line: 184*/ {
if (bevl_fb == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_30_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_4));
bevt_29_ta_ph = bevl_fb.bem_equals_1(bevt_30_ta_ph);
if (bevt_29_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 190*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 190*/
 else /* Line: 190*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 190*/ {
bevt_31_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_32_ta_ph = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_ta_ph, bevt_32_ta_ph);
} /* Line: 191*/
 else /* Line: 184*/ {
if (bevl_fa == null) {
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 192*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemParameters_bels_5));
bevt_34_ta_ph = bevl_fa.bem_equals_1(bevt_35_ta_ph);
if (bevt_34_ta_ph.bevi_bool)/* Line: 192*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 192*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 192*/
 else /* Line: 192*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 192*/ {
bevt_36_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_37_ta_ph = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_ta_ph, bevt_37_ta_ph);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemParameters_bels_6));
bevl_pos = bevl_par.bem_find_1(bevt_38_ta_ph);
if (bevl_pos == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 195*/ {
bevt_40_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_key = bevl_par.bem_substring_2(bevt_40_ta_ph, bevl_pos);
bevt_42_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_41_ta_ph = bevl_pos.bem_add_1(bevt_42_ta_ph);
bevl_value = bevl_par.bem_substring_1(bevt_41_ta_ph);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 198*/
} /* Line: 195*/
 else /* Line: 184*/ {
if (bevl_fc == null) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 200*/ {
bevt_45_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_10_SystemParameters_bels_7));
bevt_44_ta_ph = bevl_fc.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 200*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 200*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 200*/
 else /* Line: 200*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 200*/ {
bevt_46_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_47_ta_ph = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_ta_ph, bevt_47_ta_ph);
bevl_pnameComment = be.BECS_Runtime.boolTrue;
} /* Line: 202*/
 else /* Line: 184*/ {
if (bevl_fa == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 203*/ {
bevt_50_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemParameters_bels_8));
bevt_49_ta_ph = bevl_fa.bem_equals_1(bevt_50_ta_ph);
if (bevt_49_ta_ph.bevi_bool)/* Line: 203*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 203*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 203*/
 else /* Line: 203*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool) {
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 203*/ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 204*/
} /* Line: 184*/
} /* Line: 184*/
} /* Line: 184*/
} /* Line: 184*/
} /* Line: 184*/
 else /* Line: 171*/ {
break;
} /* Line: 171*/
} /* Line: 171*/
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 211*/ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 212*/ {
bevt_3_ta_ph = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_5_ta_ph = bevp_args.bem_get_1(bevl_i);
bevt_4_ta_ph = bevp_preProcessor.bemd_1(1235148147, bevt_5_ta_ph);
bevp_args.bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 212*/
 else /* Line: 212*/ {
break;
} /* Line: 212*/
} /* Line: 212*/
} /* Line: 212*/
if (bevp_ordered == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 217*/ {
bevt_8_ta_ph = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_10_ta_ph = bevp_ordered.bem_get_1(bevl_i);
bevt_9_ta_ph = bevp_preProcessor.bemd_1(1235148147, bevt_10_ta_ph);
bevp_ordered.bem_put_2(bevl_i, bevt_9_ta_ph);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 217*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
} /* Line: 217*/
if (bevp_params == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 221*/ {
bevl__params = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
/* Line: 223*/ {
bevt_12_ta_ph = bevl_it.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 223*/ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(900728463);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_ta_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
/* Line: 227*/ {
bevt_13_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 227*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevt_14_ta_ph = bevp_preProcessor.bemd_1(1235148147, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_ta_ph);
} /* Line: 228*/
 else /* Line: 227*/ {
break;
} /* Line: 227*/
} /* Line: 227*/
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(1235148147, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 231*/
 else /* Line: 223*/ {
break;
} /* Line: 223*/
} /* Line: 223*/
bevp_params = bevl__params;
} /* Line: 233*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 239*/ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 241*/
return beva_isit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_isTrue_2(beva_name, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_params.bem_has_1(beva_name);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 261*/ {
bevl_pl = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 263*/
return bevl_pl;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getFirst_2(beva_name, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 274*/ {
return beva_default;
} /* Line: 275*/
bevt_1_ta_ph = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_ta_ph;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 287*/ {
bevl_vals = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 289*/
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) throws Throwable {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = beva_file.bem_readerGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1287088203);
bevl_fcontents = bevt_0_ta_ph.bemd_0(428366797);
bevt_2_ta_ph = beva_file.bem_readerGet_0();
bevt_2_ta_ph.bemd_0(-722852782);
bevt_3_ta_ph = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_ta_ph.bemd_0(1629976360);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_params.bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_initialArgsGet_0() throws Throwable {
return bevp_initialArgs;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_initialArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGet_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGet_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGet_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {113, 114, 115, 116, 117, 117, 124, 124, 124, 124, 124, 125, 125, 125, 129, 129, 130, 130, 131, 131, 132, 132, 136, 136, 136, 136, 140, 140, 140, 140, 144, 144, 145, 145, 146, 146, 0, 146, 146, 147, 147, 148, 148, 149, 149, 151, 151, 151, 157, 158, 159, 163, 163, 164, 164, 164, 165, 165, 165, 164, 168, 169, 170, 171, 0, 171, 171, 172, 173, 174, 175, 175, 175, 175, 176, 176, 176, 177, 177, 177, 177, 178, 178, 178, 179, 179, 179, 179, 180, 180, 180, 184, 184, 185, 185, 186, 188, 189, 190, 190, 190, 190, 0, 0, 0, 191, 191, 191, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 194, 194, 195, 195, 196, 196, 197, 197, 197, 198, 200, 200, 200, 200, 0, 0, 0, 201, 201, 201, 202, 203, 203, 203, 203, 0, 0, 0, 203, 203, 204, 210, 211, 211, 212, 212, 212, 212, 213, 213, 213, 212, 216, 216, 217, 217, 217, 217, 218, 218, 218, 217, 221, 221, 222, 223, 223, 224, 225, 226, 227, 0, 227, 227, 228, 228, 230, 231, 233, 238, 239, 239, 241, 244, 248, 248, 248, 252, 252, 256, 256, 260, 261, 261, 262, 263, 265, 269, 269, 273, 274, 274, 275, 277, 277, 281, 286, 287, 287, 288, 289, 291, 296, 296, 296, 297, 297, 298, 298, 299, 303, 303, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {28, 29, 30, 31, 32, 33, 45, 46, 47, 48, 49, 56, 57, 58, 66, 67, 68, 69, 70, 71, 72, 73, 80, 81, 82, 83, 90, 91, 92, 93, 109, 110, 111, 112, 113, 114, 114, 117, 119, 120, 121, 122, 127, 128, 129, 132, 133, 134, 144, 145, 146, 213, 218, 219, 222, 223, 225, 226, 227, 228, 235, 236, 237, 238, 238, 241, 243, 244, 245, 246, 247, 248, 249, 254, 255, 256, 257, 258, 259, 260, 265, 266, 267, 268, 269, 270, 271, 276, 277, 278, 279, 283, 288, 289, 294, 295, 297, 298, 301, 306, 307, 308, 310, 313, 317, 320, 321, 322, 325, 330, 331, 332, 334, 337, 341, 344, 345, 346, 347, 348, 349, 354, 355, 356, 357, 358, 359, 360, 364, 369, 370, 371, 373, 376, 380, 383, 384, 385, 386, 389, 394, 395, 396, 398, 401, 405, 407, 412, 413, 449, 450, 455, 456, 459, 460, 465, 466, 467, 468, 469, 476, 481, 482, 485, 486, 491, 492, 493, 494, 495, 502, 507, 508, 509, 512, 514, 515, 516, 517, 517, 520, 522, 523, 524, 530, 531, 537, 544, 545, 550, 551, 553, 558, 559, 560, 564, 565, 569, 570, 575, 576, 581, 582, 583, 585, 589, 590, 596, 597, 602, 603, 605, 606, 609, 615, 616, 621, 622, 623, 625, 635, 636, 637, 638, 639, 640, 641, 642, 647, 648, 651, 654, 658, 661, 665, 668, 672, 675, 679, 682, 686};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 113 28
new 0 113 28
assign 1 114 29
new 0 114 29
assign 1 115 30
new 0 115 30
assign 1 116 31
new 0 116 31
assign 1 117 32
new 0 117 32
assign 1 117 33
new 1 117 33
assign 1 124 45
new 0 124 45
assign 1 124 46
new 0 124 46
assign 1 124 47
new 0 124 47
assign 1 124 48
new 0 124 48
assign 1 124 49
from 6 124 49
assign 1 125 56
new 0 125 56
assign 1 125 57
marshall 1 125 57
return 1 125 58
assign 1 129 66
new 0 129 66
assign 1 129 67
unmarshall 1 129 67
assign 1 130 68
new 0 130 68
assign 1 130 69
get 1 130 69
assign 1 131 70
new 0 131 70
assign 1 131 71
get 1 131 71
assign 1 132 72
new 0 132 72
assign 1 132 73
get 1 132 73
assign 1 136 80
readerGet 0 136 80
assign 1 136 81
open 0 136 81
assign 1 136 82
readStringClose 0 136 82
fromJson 1 136 83
assign 1 140 90
writerGet 0 140 90
assign 1 140 91
open 0 140 91
assign 1 140 92
toJson 0 140 92
writeStringClose 1 140 93
assign 1 144 109
argsGet 0 144 109
addValue 1 144 110
assign 1 145 111
orderedGet 0 145 111
addValue 1 145 112
assign 1 146 113
paramsGet 0 146 113
assign 1 146 114
iteratorGet 0 0 114
assign 1 146 117
hasNextGet 0 146 117
assign 1 146 119
nextGet 0 146 119
assign 1 147 120
keyGet 0 147 120
assign 1 147 121
get 1 147 121
assign 1 148 122
def 1 148 127
assign 1 149 128
valueGet 0 149 128
addValue 1 149 129
assign 1 151 132
keyGet 0 151 132
assign 1 151 133
valueGet 0 151 133
put 2 151 134
new 0 157 144
assign 1 158 145
addArgs 1 159 146
assign 1 163 213
def 1 163 218
assign 1 164 219
new 0 164 219
assign 1 164 222
lengthGet 0 164 222
assign 1 164 223
lesser 1 164 223
assign 1 165 225
get 1 165 225
assign 1 165 226
process 1 165 226
put 2 165 227
assign 1 164 228
increment 0 164 228
assign 1 168 235
add 1 168 235
assign 1 169 236
assign 1 170 237
new 0 170 237
assign 1 171 238
iteratorGet 0 0 238
assign 1 171 241
hasNextGet 0 171 241
assign 1 171 243
nextGet 0 171 243
assign 1 172 244
assign 1 173 245
assign 1 174 246
assign 1 175 247
sizeGet 0 175 247
assign 1 175 248
new 0 175 248
assign 1 175 249
greater 1 175 254
assign 1 176 255
new 0 176 255
assign 1 176 256
new 0 176 256
assign 1 176 257
substring 2 176 257
assign 1 177 258
sizeGet 0 177 258
assign 1 177 259
new 0 177 259
assign 1 177 260
greater 1 177 265
assign 1 178 266
new 0 178 266
assign 1 178 267
new 0 178 267
assign 1 178 268
substring 2 178 268
assign 1 179 269
sizeGet 0 179 269
assign 1 179 270
new 0 179 270
assign 1 179 271
greater 1 179 276
assign 1 180 277
new 0 180 277
assign 1 180 278
new 0 180 278
assign 1 180 279
substring 2 180 279
assign 1 184 283
def 1 184 288
assign 1 185 289
not 0 185 294
addParameter 2 186 295
assign 1 188 297
assign 1 189 298
new 0 189 298
assign 1 190 301
def 1 190 306
assign 1 190 307
new 0 190 307
assign 1 190 308
equals 1 190 308
assign 1 0 310
assign 1 0 313
assign 1 0 317
assign 1 191 320
new 0 191 320
assign 1 191 321
sizeGet 0 191 321
assign 1 191 322
substring 2 191 322
assign 1 192 325
def 1 192 330
assign 1 192 331
new 0 192 331
assign 1 192 332
equals 1 192 332
assign 1 0 334
assign 1 0 337
assign 1 0 341
assign 1 193 344
new 0 193 344
assign 1 193 345
sizeGet 0 193 345
assign 1 193 346
substring 2 193 346
assign 1 194 347
new 0 194 347
assign 1 194 348
find 1 194 348
assign 1 195 349
def 1 195 354
assign 1 196 355
new 0 196 355
assign 1 196 356
substring 2 196 356
assign 1 197 357
new 0 197 357
assign 1 197 358
add 1 197 358
assign 1 197 359
substring 1 197 359
addParameter 2 198 360
assign 1 200 364
def 1 200 369
assign 1 200 370
new 0 200 370
assign 1 200 371
equals 1 200 371
assign 1 0 373
assign 1 0 376
assign 1 0 380
assign 1 201 383
new 0 201 383
assign 1 201 384
sizeGet 0 201 384
assign 1 201 385
substring 2 201 385
assign 1 202 386
new 0 202 386
assign 1 203 389
def 1 203 394
assign 1 203 395
new 0 203 395
assign 1 203 396
equals 1 203 396
assign 1 0 398
assign 1 0 401
assign 1 0 405
assign 1 203 407
not 0 203 412
addValue 1 204 413
assign 1 210 449
assign 1 211 450
def 1 211 455
assign 1 212 456
new 0 212 456
assign 1 212 459
lengthGet 0 212 459
assign 1 212 460
lesser 1 212 465
assign 1 213 466
get 1 213 466
assign 1 213 467
process 1 213 467
put 2 213 468
assign 1 212 469
increment 0 212 469
assign 1 216 476
def 1 216 481
assign 1 217 482
new 0 217 482
assign 1 217 485
lengthGet 0 217 485
assign 1 217 486
lesser 1 217 491
assign 1 218 492
get 1 218 492
assign 1 218 493
process 1 218 493
put 2 218 494
assign 1 217 495
increment 0 217 495
assign 1 221 502
def 1 221 507
assign 1 222 508
new 0 222 508
assign 1 223 509
keyIteratorGet 0 223 509
assign 1 223 512
hasNextGet 0 223 512
assign 1 224 514
nextGet 0 224 514
assign 1 225 515
get 1 225 515
assign 1 226 516
new 0 226 516
assign 1 227 517
linkedListIteratorGet 0 0 517
assign 1 227 520
hasNextGet 0 227 520
assign 1 227 522
nextGet 0 227 522
assign 1 228 523
process 1 228 523
addValue 1 228 524
assign 1 230 530
process 1 230 530
put 2 231 531
assign 1 233 537
assign 1 238 544
getFirst 1 238 544
assign 1 239 545
def 1 239 550
assign 1 241 551
new 1 241 551
return 1 244 553
assign 1 248 558
new 0 248 558
assign 1 248 559
isTrue 2 248 559
return 1 248 560
assign 1 252 564
has 1 252 564
return 1 252 565
assign 1 256 569
get 1 256 569
return 1 256 570
assign 1 260 575
get 1 260 575
assign 1 261 576
undef 1 261 581
assign 1 262 582
new 0 262 582
addValue 1 263 583
return 1 265 585
assign 1 269 589
getFirst 2 269 589
return 1 269 590
assign 1 273 596
get 1 273 596
assign 1 274 597
undef 1 274 602
return 1 275 603
assign 1 277 605
firstGet 0 277 605
return 1 277 606
addParam 2 281 609
assign 1 286 615
get 1 286 615
assign 1 287 616
undef 1 287 621
assign 1 288 622
new 0 288 622
put 2 289 623
addValue 1 291 625
assign 1 296 635
readerGet 0 296 635
assign 1 296 636
open 0 296 636
assign 1 296 637
readString 0 296 637
assign 1 297 638
readerGet 0 297 638
close 0 297 639
assign 1 298 640
tokenize 1 298 640
assign 1 298 641
toList 0 298 641
addArgs 1 299 642
assign 1 303 647
iteratorGet 0 303 647
return 1 303 648
return 1 0 651
assign 1 0 654
return 1 0 658
assign 1 0 661
return 1 0 665
assign 1 0 668
return 1 0 672
assign 1 0 675
return 1 0 679
assign 1 0 682
return 1 0 686
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1793966784: return bem_toJson_0();
case 668645503: return bem_new_0();
case -1878414935: return bem_initialArgsGet_0();
case 485739803: return bem_orderedGet_0();
case -329971324: return bem_paramsGet_0();
case -161809366: return bem_copy_0();
case -318437716: return bem_preProcessorGet_0();
case -508717313: return bem_create_0();
case 1401626610: return bem_print_0();
case 57557975: return bem_fileTokGet_0();
case 969005479: return bem_toString_0();
case -1877988678: return bem_hashGet_0();
case -1862765991: return bem_argsGet_0();
case 326916018: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 939305500: return bem_def_1(bevd_0);
case 1646027802: return bem_orderedSet_1(bevd_0);
case 157460336: return bem_fileTokSet_1(bevd_0);
case 422058995: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -821724364: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case 1670817152: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 317522033: return bem_fromJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case -894881001: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case 1919831451: return bem_argsSet_1(bevd_0);
case 1506806924: return bem_toJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case -1213546628: return bem_addArgs_1(bevd_0);
case -955550081: return bem_fromJson_1((BEC_2_4_6_TextString) bevd_0);
case 1351100239: return bem_initialArgsSet_1(bevd_0);
case -1581048634: return bem_copyTo_1(bevd_0);
case 384220308: return bem_notEquals_1(bevd_0);
case 445198680: return bem_paramsSet_1(bevd_0);
case 1379140839: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1391871629: return bem_undef_1(bevd_0);
case 1011661229: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case 567335501: return bem_equals_1(bevd_0);
case 1284665326: return bem_addValue_1((BEC_2_6_10_SystemParameters) bevd_0);
case 973547078: return bem_preProcessorSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 72722300: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 389973979: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 967575372: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2046340809: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2045439233: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 163536847: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1473641963: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1927785107: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1961786723: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemParameters();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
