package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_6_IOFileWriterStderr extends BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_6_IOFileWriterStderr() { }
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x53,0x74,0x64,0x65,0x72,0x72};
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_6_IOFileWriterStderr bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;

public static BET_4_2_4_6_6_IOFileWriterStderr bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_type;

public BEC_4_2_4_6_6_IOFileWriterStderr bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {690, 695, 695};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 23, 24};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 690 15
new 0 690 15
assign 1 695 23
new 0 695 23
return 1 695 24
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1222234212: return bem_once_0();
case 667228902: return bem_create_0();
case -631740911: return bem_toAny_0();
case -675749221: return bem_deserializeClassNameGet_0();
case 1532059915: return bem_hashGet_0();
case -372207069: return bem_echo_0();
case -2108905129: return bem_openAppend_0();
case -1434554234: return bem_serializeToString_0();
case 1208003411: return bem_pathGetDirect_0();
case 1675115881: return bem_vfileGetDirect_0();
case 903242673: return bem_serializeContents_0();
case -808119328: return bem_print_0();
case -181121720: return bem_new_0();
case 1731345338: return bem_tagGet_0();
case 68278359: return bem_default_0();
case 223536155: return bem_isClosedGetDirect_0();
case 686096526: return bem_extOpen_0();
case 66176814: return bem_close_0();
case 1905072488: return bem_isClosedGet_0();
case -1997158745: return bem_open_0();
case -809603074: return bem_openTruncate_0();
case 116064121: return bem_fieldIteratorGet_0();
case -48097544: return bem_pathGet_0();
case 201401408: return bem_iteratorGet_0();
case -2049877255: return bem_vfileGet_0();
case 1443369362: return bem_copy_0();
case 1497839510: return bem_classNameGet_0();
case 1437342193: return bem_many_0();
case 1365890250: return bem_serializationIteratorGet_0();
case -213179861: return bem_fieldNamesGet_0();
case 1218813014: return bem_sourceFileNameGet_0();
case 304904756: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -584784187: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 1388977817: return bem_pathSetDirect_1(bevd_0);
case -1883300982: return bem_defined_1(bevd_0);
case -1022294260: return bem_isClosedSet_1(bevd_0);
case 485277844: return bem_undef_1(bevd_0);
case 1053363366: return bem_isClosedSetDirect_1(bevd_0);
case 1485967678: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1112415428: return bem_otherClass_1(bevd_0);
case 1488188129: return bem_vfileSetDirect_1(bevd_0);
case 48512687: return bem_equals_1(bevd_0);
case -6903784: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 576196815: return bem_vfileSet_1(bevd_0);
case 1801074654: return bem_sameType_1(bevd_0);
case -1960916636: return bem_notEquals_1(bevd_0);
case -1464177031: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1186867352: return bem_sameClass_1(bevd_0);
case 1923378701: return bem_pathSet_1(bevd_0);
case -1045546721: return bem_sameObject_1(bevd_0);
case 381288505: return bem_def_1(bevd_0);
case -827042537: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case -1674224941: return bem_undefined_1(bevd_0);
case -1397213195: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1477350298: return bem_otherType_1(bevd_0);
case -71227052: return bem_copyTo_1(bevd_0);
case -1755663349: return bem_new_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2106641120: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 219701968: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 859481713: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1909968647: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -803774767: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -545558457: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 116867693: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_6_IOFileWriterStderr();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst = (BEC_4_2_4_6_6_IOFileWriterStderr) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_type;
}
}
