package be;
/* IO:File: source/extended/FileReadWrite.be */
public final class BEC_4_2_4_6_6_IOFileWriterStderr extends BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_6_IOFileWriterStderr() { }
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x53,0x74,0x64,0x65,0x72,0x72};
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_4_2_4_6_6_IOFileWriterStderr bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;

public static BET_4_2_4_6_6_IOFileWriterStderr bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_type;

public BEC_4_2_4_6_6_IOFileWriterStderr bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_default_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_close_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {714, 719, 719};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 23, 24};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 714 15
new 0 714 15
assign 1 719 23
new 0 719 23
return 1 719 24
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1753282001: return bem_pathGetDirect_0();
case -568575955: return bem_hashGet_0();
case -1350802630: return bem_default_0();
case -220602072: return bem_echo_0();
case 774721401: return bem_serializeToString_0();
case 881754957: return bem_deserializeClassNameGet_0();
case -674491561: return bem_sourceFileNameGet_0();
case -829315536: return bem_classNameGet_0();
case -1111250456: return bem_fieldNamesGet_0();
case -649488434: return bem_openTruncate_0();
case 234248288: return bem_copy_0();
case -437991849: return bem_toString_0();
case -763928014: return bem_create_0();
case -419834598: return bem_print_0();
case -1094245586: return bem_isClosedGet_0();
case 533948793: return bem_openAppend_0();
case -1814783732: return bem_serializationIteratorGet_0();
case -1784606128: return bem_pathGet_0();
case -18123974: return bem_new_0();
case 1087832621: return bem_tagGet_0();
case 2087607686: return bem_iteratorGet_0();
case -707996503: return bem_extOpen_0();
case 1126911928: return bem_serializeContents_0();
case -7735265: return bem_vfileGet_0();
case 514808405: return bem_open_0();
case 1554579989: return bem_isClosedGetDirect_0();
case -1454950260: return bem_fieldIteratorGet_0();
case -35739564: return bem_close_0();
case 1232367928: return bem_vfileGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -643713889: return bem_notEquals_1(bevd_0);
case -26112674: return bem_new_1(bevd_0);
case -1008682565: return bem_vfileSetDirect_1(bevd_0);
case 1716537031: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 13552187: return bem_otherType_1(bevd_0);
case 703321547: return bem_pathSet_1(bevd_0);
case 574822957: return bem_sameType_1(bevd_0);
case 1644346432: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case 1650838819: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1126785813: return bem_sameObject_1(bevd_0);
case -1060096198: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 1067712071: return bem_vfileSet_1(bevd_0);
case 523851963: return bem_undef_1(bevd_0);
case -1669644461: return bem_pathSetDirect_1(bevd_0);
case -2119212607: return bem_sameClass_1(bevd_0);
case 159047407: return bem_copyTo_1(bevd_0);
case -1342097074: return bem_def_1(bevd_0);
case 1464266195: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1235728790: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -229960022: return bem_equals_1(bevd_0);
case -1257350534: return bem_otherClass_1(bevd_0);
case 1860470681: return bem_isClosedSet_1(bevd_0);
case -1550634713: return bem_isClosedSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 79740554: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -191675663: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1336666114: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -158335944: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1790737002: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_2_4_6_6_IOFileWriterStderr();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst = (BEC_4_2_4_6_6_IOFileWriterStderr) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_type;
}
}
