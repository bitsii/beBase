package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_20_SystemStartupWithArguments extends BEC_2_6_6_SystemObject {
public BEC_2_6_20_SystemStartupWithArguments() { }
private static byte[] becc_BEC_2_6_20_SystemStartupWithArguments_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x41,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_6_20_SystemStartupWithArguments_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_20_SystemStartupWithArguments_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_20_SystemStartupWithArguments_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x4C,0x69,0x73,0x74,0x20,0x61,0x72,0x67,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_6_20_SystemStartupWithArguments_bevo_1 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_6_20_SystemStartupWithArguments bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_20_SystemStartupWithArguments bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_20_SystemStartupWithArguments bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_2_tmpany_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_6_20_SystemStartupWithArguments_bevo_0;
if (bevt_2_tmpany_phold.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(145, bece_BEC_2_6_20_SystemStartupWithArguments_bels_0));
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 73 */
bevt_8_tmpany_phold = bece_BEC_2_6_20_SystemStartupWithArguments_bevo_1;
bevt_7_tmpany_phold = bevp_args.bem_get_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_tmpany_phold );
bevl_x = bevt_6_tmpany_phold.bemd_0(-124916815);
bevt_9_tmpany_phold = bevl_x.bemd_1(-1416642241, bevp_args);
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_20_SystemStartupWithArguments bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {71, 71, 72, 72, 72, 72, 73, 73, 73, 75, 75, 75, 75, 76, 76, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 31, 32, 33, 34, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 52, 55};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 71 30
new 0 71 30
assign 1 71 31
argsGet 0 71 31
assign 1 72 32
sizeGet 0 72 32
assign 1 72 33
new 0 72 33
assign 1 72 34
lesser 1 72 39
assign 1 73 40
new 0 73 40
assign 1 73 41
new 1 73 41
throw 1 73 42
assign 1 75 44
new 0 75 44
assign 1 75 45
get 1 75 45
assign 1 75 46
createInstance 1 75 46
assign 1 75 47
new 0 75 47
assign 1 76 48
main 1 76 48
return 1 76 49
return 1 0 52
assign 1 0 55
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -149632320: return bem_toAny_0();
case -93701646: return bem_fieldIteratorGet_0();
case -748319096: return bem_print_0();
case -29400896: return bem_create_0();
case -1052800757: return bem_echo_0();
case -801589503: return bem_tagGet_0();
case -794227383: return bem_copy_0();
case 861710738: return bem_many_0();
case -7634332: return bem_classNameGet_0();
case 1243909045: return bem_argsGet_0();
case 900978335: return bem_serializeToString_0();
case 313469553: return bem_default_0();
case 1338975369: return bem_sourceFileNameGet_0();
case -14402816: return bem_serializeContents_0();
case -1674098047: return bem_once_0();
case 1684316154: return bem_main_0();
case -1701242685: return bem_serializationIteratorGet_0();
case -258597009: return bem_hashGet_0();
case -51803385: return bem_toString_0();
case -124916815: return bem_new_0();
case -1749103224: return bem_iteratorGet_0();
case -467186719: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 642489795: return bem_otherType_1(bevd_0);
case 760131355: return bem_argsSet_1(bevd_0);
case 1518481031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 550176080: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -983540661: return bem_undefined_1(bevd_0);
case -2092712540: return bem_def_1(bevd_0);
case 2036979549: return bem_notEquals_1(bevd_0);
case -1474467614: return bem_sameObject_1(bevd_0);
case -218714893: return bem_otherClass_1(bevd_0);
case 1970850163: return bem_sameType_1(bevd_0);
case -93273669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -20159434: return bem_sameClass_1(bevd_0);
case 616348580: return bem_undef_1(bevd_0);
case -271716565: return bem_copyTo_1(bevd_0);
case 226940097: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1391202250: return bem_defined_1(bevd_0);
case -73997568: return bem_equals_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case -66460559: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1367679335: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1031466779: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2131321099: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 292502272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2093180987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -323049121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_6_20_SystemStartupWithArguments_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_20_SystemStartupWithArguments_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_20_SystemStartupWithArguments();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst = (BEC_2_6_20_SystemStartupWithArguments) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst;
}
}
