package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_20_SystemStartupWithArguments extends BEC_2_6_6_SystemObject {
public BEC_2_6_20_SystemStartupWithArguments() { }
private static byte[] becc_BEC_2_6_20_SystemStartupWithArguments_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x57,0x69,0x74,0x68,0x41,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_6_20_SystemStartupWithArguments_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_20_SystemStartupWithArguments_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_20_SystemStartupWithArguments_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x4C,0x69,0x73,0x74,0x20,0x61,0x72,0x67,0x73,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_6_20_SystemStartupWithArguments_bevo_1 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_6_20_SystemStartupWithArguments bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst;

public static BET_2_6_20_SystemStartupWithArguments bece_BEC_2_6_20_SystemStartupWithArguments_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_20_SystemStartupWithArguments bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_20_SystemStartupWithArguments bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_2_tmpany_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_6_20_SystemStartupWithArguments_bevo_0;
if (bevt_2_tmpany_phold.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 71 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(145, bece_BEC_2_6_20_SystemStartupWithArguments_bels_0));
bevt_4_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 72 */
bevt_8_tmpany_phold = bece_BEC_2_6_20_SystemStartupWithArguments_bevo_1;
bevt_7_tmpany_phold = bevp_args.bem_get_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_tmpany_phold );
bevl_x = bevt_6_tmpany_phold.bemd_0(-410783155);
bevt_9_tmpany_phold = bevl_x.bemd_1(1170651075, bevp_args);
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_20_SystemStartupWithArguments bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_20_SystemStartupWithArguments bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {70, 70, 71, 71, 71, 71, 72, 72, 72, 74, 74, 74, 74, 75, 75, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 35, 36, 37, 42, 43, 44, 45, 47, 48, 49, 50, 51, 52, 55, 58, 61, 65};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 70 33
new 0 70 33
assign 1 70 34
argsGet 0 70 34
assign 1 71 35
sizeGet 0 71 35
assign 1 71 36
new 0 71 36
assign 1 71 37
lesser 1 71 42
assign 1 72 43
new 0 72 43
assign 1 72 44
new 1 72 44
throw 1 72 45
assign 1 74 47
new 0 74 47
assign 1 74 48
get 1 74 48
assign 1 74 49
createInstance 1 74 49
assign 1 74 50
new 0 74 50
assign 1 75 51
main 1 75 51
return 1 75 52
return 1 0 55
return 1 0 58
assign 1 0 61
assign 1 0 65
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 322973431: return bem_print_0();
case 2050059376: return bem_iteratorGet_0();
case -43502949: return bem_toAny_0();
case 1851036145: return bem_serializationIteratorGet_0();
case 929987777: return bem_argsGet_0();
case -304415890: return bem_classNameGet_0();
case 625547167: return bem_toString_0();
case 305613993: return bem_sourceFileNameGet_0();
case -1120168384: return bem_argsGetDirect_0();
case -1087766017: return bem_serializeToString_0();
case -410783155: return bem_new_0();
case -545885409: return bem_fieldNamesGet_0();
case -1569222986: return bem_fieldIteratorGet_0();
case -2139486839: return bem_main_0();
case 364235321: return bem_echo_0();
case 291309239: return bem_once_0();
case -753644705: return bem_hashGet_0();
case 1461724031: return bem_copy_0();
case -417135958: return bem_default_0();
case -381740729: return bem_deserializeClassNameGet_0();
case -909675958: return bem_create_0();
case -1101326644: return bem_serializeContents_0();
case 597357534: return bem_tagGet_0();
case 678571136: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case -276244091: return bem_argsSet_1(bevd_0);
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
case 1958628559: return bem_argsSetDirect_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_6_20_SystemStartupWithArguments_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_20_SystemStartupWithArguments_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_20_SystemStartupWithArguments();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst = (BEC_2_6_20_SystemStartupWithArguments) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_20_SystemStartupWithArguments.bece_BEC_2_6_20_SystemStartupWithArguments_bevs_type;
}
}
