package be;
/* IO:File: source/base/Exceptions.be */
public final class BEC_2_6_13_SystemIncorrectType extends BEC_2_6_9_SystemException {
public BEC_2_6_13_SystemIncorrectType() { }
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x54,0x79,0x70,0x65};
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static BEC_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;

public static BET_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_type;

public BEC_2_6_13_SystemIncorrectType bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {144};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 144 12
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -432721106: return bem_methodNameGet_0();
case -1076289587: return bem_framesTextGet_0();
case -1785051917: return bem_lineNumberGet_0();
case 1271737474: return bem_klassNameGet_0();
case 1734159100: return bem_new_0();
case 1072084912: return bem_langGet_0();
case -1492973205: return bem_print_0();
case -579745913: return bem_emitLangGet_0();
case -1868791417: return bem_create_0();
case -1378154513: return bem_copy_0();
case -1148970439: return bem_fileNameGet_0();
case 1524127055: return bem_vvGet_0();
case -341701962: return bem_iteratorGet_0();
case 1594913180: return bem_framesGet_0();
case -931159963: return bem_getFrameText_0();
case 1394706579: return bem_hashGet_0();
case -1251189415: return bem_toString_0();
case -1952092196: return bem_translatedGet_0();
case -2095074133: return bem_descriptionGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -473940483: return bem_framesTextSet_1(bevd_0);
case -565750754: return bem_descriptionSet_1(bevd_0);
case 212925280: return bem_print_1(bevd_0);
case -1504859590: return bem_copyTo_1(bevd_0);
case -2008963967: return bem_klassNameSet_1(bevd_0);
case 224732862: return bem_notEquals_1(bevd_0);
case -720822093: return bem_lineNumberSet_1(bevd_0);
case 764483733: return bem_equals_1(bevd_0);
case -1731276133: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -862259670: return bem_translatedSet_1(bevd_0);
case 404631763: return bem_undef_1(bevd_0);
case -970799404: return bem_methodNameSet_1(bevd_0);
case 405438663: return bem_fileNameSet_1(bevd_0);
case 145046447: return bem_vvSet_1(bevd_0);
case -2106560570: return bem_langSet_1(bevd_0);
case -589620627: return bem_new_1(bevd_0);
case -41647352: return bem_def_1(bevd_0);
case -1465446038: return bem_emitLangSet_1(bevd_0);
case -1103683937: return bem_framesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 717909815: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1423582782: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -418624509: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -861820000: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1747758835: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_13_SystemIncorrectType_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_13_SystemIncorrectType_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_13_SystemIncorrectType();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst = (BEC_2_6_13_SystemIncorrectType) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_type;
}
}
