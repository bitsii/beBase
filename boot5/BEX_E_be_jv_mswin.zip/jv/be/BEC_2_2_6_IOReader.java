package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOReader() { }

    public java.io.InputStream bevi_is;
   private static byte[] becc_BEC_2_2_6_IOReader_clname = {0x49,0x4F,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_inst;

public static BET_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_type;

public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_3_MathInt bevp_blockSize;
public BEC_2_2_6_IOReader bem_new_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolTrue;
bevp_blockSize = (new BEC_2_4_3_MathInt(256));
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_extOpen_0() throws Throwable {
bevp_isClosed = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_close_0() throws Throwable {

      if (this.bevi_is != null) {
        this.bevi_is.close();
        this.bevi_is = null;
      }
      bevp_isClosed = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_vfileGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) throws Throwable {
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReaderGet_0() throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_2_10_IOByteReader()).bem_readerNew_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_byteReader_1(BEC_2_4_3_MathInt beva_blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_2_10_IOByteReader()).bem_readerBlockNew_2(this, beva_blockSize);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_1(BEC_2_4_6_TextString beva_readBuf) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_readIntoBuffer_2(beva_readBuf, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_2(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_readIntoBuffer_3(beva_readBuf, beva_at, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_readIntoBuffer_3(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at, BEC_2_4_3_MathInt beva_readsz) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;

      int bevls_read = this.bevi_is.read(beva_readBuf.bevi_bytes, beva_at.bevi_int, beva_readBuf.bevi_bytes.length - beva_at.bevi_int);
      if (bevls_read < 0) {
        bevls_read = 0;
      }
      beva_readsz.bevi_int = bevls_read + beva_at.bevi_int;
      bevt_0_ta_ph = beva_readBuf.bem_sizeGet_0();
bevt_0_ta_ph.bevi_int = beva_readsz.bevi_int;
return beva_readsz;
} /*method end*/
public BEC_2_2_6_IOReader bem_copyData_3(BEC_2_2_6_IOWriter beva_outw, BEC_2_4_6_TextString beva_rwbufE, BEC_2_4_3_MathInt beva_rsz) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_at = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 298*/ {
bevt_1_ta_ph = bem_readIntoBuffer_3(beva_rwbufE, bevl_at, beva_rsz);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_1_ta_ph.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 298*/ {
beva_outw.bem_write_1(beva_rwbufE);
} /* Line: 299*/
 else /* Line: 298*/ {
break;
} /* Line: 298*/
} /* Line: 298*/
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_copyData_1(BEC_2_2_6_IOWriter beva_outw) throws Throwable {
BEC_2_4_6_TextString bevl_rwbufE = null;
BEC_2_4_3_MathInt bevl_rsz = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(4096));
bevl_rwbufE = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_rsz = (new BEC_2_4_3_MathInt());
bem_copyData_3(beva_outw, bevl_rwbufE, bevl_rsz);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevt_0_ta_ph = bem_readBuffer_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_at = (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (new BEC_2_4_3_MathInt());
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
while (true)
/* Line: 317*/ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 317*/ {
bevl_at.bevi_int = bevl_nowAt.bevi_int;
bevt_3_ta_ph = beva_builder.bem_capacityGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_subtract_1(bevl_at);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevt_2_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 319*/ {
bevt_7_ta_ph = bevl_at.bem_add_1(bevp_blockSize);
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(16));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_5_ta_ph = bevt_6_ta_ph.bem_multiply_1(bevt_9_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_nsize = bevt_5_ta_ph.bem_divide_1(bevt_10_ta_ph);
beva_builder.bem_capacitySet_1(bevl_nsize);
} /* Line: 321*/
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
} /* Line: 323*/
 else /* Line: 317*/ {
break;
} /* Line: 317*/
} /* Line: 317*/
return beva_builder;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readDiscard_0() throws Throwable {
BEC_2_4_6_TextString bevl_builder = null;
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevl_builder = (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevl_at = (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (new BEC_2_4_3_MathInt());
bem_readIntoBuffer_3(bevl_builder, bevl_at, bevl_nowAt);
while (true)
/* Line: 333*/ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_nowAt.bevi_int = bevt_1_ta_ph.bevi_int;
bem_readIntoBuffer_3(bevl_builder, bevl_at, bevl_nowAt);
} /* Line: 335*/
 else /* Line: 333*/ {
break;
} /* Line: 333*/
} /* Line: 333*/
return bevl_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = bem_readBufferLine_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferLine_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevl_crb = null;
BEC_2_4_6_TextString bevl_rbuf = null;
BEC_2_4_3_MathInt bevl_got = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_newlineGet_0();
bevl_crb = bevt_0_ta_ph.bem_addValue_1(bevt_1_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_rbuf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_3_ta_ph);
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_got.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 351*/ {
beva_builder = null;
return beva_builder;
} /* Line: 353*/
beva_builder.bem_addValue_1(bevl_rbuf);
while (true)
/* Line: 356*/ {
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_got.bevi_int != bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_8_ta_ph = bevl_rbuf.bem_equals_1(bevl_crb);
if (bevt_8_ta_ph.bevi_bool)/* Line: 357*/ {
return beva_builder;
} /* Line: 358*/
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
beva_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 361*/
 else /* Line: 356*/ {
break;
} /* Line: 356*/
} /* Line: 356*/
return beva_builder;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_readBuffer_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_1(BEC_2_4_6_TextString beva_builder) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_readBuffer_1(beva_builder);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_readStringClose_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = bem_readString_0();
bem_close_0();
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_readDiscardClose_0() throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (BEC_2_4_6_TextString) bem_readDiscard_0();
bem_close_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGet_0() throws Throwable {
return bevp_isClosed;
} /*method end*/
public BEC_2_2_6_IOReader bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_blockSizeGet_0() throws Throwable {
return bevp_blockSize;
} /*method end*/
public BEC_2_2_6_IOReader bem_blockSizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {179, 180, 186, 230, 238, 238, 242, 242, 246, 246, 246, 250, 250, 250, 292, 292, 293, 297, 298, 298, 298, 298, 299, 304, 304, 305, 306, 310, 310, 310, 314, 315, 316, 317, 317, 318, 319, 319, 319, 319, 319, 320, 320, 320, 320, 320, 320, 320, 321, 323, 325, 329, 330, 331, 332, 333, 333, 334, 334, 335, 337, 341, 341, 341, 348, 348, 348, 348, 349, 349, 350, 351, 351, 351, 352, 353, 355, 356, 356, 356, 357, 358, 360, 361, 363, 367, 367, 371, 371, 375, 376, 377, 381, 382, 383, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 22, 31, 42, 43, 47, 48, 53, 54, 55, 60, 61, 62, 72, 73, 74, 81, 84, 85, 86, 91, 92, 104, 105, 106, 107, 113, 114, 115, 132, 133, 134, 137, 142, 143, 144, 145, 146, 147, 152, 153, 154, 155, 156, 157, 158, 159, 160, 162, 168, 176, 177, 178, 179, 182, 187, 188, 189, 190, 196, 201, 202, 203, 218, 219, 220, 221, 222, 223, 224, 225, 226, 231, 232, 233, 235, 238, 239, 244, 245, 247, 249, 250, 256, 260, 261, 265, 266, 270, 271, 272, 276, 277, 278, 281, 284, 288, 291};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 179 17
new 0 179 17
assign 1 180 18
new 0 180 18
assign 1 186 22
new 0 186 22
assign 1 230 31
new 0 230 31
assign 1 238 42
readerNew 1 238 42
return 1 238 43
assign 1 242 47
readerBlockNew 2 242 47
return 1 242 48
assign 1 246 53
new 0 246 53
assign 1 246 54
readIntoBuffer 2 246 54
return 1 246 55
assign 1 250 60
new 0 250 60
assign 1 250 61
readIntoBuffer 3 250 61
return 1 250 62
assign 1 292 72
sizeGet 0 292 72
setValue 1 292 73
return 1 293 74
assign 1 297 81
new 0 297 81
assign 1 298 84
readIntoBuffer 3 298 84
assign 1 298 85
new 0 298 85
assign 1 298 86
greater 1 298 91
write 1 299 92
assign 1 304 104
new 0 304 104
assign 1 304 105
new 1 304 105
assign 1 305 106
new 0 305 106
copyData 3 306 107
assign 1 310 113
new 1 310 113
assign 1 310 114
readBuffer 1 310 114
return 1 310 115
assign 1 314 132
new 0 314 132
assign 1 315 133
new 0 315 133
readIntoBuffer 3 316 134
assign 1 317 137
greater 1 317 142
setValue 1 318 143
assign 1 319 144
capacityGet 0 319 144
assign 1 319 145
subtract 1 319 145
assign 1 319 146
new 0 319 146
assign 1 319 147
lesser 1 319 152
assign 1 320 153
add 1 320 153
assign 1 320 154
new 0 320 154
assign 1 320 155
add 1 320 155
assign 1 320 156
new 0 320 156
assign 1 320 157
multiply 1 320 157
assign 1 320 158
new 0 320 158
assign 1 320 159
divide 1 320 159
capacitySet 1 321 160
readIntoBuffer 3 323 162
return 1 325 168
assign 1 329 176
new 1 329 176
assign 1 330 177
new 0 330 177
assign 1 331 178
new 0 331 178
readIntoBuffer 3 332 179
assign 1 333 182
greater 1 333 187
assign 1 334 188
new 0 334 188
setValue 1 334 189
readIntoBuffer 3 335 190
return 1 337 196
assign 1 341 201
new 0 341 201
assign 1 341 202
readBufferLine 1 341 202
return 1 341 203
assign 1 348 218
new 0 348 218
assign 1 348 219
new 0 348 219
assign 1 348 220
newlineGet 0 348 220
assign 1 348 221
addValue 1 348 221
assign 1 349 222
new 0 349 222
assign 1 349 223
new 1 349 223
assign 1 350 224
readIntoBuffer 1 350 224
assign 1 351 225
new 0 351 225
assign 1 351 226
equals 1 351 231
assign 1 352 232
return 1 353 233
addValue 1 355 235
assign 1 356 238
new 0 356 238
assign 1 356 239
notEquals 1 356 244
assign 1 357 245
equals 1 357 245
return 1 358 247
assign 1 360 249
readIntoBuffer 1 360 249
addValue 1 361 250
return 1 363 256
assign 1 367 260
readBuffer 0 367 260
return 1 367 261
assign 1 371 265
readBuffer 1 371 265
return 1 371 266
assign 1 375 270
readString 0 375 270
close 0 376 271
return 1 377 272
assign 1 381 276
readDiscard 0 381 276
close 0 382 277
return 1 383 278
return 1 0 281
assign 1 0 284
return 1 0 288
assign 1 0 291
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1514929155: return bem_blockSizeGet_0();
case -352709573: return bem_readStringClose_0();
case -1877988678: return bem_hashGet_0();
case 969005479: return bem_toString_0();
case 606643687: return bem_readDiscard_0();
case 428366797: return bem_readString_0();
case -508717313: return bem_create_0();
case 1401626610: return bem_print_0();
case 326916018: return bem_iteratorGet_0();
case -161809366: return bem_copy_0();
case -1441147321: return bem_readBuffer_0();
case 403839243: return bem_extOpen_0();
case 668645503: return bem_new_0();
case 899547968: return bem_byteReaderGet_0();
case 657937474: return bem_isClosedGet_0();
case 548726965: return bem_readBufferLine_0();
case 1760492203: return bem_vfileGet_0();
case -1774106827: return bem_readDiscardClose_0();
case -722852782: return bem_close_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 705107605: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -754310410: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1697627164: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 384220308: return bem_notEquals_1(bevd_0);
case -1581048634: return bem_copyTo_1(bevd_0);
case 939305500: return bem_def_1(bevd_0);
case 1118603808: return bem_blockSizeSet_1(bevd_0);
case -1391871629: return bem_undef_1(bevd_0);
case 242534406: return bem_isClosedSet_1(bevd_0);
case 1169595167: return bem_vfileSet_1(bevd_0);
case 567335501: return bem_equals_1(bevd_0);
case -1456748338: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1316777692: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -1096659726: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 163536847: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 72722300: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1867222460: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1961786723: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2046340809: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1410604514: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1535433982: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_6_IOReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst = (BEC_2_2_6_IOReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_type;
}
}
