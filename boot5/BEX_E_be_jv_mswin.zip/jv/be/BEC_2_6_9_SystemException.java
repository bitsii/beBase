package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x54,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x6F,0x72};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x0A};
public static BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
/* Line: 54*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_1_ta_ph = bem_createInstance_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1564435804);
bevt_0_ta_ph.bemd_1(1002965126, this);
} /* Line: 55*/
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_1));
if (bevp_description == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_5_ta_ph);
bevl_toRet = bevt_4_ta_ph.bemd_1(-989002532, bevp_description);
} /* Line: 61*/
if (bevp_fileName == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 63*/ {
bevt_8_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_8_ta_ph);
bevl_toRet = bevt_7_ta_ph.bemd_1(-989002532, bevp_fileName);
} /* Line: 64*/
if (bevp_lineNumber == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 66*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_10_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_lineNumber.bemd_0(-1318471451);
bevl_toRet = bevt_10_ta_ph.bemd_1(-989002532, bevt_12_ta_ph);
} /* Line: 67*/
if (bevp_lang == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 69*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_15_ta_ph);
bevl_toRet = bevt_14_ta_ph.bemd_1(-989002532, bevp_lang);
} /* Line: 70*/
if (bevp_emitLang == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_18_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_18_ta_ph);
bevl_toRet = bevt_17_ta_ph.bemd_1(-989002532, bevp_emitLang);
} /* Line: 73*/
if (bevp_methodName == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 75*/ {
bevt_21_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_21_ta_ph);
bevl_toRet = bevt_20_ta_ph.bemd_1(-989002532, bevp_methodName);
} /* Line: 76*/
if (bevp_klassName == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 78*/ {
bevt_24_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_24_ta_ph);
bevl_toRet = bevt_23_ta_ph.bemd_1(-989002532, bevp_klassName);
} /* Line: 79*/
if (bevp_framesText == null) {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 81*/ {
bevt_27_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_9));
bevt_26_ta_ph = bevl_toRet.bemd_1(-989002532, bevt_27_ta_ph);
bevl_toRet = bevt_26_ta_ph.bemd_1(-989002532, bevp_framesText);
} /* Line: 82*/
if (bevp_frames == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 84*/ {
bevt_29_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(-989002532, bevt_29_ta_ph);
} /* Line: 85*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
/* Line: 93*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_1_ta_ph = bem_createInstance_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1564435804);
bevt_0_ta_ph.bemd_1(1002965126, this);
} /* Line: 94*/
if (bevp_vv.bevi_bool)/* Line: 96*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_9_SystemException_bels_10));
bevt_3_ta_ph.bem_print_0();
} /* Line: 97*/
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
/* Line: 104*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_2_ta_ph = bem_createInstance_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1564435804);
bevt_1_ta_ph.bemd_1(1002965126, this);
} /* Line: 105*/
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 109*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_11));
bevl_toRet = bevl_toRet.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
/* Line: 111*/ {
bevt_6_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 111*/ {
bevl_ft = bevt_0_ta_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 112*/
 else /* Line: 111*/ {
break;
} /* Line: 111*/
} /* Line: 111*/
} /* Line: 111*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_frames == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 123*/ {
bevp_frames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 124*/
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_methodNameGetDirect_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_klassNameGetDirect_0() throws Throwable {
return bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_descriptionGetDirect_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_description = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_descriptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_description = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_fileNameGetDirect_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_lineNumberGetDirect_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lineNumber = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_lineNumberSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lineNumber = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public final BEC_2_4_6_TextString bem_langGetDirect_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_langSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public final BEC_2_4_6_TextString bem_emitLangGetDirect_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_emitLangSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_10_ContainerLinkedList bem_framesGetDirect_0() throws Throwable {
return bevp_frames;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_framesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public final BEC_2_4_6_TextString bem_framesTextGetDirect_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_framesTextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_translatedGetDirect_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_translatedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_vvGetDirect_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_6_9_SystemException bem_vvSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {47, 50, 55, 55, 55, 55, 59, 60, 60, 61, 61, 61, 63, 63, 64, 64, 64, 66, 66, 67, 67, 67, 67, 69, 69, 70, 70, 70, 72, 72, 73, 73, 73, 75, 75, 76, 76, 76, 78, 78, 79, 79, 79, 81, 81, 82, 82, 82, 84, 84, 85, 85, 87, 94, 94, 94, 94, 97, 97, 100, 105, 105, 105, 105, 107, 108, 109, 109, 110, 110, 111, 0, 111, 111, 112, 115, 119, 123, 123, 124, 126, 130, 130, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {35, 36, 72, 73, 74, 75, 77, 78, 83, 84, 85, 86, 88, 93, 94, 95, 96, 98, 103, 104, 105, 106, 107, 109, 114, 115, 116, 117, 119, 124, 125, 126, 127, 129, 134, 135, 136, 137, 139, 144, 145, 146, 147, 149, 154, 155, 156, 157, 159, 164, 165, 166, 168, 176, 177, 178, 179, 182, 183, 185, 199, 200, 201, 202, 204, 205, 206, 211, 212, 213, 214, 214, 217, 219, 220, 227, 230, 234, 239, 240, 242, 247, 248, 252, 255, 258, 262, 266, 269, 273, 277, 280, 283, 287, 291, 294, 297, 301, 305, 308, 311, 315, 319, 322, 325, 329, 333, 336, 339, 343, 347, 350, 354, 358, 361, 364, 368, 372, 375, 378, 382, 386, 389, 392, 396};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 47 35
new 0 47 35
assign 1 50 36
assign 1 55 72
new 0 55 72
assign 1 55 73
createInstance 1 55 73
assign 1 55 74
new 0 55 74
translateEmittedException 1 55 75
assign 1 59 77
new 0 59 77
assign 1 60 78
def 1 60 83
assign 1 61 84
new 0 61 84
assign 1 61 85
add 1 61 85
assign 1 61 86
add 1 61 86
assign 1 63 88
def 1 63 93
assign 1 64 94
new 0 64 94
assign 1 64 95
add 1 64 95
assign 1 64 96
add 1 64 96
assign 1 66 98
def 1 66 103
assign 1 67 104
new 0 67 104
assign 1 67 105
add 1 67 105
assign 1 67 106
toString 0 67 106
assign 1 67 107
add 1 67 107
assign 1 69 109
def 1 69 114
assign 1 70 115
new 0 70 115
assign 1 70 116
add 1 70 116
assign 1 70 117
add 1 70 117
assign 1 72 119
def 1 72 124
assign 1 73 125
new 0 73 125
assign 1 73 126
add 1 73 126
assign 1 73 127
add 1 73 127
assign 1 75 129
def 1 75 134
assign 1 76 135
new 0 76 135
assign 1 76 136
add 1 76 136
assign 1 76 137
add 1 76 137
assign 1 78 139
def 1 78 144
assign 1 79 145
new 0 79 145
assign 1 79 146
add 1 79 146
assign 1 79 147
add 1 79 147
assign 1 81 149
def 1 81 154
assign 1 82 155
new 0 82 155
assign 1 82 156
add 1 82 156
assign 1 82 157
add 1 82 157
assign 1 84 159
def 1 84 164
assign 1 85 165
getFrameText 0 85 165
assign 1 85 166
add 1 85 166
return 1 87 168
assign 1 94 176
new 0 94 176
assign 1 94 177
createInstance 1 94 177
assign 1 94 178
new 0 94 178
translateEmittedException 1 94 179
assign 1 97 182
new 0 97 182
print 0 97 183
return 1 100 185
assign 1 105 199
new 0 105 199
assign 1 105 200
createInstance 1 105 200
assign 1 105 201
new 0 105 201
translateEmittedException 1 105 202
assign 1 107 204
new 0 107 204
assign 1 108 205
framesGet 0 108 205
assign 1 109 206
def 1 109 211
assign 1 110 212
new 0 110 212
assign 1 110 213
add 1 110 213
assign 1 111 214
linkedListIteratorGet 0 0 214
assign 1 111 217
hasNextGet 0 111 217
assign 1 111 219
nextGet 0 111 219
assign 1 112 220
add 1 112 220
return 1 115 227
return 1 119 230
assign 1 123 234
undef 1 123 239
assign 1 124 240
new 0 124 240
addValue 1 126 242
assign 1 130 247
new 4 130 247
addFrame 1 130 248
return 1 0 252
return 1 0 255
assign 1 0 258
assign 1 0 262
return 1 0 266
assign 1 0 269
assign 1 0 273
return 1 0 277
return 1 0 280
assign 1 0 283
assign 1 0 287
return 1 0 291
return 1 0 294
assign 1 0 297
assign 1 0 301
return 1 0 305
return 1 0 308
assign 1 0 311
assign 1 0 315
return 1 0 319
return 1 0 322
assign 1 0 325
assign 1 0 329
return 1 0 333
return 1 0 336
assign 1 0 339
assign 1 0 343
return 1 0 347
assign 1 0 350
assign 1 0 354
return 1 0 358
return 1 0 361
assign 1 0 364
assign 1 0 368
return 1 0 372
return 1 0 375
assign 1 0 378
assign 1 0 382
return 1 0 386
return 1 0 389
assign 1 0 392
assign 1 0 396
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1993389394: return bem_descriptionGetDirect_0();
case 263412489: return bem_langGet_0();
case 490867390: return bem_fileNameGetDirect_0();
case 487655943: return bem_hashGet_0();
case 944526315: return bem_methodNameGet_0();
case -737828887: return bem_serializeContents_0();
case 1177953347: return bem_fieldNamesGet_0();
case -1318471451: return bem_toString_0();
case -1855517910: return bem_lineNumberGet_0();
case 1620426785: return bem_fieldIteratorGet_0();
case -281290652: return bem_lineNumberGetDirect_0();
case 678941566: return bem_vvGet_0();
case 461679840: return bem_framesTextGet_0();
case -1285558050: return bem_klassNameGetDirect_0();
case 1415441779: return bem_translatedGetDirect_0();
case -1243764713: return bem_sourceFileNameGet_0();
case 440169444: return bem_tagGet_0();
case 1998804429: return bem_deserializeClassNameGet_0();
case -1251108396: return bem_vvGetDirect_0();
case -2046304502: return bem_create_0();
case 1483871301: return bem_print_0();
case 448996129: return bem_classNameGet_0();
case -1633309881: return bem_echo_0();
case -306508262: return bem_framesGet_0();
case 32424274: return bem_descriptionGet_0();
case 463567396: return bem_framesTextGetDirect_0();
case -289473980: return bem_methodNameGetDirect_0();
case -1615184066: return bem_emitLangGet_0();
case -1624889671: return bem_copy_0();
case -1564435804: return bem_new_0();
case -1593274565: return bem_getFrameText_0();
case 1626608589: return bem_langGetDirect_0();
case 1104929273: return bem_emitLangGetDirect_0();
case -1063664471: return bem_framesGetDirect_0();
case -573083229: return bem_fileNameGet_0();
case 73832774: return bem_translatedGet_0();
case -1142809906: return bem_serializationIteratorGet_0();
case 1581478205: return bem_iteratorGet_0();
case -312036224: return bem_klassNameGet_0();
case -2033056683: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1724702365: return bem_copyTo_1(bevd_0);
case -1900502363: return bem_def_1(bevd_0);
case 602691229: return bem_klassNameSetDirect_1(bevd_0);
case -428665530: return bem_framesTextSet_1(bevd_0);
case -1767763000: return bem_sameObject_1(bevd_0);
case -1217337757: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 571103967: return bem_fileNameSet_1(bevd_0);
case -30005655: return bem_framesTextSetDirect_1(bevd_0);
case 965946056: return bem_sameClass_1(bevd_0);
case -931683832: return bem_framesSetDirect_1(bevd_0);
case -1346489980: return bem_klassNameSet_1(bevd_0);
case -48526213: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1655576193: return bem_undef_1(bevd_0);
case 1261805147: return bem_methodNameSet_1(bevd_0);
case -1801363800: return bem_sameType_1(bevd_0);
case -114439408: return bem_vvSetDirect_1(bevd_0);
case 470245843: return bem_translatedSetDirect_1(bevd_0);
case 1647852827: return bem_translatedSet_1(bevd_0);
case -2082849717: return bem_new_1(bevd_0);
case -768475414: return bem_emitLangSet_1(bevd_0);
case -1851732120: return bem_emitLangSetDirect_1(bevd_0);
case 1986631835: return bem_lineNumberSetDirect_1(bevd_0);
case -604374453: return bem_methodNameSetDirect_1(bevd_0);
case 1698066716: return bem_descriptionSetDirect_1(bevd_0);
case -1776828338: return bem_descriptionSet_1(bevd_0);
case -40889849: return bem_equals_1(bevd_0);
case 887328988: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1412099164: return bem_langSetDirect_1(bevd_0);
case -1300393106: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 2011383689: return bem_lineNumberSet_1(bevd_0);
case -776802815: return bem_notEquals_1(bevd_0);
case 724957352: return bem_framesSet_1(bevd_0);
case -1633666379: return bem_langSet_1(bevd_0);
case 1254306911: return bem_fileNameSetDirect_1(bevd_0);
case -1601506198: return bem_otherClass_1(bevd_0);
case 1276126874: return bem_otherType_1(bevd_0);
case 877867982: return bem_vvSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -180551001: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -984805442: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 162928067: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -336527550: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1644303351: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 268803274: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
