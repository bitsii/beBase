package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x0A};
public static BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_4_ContainerList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_vv = be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_19_SystemExceptionTranslator bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_19_SystemExceptionTranslator) BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
bevt_0_ta_ph.bem_translateEmittedException_1(this);
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_0));
if (bevp_description == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 62*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_1));
bevt_2_ta_ph = bevl_toRet.bemd_1(938057778, bevt_3_ta_ph);
bevl_toRet = bevt_2_ta_ph.bemd_1(938057778, bevp_description);
} /* Line: 63*/
if (bevp_fileName == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 65*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_2));
bevt_5_ta_ph = bevl_toRet.bemd_1(938057778, bevt_6_ta_ph);
bevl_toRet = bevt_5_ta_ph.bemd_1(938057778, bevp_fileName);
} /* Line: 66*/
if (bevp_lineNumber == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 68*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_3));
bevt_8_ta_ph = bevl_toRet.bemd_1(938057778, bevt_9_ta_ph);
bevt_10_ta_ph = bevp_lineNumber.bemd_0(969005479);
bevl_toRet = bevt_8_ta_ph.bemd_1(938057778, bevt_10_ta_ph);
} /* Line: 69*/
if (bevp_lang == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_12_ta_ph = bevl_toRet.bemd_1(938057778, bevt_13_ta_ph);
bevl_toRet = bevt_12_ta_ph.bemd_1(938057778, bevp_lang);
} /* Line: 72*/
if (bevp_emitLang == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 74*/ {
bevt_16_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_5));
bevt_15_ta_ph = bevl_toRet.bemd_1(938057778, bevt_16_ta_ph);
bevl_toRet = bevt_15_ta_ph.bemd_1(938057778, bevp_emitLang);
} /* Line: 75*/
if (bevp_methodName == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_6));
bevt_18_ta_ph = bevl_toRet.bemd_1(938057778, bevt_19_ta_ph);
bevl_toRet = bevt_18_ta_ph.bemd_1(938057778, bevp_methodName);
} /* Line: 78*/
if (bevp_klassName == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_22_ta_ph = (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_7));
bevt_21_ta_ph = bevl_toRet.bemd_1(938057778, bevt_22_ta_ph);
bevl_toRet = bevt_21_ta_ph.bemd_1(938057778, bevp_klassName);
} /* Line: 81*/
if (bevp_framesText == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_8));
bevt_24_ta_ph = bevl_toRet.bemd_1(938057778, bevt_25_ta_ph);
bevl_toRet = bevt_24_ta_ph.bemd_1(938057778, bevp_framesText);
} /* Line: 84*/
if (bevp_frames == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_27_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(938057778, bevt_27_ta_ph);
} /* Line: 87*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_9_4_ContainerList bem_framesGet_0() throws Throwable {
BEC_2_6_19_SystemExceptionTranslator bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_19_SystemExceptionTranslator) BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
bevt_0_ta_ph.bem_translateEmittedException_1(this);
if (bevp_vv.bevi_bool)/* Line: 96*/ {
bevt_1_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_9_SystemException_bels_9));
bevt_1_ta_ph.bem_print_0();
} /* Line: 97*/
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_4_ContainerList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_19_SystemExceptionTranslator bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_19_SystemExceptionTranslator) BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
bevt_1_ta_ph.bem_translateEmittedException_1(this);
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 107*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_10));
bevl_toRet = bevl_toRet.bem_add_1(bevt_3_ta_ph);
bevt_0_ta_loop = bevl_myFrames.bem_iteratorGet_0();
while (true)
/* Line: 109*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bemd_0(-642025972);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 109*/ {
bevl_ft = bevt_0_ta_loop.bemd_0(900728463);
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 110*/
 else /* Line: 109*/ {
break;
} /* Line: 109*/
} /* Line: 109*/
} /* Line: 109*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_frames == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 121*/ {
bevp_frames = (new BEC_2_9_4_ContainerList()).bem_new_0();
} /* Line: 122*/
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_methodName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_klassName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_description = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fileName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lineNumber = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_frames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGet_0() throws Throwable {
return bevp_vv;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {53, 56, 60, 60, 61, 62, 62, 63, 63, 63, 65, 65, 66, 66, 66, 68, 68, 69, 69, 69, 69, 71, 71, 72, 72, 72, 74, 74, 75, 75, 75, 77, 77, 78, 78, 78, 80, 80, 81, 81, 81, 83, 83, 84, 84, 84, 86, 86, 87, 87, 89, 95, 95, 97, 97, 100, 104, 104, 105, 106, 107, 107, 108, 108, 109, 0, 109, 109, 110, 113, 117, 121, 121, 122, 124, 128, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {34, 35, 68, 69, 70, 71, 76, 77, 78, 79, 81, 86, 87, 88, 89, 91, 96, 97, 98, 99, 100, 102, 107, 108, 109, 110, 112, 117, 118, 119, 120, 122, 127, 128, 129, 130, 132, 137, 138, 139, 140, 142, 147, 148, 149, 150, 152, 157, 158, 159, 161, 166, 167, 169, 170, 172, 183, 184, 185, 186, 187, 192, 193, 194, 195, 195, 198, 200, 201, 208, 211, 215, 220, 221, 223, 228, 229, 233, 236, 240, 244, 247, 251, 254, 258, 261, 265, 268, 272, 275, 279, 283, 286, 290, 293, 297, 300};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 53 34
new 0 53 34
assign 1 56 35
assign 1 60 68
new 0 60 68
translateEmittedException 1 60 69
assign 1 61 70
new 0 61 70
assign 1 62 71
def 1 62 76
assign 1 63 77
new 0 63 77
assign 1 63 78
add 1 63 78
assign 1 63 79
add 1 63 79
assign 1 65 81
def 1 65 86
assign 1 66 87
new 0 66 87
assign 1 66 88
add 1 66 88
assign 1 66 89
add 1 66 89
assign 1 68 91
def 1 68 96
assign 1 69 97
new 0 69 97
assign 1 69 98
add 1 69 98
assign 1 69 99
toString 0 69 99
assign 1 69 100
add 1 69 100
assign 1 71 102
def 1 71 107
assign 1 72 108
new 0 72 108
assign 1 72 109
add 1 72 109
assign 1 72 110
add 1 72 110
assign 1 74 112
def 1 74 117
assign 1 75 118
new 0 75 118
assign 1 75 119
add 1 75 119
assign 1 75 120
add 1 75 120
assign 1 77 122
def 1 77 127
assign 1 78 128
new 0 78 128
assign 1 78 129
add 1 78 129
assign 1 78 130
add 1 78 130
assign 1 80 132
def 1 80 137
assign 1 81 138
new 0 81 138
assign 1 81 139
add 1 81 139
assign 1 81 140
add 1 81 140
assign 1 83 142
def 1 83 147
assign 1 84 148
new 0 84 148
assign 1 84 149
add 1 84 149
assign 1 84 150
add 1 84 150
assign 1 86 152
def 1 86 157
assign 1 87 158
getFrameText 0 87 158
assign 1 87 159
add 1 87 159
return 1 89 161
assign 1 95 166
new 0 95 166
translateEmittedException 1 95 167
assign 1 97 169
new 0 97 169
print 0 97 170
return 1 100 172
assign 1 104 183
new 0 104 183
translateEmittedException 1 104 184
assign 1 105 185
new 0 105 185
assign 1 106 186
framesGet 0 106 186
assign 1 107 187
def 1 107 192
assign 1 108 193
new 0 108 193
assign 1 108 194
add 1 108 194
assign 1 109 195
iteratorGet 0 0 195
assign 1 109 198
hasNextGet 0 109 198
assign 1 109 200
nextGet 0 109 200
assign 1 110 201
add 1 110 201
return 1 113 208
return 1 117 211
assign 1 121 215
undef 1 121 220
assign 1 122 221
new 0 122 221
addValue 1 124 223
assign 1 128 228
new 4 128 228
addFrame 1 128 229
return 1 0 233
assign 1 0 236
assign 1 0 240
return 1 0 244
assign 1 0 247
return 1 0 251
assign 1 0 254
return 1 0 258
assign 1 0 261
return 1 0 265
assign 1 0 268
return 1 0 272
assign 1 0 275
assign 1 0 279
return 1 0 283
assign 1 0 286
return 1 0 290
assign 1 0 293
return 1 0 297
assign 1 0 300
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 969005479: return bem_toString_0();
case 1359806206: return bem_lineNumberGet_0();
case 28336608: return bem_translatedGet_0();
case 675933254: return bem_fileNameGet_0();
case -1313363915: return bem_langGet_0();
case -2140525323: return bem_emitLangGet_0();
case 1357348184: return bem_vvGet_0();
case -592817210: return bem_klassNameGet_0();
case 101543308: return bem_framesTextGet_0();
case 1781415750: return bem_descriptionGet_0();
case 326916018: return bem_iteratorGet_0();
case -1877988678: return bem_hashGet_0();
case 668645503: return bem_new_0();
case 1401626610: return bem_print_0();
case 40114523: return bem_framesGet_0();
case 1691925401: return bem_methodNameGet_0();
case -1954821624: return bem_getFrameText_0();
case -161809366: return bem_copy_0();
case -508717313: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 182599691: return bem_methodNameSet_1(bevd_0);
case -1535938918: return bem_lineNumberSet_1(bevd_0);
case 552614443: return bem_descriptionSet_1(bevd_0);
case 1877593793: return bem_klassNameSet_1(bevd_0);
case -1581048634: return bem_copyTo_1(bevd_0);
case 422058995: return bem_new_1(bevd_0);
case 382332086: return bem_emitLangSet_1(bevd_0);
case 384220308: return bem_notEquals_1(bevd_0);
case -1391871629: return bem_undef_1(bevd_0);
case 939305500: return bem_def_1(bevd_0);
case -427684143: return bem_vvSet_1(bevd_0);
case -374906707: return bem_translatedSet_1(bevd_0);
case 287106773: return bem_framesSet_1(bevd_0);
case -2039797495: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 567335501: return bem_equals_1(bevd_0);
case -1558005103: return bem_fileNameSet_1(bevd_0);
case 655851770: return bem_langSet_1(bevd_0);
case -1340800831: return bem_framesTextSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 163536847: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 72722300: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1961786723: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2046340809: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -951153683: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
