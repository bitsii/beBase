package be;
public class BET_2_4_6_TextString extends BETS_Object {
public BET_2_4_6_TextString() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "vstringGet_0", "vstringSet_0", "new_1", "capacitySet_1", "hexNew_1", "getHex_1", "setHex_2", "addValue_1", "readBuffer_0", "readString_0", "write_1", "writeTo_1", "open_0", "close_0", "extractString_0", "clear_0", "codeNew_1", "chomp_0", "begins_1", "ends_1", "has_1", "isIntegerGet_0", "isInteger_0", "isAlphaNumGet_0", "isAlphaNumericGet_0", "lowerValue_0", "lower_0", "upperValue_0", "upper_0", "swapFirst_2", "swap_2", "getPoint_1", "hashValue_1", "getCode_1", "getInt_2", "getCode_2", "setInt_2", "setCode_2", "toAlphaNum_0", "isEmptyGet_0", "setIntUnchecked_2", "setCodeUnchecked_2", "reverseFind_1", "rfind_1", "find_1", "find_2", "split_1", "join_2", "compare_1", "lesser_1", "greater_1", "add_1", "copyValue_4", "substring_1", "substring_2", "output_0", "echo_0", "byteIteratorGet_0", "multiByteIteratorGet_0", "biterGet_0", "mbiterGet_0", "stringIteratorGet_0", "serializeToString_0", "deserializeFromStringNew_1", "serializeContentsGet_0", "strip_0", "reverseBytes_0", "sizeGet_0", "sizeGetDirect_0", "sizeSet_1", "sizeSetDirect_1", "capacityGet_0", "capacityGetDirect_0", "capacitySetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "size", "capacity" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_6_TextString();
}
}
