package be;
public class BET_2_4_12_JsonUnmarshaller extends BETS_Object {
public BET_2_4_12_JsonUnmarshaller() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "unmarshall_1", "addIn_1", "beginMap_0", "endMap_0", "kvMid_0", "beginList_0", "endList_0", "handleString_1", "handleTrue_0", "handleFalse_0", "handleNull_0", "handleInteger_1", "parserGet_0", "parserGetDirect_0", "parserSet_1", "parserSetDirect_1", "listGet_0", "listGetDirect_0", "listSet_1", "listSetDirect_1", "pairGet_0", "pairGetDirect_0", "pairSet_1", "pairSetDirect_1", "mapGet_0", "mapGetDirect_0", "mapSet_1", "mapSetDirect_1", "firstGet_0", "firstGetDirect_0", "firstSet_1", "firstSetDirect_1", "stackGet_0", "stackGetDirect_0", "stackSet_1", "stackSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "parser", "list", "pair", "map", "first", "stack" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_12_JsonUnmarshaller();
}
}
