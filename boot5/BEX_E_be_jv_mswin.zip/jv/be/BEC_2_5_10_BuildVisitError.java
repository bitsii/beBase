package be;
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError extends BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public BEC_2_5_10_BuildVisitError bem_new_1(BEC_2_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_7_TextStrings bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 24*/ {
bevt_1_ta_ph = bevl_toRet.bemd_1(440608122, bevp_msg);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_newlineGet_0();
bevl_toRet = bevt_1_ta_ph.bemd_1(440608122, bevt_2_ta_ph);
} /* Line: 25*/
if (bevp_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 27*/ {
bevl_nc = bevp_node;
while (true)
/* Line: 29*/ {
if (bevl_nc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 29*/ {
bevl_toRet.bemd_1(1513347703, bevl_nc);
bevt_7_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_ta_ph = bevt_7_ta_ph.bem_newlineGet_0();
bevl_toRet.bemd_1(1513347703, bevt_6_ta_ph);
bevl_nc = bevl_nc.bemd_0(-1058156920);
} /* Line: 32*/
 else /* Line: 29*/ {
break;
} /* Line: 29*/
} /* Line: 29*/
} /* Line: 29*/
bevt_8_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(440608122, bevt_8_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_msgGetDirect_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msg = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildVisitError bem_msgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msg = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nodeGetDirect_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_node = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildVisitError bem_nodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_node = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {10, 15, 16, 23, 24, 24, 25, 25, 25, 25, 27, 27, 28, 29, 29, 30, 31, 31, 31, 32, 35, 35, 36, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 20, 35, 36, 41, 42, 43, 44, 45, 47, 52, 53, 56, 61, 62, 63, 64, 65, 66, 73, 74, 75, 78, 81, 84, 88, 92, 95, 98, 102};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 10 15
assign 1 15 19
assign 1 16 20
assign 1 23 35
new 0 23 35
assign 1 24 36
def 1 24 41
assign 1 25 42
add 1 25 42
assign 1 25 43
new 0 25 43
assign 1 25 44
newlineGet 0 25 44
assign 1 25 45
add 1 25 45
assign 1 27 47
def 1 27 52
assign 1 28 53
assign 1 29 56
def 1 29 61
addValue 1 30 62
assign 1 31 63
new 0 31 63
assign 1 31 64
newlineGet 0 31 64
addValue 1 31 65
assign 1 32 66
containerGet 0 32 66
assign 1 35 73
getFrameText 0 35 73
assign 1 35 74
add 1 35 74
return 1 36 75
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 254283761: return bem_classNameGet_0();
case 32986096: return bem_tagGet_0();
case -857413750: return bem_descriptionGet_0();
case -335200426: return bem_langGet_0();
case 1337499076: return bem_fieldIteratorGet_0();
case 2118612574: return bem_msgGet_0();
case -434766936: return bem_many_0();
case -1639952368: return bem_framesTextGetDirect_0();
case -1193538733: return bem_echo_0();
case -1759661711: return bem_nodeGet_0();
case -249118944: return bem_msgGetDirect_0();
case 1814565119: return bem_klassNameGetDirect_0();
case -1449015112: return bem_emitLangGetDirect_0();
case 1708691670: return bem_klassNameGet_0();
case -1667230363: return bem_new_0();
case -2068645774: return bem_toString_0();
case -171018687: return bem_nodeGetDirect_0();
case 656174411: return bem_iteratorGet_0();
case -364835164: return bem_translatedGet_0();
case 1258540231: return bem_print_0();
case 1043653138: return bem_framesGetDirect_0();
case -1723302242: return bem_emitLangGet_0();
case -23495678: return bem_methodNameGet_0();
case -1976477233: return bem_vvGetDirect_0();
case 181316061: return bem_serializeContents_0();
case 1648944132: return bem_translateEmittedException_0();
case 1559646396: return bem_methodNameGetDirect_0();
case 1806144780: return bem_framesTextGet_0();
case -750795685: return bem_framesGet_0();
case -1623758382: return bem_fileNameGet_0();
case 192923601: return bem_lineNumberGet_0();
case 1333189262: return bem_copy_0();
case -1134589630: return bem_serializeToString_0();
case -1069872570: return bem_getFrameText_0();
case 1887791078: return bem_toAny_0();
case 611274904: return bem_vvGet_0();
case -152298688: return bem_translateEmittedExceptionInner_0();
case 1104438617: return bem_serializationIteratorGet_0();
case -810892117: return bem_sourceFileNameGet_0();
case 238716313: return bem_once_0();
case -1982045096: return bem_lineNumberGetDirect_0();
case -1916545082: return bem_hashGet_0();
case -493526692: return bem_translatedGetDirect_0();
case 1682074595: return bem_fileNameGetDirect_0();
case -135939427: return bem_descriptionGetDirect_0();
case 470335985: return bem_fieldNamesGet_0();
case -1742789838: return bem_langGetDirect_0();
case 1422294520: return bem_create_0();
case 1433312714: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1083248871: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -304085546: return bem_klassNameSet_1(bevd_0);
case -25458794: return bem_framesTextSetDirect_1(bevd_0);
case 1537925034: return bem_framesSet_1(bevd_0);
case -968969729: return bem_fileNameSetDirect_1(bevd_0);
case -1041366691: return bem_otherType_1(bevd_0);
case 1854448500: return bem_emitLangSet_1(bevd_0);
case 1112591683: return bem_msgSet_1(bevd_0);
case 1598801759: return bem_vvSet_1(bevd_0);
case 252756311: return bem_vvSetDirect_1(bevd_0);
case 1265043700: return bem_descriptionSet_1(bevd_0);
case 66747004: return bem_undef_1(bevd_0);
case -887751171: return bem_emitLangSetDirect_1(bevd_0);
case -1815286784: return bem_nodeSet_1(bevd_0);
case -184175961: return bem_klassNameSetDirect_1(bevd_0);
case -1742780291: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -91969480: return bem_translatedSet_1(bevd_0);
case 226161992: return bem_framesSetDirect_1(bevd_0);
case -1335631064: return bem_fileNameSet_1(bevd_0);
case 1621914759: return bem_sameType_1(bevd_0);
case 1290216463: return bem_def_1(bevd_0);
case 454461474: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -588560885: return bem_lineNumberSet_1(bevd_0);
case -1013582118: return bem_lineNumberSetDirect_1(bevd_0);
case 1515359610: return bem_defined_1(bevd_0);
case -1612212657: return bem_methodNameSetDirect_1(bevd_0);
case -1338803131: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -437060655: return bem_descriptionSetDirect_1(bevd_0);
case 657229738: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -154605448: return bem_notEquals_1(bevd_0);
case 1350425667: return bem_msgSetDirect_1(bevd_0);
case -2136394139: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1940151461: return bem_methodNameSet_1(bevd_0);
case 729030396: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 653347681: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -494057614: return bem_framesTextSet_1(bevd_0);
case -1577528613: return bem_undefined_1(bevd_0);
case -2101960569: return bem_langSetDirect_1(bevd_0);
case -1985219488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -517334457: return bem_sameClass_1(bevd_0);
case -420475689: return bem_equals_1(bevd_0);
case 1948301764: return bem_new_1(bevd_0);
case 1634548560: return bem_langSet_1(bevd_0);
case 798567198: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -829491009: return bem_sameObject_1(bevd_0);
case 1297978910: return bem_translatedSetDirect_1(bevd_0);
case -868162923: return bem_copyTo_1(bevd_0);
case 771401438: return bem_otherClass_1(bevd_0);
case 1954101613: return bem_nodeSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1794052685: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -728964893: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -125531032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1236472697: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 40605738: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1992262987: return bem_new_2(bevd_0, bevd_1);
case -1943210084: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 587426084: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 462334666: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
