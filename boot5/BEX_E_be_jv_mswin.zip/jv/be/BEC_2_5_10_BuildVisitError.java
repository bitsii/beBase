package be;
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError extends BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public BEC_2_5_10_BuildVisitError bem_new_1(BEC_2_6_6_SystemObject beva_msgi) throws Throwable {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) throws Throwable {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_1_tmpany_phold = bevl_toRet.bemd_1(-323401251, bevp_msg);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_newlineGet_0();
bevl_toRet = bevt_1_tmpany_phold.bemd_1(-323401251, bevt_2_tmpany_phold);
} /* Line: 26 */
if (bevp_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevl_nc = bevp_node;
while (true)
 /* Line: 30 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevl_toRet.bemd_1(-1956247108, bevl_nc);
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_newlineGet_0();
bevl_toRet.bemd_1(-1956247108, bevt_6_tmpany_phold);
bevl_nc = bevl_nc.bemd_0(-1838234759);
} /* Line: 33 */
 else  /* Line: 30 */ {
break;
} /* Line: 30 */
} /* Line: 30 */
} /* Line: 30 */
bevt_8_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(-323401251, bevt_8_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGet_0() throws Throwable {
return bevp_msg;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_msgGetDirect_0() throws Throwable {
return bevp_msg;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildVisitError bem_msgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGet_0() throws Throwable {
return bevp_node;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nodeGetDirect_0() throws Throwable {
return bevp_node;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_5_10_BuildVisitError bem_nodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {11, 16, 17, 24, 25, 25, 26, 26, 26, 26, 28, 28, 29, 30, 30, 31, 32, 32, 32, 33, 36, 36, 37, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 19, 20, 35, 36, 41, 42, 43, 44, 45, 47, 52, 53, 56, 61, 62, 63, 64, 65, 66, 73, 74, 75, 78, 81, 84, 88, 92, 95, 98, 102};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 11 15
assign 1 16 19
assign 1 17 20
assign 1 24 35
new 0 24 35
assign 1 25 36
def 1 25 41
assign 1 26 42
add 1 26 42
assign 1 26 43
new 0 26 43
assign 1 26 44
newlineGet 0 26 44
assign 1 26 45
add 1 26 45
assign 1 28 47
def 1 28 52
assign 1 29 53
assign 1 30 56
def 1 30 61
addValue 1 31 62
assign 1 32 63
new 0 32 63
assign 1 32 64
newlineGet 0 32 64
addValue 1 32 65
assign 1 33 66
containerGet 0 33 66
assign 1 36 73
getFrameText 0 36 73
assign 1 36 74
add 1 36 74
return 1 37 75
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -919772434: return bem_serializeToString_0();
case 1776086751: return bem_fileNameGetDirect_0();
case 88318799: return bem_nodeGetDirect_0();
case 1727938707: return bem_msgGetDirect_0();
case 2064556163: return bem_klassNameGet_0();
case 1928293906: return bem_once_0();
case 619304343: return bem_hashGet_0();
case 1623987490: return bem_serializeContents_0();
case 407789443: return bem_methodNameGetDirect_0();
case 1733513513: return bem_deserializeClassNameGet_0();
case 1385440424: return bem_emitLangGet_0();
case 322458447: return bem_translateEmittedException_0();
case -465411094: return bem_klassNameGetDirect_0();
case 868760417: return bem_serializationIteratorGet_0();
case -1836757512: return bem_copy_0();
case 1452564531: return bem_toString_0();
case -757699318: return bem_iteratorGet_0();
case 1065543761: return bem_langGet_0();
case 998021668: return bem_langGetDirect_0();
case -977356120: return bem_fieldNamesGet_0();
case 1605752359: return bem_many_0();
case 438244040: return bem_create_0();
case 1576417178: return bem_new_0();
case -197180620: return bem_echo_0();
case 1148186102: return bem_toAny_0();
case -501838281: return bem_descriptionGet_0();
case 681563544: return bem_lineNumberGetDirect_0();
case 1066844859: return bem_getFrameText_0();
case -701837270: return bem_framesGet_0();
case 141983605: return bem_sourceFileNameGet_0();
case -464967776: return bem_classNameGet_0();
case 802324918: return bem_framesTextGetDirect_0();
case -294275930: return bem_lineNumberGet_0();
case 84498289: return bem_nodeGet_0();
case -2028524717: return bem_translatedGet_0();
case 1739178121: return bem_fileNameGet_0();
case -571532887: return bem_translatedGetDirect_0();
case 259514819: return bem_vvGetDirect_0();
case 555221661: return bem_emitLangGetDirect_0();
case 500389220: return bem_print_0();
case -1577376052: return bem_methodNameGet_0();
case 612655702: return bem_descriptionGetDirect_0();
case 717709992: return bem_framesGetDirect_0();
case -978724962: return bem_tagGet_0();
case 730875238: return bem_framesTextGet_0();
case -1693291784: return bem_vvGet_0();
case 23744672: return bem_translateEmittedExceptionInner_0();
case -1895797969: return bem_fieldIteratorGet_0();
case 414284367: return bem_msgGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1399711040: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 849561595: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 532950266: return bem_nodeSet_1(bevd_0);
case 1455200885: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 140576519: return bem_undef_1(bevd_0);
case 137909243: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1874280381: return bem_klassNameSetDirect_1(bevd_0);
case 664139783: return bem_translatedSet_1(bevd_0);
case -1670220047: return bem_fileNameSetDirect_1(bevd_0);
case -2109520205: return bem_methodNameSetDirect_1(bevd_0);
case 1698026019: return bem_new_1(bevd_0);
case 1592373155: return bem_framesSetDirect_1(bevd_0);
case 1149773549: return bem_vvSet_1(bevd_0);
case -2080355933: return bem_defined_1(bevd_0);
case -217159540: return bem_framesTextSetDirect_1(bevd_0);
case -1868285108: return bem_def_1(bevd_0);
case 664447252: return bem_fileNameSet_1(bevd_0);
case 1140122456: return bem_sameType_1(bevd_0);
case 2141085532: return bem_undefined_1(bevd_0);
case -1583961333: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -341841106: return bem_klassNameSet_1(bevd_0);
case 177273835: return bem_notEquals_1(bevd_0);
case -1386227183: return bem_equals_1(bevd_0);
case -1564294537: return bem_langSetDirect_1(bevd_0);
case -1478855850: return bem_sameClass_1(bevd_0);
case -1054095411: return bem_msgSetDirect_1(bevd_0);
case 1108388022: return bem_copyTo_1(bevd_0);
case -1559076513: return bem_emitLangSet_1(bevd_0);
case -1158572731: return bem_otherType_1(bevd_0);
case -1303807005: return bem_methodNameSet_1(bevd_0);
case 1945904012: return bem_emitLangSetDirect_1(bevd_0);
case 1815436791: return bem_nodeSetDirect_1(bevd_0);
case 1016435319: return bem_sameObject_1(bevd_0);
case 1697588086: return bem_msgSet_1(bevd_0);
case -1856971928: return bem_vvSetDirect_1(bevd_0);
case 554878156: return bem_descriptionSetDirect_1(bevd_0);
case 1949971683: return bem_lineNumberSetDirect_1(bevd_0);
case 910618841: return bem_framesSet_1(bevd_0);
case -1370861903: return bem_otherClass_1(bevd_0);
case 643357388: return bem_translatedSetDirect_1(bevd_0);
case -925234766: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 626970944: return bem_framesTextSet_1(bevd_0);
case 1764782799: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1932446897: return bem_langSet_1(bevd_0);
case 638723889: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -558105795: return bem_lineNumberSet_1(bevd_0);
case 559985449: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1724832529: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 308935537: return bem_descriptionSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1155977356: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -403604142: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 809509937: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1429864581: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -953745911: return bem_new_2(bevd_0, bevd_1);
case 858274939: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1387375867: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1832424834: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -220218582: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_10_BuildVisitError();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
