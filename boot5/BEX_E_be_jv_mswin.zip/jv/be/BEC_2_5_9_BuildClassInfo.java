package be;
/* IO:File: source/build/CEmitter.be */
public final class BEC_2_5_9_BuildClassInfo extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x46,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x58,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x42,0x45,0x4B,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x2E,0x68};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x2E,0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x2E,0x73,0x79,0x6E};
public static BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;

public static BET_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) throws Throwable {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) throws Throwable {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_ta_ph = bevp_emitter.bemd_0(1382187419);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_ph.bemd_0(-1028712780);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_ta_ph = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(-1495466998, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_0));
bevp_incBlock = bevt_2_ta_ph.bem_add_1(bevp_midName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_midName);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildClassInfo_bels_2));
bevp_mtdName = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_midName);
bevt_8_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildClassInfo_bels_4));
bevp_cldefName = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_midName);
bevt_11_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_5));
bevp_shClassName = bevt_9_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevp_midName);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildClassInfo_bels_6));
bevp_shFileName = bevt_12_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_15_ta_ph = bevt_16_ta_ph.bem_add_1(bevp_midName);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildClassInfo_bels_4));
bevp_cldefBuild = bevt_15_ta_ph.bem_add_1(bevt_17_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevp_midName);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_8));
bevp_libnameInit = bevt_18_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevp_midName);
bevt_23_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_9));
bevp_libnameInitDone = bevt_21_ta_ph.bem_add_1(bevt_23_ta_ph);
bevt_25_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevp_midName);
bevt_26_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_10));
bevp_libnameData = bevt_24_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(bevp_midName);
bevt_29_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_11));
bevp_libnameDataDone = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevp_midName);
bevt_32_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildClassInfo_bels_12));
bevp_libnameDataClear = bevt_30_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_34_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevp_midName);
bevt_35_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_13));
bevp_libNotNullInit = bevt_33_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_37_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_midName);
bevt_38_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_14));
bevp_libNotNullInitDone = bevt_36_ta_ph.bem_add_1(bevt_38_ta_ph);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = beva__emitPath.bem_copy_0();
bevt_39_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_15));
bevp_xbase = bevt_39_ta_ph.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_16));
bevp_kbase = bevt_40_ta_ph.bem_add_1(bevp_clBase);
bevt_41_ta_ph = bevp_cuBase.bem_copy_0();
bevt_43_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_42_ta_ph = bevp_nbase.bem_add_1(bevt_43_ta_ph);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_ta_ph.bem_addStep_1(bevt_42_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_ta_ph);
bevt_45_ta_ph = bevp_cuBase.bem_copy_0();
bevt_46_ta_ph = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_ta_ph.bem_addStep_1(bevt_46_ta_ph);
bevt_47_ta_ph = bevp_cuBase.bem_copy_0();
bevt_48_ta_ph = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_ta_ph.bem_addStep_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevp_cuBase.bem_copy_0();
bevt_51_ta_ph = bevp_cpro.bem_libExtGet_0();
bevt_50_ta_ph = bevp_lbase.bem_add_1(bevt_51_ta_ph);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_ta_ph.bem_addStep_1(bevt_50_ta_ph);
bevt_52_ta_ph = bevp_cuBase.bem_copy_0();
bevt_54_ta_ph = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_ta_ph = bevp_lbase.bem_add_1(bevt_54_ta_ph);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_ta_ph.bem_addStep_1(bevt_53_ta_ph);
bevt_55_ta_ph = bevp_cuBase.bem_copy_0();
bevt_57_ta_ph = bevp_cpro.bem_exeExtGet_0();
bevt_56_ta_ph = beva__exeName.bem_add_1(bevt_57_ta_ph);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_ta_ph.bem_addStep_1(bevt_56_ta_ph);
bevt_58_ta_ph = bevp_basePath.bem_copy_0();
bevt_59_ta_ph = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_ta_ph.bem_addStep_1(bevt_59_ta_ph);
bevt_60_ta_ph = bevp_basePath.bem_copy_0();
bevt_61_ta_ph = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_ta_ph.bem_addStep_1(bevt_61_ta_ph);
bevt_62_ta_ph = bevp_basePath.bem_copy_0();
bevt_64_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_18));
bevt_63_ta_ph = bevp_xbase.bem_add_1(bevt_64_ta_ph);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_ta_ph.bem_addStep_1(bevt_63_ta_ph);
bevt_65_ta_ph = bevp_basePath.bem_copy_0();
bevt_66_ta_ph = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_ta_ph.bem_addStep_1(bevt_66_ta_ph);
bevt_67_ta_ph = bevp_basePath.bem_copy_0();
bevt_69_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_68_ta_ph = bevp_kbase.bem_add_1(bevt_69_ta_ph);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_ta_ph.bem_addStep_1(bevt_68_ta_ph);
bevt_70_ta_ph = bevp_nsDir.bem_copy_0();
bevt_72_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_71_ta_ph = bevp_kbase.bem_add_1(bevt_72_ta_ph);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_ta_ph.bem_addStep_1(bevt_71_ta_ph);
bevt_73_ta_ph = bevp_basePath.bem_copy_0();
bevt_74_ta_ph = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_ta_ph.bem_addStep_1(bevt_74_ta_ph);
bevt_75_ta_ph = bevp_basePath.bem_copy_0();
bevt_77_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_19));
bevt_76_ta_ph = bevp_kbase.bem_add_1(bevt_77_ta_ph);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_ta_ph.bem_addStep_1(bevt_76_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(38127485);
while (true)
/* Line: 110*/ {
bevt_0_ta_ph = bevl_i.bemd_0(1757263953);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 110*/ {
bevt_1_ta_ph = bevl_i.bemd_0(1982151412);
bevp_nsDir.bem_addStep_1(bevt_1_ta_ph);
} /* Line: 111*/
 else /* Line: 110*/ {
break;
} /* Line: 110*/
} /* Line: 110*/
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() throws Throwable {
return bevp_np;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_npGetDirect_0() throws Throwable {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_emitterGetDirect_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() throws Throwable {
return bevp_cpro;
} /*method end*/
public final BEC_2_5_15_BuildCompilerProfile bem_cproGetDirect_0() throws Throwable {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cproSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() throws Throwable {
return bevp_npar;
} /*method end*/
public final BEC_2_5_8_BuildNamePath bem_nparGetDirect_0() throws Throwable {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nparSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() throws Throwable {
return bevp_nparSteps;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_nparStepsGetDirect_0() throws Throwable {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nparSteps = bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nparStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nparSteps = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() throws Throwable {
return bevp_clName;
} /*method end*/
public final BEC_2_4_6_TextString bem_clNameGetDirect_0() throws Throwable {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_clNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() throws Throwable {
return bevp_clBase;
} /*method end*/
public final BEC_2_4_6_TextString bem_clBaseGetDirect_0() throws Throwable {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_clBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() throws Throwable {
return bevp_midName;
} /*method end*/
public final BEC_2_4_6_TextString bem_midNameGetDirect_0() throws Throwable {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_midNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() throws Throwable {
return bevp_incBlock;
} /*method end*/
public final BEC_2_4_6_TextString bem_incBlockGetDirect_0() throws Throwable {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_incBlockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() throws Throwable {
return bevp_mtdName;
} /*method end*/
public final BEC_2_4_6_TextString bem_mtdNameGetDirect_0() throws Throwable {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_mtdNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() throws Throwable {
return bevp_cldefName;
} /*method end*/
public final BEC_2_4_6_TextString bem_cldefNameGetDirect_0() throws Throwable {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cldefNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() throws Throwable {
return bevp_shClassName;
} /*method end*/
public final BEC_2_4_6_TextString bem_shClassNameGetDirect_0() throws Throwable {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_shClassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() throws Throwable {
return bevp_shFileName;
} /*method end*/
public final BEC_2_4_6_TextString bem_shFileNameGetDirect_0() throws Throwable {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_shFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() throws Throwable {
return bevp_cldefBuild;
} /*method end*/
public final BEC_2_4_6_TextString bem_cldefBuildGetDirect_0() throws Throwable {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cldefBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() throws Throwable {
return bevp_libnameInit;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameInitGetDirect_0() throws Throwable {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() throws Throwable {
return bevp_libnameInitDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameInitDoneGetDirect_0() throws Throwable {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() throws Throwable {
return bevp_libnameData;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataGetDirect_0() throws Throwable {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() throws Throwable {
return bevp_libnameDataDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataDoneGetDirect_0() throws Throwable {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() throws Throwable {
return bevp_libnameDataClear;
} /*method end*/
public final BEC_2_4_6_TextString bem_libnameDataClearGetDirect_0() throws Throwable {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libnameDataClearSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() throws Throwable {
return bevp_libNotNullInit;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNotNullInitGetDirect_0() throws Throwable {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libNotNullInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() throws Throwable {
return bevp_libNotNullInitDone;
} /*method end*/
public final BEC_2_4_6_TextString bem_libNotNullInitDoneGetDirect_0() throws Throwable {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_basePathGetDirect_0() throws Throwable {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_basePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() throws Throwable {
return bevp_cuBase;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuBaseGetDirect_0() throws Throwable {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() throws Throwable {
return bevp_nsDir;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_nsDirGetDirect_0() throws Throwable {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nsDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() throws Throwable {
return bevp_xbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_xbaseGetDirect_0() throws Throwable {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_xbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() throws Throwable {
return bevp_lbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_lbaseGetDirect_0() throws Throwable {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_lbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() throws Throwable {
return bevp_nbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_nbaseGetDirect_0() throws Throwable {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_nbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() throws Throwable {
return bevp_kbase;
} /*method end*/
public final BEC_2_4_6_TextString bem_kbaseGetDirect_0() throws Throwable {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_kbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() throws Throwable {
return bevp_cuinitH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuinitHGetDirect_0() throws Throwable {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuinitHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() throws Throwable {
return bevp_namesIncH;
} /*method end*/
public final BEC_2_4_6_TextString bem_namesIncHGetDirect_0() throws Throwable {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_namesIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() throws Throwable {
return bevp_cuinit;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_cuinitGetDirect_0() throws Throwable {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_cuinitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() throws Throwable {
return bevp_namesO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_namesOGetDirect_0() throws Throwable {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_namesOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() throws Throwable {
return bevp_unitShlib;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitShlibGetDirect_0() throws Throwable {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitShlibSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() throws Throwable {
return bevp_unitExeLink;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitExeLinkGetDirect_0() throws Throwable {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitExeLinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() throws Throwable {
return bevp_unitExe;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_unitExeGetDirect_0() throws Throwable {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_unitExeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() throws Throwable {
return bevp_classExeSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classExeSrcGetDirect_0() throws Throwable {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classExeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() throws Throwable {
return bevp_classExeO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classExeOGetDirect_0() throws Throwable {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classExeOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() throws Throwable {
return bevp_makeSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_makeSrcGetDirect_0() throws Throwable {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_makeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() throws Throwable {
return bevp_classSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classSrcGetDirect_0() throws Throwable {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() throws Throwable {
return bevp_classSrcH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classSrcHGetDirect_0() throws Throwable {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classSrcHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() throws Throwable {
return bevp_classIncH;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classIncHGetDirect_0() throws Throwable {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() throws Throwable {
return bevp_classO;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_classOGetDirect_0() throws Throwable {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_classOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() throws Throwable {
return bevp_synSrc;
} /*method end*/
public final BEC_3_2_4_4_IOFilePath bem_synSrcGetDirect_0() throws Throwable {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildClassInfo bem_synSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 27, 28, 29, 29, 30, 31, 32, 34, 34, 36, 38, 39, 40, 43, 43, 45, 45, 45, 45, 47, 47, 47, 47, 49, 49, 49, 49, 51, 51, 51, 51, 53, 53, 53, 53, 55, 55, 55, 55, 57, 57, 57, 57, 59, 59, 59, 59, 61, 61, 61, 61, 63, 63, 63, 63, 65, 65, 65, 65, 66, 66, 66, 66, 68, 70, 71, 74, 74, 75, 76, 77, 77, 79, 79, 79, 79, 80, 80, 81, 81, 81, 82, 82, 82, 86, 86, 86, 86, 87, 87, 87, 87, 88, 88, 88, 88, 90, 90, 90, 91, 91, 91, 92, 92, 92, 92, 94, 94, 94, 95, 95, 95, 95, 96, 96, 96, 96, 97, 97, 97, 98, 98, 98, 98, 108, 109, 110, 110, 111, 111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {76, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 290, 291, 292, 295, 297, 298, 307, 310, 313, 317, 321, 324, 327, 331, 335, 338, 341, 345, 349, 352, 355, 359, 363, 366, 369, 373, 377, 380, 383, 387, 391, 394, 397, 401, 405, 408, 411, 415, 419, 422, 425, 429, 433, 436, 439, 443, 447, 450, 453, 457, 461, 464, 467, 471, 475, 478, 481, 485, 489, 492, 495, 499, 503, 506, 509, 513, 517, 520, 523, 527, 531, 534, 537, 541, 545, 548, 551, 555, 559, 562, 565, 569, 573, 576, 579, 583, 587, 590, 593, 597, 601, 604, 607, 611, 615, 618, 621, 625, 629, 632, 635, 639, 643, 646, 649, 653, 657, 660, 663, 667, 671, 674, 677, 681, 685, 688, 691, 695, 699, 702, 705, 709, 713, 716, 719, 723, 727, 730, 733, 737, 741, 744, 747, 751, 755, 758, 761, 765, 769, 772, 775, 779, 783, 786, 789, 793, 797, 800, 803, 807, 811, 814, 817, 821, 825, 828, 831, 835, 839, 842, 845, 849, 853, 856, 859, 863, 867, 870, 873, 877, 881, 884, 887, 891, 895, 898, 901, 905, 909, 912, 915, 919};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 5 20 76
assign 1 27 160
assign 1 28 161
assign 1 29 162
buildGet 0 29 162
assign 1 29 163
compilerProfileGet 0 29 163
assign 1 30 164
parentGet 0 30 164
assign 1 31 165
stepsGet 0 31 165
assign 1 32 166
toString 0 32 166
assign 1 34 167
stepsGet 0 34 167
assign 1 34 168
lastGet 0 34 168
assign 1 36 169
midNameDo 2 36 169
nsDirDo 1 38 170
assign 1 39 171
cextGet 0 39 171
assign 1 40 172
oextGet 0 40 172
assign 1 43 173
new 0 43 173
assign 1 43 174
add 1 43 174
assign 1 45 175
new 0 45 175
assign 1 45 176
add 1 45 176
assign 1 45 177
new 0 45 177
assign 1 45 178
add 1 45 178
assign 1 47 179
new 0 47 179
assign 1 47 180
add 1 47 180
assign 1 47 181
new 0 47 181
assign 1 47 182
add 1 47 182
assign 1 49 183
new 0 49 183
assign 1 49 184
add 1 49 184
assign 1 49 185
new 0 49 185
assign 1 49 186
add 1 49 186
assign 1 51 187
new 0 51 187
assign 1 51 188
add 1 51 188
assign 1 51 189
new 0 51 189
assign 1 51 190
add 1 51 190
assign 1 53 191
new 0 53 191
assign 1 53 192
add 1 53 192
assign 1 53 193
new 0 53 193
assign 1 53 194
add 1 53 194
assign 1 55 195
new 0 55 195
assign 1 55 196
add 1 55 196
assign 1 55 197
new 0 55 197
assign 1 55 198
add 1 55 198
assign 1 57 199
new 0 57 199
assign 1 57 200
add 1 57 200
assign 1 57 201
new 0 57 201
assign 1 57 202
add 1 57 202
assign 1 59 203
new 0 59 203
assign 1 59 204
add 1 59 204
assign 1 59 205
new 0 59 205
assign 1 59 206
add 1 59 206
assign 1 61 207
new 0 61 207
assign 1 61 208
add 1 61 208
assign 1 61 209
new 0 61 209
assign 1 61 210
add 1 61 210
assign 1 63 211
new 0 63 211
assign 1 63 212
add 1 63 212
assign 1 63 213
new 0 63 213
assign 1 63 214
add 1 63 214
assign 1 65 215
new 0 65 215
assign 1 65 216
add 1 65 216
assign 1 65 217
new 0 65 217
assign 1 65 218
add 1 65 218
assign 1 66 219
new 0 66 219
assign 1 66 220
add 1 66 220
assign 1 66 221
new 0 66 221
assign 1 66 222
add 1 66 222
assign 1 68 223
assign 1 70 224
add 1 70 224
assign 1 71 225
copy 0 71 225
assign 1 74 226
new 0 74 226
assign 1 74 227
add 1 74 227
assign 1 75 228
assign 1 76 229
assign 1 77 230
new 0 77 230
assign 1 77 231
add 1 77 231
assign 1 79 232
copy 0 79 232
assign 1 79 233
new 0 79 233
assign 1 79 234
add 1 79 234
assign 1 79 235
addStep 1 79 235
assign 1 80 236
new 0 80 236
assign 1 80 237
add 1 80 237
assign 1 81 238
copy 0 81 238
assign 1 81 239
add 1 81 239
assign 1 81 240
addStep 1 81 240
assign 1 82 241
copy 0 82 241
assign 1 82 242
add 1 82 242
assign 1 82 243
addStep 1 82 243
assign 1 86 244
copy 0 86 244
assign 1 86 245
libExtGet 0 86 245
assign 1 86 246
add 1 86 246
assign 1 86 247
addStep 1 86 247
assign 1 87 248
copy 0 87 248
assign 1 87 249
exeLibExtGet 0 87 249
assign 1 87 250
add 1 87 250
assign 1 87 251
addStep 1 87 251
assign 1 88 252
copy 0 88 252
assign 1 88 253
exeExtGet 0 88 253
assign 1 88 254
add 1 88 254
assign 1 88 255
addStep 1 88 255
assign 1 90 256
copy 0 90 256
assign 1 90 257
add 1 90 257
assign 1 90 258
addStep 1 90 258
assign 1 91 259
copy 0 91 259
assign 1 91 260
add 1 91 260
assign 1 91 261
addStep 1 91 261
assign 1 92 262
copy 0 92 262
assign 1 92 263
new 0 92 263
assign 1 92 264
add 1 92 264
assign 1 92 265
addStep 1 92 265
assign 1 94 266
copy 0 94 266
assign 1 94 267
add 1 94 267
assign 1 94 268
addStep 1 94 268
assign 1 95 269
copy 0 95 269
assign 1 95 270
new 0 95 270
assign 1 95 271
add 1 95 271
assign 1 95 272
addStep 1 95 272
assign 1 96 273
copy 0 96 273
assign 1 96 274
new 0 96 274
assign 1 96 275
add 1 96 275
assign 1 96 276
addStep 1 96 276
assign 1 97 277
copy 0 97 277
assign 1 97 278
add 1 97 278
assign 1 97 279
addStep 1 97 279
assign 1 98 280
copy 0 98 280
assign 1 98 281
new 0 98 281
assign 1 98 282
add 1 98 282
assign 1 98 283
addStep 1 98 283
assign 1 108 290
new 0 108 290
addStep 1 109 291
assign 1 110 292
iteratorGet 0 110 292
assign 1 110 295
hasNextGet 0 110 295
assign 1 111 297
nextGet 0 111 297
addStep 1 111 298
return 1 0 307
return 1 0 310
assign 1 0 313
assign 1 0 317
return 1 0 321
return 1 0 324
assign 1 0 327
assign 1 0 331
return 1 0 335
return 1 0 338
assign 1 0 341
assign 1 0 345
return 1 0 349
return 1 0 352
assign 1 0 355
assign 1 0 359
return 1 0 363
return 1 0 366
assign 1 0 369
assign 1 0 373
return 1 0 377
return 1 0 380
assign 1 0 383
assign 1 0 387
return 1 0 391
return 1 0 394
assign 1 0 397
assign 1 0 401
return 1 0 405
return 1 0 408
assign 1 0 411
assign 1 0 415
return 1 0 419
return 1 0 422
assign 1 0 425
assign 1 0 429
return 1 0 433
return 1 0 436
assign 1 0 439
assign 1 0 443
return 1 0 447
return 1 0 450
assign 1 0 453
assign 1 0 457
return 1 0 461
return 1 0 464
assign 1 0 467
assign 1 0 471
return 1 0 475
return 1 0 478
assign 1 0 481
assign 1 0 485
return 1 0 489
return 1 0 492
assign 1 0 495
assign 1 0 499
return 1 0 503
return 1 0 506
assign 1 0 509
assign 1 0 513
return 1 0 517
return 1 0 520
assign 1 0 523
assign 1 0 527
return 1 0 531
return 1 0 534
assign 1 0 537
assign 1 0 541
return 1 0 545
return 1 0 548
assign 1 0 551
assign 1 0 555
return 1 0 559
return 1 0 562
assign 1 0 565
assign 1 0 569
return 1 0 573
return 1 0 576
assign 1 0 579
assign 1 0 583
return 1 0 587
return 1 0 590
assign 1 0 593
assign 1 0 597
return 1 0 601
return 1 0 604
assign 1 0 607
assign 1 0 611
return 1 0 615
return 1 0 618
assign 1 0 621
assign 1 0 625
return 1 0 629
return 1 0 632
assign 1 0 635
assign 1 0 639
return 1 0 643
return 1 0 646
assign 1 0 649
assign 1 0 653
return 1 0 657
return 1 0 660
assign 1 0 663
assign 1 0 667
return 1 0 671
return 1 0 674
assign 1 0 677
assign 1 0 681
return 1 0 685
return 1 0 688
assign 1 0 691
assign 1 0 695
return 1 0 699
return 1 0 702
assign 1 0 705
assign 1 0 709
return 1 0 713
return 1 0 716
assign 1 0 719
assign 1 0 723
return 1 0 727
return 1 0 730
assign 1 0 733
assign 1 0 737
return 1 0 741
return 1 0 744
assign 1 0 747
assign 1 0 751
return 1 0 755
return 1 0 758
assign 1 0 761
assign 1 0 765
return 1 0 769
return 1 0 772
assign 1 0 775
assign 1 0 779
return 1 0 783
return 1 0 786
assign 1 0 789
assign 1 0 793
return 1 0 797
return 1 0 800
assign 1 0 803
assign 1 0 807
return 1 0 811
return 1 0 814
assign 1 0 817
assign 1 0 821
return 1 0 825
return 1 0 828
assign 1 0 831
assign 1 0 835
return 1 0 839
return 1 0 842
assign 1 0 845
assign 1 0 849
return 1 0 853
return 1 0 856
assign 1 0 859
assign 1 0 863
return 1 0 867
return 1 0 870
assign 1 0 873
assign 1 0 877
return 1 0 881
return 1 0 884
assign 1 0 887
assign 1 0 891
return 1 0 895
return 1 0 898
assign 1 0 901
assign 1 0 905
return 1 0 909
return 1 0 912
assign 1 0 915
assign 1 0 919
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 5832831: return bem_classSrcGet_0();
case 2042182232: return bem_libNotNullInitDoneGet_0();
case 484230991: return bem_midNameGet_0();
case 1573284344: return bem_classOGet_0();
case 1146667411: return bem_shFileNameGetDirect_0();
case -799062726: return bem_makeSrcGetDirect_0();
case 1668616199: return bem_libnameDataClearGetDirect_0();
case 84695890: return bem_emitterGet_0();
case -1264130095: return bem_unitShlibGet_0();
case 1125378492: return bem_nparGetDirect_0();
case 229011036: return bem_kbaseGet_0();
case 719042504: return bem_unitExeGet_0();
case -764486101: return bem_classExeOGetDirect_0();
case 1668274646: return bem_synSrcGetDirect_0();
case 1368903753: return bem_classIncHGet_0();
case -1779592094: return bem_cuinitHGetDirect_0();
case 1665960093: return bem_namesOGetDirect_0();
case -92397232: return bem_libnameDataDoneGetDirect_0();
case 38127485: return bem_iteratorGet_0();
case 724926264: return bem_lbaseGet_0();
case -190671676: return bem_cproGetDirect_0();
case 2061432375: return bem_tagGet_0();
case 715992415: return bem_nbaseGet_0();
case 883075495: return bem_namesOGet_0();
case 854710191: return bem_create_0();
case -99022728: return bem_unitExeGetDirect_0();
case 1398295791: return bem_classExeOGet_0();
case -115077593: return bem_emitterGetDirect_0();
case 1751802557: return bem_libnameDataGetDirect_0();
case 1159261448: return bem_classSrcHGetDirect_0();
case -593469656: return bem_sourceFileNameGet_0();
case -682359229: return bem_unitShlibGetDirect_0();
case -22788464: return bem_hashGet_0();
case -619895860: return bem_classSrcHGet_0();
case -1772212888: return bem_libnameInitDoneGet_0();
case -258158542: return bem_nparStepsGetDirect_0();
case -1278524785: return bem_lbaseGetDirect_0();
case 1502349257: return bem_classExeSrcGetDirect_0();
case -904597055: return bem_shClassNameGet_0();
case -625687222: return bem_npGet_0();
case -1431864677: return bem_libnameDataClearGet_0();
case -1107657411: return bem_emitPathGetDirect_0();
case 1204078843: return bem_basePathGet_0();
case -224382236: return bem_clBaseGet_0();
case 1010524993: return bem_libNotNullInitGet_0();
case -269885874: return bem_kbaseGetDirect_0();
case 1173940662: return bem_cldefNameGetDirect_0();
case 1554877035: return bem_cuBaseGet_0();
case -852928372: return bem_libnameDataGet_0();
case -1818293830: return bem_fieldNamesGet_0();
case -1937227753: return bem_xbaseGetDirect_0();
case 636345: return bem_print_0();
case 1958739924: return bem_basePathGetDirect_0();
case 888671685: return bem_shClassNameGetDirect_0();
case -1166187248: return bem_incBlockGet_0();
case -825294139: return bem_libnameInitGet_0();
case -1827483289: return bem_namesIncHGetDirect_0();
case 1171213682: return bem_cldefNameGet_0();
case -1053197013: return bem_xbaseGet_0();
case -667879177: return bem_cldefBuildGet_0();
case -500283631: return bem_nsDirGet_0();
case -1095481117: return bem_libNotNullInitDoneGetDirect_0();
case 1294872422: return bem_nparGet_0();
case -1354681063: return bem_makeSrcGet_0();
case -394720589: return bem_classExeSrcGet_0();
case -951416910: return bem_mtdNameGetDirect_0();
case 1847639727: return bem_new_0();
case 641560842: return bem_clBaseGetDirect_0();
case 793589441: return bem_classNameGet_0();
case 1764729221: return bem_classOGetDirect_0();
case -1593344693: return bem_unitExeLinkGet_0();
case -2025700595: return bem_synSrcGet_0();
case -903775775: return bem_cldefBuildGetDirect_0();
case -45763: return bem_cuBaseGetDirect_0();
case -1087794039: return bem_nsDirGetDirect_0();
case -334904494: return bem_nbaseGetDirect_0();
case 1143261203: return bem_classSrcGetDirect_0();
case -833254284: return bem_incBlockGetDirect_0();
case -2032749368: return bem_cuinitGetDirect_0();
case -1956487305: return bem_npGetDirect_0();
case -471567773: return bem_shFileNameGet_0();
case -1331374769: return bem_toString_0();
case 1740845732: return bem_midNameGetDirect_0();
case -1632877188: return bem_emitPathGet_0();
case -2141764470: return bem_clNameGet_0();
case -1035420468: return bem_libNotNullInitGetDirect_0();
case 2143588211: return bem_nparStepsGet_0();
case -1996405947: return bem_libnameInitDoneGetDirect_0();
case 1644596716: return bem_libnameInitGetDirect_0();
case -1508036637: return bem_copy_0();
case -930713116: return bem_namesIncHGet_0();
case 1324156963: return bem_clNameGetDirect_0();
case -1561206068: return bem_unitExeLinkGetDirect_0();
case -268586142: return bem_classIncHGetDirect_0();
case -917921033: return bem_mtdNameGet_0();
case 756185995: return bem_libnameDataDoneGet_0();
case 1396739376: return bem_cuinitHGet_0();
case 140395206: return bem_cuinitGet_0();
case -173662286: return bem_cproGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -543917297: return bem_makeSrcSet_1(bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
case -1393015462: return bem_libNotNullInitSetDirect_1(bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case -1729975441: return bem_nsDirSet_1(bevd_0);
case -1792785846: return bem_npSetDirect_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case -1709336290: return bem_basePathSet_1(bevd_0);
case 523479891: return bem_shClassNameSet_1(bevd_0);
case -31004535: return bem_cuinitHSetDirect_1(bevd_0);
case -738720805: return bem_synSrcSetDirect_1(bevd_0);
case 444143719: return bem_classSrcHSetDirect_1(bevd_0);
case 2090871247: return bem_mtdNameSet_1(bevd_0);
case 1114749466: return bem_nsDirSetDirect_1(bevd_0);
case 2098434636: return bem_incBlockSet_1(bevd_0);
case -1351975687: return bem_libnameInitSet_1(bevd_0);
case 1075585713: return bem_libNotNullInitDoneSetDirect_1(bevd_0);
case -1210148198: return bem_cuBaseSetDirect_1(bevd_0);
case -81318251: return bem_libnameDataClearSet_1(bevd_0);
case -1694644463: return bem_unitShlibSet_1(bevd_0);
case -717341503: return bem_npSet_1(bevd_0);
case -1491381035: return bem_classExeSrcSetDirect_1(bevd_0);
case 430820999: return bem_libnameDataSetDirect_1(bevd_0);
case 831971210: return bem_cproSet_1(bevd_0);
case 1633430227: return bem_unitExeLinkSet_1(bevd_0);
case -937952216: return bem_classOSetDirect_1(bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 67736270: return bem_cuBaseSet_1(bevd_0);
case 132385167: return bem_shFileNameSetDirect_1(bevd_0);
case 411073861: return bem_namesIncHSetDirect_1(bevd_0);
case -1498761938: return bem_classSrcSet_1(bevd_0);
case -338454315: return bem_cuinitSetDirect_1(bevd_0);
case -1631075580: return bem_classExeSrcSet_1(bevd_0);
case 807188727: return bem_emitPathSetDirect_1(bevd_0);
case -1436765347: return bem_kbaseSet_1(bevd_0);
case 292389848: return bem_nbaseSetDirect_1(bevd_0);
case 666027766: return bem_incBlockSetDirect_1(bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
case 1301194295: return bem_nparSet_1(bevd_0);
case -1975139555: return bem_classExeOSetDirect_1(bevd_0);
case -1688922768: return bem_xbaseSetDirect_1(bevd_0);
case 768417696: return bem_makeSrcSetDirect_1(bevd_0);
case 153558294: return bem_cldefNameSet_1(bevd_0);
case -78793441: return bem_unitExeSet_1(bevd_0);
case 1799778839: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case -1616073924: return bem_classIncHSetDirect_1(bevd_0);
case 2032939192: return bem_classSrcHSet_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case 1664570578: return bem_clNameSet_1(bevd_0);
case -479412916: return bem_classSrcSetDirect_1(bevd_0);
case 682463898: return bem_namesOSet_1(bevd_0);
case 1296625343: return bem_synSrcSet_1(bevd_0);
case 2043417197: return bem_cldefBuildSetDirect_1(bevd_0);
case -517011268: return bem_kbaseSetDirect_1(bevd_0);
case -1319178261: return bem_libnameInitSetDirect_1(bevd_0);
case -1938496248: return bem_classIncHSet_1(bevd_0);
case 1152921811: return bem_namesOSetDirect_1(bevd_0);
case -1701544651: return bem_clBaseSet_1(bevd_0);
case -512654779: return bem_unitShlibSetDirect_1(bevd_0);
case -1634804160: return bem_libnameDataClearSetDirect_1(bevd_0);
case 1638353071: return bem_libNotNullInitSet_1(bevd_0);
case -696291458: return bem_clNameSetDirect_1(bevd_0);
case 2035781808: return bem_emitterSetDirect_1(bevd_0);
case 1974115785: return bem_unitExeSetDirect_1(bevd_0);
case -921351528: return bem_midNameSet_1(bevd_0);
case 1905746187: return bem_cldefBuildSet_1(bevd_0);
case 321810662: return bem_libNotNullInitDoneSet_1(bevd_0);
case -1431043774: return bem_nparStepsSetDirect_1(bevd_0);
case -877506807: return bem_libnameDataSet_1(bevd_0);
case 499921913: return bem_basePathSetDirect_1(bevd_0);
case -561159966: return bem_libnameDataDoneSetDirect_1(bevd_0);
case -560580131: return bem_emitPathSet_1(bevd_0);
case -313733455: return bem_midNameSetDirect_1(bevd_0);
case -125270821: return bem_lbaseSetDirect_1(bevd_0);
case -56174094: return bem_unitExeLinkSetDirect_1(bevd_0);
case -936490675: return bem_shFileNameSet_1(bevd_0);
case -1025813963: return bem_namesIncHSet_1(bevd_0);
case 278667015: return bem_libnameInitDoneSet_1(bevd_0);
case 1063342556: return bem_nparStepsSet_1(bevd_0);
case 1721104115: return bem_libnameInitDoneSetDirect_1(bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case -1942331493: return bem_nbaseSet_1(bevd_0);
case -2585433: return bem_xbaseSet_1(bevd_0);
case -502376443: return bem_equals_1(bevd_0);
case 1673308560: return bem_mtdNameSetDirect_1(bevd_0);
case 1191259809: return bem_classExeOSet_1(bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case -52741127: return bem_lbaseSet_1(bevd_0);
case 1232677054: return bem_cproSetDirect_1(bevd_0);
case 645443455: return bem_clBaseSetDirect_1(bevd_0);
case -1662781530: return bem_libnameDataDoneSet_1(bevd_0);
case 1376213459: return bem_shClassNameSetDirect_1(bevd_0);
case 538814401: return bem_cuinitSet_1(bevd_0);
case 631040018: return bem_cldefNameSetDirect_1(bevd_0);
case 174505512: return bem_classOSet_1(bevd_0);
case 893460647: return bem_emitterSet_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case 1699747923: return bem_cuinitHSet_1(bevd_0);
case -203226612: return bem_nparSetDirect_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -552756560: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1521301043: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildClassInfo();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_type;
}
}
