package be;
public class BET_2_5_8_BuildEmitData extends BETS_Object {
public BET_2_5_8_BuildEmitData() {String[] bevs_mtnames = new String[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "addSynClass_2", "addParsedClass_1", "ptspGet_0", "ptspSet_1", "allNamesGet_0", "allNamesSet_1", "foreignClassesGet_0", "foreignClassesSet_1", "nameEntriesGet_0", "nameEntriesSet_1", "classesGet_0", "classesSet_1", "parseOrderClassNamesGet_0", "parseOrderClassNamesSet_1", "justParsedGet_0", "justParsedSet_1", "synClassesGet_0", "synClassesSet_1", "midNamesGet_0", "midNamesSet_1", "usedByGet_0", "usedBySet_1", "subClassesGet_0", "subClassesSet_1", "propertyIndexesGet_0", "propertyIndexesSet_1", "methodIndexesGet_0", "methodIndexesSet_1", "shouldEmitGet_0", "shouldEmitSet_1", "aliasedGet_0", "aliasedSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_8_BuildEmitData();
}
}
