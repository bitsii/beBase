package be;
public class BET_2_5_8_BuildEmitData extends BETS_Object {
public BET_2_5_8_BuildEmitData() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "sameType_1", "otherType_1", "addSynClass_2", "addParsedClass_1", "ptspGet_0", "ptspSet_1", "allNamesGet_0", "allNamesSet_1", "foreignClassesGet_0", "foreignClassesSet_1", "nameEntriesGet_0", "nameEntriesSet_1", "classesGet_0", "classesSet_1", "parseOrderClassNamesGet_0", "parseOrderClassNamesSet_1", "justParsedGet_0", "justParsedSet_1", "synClassesGet_0", "synClassesSet_1", "midNamesGet_0", "midNamesSet_1", "usedByGet_0", "usedBySet_1", "subClassesGet_0", "subClassesSet_1", "propertyIndexesGet_0", "propertyIndexesSet_1", "methodIndexesGet_0", "methodIndexesSet_1", "shouldEmitGet_0", "shouldEmitSet_1", "aliasedGet_0", "aliasedSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "ptsp", "allNames", "foreignClasses", "nameEntries", "classes", "parseOrderClassNames", "justParsed", "synClasses", "midNames", "usedBy", "subClasses", "propertyIndexes", "methodIndexes", "shouldEmit", "aliased" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_8_BuildEmitData();
}
}
