package be;
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerQueue extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerQueue() { }
private static byte[] becc_BEC_2_9_5_ContainerQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_5_ContainerQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_inst;
public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_bottom;
public BEC_3_9_5_4_ContainerStackNode bevp_end;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_9_5_ContainerQueue bem_new_0() throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_addValue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
bem_enqueue_1(beva_item);
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevp_top = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_end = bevp_top;
bevp_bottom = bevp_top;
} /* Line: 129 */
 else  /* Line: 126 */ {
if (bevp_bottom == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_4_tmpany_phold = (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
bevp_end = bevp_top;
} /* Line: 135 */
 else  /* Line: 136 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 137 */
} /* Line: 131 */
 else  /* Line: 139 */ {
bevp_bottom = bevp_top;
} /* Line: 140 */
} /* Line: 126 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dequeue_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_item = null;
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 147 */ {
return null;
} /* Line: 148 */
bevl_item = bevp_bottom.bem_heldGet_0();
bevp_bottom.bem_heldSet_1(null);
bevt_1_tmpany_phold = bevp_bottom.bem_equals_1(bevp_top);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevp_bottom = null;
} /* Line: 153 */
 else  /* Line: 154 */ {
bevl_last = bevp_bottom;
bevp_bottom = bevp_bottom.bem_nextGet_0();
bevl_last.bem_nextSet_1(null);
bevl_last.bem_priorSet_1(bevp_end);
bevp_end.bem_nextSet_1(bevl_last);
bevp_end = bevl_last;
} /* Line: 161 */
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_dequeue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_item) throws Throwable {
BEC_2_9_5_ContainerQueue bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_enqueue_1(beva_item);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_bottomGet_0() throws Throwable {
return bevp_bottom;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_bottomSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_endGet_0() throws Throwable {
return bevp_end;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_endSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {116, 122, 126, 126, 127, 128, 129, 130, 130, 131, 131, 131, 132, 132, 133, 133, 134, 135, 137, 140, 142, 143, 147, 147, 148, 150, 151, 152, 153, 156, 157, 158, 159, 160, 161, 163, 164, 168, 168, 172, 172, 176, 176, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 17, 27, 32, 33, 34, 35, 38, 43, 44, 45, 50, 51, 52, 53, 54, 55, 56, 59, 63, 66, 67, 75, 80, 81, 83, 84, 85, 87, 90, 91, 92, 93, 94, 95, 97, 98, 102, 107, 111, 112, 116, 117, 120, 123, 127, 130, 134, 137, 141, 144};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 116 13
new 0 116 13
enqueue 1 122 17
assign 1 126 27
undef 1 126 32
assign 1 127 33
new 0 127 33
assign 1 128 34
assign 1 129 35
assign 1 130 38
def 1 130 43
assign 1 131 44
nextGet 0 131 44
assign 1 131 45
undef 1 131 50
assign 1 132 51
new 0 132 51
nextSet 1 132 52
assign 1 133 53
nextGet 0 133 53
priorSet 1 133 54
assign 1 134 55
nextGet 0 134 55
assign 1 135 56
assign 1 137 59
nextGet 0 137 59
assign 1 140 63
heldSet 1 142 66
assign 1 143 67
increment 0 143 67
assign 1 147 75
undef 1 147 80
return 1 148 81
assign 1 150 83
heldGet 0 150 83
heldSet 1 151 84
assign 1 152 85
equals 1 152 85
assign 1 153 87
assign 1 156 90
assign 1 157 91
nextGet 0 157 91
nextSet 1 158 92
priorSet 1 159 93
nextSet 1 160 94
assign 1 161 95
assign 1 163 97
decrement 0 163 97
return 1 164 98
assign 1 168 102
undef 1 168 107
return 1 168 107
assign 1 172 111
dequeue 0 172 111
return 1 172 112
assign 1 176 116
enqueue 1 176 116
return 1 176 117
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2092326455: return bem_many_0();
case 65678538: return bem_echo_0();
case -1620819332: return bem_once_0();
case 1342246094: return bem_print_0();
case -117420215: return bem_serializeContents_0();
case -1197182710: return bem_serializeToString_0();
case 1637405965: return bem_toString_0();
case -261636586: return bem_classNameGet_0();
case 1658417978: return bem_endGet_0();
case 1053098123: return bem_hashGet_0();
case -1975952737: return bem_tagGet_0();
case 386788561: return bem_new_0();
case 866679447: return bem_serializationIteratorGet_0();
case 1579880073: return bem_dequeue_0();
case 168705805: return bem_iteratorGet_0();
case 934734695: return bem_topGet_0();
case 845917022: return bem_fieldIteratorGet_0();
case 1889003157: return bem_get_0();
case -368356400: return bem_sizeGet_0();
case -1555805672: return bem_isEmptyGet_0();
case 582818432: return bem_create_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -1712633963: return bem_toAny_0();
case -935771084: return bem_sourceFileNameGet_0();
case 1449516553: return bem_copy_0();
case 1178719053: return bem_bottomGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1921133350: return bem_defined_1(bevd_0);
case 701099552: return bem_addValue_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case 1210918104: return bem_topSet_1(bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case -887511763: return bem_bottomSet_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case 850650222: return bem_sizeSet_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
case -1916249935: return bem_endSet_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2048862996: return bem_put_1(bevd_0);
case 1199383199: return bem_enqueue_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerQueue_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerQueue_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerQueue();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst = (BEC_2_9_5_ContainerQueue) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst;
}
}
