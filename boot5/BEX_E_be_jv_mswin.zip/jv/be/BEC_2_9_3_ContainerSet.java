package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 232*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 233*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 240*/
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
/* Line: 258*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-951134133);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 261*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 262*/
} /* Line: 261*/
} /* Line: 260*/
 else /* Line: 258*/ {
break;
} /* Line: 258*/
} /* Line: 258*/
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_sizeGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_nslots = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
/* Line: 273*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-951134133);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 273*/ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 275*/
 else /* Line: 273*/ {
break;
} /* Line: 273*/
} /* Line: 273*/
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 281*/ {
bevt_4_ta_ph = beva_other.bem_sizeGet_0();
bevt_5_ta_ph = bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 281*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 281*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 282*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 284*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 284*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_has_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 285*/
} /* Line: 285*/
 else /* Line: 284*/ {
break;
} /* Line: 284*/
} /* Line: 284*/
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 292*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 294*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 295*/
} /* Line: 294*/
 else /* Line: 297*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(1427187093);
} /* Line: 298*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 302*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 304*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 306*/
 else /* Line: 307*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 308*/
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 311*/
 else /* Line: 304*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 312*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 313*/
 else /* Line: 304*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 314*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 318*/
 else /* Line: 319*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 322*/
} /* Line: 321*/
} /* Line: 304*/
} /* Line: 304*/
} /* Line: 304*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-951134133);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 329*/ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 332*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-951134133);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 332*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 333*/
 else /* Line: 332*/ {
break;
} /* Line: 332*/
} /* Line: 332*/
bevp_slots = bevl_slt;
} /* Line: 335*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 337*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 338*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 346*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 347*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 351*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 353*/ {
return null;
} /* Line: 354*/
 else /* Line: 353*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 355*/ {
return null;
} /* Line: 356*/
 else /* Line: 353*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 357*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 358*/
 else /* Line: 359*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 361*/ {
return null;
} /* Line: 362*/
} /* Line: 361*/
} /* Line: 353*/
} /* Line: 353*/
} /* Line: 353*/
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 372*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 373*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 377*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 380*/
 else /* Line: 379*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 381*/ {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 382*/
 else /* Line: 379*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 383*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 384*/
 else /* Line: 385*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 387*/ {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /* Line: 388*/
} /* Line: 387*/
} /* Line: 379*/
} /* Line: 379*/
} /* Line: 379*/
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 399*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 400*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 404*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 406*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 407*/
 else /* Line: 406*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 409*/
 else /* Line: 406*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 410*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
/* Line: 414*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 414*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_15_ta_ph = bevl_n.bem_hvalGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_14_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 416*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 416*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_16_ta_ph;
} /* Line: 417*/
 else /* Line: 418*/ {
bevt_18_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_17_ta_ph = bevl_sl.bem_subtract_1(bevt_18_ta_ph);
bevl_slt.bem_put_2(bevt_17_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 420*/
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 422*/
 else /* Line: 414*/ {
break;
} /* Line: 414*/
} /* Line: 414*/
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_19_ta_ph;
} /* Line: 424*/
 else /* Line: 425*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 427*/ {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_21_ta_ph;
} /* Line: 428*/
} /* Line: 427*/
} /* Line: 406*/
} /* Line: 406*/
} /* Line: 406*/
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = bevp_slots.bem_copy_0();
bevl_other.bemd_1(-1598460472, bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 439*/ {
bevt_2_ta_ph = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 439*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 441*/ {
bevt_4_ta_ph = bevl_other.bemd_0(516529341);
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_8_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevl_n.bem_getFrom_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_new_3(bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
bevt_4_ta_ph.bemd_2(-778867782, bevl_i, bevt_5_ta_ph);
} /* Line: 442*/
 else /* Line: 443*/ {
bevt_10_ta_ph = bevl_other.bemd_0(516529341);
bevt_10_ta_ph.bemd_2(-778867782, bevl_i, null);
} /* Line: 444*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 439*/
 else /* Line: 439*/ {
break;
} /* Line: 439*/
} /* Line: 439*/
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_slots.bem_sizeSet_1(bevp_modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 483*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 484*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 484*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_has_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 485*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 486*/
} /* Line: 485*/
 else /* Line: 484*/ {
break;
} /* Line: 484*/
} /* Line: 484*/
} /* Line: 484*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 495*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 495*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 496*/
 else /* Line: 495*/ {
break;
} /* Line: 495*/
} /* Line: 495*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 498*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 499*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 499*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 500*/
 else /* Line: 499*/ {
break;
} /* Line: 499*/
} /* Line: 499*/
} /* Line: 499*/
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 513*/ {
bevt_2_ta_ph = beva_other.bemd_1(1706172624, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 514*/ {
bevt_0_ta_loop = beva_other.bemd_0(1400956038);
while (true)
/* Line: 515*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(665623324);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 515*/ {
bevl_x = bevt_0_ta_loop.bemd_0(303181667);
bem_put_1(bevl_x);
} /* Line: 516*/
 else /* Line: 515*/ {
break;
} /* Line: 515*/
} /* Line: 515*/
} /* Line: 515*/
 else /* Line: 514*/ {
bevt_4_ta_ph = beva_other.bemd_1(1706172624, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 518*/ {
bevt_5_ta_ph = beva_other.bemd_0(-506438029);
bem_put_1(bevt_5_ta_ph);
} /* Line: 519*/
 else /* Line: 520*/ {
bem_put_1(beva_other);
} /* Line: 521*/
} /* Line: 514*/
} /* Line: 514*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_slotsGetDirect_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public final BEC_2_4_3_MathInt bem_moduGetDirect_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public final BEC_2_4_3_MathInt bem_multiGetDirect_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_multiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public final BEC_3_9_3_9_ContainerSetRelations bem_relGetDirect_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_relSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public final BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGetDirect_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_baseNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_innerPutAddedGetDirect_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_innerPutAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {214, 214, 220, 221, 222, 223, 224, 225, 226, 232, 232, 232, 233, 233, 235, 235, 239, 239, 239, 240, 240, 242, 242, 246, 246, 250, 250, 254, 254, 258, 258, 259, 260, 260, 261, 261, 261, 262, 262, 266, 266, 271, 271, 271, 271, 272, 273, 273, 274, 275, 277, 281, 281, 0, 281, 281, 281, 281, 0, 0, 282, 282, 284, 0, 284, 284, 285, 285, 285, 285, 285, 287, 287, 291, 292, 292, 293, 294, 294, 294, 295, 298, 300, 301, 303, 304, 304, 305, 305, 306, 306, 306, 308, 310, 311, 311, 312, 312, 312, 312, 313, 313, 314, 314, 315, 317, 318, 318, 320, 321, 321, 322, 322, 329, 329, 330, 331, 332, 332, 333, 335, 338, 343, 344, 345, 346, 346, 346, 347, 349, 350, 352, 353, 353, 354, 355, 355, 355, 355, 356, 357, 357, 358, 358, 360, 361, 361, 362, 369, 370, 371, 372, 372, 372, 373, 375, 376, 378, 379, 379, 380, 380, 381, 381, 381, 381, 382, 382, 383, 383, 384, 384, 386, 387, 387, 388, 388, 395, 396, 398, 399, 399, 399, 400, 402, 403, 405, 406, 406, 407, 407, 408, 408, 408, 408, 409, 409, 410, 410, 411, 412, 413, 414, 414, 415, 416, 416, 0, 416, 416, 416, 416, 0, 0, 417, 417, 419, 419, 419, 420, 422, 424, 424, 426, 427, 427, 428, 428, 436, 437, 438, 438, 439, 439, 439, 439, 440, 441, 441, 442, 442, 442, 442, 442, 442, 442, 444, 444, 439, 447, 452, 453, 454, 458, 458, 462, 462, 466, 466, 470, 470, 474, 474, 478, 478, 482, 483, 483, 484, 0, 484, 484, 485, 486, 490, 494, 495, 0, 495, 495, 496, 498, 498, 499, 0, 499, 499, 500, 503, 507, 508, 509, 513, 513, 514, 515, 0, 515, 515, 516, 518, 519, 519, 521, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 27, 28, 29, 30, 31, 39, 40, 45, 46, 47, 49, 50, 57, 58, 63, 64, 65, 67, 68, 72, 73, 77, 78, 83, 84, 96, 99, 101, 102, 107, 108, 109, 110, 112, 113, 121, 122, 132, 133, 134, 135, 136, 139, 140, 142, 143, 149, 165, 170, 171, 174, 175, 176, 181, 182, 185, 189, 190, 192, 192, 195, 197, 198, 199, 204, 205, 206, 213, 214, 239, 240, 245, 246, 247, 248, 253, 254, 258, 260, 261, 264, 265, 270, 271, 276, 277, 278, 279, 282, 284, 285, 286, 289, 290, 291, 296, 297, 298, 301, 302, 304, 305, 306, 307, 310, 311, 316, 317, 318, 331, 332, 334, 335, 338, 339, 341, 347, 350, 371, 372, 373, 374, 375, 380, 381, 383, 384, 387, 388, 393, 394, 397, 398, 399, 404, 405, 408, 409, 411, 412, 415, 416, 421, 422, 449, 450, 451, 452, 453, 458, 459, 461, 462, 465, 466, 471, 472, 473, 476, 477, 478, 483, 484, 485, 488, 489, 491, 492, 495, 496, 501, 502, 503, 539, 540, 541, 542, 543, 548, 549, 551, 552, 555, 556, 561, 562, 563, 566, 567, 568, 573, 574, 575, 578, 579, 581, 582, 583, 586, 591, 592, 593, 598, 599, 602, 603, 604, 609, 610, 613, 617, 618, 621, 622, 623, 624, 626, 632, 633, 636, 637, 642, 643, 644, 666, 667, 668, 669, 670, 673, 674, 679, 680, 681, 686, 687, 688, 689, 690, 691, 692, 693, 696, 697, 699, 705, 708, 709, 710, 715, 716, 720, 721, 725, 726, 730, 731, 735, 736, 740, 741, 750, 751, 756, 757, 757, 760, 762, 763, 765, 773, 783, 784, 784, 787, 789, 790, 796, 801, 802, 802, 805, 807, 808, 815, 819, 820, 821, 831, 836, 837, 839, 839, 842, 844, 845, 853, 855, 856, 859, 866, 869, 872, 876, 880, 883, 886, 890, 894, 897, 900, 904, 908, 911, 914, 918, 922, 925, 928, 932, 936, 939, 942, 946, 950, 953, 956, 960};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 214 20
new 0 214 20
new 1 214 21
assign 1 220 25
new 1 220 25
assign 1 221 26
assign 1 222 27
new 0 222 27
assign 1 223 28
new 0 223 28
assign 1 224 29
new 0 224 29
assign 1 225 30
new 0 225 30
assign 1 226 31
new 0 226 31
assign 1 232 39
new 0 232 39
assign 1 232 40
equals 1 232 45
assign 1 233 46
new 0 233 46
return 1 233 47
assign 1 235 49
new 0 235 49
return 1 235 50
assign 1 239 57
new 0 239 57
assign 1 239 58
equals 1 239 63
assign 1 240 64
new 0 240 64
return 1 240 65
assign 1 242 67
new 0 242 67
return 1 242 68
assign 1 246 72
toString 0 246 72
return 1 246 73
assign 1 250 77
new 1 250 77
new 1 250 78
assign 1 254 83
new 1 254 83
return 1 254 84
assign 1 258 96
arrayIteratorGet 0 258 96
assign 1 258 99
hasNextGet 0 258 99
assign 1 259 101
nextGet 0 259 101
assign 1 260 102
def 1 260 107
assign 1 261 108
keyGet 0 261 108
assign 1 261 109
innerPut 4 261 109
assign 1 261 110
not 0 261 110
assign 1 262 112
new 0 262 112
return 1 262 113
assign 1 266 121
new 0 266 121
return 1 266 122
assign 1 271 132
sizeGet 0 271 132
assign 1 271 133
multiply 1 271 133
assign 1 271 134
new 0 271 134
assign 1 271 135
add 1 271 135
assign 1 272 136
new 1 272 136
assign 1 273 139
insertAll 2 273 139
assign 1 273 140
not 0 273 140
assign 1 274 142
increment 0 274 142
assign 1 275 143
new 1 275 143
return 1 277 149
assign 1 281 165
undef 1 281 170
assign 1 0 171
assign 1 281 174
sizeGet 0 281 174
assign 1 281 175
sizeGet 0 281 175
assign 1 281 176
notEquals 1 281 181
assign 1 0 182
assign 1 0 185
assign 1 282 189
new 0 282 189
return 1 282 190
assign 1 284 192
setIteratorGet 0 0 192
assign 1 284 195
hasNextGet 0 284 195
assign 1 284 197
nextGet 0 284 197
assign 1 285 198
has 1 285 198
assign 1 285 199
not 0 285 204
assign 1 285 205
new 0 285 205
return 1 285 206
assign 1 287 213
new 0 287 213
return 1 287 214
assign 1 291 239
sizeGet 0 291 239
assign 1 292 240
undef 1 292 245
assign 1 293 246
getHash 1 293 246
assign 1 294 247
new 0 294 247
assign 1 294 248
lesser 1 294 253
assign 1 295 254
abs 0 295 254
assign 1 298 258
hvalGet 0 298 258
assign 1 300 260
modulus 1 300 260
assign 1 301 261
assign 1 303 264
get 1 303 264
assign 1 304 265
undef 1 304 270
assign 1 305 271
undef 1 305 276
assign 1 306 277
create 0 306 277
assign 1 306 278
new 3 306 278
put 2 306 279
put 2 308 282
assign 1 310 284
new 0 310 284
assign 1 311 285
new 0 311 285
return 1 311 286
assign 1 312 289
hvalGet 0 312 289
assign 1 312 290
modulus 1 312 290
assign 1 312 291
notEquals 1 312 296
assign 1 313 297
new 0 313 297
return 1 313 298
assign 1 314 301
keyGet 0 314 301
assign 1 314 302
isEqual 2 314 302
putTo 2 315 304
assign 1 317 305
new 0 317 305
assign 1 318 306
new 0 318 306
return 1 318 307
assign 1 320 310
increment 0 320 310
assign 1 321 311
greaterEquals 1 321 316
assign 1 322 317
new 0 322 317
return 1 322 318
assign 1 329 331
innerPut 4 329 331
assign 1 329 332
not 0 329 332
assign 1 330 334
assign 1 331 335
rehash 1 331 335
assign 1 332 338
innerPut 4 332 338
assign 1 332 339
not 0 332 339
assign 1 333 341
rehash 1 333 341
assign 1 335 347
assign 1 338 350
increment 0 338 350
assign 1 343 371
assign 1 344 372
sizeGet 0 344 372
assign 1 345 373
getHash 1 345 373
assign 1 346 374
new 0 346 374
assign 1 346 375
lesser 1 346 380
assign 1 347 381
abs 0 347 381
assign 1 349 383
modulus 1 349 383
assign 1 350 384
assign 1 352 387
get 1 352 387
assign 1 353 388
undef 1 353 393
return 1 354 394
assign 1 355 397
hvalGet 0 355 397
assign 1 355 398
modulus 1 355 398
assign 1 355 399
notEquals 1 355 404
return 1 356 405
assign 1 357 408
keyGet 0 357 408
assign 1 357 409
isEqual 2 357 409
assign 1 358 411
getFrom 0 358 411
return 1 358 412
assign 1 360 415
increment 0 360 415
assign 1 361 416
greaterEquals 1 361 421
return 1 362 422
assign 1 369 449
assign 1 370 450
sizeGet 0 370 450
assign 1 371 451
getHash 1 371 451
assign 1 372 452
new 0 372 452
assign 1 372 453
lesser 1 372 458
assign 1 373 459
abs 0 373 459
assign 1 375 461
modulus 1 375 461
assign 1 376 462
assign 1 378 465
get 1 378 465
assign 1 379 466
undef 1 379 471
assign 1 380 472
new 0 380 472
return 1 380 473
assign 1 381 476
hvalGet 0 381 476
assign 1 381 477
modulus 1 381 477
assign 1 381 478
notEquals 1 381 483
assign 1 382 484
new 0 382 484
return 1 382 485
assign 1 383 488
keyGet 0 383 488
assign 1 383 489
isEqual 2 383 489
assign 1 384 491
new 0 384 491
return 1 384 492
assign 1 386 495
increment 0 386 495
assign 1 387 496
greaterEquals 1 387 501
assign 1 388 502
new 0 388 502
return 1 388 503
assign 1 395 539
assign 1 396 540
sizeGet 0 396 540
assign 1 398 541
getHash 1 398 541
assign 1 399 542
new 0 399 542
assign 1 399 543
lesser 1 399 548
assign 1 400 549
abs 0 400 549
assign 1 402 551
modulus 1 402 551
assign 1 403 552
assign 1 405 555
get 1 405 555
assign 1 406 556
undef 1 406 561
assign 1 407 562
new 0 407 562
return 1 407 563
assign 1 408 566
hvalGet 0 408 566
assign 1 408 567
modulus 1 408 567
assign 1 408 568
notEquals 1 408 573
assign 1 409 574
new 0 409 574
return 1 409 575
assign 1 410 578
keyGet 0 410 578
assign 1 410 579
isEqual 2 410 579
put 2 411 581
assign 1 412 582
decrement 0 412 582
assign 1 413 583
increment 0 413 583
assign 1 414 586
lesser 1 414 591
assign 1 415 592
get 1 415 592
assign 1 416 593
undef 1 416 598
assign 1 0 599
assign 1 416 602
hvalGet 0 416 602
assign 1 416 603
modulus 1 416 603
assign 1 416 604
notEquals 1 416 609
assign 1 0 610
assign 1 0 613
assign 1 417 617
new 0 417 617
return 1 417 618
assign 1 419 621
new 0 419 621
assign 1 419 622
subtract 1 419 622
put 2 419 623
put 2 420 624
assign 1 422 626
increment 0 422 626
assign 1 424 632
new 0 424 632
return 1 424 633
assign 1 426 636
increment 0 426 636
assign 1 427 637
greaterEquals 1 427 642
assign 1 428 643
new 0 428 643
return 1 428 644
assign 1 436 666
create 0 436 666
copyTo 1 437 667
assign 1 438 668
copy 0 438 668
slotsSet 1 438 669
assign 1 439 670
new 0 439 670
assign 1 439 673
lengthGet 0 439 673
assign 1 439 674
lesser 1 439 679
assign 1 440 680
get 1 440 680
assign 1 441 681
def 1 441 686
assign 1 442 687
slotsGet 0 442 687
assign 1 442 688
create 0 442 688
assign 1 442 689
hvalGet 0 442 689
assign 1 442 690
keyGet 0 442 690
assign 1 442 691
getFrom 0 442 691
assign 1 442 692
new 3 442 692
put 2 442 693
assign 1 444 696
slotsGet 0 444 696
put 2 444 697
assign 1 439 699
increment 0 439 699
return 1 447 705
clear 0 452 708
sizeSet 1 453 709
assign 1 454 710
new 0 454 710
assign 1 458 715
new 1 458 715
return 1 458 716
assign 1 462 720
new 1 462 720
return 1 462 721
assign 1 466 725
new 1 466 725
return 1 466 726
assign 1 470 730
keyIteratorGet 0 470 730
return 1 470 731
assign 1 474 735
new 1 474 735
return 1 474 736
assign 1 478 740
nodeIteratorGet 0 478 740
return 1 478 741
assign 1 482 750
new 0 482 750
assign 1 483 751
def 1 483 756
assign 1 484 757
setIteratorGet 0 0 757
assign 1 484 760
hasNextGet 0 484 760
assign 1 484 762
nextGet 0 484 762
assign 1 485 763
has 1 485 763
put 1 486 765
return 1 490 773
assign 1 494 783
new 0 494 783
assign 1 495 784
setIteratorGet 0 0 784
assign 1 495 787
hasNextGet 0 495 787
assign 1 495 789
nextGet 0 495 789
put 1 496 790
assign 1 498 796
def 1 498 801
assign 1 499 802
setIteratorGet 0 0 802
assign 1 499 805
hasNextGet 0 499 805
assign 1 499 807
nextGet 0 499 807
put 1 500 808
return 1 503 815
assign 1 507 819
copy 0 507 819
addValue 1 508 820
return 1 509 821
assign 1 513 831
def 1 513 836
assign 1 514 837
sameType 1 514 837
assign 1 515 839
iteratorGet 0 0 839
assign 1 515 842
hasNextGet 0 515 842
assign 1 515 844
nextGet 0 515 844
put 1 516 845
assign 1 518 853
sameType 1 518 853
assign 1 519 855
keyGet 0 519 855
put 1 519 856
put 1 521 859
return 1 0 866
return 1 0 869
assign 1 0 872
assign 1 0 876
return 1 0 880
return 1 0 883
assign 1 0 886
assign 1 0 890
return 1 0 894
return 1 0 897
assign 1 0 900
assign 1 0 904
return 1 0 908
return 1 0 911
assign 1 0 914
assign 1 0 918
return 1 0 922
return 1 0 925
assign 1 0 928
assign 1 0 932
return 1 0 936
return 1 0 939
assign 1 0 942
assign 1 0 946
return 1 0 950
return 1 0 953
assign 1 0 956
assign 1 0 960
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1574006018: return bem_new_0();
case 1400956038: return bem_iteratorGet_0();
case -338202822: return bem_deserializeClassNameGet_0();
case -63388045: return bem_innerPutAddedGet_0();
case -931704592: return bem_nodeIteratorGet_0();
case 1221020955: return bem_multiGet_0();
case -1772053083: return bem_slotsGetDirect_0();
case -353923806: return bem_setIteratorGet_0();
case 1982260447: return bem_copy_0();
case 64969569: return bem_isEmptyGet_0();
case -436425250: return bem_sourceFileNameGet_0();
case -153348132: return bem_clear_0();
case 1375821928: return bem_serializeToString_0();
case 55049320: return bem_print_0();
case -426939704: return bem_keysGet_0();
case -2063813825: return bem_relGetDirect_0();
case 1940846657: return bem_nodesGet_0();
case 411688773: return bem_toString_0();
case -1045716169: return bem_baseNodeGetDirect_0();
case 879231054: return bem_classNameGet_0();
case -74182749: return bem_serializationIteratorGet_0();
case -464277223: return bem_sizeGetDirect_0();
case -272002283: return bem_serializeContents_0();
case 1862506291: return bem_notEmptyGet_0();
case -1609947385: return bem_echo_0();
case 1843425914: return bem_multiGetDirect_0();
case 2111340989: return bem_moduGet_0();
case 115209925: return bem_fieldIteratorGet_0();
case -2019788295: return bem_fieldNamesGet_0();
case 2127162183: return bem_relGet_0();
case 241030035: return bem_innerPutAddedGetDirect_0();
case -1273376981: return bem_keyIteratorGet_0();
case -1188577496: return bem_sizeGet_0();
case -1370457182: return bem_tagGet_0();
case 2045133666: return bem_moduGetDirect_0();
case 77682213: return bem_hashGet_0();
case -1445643632: return bem_baseNodeGet_0();
case -660861106: return bem_create_0();
case 516529341: return bem_slotsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1186857031: return bem_slotsSetDirect_1(bevd_0);
case -1903892968: return bem_equals_1(bevd_0);
case 943901544: return bem_baseNodeSet_1(bevd_0);
case -318666284: return bem_addValue_1(bevd_0);
case 138356423: return bem_innerPutAddedSet_1(bevd_0);
case 1277553622: return bem_def_1(bevd_0);
case -292252818: return bem_undef_1(bevd_0);
case 1716403917: return bem_relSet_1(bevd_0);
case -643607421: return bem_relSetDirect_1(bevd_0);
case 1724041773: return bem_notEquals_1(bevd_0);
case 691163553: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1020423162: return bem_otherClass_1(bevd_0);
case 843541338: return bem_sameObject_1(bevd_0);
case 103695285: return bem_has_1(bevd_0);
case 699493009: return bem_put_1(bevd_0);
case 1353776886: return bem_delete_1(bevd_0);
case -1547233575: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1386418824: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 420068993: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -545796780: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1253673578: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1030354071: return bem_moduSet_1(bevd_0);
case -1937138440: return bem_moduSetDirect_1(bevd_0);
case 1279545719: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1345869400: return bem_multiSet_1(bevd_0);
case 1560006190: return bem_copyTo_1(bevd_0);
case 1541786617: return bem_multiSetDirect_1(bevd_0);
case 1706172624: return bem_sameType_1(bevd_0);
case 462653776: return bem_sameClass_1(bevd_0);
case -1599697707: return bem_get_1(bevd_0);
case -1598460472: return bem_slotsSet_1(bevd_0);
case -2028195342: return bem_sizeSet_1(bevd_0);
case 1531126746: return bem_otherType_1(bevd_0);
case 1423522577: return bem_sizeSetDirect_1(bevd_0);
case -896451798: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 862684889: return bem_baseNodeSetDirect_1(bevd_0);
case -850580322: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -615227441: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1397786085: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1432975146: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 861664880: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 53516876: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -860737988: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1645563126: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1362496456: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
