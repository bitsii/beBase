package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_7 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 234 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /* Line: 241 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 259 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_4_tmpany_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpany_phold = bem_innerPut_4(bevt_4_tmpany_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 263 */
} /* Line: 262 */
} /* Line: 261 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_2;
bevl_nslots = bevt_0_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 274 */ {
bevt_4_tmpany_phold = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 274 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 276 */
 else  /* Line: 274 */ {
break;
} /* Line: 274 */
} /* Line: 274 */
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_other == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_4_tmpany_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpany_phold = bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 282 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 283 */
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 285 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_9_tmpany_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 286 */
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 296 */
} /* Line: 295 */
 else  /* Line: 298 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-1059232237);
} /* Line: 299 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 303 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 305 */ {
if (beva_inode == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpany_phold);
} /* Line: 307 */
 else  /* Line: 308 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 309 */
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 312 */
 else  /* Line: 305 */ {
bevt_10_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 313 */ {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /* Line: 314 */
 else  /* Line: 305 */ {
bevt_13_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 315 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /* Line: 319 */
 else  /* Line: 320 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 323 */
} /* Line: 322 */
} /* Line: 305 */
} /* Line: 305 */
} /* Line: 305 */
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 333 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1773122929);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 333 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 334 */
 else  /* Line: 333 */ {
break;
} /* Line: 333 */
} /* Line: 333 */
bevp_slots = bevl_slt;
} /* Line: 336 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 338 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 339 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 348 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 352 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 354 */ {
return null;
} /* Line: 355 */
 else  /* Line: 354 */ {
bevt_5_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 356 */ {
return null;
} /* Line: 357 */
 else  /* Line: 354 */ {
bevt_7_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 358 */ {
bevt_8_tmpany_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpany_phold;
} /* Line: 359 */
 else  /* Line: 360 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 362 */ {
return null;
} /* Line: 363 */
} /* Line: 362 */
} /* Line: 354 */
} /* Line: 354 */
} /* Line: 354 */
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 374 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 378 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 380 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 381 */
 else  /* Line: 380 */ {
bevt_6_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /* Line: 383 */
 else  /* Line: 380 */ {
bevt_9_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 384 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 385 */
 else  /* Line: 386 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /* Line: 389 */
} /* Line: 388 */
} /* Line: 380 */
} /* Line: 380 */
} /* Line: 380 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 400 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 401 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 405 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 407 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 408 */
 else  /* Line: 407 */ {
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 410 */
 else  /* Line: 407 */ {
bevt_10_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 415 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_15_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 417 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 417 */ {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_16_tmpany_phold;
} /* Line: 418 */
 else  /* Line: 419 */ {
bevt_18_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_7;
bevt_17_tmpany_phold = bevl_sl.bem_subtract_1(bevt_18_tmpany_phold);
bevl_slt.bem_put_2(bevt_17_tmpany_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 421 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 423 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_19_tmpany_phold;
} /* Line: 425 */
 else  /* Line: 426 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 428 */ {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_21_tmpany_phold;
} /* Line: 429 */
} /* Line: 428 */
} /* Line: 407 */
} /* Line: 407 */
} /* Line: 407 */
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(1779048441, bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
bevt_2_tmpany_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_4_tmpany_phold = bevl_other.bemd_0(-1909070982);
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_new_3(bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_4_tmpany_phold.bemd_2(-343510156, bevl_i, bevt_5_tmpany_phold);
} /* Line: 442 */
 else  /* Line: 443 */ {
bevt_10_tmpany_phold = bevl_other.bemd_0(-1909070982);
bevt_10_tmpany_phold.bemd_2(-343510156, bevl_i, null);
} /* Line: 444 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_keyIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_nodeIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 483 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 485 */
} /* Line: 484 */
 else  /* Line: 483 */ {
break;
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 483 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 494 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 494 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 495 */
 else  /* Line: 494 */ {
break;
} /* Line: 494 */
} /* Line: 494 */
if (beva_other == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevt_1_tmpany_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 498 */ {
bevt_4_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevl_x = bevt_1_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 499 */
 else  /* Line: 498 */ {
break;
} /* Line: 498 */
} /* Line: 498 */
} /* Line: 498 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(1420318580, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 513 */ {
bevt_0_tmpany_loop = beva_other.bemd_0(-612311095);
while (true)
 /* Line: 514 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1044268871);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 514 */ {
bevl_x = bevt_0_tmpany_loop.bemd_0(-1274688402);
bem_put_1(bevl_x);
} /* Line: 515 */
 else  /* Line: 514 */ {
break;
} /* Line: 514 */
} /* Line: 514 */
} /* Line: 514 */
 else  /* Line: 513 */ {
bevt_4_tmpany_phold = beva_other.bemd_1(1420318580, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(1879046512);
bem_put_1(bevt_5_tmpany_phold);
} /* Line: 518 */
 else  /* Line: 519 */ {
bem_put_1(beva_other);
} /* Line: 520 */
} /* Line: 513 */
} /* Line: 513 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {215, 215, 221, 222, 223, 224, 225, 226, 227, 233, 233, 233, 234, 234, 236, 236, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 255, 255, 259, 259, 260, 261, 261, 262, 262, 262, 263, 263, 267, 267, 272, 272, 272, 272, 273, 274, 274, 275, 276, 278, 282, 282, 0, 282, 282, 282, 282, 0, 0, 283, 283, 285, 0, 285, 285, 286, 286, 286, 286, 286, 288, 288, 292, 293, 293, 294, 295, 295, 295, 296, 299, 301, 302, 304, 305, 305, 306, 306, 307, 307, 307, 309, 311, 312, 312, 313, 313, 313, 313, 314, 314, 315, 315, 316, 318, 319, 319, 321, 322, 322, 323, 323, 330, 330, 331, 332, 333, 333, 334, 336, 339, 344, 345, 346, 347, 347, 347, 348, 350, 351, 353, 354, 354, 355, 356, 356, 356, 356, 357, 358, 358, 359, 359, 361, 362, 362, 363, 370, 371, 372, 373, 373, 373, 374, 376, 377, 379, 380, 380, 381, 381, 382, 382, 382, 382, 383, 383, 384, 384, 385, 385, 387, 388, 388, 389, 389, 396, 397, 399, 400, 400, 400, 401, 403, 404, 406, 407, 407, 408, 408, 409, 409, 409, 409, 410, 410, 411, 411, 412, 413, 414, 415, 415, 416, 417, 417, 0, 417, 417, 417, 417, 0, 0, 418, 418, 420, 420, 420, 421, 423, 425, 425, 427, 428, 428, 429, 429, 436, 437, 438, 438, 439, 439, 439, 439, 440, 441, 441, 442, 442, 442, 442, 442, 442, 442, 444, 444, 439, 447, 452, 453, 457, 457, 461, 461, 465, 465, 469, 469, 473, 473, 477, 477, 481, 482, 482, 483, 0, 483, 483, 484, 485, 489, 493, 494, 0, 494, 494, 495, 497, 497, 498, 0, 498, 498, 499, 502, 506, 507, 508, 512, 512, 513, 514, 0, 514, 514, 515, 517, 518, 518, 520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 30, 31, 32, 33, 34, 35, 36, 44, 45, 50, 51, 52, 54, 55, 62, 63, 68, 69, 70, 72, 73, 77, 78, 82, 83, 88, 89, 101, 104, 106, 107, 112, 113, 114, 115, 117, 118, 126, 127, 137, 138, 139, 140, 141, 144, 145, 147, 148, 154, 170, 175, 176, 179, 180, 181, 186, 187, 190, 194, 195, 197, 197, 200, 202, 203, 204, 209, 210, 211, 218, 219, 244, 245, 250, 251, 252, 253, 258, 259, 263, 265, 266, 269, 270, 275, 276, 281, 282, 283, 284, 287, 289, 290, 291, 294, 295, 296, 301, 302, 303, 306, 307, 309, 310, 311, 312, 315, 316, 321, 322, 323, 336, 337, 339, 340, 343, 344, 346, 352, 355, 376, 377, 378, 379, 380, 385, 386, 388, 389, 392, 393, 398, 399, 402, 403, 404, 409, 410, 413, 414, 416, 417, 420, 421, 426, 427, 454, 455, 456, 457, 458, 463, 464, 466, 467, 470, 471, 476, 477, 478, 481, 482, 483, 488, 489, 490, 493, 494, 496, 497, 500, 501, 506, 507, 508, 544, 545, 546, 547, 548, 553, 554, 556, 557, 560, 561, 566, 567, 568, 571, 572, 573, 578, 579, 580, 583, 584, 586, 587, 588, 591, 596, 597, 598, 603, 604, 607, 608, 609, 614, 615, 618, 622, 623, 626, 627, 628, 629, 631, 637, 638, 641, 642, 647, 648, 649, 671, 672, 673, 674, 675, 678, 679, 684, 685, 686, 691, 692, 693, 694, 695, 696, 697, 698, 701, 702, 704, 710, 713, 714, 719, 720, 724, 725, 729, 730, 734, 735, 739, 740, 744, 745, 754, 755, 760, 761, 761, 764, 766, 767, 769, 777, 787, 788, 788, 791, 793, 794, 800, 805, 806, 806, 809, 811, 812, 819, 823, 824, 825, 835, 840, 841, 843, 843, 846, 848, 849, 857, 859, 860, 863, 870, 873, 877, 880, 884, 887, 891, 894, 898, 901, 905, 908, 912, 915};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 215 25
new 0 215 25
new 1 215 26
assign 1 221 30
new 1 221 30
assign 1 222 31
assign 1 223 32
new 0 223 32
assign 1 224 33
new 0 224 33
assign 1 225 34
new 0 225 34
assign 1 226 35
new 0 226 35
assign 1 227 36
new 0 227 36
assign 1 233 44
new 0 233 44
assign 1 233 45
equals 1 233 50
assign 1 234 51
new 0 234 51
return 1 234 52
assign 1 236 54
new 0 236 54
return 1 236 55
assign 1 240 62
new 0 240 62
assign 1 240 63
equals 1 240 68
assign 1 241 69
new 0 241 69
return 1 241 70
assign 1 243 72
new 0 243 72
return 1 243 73
assign 1 247 77
toString 0 247 77
return 1 247 78
assign 1 251 82
new 1 251 82
new 1 251 83
assign 1 255 88
new 1 255 88
return 1 255 89
assign 1 259 101
arrayIteratorGet 0 259 101
assign 1 259 104
hasNextGet 0 259 104
assign 1 260 106
nextGet 0 260 106
assign 1 261 107
def 1 261 112
assign 1 262 113
keyGet 0 262 113
assign 1 262 114
innerPut 4 262 114
assign 1 262 115
not 0 262 115
assign 1 263 117
new 0 263 117
return 1 263 118
assign 1 267 126
new 0 267 126
return 1 267 127
assign 1 272 137
sizeGet 0 272 137
assign 1 272 138
multiply 1 272 138
assign 1 272 139
new 0 272 139
assign 1 272 140
add 1 272 140
assign 1 273 141
new 1 273 141
assign 1 274 144
insertAll 2 274 144
assign 1 274 145
not 0 274 145
assign 1 275 147
increment 0 275 147
assign 1 276 148
new 1 276 148
return 1 278 154
assign 1 282 170
undef 1 282 175
assign 1 0 176
assign 1 282 179
sizeGet 0 282 179
assign 1 282 180
sizeGet 0 282 180
assign 1 282 181
notEquals 1 282 186
assign 1 0 187
assign 1 0 190
assign 1 283 194
new 0 283 194
return 1 283 195
assign 1 285 197
setIteratorGet 0 0 197
assign 1 285 200
hasNextGet 0 285 200
assign 1 285 202
nextGet 0 285 202
assign 1 286 203
has 1 286 203
assign 1 286 204
not 0 286 209
assign 1 286 210
new 0 286 210
return 1 286 211
assign 1 288 218
new 0 288 218
return 1 288 219
assign 1 292 244
sizeGet 0 292 244
assign 1 293 245
undef 1 293 250
assign 1 294 251
getHash 1 294 251
assign 1 295 252
new 0 295 252
assign 1 295 253
lesser 1 295 258
assign 1 296 259
abs 0 296 259
assign 1 299 263
hvalGet 0 299 263
assign 1 301 265
modulus 1 301 265
assign 1 302 266
assign 1 304 269
get 1 304 269
assign 1 305 270
undef 1 305 275
assign 1 306 276
undef 1 306 281
assign 1 307 282
create 0 307 282
assign 1 307 283
new 3 307 283
put 2 307 284
put 2 309 287
assign 1 311 289
new 0 311 289
assign 1 312 290
new 0 312 290
return 1 312 291
assign 1 313 294
hvalGet 0 313 294
assign 1 313 295
modulus 1 313 295
assign 1 313 296
notEquals 1 313 301
assign 1 314 302
new 0 314 302
return 1 314 303
assign 1 315 306
keyGet 0 315 306
assign 1 315 307
isEqual 2 315 307
putTo 2 316 309
assign 1 318 310
new 0 318 310
assign 1 319 311
new 0 319 311
return 1 319 312
assign 1 321 315
increment 0 321 315
assign 1 322 316
greaterEquals 1 322 321
assign 1 323 322
new 0 323 322
return 1 323 323
assign 1 330 336
innerPut 4 330 336
assign 1 330 337
not 0 330 337
assign 1 331 339
assign 1 332 340
rehash 1 332 340
assign 1 333 343
innerPut 4 333 343
assign 1 333 344
not 0 333 344
assign 1 334 346
rehash 1 334 346
assign 1 336 352
assign 1 339 355
increment 0 339 355
assign 1 344 376
assign 1 345 377
sizeGet 0 345 377
assign 1 346 378
getHash 1 346 378
assign 1 347 379
new 0 347 379
assign 1 347 380
lesser 1 347 385
assign 1 348 386
abs 0 348 386
assign 1 350 388
modulus 1 350 388
assign 1 351 389
assign 1 353 392
get 1 353 392
assign 1 354 393
undef 1 354 398
return 1 355 399
assign 1 356 402
hvalGet 0 356 402
assign 1 356 403
modulus 1 356 403
assign 1 356 404
notEquals 1 356 409
return 1 357 410
assign 1 358 413
keyGet 0 358 413
assign 1 358 414
isEqual 2 358 414
assign 1 359 416
getFrom 0 359 416
return 1 359 417
assign 1 361 420
increment 0 361 420
assign 1 362 421
greaterEquals 1 362 426
return 1 363 427
assign 1 370 454
assign 1 371 455
sizeGet 0 371 455
assign 1 372 456
getHash 1 372 456
assign 1 373 457
new 0 373 457
assign 1 373 458
lesser 1 373 463
assign 1 374 464
abs 0 374 464
assign 1 376 466
modulus 1 376 466
assign 1 377 467
assign 1 379 470
get 1 379 470
assign 1 380 471
undef 1 380 476
assign 1 381 477
new 0 381 477
return 1 381 478
assign 1 382 481
hvalGet 0 382 481
assign 1 382 482
modulus 1 382 482
assign 1 382 483
notEquals 1 382 488
assign 1 383 489
new 0 383 489
return 1 383 490
assign 1 384 493
keyGet 0 384 493
assign 1 384 494
isEqual 2 384 494
assign 1 385 496
new 0 385 496
return 1 385 497
assign 1 387 500
increment 0 387 500
assign 1 388 501
greaterEquals 1 388 506
assign 1 389 507
new 0 389 507
return 1 389 508
assign 1 396 544
assign 1 397 545
sizeGet 0 397 545
assign 1 399 546
getHash 1 399 546
assign 1 400 547
new 0 400 547
assign 1 400 548
lesser 1 400 553
assign 1 401 554
abs 0 401 554
assign 1 403 556
modulus 1 403 556
assign 1 404 557
assign 1 406 560
get 1 406 560
assign 1 407 561
undef 1 407 566
assign 1 408 567
new 0 408 567
return 1 408 568
assign 1 409 571
hvalGet 0 409 571
assign 1 409 572
modulus 1 409 572
assign 1 409 573
notEquals 1 409 578
assign 1 410 579
new 0 410 579
return 1 410 580
assign 1 411 583
keyGet 0 411 583
assign 1 411 584
isEqual 2 411 584
put 2 412 586
assign 1 413 587
decrement 0 413 587
assign 1 414 588
increment 0 414 588
assign 1 415 591
lesser 1 415 596
assign 1 416 597
get 1 416 597
assign 1 417 598
undef 1 417 603
assign 1 0 604
assign 1 417 607
hvalGet 0 417 607
assign 1 417 608
modulus 1 417 608
assign 1 417 609
notEquals 1 417 614
assign 1 0 615
assign 1 0 618
assign 1 418 622
new 0 418 622
return 1 418 623
assign 1 420 626
new 0 420 626
assign 1 420 627
subtract 1 420 627
put 2 420 628
put 2 421 629
assign 1 423 631
increment 0 423 631
assign 1 425 637
new 0 425 637
return 1 425 638
assign 1 427 641
increment 0 427 641
assign 1 428 642
greaterEquals 1 428 647
assign 1 429 648
new 0 429 648
return 1 429 649
assign 1 436 671
create 0 436 671
copyTo 1 437 672
assign 1 438 673
copy 0 438 673
slotsSet 1 438 674
assign 1 439 675
new 0 439 675
assign 1 439 678
lengthGet 0 439 678
assign 1 439 679
lesser 1 439 684
assign 1 440 685
get 1 440 685
assign 1 441 686
def 1 441 691
assign 1 442 692
slotsGet 0 442 692
assign 1 442 693
create 0 442 693
assign 1 442 694
hvalGet 0 442 694
assign 1 442 695
keyGet 0 442 695
assign 1 442 696
getFrom 0 442 696
assign 1 442 697
new 3 442 697
put 2 442 698
assign 1 444 701
slotsGet 0 444 701
put 2 444 702
assign 1 439 704
increment 0 439 704
return 1 447 710
clear 0 452 713
assign 1 453 714
new 0 453 714
assign 1 457 719
new 1 457 719
return 1 457 720
assign 1 461 724
new 1 461 724
return 1 461 725
assign 1 465 729
new 1 465 729
return 1 465 730
assign 1 469 734
keyIteratorGet 0 469 734
return 1 469 735
assign 1 473 739
new 1 473 739
return 1 473 740
assign 1 477 744
nodeIteratorGet 0 477 744
return 1 477 745
assign 1 481 754
new 0 481 754
assign 1 482 755
def 1 482 760
assign 1 483 761
setIteratorGet 0 0 761
assign 1 483 764
hasNextGet 0 483 764
assign 1 483 766
nextGet 0 483 766
assign 1 484 767
has 1 484 767
put 1 485 769
return 1 489 777
assign 1 493 787
new 0 493 787
assign 1 494 788
setIteratorGet 0 0 788
assign 1 494 791
hasNextGet 0 494 791
assign 1 494 793
nextGet 0 494 793
put 1 495 794
assign 1 497 800
def 1 497 805
assign 1 498 806
setIteratorGet 0 0 806
assign 1 498 809
hasNextGet 0 498 809
assign 1 498 811
nextGet 0 498 811
put 1 499 812
return 1 502 819
assign 1 506 823
copy 0 506 823
addValue 1 507 824
return 1 508 825
assign 1 512 835
def 1 512 840
assign 1 513 841
sameType 1 513 841
assign 1 514 843
iteratorGet 0 0 843
assign 1 514 846
hasNextGet 0 514 846
assign 1 514 848
nextGet 0 514 848
put 1 515 849
assign 1 517 857
sameType 1 517 857
assign 1 518 859
keyGet 0 518 859
put 1 518 860
put 1 520 863
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
return 1 0 884
assign 1 0 887
return 1 0 891
assign 1 0 894
return 1 0 898
assign 1 0 901
return 1 0 905
assign 1 0 908
return 1 0 912
assign 1 0 915
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1387595522: return bem_toAny_0();
case 434581062: return bem_nodeIteratorGet_0();
case -1909070982: return bem_slotsGet_0();
case 144613256: return bem_serializeContents_0();
case -1872600200: return bem_moduGet_0();
case 1359373450: return bem_echo_0();
case -961535531: return bem_hashGet_0();
case 627086221: return bem_once_0();
case -570363758: return bem_serializationIteratorGet_0();
case 589130895: return bem_multiGet_0();
case 1894814226: return bem_sizeGet_0();
case 1234289396: return bem_tagGet_0();
case 1919215415: return bem_innerPutAddedGet_0();
case -1049623416: return bem_keysGet_0();
case 1087786397: return bem_deserializeClassNameGet_0();
case 1494452579: return bem_isEmptyGet_0();
case 1521162663: return bem_relGet_0();
case -1988392847: return bem_fieldIteratorGet_0();
case 305137971: return bem_classNameGet_0();
case -1601492406: return bem_new_0();
case -612311095: return bem_iteratorGet_0();
case 436412028: return bem_sourceFileNameGet_0();
case -227075485: return bem_clear_0();
case 901060004: return bem_copy_0();
case -1240851525: return bem_setIteratorGet_0();
case 625610277: return bem_nodesGet_0();
case -1550372712: return bem_serializeToString_0();
case -1194864649: return bem_toString_0();
case 741511465: return bem_print_0();
case -234081772: return bem_baseNodeGet_0();
case 1278732754: return bem_create_0();
case 486790650: return bem_keyIteratorGet_0();
case 1014192958: return bem_notEmptyGet_0();
case 730619711: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -630430262: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1737187408: return bem_relSet_1(bevd_0);
case 1055943890: return bem_baseNodeSet_1(bevd_0);
case -928048191: return bem_innerPutAddedSet_1(bevd_0);
case -1001249520: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1633632376: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -483921074: return bem_sizeSet_1(bevd_0);
case 457153382: return bem_copyTo_1(bevd_0);
case 1067421305: return bem_notEquals_1(bevd_0);
case -1681017212: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -686450804: return bem_defined_1(bevd_0);
case -90541311: return bem_get_1(bevd_0);
case 758054799: return bem_delete_1(bevd_0);
case -1568064603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 661372330: return bem_equals_1(bevd_0);
case -993276278: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 266931166: return bem_undef_1(bevd_0);
case -2049241562: return bem_sameObject_1(bevd_0);
case -596533003: return bem_otherType_1(bevd_0);
case -114630842: return bem_put_1(bevd_0);
case -1584461232: return bem_addValue_1(bevd_0);
case 1464031722: return bem_multiSet_1(bevd_0);
case -1903482804: return bem_otherClass_1(bevd_0);
case 1717289899: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 155900047: return bem_moduSet_1(bevd_0);
case -1718194680: return bem_undefined_1(bevd_0);
case 385185820: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1779048441: return bem_slotsSet_1(bevd_0);
case -1023168427: return bem_sameClass_1(bevd_0);
case -695214746: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -2082168507: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1420318580: return bem_sameType_1(bevd_0);
case 486402499: return bem_has_1(bevd_0);
case -309742024: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1461540614: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513720300: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2007577729: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 224164494: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2129126272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88269440: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -366737409: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -666768572: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1139111074: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
}
