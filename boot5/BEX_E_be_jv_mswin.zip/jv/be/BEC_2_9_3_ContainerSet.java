package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_7 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 234 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /* Line: 241 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 259 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_4_tmpany_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpany_phold = bem_innerPut_4(bevt_4_tmpany_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-450415251);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 263 */
} /* Line: 262 */
} /* Line: 261 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_2;
bevl_nslots = bevt_0_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 274 */ {
bevt_4_tmpany_phold = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-450415251);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 274 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 276 */
 else  /* Line: 274 */ {
break;
} /* Line: 274 */
} /* Line: 274 */
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_other == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_4_tmpany_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpany_phold = bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 282 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 283 */
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 285 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_9_tmpany_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 286 */
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 296 */
} /* Line: 295 */
 else  /* Line: 298 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(98867401);
} /* Line: 299 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 303 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 305 */ {
if (beva_inode == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpany_phold);
} /* Line: 307 */
 else  /* Line: 308 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 309 */
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 312 */
 else  /* Line: 305 */ {
bevt_10_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 313 */ {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /* Line: 314 */
 else  /* Line: 305 */ {
bevt_13_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 315 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /* Line: 319 */
 else  /* Line: 320 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 323 */
} /* Line: 322 */
} /* Line: 305 */
} /* Line: 305 */
} /* Line: 305 */
} /*method end*/
public BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-450415251);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 333 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-450415251);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 333 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 334 */
 else  /* Line: 333 */ {
break;
} /* Line: 333 */
} /* Line: 333 */
bevp_slots = bevl_slt;
} /* Line: 336 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 338 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 339 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 348 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 352 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 354 */ {
return null;
} /* Line: 355 */
 else  /* Line: 354 */ {
bevt_5_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 356 */ {
return null;
} /* Line: 357 */
 else  /* Line: 354 */ {
bevt_7_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 358 */ {
bevt_8_tmpany_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpany_phold;
} /* Line: 359 */
 else  /* Line: 360 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 362 */ {
return null;
} /* Line: 363 */
} /* Line: 362 */
} /* Line: 354 */
} /* Line: 354 */
} /* Line: 354 */
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 374 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 378 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 380 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 381 */
 else  /* Line: 380 */ {
bevt_6_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /* Line: 383 */
 else  /* Line: 380 */ {
bevt_9_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 384 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 385 */
 else  /* Line: 386 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /* Line: 389 */
} /* Line: 388 */
} /* Line: 380 */
} /* Line: 380 */
} /* Line: 380 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 400 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 401 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 405 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 407 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 408 */
 else  /* Line: 407 */ {
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 410 */
 else  /* Line: 407 */ {
bevt_10_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 415 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_15_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 417 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 417 */ {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_16_tmpany_phold;
} /* Line: 418 */
 else  /* Line: 419 */ {
bevt_18_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_7;
bevt_17_tmpany_phold = bevl_sl.bem_subtract_1(bevt_18_tmpany_phold);
bevl_slt.bem_put_2(bevt_17_tmpany_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 421 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 423 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_19_tmpany_phold;
} /* Line: 425 */
 else  /* Line: 426 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 428 */ {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_21_tmpany_phold;
} /* Line: 429 */
} /* Line: 428 */
} /* Line: 407 */
} /* Line: 407 */
} /* Line: 407 */
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(1430635788, bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
bevt_2_tmpany_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_4_tmpany_phold = bevl_other.bemd_0(-200848449);
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_new_3(bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_4_tmpany_phold.bemd_2(1922480642, bevl_i, bevt_5_tmpany_phold);
} /* Line: 442 */
 else  /* Line: 443 */ {
bevt_10_tmpany_phold = bevl_other.bemd_0(-200848449);
bevt_10_tmpany_phold.bemd_2(1922480642, bevl_i, null);
} /* Line: 444 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_slots.bem_sizeSet_1(bevp_modu);
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_keyIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_nodeIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 484 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 485 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 486 */
} /* Line: 485 */
 else  /* Line: 484 */ {
break;
} /* Line: 484 */
} /* Line: 484 */
} /* Line: 484 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 495 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 495 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 496 */
 else  /* Line: 495 */ {
break;
} /* Line: 495 */
} /* Line: 495 */
if (beva_other == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevt_1_tmpany_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 499 */ {
bevt_4_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 499 */ {
bevl_x = bevt_1_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 500 */
 else  /* Line: 499 */ {
break;
} /* Line: 499 */
} /* Line: 499 */
} /* Line: 499 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 513 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(1116925492, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 514 */ {
bevt_0_tmpany_loop = beva_other.bemd_0(-973290132);
while (true)
 /* Line: 515 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-347381802);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 515 */ {
bevl_x = bevt_0_tmpany_loop.bemd_0(289547506);
bem_put_1(bevl_x);
} /* Line: 516 */
 else  /* Line: 515 */ {
break;
} /* Line: 515 */
} /* Line: 515 */
} /* Line: 515 */
 else  /* Line: 514 */ {
bevt_4_tmpany_phold = beva_other.bemd_1(1116925492, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 518 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(681755728);
bem_put_1(bevt_5_tmpany_phold);
} /* Line: 519 */
 else  /* Line: 520 */ {
bem_put_1(beva_other);
} /* Line: 521 */
} /* Line: 514 */
} /* Line: 514 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_slotsGetDirect_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public final BEC_2_4_3_MathInt bem_moduGetDirect_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public final BEC_2_4_3_MathInt bem_multiGetDirect_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_multiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public final BEC_3_9_3_9_ContainerSetRelations bem_relGetDirect_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_relSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public final BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGetDirect_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_baseNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public final BEC_2_4_3_MathInt bem_sizeGetDirect_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_innerPutAddedGetDirect_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerSet bem_innerPutAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {215, 215, 221, 222, 223, 224, 225, 226, 227, 233, 233, 233, 234, 234, 236, 236, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 255, 255, 259, 259, 260, 261, 261, 262, 262, 262, 263, 263, 267, 267, 272, 272, 272, 272, 273, 274, 274, 275, 276, 278, 282, 282, 0, 282, 282, 282, 282, 0, 0, 283, 283, 285, 0, 285, 285, 286, 286, 286, 286, 286, 288, 288, 292, 293, 293, 294, 295, 295, 295, 296, 299, 301, 302, 304, 305, 305, 306, 306, 307, 307, 307, 309, 311, 312, 312, 313, 313, 313, 313, 314, 314, 315, 315, 316, 318, 319, 319, 321, 322, 322, 323, 323, 330, 330, 331, 332, 333, 333, 334, 336, 339, 344, 345, 346, 347, 347, 347, 348, 350, 351, 353, 354, 354, 355, 356, 356, 356, 356, 357, 358, 358, 359, 359, 361, 362, 362, 363, 370, 371, 372, 373, 373, 373, 374, 376, 377, 379, 380, 380, 381, 381, 382, 382, 382, 382, 383, 383, 384, 384, 385, 385, 387, 388, 388, 389, 389, 396, 397, 399, 400, 400, 400, 401, 403, 404, 406, 407, 407, 408, 408, 409, 409, 409, 409, 410, 410, 411, 411, 412, 413, 414, 415, 415, 416, 417, 417, 0, 417, 417, 417, 417, 0, 0, 418, 418, 420, 420, 420, 421, 423, 425, 425, 427, 428, 428, 429, 429, 436, 437, 438, 438, 439, 439, 439, 439, 440, 441, 441, 442, 442, 442, 442, 442, 442, 442, 444, 444, 439, 447, 452, 453, 454, 458, 458, 462, 462, 466, 466, 470, 470, 474, 474, 478, 478, 482, 483, 483, 484, 0, 484, 484, 485, 486, 490, 494, 495, 0, 495, 495, 496, 498, 498, 499, 0, 499, 499, 500, 503, 507, 508, 509, 513, 513, 514, 515, 0, 515, 515, 516, 518, 519, 519, 521, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {28, 29, 33, 34, 35, 36, 37, 38, 39, 47, 48, 53, 54, 55, 57, 58, 65, 66, 71, 72, 73, 75, 76, 80, 81, 85, 86, 91, 92, 104, 107, 109, 110, 115, 116, 117, 118, 120, 121, 129, 130, 140, 141, 142, 143, 144, 147, 148, 150, 151, 157, 173, 178, 179, 182, 183, 184, 189, 190, 193, 197, 198, 200, 200, 203, 205, 206, 207, 212, 213, 214, 221, 222, 247, 248, 253, 254, 255, 256, 261, 262, 266, 268, 269, 272, 273, 278, 279, 284, 285, 286, 287, 290, 292, 293, 294, 297, 298, 299, 304, 305, 306, 309, 310, 312, 313, 314, 315, 318, 319, 324, 325, 326, 339, 340, 342, 343, 346, 347, 349, 355, 358, 379, 380, 381, 382, 383, 388, 389, 391, 392, 395, 396, 401, 402, 405, 406, 407, 412, 413, 416, 417, 419, 420, 423, 424, 429, 430, 457, 458, 459, 460, 461, 466, 467, 469, 470, 473, 474, 479, 480, 481, 484, 485, 486, 491, 492, 493, 496, 497, 499, 500, 503, 504, 509, 510, 511, 547, 548, 549, 550, 551, 556, 557, 559, 560, 563, 564, 569, 570, 571, 574, 575, 576, 581, 582, 583, 586, 587, 589, 590, 591, 594, 599, 600, 601, 606, 607, 610, 611, 612, 617, 618, 621, 625, 626, 629, 630, 631, 632, 634, 640, 641, 644, 645, 650, 651, 652, 674, 675, 676, 677, 678, 681, 682, 687, 688, 689, 694, 695, 696, 697, 698, 699, 700, 701, 704, 705, 707, 713, 716, 717, 718, 723, 724, 728, 729, 733, 734, 738, 739, 743, 744, 748, 749, 758, 759, 764, 765, 765, 768, 770, 771, 773, 781, 791, 792, 792, 795, 797, 798, 804, 809, 810, 810, 813, 815, 816, 823, 827, 828, 829, 839, 844, 845, 847, 847, 850, 852, 853, 861, 863, 864, 867, 874, 877, 880, 884, 888, 891, 894, 898, 902, 905, 908, 912, 916, 919, 922, 926, 930, 933, 936, 940, 944, 947, 950, 954, 958, 961, 964, 968};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 215 28
new 0 215 28
new 1 215 29
assign 1 221 33
new 1 221 33
assign 1 222 34
assign 1 223 35
new 0 223 35
assign 1 224 36
new 0 224 36
assign 1 225 37
new 0 225 37
assign 1 226 38
new 0 226 38
assign 1 227 39
new 0 227 39
assign 1 233 47
new 0 233 47
assign 1 233 48
equals 1 233 53
assign 1 234 54
new 0 234 54
return 1 234 55
assign 1 236 57
new 0 236 57
return 1 236 58
assign 1 240 65
new 0 240 65
assign 1 240 66
equals 1 240 71
assign 1 241 72
new 0 241 72
return 1 241 73
assign 1 243 75
new 0 243 75
return 1 243 76
assign 1 247 80
toString 0 247 80
return 1 247 81
assign 1 251 85
new 1 251 85
new 1 251 86
assign 1 255 91
new 1 255 91
return 1 255 92
assign 1 259 104
arrayIteratorGet 0 259 104
assign 1 259 107
hasNextGet 0 259 107
assign 1 260 109
nextGet 0 260 109
assign 1 261 110
def 1 261 115
assign 1 262 116
keyGet 0 262 116
assign 1 262 117
innerPut 4 262 117
assign 1 262 118
not 0 262 118
assign 1 263 120
new 0 263 120
return 1 263 121
assign 1 267 129
new 0 267 129
return 1 267 130
assign 1 272 140
sizeGet 0 272 140
assign 1 272 141
multiply 1 272 141
assign 1 272 142
new 0 272 142
assign 1 272 143
add 1 272 143
assign 1 273 144
new 1 273 144
assign 1 274 147
insertAll 2 274 147
assign 1 274 148
not 0 274 148
assign 1 275 150
increment 0 275 150
assign 1 276 151
new 1 276 151
return 1 278 157
assign 1 282 173
undef 1 282 178
assign 1 0 179
assign 1 282 182
sizeGet 0 282 182
assign 1 282 183
sizeGet 0 282 183
assign 1 282 184
notEquals 1 282 189
assign 1 0 190
assign 1 0 193
assign 1 283 197
new 0 283 197
return 1 283 198
assign 1 285 200
setIteratorGet 0 0 200
assign 1 285 203
hasNextGet 0 285 203
assign 1 285 205
nextGet 0 285 205
assign 1 286 206
has 1 286 206
assign 1 286 207
not 0 286 212
assign 1 286 213
new 0 286 213
return 1 286 214
assign 1 288 221
new 0 288 221
return 1 288 222
assign 1 292 247
sizeGet 0 292 247
assign 1 293 248
undef 1 293 253
assign 1 294 254
getHash 1 294 254
assign 1 295 255
new 0 295 255
assign 1 295 256
lesser 1 295 261
assign 1 296 262
abs 0 296 262
assign 1 299 266
hvalGet 0 299 266
assign 1 301 268
modulus 1 301 268
assign 1 302 269
assign 1 304 272
get 1 304 272
assign 1 305 273
undef 1 305 278
assign 1 306 279
undef 1 306 284
assign 1 307 285
create 0 307 285
assign 1 307 286
new 3 307 286
put 2 307 287
put 2 309 290
assign 1 311 292
new 0 311 292
assign 1 312 293
new 0 312 293
return 1 312 294
assign 1 313 297
hvalGet 0 313 297
assign 1 313 298
modulus 1 313 298
assign 1 313 299
notEquals 1 313 304
assign 1 314 305
new 0 314 305
return 1 314 306
assign 1 315 309
keyGet 0 315 309
assign 1 315 310
isEqual 2 315 310
putTo 2 316 312
assign 1 318 313
new 0 318 313
assign 1 319 314
new 0 319 314
return 1 319 315
assign 1 321 318
increment 0 321 318
assign 1 322 319
greaterEquals 1 322 324
assign 1 323 325
new 0 323 325
return 1 323 326
assign 1 330 339
innerPut 4 330 339
assign 1 330 340
not 0 330 340
assign 1 331 342
assign 1 332 343
rehash 1 332 343
assign 1 333 346
innerPut 4 333 346
assign 1 333 347
not 0 333 347
assign 1 334 349
rehash 1 334 349
assign 1 336 355
assign 1 339 358
increment 0 339 358
assign 1 344 379
assign 1 345 380
sizeGet 0 345 380
assign 1 346 381
getHash 1 346 381
assign 1 347 382
new 0 347 382
assign 1 347 383
lesser 1 347 388
assign 1 348 389
abs 0 348 389
assign 1 350 391
modulus 1 350 391
assign 1 351 392
assign 1 353 395
get 1 353 395
assign 1 354 396
undef 1 354 401
return 1 355 402
assign 1 356 405
hvalGet 0 356 405
assign 1 356 406
modulus 1 356 406
assign 1 356 407
notEquals 1 356 412
return 1 357 413
assign 1 358 416
keyGet 0 358 416
assign 1 358 417
isEqual 2 358 417
assign 1 359 419
getFrom 0 359 419
return 1 359 420
assign 1 361 423
increment 0 361 423
assign 1 362 424
greaterEquals 1 362 429
return 1 363 430
assign 1 370 457
assign 1 371 458
sizeGet 0 371 458
assign 1 372 459
getHash 1 372 459
assign 1 373 460
new 0 373 460
assign 1 373 461
lesser 1 373 466
assign 1 374 467
abs 0 374 467
assign 1 376 469
modulus 1 376 469
assign 1 377 470
assign 1 379 473
get 1 379 473
assign 1 380 474
undef 1 380 479
assign 1 381 480
new 0 381 480
return 1 381 481
assign 1 382 484
hvalGet 0 382 484
assign 1 382 485
modulus 1 382 485
assign 1 382 486
notEquals 1 382 491
assign 1 383 492
new 0 383 492
return 1 383 493
assign 1 384 496
keyGet 0 384 496
assign 1 384 497
isEqual 2 384 497
assign 1 385 499
new 0 385 499
return 1 385 500
assign 1 387 503
increment 0 387 503
assign 1 388 504
greaterEquals 1 388 509
assign 1 389 510
new 0 389 510
return 1 389 511
assign 1 396 547
assign 1 397 548
sizeGet 0 397 548
assign 1 399 549
getHash 1 399 549
assign 1 400 550
new 0 400 550
assign 1 400 551
lesser 1 400 556
assign 1 401 557
abs 0 401 557
assign 1 403 559
modulus 1 403 559
assign 1 404 560
assign 1 406 563
get 1 406 563
assign 1 407 564
undef 1 407 569
assign 1 408 570
new 0 408 570
return 1 408 571
assign 1 409 574
hvalGet 0 409 574
assign 1 409 575
modulus 1 409 575
assign 1 409 576
notEquals 1 409 581
assign 1 410 582
new 0 410 582
return 1 410 583
assign 1 411 586
keyGet 0 411 586
assign 1 411 587
isEqual 2 411 587
put 2 412 589
assign 1 413 590
decrement 0 413 590
assign 1 414 591
increment 0 414 591
assign 1 415 594
lesser 1 415 599
assign 1 416 600
get 1 416 600
assign 1 417 601
undef 1 417 606
assign 1 0 607
assign 1 417 610
hvalGet 0 417 610
assign 1 417 611
modulus 1 417 611
assign 1 417 612
notEquals 1 417 617
assign 1 0 618
assign 1 0 621
assign 1 418 625
new 0 418 625
return 1 418 626
assign 1 420 629
new 0 420 629
assign 1 420 630
subtract 1 420 630
put 2 420 631
put 2 421 632
assign 1 423 634
increment 0 423 634
assign 1 425 640
new 0 425 640
return 1 425 641
assign 1 427 644
increment 0 427 644
assign 1 428 645
greaterEquals 1 428 650
assign 1 429 651
new 0 429 651
return 1 429 652
assign 1 436 674
create 0 436 674
copyTo 1 437 675
assign 1 438 676
copy 0 438 676
slotsSet 1 438 677
assign 1 439 678
new 0 439 678
assign 1 439 681
lengthGet 0 439 681
assign 1 439 682
lesser 1 439 687
assign 1 440 688
get 1 440 688
assign 1 441 689
def 1 441 694
assign 1 442 695
slotsGet 0 442 695
assign 1 442 696
create 0 442 696
assign 1 442 697
hvalGet 0 442 697
assign 1 442 698
keyGet 0 442 698
assign 1 442 699
getFrom 0 442 699
assign 1 442 700
new 3 442 700
put 2 442 701
assign 1 444 704
slotsGet 0 444 704
put 2 444 705
assign 1 439 707
increment 0 439 707
return 1 447 713
clear 0 452 716
sizeSet 1 453 717
assign 1 454 718
new 0 454 718
assign 1 458 723
new 1 458 723
return 1 458 724
assign 1 462 728
new 1 462 728
return 1 462 729
assign 1 466 733
new 1 466 733
return 1 466 734
assign 1 470 738
keyIteratorGet 0 470 738
return 1 470 739
assign 1 474 743
new 1 474 743
return 1 474 744
assign 1 478 748
nodeIteratorGet 0 478 748
return 1 478 749
assign 1 482 758
new 0 482 758
assign 1 483 759
def 1 483 764
assign 1 484 765
setIteratorGet 0 0 765
assign 1 484 768
hasNextGet 0 484 768
assign 1 484 770
nextGet 0 484 770
assign 1 485 771
has 1 485 771
put 1 486 773
return 1 490 781
assign 1 494 791
new 0 494 791
assign 1 495 792
setIteratorGet 0 0 792
assign 1 495 795
hasNextGet 0 495 795
assign 1 495 797
nextGet 0 495 797
put 1 496 798
assign 1 498 804
def 1 498 809
assign 1 499 810
setIteratorGet 0 0 810
assign 1 499 813
hasNextGet 0 499 813
assign 1 499 815
nextGet 0 499 815
put 1 500 816
return 1 503 823
assign 1 507 827
copy 0 507 827
addValue 1 508 828
return 1 509 829
assign 1 513 839
def 1 513 844
assign 1 514 845
sameType 1 514 845
assign 1 515 847
iteratorGet 0 0 847
assign 1 515 850
hasNextGet 0 515 850
assign 1 515 852
nextGet 0 515 852
put 1 516 853
assign 1 518 861
sameType 1 518 861
assign 1 519 863
keyGet 0 519 863
put 1 519 864
put 1 521 867
return 1 0 874
return 1 0 877
assign 1 0 880
assign 1 0 884
return 1 0 888
return 1 0 891
assign 1 0 894
assign 1 0 898
return 1 0 902
return 1 0 905
assign 1 0 908
assign 1 0 912
return 1 0 916
return 1 0 919
assign 1 0 922
assign 1 0 926
return 1 0 930
return 1 0 933
assign 1 0 936
assign 1 0 940
return 1 0 944
return 1 0 947
assign 1 0 950
assign 1 0 954
return 1 0 958
return 1 0 961
assign 1 0 964
assign 1 0 968
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -921815851: return bem_isEmptyGet_0();
case -1515347213: return bem_hashGet_0();
case 507602572: return bem_once_0();
case 631342118: return bem_deserializeClassNameGet_0();
case -862155694: return bem_copy_0();
case -1370019545: return bem_serializeToString_0();
case -647428547: return bem_fieldIteratorGet_0();
case 1379664484: return bem_toAny_0();
case 1547452063: return bem_slotsGetDirect_0();
case -370327287: return bem_moduGet_0();
case -1912025809: return bem_nodeIteratorGet_0();
case 425516171: return bem_moduGetDirect_0();
case -688295882: return bem_tagGet_0();
case 1854534437: return bem_clear_0();
case -1241867755: return bem_baseNodeGet_0();
case -1814630541: return bem_classNameGet_0();
case 562477328: return bem_serializationIteratorGet_0();
case -60434212: return bem_setIteratorGet_0();
case -1568958137: return bem_baseNodeGetDirect_0();
case -200848449: return bem_slotsGet_0();
case 886168102: return bem_many_0();
case 1649934704: return bem_relGet_0();
case 899271096: return bem_new_0();
case 278720698: return bem_sizeGet_0();
case -542639344: return bem_toString_0();
case 1884909798: return bem_create_0();
case -1906660880: return bem_print_0();
case -1850707241: return bem_multiGet_0();
case -712702699: return bem_keyIteratorGet_0();
case -1530567958: return bem_nodesGet_0();
case 1978969112: return bem_keysGet_0();
case -973290132: return bem_iteratorGet_0();
case 1568277288: return bem_relGetDirect_0();
case 1688744619: return bem_serializeContents_0();
case -1067099981: return bem_fieldNamesGet_0();
case -264354485: return bem_notEmptyGet_0();
case -1950829289: return bem_innerPutAddedGet_0();
case -392726163: return bem_innerPutAddedGetDirect_0();
case -21012660: return bem_sourceFileNameGet_0();
case 554645277: return bem_sizeGetDirect_0();
case -1648627766: return bem_echo_0();
case 682533722: return bem_multiGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -217339201: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1744917313: return bem_defined_1(bevd_0);
case 216018244: return bem_copyTo_1(bevd_0);
case 1430635788: return bem_slotsSet_1(bevd_0);
case 870960402: return bem_relSetDirect_1(bevd_0);
case -734789597: return bem_undefined_1(bevd_0);
case -165072616: return bem_sizeSet_1(bevd_0);
case 1280914604: return bem_otherClass_1(bevd_0);
case -914794223: return bem_undef_1(bevd_0);
case -1134659376: return bem_put_1(bevd_0);
case 1116925492: return bem_sameType_1(bevd_0);
case -1185031157: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2071106550: return bem_relSet_1(bevd_0);
case 1142143738: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 164156228: return bem_delete_1(bevd_0);
case 1937536964: return bem_baseNodeSet_1(bevd_0);
case -589022088: return bem_addValue_1(bevd_0);
case -1445456905: return bem_baseNodeSetDirect_1(bevd_0);
case -1884792077: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2120701530: return bem_equals_1(bevd_0);
case -146492636: return bem_multiSetDirect_1(bevd_0);
case 876777123: return bem_moduSetDirect_1(bevd_0);
case -1028156837: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 2001300007: return bem_sameObject_1(bevd_0);
case 1402754792: return bem_def_1(bevd_0);
case 898034411: return bem_sameClass_1(bevd_0);
case 1349849963: return bem_otherType_1(bevd_0);
case -38382637: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1364853423: return bem_get_1(bevd_0);
case -504103026: return bem_sizeSetDirect_1(bevd_0);
case 1820085236: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 463156533: return bem_multiSet_1(bevd_0);
case -105527356: return bem_innerPutAddedSetDirect_1(bevd_0);
case 533270141: return bem_moduSet_1(bevd_0);
case -345992202: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 377027283: return bem_slotsSetDirect_1(bevd_0);
case -1711091481: return bem_has_1(bevd_0);
case -241199401: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1221276469: return bem_innerPutAddedSet_1(bevd_0);
case -1715866358: return bem_notEquals_1(bevd_0);
case 1694509052: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -603725496: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1784313817: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1506940745: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -69860322: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1630879145: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2028721987: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1485133109: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2011759429: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 676875201: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
