package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x20,0x3A,0x20};
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(-860638958);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(-275494575);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-796347509);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(-275494575);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_41_ta_ph = bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_43_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_ta_ph = bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevt_40_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_45_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_47_ta_ph = bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_46_ta_ph = bevt_47_ta_ph.bem_addValue_1(bevt_49_ta_ph);
bevt_50_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevt_46_ta_ph.bem_addValue_1(bevt_50_ta_ph);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevl_tout.bemd_1(135517263, bevl_bet);
bevl_tout.bemd_0(-1663500641);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1109345593);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1574466354);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, bevt_16_ta_ph);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
if (beva_msyn == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_3_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
return bevt_4_ta_ph;
} /* Line: 87*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 93*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 93*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 94*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_typeName);
bevt_3_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 122*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(48, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_exceptDec);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_36));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevl_ms = bevt_3_ta_ph.bem_add_1(bevp_nl);
} /* Line: 123*/
 else /* Line: 124*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildCSEmitter_bels_37));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_exceptDec);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_36));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
bevl_ms = bevt_7_ta_ph.bem_add_1(bevp_nl);
} /* Line: 125*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_38));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_39));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_16_ta_ph = bevl_ms.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_20_ta_ph = bevl_ms.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(1034875381);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_18_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_36));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_45));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 62, 62, 62, 62, 63, 63, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 67, 67, 68, 69, 73, 73, 73, 74, 75, 75, 75, 75, 75, 75, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 82, 82, 86, 0, 86, 86, 86, 0, 0, 0, 0, 0, 87, 87, 89, 89, 93, 93, 93, 0, 0, 0, 94, 94, 96, 96, 100, 100, 104, 104, 104, 104, 104, 109, 110, 111, 111, 112, 118, 118, 118, 118, 118, 118, 122, 122, 122, 123, 123, 123, 123, 123, 125, 125, 125, 125, 125, 127, 127, 127, 127, 127, 127, 128, 128, 128, 129, 129, 129, 129, 129, 129, 129, 129, 130, 134, 134, 134, 138, 138, 138, 138, 138, 138, 138, 142, 142, 146, 146, 146, 150, 150, 150, 154, 154};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {58, 59, 60, 61, 125, 126, 127, 128, 133, 134, 135, 136, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 161, 164, 166, 168, 171, 172, 174, 175, 176, 177, 183, 184, 185, 186, 187, 188, 189, 190, 191, 191, 194, 196, 198, 201, 202, 204, 205, 206, 207, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 285, 286, 295, 297, 300, 305, 306, 308, 311, 315, 318, 321, 325, 326, 328, 329, 337, 342, 343, 345, 348, 352, 355, 356, 358, 359, 363, 364, 371, 372, 373, 374, 375, 380, 381, 382, 383, 384, 393, 394, 395, 396, 397, 398, 427, 428, 429, 431, 432, 433, 434, 435, 438, 439, 440, 441, 442, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 466, 467, 468, 477, 478, 479, 480, 481, 482, 483, 487, 488, 493, 494, 495, 500, 501, 502, 506, 507};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 58
new 0 16 58
assign 1 17 59
new 0 17 59
assign 1 18 60
new 0 18 60
new 1 22 61
assign 1 26 125
classDirGet 0 26 125
assign 1 26 126
fileGet 0 26 126
assign 1 26 127
existsGet 0 26 127
assign 1 26 128
not 0 26 133
assign 1 27 134
classDirGet 0 27 134
assign 1 27 135
fileGet 0 27 135
makeDirs 0 27 136
assign 1 29 138
typePathGet 0 29 138
assign 1 29 139
fileGet 0 29 139
assign 1 29 140
writerGet 0 29 140
assign 1 29 141
open 0 29 141
assign 1 30 142
new 0 30 142
assign 1 31 143
new 0 31 143
addValue 1 31 144
assign 1 32 145
new 0 32 145
assign 1 32 146
addValue 1 32 146
assign 1 32 147
typeEmitNameGet 0 32 147
assign 1 32 148
addValue 1 32 148
assign 1 32 149
new 0 32 149
addValue 1 32 150
assign 1 33 151
new 0 33 151
assign 1 33 152
addValue 1 33 152
assign 1 33 153
typeEmitNameGet 0 33 153
assign 1 33 154
addValue 1 33 154
assign 1 33 155
new 0 33 155
addValue 1 33 156
assign 1 35 157
new 0 35 157
addValue 1 35 158
assign 1 36 159
new 0 36 159
assign 1 37 160
mtdListGet 0 37 160
assign 1 37 161
iteratorGet 0 0 161
assign 1 37 164
hasNextGet 0 37 164
assign 1 37 166
nextGet 0 37 166
assign 1 39 168
new 0 39 168
assign 1 41 171
new 0 41 171
addValue 1 41 172
assign 1 43 174
addValue 1 43 174
assign 1 43 175
nameGet 0 43 175
assign 1 43 176
addValue 1 43 176
addValue 1 43 177
assign 1 45 183
new 0 45 183
addValue 1 45 184
assign 1 46 185
new 0 46 185
addValue 1 46 186
assign 1 48 187
new 0 48 187
addValue 1 48 188
assign 1 49 189
new 0 49 189
assign 1 50 190
ptyListGet 0 50 190
assign 1 50 191
iteratorGet 0 0 191
assign 1 50 194
hasNextGet 0 50 194
assign 1 50 196
nextGet 0 50 196
assign 1 52 198
new 0 52 198
assign 1 54 201
new 0 54 201
addValue 1 54 202
assign 1 56 204
addValue 1 56 204
assign 1 56 205
nameGet 0 56 205
assign 1 56 206
addValue 1 56 206
addValue 1 56 207
assign 1 58 213
new 0 58 213
addValue 1 58 214
assign 1 60 215
new 0 60 215
addValue 1 60 216
assign 1 62 217
new 0 62 217
assign 1 62 218
addValue 1 62 218
assign 1 62 219
typeEmitNameGet 0 62 219
assign 1 62 220
addValue 1 62 220
assign 1 62 221
new 0 62 221
addValue 1 62 222
assign 1 63 223
new 0 63 223
addValue 1 63 224
assign 1 64 225
new 0 64 225
assign 1 64 226
addValue 1 64 226
assign 1 64 227
emitNameGet 0 64 227
assign 1 64 228
addValue 1 64 228
assign 1 64 229
new 0 64 229
addValue 1 64 230
assign 1 65 231
new 0 65 231
addValue 1 65 232
assign 1 66 233
new 0 66 233
addValue 1 66 234
assign 1 67 235
new 0 67 235
addValue 1 67 236
write 1 68 237
close 0 69 238
assign 1 73 260
new 0 73 260
assign 1 73 261
toString 0 73 261
assign 1 73 262
add 1 73 262
incrementValue 0 74 263
assign 1 75 264
new 0 75 264
assign 1 75 265
addValue 1 75 265
assign 1 75 266
addValue 1 75 266
assign 1 75 267
new 0 75 267
assign 1 75 268
addValue 1 75 268
addValue 1 75 269
assign 1 77 270
containedGet 0 77 270
assign 1 77 271
firstGet 0 77 271
assign 1 77 272
containedGet 0 77 272
assign 1 77 273
firstGet 0 77 273
assign 1 77 274
new 0 77 274
assign 1 77 275
add 1 77 275
assign 1 77 276
new 0 77 276
assign 1 77 277
add 1 77 277
assign 1 77 278
new 0 77 278
assign 1 77 279
finalAssign 4 77 279
addValue 1 77 280
assign 1 82 285
new 0 82 285
return 1 82 286
assign 1 86 295
isFinalGet 0 86 295
assign 1 0 297
assign 1 86 300
def 1 86 305
assign 1 86 306
isFinalGet 0 86 306
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 0 318
assign 1 0 321
assign 1 87 325
new 0 87 325
return 1 87 326
assign 1 89 328
new 0 89 328
return 1 89 329
assign 1 93 337
def 1 93 342
assign 1 93 343
isFinalGet 0 93 343
assign 1 0 345
assign 1 0 348
assign 1 0 352
assign 1 94 355
new 0 94 355
return 1 94 356
assign 1 96 358
new 0 96 358
return 1 96 359
assign 1 100 363
new 0 100 363
return 1 100 364
assign 1 104 371
new 0 104 371
assign 1 104 372
add 1 104 372
assign 1 104 373
new 0 104 373
assign 1 104 374
add 1 104 374
return 1 104 375
getCode 2 109 380
assign 1 110 381
toHexString 1 110 381
assign 1 111 382
new 0 111 382
addValue 1 111 383
addValue 1 112 384
assign 1 118 393
new 0 118 393
assign 1 118 394
add 1 118 394
assign 1 118 395
new 0 118 395
assign 1 118 396
add 1 118 396
assign 1 118 397
add 1 118 397
return 1 118 398
assign 1 122 427
emitChecksGet 0 122 427
assign 1 122 428
new 0 122 428
assign 1 122 429
has 1 122 429
assign 1 123 431
new 0 123 431
assign 1 123 432
add 1 123 432
assign 1 123 433
new 0 123 433
assign 1 123 434
add 1 123 434
assign 1 123 435
add 1 123 435
assign 1 125 438
new 0 125 438
assign 1 125 439
add 1 125 439
assign 1 125 440
new 0 125 440
assign 1 125 441
add 1 125 441
assign 1 125 442
add 1 125 442
assign 1 127 444
new 0 127 444
assign 1 127 445
addValue 1 127 445
assign 1 127 446
addValue 1 127 446
assign 1 127 447
new 0 127 447
assign 1 127 448
addValue 1 127 448
addValue 1 127 449
assign 1 128 450
new 0 128 450
assign 1 128 451
addValue 1 128 451
addValue 1 128 452
assign 1 129 453
new 0 129 453
assign 1 129 454
addValue 1 129 454
assign 1 129 455
outputPlatformGet 0 129 455
assign 1 129 456
nameGet 0 129 456
assign 1 129 457
addValue 1 129 457
assign 1 129 458
new 0 129 458
assign 1 129 459
addValue 1 129 459
addValue 1 129 460
return 1 130 461
assign 1 134 466
libNameGet 0 134 466
assign 1 134 467
beginNs 1 134 467
return 1 134 468
assign 1 138 477
new 0 138 477
assign 1 138 478
libNs 1 138 478
assign 1 138 479
add 1 138 479
assign 1 138 480
new 0 138 480
assign 1 138 481
add 1 138 481
assign 1 138 482
add 1 138 482
return 1 138 483
assign 1 142 487
getNameSpace 1 142 487
return 1 142 488
assign 1 146 493
new 0 146 493
assign 1 146 494
add 1 146 494
return 1 146 495
assign 1 150 500
new 0 150 500
assign 1 150 501
add 1 150 501
return 1 150 502
assign 1 154 506
new 0 154 506
return 1 154 507
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -329066015: return bem_onceDecsGet_0();
case -124246836: return bem_boolNpGetDirect_0();
case 1085612775: return bem_tagGet_0();
case -1149405517: return bem_spropDecGet_0();
case 1462930665: return bem_buildCreate_0();
case -1648057302: return bem_echo_0();
case 1156534175: return bem_synEmitPathGet_0();
case 1222954954: return bem_libEmitPathGet_0();
case -622293713: return bem_fileExtGetDirect_0();
case 297833957: return bem_loadIds_0();
case 1935487978: return bem_emitLangGet_0();
case 1113199097: return bem_lastMethodBodySizeGet_0();
case -392202678: return bem_classCallsGetDirect_0();
case 1784698535: return bem_nativeCSlotsGet_0();
case -1437358025: return bem_mainEndGet_0();
case 1533301608: return bem_once_0();
case -298083742: return bem_stringNpGetDirect_0();
case -1745697587: return bem_classNameGet_0();
case 452813698: return bem_msynGetDirect_0();
case -1738437781: return bem_ccCacheGetDirect_0();
case 463783587: return bem_transGet_0();
case 1384861752: return bem_instOfGet_0();
case 678439469: return bem_smnlcsGet_0();
case -1948916370: return bem_fullLibEmitNameGet_0();
case 701269057: return bem_callNamesGet_0();
case -1177305810: return bem_lastCallGet_0();
case -1604434462: return bem_mnodeGetDirect_0();
case 1031346632: return bem_gcMarksGet_0();
case 1356264168: return bem_lastMethodBodyLinesGet_0();
case 1372278772: return bem_endNs_0();
case 2024312882: return bem_exceptDecGetDirect_0();
case 197691063: return bem_classesInDepthOrderGet_0();
case 424187441: return bem_nlGetDirect_0();
case -46879192: return bem_superCallsGetDirect_0();
case 1922559573: return bem_smnlecsGet_0();
case 469657691: return bem_fieldNamesGet_0();
case 310318313: return bem_covariantReturnsGet_0();
case 1668281746: return bem_libEmitNameGetDirect_0();
case -1533189966: return bem_ccCacheGet_0();
case 207111705: return bem_smnlcsGetDirect_0();
case -1070994386: return bem_serializeToString_0();
case -2068534846: return bem_methodCallsGetDirect_0();
case 546328157: return bem_libEmitPathGetDirect_0();
case -1020860404: return bem_idToNamePathGet_0();
case 1297554844: return bem_belslitsGetDirect_0();
case 1739331300: return bem_nameToIdGet_0();
case -995921477: return bem_methodsGet_0();
case 2090308182: return bem_serializationIteratorGet_0();
case -582614787: return bem_methodCatchGet_0();
case -1269645420: return bem_runtimeInitGet_0();
case -2107872104: return bem_lastMethodBodySizeGetDirect_0();
case -1499925507: return bem_instanceEqualGet_0();
case -1485421802: return bem_serializeContents_0();
case 1520079032: return bem_lineCountGet_0();
case 1579512018: return bem_print_0();
case 669563776: return bem_lastMethodsLinesGet_0();
case 1478046755: return bem_fileExtGet_0();
case -414591341: return bem_instanceNotEqualGetDirect_0();
case -1248679117: return bem_toString_0();
case -1631685182: return bem_getClassOutput_0();
case 1814161398: return bem_methodCallsGet_0();
case 238971711: return bem_sourceFileNameGet_0();
case 756246912: return bem_ccMethodsGet_0();
case -306813751: return bem_superCallsGet_0();
case 285386260: return bem_nameToIdPathGet_0();
case -486553170: return bem_invpGet_0();
case 2069972657: return bem_msynGet_0();
case 1270276445: return bem_boolCcGetDirect_0();
case 1384510541: return bem_inFilePathedGetDirect_0();
case 1446040207: return bem_many_0();
case 2135887718: return bem_parentConfGetDirect_0();
case -902475206: return bem_idToNameGet_0();
case 677156823: return bem_hashGet_0();
case -177884053: return bem_onceDecsGetDirect_0();
case 1567716657: return bem_stringNpGet_0();
case -1511279831: return bem_buildGet_0();
case -1499368913: return bem_nameToIdGetDirect_0();
case 1915060382: return bem_mainInClassGet_0();
case -1322635312: return bem_qGet_0();
case -803884467: return bem_lineCountGetDirect_0();
case -1769549363: return bem_cnodeGet_0();
case 1803982523: return bem_randGetDirect_0();
case -989558503: return bem_methodBodyGetDirect_0();
case 887875557: return bem_copy_0();
case 792882701: return bem_ntypesGet_0();
case 2140743800: return bem_intNpGetDirect_0();
case -789361655: return bem_buildGetDirect_0();
case 1079407473: return bem_scvpGetDirect_0();
case 972996634: return bem_idToNameGetDirect_0();
case 781986565: return bem_boolCcGet_0();
case -1003406160: return bem_intNpGet_0();
case 1316409546: return bem_falseValueGetDirect_0();
case -367697179: return bem_mainStartGet_0();
case 1920089389: return bem_maxSpillArgsLenGetDirect_0();
case 1368909213: return bem_preClassGetDirect_0();
case -806163823: return bem_methodCatchGetDirect_0();
case -1707594248: return bem_writeBET_0();
case 452187684: return bem_dynMethodsGetDirect_0();
case -508342835: return bem_boolNpGet_0();
case -1676010032: return bem_nativeCSlotsGetDirect_0();
case 2109086157: return bem_getLibOutput_0();
case 1230712573: return bem_belslitsGet_0();
case 1066357231: return bem_beginNs_0();
case 338667504: return bem_instanceNotEqualGet_0();
case 1044622455: return bem_inClassGetDirect_0();
case 558678650: return bem_boolTypeGet_0();
case -746410905: return bem_nullValueGetDirect_0();
case 2100008175: return bem_mainOutsideNsGet_0();
case 701545701: return bem_gcMarksGetDirect_0();
case -414899365: return bem_trueValueGet_0();
case -2093731063: return bem_lastMethodsSizeGetDirect_0();
case 1935105509: return bem_objectCcGet_0();
case -1425061390: return bem_classesInDepthOrderGetDirect_0();
case -1383000262: return bem_transGetDirect_0();
case 286123199: return bem_buildInitial_0();
case 1899215943: return bem_classConfGet_0();
case -918189470: return bem_falseValueGet_0();
case -295675046: return bem_objectNpGetDirect_0();
case 1370887759: return bem_propertyDecsGet_0();
case -1877398007: return bem_classEmitsGet_0();
case 107539529: return bem_idToNamePathGetDirect_0();
case 189955688: return bem_constGetDirect_0();
case -1018326488: return bem_nameToIdPathGetDirect_0();
case -281459492: return bem_preClassGet_0();
case -1398003509: return bem_qGetDirect_0();
case -472504784: return bem_classEmitsGetDirect_0();
case -1431710046: return bem_exceptDecGet_0();
case 1870269488: return bem_inClassGet_0();
case 672986683: return bem_dynMethodsGet_0();
case -1159990028: return bem_ntypesGetDirect_0();
case 1752703222: return bem_initialDecGet_0();
case -296254644: return bem_constGet_0();
case 322294792: return bem_propDecGet_0();
case -376638182: return bem_maxDynArgsGet_0();
case 222871763: return bem_emitLangGetDirect_0();
case -786273402: return bem_invpGetDirect_0();
case -1977365508: return bem_scvpGet_0();
case 504159692: return bem_doEmit_0();
case 714174108: return bem_superNameGet_0();
case -188592407: return bem_fullLibEmitNameGetDirect_0();
case -667878155: return bem_nlGet_0();
case 1539648106: return bem_lastMethodBodyLinesGetDirect_0();
case -893270259: return bem_onceCountGetDirect_0();
case -235429587: return bem_callNamesGetDirect_0();
case 2079122371: return bem_cnodeGetDirect_0();
case -687612480: return bem_smnlecsGetDirect_0();
case 440296821: return bem_classCallsGet_0();
case -1381614910: return bem_propertyDecsGetDirect_0();
case -1525890408: return bem_ccMethodsGetDirect_0();
case -1816381160: return bem_typeDecGet_0();
case -1456422317: return bem_toAny_0();
case 1329877198: return bem_buildClassInfo_0();
case 441100344: return bem_instOfGetDirect_0();
case 1001390589: return bem_synEmitPathGetDirect_0();
case -408850294: return bem_objectNpGet_0();
case 1112122799: return bem_lastCallGetDirect_0();
case -1902993885: return bem_classConfGetDirect_0();
case -944886574: return bem_emitLib_0();
case -369356392: return bem_fieldIteratorGet_0();
case -389439539: return bem_floatNpGetDirect_0();
case -1822472875: return bem_baseSmtdDecGet_0();
case 176957219: return bem_saveIds_0();
case 1513032233: return bem_maxDynArgsGetDirect_0();
case 816341008: return bem_afterCast_0();
case 2126241428: return bem_methodBodyGet_0();
case -1872786277: return bem_nullValueGet_0();
case -1144459554: return bem_objectCcGetDirect_0();
case 1718558910: return bem_inFilePathedGet_0();
case 1469037774: return bem_overrideMtdDecGet_0();
case -189649319: return bem_baseMtdDecGet_0();
case 1681481776: return bem_classEndGet_0();
case -315448632: return bem_create_0();
case -119240146: return bem_instanceEqualGetDirect_0();
case 1977753563: return bem_lastMethodsLinesGetDirect_0();
case -1509322445: return bem_returnTypeGet_0();
case 102975912: return bem_methodsGetDirect_0();
case -616157047: return bem_lastMethodsSizeGet_0();
case 1870104004: return bem_onceCountGet_0();
case -203388125: return bem_libEmitNameGet_0();
case 392512834: return bem_floatNpGet_0();
case 1965801140: return bem_iteratorGet_0();
case -166800760: return bem_useDynMethodsGet_0();
case 342689328: return bem_parentConfGet_0();
case 1499284258: return bem_mnodeGet_0();
case -1104703438: return bem_trueValueGetDirect_0();
case 1173031986: return bem_randGet_0();
case -1849912258: return bem_csynGetDirect_0();
case -2002801624: return bem_saveSyns_0();
case 1910516796: return bem_maxSpillArgsLenGet_0();
case 983251128: return bem_new_0();
case -1753072439: return bem_newDecGet_0();
case 1350181777: return bem_deserializeClassNameGet_0();
case -2102192709: return bem_preClassOutput_0();
case 500354691: return bem_returnTypeGetDirect_0();
case 1770517901: return bem_csynGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 879258878: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 712814075: return bem_methodBodySet_1(bevd_0);
case -1330033516: return bem_parentConfSet_1(bevd_0);
case 1019040538: return bem_libEmitNameSet_1(bevd_0);
case 2043792263: return bem_mnodeSet_1(bevd_0);
case -655517408: return bem_dynMethodsSet_1(bevd_0);
case -851316040: return bem_ccMethodsSetDirect_1(bevd_0);
case 1474459106: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1522604424: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 980771991: return bem_inClassSetDirect_1(bevd_0);
case 624251854: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1945776441: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -74342257: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 203482140: return bem_undefined_1(bevd_0);
case -1904508066: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1109614879: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -481259763: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 917178746: return bem_randSet_1(bevd_0);
case 2077650259: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2024634825: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 966325773: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1353040804: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 790558631: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -748640894: return bem_nativeCSlotsSet_1(bevd_0);
case -1633804400: return bem_methodCatchSetDirect_1(bevd_0);
case 1894039129: return bem_ccMethodsSet_1(bevd_0);
case 1953102532: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 837049509: return bem_cnodeSetDirect_1(bevd_0);
case 831621562: return bem_belslitsSetDirect_1(bevd_0);
case 226306348: return bem_msynSetDirect_1(bevd_0);
case -333230102: return bem_maxDynArgsSetDirect_1(bevd_0);
case 172085484: return bem_instanceEqualSet_1(bevd_0);
case 362126298: return bem_floatNpSet_1(bevd_0);
case 659588232: return bem_smnlcsSet_1(bevd_0);
case -1733963570: return bem_methodCatchSet_1(bevd_0);
case -1855447660: return bem_fullLibEmitNameSet_1(bevd_0);
case -142415641: return bem_preClassSet_1(bevd_0);
case -294571256: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1124348142: return bem_smnlecsSet_1(bevd_0);
case 627763126: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1630597488: return bem_notEquals_1(bevd_0);
case -150071484: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 65800815: return bem_transSetDirect_1(bevd_0);
case -1035364534: return bem_fileExtSet_1(bevd_0);
case 1300148174: return bem_constSet_1(bevd_0);
case -1827746691: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -2023300100: return bem_sameObject_1(bevd_0);
case -278826317: return bem_callNamesSetDirect_1(bevd_0);
case -513408185: return bem_otherClass_1(bevd_0);
case -1682701173: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 1774018030: return bem_emitLangSetDirect_1(bevd_0);
case -855511361: return bem_nameToIdPathSetDirect_1(bevd_0);
case 565121501: return bem_def_1(bevd_0);
case -1429372761: return bem_nameToIdSetDirect_1(bevd_0);
case -437150821: return bem_libEmitPathSet_1(bevd_0);
case 1480127577: return bem_exceptDecSetDirect_1(bevd_0);
case 1645800414: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1989487241: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 71175363: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1768990792: return bem_boolCcSet_1(bevd_0);
case -42887111: return bem_synEmitPathSet_1(bevd_0);
case 633548757: return bem_intNpSet_1(bevd_0);
case -1230754001: return bem_inClassSet_1(bevd_0);
case -580813096: return bem_sameType_1(bevd_0);
case -1307196208: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1438356679: return bem_lastMethodsSizeSet_1(bevd_0);
case -2038660155: return bem_inFilePathedSet_1(bevd_0);
case -1593114887: return bem_instanceEqualSetDirect_1(bevd_0);
case -1101415546: return bem_onceDecsSetDirect_1(bevd_0);
case 2114292416: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1888533796: return bem_floatNpSetDirect_1(bevd_0);
case 1772657279: return bem_methodBodySetDirect_1(bevd_0);
case -100658776: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -982839769: return bem_boolCcSetDirect_1(bevd_0);
case -1571698421: return bem_idToNamePathSet_1(bevd_0);
case 1339708793: return bem_exceptDecSet_1(bevd_0);
case 1481390150: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1951230863: return bem_mnodeSetDirect_1(bevd_0);
case 1538571134: return bem_qSet_1(bevd_0);
case -291157311: return bem_emitLangSet_1(bevd_0);
case 1458274273: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 962153823: return bem_objectCcSetDirect_1(bevd_0);
case 1494491213: return bem_ccCacheSet_1(bevd_0);
case 1039262659: return bem_qSetDirect_1(bevd_0);
case -1933004170: return bem_methodsSet_1(bevd_0);
case 751501301: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1693745602: return bem_otherType_1(bevd_0);
case 803677442: return bem_libEmitNameSetDirect_1(bevd_0);
case -1835104030: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1883076638: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1212392739: return bem_nullValueSet_1(bevd_0);
case -1904810949: return bem_boolNpSetDirect_1(bevd_0);
case -652677234: return bem_idToNameSetDirect_1(bevd_0);
case -2034227152: return bem_classEmitsSet_1(bevd_0);
case 1828534550: return bem_gcMarksSetDirect_1(bevd_0);
case 1470454964: return bem_randSetDirect_1(bevd_0);
case -2090403063: return bem_nlSetDirect_1(bevd_0);
case 375143209: return bem_csynSetDirect_1(bevd_0);
case 1495318592: return bem_methodCallsSetDirect_1(bevd_0);
case -1592774941: return bem_cnodeSet_1(bevd_0);
case 1788882700: return bem_undef_1(bevd_0);
case 618399824: return bem_ccCacheSetDirect_1(bevd_0);
case -46251647: return bem_falseValueSet_1(bevd_0);
case -1521194289: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -986812145: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 568120002: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 130714078: return bem_equals_1(bevd_0);
case 1366610544: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -488975057: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 604100334: return bem_inFilePathedSetDirect_1(bevd_0);
case -1377791170: return bem_scvpSet_1(bevd_0);
case 2108037585: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1170836141: return bem_lineCountSetDirect_1(bevd_0);
case 119264116: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1894822196: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 477856701: return bem_methodCallsSet_1(bevd_0);
case -1425157652: return bem_dynMethodsSetDirect_1(bevd_0);
case -1455433723: return bem_trueValueSetDirect_1(bevd_0);
case -647420518: return bem_classCallsSetDirect_1(bevd_0);
case 1157738659: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1436362493: return bem_onceDecsSet_1(bevd_0);
case -655224851: return bem_lastMethodsLinesSet_1(bevd_0);
case 119611352: return bem_lastMethodBodySizeSet_1(bevd_0);
case -236586277: return bem_objectCcSet_1(bevd_0);
case 63252478: return bem_buildSet_1(bevd_0);
case -1939192421: return bem_classCallsSet_1(bevd_0);
case 1154464347: return bem_instOfSetDirect_1(bevd_0);
case 31038758: return bem_classesInDepthOrderSet_1(bevd_0);
case 1311545374: return bem_smnlecsSetDirect_1(bevd_0);
case -1367042520: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2089009691: return bem_stringNpSet_1(bevd_0);
case 1386108603: return bem_onceCountSet_1(bevd_0);
case 1555630926: return bem_gcMarksSet_1(bevd_0);
case -1776871716: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -893240077: return bem_classConfSetDirect_1(bevd_0);
case 1111658966: return bem_lastCallSetDirect_1(bevd_0);
case -516066761: return bem_defined_1(bevd_0);
case 1510823956: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1695680310: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1649256832: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 455987933: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1720167479: return bem_instanceNotEqualSet_1(bevd_0);
case 1138018239: return bem_nameToIdSet_1(bevd_0);
case 282111874: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1414802823: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -876531470: return bem_lineCountSet_1(bevd_0);
case 97462777: return bem_idToNameSet_1(bevd_0);
case 957608944: return bem_idToNamePathSetDirect_1(bevd_0);
case -264273708: return bem_lastCallSet_1(bevd_0);
case 851006420: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -789654751: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1309956683: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -520323927: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -803469033: return bem_objectNpSetDirect_1(bevd_0);
case 403437117: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 213194279: return bem_smnlcsSetDirect_1(bevd_0);
case 668566191: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 38767287: return bem_copyTo_1(bevd_0);
case -872773593: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 24277778: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -686936327: return bem_begin_1(bevd_0);
case -243814035: return bem_onceCountSetDirect_1(bevd_0);
case -2086650841: return bem_propertyDecsSetDirect_1(bevd_0);
case 1512038227: return bem_returnTypeSet_1(bevd_0);
case 195031497: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1948748188: return bem_intNpSetDirect_1(bevd_0);
case 1617352434: return bem_belslitsSet_1(bevd_0);
case 729007819: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 932156558: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -455033093: return bem_libEmitPathSetDirect_1(bevd_0);
case -825628308: return bem_synEmitPathSetDirect_1(bevd_0);
case 2031096766: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 641554294: return bem_invpSetDirect_1(bevd_0);
case -1124950231: return bem_fileExtSetDirect_1(bevd_0);
case 1223418614: return bem_boolNpSet_1(bevd_0);
case -920618532: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1907716468: return bem_objectNpSet_1(bevd_0);
case 1645713309: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1425049347: return bem_trueValueSet_1(bevd_0);
case 556275089: return bem_msynSet_1(bevd_0);
case 1062522692: return bem_stringNpSetDirect_1(bevd_0);
case 902207013: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 238311972: return bem_csynSet_1(bevd_0);
case -323995358: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1936588545: return bem_constSetDirect_1(bevd_0);
case 109388014: return bem_ntypesSet_1(bevd_0);
case -449942058: return bem_transSet_1(bevd_0);
case -1644587407: return bem_buildSetDirect_1(bevd_0);
case 546284509: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1783106652: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 603494847: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1775587300: return bem_invpSet_1(bevd_0);
case -1089489921: return bem_methodsSetDirect_1(bevd_0);
case -1743252688: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1003770285: return bem_returnTypeSetDirect_1(bevd_0);
case 290396673: return bem_end_1(bevd_0);
case 218472313: return bem_nameToIdPathSet_1(bevd_0);
case 284707947: return bem_nlSet_1(bevd_0);
case 1547200215: return bem_instOfSet_1(bevd_0);
case -486195329: return bem_superCallsSetDirect_1(bevd_0);
case 211198219: return bem_parentConfSetDirect_1(bevd_0);
case -1793774391: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1007512741: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -59989013: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1213543846: return bem_preClassSetDirect_1(bevd_0);
case 1161315913: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -641148697: return bem_propertyDecsSet_1(bevd_0);
case 189130629: return bem_callNamesSet_1(bevd_0);
case -150938026: return bem_scvpSetDirect_1(bevd_0);
case -852934177: return bem_falseValueSetDirect_1(bevd_0);
case 2020949180: return bem_superCallsSet_1(bevd_0);
case -1689228748: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1812690261: return bem_maxDynArgsSet_1(bevd_0);
case -168890216: return bem_ntypesSetDirect_1(bevd_0);
case 1652156979: return bem_classEmitsSetDirect_1(bevd_0);
case 1932338560: return bem_nullValueSetDirect_1(bevd_0);
case 686953964: return bem_classConfSet_1(bevd_0);
case 1812369063: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 619523077: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1432082908: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1533513098: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1066646216: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 939216903: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1808310541: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -432356215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1753294364: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -312936927: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -693517224: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1398155327: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1289805242: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 391432487: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 828688575: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1881226505: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1676574552: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -1830626465: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -926983607: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1433806572: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -63832734: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 397275811: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 906912874: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1681155069: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 865760635: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 537199198: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case 346512260: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 1672012095: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 197278640: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
