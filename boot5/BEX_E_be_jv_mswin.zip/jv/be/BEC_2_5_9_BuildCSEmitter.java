package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_15, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_16, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_17, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_18, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_19, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_27, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_29, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_30, 3));
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(840830840);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(728696369);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
return bevt_4_tmpany_phold;
} /* Line: 41 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 47 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 47 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
return bevt_3_tmpany_phold;
} /* Line: 48 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1203841037);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 36, 36, 40, 0, 40, 40, 40, 0, 0, 0, 0, 0, 41, 41, 43, 43, 47, 47, 47, 0, 0, 0, 48, 48, 50, 50, 54, 54, 58, 58, 58, 58, 58, 63, 64, 65, 65, 65, 66, 72, 72, 72, 72, 72, 72, 76, 76, 76, 76, 76, 77, 77, 77, 77, 77, 77, 78, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 80, 84, 84, 84, 88, 88, 88, 88, 88, 88, 88, 92, 92, 96, 96, 96, 100, 100, 100, 100, 104, 104};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {54, 55, 56, 57, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 104, 105, 114, 116, 119, 124, 125, 127, 130, 134, 137, 140, 144, 145, 147, 148, 156, 161, 162, 164, 167, 171, 174, 175, 177, 178, 182, 183, 190, 191, 192, 193, 194, 200, 201, 202, 203, 204, 205, 214, 215, 216, 217, 218, 219, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 268, 269, 270, 279, 280, 281, 282, 283, 284, 285, 289, 290, 295, 296, 297, 303, 304, 305, 306, 310, 311};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 17 54
new 0 17 54
assign 1 18 55
new 0 18 55
assign 1 19 56
new 0 19 56
new 1 23 57
assign 1 27 79
new 0 27 79
assign 1 27 80
toString 0 27 80
assign 1 27 81
add 1 27 81
incrementValue 0 28 82
assign 1 29 83
new 0 29 83
assign 1 29 84
addValue 1 29 84
assign 1 29 85
addValue 1 29 85
assign 1 29 86
new 0 29 86
assign 1 29 87
addValue 1 29 87
addValue 1 29 88
assign 1 31 89
containedGet 0 31 89
assign 1 31 90
firstGet 0 31 90
assign 1 31 91
containedGet 0 31 91
assign 1 31 92
firstGet 0 31 92
assign 1 31 93
new 0 31 93
assign 1 31 94
add 1 31 94
assign 1 31 95
new 0 31 95
assign 1 31 96
add 1 31 96
assign 1 31 97
new 0 31 97
assign 1 31 98
finalAssign 4 31 98
addValue 1 31 99
assign 1 36 104
new 0 36 104
return 1 36 105
assign 1 40 114
isFinalGet 0 40 114
assign 1 0 116
assign 1 40 119
def 1 40 124
assign 1 40 125
isFinalGet 0 40 125
assign 1 0 127
assign 1 0 130
assign 1 0 134
assign 1 0 137
assign 1 0 140
assign 1 41 144
new 0 41 144
return 1 41 145
assign 1 43 147
new 0 43 147
return 1 43 148
assign 1 47 156
def 1 47 161
assign 1 47 162
isFinalGet 0 47 162
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 48 174
new 0 48 174
return 1 48 175
assign 1 50 177
new 0 50 177
return 1 50 178
assign 1 54 182
new 0 54 182
return 1 54 183
assign 1 58 190
new 0 58 190
assign 1 58 191
add 1 58 191
assign 1 58 192
new 0 58 192
assign 1 58 193
add 1 58 193
return 1 58 194
getCode 2 63 200
assign 1 64 201
toHexString 1 64 201
assign 1 65 202
new 0 65 202
assign 1 65 203
once 0 65 203
addValue 1 65 204
addValue 1 66 205
assign 1 72 214
new 0 72 214
assign 1 72 215
add 1 72 215
assign 1 72 216
new 0 72 216
assign 1 72 217
add 1 72 217
assign 1 72 218
add 1 72 218
return 1 72 219
assign 1 76 241
new 0 76 241
assign 1 76 242
add 1 76 242
assign 1 76 243
new 0 76 243
assign 1 76 244
add 1 76 244
assign 1 76 245
add 1 76 245
assign 1 77 246
new 0 77 246
assign 1 77 247
addValue 1 77 247
assign 1 77 248
addValue 1 77 248
assign 1 77 249
new 0 77 249
assign 1 77 250
addValue 1 77 250
addValue 1 77 251
assign 1 78 252
new 0 78 252
assign 1 78 253
addValue 1 78 253
addValue 1 78 254
assign 1 79 255
new 0 79 255
assign 1 79 256
addValue 1 79 256
assign 1 79 257
outputPlatformGet 0 79 257
assign 1 79 258
nameGet 0 79 258
assign 1 79 259
addValue 1 79 259
assign 1 79 260
new 0 79 260
assign 1 79 261
addValue 1 79 261
addValue 1 79 262
return 1 80 263
assign 1 84 268
libNameGet 0 84 268
assign 1 84 269
beginNs 1 84 269
return 1 84 270
assign 1 88 279
new 0 88 279
assign 1 88 280
libNs 1 88 280
assign 1 88 281
add 1 88 281
assign 1 88 282
new 0 88 282
assign 1 88 283
add 1 88 283
assign 1 88 284
add 1 88 284
return 1 88 285
assign 1 92 289
getNameSpace 1 92 289
return 1 92 290
assign 1 96 295
new 0 96 295
assign 1 96 296
add 1 96 296
return 1 96 297
assign 1 100 303
new 0 100 303
assign 1 100 304
once 0 100 304
assign 1 100 305
add 1 100 305
return 1 100 306
assign 1 104 310
new 0 104 310
return 1 104 311
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 998559612: return bem_buildGet_0();
case -724885584: return bem_nlGet_0();
case -1197182710: return bem_serializeToString_0();
case -816334231: return bem_callNamesGet_0();
case -874486665: return bem_beginNs_0();
case 403847041: return bem_lastMethodsLinesGet_0();
case -299653928: return bem_boolNpGet_0();
case 1449516553: return bem_copy_0();
case -1829845797: return bem_initialDecGet_0();
case -1713860826: return bem_mainEndGet_0();
case 1431740587: return bem_coanyiantReturnsGet_0();
case 717772505: return bem_doEmit_0();
case 178551585: return bem_saveSyns_0();
case 866679447: return bem_serializationIteratorGet_0();
case 1891156754: return bem_libEmitPathGet_0();
case 1031630483: return bem_dynMethodsGet_0();
case 333650516: return bem_classConfGet_0();
case -1750402307: return bem_classCallsGet_0();
case 1661135014: return bem_ntypesGet_0();
case 324998005: return bem_lastCallGet_0();
case 1759521942: return bem_superCallsGet_0();
case 1544924550: return bem_instanceNotEqualGet_0();
case 1090806872: return bem_falseValueGet_0();
case 838073469: return bem_fullLibEmitNameGet_0();
case -1512663010: return bem_classEmitsGet_0();
case -117420215: return bem_serializeContents_0();
case 862718722: return bem_nullValueGet_0();
case 1649797248: return bem_msynGet_0();
case -1705055765: return bem_getLibOutput_0();
case 409089614: return bem_lastMethodBodyLinesGet_0();
case 288696693: return bem_afterCast_0();
case 1663082460: return bem_endNs_0();
case 249203097: return bem_scvpGet_0();
case 1611902099: return bem_onceDecsGet_0();
case 1501379702: return bem_cnodeGet_0();
case 1053098123: return bem_hashGet_0();
case -1672813427: return bem_mnodeGet_0();
case 1044607447: return bem_deserializeClassNameGet_0();
case -1065169191: return bem_transGet_0();
case 1175461532: return bem_classesInDepthOrderGet_0();
case 316635538: return bem_getClassOutput_0();
case 1028596389: return bem_baseSmtdDecGet_0();
case -1620819332: return bem_once_0();
case 1766943572: return bem_maxDynArgsGet_0();
case 2011054361: return bem_nameToIdGet_0();
case -475729755: return bem_classEndGet_0();
case -1187636146: return bem_intNpGet_0();
case 2092326455: return bem_many_0();
case 981910644: return bem_buildInitial_0();
case -1763044920: return bem_libEmitNameGet_0();
case 168705805: return bem_iteratorGet_0();
case 65678538: return bem_echo_0();
case -1703365440: return bem_boolCcGet_0();
case -1272774710: return bem_returnTypeGet_0();
case -441598317: return bem_emitLib_0();
case 1008740366: return bem_superNameGet_0();
case -684374540: return bem_synEmitPathGet_0();
case -958749621: return bem_useDynMethodsGet_0();
case 845917022: return bem_fieldIteratorGet_0();
case -85026949: return bem_mainOutsideNsGet_0();
case -935771084: return bem_sourceFileNameGet_0();
case -1731537432: return bem_nativeCSlotsGet_0();
case 946525978: return bem_lineCountGet_0();
case -1712633963: return bem_toAny_0();
case 386788561: return bem_new_0();
case -1975952737: return bem_tagGet_0();
case -430007484: return bem_spropDecGet_0();
case -275108767: return bem_fileExtGet_0();
case 582818432: return bem_create_0();
case -510586993: return bem_lastMethodsSizeGet_0();
case 494977015: return bem_trueValueGet_0();
case 231783279: return bem_ccCacheGet_0();
case 244132753: return bem_boolTypeGet_0();
case -784675241: return bem_smnlcsGet_0();
case -1970443442: return bem_buildClassInfo_0();
case 89389756: return bem_qGet_0();
case 1353181025: return bem_csynGet_0();
case -795939421: return bem_overrideMtdDecGet_0();
case -1348335897: return bem_methodsGet_0();
case -2006545388: return bem_emitLangGet_0();
case 1684834913: return bem_maxSpillArgsLenGet_0();
case 2100223710: return bem_invpGet_0();
case -601432089: return bem_onceCountGet_0();
case 224869613: return bem_smnlecsGet_0();
case 1637405965: return bem_toString_0();
case 1754753899: return bem_instanceEqualGet_0();
case 1582456567: return bem_preClassGet_0();
case -386682859: return bem_ccMethodsGet_0();
case -1357461730: return bem_exceptDecGet_0();
case -119028255: return bem_floatNpGet_0();
case -1639509116: return bem_mainInClassGet_0();
case -261636586: return bem_classNameGet_0();
case -215561367: return bem_propertyDecsGet_0();
case -1343253091: return bem_runtimeInitGet_0();
case -1734218307: return bem_parentConfGet_0();
case 770672270: return bem_baseMtdDecGet_0();
case -1406486124: return bem_constGet_0();
case -87427138: return bem_instOfGet_0();
case -1646417550: return bem_objectCcGet_0();
case 410845753: return bem_methodBodyGet_0();
case 1243912834: return bem_objectNpGet_0();
case -1005405751: return bem_mainStartGet_0();
case 881848957: return bem_lastMethodBodySizeGet_0();
case -1637242716: return bem_randGet_0();
case 1342246094: return bem_print_0();
case 1834364818: return bem_idToNameGet_0();
case 1887700473: return bem_methodCatchGet_0();
case -1236962335: return bem_stringNpGet_0();
case 349412188: return bem_inFilePathedGet_0();
case 384570708: return bem_propDecGet_0();
case 764035527: return bem_buildCreate_0();
case -774294169: return bem_methodCallsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -245369953: return bem_instanceNotEqualSet_1(bevd_0);
case -1711792917: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -620789734: return bem_msynSet_1(bevd_0);
case 673393098: return bem_objectNpSet_1(bevd_0);
case -755784958: return bem_lastMethodsSizeSet_1(bevd_0);
case 1597366700: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1643598858: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1208489178: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2037318669: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 203787014: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 204436918: return bem_idToNameSet_1(bevd_0);
case -276885629: return bem_dynMethodsSet_1(bevd_0);
case 1497573625: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 905516595: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 462734292: return bem_maxDynArgsSet_1(bevd_0);
case 1087621394: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -578385075: return bem_fullLibEmitNameSet_1(bevd_0);
case -705833712: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1890118127: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 692562594: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -448341852: return bem_smnlcsSet_1(bevd_0);
case -948921734: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -723986488: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -119452223: return bem_onceCountSet_1(bevd_0);
case -333966351: return bem_smnlecsSet_1(bevd_0);
case -943495125: return bem_synEmitPathSet_1(bevd_0);
case 1236896327: return bem_lastCallSet_1(bevd_0);
case -483614410: return bem_nullValueSet_1(bevd_0);
case 683657476: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -772227381: return bem_lineCountSet_1(bevd_0);
case 1966161877: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1137622174: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1741644079: return bem_fileExtSet_1(bevd_0);
case -2002464033: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1016055328: return bem_transSet_1(bevd_0);
case 113636171: return bem_methodCallsSet_1(bevd_0);
case 1908120494: return bem_qSet_1(bevd_0);
case -1123596445: return bem_undef_1(bevd_0);
case 1075077404: return bem_falseValueSet_1(bevd_0);
case 341493510: return bem_sameObject_1(bevd_0);
case 1686881615: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1485088644: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 46520874: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1728391044: return bem_libEmitNameSet_1(bevd_0);
case -1109046842: return bem_stringNpSet_1(bevd_0);
case 10259715: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 988858322: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -994928324: return bem_sameClass_1(bevd_0);
case 820672965: return bem_randSet_1(bevd_0);
case 199161372: return bem_ccCacheSet_1(bevd_0);
case -630650023: return bem_csynSet_1(bevd_0);
case 367531753: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1149971919: return bem_otherClass_1(bevd_0);
case -244090501: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1615498723: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1310725358: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -441177172: return bem_boolCcSet_1(bevd_0);
case -180959661: return bem_instOfSet_1(bevd_0);
case 272124194: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -675194535: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -258826870: return bem_lastMethodsLinesSet_1(bevd_0);
case -775221825: return bem_nativeCSlotsSet_1(bevd_0);
case 389266338: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 357099289: return bem_maxSpillArgsLenSet_1(bevd_0);
case -633822688: return bem_parentConfSet_1(bevd_0);
case -1471570539: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1274421718: return bem_superCallsSet_1(bevd_0);
case -13884270: return bem_floatNpSet_1(bevd_0);
case -973544430: return bem_methodBodySet_1(bevd_0);
case -1509932044: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1921133350: return bem_defined_1(bevd_0);
case 1535547825: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1242953722: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -2051613741: return bem_callNamesSet_1(bevd_0);
case 983199503: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1309353780: return bem_mnodeSet_1(bevd_0);
case 1405280345: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1980235675: return bem_libEmitPathSet_1(bevd_0);
case -581638533: return bem_otherType_1(bevd_0);
case -908914129: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 301795029: return bem_methodsSet_1(bevd_0);
case -1635745404: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1960557313: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -213316832: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1678404028: return bem_instanceEqualSet_1(bevd_0);
case 1560206089: return bem_begin_1(bevd_0);
case -1043128567: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1303260969: return bem_ccMethodsSet_1(bevd_0);
case 1434165319: return bem_ntypesSet_1(bevd_0);
case -825865961: return bem_boolNpSet_1(bevd_0);
case 1572257749: return bem_inFilePathedSet_1(bevd_0);
case -1960711306: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 361568569: return bem_returnTypeSet_1(bevd_0);
case -1178695137: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1157448531: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 780018541: return bem_emitLangSet_1(bevd_0);
case -1064936758: return bem_nlSet_1(bevd_0);
case 838881794: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -410066392: return bem_propertyDecsSet_1(bevd_0);
case -1843137123: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1027952049: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -681271476: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1716916256: return bem_objectCcSet_1(bevd_0);
case 953768146: return bem_def_1(bevd_0);
case -1850880172: return bem_undefined_1(bevd_0);
case 53465634: return bem_nameToIdSet_1(bevd_0);
case 1590710137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 947929009: return bem_preClassSet_1(bevd_0);
case 1958693024: return bem_copyTo_1(bevd_0);
case 198232146: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 707881002: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 656236943: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1423299129: return bem_classEmitsSet_1(bevd_0);
case -196631197: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1541475808: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1277494840: return bem_cnodeSet_1(bevd_0);
case 2068598019: return bem_onceDecsSet_1(bevd_0);
case 735281181: return bem_trueValueSet_1(bevd_0);
case -1595917584: return bem_sameType_1(bevd_0);
case 882678331: return bem_equals_1(bevd_0);
case 814841054: return bem_notEquals_1(bevd_0);
case -803982835: return bem_intNpSet_1(bevd_0);
case 544976745: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1380941901: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1225366337: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1891771035: return bem_classConfSet_1(bevd_0);
case 98637250: return bem_classCallsSet_1(bevd_0);
case -494154463: return bem_scvpSet_1(bevd_0);
case -426446534: return bem_end_1(bevd_0);
case -1728184030: return bem_methodCatchSet_1(bevd_0);
case -359304999: return bem_invpSet_1(bevd_0);
case -214808649: return bem_constSet_1(bevd_0);
case -2009733373: return bem_buildSet_1(bevd_0);
case 985248038: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -491820244: return bem_classesInDepthOrderSet_1(bevd_0);
case 1314874378: return bem_exceptDecSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1181568840: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -2099572575: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -772598030: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -327621007: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1979849071: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -649478949: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1651140441: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1887882040: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1722452815: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -595774731: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 795294323: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 287041203: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -335449250: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2117679624: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1255485143: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1673931310: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -540472349: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1171906177: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -531802304: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1195056449: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1754447765: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1097111945: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -181027971: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -708269337: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1958589004: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -1062830680: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
}
