package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x20,0x3A,0x20};
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(-560538525);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-1214698492);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(1256531013);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-1214698492);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(1256531013);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_42_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_41_ta_ph = bevl_bet.bem_addValue_1(bevt_42_ta_ph);
bevt_43_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_40_ta_ph = bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevt_40_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_45_ta_ph);
bevt_48_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_47_ta_ph = bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevt_49_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_46_ta_ph = bevt_47_ta_ph.bem_addValue_1(bevt_49_ta_ph);
bevt_50_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevt_46_ta_ph.bem_addValue_1(bevt_50_ta_ph);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevl_tout.bemd_1(644793263, bevl_bet);
bevl_tout.bemd_0(1122071457);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-393302877);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1707726694);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, bevt_16_ta_ph);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
if (beva_msyn == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_3_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 86*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 86*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 86*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
return bevt_4_ta_ph;
} /* Line: 87*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 93*/
 else /* Line: 93*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 93*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 94*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 118*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(48, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_exceptDec);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevl_ms = bevt_3_ta_ph.bem_add_1(bevp_nl);
} /* Line: 119*/
 else /* Line: 120*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildCSEmitter_bels_36));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_exceptDec);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
bevl_ms = bevt_7_ta_ph.bem_add_1(bevp_nl);
} /* Line: 121*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_37));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_38));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_39));
bevt_16_ta_ph = bevl_ms.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_20_ta_ph = bevl_ms.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(199171418);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_18_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 62, 62, 62, 62, 63, 63, 64, 64, 64, 64, 64, 64, 65, 65, 66, 66, 67, 67, 68, 69, 73, 73, 73, 74, 75, 75, 75, 75, 75, 75, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 77, 82, 82, 86, 0, 86, 86, 86, 0, 0, 0, 0, 0, 87, 87, 89, 89, 93, 93, 93, 0, 0, 0, 94, 94, 96, 96, 100, 100, 105, 106, 107, 107, 108, 114, 114, 114, 114, 114, 114, 118, 118, 118, 119, 119, 119, 119, 119, 121, 121, 121, 121, 121, 123, 123, 123, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 130, 130, 130, 134, 134, 134, 134, 134, 134, 134, 138, 138, 142, 142, 142, 146, 146, 146, 150, 150};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {57, 58, 59, 60, 124, 125, 126, 127, 132, 133, 134, 135, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 160, 163, 165, 167, 170, 171, 173, 174, 175, 176, 182, 183, 184, 185, 186, 187, 188, 189, 190, 190, 193, 195, 197, 200, 201, 203, 204, 205, 206, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 284, 285, 294, 296, 299, 304, 305, 307, 310, 314, 317, 320, 324, 325, 327, 328, 336, 341, 342, 344, 347, 351, 354, 355, 357, 358, 362, 363, 368, 369, 370, 371, 372, 381, 382, 383, 384, 385, 386, 415, 416, 417, 419, 420, 421, 422, 423, 426, 427, 428, 429, 430, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 454, 455, 456, 465, 466, 467, 468, 469, 470, 471, 475, 476, 481, 482, 483, 488, 489, 490, 494, 495};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 16 57
new 0 16 57
assign 1 17 58
new 0 17 58
assign 1 18 59
new 0 18 59
new 1 22 60
assign 1 26 124
classDirGet 0 26 124
assign 1 26 125
fileGet 0 26 125
assign 1 26 126
existsGet 0 26 126
assign 1 26 127
not 0 26 132
assign 1 27 133
classDirGet 0 27 133
assign 1 27 134
fileGet 0 27 134
makeDirs 0 27 135
assign 1 29 137
typePathGet 0 29 137
assign 1 29 138
fileGet 0 29 138
assign 1 29 139
writerGet 0 29 139
assign 1 29 140
open 0 29 140
assign 1 30 141
new 0 30 141
assign 1 31 142
new 0 31 142
addValue 1 31 143
assign 1 32 144
new 0 32 144
assign 1 32 145
addValue 1 32 145
assign 1 32 146
typeEmitNameGet 0 32 146
assign 1 32 147
addValue 1 32 147
assign 1 32 148
new 0 32 148
addValue 1 32 149
assign 1 33 150
new 0 33 150
assign 1 33 151
addValue 1 33 151
assign 1 33 152
typeEmitNameGet 0 33 152
assign 1 33 153
addValue 1 33 153
assign 1 33 154
new 0 33 154
addValue 1 33 155
assign 1 35 156
new 0 35 156
addValue 1 35 157
assign 1 36 158
new 0 36 158
assign 1 37 159
mtdListGet 0 37 159
assign 1 37 160
iteratorGet 0 0 160
assign 1 37 163
hasNextGet 0 37 163
assign 1 37 165
nextGet 0 37 165
assign 1 39 167
new 0 39 167
assign 1 41 170
new 0 41 170
addValue 1 41 171
assign 1 43 173
addValue 1 43 173
assign 1 43 174
nameGet 0 43 174
assign 1 43 175
addValue 1 43 175
addValue 1 43 176
assign 1 45 182
new 0 45 182
addValue 1 45 183
assign 1 46 184
new 0 46 184
addValue 1 46 185
assign 1 48 186
new 0 48 186
addValue 1 48 187
assign 1 49 188
new 0 49 188
assign 1 50 189
ptyListGet 0 50 189
assign 1 50 190
iteratorGet 0 0 190
assign 1 50 193
hasNextGet 0 50 193
assign 1 50 195
nextGet 0 50 195
assign 1 52 197
new 0 52 197
assign 1 54 200
new 0 54 200
addValue 1 54 201
assign 1 56 203
addValue 1 56 203
assign 1 56 204
nameGet 0 56 204
assign 1 56 205
addValue 1 56 205
addValue 1 56 206
assign 1 58 212
new 0 58 212
addValue 1 58 213
assign 1 60 214
new 0 60 214
addValue 1 60 215
assign 1 62 216
new 0 62 216
assign 1 62 217
addValue 1 62 217
assign 1 62 218
typeEmitNameGet 0 62 218
assign 1 62 219
addValue 1 62 219
assign 1 62 220
new 0 62 220
addValue 1 62 221
assign 1 63 222
new 0 63 222
addValue 1 63 223
assign 1 64 224
new 0 64 224
assign 1 64 225
addValue 1 64 225
assign 1 64 226
emitNameGet 0 64 226
assign 1 64 227
addValue 1 64 227
assign 1 64 228
new 0 64 228
addValue 1 64 229
assign 1 65 230
new 0 65 230
addValue 1 65 231
assign 1 66 232
new 0 66 232
addValue 1 66 233
assign 1 67 234
new 0 67 234
addValue 1 67 235
write 1 68 236
close 0 69 237
assign 1 73 259
new 0 73 259
assign 1 73 260
toString 0 73 260
assign 1 73 261
add 1 73 261
incrementValue 0 74 262
assign 1 75 263
new 0 75 263
assign 1 75 264
addValue 1 75 264
assign 1 75 265
addValue 1 75 265
assign 1 75 266
new 0 75 266
assign 1 75 267
addValue 1 75 267
addValue 1 75 268
assign 1 77 269
containedGet 0 77 269
assign 1 77 270
firstGet 0 77 270
assign 1 77 271
containedGet 0 77 271
assign 1 77 272
firstGet 0 77 272
assign 1 77 273
new 0 77 273
assign 1 77 274
add 1 77 274
assign 1 77 275
new 0 77 275
assign 1 77 276
add 1 77 276
assign 1 77 277
new 0 77 277
assign 1 77 278
finalAssign 4 77 278
addValue 1 77 279
assign 1 82 284
new 0 82 284
return 1 82 285
assign 1 86 294
isFinalGet 0 86 294
assign 1 0 296
assign 1 86 299
def 1 86 304
assign 1 86 305
isFinalGet 0 86 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 0 317
assign 1 0 320
assign 1 87 324
new 0 87 324
return 1 87 325
assign 1 89 327
new 0 89 327
return 1 89 328
assign 1 93 336
def 1 93 341
assign 1 93 342
isFinalGet 0 93 342
assign 1 0 344
assign 1 0 347
assign 1 0 351
assign 1 94 354
new 0 94 354
return 1 94 355
assign 1 96 357
new 0 96 357
return 1 96 358
assign 1 100 362
new 0 100 362
return 1 100 363
getCode 2 105 368
assign 1 106 369
toHexString 1 106 369
assign 1 107 370
new 0 107 370
addValue 1 107 371
addValue 1 108 372
assign 1 114 381
new 0 114 381
assign 1 114 382
add 1 114 382
assign 1 114 383
new 0 114 383
assign 1 114 384
add 1 114 384
assign 1 114 385
add 1 114 385
return 1 114 386
assign 1 118 415
emitChecksGet 0 118 415
assign 1 118 416
new 0 118 416
assign 1 118 417
has 1 118 417
assign 1 119 419
new 0 119 419
assign 1 119 420
add 1 119 420
assign 1 119 421
new 0 119 421
assign 1 119 422
add 1 119 422
assign 1 119 423
add 1 119 423
assign 1 121 426
new 0 121 426
assign 1 121 427
add 1 121 427
assign 1 121 428
new 0 121 428
assign 1 121 429
add 1 121 429
assign 1 121 430
add 1 121 430
assign 1 123 432
new 0 123 432
assign 1 123 433
addValue 1 123 433
assign 1 123 434
addValue 1 123 434
assign 1 123 435
new 0 123 435
assign 1 123 436
addValue 1 123 436
addValue 1 123 437
assign 1 124 438
new 0 124 438
assign 1 124 439
addValue 1 124 439
addValue 1 124 440
assign 1 125 441
new 0 125 441
assign 1 125 442
addValue 1 125 442
assign 1 125 443
outputPlatformGet 0 125 443
assign 1 125 444
nameGet 0 125 444
assign 1 125 445
addValue 1 125 445
assign 1 125 446
new 0 125 446
assign 1 125 447
addValue 1 125 447
addValue 1 125 448
return 1 126 449
assign 1 130 454
libNameGet 0 130 454
assign 1 130 455
beginNs 1 130 455
return 1 130 456
assign 1 134 465
new 0 134 465
assign 1 134 466
libNs 1 134 466
assign 1 134 467
add 1 134 467
assign 1 134 468
new 0 134 468
assign 1 134 469
add 1 134 469
assign 1 134 470
add 1 134 470
return 1 134 471
assign 1 138 475
getNameSpace 1 138 475
return 1 138 476
assign 1 142 481
new 0 142 481
assign 1 142 482
add 1 142 482
return 1 142 483
assign 1 146 488
new 0 146 488
assign 1 146 489
add 1 146 489
return 1 146 490
assign 1 150 494
new 0 150 494
return 1 150 495
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 385428896: return bem_saveIds_0();
case -395536224: return bem_iteratorGet_0();
case -96677338: return bem_copy_0();
case 735499144: return bem_invpGet_0();
case 585491040: return bem_emitLib_0();
case 875968694: return bem_classEndGet_0();
case -1982808513: return bem_boolTypeGet_0();
case -953319820: return bem_mainInClassGet_0();
case 299271022: return bem_hashGet_0();
case -833916477: return bem_inFilePathedGet_0();
case -125015202: return bem_buildGet_0();
case 18727052: return bem_writeBET_0();
case -83883564: return bem_superCallsGet_0();
case -200481924: return bem_idToNamePathGet_0();
case -1426886510: return bem_libEmitNameGet_0();
case -1456177122: return bem_lineCountGet_0();
case -432619662: return bem_useDynMethodsGet_0();
case -18783984: return bem_lastCallGet_0();
case 574431004: return bem_preClassOutput_0();
case 2119262036: return bem_belslitsGet_0();
case 232502323: return bem_synEmitPathGet_0();
case 1331555692: return bem_returnTypeGet_0();
case -832926775: return bem_trueValueGet_0();
case 4479169: return bem_instOfGet_0();
case 2120245748: return bem_endNs_0();
case 12273323: return bem_getLibOutput_0();
case 1599817570: return bem_smnlcsGet_0();
case -1927784181: return bem_typeDecGet_0();
case -906996412: return bem_buildClassInfo_0();
case -769857637: return bem_preClassGet_0();
case -940807410: return bem_lastMethodsSizeGet_0();
case 1019314301: return bem_nameToIdGet_0();
case 1799552386: return bem_new_0();
case 825006787: return bem_spropDecGet_0();
case -761811500: return bem_buildCreate_0();
case 1156520788: return bem_objectNpGet_0();
case -1516885820: return bem_baseMtdDecGet_0();
case 1458422952: return bem_smnlecsGet_0();
case 181257429: return bem_falseValueGet_0();
case -1085765028: return bem_randGet_0();
case -897268902: return bem_methodBodyGet_0();
case 19893978: return bem_initialDecGet_0();
case -1270727633: return bem_lastMethodsLinesGet_0();
case 1836120770: return bem_stringNpGet_0();
case -738154070: return bem_intNpGet_0();
case 773385196: return bem_boolNpGet_0();
case 724078247: return bem_propertyDecsGet_0();
case -1436093512: return bem_classCallsGet_0();
case 1233698284: return bem_methodsGet_0();
case 742692896: return bem_superNameGet_0();
case -942793427: return bem_fullLibEmitNameGet_0();
case 890049802: return bem_runtimeInitGet_0();
case -1147592640: return bem_ccCacheGet_0();
case -2092191343: return bem_ccMethodsGet_0();
case -1467233357: return bem_mainEndGet_0();
case -891769806: return bem_transGet_0();
case -408051328: return bem_mainOutsideNsGet_0();
case 299960272: return bem_classEmitsGet_0();
case -1447441440: return bem_nativeCSlotsGet_0();
case -2045774058: return bem_parentConfGet_0();
case -1650271695: return bem_maxSpillArgsLenGet_0();
case -177144816: return bem_instanceEqualGet_0();
case 541020355: return bem_floatNpGet_0();
case 236742011: return bem_idToNameGet_0();
case 409886638: return bem_buildInitial_0();
case -311861408: return bem_libEmitPathGet_0();
case 2040720527: return bem_covariantReturnsGet_0();
case -263052479: return bem_gcMarksGet_0();
case 180232791: return bem_cnodeGet_0();
case 420064740: return bem_csynGet_0();
case 894109392: return bem_instanceNotEqualGet_0();
case 1559548937: return bem_newDecGet_0();
case 1015244994: return bem_methodCatchGet_0();
case -541031322: return bem_boolCcGet_0();
case -1663812924: return bem_scvpGet_0();
case -560900152: return bem_exceptDecGet_0();
case -995061177: return bem_propDecGet_0();
case 910094291: return bem_callNamesGet_0();
case -703178742: return bem_doEmit_0();
case -370604220: return bem_nullValueGet_0();
case 2134125759: return bem_nlGet_0();
case -1363848989: return bem_fileExtGet_0();
case -611841005: return bem_dynMethodsGet_0();
case -1013891004: return bem_constGet_0();
case 772503647: return bem_objectCcGet_0();
case -610122682: return bem_loadIds_0();
case 613673165: return bem_overrideMtdDecGet_0();
case -874363736: return bem_getClassOutput_0();
case -1868486131: return bem_msynGet_0();
case 338544036: return bem_onceDecsGet_0();
case -228442595: return bem_lastMethodBodySizeGet_0();
case 1498797695: return bem_emitLangGet_0();
case -1044946195: return bem_qGet_0();
case -1291461014: return bem_beginNs_0();
case -185767821: return bem_mnodeGet_0();
case -1419957305: return bem_classesInDepthOrderGet_0();
case -1567105080: return bem_ntypesGet_0();
case -2035203049: return bem_classConfGet_0();
case 1341364362: return bem_create_0();
case -734513744: return bem_methodCallsGet_0();
case 1463266925: return bem_maxDynArgsGet_0();
case 588452642: return bem_afterCast_0();
case 638949253: return bem_nameToIdPathGet_0();
case 1972123084: return bem_inClassGet_0();
case 254172080: return bem_baseSmtdDecGet_0();
case -116845747: return bem_mainStartGet_0();
case 1884194420: return bem_print_0();
case 1252588871: return bem_saveSyns_0();
case -1152814540: return bem_toString_0();
case 464115591: return bem_lastMethodBodyLinesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 999936046: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1926929684: return bem_emitLangSet_1(bevd_0);
case -1555025459: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -2134768854: return bem_classConfSet_1(bevd_0);
case -1778695627: return bem_callNamesSet_1(bevd_0);
case -431266740: return bem_qSet_1(bevd_0);
case 447539969: return bem_nlSet_1(bevd_0);
case 724866682: return bem_ccCacheSet_1(bevd_0);
case -545781333: return bem_classCallsSet_1(bevd_0);
case -1771343756: return bem_lastMethodsSizeSet_1(bevd_0);
case 2025782284: return bem_lastCallSet_1(bevd_0);
case -440949788: return bem_begin_1(bevd_0);
case 1787322254: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1395011218: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1971702032: return bem_scvpSet_1(bevd_0);
case 1964669472: return bem_idToNamePathSet_1(bevd_0);
case -302199064: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -194560567: return bem_boolNpSet_1(bevd_0);
case 787899300: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -2061897513: return bem_invpSet_1(bevd_0);
case 2072713589: return bem_instanceEqualSet_1(bevd_0);
case 810188638: return bem_instanceNotEqualSet_1(bevd_0);
case -68969026: return bem_preClassSet_1(bevd_0);
case -274087259: return bem_methodCallsSet_1(bevd_0);
case 587476738: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2012144358: return bem_boolCcSet_1(bevd_0);
case 652032270: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -248677921: return bem_methodBodySet_1(bevd_0);
case 1182569023: return bem_end_1(bevd_0);
case 336140040: return bem_objectNpSet_1(bevd_0);
case 7859397: return bem_intNpSet_1(bevd_0);
case -227838209: return bem_fullLibEmitNameSet_1(bevd_0);
case -23057798: return bem_idToNameSet_1(bevd_0);
case -1591574129: return bem_lastMethodBodySizeSet_1(bevd_0);
case -596806596: return bem_ccMethodsSet_1(bevd_0);
case -1060687291: return bem_trueValueSet_1(bevd_0);
case -1596183751: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1959289633: return bem_belslitsSet_1(bevd_0);
case -2127945914: return bem_smnlecsSet_1(bevd_0);
case 753397060: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1114353218: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 2109083904: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 270193694: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1536023054: return bem_falseValueSet_1(bevd_0);
case -1569705786: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -662031824: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 124133917: return bem_methodCatchSet_1(bevd_0);
case -2057319216: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 11999451: return bem_fileExtSet_1(bevd_0);
case -1264565161: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1874754523: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1181577618: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 2013118452: return bem_inClassSet_1(bevd_0);
case -87767287: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -838884764: return bem_instOfSet_1(bevd_0);
case 701414524: return bem_ntypesSet_1(bevd_0);
case 232976470: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -904751583: return bem_undef_1(bevd_0);
case 796201002: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1726870629: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 716702050: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1365979047: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 935099335: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -538058964: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1468636493: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 2024128203: return bem_lastMethodsLinesSet_1(bevd_0);
case 404550472: return bem_superCallsSet_1(bevd_0);
case -723160601: return bem_objectCcSet_1(bevd_0);
case 923094993: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 214824155: return bem_synEmitPathSet_1(bevd_0);
case -1939196808: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -823696003: return bem_classesInDepthOrderSet_1(bevd_0);
case 528517630: return bem_floatNpSet_1(bevd_0);
case 1571720980: return bem_exceptDecSet_1(bevd_0);
case -422614232: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1183374659: return bem_randSet_1(bevd_0);
case -551132548: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 903640429: return bem_msynSet_1(bevd_0);
case 468363036: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 249652620: return bem_nameToIdSet_1(bevd_0);
case -572660422: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1551818071: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 366445864: return bem_constSet_1(bevd_0);
case 1365896705: return bem_smnlcsSet_1(bevd_0);
case -1369993432: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -2135698186: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1132657384: return bem_buildSet_1(bevd_0);
case 1168714019: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 623811155: return bem_propertyDecsSet_1(bevd_0);
case -498075211: return bem_mnodeSet_1(bevd_0);
case -158441044: return bem_def_1(bevd_0);
case 2009037933: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -352215013: return bem_classEmitsSet_1(bevd_0);
case -407351766: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 362877566: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1124700543: return bem_inFilePathedSet_1(bevd_0);
case -1408153860: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1271159655: return bem_nativeCSlotsSet_1(bevd_0);
case -539988354: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1495050931: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 6887342: return bem_lineCountSet_1(bevd_0);
case 1618591166: return bem_maxSpillArgsLenSet_1(bevd_0);
case -857486820: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1542854247: return bem_gcMarksSet_1(bevd_0);
case 793871222: return bem_transSet_1(bevd_0);
case -659088107: return bem_equals_1(bevd_0);
case -1110761722: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1756955442: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1850749975: return bem_libEmitPathSet_1(bevd_0);
case 25777534: return bem_notEquals_1(bevd_0);
case -994840806: return bem_parentConfSet_1(bevd_0);
case 243846208: return bem_stringNpSet_1(bevd_0);
case -1371244095: return bem_nameToIdPathSet_1(bevd_0);
case 473345130: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1829987045: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -2064930837: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 95378775: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1301987020: return bem_nullValueSet_1(bevd_0);
case 291118235: return bem_methodsSet_1(bevd_0);
case -1319083297: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case -2028161849: return bem_maxDynArgsSet_1(bevd_0);
case 1292080003: return bem_copyTo_1(bevd_0);
case 1618327690: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1547848255: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 273573699: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 708230763: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 2069620437: return bem_dynMethodsSet_1(bevd_0);
case -195969559: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1314274221: return bem_returnTypeSet_1(bevd_0);
case -1864588209: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1894100529: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1192690313: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 450101029: return bem_onceDecsSet_1(bevd_0);
case -1874587467: return bem_cnodeSet_1(bevd_0);
case 1369868625: return bem_libEmitNameSet_1(bevd_0);
case 751587283: return bem_csynSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1371013688: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -94082723: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -979237626: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -446818620: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 783026306: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 60014128: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 70167069: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -65106961: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2008502583: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1102317820: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -252678892: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1888475258: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -869432918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2070900263: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1469457957: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 617695149: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 694057200: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1557816753: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 2120051714: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 843871782: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1407535130: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 101158596: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1929310537: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -1003817982: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1983620216: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -999966107: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
