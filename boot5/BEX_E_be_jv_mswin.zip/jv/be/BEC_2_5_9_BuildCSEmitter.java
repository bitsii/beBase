package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x20,0x3A,0x20};
public static BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public BEC_2_5_9_BuildCSEmitter bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_writeBET_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 32*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 33*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(-324454467);
bevl_bet = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_13_ta_ph = bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_18_ta_ph = bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 43*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-2045504457);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 43*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(1855989374);
if (bevl_firstmnsyn.bevi_bool)/* Line: 44*/ {
bevl_firstmnsyn = be.BECS_Runtime.boolFalse;
} /* Line: 45*/
 else /* Line: 46*/ {
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 47*/
bevt_27_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 49*/
 else /* Line: 43*/ {
break;
} /* Line: 43*/
} /* Line: 43*/
bevt_29_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 56*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-2045504457);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 56*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(1855989374);
bevt_34_ta_ph = bevl_ptySyn.bem_isSlotGet_0();
if (!(bevt_34_ta_ph.bevi_bool))/* Line: 57*/ {
if (bevl_firstptsyn.bevi_bool)/* Line: 58*/ {
bevl_firstptsyn = be.BECS_Runtime.boolFalse;
} /* Line: 59*/
 else /* Line: 60*/ {
bevt_35_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_35_ta_ph);
} /* Line: 61*/
bevt_37_ta_ph = bevl_bet.bem_addValue_1(bevp_q);
bevt_38_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_36_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 63*/
} /* Line: 57*/
 else /* Line: 56*/ {
break;
} /* Line: 56*/
} /* Line: 56*/
bevt_39_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_43_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_42_ta_ph = bevl_bet.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevt_41_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevl_bet.bem_addValue_1(bevt_46_ta_ph);
bevt_49_ta_ph = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_48_ta_ph = bevl_bet.bem_addValue_1(bevt_49_ta_ph);
bevt_50_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_47_ta_ph = bevt_48_ta_ph.bem_addValue_1(bevt_50_ta_ph);
bevt_51_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevt_47_ta_ph.bem_addValue_1(bevt_51_ta_ph);
bevt_52_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_53_ta_ph);
bevt_54_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_54_ta_ph);
bevl_tout.bemd_1(1826422363, bevl_bet);
bevl_tout.bemd_0(890464415);
return this;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevt_4_ta_ph = bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_21));
bevt_2_ta_ph = bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(983253680);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(293093515);
bevt_14_ta_ph = (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, bevt_16_ta_ph);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_1_ta_ph = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
if (beva_msyn == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_3_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 94*/
 else /* Line: 94*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 94*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 94*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 94*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
return bevt_4_ta_ph;
} /* Line: 95*/
bevt_5_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_3_ta_ph;
} /* Line: 102*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_9_BuildCSEmitter bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCSEmitter_bels_33));
bevt_0_ta_ph = bevt_1_ta_ph.bem_contains_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 126*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(48, bece_BEC_2_5_9_BuildCSEmitter_bels_34));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_exceptDec);
bevt_6_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevl_ms = bevt_3_ta_ph.bem_add_1(bevp_nl);
} /* Line: 127*/
 else /* Line: 128*/ {
bevt_9_ta_ph = (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildCSEmitter_bels_36));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevp_exceptDec);
bevt_10_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_10_ta_ph);
bevl_ms = bevt_7_ta_ph.bem_add_1(bevp_nl);
} /* Line: 129*/
bevt_14_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_37));
bevt_13_ta_ph = bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_12_ta_ph = bevt_13_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_15_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_38));
bevt_11_ta_ph = bevt_12_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_17_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_39));
bevt_16_ta_ph = bevl_ms.bem_addValue_1(bevt_17_ta_ph);
bevt_16_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_20_ta_ph = bevl_ms.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(35517966);
bevt_19_ta_ph = bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_18_ta_ph = bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_18_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_35));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 23, 24, 28, 32, 32, 32, 32, 32, 33, 33, 33, 35, 35, 35, 35, 36, 37, 37, 38, 38, 38, 38, 38, 38, 39, 39, 39, 39, 39, 39, 41, 41, 42, 43, 43, 0, 43, 43, 45, 47, 47, 49, 49, 49, 49, 51, 51, 52, 52, 54, 54, 55, 56, 56, 0, 56, 56, 57, 59, 61, 61, 63, 63, 63, 63, 66, 66, 68, 68, 70, 70, 70, 70, 70, 70, 71, 71, 72, 72, 72, 72, 72, 72, 73, 73, 74, 74, 75, 75, 76, 77, 81, 81, 81, 82, 83, 83, 83, 83, 83, 83, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 90, 90, 94, 0, 94, 94, 94, 0, 0, 0, 0, 0, 95, 95, 97, 97, 101, 101, 101, 0, 0, 0, 102, 102, 104, 104, 108, 108, 113, 114, 115, 115, 116, 122, 122, 122, 122, 122, 122, 126, 126, 126, 127, 127, 127, 127, 127, 129, 129, 129, 129, 129, 131, 131, 131, 131, 131, 131, 132, 132, 132, 133, 133, 133, 133, 133, 133, 133, 133, 134, 138, 138, 138, 142, 142, 142, 142, 142, 142, 142, 146, 146, 150, 150, 150, 154, 154, 154, 158, 158};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {57, 58, 59, 60, 125, 126, 127, 128, 133, 134, 135, 136, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 161, 164, 166, 168, 171, 172, 174, 175, 176, 177, 183, 184, 185, 186, 187, 188, 189, 190, 191, 191, 194, 196, 197, 200, 203, 204, 206, 207, 208, 209, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 288, 289, 298, 300, 303, 308, 309, 311, 314, 318, 321, 324, 328, 329, 331, 332, 340, 345, 346, 348, 351, 355, 358, 359, 361, 362, 366, 367, 372, 373, 374, 375, 376, 385, 386, 387, 388, 389, 390, 419, 420, 421, 423, 424, 425, 426, 427, 430, 431, 432, 433, 434, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 458, 459, 460, 469, 470, 471, 472, 473, 474, 475, 479, 480, 485, 486, 487, 492, 493, 494, 498, 499};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 57
new 0 22 57
assign 1 23 58
new 0 23 58
assign 1 24 59
new 0 24 59
new 1 28 60
assign 1 32 125
classDirGet 0 32 125
assign 1 32 126
fileGet 0 32 126
assign 1 32 127
existsGet 0 32 127
assign 1 32 128
not 0 32 133
assign 1 33 134
classDirGet 0 33 134
assign 1 33 135
fileGet 0 33 135
makeDirs 0 33 136
assign 1 35 138
typePathGet 0 35 138
assign 1 35 139
fileGet 0 35 139
assign 1 35 140
writerGet 0 35 140
assign 1 35 141
open 0 35 141
assign 1 36 142
new 0 36 142
assign 1 37 143
new 0 37 143
addValue 1 37 144
assign 1 38 145
new 0 38 145
assign 1 38 146
addValue 1 38 146
assign 1 38 147
typeEmitNameGet 0 38 147
assign 1 38 148
addValue 1 38 148
assign 1 38 149
new 0 38 149
addValue 1 38 150
assign 1 39 151
new 0 39 151
assign 1 39 152
addValue 1 39 152
assign 1 39 153
typeEmitNameGet 0 39 153
assign 1 39 154
addValue 1 39 154
assign 1 39 155
new 0 39 155
addValue 1 39 156
assign 1 41 157
new 0 41 157
addValue 1 41 158
assign 1 42 159
new 0 42 159
assign 1 43 160
mtdListGet 0 43 160
assign 1 43 161
iteratorGet 0 0 161
assign 1 43 164
hasNextGet 0 43 164
assign 1 43 166
nextGet 0 43 166
assign 1 45 168
new 0 45 168
assign 1 47 171
new 0 47 171
addValue 1 47 172
assign 1 49 174
addValue 1 49 174
assign 1 49 175
nameGet 0 49 175
assign 1 49 176
addValue 1 49 176
addValue 1 49 177
assign 1 51 183
new 0 51 183
addValue 1 51 184
assign 1 52 185
new 0 52 185
addValue 1 52 186
assign 1 54 187
new 0 54 187
addValue 1 54 188
assign 1 55 189
new 0 55 189
assign 1 56 190
ptyListGet 0 56 190
assign 1 56 191
iteratorGet 0 0 191
assign 1 56 194
hasNextGet 0 56 194
assign 1 56 196
nextGet 0 56 196
assign 1 57 197
isSlotGet 0 57 197
assign 1 59 200
new 0 59 200
assign 1 61 203
new 0 61 203
addValue 1 61 204
assign 1 63 206
addValue 1 63 206
assign 1 63 207
nameGet 0 63 207
assign 1 63 208
addValue 1 63 208
addValue 1 63 209
assign 1 66 216
new 0 66 216
addValue 1 66 217
assign 1 68 218
new 0 68 218
addValue 1 68 219
assign 1 70 220
new 0 70 220
assign 1 70 221
addValue 1 70 221
assign 1 70 222
typeEmitNameGet 0 70 222
assign 1 70 223
addValue 1 70 223
assign 1 70 224
new 0 70 224
addValue 1 70 225
assign 1 71 226
new 0 71 226
addValue 1 71 227
assign 1 72 228
new 0 72 228
assign 1 72 229
addValue 1 72 229
assign 1 72 230
emitNameGet 0 72 230
assign 1 72 231
addValue 1 72 231
assign 1 72 232
new 0 72 232
addValue 1 72 233
assign 1 73 234
new 0 73 234
addValue 1 73 235
assign 1 74 236
new 0 74 236
addValue 1 74 237
assign 1 75 238
new 0 75 238
addValue 1 75 239
write 1 76 240
close 0 77 241
assign 1 81 263
new 0 81 263
assign 1 81 264
toString 0 81 264
assign 1 81 265
add 1 81 265
incrementValue 0 82 266
assign 1 83 267
new 0 83 267
assign 1 83 268
addValue 1 83 268
assign 1 83 269
addValue 1 83 269
assign 1 83 270
new 0 83 270
assign 1 83 271
addValue 1 83 271
addValue 1 83 272
assign 1 85 273
containedGet 0 85 273
assign 1 85 274
firstGet 0 85 274
assign 1 85 275
containedGet 0 85 275
assign 1 85 276
firstGet 0 85 276
assign 1 85 277
new 0 85 277
assign 1 85 278
add 1 85 278
assign 1 85 279
new 0 85 279
assign 1 85 280
add 1 85 280
assign 1 85 281
new 0 85 281
assign 1 85 282
finalAssign 4 85 282
addValue 1 85 283
assign 1 90 288
new 0 90 288
return 1 90 289
assign 1 94 298
isFinalGet 0 94 298
assign 1 0 300
assign 1 94 303
def 1 94 308
assign 1 94 309
isFinalGet 0 94 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 0 321
assign 1 0 324
assign 1 95 328
new 0 95 328
return 1 95 329
assign 1 97 331
new 0 97 331
return 1 97 332
assign 1 101 340
def 1 101 345
assign 1 101 346
isFinalGet 0 101 346
assign 1 0 348
assign 1 0 351
assign 1 0 355
assign 1 102 358
new 0 102 358
return 1 102 359
assign 1 104 361
new 0 104 361
return 1 104 362
assign 1 108 366
new 0 108 366
return 1 108 367
getCode 2 113 372
assign 1 114 373
toHexString 1 114 373
assign 1 115 374
new 0 115 374
addValue 1 115 375
addValue 1 116 376
assign 1 122 385
new 0 122 385
assign 1 122 386
add 1 122 386
assign 1 122 387
new 0 122 387
assign 1 122 388
add 1 122 388
assign 1 122 389
add 1 122 389
return 1 122 390
assign 1 126 419
emitChecksGet 0 126 419
assign 1 126 420
new 0 126 420
assign 1 126 421
contains 1 126 421
assign 1 127 423
new 0 127 423
assign 1 127 424
add 1 127 424
assign 1 127 425
new 0 127 425
assign 1 127 426
add 1 127 426
assign 1 127 427
add 1 127 427
assign 1 129 430
new 0 129 430
assign 1 129 431
add 1 129 431
assign 1 129 432
new 0 129 432
assign 1 129 433
add 1 129 433
assign 1 129 434
add 1 129 434
assign 1 131 436
new 0 131 436
assign 1 131 437
addValue 1 131 437
assign 1 131 438
addValue 1 131 438
assign 1 131 439
new 0 131 439
assign 1 131 440
addValue 1 131 440
addValue 1 131 441
assign 1 132 442
new 0 132 442
assign 1 132 443
addValue 1 132 443
addValue 1 132 444
assign 1 133 445
new 0 133 445
assign 1 133 446
addValue 1 133 446
assign 1 133 447
outputPlatformGet 0 133 447
assign 1 133 448
nameGet 0 133 448
assign 1 133 449
addValue 1 133 449
assign 1 133 450
new 0 133 450
assign 1 133 451
addValue 1 133 451
addValue 1 133 452
return 1 134 453
assign 1 138 458
libNameGet 0 138 458
assign 1 138 459
beginNs 1 138 459
return 1 138 460
assign 1 142 469
new 0 142 469
assign 1 142 470
libNs 1 142 470
assign 1 142 471
add 1 142 471
assign 1 142 472
new 0 142 472
assign 1 142 473
add 1 142 473
assign 1 142 474
add 1 142 474
return 1 142 475
assign 1 146 479
getNameSpace 1 146 479
return 1 146 480
assign 1 150 485
new 0 150 485
assign 1 150 486
add 1 150 486
return 1 150 487
assign 1 154 492
new 0 154 492
assign 1 154 493
add 1 154 493
return 1 154 494
assign 1 158 498
new 0 158 498
return 1 158 499
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -145026050: return bem_newDecGet_0();
case 1689550852: return bem_nullValueGet_0();
case 1629069322: return bem_classConfGet_0();
case 1264100374: return bem_transGet_0();
case -904135727: return bem_methodCallsGet_0();
case -413750837: return bem_gcMarksGet_0();
case 1225605186: return bem_hashGet_0();
case -807929924: return bem_superNameGet_0();
case 902349384: return bem_methodCatchGet_0();
case 1163567696: return bem_nameToIdPathGet_0();
case 1911191120: return bem_emitLib_0();
case -996908662: return bem_exceptDecGet_0();
case -13751931: return bem_beginNs_0();
case 717476485: return bem_nlGet_0();
case -1121464473: return bem_preClassGet_0();
case -1909945499: return bem_idToNamePathGet_0();
case 1916213935: return bem_msynGet_0();
case -1656505530: return bem_classEmitsGet_0();
case -693167819: return bem_randGet_0();
case 1837389516: return bem_buildClassInfo_0();
case -256522979: return bem_returnTypeGet_0();
case -15166694: return bem_inFilePathedGet_0();
case 1619802871: return bem_objectCcGet_0();
case -304960763: return bem_propDecGet_0();
case -887901959: return bem_stringNpGet_0();
case -1596231434: return bem_csynGet_0();
case -578273566: return bem_lastMethodBodySizeGet_0();
case 1621282084: return bem_libEmitPathGet_0();
case -1609517892: return bem_saveSyns_0();
case 396813646: return bem_lineCountGet_0();
case 1837965650: return bem_buildCreate_0();
case 41721194: return bem_ccCacheGet_0();
case 2036737920: return bem_smnlcsGet_0();
case 1864827271: return bem_copy_0();
case 175061408: return bem_constGet_0();
case -2181583: return bem_emitLangGet_0();
case 1056889808: return bem_fileExtGet_0();
case 32393199: return bem_saveIds_0();
case 2065534965: return bem_maxDynArgsGet_0();
case 535313399: return bem_mainInClassGet_0();
case 1626371085: return bem_toString_0();
case 167532048: return bem_instanceNotEqualGet_0();
case -1829898789: return bem_parentConfGet_0();
case 1399579177: return bem_initialDecGet_0();
case 217733163: return bem_dynMethodsGet_0();
case -1642952294: return bem_methodBodyGet_0();
case -885432431: return bem_instanceEqualGet_0();
case -659499135: return bem_classEndGet_0();
case 730181252: return bem_objectNpGet_0();
case 1471190666: return bem_invpGet_0();
case -1180911254: return bem_mainOutsideNsGet_0();
case 1221587665: return bem_classesInDepthOrderGet_0();
case -43056415: return bem_boolTypeGet_0();
case -1093672743: return bem_create_0();
case -846806835: return bem_new_0();
case -1196773685: return bem_lastMethodsLinesGet_0();
case -1613660: return bem_getClassOutput_0();
case 1011168098: return bem_afterCast_0();
case -1928502658: return bem_scvpGet_0();
case -1638072707: return bem_spropDecGet_0();
case 1327230882: return bem_qGet_0();
case -1493115817: return bem_callNamesGet_0();
case -498116521: return bem_nativeCSlotsGet_0();
case -834546610: return bem_lastCallGet_0();
case -86251957: return bem_getLibOutput_0();
case -2123573176: return bem_idToNameGet_0();
case -58499528: return bem_mnodeGet_0();
case -116466659: return bem_propertyDecsGet_0();
case 229728232: return bem_iteratorGet_0();
case 947107817: return bem_print_0();
case -1234044913: return bem_writeBET_0();
case 488472051: return bem_trueValueGet_0();
case -1333972470: return bem_smnlecsGet_0();
case -1096543741: return bem_instOfGet_0();
case -1163633159: return bem_intNpGet_0();
case -81989643: return bem_preClassOutput_0();
case 2095846941: return bem_lastMethodBodyLinesGet_0();
case 443627038: return bem_doEmit_0();
case 444699172: return bem_onceDecsGet_0();
case 627549243: return bem_nameToIdGet_0();
case -44658753: return bem_ntypesGet_0();
case 740549707: return bem_endNs_0();
case -212789377: return bem_lastMethodsSizeGet_0();
case -743998082: return bem_superCallsGet_0();
case 1098290320: return bem_libEmitNameGet_0();
case -978161347: return bem_boolCcGet_0();
case 926146243: return bem_covariantReturnsGet_0();
case 891461834: return bem_loadIds_0();
case -163436237: return bem_inClassGet_0();
case -272564440: return bem_cnodeGet_0();
case 2121866969: return bem_boolNpGet_0();
case -128040670: return bem_floatNpGet_0();
case -614743779: return bem_mainEndGet_0();
case -787580646: return bem_runtimeInitGet_0();
case 835528423: return bem_fullLibEmitNameGet_0();
case -1598785311: return bem_buildGet_0();
case -973270837: return bem_buildInitial_0();
case -1901093193: return bem_useDynMethodsGet_0();
case -367369546: return bem_falseValueGet_0();
case -988550991: return bem_synEmitPathGet_0();
case -1273451356: return bem_baseMtdDecGet_0();
case 963595665: return bem_mainStartGet_0();
case -884284315: return bem_baseSmtdDecGet_0();
case -1803732402: return bem_maxSpillArgsLenGet_0();
case -449926592: return bem_methodsGet_0();
case -2102788559: return bem_overrideMtdDecGet_0();
case -43897308: return bem_classCallsGet_0();
case 163998686: return bem_ccMethodsGet_0();
case -1416261096: return bem_belslitsGet_0();
case 200819690: return bem_typeDecGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1989225985: return bem_equals_1(bevd_0);
case -109571331: return bem_nlSet_1(bevd_0);
case 1221468677: return bem_print_1(bevd_0);
case -1701821958: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1230581774: return bem_instanceNotEqualSet_1(bevd_0);
case -967958810: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 21466395: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1341192996: return bem_lineCountSet_1(bevd_0);
case -1571919398: return bem_methodCatchSet_1(bevd_0);
case -1094860839: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -934175273: return bem_boolCcSet_1(bevd_0);
case 1046732605: return bem_parentConfSet_1(bevd_0);
case 366342975: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1398935876: return bem_synEmitPathSet_1(bevd_0);
case 2145780549: return bem_stringNpSet_1(bevd_0);
case -1595323464: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -30358345: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -117343562: return bem_ccMethodsSet_1(bevd_0);
case -697791053: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 130213711: return bem_falseValueSet_1(bevd_0);
case -281293921: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 528899434: return bem_notEquals_1(bevd_0);
case -231241068: return bem_boolNpSet_1(bevd_0);
case -388763253: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1962272373: return bem_floatNpSet_1(bevd_0);
case -1889680253: return bem_emitLangSet_1(bevd_0);
case -714049668: return bem_randSet_1(bevd_0);
case -274468743: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1498007175: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -975211148: return bem_methodsSet_1(bevd_0);
case 1958695822: return bem_callNamesSet_1(bevd_0);
case 260898960: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case 423666586: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 410174379: return bem_instOfSet_1(bevd_0);
case -1469222578: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1237092277: return bem_idToNameSet_1(bevd_0);
case 1107976117: return bem_classEmitsSet_1(bevd_0);
case -837046456: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -403246264: return bem_onceDecsSet_1(bevd_0);
case 393932730: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1998557375: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1537105344: return bem_libEmitNameSet_1(bevd_0);
case 994039501: return bem_inFilePathedSet_1(bevd_0);
case 1213028574: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1295951844: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1419149028: return bem_classCallsSet_1(bevd_0);
case 909663208: return bem_nameToIdSet_1(bevd_0);
case 881526767: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1619277552: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 415445233: return bem_ntypesSet_1(bevd_0);
case 2113723648: return bem_objectNpSet_1(bevd_0);
case 658088713: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1914735633: return bem_dynMethodsSet_1(bevd_0);
case -1029297684: return bem_returnTypeSet_1(bevd_0);
case 480945696: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 455321383: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1744976941: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -576418862: return bem_msynSet_1(bevd_0);
case 2000145721: return bem_exceptDecSet_1(bevd_0);
case 608849213: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2008953154: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1267774788: return bem_nativeCSlotsSet_1(bevd_0);
case 1541190474: return bem_invpSet_1(bevd_0);
case 1343965772: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1678283853: return bem_libEmitPathSet_1(bevd_0);
case 846675023: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -734362714: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 73113183: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 171219042: return bem_constSet_1(bevd_0);
case -154135651: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 430148712: return bem_undef_1(bevd_0);
case 507243627: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -913699951: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -2067413362: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 165843059: return bem_methodCallsSet_1(bevd_0);
case 2018384245: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 2053133947: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1465868163: return bem_transSet_1(bevd_0);
case 1316959110: return bem_gcMarksSet_1(bevd_0);
case -1880257165: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -384903574: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -978754199: return bem_lastCallSet_1(bevd_0);
case 217421209: return bem_belslitsSet_1(bevd_0);
case 2025919136: return bem_qSet_1(bevd_0);
case 986169250: return bem_decNameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1700416165: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1205588401: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1723434678: return bem_lastMethodsLinesSet_1(bevd_0);
case -442062778: return bem_maxDynArgsSet_1(bevd_0);
case 1646660035: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 755026647: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1572971227: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1760615900: return bem_begin_1(bevd_0);
case 938059495: return bem_methodBodySet_1(bevd_0);
case -1341968363: return bem_fileExtSet_1(bevd_0);
case -602482669: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1947796728: return bem_superCallsSet_1(bevd_0);
case 1104247810: return bem_csynSet_1(bevd_0);
case -60694023: return bem_scvpSet_1(bevd_0);
case 1329485321: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1319069711: return bem_classConfSet_1(bevd_0);
case -2029229331: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -627498024: return bem_propertyDecsSet_1(bevd_0);
case 468176430: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1192843581: return bem_smnlcsSet_1(bevd_0);
case -1068220991: return bem_copyTo_1(bevd_0);
case -1271268672: return bem_end_1(bevd_0);
case 25413698: return bem_nameToIdPathSet_1(bevd_0);
case 120328519: return bem_smnlecsSet_1(bevd_0);
case -760253780: return bem_fullLibEmitNameSet_1(bevd_0);
case -361349209: return bem_instanceEqualSet_1(bevd_0);
case -1337550940: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case -1910753894: return bem_preClassSet_1(bevd_0);
case -107377777: return bem_buildSet_1(bevd_0);
case -850089843: return bem_classesInDepthOrderSet_1(bevd_0);
case -2092617079: return bem_ccCacheSet_1(bevd_0);
case 974697091: return bem_inClassSet_1(bevd_0);
case 991941770: return bem_cnodeSet_1(bevd_0);
case 1221875616: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1841303718: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -510863552: return bem_lastMethodsSizeSet_1(bevd_0);
case 931631556: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -945500101: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1331931590: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 117868742: return bem_lastMethodBodySizeSet_1(bevd_0);
case -105019337: return bem_mnodeSet_1(bevd_0);
case 1400628427: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1520355021: return bem_nullValueSet_1(bevd_0);
case 1095927508: return bem_trueValueSet_1(bevd_0);
case -516490721: return bem_objectCcSet_1(bevd_0);
case -977892835: return bem_idToNamePathSet_1(bevd_0);
case 2094676964: return bem_def_1(bevd_0);
case -1664193765: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1525989867: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1667539953: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 682921723: return bem_intNpSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -581305477: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -203428159: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2084265811: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -354110144: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -873334744: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1174802049: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 595068842: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -35409403: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1003205186: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 306866874: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1901538121: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -949275792: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 827909690: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1827077894: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 708022361: return bem_writeOnceDecs_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case -785184004: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -568077610: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 710380640: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -573416967: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1618063935: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case -1070513342: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -805620062: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callId) {
case -448994132: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -1163798485: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -847437671: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return super.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
