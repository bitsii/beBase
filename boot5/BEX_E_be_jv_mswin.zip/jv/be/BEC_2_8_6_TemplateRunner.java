package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_BEC_2_8_6_TemplateRunner_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_BEC_2_8_6_TemplateRunner_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_inst;

public static BET_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public BEC_2_8_6_TemplateRunner bem_new_0() throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_swap == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevp_swap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 182 */
return bevp_swap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_handOff == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_handOff = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 187 */
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) throws Throwable {
bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_new_0();
bem_load_1(beva_template);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bevp_replace = (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_restart_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 209 */
bevp_stepIter = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
if (bevp_stepIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevt_1_tmpany_phold = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_tmpany_phold.bem_iteratorGet_0();
} /* Line: 216 */
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_1_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_1_tmpany_phold = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_tmpany_phold;
} /* Line: 223 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_currentRunnerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_stepIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1052161076);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = bem_stepIterGet_0();
bevl_iter.bemd_1(481951513, beva_node);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_4_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 241 */
 else  /* Line: 242 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 245 */
} /* Line: 240 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 249 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(2096550402);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 249 */ {
bevl_s = bevl_iter.bemd_0(-2029555311);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(824292706, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 256 */
 else  /* Line: 257 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 260 */
} /* Line: 255 */
 else  /* Line: 251 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(824292706, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-1328502463, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 262 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 263 */
 else  /* Line: 264 */ {
bevt_18_tmpany_phold = bevl_s.bemd_1(539229163, this);
bevp_output.bemd_1(-1150186949, bevt_18_tmpany_phold);
} /* Line: 265 */
} /* Line: 251 */
} /* Line: 251 */
 else  /* Line: 249 */ {
break;
} /* Line: 249 */
} /* Line: 249 */
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_19_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_4_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 274 */
 else  /* Line: 275 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 278 */
} /* Line: 273 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 282 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(2096550402);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevl_s = bevl_iter.bemd_0(-2029555311);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(824292706, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 289 */
 else  /* Line: 290 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 293 */
} /* Line: 288 */
 else  /* Line: 284 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(824292706, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-1328502463, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 295 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 295 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 296 */
} /* Line: 284 */
} /* Line: 284 */
 else  /* Line: 282 */ {
break;
} /* Line: 282 */
} /* Line: 282 */
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_run_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
if (bevp_baton == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 303 */ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 306 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_iter.bemd_0(2096550402);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_s = bevl_iter.bemd_0(-2029555311);
if (bevp_handOff == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_5_tmpany_phold = bevl_s.bemd_1(824292706, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevt_6_tmpany_phold = bevp_handOff.bem_has_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_8_tmpany_phold = bevl_s.bemd_0(-1918612634);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 317 */
 else  /* Line: 318 */ {
bevt_9_tmpany_phold = bevl_s.bemd_1(539229163, this);
bevp_output.bemd_1(-1150186949, bevt_9_tmpany_phold);
} /* Line: 319 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public final BEC_2_8_7_TemplateReplace bem_replaceGetDirect_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_replaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_outputGetDirect_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_output = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_outputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_output = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_stepIterGetDirect_0() throws Throwable {
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stepIter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_stepIterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stepIter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_swapGetDirect_0() throws Throwable {
return bevp_swap;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_swapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_9_3_ContainerMap bem_handOffGetDirect_0() throws Throwable {
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_handOffSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGet_0() throws Throwable {
return bevp_baton;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_batonGetDirect_0() throws Throwable {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_batonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public final BEC_2_7_7_ReplaceRunStep bem_runStepGetDirect_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_8_6_TemplateRunner bem_runStepSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {177, 182, 182, 182, 183, 187, 187, 187, 188, 192, 193, 197, 198, 202, 203, 207, 207, 208, 209, 211, 215, 215, 216, 216, 218, 222, 222, 223, 223, 225, 229, 229, 229, 229, 234, 235, 239, 239, 240, 241, 241, 244, 245, 248, 249, 250, 251, 251, 251, 0, 0, 0, 251, 251, 0, 0, 0, 252, 252, 253, 254, 255, 256, 256, 259, 260, 262, 262, 262, 0, 0, 0, 263, 263, 265, 265, 268, 268, 272, 272, 273, 274, 274, 277, 278, 281, 282, 283, 284, 284, 284, 0, 0, 0, 284, 284, 0, 0, 0, 285, 285, 286, 287, 288, 289, 289, 292, 293, 295, 295, 295, 0, 0, 0, 296, 296, 299, 299, 303, 303, 304, 305, 306, 308, 309, 310, 311, 311, 311, 0, 0, 0, 311, 311, 0, 0, 0, 312, 312, 313, 314, 315, 316, 317, 319, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 24, 29, 30, 32, 36, 41, 42, 44, 47, 48, 52, 53, 57, 58, 63, 68, 69, 70, 72, 78, 83, 84, 85, 87, 92, 97, 98, 99, 101, 107, 108, 109, 110, 114, 115, 141, 146, 147, 149, 150, 153, 154, 157, 160, 162, 163, 168, 169, 171, 174, 178, 181, 182, 184, 187, 191, 194, 195, 196, 197, 198, 200, 201, 204, 205, 209, 211, 212, 214, 217, 221, 224, 225, 228, 229, 237, 238, 262, 267, 268, 270, 271, 274, 275, 278, 281, 283, 284, 289, 290, 292, 295, 299, 302, 303, 305, 308, 312, 315, 316, 317, 318, 319, 321, 322, 325, 326, 330, 332, 333, 335, 338, 342, 345, 346, 354, 355, 370, 375, 376, 377, 378, 380, 383, 385, 386, 391, 392, 394, 397, 401, 404, 405, 407, 410, 414, 417, 418, 419, 420, 421, 422, 423, 426, 427, 437, 440, 443, 447, 451, 454, 457, 461, 465, 468, 472, 476, 479, 483, 487, 490, 494, 498, 501, 504, 508, 512, 515, 518, 522};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 177 19
new 0 177 19
assign 1 182 24
undef 1 182 29
assign 1 182 30
new 0 182 30
return 1 183 32
assign 1 187 36
undef 1 187 41
assign 1 187 42
new 0 187 42
return 1 188 44
new 1 192 47
assign 1 193 48
new 0 197 52
load 1 198 53
assign 1 202 57
new 0 202 57
load 2 203 58
assign 1 207 63
def 1 207 68
restart 0 208 69
assign 1 209 70
assign 1 211 72
assign 1 215 78
undef 1 215 83
assign 1 216 84
stepsGet 0 216 84
assign 1 216 85
iteratorGet 0 216 85
return 1 218 87
assign 1 222 92
def 1 222 97
assign 1 223 98
currentRunnerGet 0 223 98
return 1 223 99
return 1 225 101
assign 1 229 107
currentRunnerGet 0 229 107
assign 1 229 108
stepIterGet 0 229 108
assign 1 229 109
currentNodeGet 0 229 109
return 1 229 110
assign 1 234 114
stepIterGet 0 234 114
currentNodeSet 1 235 115
assign 1 239 141
def 1 239 146
assign 1 240 147
runToLabel 1 240 147
assign 1 241 149
new 0 241 149
return 1 241 150
restart 0 244 153
assign 1 245 154
assign 1 248 157
stepIterGet 0 248 157
assign 1 249 160
hasNextGet 0 249 160
assign 1 250 162
nextGet 0 250 162
assign 1 251 163
def 1 251 168
assign 1 251 169
sameType 1 251 169
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 251 181
strGet 0 251 181
assign 1 251 182
has 1 251 182
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 252 194
strGet 0 252 194
assign 1 252 195
get 1 252 195
outputSet 1 253 196
swapSet 1 254 197
assign 1 255 198
runToLabel 1 255 198
assign 1 256 200
new 0 256 200
return 1 256 201
restart 0 259 204
assign 1 260 205
assign 1 262 209
sameType 1 262 209
assign 1 262 211
strGet 0 262 211
assign 1 262 212
equals 1 262 212
assign 1 0 214
assign 1 0 217
assign 1 0 221
assign 1 263 224
new 0 263 224
return 1 263 225
assign 1 265 228
handle 1 265 228
write 1 265 229
assign 1 268 237
new 0 268 237
return 1 268 238
assign 1 272 262
def 1 272 267
assign 1 273 268
skipToLabel 1 273 268
assign 1 274 270
new 0 274 270
return 1 274 271
restart 0 277 274
assign 1 278 275
assign 1 281 278
stepIterGet 0 281 278
assign 1 282 281
hasNextGet 0 282 281
assign 1 283 283
nextGet 0 283 283
assign 1 284 284
def 1 284 289
assign 1 284 290
sameType 1 284 290
assign 1 0 292
assign 1 0 295
assign 1 0 299
assign 1 284 302
strGet 0 284 302
assign 1 284 303
has 1 284 303
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 285 315
strGet 0 285 315
assign 1 285 316
get 1 285 316
outputSet 1 286 317
swapSet 1 287 318
assign 1 288 319
skipToLabel 1 288 319
assign 1 289 321
new 0 289 321
return 1 289 322
restart 0 292 325
assign 1 293 326
assign 1 295 330
sameType 1 295 330
assign 1 295 332
strGet 0 295 332
assign 1 295 333
equals 1 295 333
assign 1 0 335
assign 1 0 338
assign 1 0 342
assign 1 296 345
new 0 296 345
return 1 296 346
assign 1 299 354
new 0 299 354
return 1 299 355
assign 1 303 370
def 1 303 375
run 0 304 376
restart 0 305 377
assign 1 306 378
assign 1 308 380
stepIterGet 0 308 380
assign 1 309 383
hasNextGet 0 309 383
assign 1 310 385
nextGet 0 310 385
assign 1 311 386
def 1 311 391
assign 1 311 392
sameType 1 311 392
assign 1 0 394
assign 1 0 397
assign 1 0 401
assign 1 311 404
strGet 0 311 404
assign 1 311 405
has 1 311 405
assign 1 0 407
assign 1 0 410
assign 1 0 414
assign 1 312 417
strGet 0 312 417
assign 1 312 418
get 1 312 418
outputSet 1 313 419
swapSet 1 314 420
run 0 315 421
restart 0 316 422
assign 1 317 423
assign 1 319 426
handle 1 319 426
write 1 319 427
return 1 0 437
return 1 0 440
assign 1 0 443
assign 1 0 447
return 1 0 451
return 1 0 454
assign 1 0 457
assign 1 0 461
return 1 0 465
assign 1 0 468
assign 1 0 472
return 1 0 476
assign 1 0 479
assign 1 0 483
return 1 0 487
assign 1 0 490
assign 1 0 494
return 1 0 498
return 1 0 501
assign 1 0 504
assign 1 0 508
return 1 0 512
return 1 0 515
assign 1 0 518
assign 1 0 522
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -201292676: return bem_create_0();
case 1052161076: return bem_currentNodeGet_0();
case -2065475128: return bem_tagGet_0();
case -776020472: return bem_batonGetDirect_0();
case -507248646: return bem_toString_0();
case -479220991: return bem_echo_0();
case 67894489: return bem_sourceFileNameGet_0();
case 2090520684: return bem_run_0();
case 1509454415: return bem_fieldNamesGet_0();
case -755857848: return bem_serializeToString_0();
case -842698583: return bem_print_0();
case 404196396: return bem_outputGetDirect_0();
case -159549660: return bem_swapGet_0();
case 1279262631: return bem_runStepGetDirect_0();
case -1011972693: return bem_classNameGet_0();
case -743481213: return bem_outputGet_0();
case -1312089850: return bem_serializationIteratorGet_0();
case -1261572271: return bem_stepIterGet_0();
case 1060470033: return bem_handOffGet_0();
case 116405623: return bem_once_0();
case 838598675: return bem_deserializeClassNameGet_0();
case 2027881489: return bem_new_0();
case -1817966493: return bem_iteratorGet_0();
case 522375874: return bem_swapGetDirect_0();
case 66023749: return bem_copy_0();
case 1767145499: return bem_toAny_0();
case 1880418594: return bem_many_0();
case 757994464: return bem_replaceGetDirect_0();
case 1499522057: return bem_batonGet_0();
case 1334238154: return bem_hashGet_0();
case -1931818716: return bem_stepIterGetDirect_0();
case 1701297643: return bem_handOffGetDirect_0();
case -859458228: return bem_replaceGet_0();
case 1292255745: return bem_fieldIteratorGet_0();
case -1903129126: return bem_currentRunnerGet_0();
case -1280942967: return bem_runStepGet_0();
case 1446628444: return bem_restart_0();
case 1319463124: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 931801515: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -890367556: return bem_undefined_1(bevd_0);
case 358154948: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2132892414: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 2053800830: return bem_swapSetDirect_1(bevd_0);
case 1790887761: return bem_batonSetDirect_1(bevd_0);
case 1201016043: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2139599139: return bem_replaceSetDirect_1(bevd_0);
case 497782353: return bem_swapSet_1(bevd_0);
case 1902941795: return bem_defined_1(bevd_0);
case -1397337450: return bem_stepIterSet_1(bevd_0);
case 2126549850: return bem_handOffSetDirect_1(bevd_0);
case 1317453949: return bem_sameClass_1(bevd_0);
case 58873144: return bem_outputSet_1(bevd_0);
case 824292706: return bem_sameType_1(bevd_0);
case -1508117625: return bem_otherClass_1(bevd_0);
case 440989655: return bem_copyTo_1(bevd_0);
case 152840693: return bem_stepIterSetDirect_1(bevd_0);
case -1890627721: return bem_notEquals_1(bevd_0);
case -1328502463: return bem_equals_1(bevd_0);
case -737237761: return bem_sameObject_1(bevd_0);
case 1791703089: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 601146370: return bem_batonSet_1(bevd_0);
case 1654367103: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case 236521366: return bem_def_1(bevd_0);
case -697364376: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1483817890: return bem_undef_1(bevd_0);
case 481951513: return bem_currentNodeSet_1(bevd_0);
case 1026425587: return bem_outputSetDirect_1(bevd_0);
case 1751676394: return bem_otherType_1(bevd_0);
case -1381869326: return bem_replaceSet_1(bevd_0);
case -1968558358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1857572899: return bem_runStepSetDirect_1(bevd_0);
case 1310628831: return bem_handOffSet_1(bevd_0);
case 938307969: return bem_runStepSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 77948450: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1747625055: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1008558996: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 139476281: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1704645214: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1221915514: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -778494517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1737168375: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_TemplateRunner_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_6_TemplateRunner_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_TemplateRunner();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst = (BEC_2_8_6_TemplateRunner) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_type;
}
}
