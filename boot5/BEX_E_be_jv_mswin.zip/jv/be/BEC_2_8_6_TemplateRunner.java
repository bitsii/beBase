package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_BEC_2_8_6_TemplateRunner_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_BEC_2_8_6_TemplateRunner_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_inst;
public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public BEC_2_8_6_TemplateRunner bem_new_0() throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_swap == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevp_swap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 182 */
return bevp_swap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_handOff == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_handOff = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 187 */
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) throws Throwable {
bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_new_0();
bem_load_1(beva_template);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bevp_replace = (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_restart_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 209 */
bevp_stepIter = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
if (bevp_stepIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevt_1_tmpany_phold = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_tmpany_phold.bem_iteratorGet_0();
} /* Line: 216 */
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_1_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_1_tmpany_phold = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_tmpany_phold;
} /* Line: 223 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_currentRunnerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_stepIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-142600908);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = bem_stepIterGet_0();
bevl_iter.bemd_1(846998185, beva_node);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_4_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 241 */
 else  /* Line: 242 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 245 */
} /* Line: 240 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 249 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(1044268871);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 249 */ {
bevl_s = bevl_iter.bemd_0(-1274688402);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(1420318580, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 256 */
 else  /* Line: 257 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 260 */
} /* Line: 255 */
 else  /* Line: 251 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(1420318580, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(661372330, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 262 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 263 */
 else  /* Line: 264 */ {
bevt_18_tmpany_phold = bevl_s.bemd_1(1034791403, this);
bevp_output.bemd_1(-314785708, bevt_18_tmpany_phold);
} /* Line: 265 */
} /* Line: 251 */
} /* Line: 251 */
 else  /* Line: 249 */ {
break;
} /* Line: 249 */
} /* Line: 249 */
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_19_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_4_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 274 */
 else  /* Line: 275 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 278 */
} /* Line: 273 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 282 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(1044268871);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevl_s = bevl_iter.bemd_0(-1274688402);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(1420318580, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 289 */
 else  /* Line: 290 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 293 */
} /* Line: 288 */
 else  /* Line: 284 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(1420318580, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(661372330, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 295 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 295 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 296 */
} /* Line: 284 */
} /* Line: 284 */
 else  /* Line: 282 */ {
break;
} /* Line: 282 */
} /* Line: 282 */
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_run_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
if (bevp_baton == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 303 */ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 306 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_iter.bemd_0(1044268871);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_s = bevl_iter.bemd_0(-1274688402);
if (bevp_handOff == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_5_tmpany_phold = bevl_s.bemd_1(1420318580, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevt_6_tmpany_phold = bevp_handOff.bem_has_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_8_tmpany_phold = bevl_s.bemd_0(-1992252192);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 317 */
 else  /* Line: 318 */ {
bevt_9_tmpany_phold = bevl_s.bemd_1(1034791403, this);
bevp_output.bemd_1(-314785708, bevt_9_tmpany_phold);
} /* Line: 319 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_output = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stepIter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGet_0() throws Throwable {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {177, 182, 182, 182, 183, 187, 187, 187, 188, 192, 193, 197, 198, 202, 203, 207, 207, 208, 209, 211, 215, 215, 216, 216, 218, 222, 222, 223, 223, 225, 229, 229, 229, 229, 234, 235, 239, 239, 240, 241, 241, 244, 245, 248, 249, 250, 251, 251, 251, 0, 0, 0, 251, 251, 0, 0, 0, 252, 252, 253, 254, 255, 256, 256, 259, 260, 262, 262, 262, 0, 0, 0, 263, 263, 265, 265, 268, 268, 272, 272, 273, 274, 274, 277, 278, 281, 282, 283, 284, 284, 284, 0, 0, 0, 284, 284, 0, 0, 0, 285, 285, 286, 287, 288, 289, 289, 292, 293, 295, 295, 295, 0, 0, 0, 296, 296, 299, 299, 303, 303, 304, 305, 306, 308, 309, 310, 311, 311, 311, 0, 0, 0, 311, 311, 0, 0, 0, 312, 312, 313, 314, 315, 316, 317, 319, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 21, 26, 27, 29, 33, 38, 39, 41, 44, 45, 49, 50, 54, 55, 60, 65, 66, 67, 69, 75, 80, 81, 82, 84, 89, 94, 95, 96, 98, 104, 105, 106, 107, 111, 112, 138, 143, 144, 146, 147, 150, 151, 154, 157, 159, 160, 165, 166, 168, 171, 175, 178, 179, 181, 184, 188, 191, 192, 193, 194, 195, 197, 198, 201, 202, 206, 208, 209, 211, 214, 218, 221, 222, 225, 226, 234, 235, 259, 264, 265, 267, 268, 271, 272, 275, 278, 280, 281, 286, 287, 289, 292, 296, 299, 300, 302, 305, 309, 312, 313, 314, 315, 316, 318, 319, 322, 323, 327, 329, 330, 332, 335, 339, 342, 343, 351, 352, 367, 372, 373, 374, 375, 377, 380, 382, 383, 388, 389, 391, 394, 398, 401, 402, 404, 407, 411, 414, 415, 416, 417, 418, 419, 420, 423, 424, 434, 437, 441, 444, 448, 452, 456, 460, 463, 467, 470};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 177 16
new 0 177 16
assign 1 182 21
undef 1 182 26
assign 1 182 27
new 0 182 27
return 1 183 29
assign 1 187 33
undef 1 187 38
assign 1 187 39
new 0 187 39
return 1 188 41
new 1 192 44
assign 1 193 45
new 0 197 49
load 1 198 50
assign 1 202 54
new 0 202 54
load 2 203 55
assign 1 207 60
def 1 207 65
restart 0 208 66
assign 1 209 67
assign 1 211 69
assign 1 215 75
undef 1 215 80
assign 1 216 81
stepsGet 0 216 81
assign 1 216 82
iteratorGet 0 216 82
return 1 218 84
assign 1 222 89
def 1 222 94
assign 1 223 95
currentRunnerGet 0 223 95
return 1 223 96
return 1 225 98
assign 1 229 104
currentRunnerGet 0 229 104
assign 1 229 105
stepIterGet 0 229 105
assign 1 229 106
currentNodeGet 0 229 106
return 1 229 107
assign 1 234 111
stepIterGet 0 234 111
currentNodeSet 1 235 112
assign 1 239 138
def 1 239 143
assign 1 240 144
runToLabel 1 240 144
assign 1 241 146
new 0 241 146
return 1 241 147
restart 0 244 150
assign 1 245 151
assign 1 248 154
stepIterGet 0 248 154
assign 1 249 157
hasNextGet 0 249 157
assign 1 250 159
nextGet 0 250 159
assign 1 251 160
def 1 251 165
assign 1 251 166
sameType 1 251 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 251 178
strGet 0 251 178
assign 1 251 179
has 1 251 179
assign 1 0 181
assign 1 0 184
assign 1 0 188
assign 1 252 191
strGet 0 252 191
assign 1 252 192
get 1 252 192
outputSet 1 253 193
swapSet 1 254 194
assign 1 255 195
runToLabel 1 255 195
assign 1 256 197
new 0 256 197
return 1 256 198
restart 0 259 201
assign 1 260 202
assign 1 262 206
sameType 1 262 206
assign 1 262 208
strGet 0 262 208
assign 1 262 209
equals 1 262 209
assign 1 0 211
assign 1 0 214
assign 1 0 218
assign 1 263 221
new 0 263 221
return 1 263 222
assign 1 265 225
handle 1 265 225
write 1 265 226
assign 1 268 234
new 0 268 234
return 1 268 235
assign 1 272 259
def 1 272 264
assign 1 273 265
skipToLabel 1 273 265
assign 1 274 267
new 0 274 267
return 1 274 268
restart 0 277 271
assign 1 278 272
assign 1 281 275
stepIterGet 0 281 275
assign 1 282 278
hasNextGet 0 282 278
assign 1 283 280
nextGet 0 283 280
assign 1 284 281
def 1 284 286
assign 1 284 287
sameType 1 284 287
assign 1 0 289
assign 1 0 292
assign 1 0 296
assign 1 284 299
strGet 0 284 299
assign 1 284 300
has 1 284 300
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 285 312
strGet 0 285 312
assign 1 285 313
get 1 285 313
outputSet 1 286 314
swapSet 1 287 315
assign 1 288 316
skipToLabel 1 288 316
assign 1 289 318
new 0 289 318
return 1 289 319
restart 0 292 322
assign 1 293 323
assign 1 295 327
sameType 1 295 327
assign 1 295 329
strGet 0 295 329
assign 1 295 330
equals 1 295 330
assign 1 0 332
assign 1 0 335
assign 1 0 339
assign 1 296 342
new 0 296 342
return 1 296 343
assign 1 299 351
new 0 299 351
return 1 299 352
assign 1 303 367
def 1 303 372
run 0 304 373
restart 0 305 374
assign 1 306 375
assign 1 308 377
stepIterGet 0 308 377
assign 1 309 380
hasNextGet 0 309 380
assign 1 310 382
nextGet 0 310 382
assign 1 311 383
def 1 311 388
assign 1 311 389
sameType 1 311 389
assign 1 0 391
assign 1 0 394
assign 1 0 398
assign 1 311 401
strGet 0 311 401
assign 1 311 402
has 1 311 402
assign 1 0 404
assign 1 0 407
assign 1 0 411
assign 1 312 414
strGet 0 312 414
assign 1 312 415
get 1 312 415
outputSet 1 313 416
swapSet 1 314 417
run 0 315 418
restart 0 316 419
assign 1 317 420
assign 1 319 423
handle 1 319 423
write 1 319 424
return 1 0 434
assign 1 0 437
return 1 0 441
assign 1 0 444
assign 1 0 448
assign 1 0 452
assign 1 0 456
return 1 0 460
assign 1 0 463
return 1 0 467
assign 1 0 470
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 741511465: return bem_print_0();
case -1807776015: return bem_restart_0();
case -1194864649: return bem_toString_0();
case -488509293: return bem_replaceGet_0();
case 305137971: return bem_classNameGet_0();
case 144613256: return bem_serializeContents_0();
case 901060004: return bem_copy_0();
case 627086221: return bem_once_0();
case -142600908: return bem_currentNodeGet_0();
case 1387595522: return bem_toAny_0();
case -1480759952: return bem_stepIterGet_0();
case -570363758: return bem_serializationIteratorGet_0();
case 1087786397: return bem_deserializeClassNameGet_0();
case 2104967589: return bem_batonGet_0();
case 1234289396: return bem_tagGet_0();
case -1257959338: return bem_runStepGet_0();
case -1601492406: return bem_new_0();
case 436412028: return bem_sourceFileNameGet_0();
case -1990641673: return bem_currentRunnerGet_0();
case -406768451: return bem_handOffGet_0();
case 1359373450: return bem_echo_0();
case -1988392847: return bem_fieldIteratorGet_0();
case 1147349498: return bem_outputGet_0();
case -961535531: return bem_hashGet_0();
case -612311095: return bem_iteratorGet_0();
case 1640816089: return bem_swapGet_0();
case 1499284747: return bem_run_0();
case -1550372712: return bem_serializeToString_0();
case 1278732754: return bem_create_0();
case 730619711: return bem_many_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1001249520: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1633632376: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 72028983: return bem_batonSet_1(bevd_0);
case 1958663961: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -41686734: return bem_swapSet_1(bevd_0);
case 63520715: return bem_runStepSet_1(bevd_0);
case 895073788: return bem_handOffSet_1(bevd_0);
case 457153382: return bem_copyTo_1(bevd_0);
case 1067421305: return bem_notEquals_1(bevd_0);
case -686450804: return bem_defined_1(bevd_0);
case -1568064603: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -872936911: return bem_replaceSet_1(bevd_0);
case -959014503: return bem_stepIterSet_1(bevd_0);
case 661372330: return bem_equals_1(bevd_0);
case 266931166: return bem_undef_1(bevd_0);
case -2049241562: return bem_sameObject_1(bevd_0);
case -596533003: return bem_otherType_1(bevd_0);
case 846998185: return bem_currentNodeSet_1(bevd_0);
case -1903482804: return bem_otherClass_1(bevd_0);
case 1717289899: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1399120965: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
case -1718194680: return bem_undefined_1(bevd_0);
case 385185820: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1023168427: return bem_sameClass_1(bevd_0);
case -647902143: return bem_outputSet_1(bevd_0);
case -1196983978: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 1420318580: return bem_sameType_1(bevd_0);
case -309742024: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1461540614: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513720300: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 224164494: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2129126272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 88269440: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -366737409: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -994331834: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -666768572: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_TemplateRunner_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_6_TemplateRunner_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_TemplateRunner();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst = (BEC_2_8_6_TemplateRunner) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst;
}
}
