package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_BEC_2_8_6_TemplateRunner_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_BEC_2_8_6_TemplateRunner_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_inst;

public static BET_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public BEC_2_6_5_SystemTypes bevp_stp;
public BEC_2_8_6_TemplateRunner bem_new_0() throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
bevp_stp = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_swap == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 188*/ {
bevp_swap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 188*/
return bevp_swap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_handOff == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 193*/ {
bevp_handOff = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 193*/
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) throws Throwable {
bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bem_new_0();
bem_load_1(beva_template);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bevp_replace = (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_restart_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 213*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 215*/
bevp_stepIter = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
if (bevp_stepIter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_1_ta_ph = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_ta_ph.bem_iteratorGet_0();
} /* Line: 222*/
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_1_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 228*/ {
bevt_1_ta_ph = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_ta_ph;
} /* Line: 229*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_currentRunnerGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_stepIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1116254144);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = bem_stepIterGet_0();
bevl_iter.bemd_1(1009611758, beva_node);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 245*/ {
bevt_4_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 246*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 247*/
 else /* Line: 248*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 251*/
} /* Line: 246*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 255*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(873159525);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 255*/ {
bevl_s = bevl_iter.bemd_0(1077024860);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 257*/ {
bevt_8_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_8_ta_ph.bevi_bool)/* Line: 257*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 257*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 257*/
 else /* Line: 257*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 257*/ {
bevt_10_ta_ph = bevl_s.bemd_0(-358368207);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 257*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 257*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 257*/
 else /* Line: 257*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 257*/ {
bevt_11_ta_ph = bevl_s.bemd_0(-358368207);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 261*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 262*/
 else /* Line: 263*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 266*/
} /* Line: 261*/
 else /* Line: 257*/ {
bevt_14_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_14_ta_ph.bevi_bool)/* Line: 268*/ {
bevt_16_ta_ph = bevl_s.bemd_0(-358368207);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(445187513, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 268*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 268*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 268*/
 else /* Line: 268*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 268*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 269*/
 else /* Line: 270*/ {
bevt_18_ta_ph = bevl_s.bemd_1(13081202, this);
bevp_output.bemd_1(-1131535516, bevt_18_ta_ph);
} /* Line: 271*/
} /* Line: 257*/
} /* Line: 257*/
 else /* Line: 255*/ {
break;
} /* Line: 255*/
} /* Line: 255*/
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_19_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 278*/ {
bevt_4_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 279*/ {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 280*/
 else /* Line: 281*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 284*/
} /* Line: 279*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 288*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(873159525);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 288*/ {
bevl_s = bevl_iter.bemd_0(1077024860);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 290*/ {
bevt_8_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_8_ta_ph.bevi_bool)/* Line: 290*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 290*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 290*/
 else /* Line: 290*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 290*/ {
bevt_10_ta_ph = bevl_s.bemd_0(-358368207);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 290*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 290*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 290*/
 else /* Line: 290*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 290*/ {
bevt_11_ta_ph = bevl_s.bemd_0(-358368207);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 294*/ {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 295*/
 else /* Line: 296*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 299*/
} /* Line: 294*/
 else /* Line: 290*/ {
bevt_14_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_14_ta_ph.bevi_bool)/* Line: 301*/ {
bevt_16_ta_ph = bevl_s.bemd_0(-358368207);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(445187513, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 301*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 301*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 301*/
 else /* Line: 301*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 301*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 302*/
} /* Line: 290*/
} /* Line: 290*/
 else /* Line: 288*/ {
break;
} /* Line: 288*/
} /* Line: 288*/
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_18_ta_ph;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_run_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (bevp_baton == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 309*/ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 312*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 315*/ {
bevt_3_ta_ph = bevl_iter.bemd_0(873159525);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 315*/ {
bevl_s = bevl_iter.bemd_0(1077024860);
if (bevp_handOff == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_5_ta_ph = bevp_stp.bem_sameType_2(bevl_s, bevp_runStep);
if (bevt_5_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 317*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 317*/
 else /* Line: 317*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 317*/ {
bevt_7_ta_ph = bevl_s.bemd_0(-358368207);
bevt_6_ta_ph = bevp_handOff.bem_has_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 317*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 317*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 317*/
 else /* Line: 317*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 317*/ {
bevt_8_ta_ph = bevl_s.bemd_0(-358368207);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 323*/
 else /* Line: 324*/ {
bevt_9_ta_ph = bevl_s.bemd_1(13081202, this);
bevp_output.bemd_1(-1131535516, bevt_9_ta_ph);
} /* Line: 325*/
} /* Line: 317*/
 else /* Line: 315*/ {
break;
} /* Line: 315*/
} /* Line: 315*/
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_output = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stepIter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGet_0() throws Throwable {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stpGet_0() throws Throwable {
return bevp_stp;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_stp = (BEC_2_6_5_SystemTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {182, 183, 188, 188, 188, 189, 193, 193, 193, 194, 198, 199, 203, 204, 208, 209, 213, 213, 214, 215, 217, 221, 221, 222, 222, 224, 228, 228, 229, 229, 231, 235, 235, 235, 235, 240, 241, 245, 245, 246, 247, 247, 250, 251, 254, 255, 256, 257, 257, 257, 0, 0, 0, 257, 257, 0, 0, 0, 258, 258, 259, 260, 261, 262, 262, 265, 266, 268, 268, 268, 0, 0, 0, 269, 269, 271, 271, 274, 274, 278, 278, 279, 280, 280, 283, 284, 287, 288, 289, 290, 290, 290, 0, 0, 0, 290, 290, 0, 0, 0, 291, 291, 292, 293, 294, 295, 295, 298, 299, 301, 301, 301, 0, 0, 0, 302, 302, 305, 305, 309, 309, 310, 311, 312, 314, 315, 316, 317, 317, 317, 0, 0, 0, 317, 317, 0, 0, 0, 318, 318, 319, 320, 321, 322, 323, 325, 325, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 26, 31, 32, 34, 38, 43, 44, 46, 49, 50, 54, 55, 59, 60, 65, 70, 71, 72, 74, 80, 85, 86, 87, 89, 94, 99, 100, 101, 103, 109, 110, 111, 112, 116, 117, 143, 148, 149, 151, 152, 155, 156, 159, 162, 164, 165, 170, 171, 173, 176, 180, 183, 184, 186, 189, 193, 196, 197, 198, 199, 200, 202, 203, 206, 207, 211, 213, 214, 216, 219, 223, 226, 227, 230, 231, 239, 240, 264, 269, 270, 272, 273, 276, 277, 280, 283, 285, 286, 291, 292, 294, 297, 301, 304, 305, 307, 310, 314, 317, 318, 319, 320, 321, 323, 324, 327, 328, 332, 334, 335, 337, 340, 344, 347, 348, 356, 357, 372, 377, 378, 379, 380, 382, 385, 387, 388, 393, 394, 396, 399, 403, 406, 407, 409, 412, 416, 419, 420, 421, 422, 423, 424, 425, 428, 429, 439, 442, 446, 449, 453, 457, 461, 465, 468, 472, 475, 479, 482};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 182 20
new 0 182 20
assign 1 183 21
new 0 183 21
assign 1 188 26
undef 1 188 31
assign 1 188 32
new 0 188 32
return 1 189 34
assign 1 193 38
undef 1 193 43
assign 1 193 44
new 0 193 44
return 1 194 46
new 1 198 49
assign 1 199 50
new 0 203 54
load 1 204 55
assign 1 208 59
new 0 208 59
load 2 209 60
assign 1 213 65
def 1 213 70
restart 0 214 71
assign 1 215 72
assign 1 217 74
assign 1 221 80
undef 1 221 85
assign 1 222 86
stepsGet 0 222 86
assign 1 222 87
iteratorGet 0 222 87
return 1 224 89
assign 1 228 94
def 1 228 99
assign 1 229 100
currentRunnerGet 0 229 100
return 1 229 101
return 1 231 103
assign 1 235 109
currentRunnerGet 0 235 109
assign 1 235 110
stepIterGet 0 235 110
assign 1 235 111
currentNodeGet 0 235 111
return 1 235 112
assign 1 240 116
stepIterGet 0 240 116
currentNodeSet 1 241 117
assign 1 245 143
def 1 245 148
assign 1 246 149
runToLabel 1 246 149
assign 1 247 151
new 0 247 151
return 1 247 152
restart 0 250 155
assign 1 251 156
assign 1 254 159
stepIterGet 0 254 159
assign 1 255 162
hasNextGet 0 255 162
assign 1 256 164
nextGet 0 256 164
assign 1 257 165
def 1 257 170
assign 1 257 171
sameType 2 257 171
assign 1 0 173
assign 1 0 176
assign 1 0 180
assign 1 257 183
strGet 0 257 183
assign 1 257 184
has 1 257 184
assign 1 0 186
assign 1 0 189
assign 1 0 193
assign 1 258 196
strGet 0 258 196
assign 1 258 197
get 1 258 197
outputSet 1 259 198
swapSet 1 260 199
assign 1 261 200
runToLabel 1 261 200
assign 1 262 202
new 0 262 202
return 1 262 203
restart 0 265 206
assign 1 266 207
assign 1 268 211
sameType 2 268 211
assign 1 268 213
strGet 0 268 213
assign 1 268 214
equals 1 268 214
assign 1 0 216
assign 1 0 219
assign 1 0 223
assign 1 269 226
new 0 269 226
return 1 269 227
assign 1 271 230
handle 1 271 230
write 1 271 231
assign 1 274 239
new 0 274 239
return 1 274 240
assign 1 278 264
def 1 278 269
assign 1 279 270
skipToLabel 1 279 270
assign 1 280 272
new 0 280 272
return 1 280 273
restart 0 283 276
assign 1 284 277
assign 1 287 280
stepIterGet 0 287 280
assign 1 288 283
hasNextGet 0 288 283
assign 1 289 285
nextGet 0 289 285
assign 1 290 286
def 1 290 291
assign 1 290 292
sameType 2 290 292
assign 1 0 294
assign 1 0 297
assign 1 0 301
assign 1 290 304
strGet 0 290 304
assign 1 290 305
has 1 290 305
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 291 317
strGet 0 291 317
assign 1 291 318
get 1 291 318
outputSet 1 292 319
swapSet 1 293 320
assign 1 294 321
skipToLabel 1 294 321
assign 1 295 323
new 0 295 323
return 1 295 324
restart 0 298 327
assign 1 299 328
assign 1 301 332
sameType 2 301 332
assign 1 301 334
strGet 0 301 334
assign 1 301 335
equals 1 301 335
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 302 347
new 0 302 347
return 1 302 348
assign 1 305 356
new 0 305 356
return 1 305 357
assign 1 309 372
def 1 309 377
run 0 310 378
restart 0 311 379
assign 1 312 380
assign 1 314 382
stepIterGet 0 314 382
assign 1 315 385
hasNextGet 0 315 385
assign 1 316 387
nextGet 0 316 387
assign 1 317 388
def 1 317 393
assign 1 317 394
sameType 2 317 394
assign 1 0 396
assign 1 0 399
assign 1 0 403
assign 1 317 406
strGet 0 317 406
assign 1 317 407
has 1 317 407
assign 1 0 409
assign 1 0 412
assign 1 0 416
assign 1 318 419
strGet 0 318 419
assign 1 318 420
get 1 318 420
outputSet 1 319 421
swapSet 1 320 422
run 0 321 423
restart 0 322 424
assign 1 323 425
assign 1 325 428
handle 1 325 428
write 1 325 429
return 1 0 439
assign 1 0 442
return 1 0 446
assign 1 0 449
assign 1 0 453
assign 1 0 457
assign 1 0 461
return 1 0 465
assign 1 0 468
return 1 0 472
assign 1 0 475
return 1 0 479
assign 1 0 482
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -777617664: return bem_iteratorGet_0();
case -873263006: return bem_currentRunnerGet_0();
case -355672893: return bem_hashGet_0();
case 1630760726: return bem_toString_0();
case 1103672703: return bem_print_0();
case -247889241: return bem_handOffGet_0();
case 1996343630: return bem_swapGet_0();
case 826083187: return bem_restart_0();
case 815182698: return bem_stepIterGet_0();
case 681521317: return bem_batonGet_0();
case 1532720843: return bem_stpGet_0();
case -1116254144: return bem_currentNodeGet_0();
case -496842367: return bem_new_0();
case 1152967006: return bem_copy_0();
case 1439653353: return bem_create_0();
case 836001028: return bem_run_0();
case 1252477525: return bem_outputGet_0();
case -1951557637: return bem_replaceGet_0();
case 1969260317: return bem_runStepGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1119161086: return bem_swapSet_1(bevd_0);
case 1065274741: return bem_runStepSet_1(bevd_0);
case -1250946597: return bem_print_1(bevd_0);
case -2078689918: return bem_replaceSet_1(bevd_0);
case 1946454619: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 863284586: return bem_notEquals_1(bevd_0);
case -791914945: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case -1411723734: return bem_stepIterSet_1(bevd_0);
case 1009611758: return bem_currentNodeSet_1(bevd_0);
case -1721047471: return bem_def_1(bevd_0);
case 861793105: return bem_batonSet_1(bevd_0);
case -1528731426: return bem_handOffSet_1(bevd_0);
case -701098606: return bem_stpSet_1(bevd_0);
case 445187513: return bem_equals_1(bevd_0);
case -938105188: return bem_undef_1(bevd_0);
case -587753182: return bem_copyTo_1(bevd_0);
case 1684188548: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -1109268004: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1065004487: return bem_outputSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -2056786157: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2082389725: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 501583971: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -558969549: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1197567931: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_TemplateRunner_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_6_TemplateRunner_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_TemplateRunner();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst = (BEC_2_8_6_TemplateRunner) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_type;
}
}
