package be;
public class BET_2_5_7_BuildLibrary extends BETS_Object {
public BET_2_5_7_BuildLibrary() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "new_2", "new_4", "libNameGet_0", "libNameSet_1", "exeNameGet_0", "exeNameSet_1", "libnameInfoGet_0", "libnameInfoSet_1", "buildGet_0", "buildSet_1", "basePathGet_0", "basePathSet_1", "emitPathGet_0", "emitPathSet_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "libName", "exeName", "libnameInfo", "build", "basePath", "emitPath" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_7_BuildLibrary();
}
}
