package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemPlatform extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemPlatform() { }
private static byte[] becc_BEC_2_6_8_SystemPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_8_SystemPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_0 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_1 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_2 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_3 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_4 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_5 = {0x2F,0x64,0x65,0x76,0x2F,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_6 = {0x2E,0x73,0x68};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_7 = {0x4D,0x61,0x63,0x4F,0x53};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_8 = {0x4C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_9 = {0x46,0x72,0x65,0x65,0x42,0x53,0x44};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_11 = {0x6E,0x75,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_12 = {0x2E,0x62,0x61,0x74};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_13 = {0x4D,0x53,0x57,0x69,0x6E};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_14 = {0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_15 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x2C,0x20,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x69,0x6E,0x20,0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
public static BEC_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_inst;

public static BET_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_properName;
public BEC_2_5_4_LogicBool bevp_isNix;
public BEC_2_5_4_LogicBool bevp_isWin;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_otherSeparator;
public BEC_2_4_6_TextString bevp_nullFile;
public BEC_2_4_6_TextString bevp_scriptExt;
public BEC_2_6_8_SystemPlatform bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_new_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_9_SystemException bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_0));
bevt_2_ta_ph = bevp_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 329*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_1));
bevt_4_ta_ph = bevp_name.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 329*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 329*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 329*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 329*/ {
bevt_7_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_8_SystemPlatform_bels_2));
bevt_6_ta_ph = bevp_name.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 329*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 329*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 329*/ {
bevp_isNix = be.BECS_Runtime.boolTrue;
bevp_isWin = be.BECS_Runtime.boolFalse;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_nullFile = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_5));
bevp_scriptExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_6));
bevt_9_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_0));
bevt_8_ta_ph = bevp_name.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 336*/ {
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_7));
} /* Line: 337*/
 else /* Line: 336*/ {
bevt_11_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_1));
bevt_10_ta_ph = bevp_name.bem_equals_1(bevt_11_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 338*/ {
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_8));
} /* Line: 339*/
 else /* Line: 336*/ {
bevt_13_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_8_SystemPlatform_bels_2));
bevt_12_ta_ph = bevp_name.bem_equals_1(bevt_13_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 340*/ {
bevp_properName = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_8_SystemPlatform_bels_9));
} /* Line: 341*/
} /* Line: 336*/
} /* Line: 336*/
} /* Line: 336*/
 else /* Line: 329*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_10));
bevt_14_ta_ph = bevp_name.bem_equals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 343*/ {
bevp_isNix = be.BECS_Runtime.boolFalse;
bevp_isWin = be.BECS_Runtime.boolTrue;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_nullFile = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_11));
bevp_scriptExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_8_SystemPlatform_bels_12));
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_13));
} /* Line: 350*/
 else /* Line: 351*/ {
bevt_19_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_14));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevp_name);
bevt_20_ta_ph = (new BEC_2_4_6_TextString(60, bece_BEC_2_6_8_SystemPlatform_bels_15));
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_16_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_17_ta_ph);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 352*/
} /* Line: 329*/
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_22_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_10));
bevt_21_ta_ph = bevp_name.bem_equals_1(bevt_22_ta_ph);
if (bevt_21_ta_ph.bevi_bool)/* Line: 355*/ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(963251401);
} /* Line: 357*/
 else /* Line: 358*/ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(963251401);
} /* Line: 359*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_properNameGet_0() throws Throwable {
return bevp_properName;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_properNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_properName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNixGet_0() throws Throwable {
return bevp_isNix;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isNixSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isWinGet_0() throws Throwable {
return bevp_isWin;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isWinSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_otherSeparatorGet_0() throws Throwable {
return bevp_otherSeparator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_otherSeparatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullFileGet_0() throws Throwable {
return bevp_nullFile;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nullFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_scriptExtGet_0() throws Throwable {
return bevp_scriptExt;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_scriptExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_scriptExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {323, 324, 329, 329, 0, 329, 329, 0, 0, 0, 329, 329, 0, 0, 330, 331, 332, 333, 334, 335, 336, 336, 337, 338, 338, 339, 340, 340, 341, 343, 343, 344, 345, 346, 347, 348, 349, 350, 352, 352, 352, 352, 352, 352, 354, 355, 355, 357, 359, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {42, 43, 71, 72, 74, 77, 78, 80, 83, 87, 90, 91, 93, 96, 100, 101, 102, 103, 104, 105, 106, 107, 109, 112, 113, 115, 118, 119, 121, 127, 128, 130, 131, 132, 133, 134, 135, 136, 139, 140, 141, 142, 143, 144, 147, 148, 149, 151, 154, 159, 162, 166, 169, 173, 176, 180, 183, 187, 190, 194, 197, 201, 204, 208, 211, 215, 218};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 323 42
buildProfile 0 324 43
assign 1 329 71
new 0 329 71
assign 1 329 72
equals 1 329 72
assign 1 0 74
assign 1 329 77
new 0 329 77
assign 1 329 78
equals 1 329 78
assign 1 0 80
assign 1 0 83
assign 1 0 87
assign 1 329 90
new 0 329 90
assign 1 329 91
equals 1 329 91
assign 1 0 93
assign 1 0 96
assign 1 330 100
new 0 330 100
assign 1 331 101
new 0 331 101
assign 1 332 102
new 0 332 102
assign 1 333 103
new 0 333 103
assign 1 334 104
new 0 334 104
assign 1 335 105
new 0 335 105
assign 1 336 106
new 0 336 106
assign 1 336 107
equals 1 336 107
assign 1 337 109
new 0 337 109
assign 1 338 112
new 0 338 112
assign 1 338 113
equals 1 338 113
assign 1 339 115
new 0 339 115
assign 1 340 118
new 0 340 118
assign 1 340 119
equals 1 340 119
assign 1 341 121
new 0 341 121
assign 1 343 127
new 0 343 127
assign 1 343 128
equals 1 343 128
assign 1 344 130
new 0 344 130
assign 1 345 131
new 0 345 131
assign 1 346 132
new 0 346 132
assign 1 347 133
new 0 347 133
assign 1 348 134
new 0 348 134
assign 1 349 135
new 0 349 135
assign 1 350 136
new 0 350 136
assign 1 352 139
new 0 352 139
assign 1 352 140
add 1 352 140
assign 1 352 141
new 0 352 141
assign 1 352 142
add 1 352 142
assign 1 352 143
new 1 352 143
throw 1 352 144
assign 1 354 147
new 0 354 147
assign 1 355 148
new 0 355 148
assign 1 355 149
equals 1 355 149
assign 1 357 151
unixNewlineGet 0 357 151
assign 1 359 154
unixNewlineGet 0 359 154
return 1 0 159
assign 1 0 162
return 1 0 166
assign 1 0 169
return 1 0 173
assign 1 0 176
return 1 0 180
assign 1 0 183
return 1 0 187
assign 1 0 190
return 1 0 194
assign 1 0 197
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
return 1 0 215
assign 1 0 218
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1903518456: return bem_newlineGet_0();
case 942626481: return bem_nullFileGet_0();
case 1900805838: return bem_iteratorGet_0();
case 675554577: return bem_isNixGet_0();
case -953648774: return bem_create_0();
case -201610096: return bem_hashGet_0();
case 1447848927: return bem_properNameGet_0();
case 1394834757: return bem_new_0();
case -856419020: return bem_isWinGet_0();
case -1042462432: return bem_scriptExtGet_0();
case 875600241: return bem_nameGet_0();
case 1729417373: return bem_otherSeparatorGet_0();
case -1035398654: return bem_copy_0();
case 104746848: return bem_buildProfile_0();
case -1550354971: return bem_print_0();
case 1679318778: return bem_toString_0();
case 1380706604: return bem_separatorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 580052299: return bem_notEquals_1(bevd_0);
case -443181240: return bem_isNixSet_1(bevd_0);
case 692766759: return bem_nameSet_1(bevd_0);
case 1440615589: return bem_scriptExtSet_1(bevd_0);
case 1211719345: return bem_isWinSet_1(bevd_0);
case 914891998: return bem_equals_1(bevd_0);
case -769543545: return bem_copyTo_1(bevd_0);
case -873014888: return bem_undef_1(bevd_0);
case -1759798367: return bem_properNameSet_1(bevd_0);
case 544277029: return bem_newlineSet_1(bevd_0);
case -657949834: return bem_otherSeparatorSet_1(bevd_0);
case -1715921186: return bem_def_1(bevd_0);
case -1644342574: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -762545535: return bem_nullFileSet_1(bevd_0);
case 1511573651: return bem_separatorSet_1(bevd_0);
case -313527528: return bem_print_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1657225406: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -222789624: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 979775573: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1703451725: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst = (BEC_2_6_8_SystemPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_type;
}
}
