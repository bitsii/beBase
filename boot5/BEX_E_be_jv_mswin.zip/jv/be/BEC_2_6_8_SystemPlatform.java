package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemPlatform extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemPlatform() { }
private static byte[] becc_BEC_2_6_8_SystemPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_8_SystemPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_0 = {0x6D,0x61,0x63,0x6F,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_1 = {0x6C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_2 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_3 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_4 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_5 = {0x2F,0x64,0x65,0x76,0x2F,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_6 = {0x2E,0x73,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_7 = {0x4D,0x61,0x63,0x4F,0x53};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_8 = {0x4C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_9 = {0x46,0x72,0x65,0x65,0x42,0x53,0x44};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_11 = {0x6E,0x75,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_12 = {0x2E,0x62,0x61,0x74};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_13 = {0x4D,0x53,0x57,0x69,0x6E};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_14 = {0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_14, 9));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_15 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x2C,0x20,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x69,0x6E,0x20,0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_15, 60));
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 5));
public static BEC_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_inst;

public static BET_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_properName;
public BEC_2_5_4_LogicBool bevp_isNix;
public BEC_2_5_4_LogicBool bevp_isWin;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_otherSeparator;
public BEC_2_4_6_TextString bevp_nullFile;
public BEC_2_4_6_TextString bevp_scriptExt;
public BEC_2_6_8_SystemPlatform bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_new_1(BEC_2_4_6_TextString beva__name) throws Throwable {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_buildProfile_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_strings = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_0;
bevt_2_tmpany_phold = bevp_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_1;
bevt_4_tmpany_phold = bevp_name.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 637 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 637 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_7_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_2;
bevt_6_tmpany_phold = bevp_name.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 637 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 637 */ {
bevp_isNix = be.BECS_Runtime.boolTrue;
bevp_isWin = be.BECS_Runtime.boolFalse;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_nullFile = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_5));
bevp_scriptExt = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_6));
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_3;
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_7));
} /* Line: 645 */
 else  /* Line: 644 */ {
bevt_11_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_4;
bevt_10_tmpany_phold = bevp_name.bem_equals_1(bevt_11_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 646 */ {
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_8));
} /* Line: 647 */
 else  /* Line: 644 */ {
bevt_13_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_5;
bevt_12_tmpany_phold = bevp_name.bem_equals_1(bevt_13_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevp_properName = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_8_SystemPlatform_bels_9));
} /* Line: 649 */
} /* Line: 644 */
} /* Line: 644 */
} /* Line: 644 */
 else  /* Line: 637 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_6;
bevt_14_tmpany_phold = bevp_name.bem_equals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 651 */ {
bevp_isNix = be.BECS_Runtime.boolFalse;
bevp_isWin = be.BECS_Runtime.boolTrue;
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_otherSeparator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_nullFile = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_11));
bevp_scriptExt = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_8_SystemPlatform_bels_12));
bevp_properName = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_13));
} /* Line: 658 */
 else  /* Line: 659 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_7;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevp_name);
bevt_20_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_8;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_16_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_17_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 660 */
} /* Line: 637 */
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_22_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_9;
bevt_21_tmpany_phold = bevp_name.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 663 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(-1687900028);
} /* Line: 665 */
 else  /* Line: 666 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(-1687900028);
} /* Line: 667 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public final BEC_2_4_6_TextString bem_nameGetDirect_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_properNameGet_0() throws Throwable {
return bevp_properName;
} /*method end*/
public final BEC_2_4_6_TextString bem_properNameGetDirect_0() throws Throwable {
return bevp_properName;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_properNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_properName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_properNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_properName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNixGet_0() throws Throwable {
return bevp_isNix;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isNixGetDirect_0() throws Throwable {
return bevp_isNix;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isNixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_isNixSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isWinGet_0() throws Throwable {
return bevp_isWin;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_isWinGetDirect_0() throws Throwable {
return bevp_isWin;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isWinSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_isWinSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public final BEC_2_4_6_TextString bem_newlineGetDirect_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_otherSeparatorGet_0() throws Throwable {
return bevp_otherSeparator;
} /*method end*/
public final BEC_2_4_6_TextString bem_otherSeparatorGetDirect_0() throws Throwable {
return bevp_otherSeparator;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_otherSeparatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_otherSeparatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullFileGet_0() throws Throwable {
return bevp_nullFile;
} /*method end*/
public final BEC_2_4_6_TextString bem_nullFileGetDirect_0() throws Throwable {
return bevp_nullFile;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nullFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_nullFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_scriptExtGet_0() throws Throwable {
return bevp_scriptExt;
} /*method end*/
public final BEC_2_4_6_TextString bem_scriptExtGetDirect_0() throws Throwable {
return bevp_scriptExt;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_scriptExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_scriptExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemPlatform bem_scriptExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_scriptExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {631, 632, 637, 637, 0, 637, 637, 0, 0, 0, 637, 637, 0, 0, 638, 639, 640, 641, 642, 643, 644, 644, 645, 646, 646, 647, 648, 648, 649, 651, 651, 652, 653, 654, 655, 656, 657, 658, 660, 660, 660, 660, 660, 660, 662, 663, 663, 665, 667, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {52, 53, 81, 82, 84, 87, 88, 90, 93, 97, 100, 101, 103, 106, 110, 111, 112, 113, 114, 115, 116, 117, 119, 122, 123, 125, 128, 129, 131, 137, 138, 140, 141, 142, 143, 144, 145, 146, 149, 150, 151, 152, 153, 154, 157, 158, 159, 161, 164, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207, 211, 214, 217, 221, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263, 267, 270, 273, 277, 281, 284, 287, 291};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 631 52
buildProfile 0 632 53
assign 1 637 81
new 0 637 81
assign 1 637 82
equals 1 637 82
assign 1 0 84
assign 1 637 87
new 0 637 87
assign 1 637 88
equals 1 637 88
assign 1 0 90
assign 1 0 93
assign 1 0 97
assign 1 637 100
new 0 637 100
assign 1 637 101
equals 1 637 101
assign 1 0 103
assign 1 0 106
assign 1 638 110
new 0 638 110
assign 1 639 111
new 0 639 111
assign 1 640 112
new 0 640 112
assign 1 641 113
new 0 641 113
assign 1 642 114
new 0 642 114
assign 1 643 115
new 0 643 115
assign 1 644 116
new 0 644 116
assign 1 644 117
equals 1 644 117
assign 1 645 119
new 0 645 119
assign 1 646 122
new 0 646 122
assign 1 646 123
equals 1 646 123
assign 1 647 125
new 0 647 125
assign 1 648 128
new 0 648 128
assign 1 648 129
equals 1 648 129
assign 1 649 131
new 0 649 131
assign 1 651 137
new 0 651 137
assign 1 651 138
equals 1 651 138
assign 1 652 140
new 0 652 140
assign 1 653 141
new 0 653 141
assign 1 654 142
new 0 654 142
assign 1 655 143
new 0 655 143
assign 1 656 144
new 0 656 144
assign 1 657 145
new 0 657 145
assign 1 658 146
new 0 658 146
assign 1 660 149
new 0 660 149
assign 1 660 150
add 1 660 150
assign 1 660 151
new 0 660 151
assign 1 660 152
add 1 660 152
assign 1 660 153
new 1 660 153
throw 1 660 154
assign 1 662 157
new 0 662 157
assign 1 663 158
new 0 663 158
assign 1 663 159
equals 1 663 159
assign 1 665 161
unixNewlineGet 0 665 161
assign 1 667 164
unixNewlineGet 0 667 164
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
return 1 0 267
return 1 0 270
assign 1 0 273
assign 1 0 277
return 1 0 281
return 1 0 284
assign 1 0 287
assign 1 0 291
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 318664185: return bem_nameGetDirect_0();
case 322973431: return bem_print_0();
case 94158825: return bem_properNameGet_0();
case 1692152348: return bem_scriptExtGet_0();
case -1478601674: return bem_properNameGetDirect_0();
case -1695668475: return bem_newlineGetDirect_0();
case 597357534: return bem_tagGet_0();
case 1334955676: return bem_isWinGet_0();
case -753644705: return bem_hashGet_0();
case -381740729: return bem_deserializeClassNameGet_0();
case -43502949: return bem_toAny_0();
case -73648962: return bem_buildProfile_0();
case -1846037583: return bem_otherSeparatorGetDirect_0();
case -410783155: return bem_new_0();
case -54433340: return bem_scriptExtGetDirect_0();
case -167875088: return bem_newlineGet_0();
case 1461724031: return bem_copy_0();
case 484695877: return bem_isNixGetDirect_0();
case 305613993: return bem_sourceFileNameGet_0();
case 771698519: return bem_isWinGetDirect_0();
case 1851036145: return bem_serializationIteratorGet_0();
case -1101326644: return bem_serializeContents_0();
case 1755762356: return bem_nullFileGet_0();
case -1569222986: return bem_fieldIteratorGet_0();
case -1603023356: return bem_nullFileGetDirect_0();
case -646385374: return bem_nameGet_0();
case -725471417: return bem_otherSeparatorGet_0();
case -1060980214: return bem_separatorGetDirect_0();
case 291309239: return bem_once_0();
case 625547167: return bem_toString_0();
case 364235321: return bem_echo_0();
case 678571136: return bem_many_0();
case -1087766017: return bem_serializeToString_0();
case -114966915: return bem_separatorGet_0();
case -304415890: return bem_classNameGet_0();
case 2050059376: return bem_iteratorGet_0();
case -545885409: return bem_fieldNamesGet_0();
case 1529339065: return bem_isNixGet_0();
case -909675958: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1354680103: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 877944352: return bem_nameSet_1(bevd_0);
case 37414530: return bem_otherSeparatorSet_1(bevd_0);
case 1941256530: return bem_sameObject_1(bevd_0);
case 947634878: return bem_equals_1(bevd_0);
case 961521914: return bem_nullFileSet_1(bevd_0);
case 1636138622: return bem_separatorSetDirect_1(bevd_0);
case 1722274975: return bem_newlineSet_1(bevd_0);
case 57523751: return bem_properNameSet_1(bevd_0);
case -1404565785: return bem_scriptExtSetDirect_1(bevd_0);
case 1123559384: return bem_separatorSet_1(bevd_0);
case -861710293: return bem_scriptExtSet_1(bevd_0);
case -1464940427: return bem_otherSeparatorSetDirect_1(bevd_0);
case 175863228: return bem_notEquals_1(bevd_0);
case 362074537: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2074318851: return bem_defined_1(bevd_0);
case 26154413: return bem_sameType_1(bevd_0);
case -225203831: return bem_undef_1(bevd_0);
case -2002487512: return bem_isNixSetDirect_1(bevd_0);
case -1217876284: return bem_undefined_1(bevd_0);
case -186793001: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -59248102: return bem_nameSetDirect_1(bevd_0);
case -1378670362: return bem_isNixSet_1(bevd_0);
case -1139506934: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1596084387: return bem_newlineSetDirect_1(bevd_0);
case -949389725: return bem_def_1(bevd_0);
case 2075415097: return bem_otherClass_1(bevd_0);
case -1262364388: return bem_properNameSetDirect_1(bevd_0);
case -289875241: return bem_otherType_1(bevd_0);
case -1796844120: return bem_sameClass_1(bevd_0);
case 206420127: return bem_isWinSetDirect_1(bevd_0);
case -586096102: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1919366404: return bem_copyTo_1(bevd_0);
case 43028074: return bem_nullFileSetDirect_1(bevd_0);
case -1307600744: return bem_isWinSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1731367965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 631014110: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1264520798: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -998516190: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 640919140: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -873775373: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -201564823: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemPlatform_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemPlatform_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemPlatform();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst = (BEC_2_6_8_SystemPlatform) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_type;
}
}
