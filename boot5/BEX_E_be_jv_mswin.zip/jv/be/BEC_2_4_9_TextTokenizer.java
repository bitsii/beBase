package be;
/* IO:File: source/base/Tokenize.be */
public final class BEC_2_4_9_TextTokenizer extends BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_BEC_2_4_9_TextTokenizer_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_4_9_TextTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_3 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_inst;
public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
bevp_includeTokens = be.BECS_Runtime.boolFalse;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) throws Throwable {
bevp_includeTokens = beva__includeTokens;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_tmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = beva_delims.bem_stringIteratorGet_0();
while (true)
 /* Line: 24 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevl_chi = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_tmpany_phold);
} /* Line: 25 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_addToken_1(BEC_2_4_6_TextString beva__delim) throws Throwable {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_tmpany_phold = bem_tokenizeIterator_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) throws Throwable {
BEC_2_4_9_TextTokenizer bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_tmpany_phold = bem_tokenizeIterator_2(bevt_1_tmpany_phold, beva_tokenAcceptor);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) throws Throwable {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 46 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(1185951145);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 46 */ {
beva_i.bemd_1(-423201660, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_0;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(-656055335, bevt_5_tmpany_phold);
} /* Line: 51 */
if (bevp_includeTokens.bevi_bool) /* Line: 53 */ {
beva_acceptor.bemd_1(-656055335, bevl_cc);
} /* Line: 54 */
} /* Line: 53 */
 else  /* Line: 56 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 57 */
} /* Line: 49 */
 else  /* Line: 46 */ {
break;
} /* Line: 46 */
} /* Line: 46 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_1;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(-656055335, bevt_9_tmpany_phold);
} /* Line: 61 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 69 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(1185951145);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 69 */ {
beva_i.bemd_1(-423201660, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_2;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 74 */
if (bevp_includeTokens.bevi_bool) /* Line: 76 */ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 77 */
} /* Line: 76 */
 else  /* Line: 79 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 80 */
} /* Line: 72 */
 else  /* Line: 69 */ {
break;
} /* Line: 69 */
} /* Line: 69 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_3;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_tmpany_phold);
} /* Line: 84 */
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() throws Throwable {
return bevp_tmap;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() throws Throwable {
return bevp_includeTokens;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {13, 14, 18, 19, 23, 24, 0, 24, 24, 25, 25, 30, 31, 32, 36, 36, 36, 40, 40, 40, 44, 45, 46, 47, 48, 49, 49, 50, 50, 50, 50, 51, 51, 54, 57, 60, 60, 60, 60, 61, 61, 66, 67, 68, 69, 70, 71, 72, 72, 73, 73, 73, 73, 74, 74, 77, 80, 83, 83, 83, 83, 84, 84, 86, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 20, 21, 29, 30, 30, 33, 35, 36, 37, 47, 48, 49, 55, 56, 57, 62, 63, 64, 80, 81, 84, 86, 87, 88, 93, 94, 95, 96, 101, 102, 103, 106, 110, 117, 118, 119, 124, 125, 126, 145, 146, 147, 150, 152, 153, 154, 159, 160, 161, 162, 167, 168, 169, 172, 176, 183, 184, 185, 190, 191, 192, 194, 197, 200, 204, 207};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 13 15
new 0 13 15
tokensStringSet 1 14 16
assign 1 18 20
tokensStringSet 1 19 21
assign 1 23 29
new 0 23 29
assign 1 24 30
stringIteratorGet 0 0 30
assign 1 24 33
hasNextGet 0 24 33
assign 1 24 35
nextGet 0 24 35
assign 1 25 36
toString 0 25 36
put 2 25 37
assign 1 30 47
new 0 30 47
addValue 1 31 48
put 2 32 49
assign 1 36 55
new 1 36 55
assign 1 36 56
tokenizeIterator 1 36 56
return 1 36 57
assign 1 40 62
new 1 40 62
assign 1 40 63
tokenizeIterator 2 40 63
return 1 40 64
assign 1 44 80
new 0 44 80
assign 1 45 81
new 0 45 81
assign 1 46 84
hasNextGet 0 46 84
next 1 47 86
assign 1 48 87
get 1 48 87
assign 1 49 88
def 1 49 93
assign 1 50 94
sizeGet 0 50 94
assign 1 50 95
new 0 50 95
assign 1 50 96
greater 1 50 101
assign 1 51 102
extractString 0 51 102
acceptToken 1 51 103
acceptToken 1 54 106
addValue 1 57 110
assign 1 60 117
sizeGet 0 60 117
assign 1 60 118
new 0 60 118
assign 1 60 119
greater 1 60 124
assign 1 61 125
extractString 0 61 125
acceptToken 1 61 126
assign 1 66 145
new 0 66 145
assign 1 67 146
new 0 67 146
assign 1 68 147
new 0 68 147
assign 1 69 150
hasNextGet 0 69 150
next 1 70 152
assign 1 71 153
get 1 71 153
assign 1 72 154
def 1 72 159
assign 1 73 160
sizeGet 0 73 160
assign 1 73 161
new 0 73 161
assign 1 73 162
greater 1 73 167
assign 1 74 168
extractString 0 74 168
addValue 1 74 169
addValue 1 77 172
addValue 1 80 176
assign 1 83 183
sizeGet 0 83 183
assign 1 83 184
new 0 83 184
assign 1 83 185
greater 1 83 190
assign 1 84 191
extractString 0 84 191
addValue 1 84 192
return 1 86 194
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -149632320: return bem_toAny_0();
case -93701646: return bem_fieldIteratorGet_0();
case -748319096: return bem_print_0();
case -29400896: return bem_create_0();
case -419498074: return bem_includeTokensGet_0();
case -1052800757: return bem_echo_0();
case -801589503: return bem_tagGet_0();
case -794227383: return bem_copy_0();
case 861710738: return bem_many_0();
case -7634332: return bem_classNameGet_0();
case 900978335: return bem_serializeToString_0();
case 1338975369: return bem_sourceFileNameGet_0();
case -14402816: return bem_serializeContents_0();
case -1674098047: return bem_once_0();
case -1701242685: return bem_serializationIteratorGet_0();
case -258597009: return bem_hashGet_0();
case -51803385: return bem_toString_0();
case -124916815: return bem_new_0();
case -1749103224: return bem_iteratorGet_0();
case 2124345343: return bem_tmapGet_0();
case -467186719: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 1518481031: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -983540661: return bem_undefined_1(bevd_0);
case -73997568: return bem_equals_1(bevd_0);
case -917774080: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
case -1748366760: return bem_tokenize_1(bevd_0);
case -302237230: return bem_tokenizeIterator_1(bevd_0);
case 1970850163: return bem_sameType_1(bevd_0);
case -808218327: return bem_tmapSet_1(bevd_0);
case 616348580: return bem_undef_1(bevd_0);
case -271716565: return bem_copyTo_1(bevd_0);
case -2092712540: return bem_def_1(bevd_0);
case 642489795: return bem_otherType_1(bevd_0);
case -93273669: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 550176080: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -20159434: return bem_sameClass_1(bevd_0);
case -218714893: return bem_otherClass_1(bevd_0);
case -247522048: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
case -223966486: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1391202250: return bem_defined_1(bevd_0);
case 2036979549: return bem_notEquals_1(bevd_0);
case -1182973110: return bem_includeTokensSet_1(bevd_0);
case -1474467614: return bem_sameObject_1(bevd_0);
case 226940097: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 2093180987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 292502272: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1140361328: return bem_tokenizeIterator_2(bevd_0, bevd_1);
case -66460559: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1031466779: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2131321099: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 393038393: return bem_tokenize_2(bevd_0, bevd_1);
case -1582293253: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1367679335: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -323049121: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_4_9_TextTokenizer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_9_TextTokenizer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_9_TextTokenizer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst = (BEC_2_4_9_TextTokenizer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst;
}
}
