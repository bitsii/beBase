package be;
/* IO:File: source/base/Tokenize.be */
public final class BEC_2_4_9_TextTokenizer extends BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_BEC_2_4_9_TextTokenizer_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_4_9_TextTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static BEC_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_inst;

public static BET_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_type;

public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
bevp_includeTokens = be.BECS_Runtime.boolFalse;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) throws Throwable {
bevp_includeTokens = beva__includeTokens;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_tmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_loop = beva_delims.bem_stringIteratorGet_0();
while (true)
/* Line: 23*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 23*/ {
bevl_chi = bevt_0_ta_loop.bem_nextGet_0();
bevt_2_ta_ph = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_ta_ph);
} /* Line: 24*/
 else /* Line: 23*/ {
break;
} /* Line: 23*/
} /* Line: 23*/
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_addToken_1(BEC_2_4_6_TextString beva__delim) throws Throwable {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_ta_ph = bem_tokenizeIterator_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) throws Throwable {
BEC_2_4_9_TextTokenizer bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_ta_ph = bem_tokenizeIterator_2(bevt_1_ta_ph, beva_tokenAcceptor);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) throws Throwable {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
/* Line: 45*/ {
bevt_0_ta_ph = beva_i.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 45*/ {
beva_i.bemd_1(-1047191582, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_3_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_5_ta_ph = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1214449749, bevt_5_ta_ph);
} /* Line: 50*/
if (bevp_includeTokens.bevi_bool)/* Line: 52*/ {
beva_acceptor.bemd_1(1214449749, bevl_cc);
} /* Line: 53*/
} /* Line: 52*/
 else /* Line: 55*/ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 56*/
} /* Line: 48*/
 else /* Line: 45*/ {
break;
} /* Line: 45*/
} /* Line: 45*/
bevt_7_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_7_ta_ph.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_9_ta_ph = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1214449749, bevt_9_ta_ph);
} /* Line: 60*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
/* Line: 68*/ {
bevt_0_ta_ph = beva_i.bemd_0(-1499211844);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 68*/ {
beva_i.bemd_1(-1047191582, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_3_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_5_ta_ph = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 73*/
if (bevp_includeTokens.bevi_bool)/* Line: 75*/ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 76*/
} /* Line: 75*/
 else /* Line: 78*/ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 79*/
} /* Line: 71*/
 else /* Line: 68*/ {
break;
} /* Line: 68*/
} /* Line: 68*/
bevt_7_ta_ph = bevl_accum.bem_sizeGet_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_7_ta_ph.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 82*/ {
bevt_9_ta_ph = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_ta_ph);
} /* Line: 83*/
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() throws Throwable {
return bevp_tmap;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() throws Throwable {
return bevp_includeTokens;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {12, 13, 17, 18, 22, 23, 0, 23, 23, 24, 24, 29, 30, 31, 35, 35, 35, 39, 39, 39, 43, 44, 45, 46, 47, 48, 48, 49, 49, 49, 49, 50, 50, 53, 56, 59, 59, 59, 59, 60, 60, 65, 66, 67, 68, 69, 70, 71, 71, 72, 72, 72, 72, 73, 73, 76, 79, 82, 82, 82, 82, 83, 83, 85, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 19, 20, 28, 29, 29, 32, 34, 35, 36, 46, 47, 48, 54, 55, 56, 61, 62, 63, 79, 80, 83, 85, 86, 87, 92, 93, 94, 95, 100, 101, 102, 105, 109, 116, 117, 118, 123, 124, 125, 144, 145, 146, 149, 151, 152, 153, 158, 159, 160, 161, 166, 167, 168, 171, 175, 182, 183, 184, 189, 190, 191, 193, 196, 199, 203, 206};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 12 14
new 0 12 14
tokensStringSet 1 13 15
assign 1 17 19
tokensStringSet 1 18 20
assign 1 22 28
new 0 22 28
assign 1 23 29
stringIteratorGet 0 0 29
assign 1 23 32
hasNextGet 0 23 32
assign 1 23 34
nextGet 0 23 34
assign 1 24 35
toString 0 24 35
put 2 24 36
assign 1 29 46
new 0 29 46
addValue 1 30 47
put 2 31 48
assign 1 35 54
new 1 35 54
assign 1 35 55
tokenizeIterator 1 35 55
return 1 35 56
assign 1 39 61
new 1 39 61
assign 1 39 62
tokenizeIterator 2 39 62
return 1 39 63
assign 1 43 79
new 0 43 79
assign 1 44 80
new 0 44 80
assign 1 45 83
hasNextGet 0 45 83
next 1 46 85
assign 1 47 86
get 1 47 86
assign 1 48 87
def 1 48 92
assign 1 49 93
sizeGet 0 49 93
assign 1 49 94
new 0 49 94
assign 1 49 95
greater 1 49 100
assign 1 50 101
extractString 0 50 101
acceptToken 1 50 102
acceptToken 1 53 105
addValue 1 56 109
assign 1 59 116
sizeGet 0 59 116
assign 1 59 117
new 0 59 117
assign 1 59 118
greater 1 59 123
assign 1 60 124
extractString 0 60 124
acceptToken 1 60 125
assign 1 65 144
new 0 65 144
assign 1 66 145
new 0 66 145
assign 1 67 146
new 0 67 146
assign 1 68 149
hasNextGet 0 68 149
next 1 69 151
assign 1 70 152
get 1 70 152
assign 1 71 153
def 1 71 158
assign 1 72 159
sizeGet 0 72 159
assign 1 72 160
new 0 72 160
assign 1 72 161
greater 1 72 166
assign 1 73 167
extractString 0 73 167
addValue 1 73 168
addValue 1 76 171
addValue 1 79 175
assign 1 82 182
sizeGet 0 82 182
assign 1 82 183
new 0 82 183
assign 1 82 184
greater 1 82 189
assign 1 83 190
extractString 0 83 190
addValue 1 83 191
return 1 85 193
return 1 0 196
assign 1 0 199
return 1 0 203
assign 1 0 206
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2003002715: return bem_includeTokensGet_0();
case -509281348: return bem_new_0();
case -1436588716: return bem_copy_0();
case 916511308: return bem_print_0();
case -593179039: return bem_hashGet_0();
case 1377393171: return bem_iteratorGet_0();
case 2018531225: return bem_tmapGet_0();
case 593600550: return bem_toString_0();
case 572942595: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 740081825: return bem_notEquals_1(bevd_0);
case 152454017: return bem_def_1(bevd_0);
case -276562405: return bem_tokenize_1(bevd_0);
case 1008582343: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1753782011: return bem_tokenizeIterator_1(bevd_0);
case -257664443: return bem_equals_1(bevd_0);
case -1239385327: return bem_undef_1(bevd_0);
case 1686316552: return bem_includeTokensSet_1(bevd_0);
case -1462221722: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
case 385334123: return bem_tmapSet_1(bevd_0);
case -1490966740: return bem_copyTo_1(bevd_0);
case 2054591481: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840314986: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1752331825: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -112439602: return bem_tokenize_2(bevd_0, bevd_1);
case 376456972: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 426315431: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1428184836: return bem_tokenizeIterator_2(bevd_0, bevd_1);
case 2087906856: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_4_9_TextTokenizer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_9_TextTokenizer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_9_TextTokenizer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst = (BEC_2_4_9_TextTokenizer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_type;
}
}
