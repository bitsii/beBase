package be;
/* IO:File: source/base/DoNothing.be */
public class BEC_2_6_9_SystemDoNothing extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemDoNothing() { }
private static byte[] becc_BEC_2_6_9_SystemDoNothing_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x44,0x6F,0x4E,0x6F,0x74,0x68,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_6_9_SystemDoNothing_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x44,0x6F,0x4E,0x6F,0x74,0x68,0x69,0x6E,0x67,0x2E,0x62,0x65};
public static BEC_2_6_9_SystemDoNothing bece_BEC_2_6_9_SystemDoNothing_bevs_inst;

public static BET_2_6_9_SystemDoNothing bece_BEC_2_6_9_SystemDoNothing_bevs_type;

public BEC_2_6_9_SystemDoNothing bem_main_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1900805838: return bem_iteratorGet_0();
case -953648774: return bem_create_0();
case -201610096: return bem_hashGet_0();
case 1394834757: return bem_new_0();
case 1126939526: return bem_main_0();
case -1035398654: return bem_copy_0();
case -1550354971: return bem_print_0();
case 1679318778: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -313527528: return bem_print_1(bevd_0);
case -1715921186: return bem_def_1(bevd_0);
case -873014888: return bem_undef_1(bevd_0);
case -769543545: return bem_copyTo_1(bevd_0);
case 580052299: return bem_notEquals_1(bevd_0);
case 914891998: return bem_equals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1657225406: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -222789624: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 979775573: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1703451725: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemDoNothing_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_9_SystemDoNothing_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemDoNothing();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_inst = (BEC_2_6_9_SystemDoNothing) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_type;
}
}
