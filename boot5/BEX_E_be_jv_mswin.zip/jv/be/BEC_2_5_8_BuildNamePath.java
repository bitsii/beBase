package be;
/* IO:File: source/build/BuildTypes.be */
public final class BEC_2_5_8_BuildNamePath extends BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
public static BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public BEC_2_5_8_BuildNamePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_ta_ph.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
if (bevp_label == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_2_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_1_ta_ph = bevt_2_ta_ph.bem_lastGet_0();
return bevt_1_ta_ph;
} /* Line: 26*/
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_0));
bevt_1_ta_ph = bevl_oldpath.bem_equals_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 34*/ {
return this;
} /* Line: 34*/
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_1));
bevt_3_ta_ph = bevl_oldpath.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 35*/ {
return this;
} /* Line: 35*/
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(771321850);
bevt_6_ta_ph = bevl_tunode.bem_heldGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(1835821324);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_ta_ph.bemd_1(-484277259, bevl_fstep);
if (bevl_par == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_10_ta_ph = beva_node.bemd_0(1152897387);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1797006708);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1835821324);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_ta_ph.bemd_1(-484277259, bevl_fstep);
} /* Line: 40*/
if (bevl_par == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_14_ta_ph = bem_pathGet_0();
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_8_BuildNamePath_bels_2));
bevt_13_ta_ph = bevt_14_ta_ph.bem_has_1(bevt_15_ta_ph);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 42*/
 else /* Line: 42*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 42*/ {
bevl_np2 = bem_deleteFirstStep_0();
bevl_np = bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 45*/
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(887645702);
if (bevl_clnode == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 48*/ {
bevt_17_ta_ph = bevl_clnode.bem_heldGet_0();
bevt_17_ta_ph.bemd_1(-478706087, this);
} /* Line: 49*/
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 20, 21, 25, 25, 26, 26, 26, 29, 33, 34, 34, 34, 35, 35, 35, 36, 37, 38, 38, 38, 39, 39, 40, 40, 40, 40, 42, 42, 42, 42, 42, 42, 42, 0, 0, 0, 43, 44, 45, 47, 48, 48, 49, 49, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 26, 31, 32, 33, 34, 36, 64, 65, 66, 68, 70, 71, 73, 75, 76, 77, 78, 79, 80, 85, 86, 87, 88, 89, 91, 96, 97, 98, 99, 100, 105, 106, 109, 113, 116, 117, 118, 120, 121, 126, 127, 128, 133};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 17
new 0 20 17
assign 1 20 18
colonGet 0 20 18
fromString 1 21 19
assign 1 25 26
undef 1 25 31
assign 1 26 32
split 1 26 32
assign 1 26 33
lastGet 0 26 33
return 1 26 34
return 1 29 36
assign 1 33 64
pathGet 0 33 64
assign 1 34 65
new 0 34 65
assign 1 34 66
equals 1 34 66
return 1 34 68
assign 1 35 70
new 0 35 70
assign 1 35 71
equals 1 35 71
return 1 35 73
assign 1 36 75
firstStepGet 0 36 75
assign 1 37 76
transUnitGet 0 37 76
assign 1 38 77
heldGet 0 38 77
assign 1 38 78
aliasedGet 0 38 78
assign 1 38 79
get 1 38 79
assign 1 39 80
undef 1 39 85
assign 1 40 86
buildGet 0 40 86
assign 1 40 87
emitDataGet 0 40 87
assign 1 40 88
aliasedGet 0 40 88
assign 1 40 89
get 1 40 89
assign 1 42 91
def 1 42 96
assign 1 42 97
pathGet 0 42 97
assign 1 42 98
new 0 42 98
assign 1 42 99
has 1 42 99
assign 1 42 100
not 0 42 105
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 43 116
deleteFirstStep 0 43 116
assign 1 44 117
add 1 44 117
assign 1 45 118
pathGet 0 45 118
assign 1 47 120
classGet 0 47 120
assign 1 48 121
def 1 48 126
assign 1 49 127
heldGet 0 49 127
addUsed 1 49 128
assign 1 0 133
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1268755732: return bem_labelGet_0();
case -906677631: return bem_deleteFirstStep_0();
case -813823710: return bem_iteratorGet_0();
case -745466650: return bem_stepListGet_0();
case -1334231140: return bem_parentGet_0();
case 749584012: return bem_hashGet_0();
case -1162278176: return bem_toString_0();
case 1487203260: return bem_firstStepGet_0();
case 2011117824: return bem_makeAbsolute_0();
case -287453828: return bem_new_0();
case 279017063: return bem_copy_0();
case -2132502860: return bem_pathGet_0();
case -1312265532: return bem_lastStepGet_0();
case -1204561292: return bem_stepsGet_0();
case 740774521: return bem_print_0();
case 1567109673: return bem_isAbsoluteGet_0();
case 1337268080: return bem_create_0();
case 588781461: return bem_makeNonAbsolute_0();
case 2066971737: return bem_separatorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1178956038: return bem_pathSet_1(bevd_0);
case -2044307114: return bem_separatorSet_1(bevd_0);
case 1378421880: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1600575656: return bem_copyTo_1(bevd_0);
case 2040463462: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -68575361: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1665033391: return bem_add_1(bevd_0);
case -1834271651: return bem_addStep_1(bevd_0);
case -286545109: return bem_notEquals_1(bevd_0);
case -851181588: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 2021639650: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -799770545: return bem_labelSet_1(bevd_0);
case 1280761877: return bem_addSteps_1(bevd_0);
case 1770269135: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -60837636: return bem_def_1(bevd_0);
case -1232318468: return bem_equals_1(bevd_0);
case -917009475: return bem_undef_1(bevd_0);
case -1395619171: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1483900587: return bem_resolve_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -539426492: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -533312375: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 982528451: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -306114529: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -266670851: return bem_addSteps_2(bevd_0, bevd_1);
case -551967809: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildNamePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
