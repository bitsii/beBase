package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
public static BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(16));
bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_leni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 229*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 229*/ {
if (beva_capi == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 229*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 229*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 229*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 229*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 230*/
if (bevp_length == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 232*/ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 235*/ {
return this;
} /* Line: 236*/
} /* Line: 235*/

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = (new BEC_2_4_3_MathInt(2));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sizeSet_1(BEC_2_4_3_MathInt beva_val) throws Throwable {
bem_lengthSet_1(beva_val);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 276*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_length.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevp_length.bem_subtract_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 304*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 305*/
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 307*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_posi.bem_add_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
} /* Line: 308*/

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 324*/ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 324*/
 else /* Line: 324*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 324*/ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 330*/
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_fl = bevp_length.bem_subtract_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_j = beva_pos.bem_add_1(bevt_2_ta_ph);
bevl_i = beva_pos.bem_copy_0();
while (true)
/* Line: 343*/ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 343*/ {
bevt_4_ta_ph = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 343*/
 else /* Line: 343*/ {
break;
} /* Line: 343*/
} /* Line: 343*/
bem_put_2(bevl_fl, null);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevp_length.bem_subtract_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 349*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 363*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 363*/ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 363*/
 else /* Line: 363*/ {
break;
} /* Line: 363*/
} /* Line: 363*/
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_n = bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 371*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_1_ta_ph = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_ta_ph);
bevl_i.bevi_int++;
} /* Line: 371*/
 else /* Line: 371*/ {
break;
} /* Line: 371*/
} /* Line: 371*/
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = beva_xi.bem_lengthGet_0();
bevt_3_ta_ph = bevp_length.bem_add_1(bevt_4_ta_ph);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_loop = bem_iteratorGet_0();
while (true)
/* Line: 383*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-221472220);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 383*/ {
bevl_c = bevt_0_ta_loop.bemd_0(571416905);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 384*/
 else /* Line: 383*/ {
break;
} /* Line: 383*/
} /* Line: 383*/
bevt_1_ta_loop = beva_xi.bem_iteratorGet_0();
while (true)
/* Line: 386*/ {
bevt_6_ta_ph = bevt_1_ta_loop.bemd_0(-221472220);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 386*/ {
bevl_c = bevt_1_ta_loop.bemd_0(571416905);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 387*/
 else /* Line: 386*/ {
break;
} /* Line: 386*/
} /* Line: 386*/
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_ta_ph, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_start.bem_copy_0();
while (true)
/* Line: 401*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 401*/ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
/* Line: 403*/ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 403*/ {
bevt_3_ta_ph = bem_get_1(bevl_j);
bevt_4_ta_ph = bem_get_1(bevl_c);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(857646196, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 404*/ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 405*/
bevl_j.bevi_int++;
} /* Line: 403*/
 else /* Line: 403*/ {
break;
} /* Line: 403*/
} /* Line: 403*/
bevl_hold = bem_get_1(bevl_i);
bevt_5_ta_ph = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_ta_ph);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 401*/
 else /* Line: 401*/ {
break;
} /* Line: 401*/
} /* Line: 401*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
/* Line: 420*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 420*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 421*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 421*/
 else /* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 421*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_ta_ph = bevl_so.bemd_1(857646196, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 424*/ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 426*/
 else /* Line: 427*/ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 429*/
} /* Line: 424*/
 else /* Line: 421*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 431*/ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 434*/
 else /* Line: 421*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 435*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 438*/
} /* Line: 421*/
} /* Line: 421*/
bevl_i.bevi_int++;
} /* Line: 440*/
 else /* Line: 420*/ {
break;
} /* Line: 420*/
} /* Line: 420*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_mergeSort_2(bevt_1_ta_ph, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_mlen.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 450*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_2_ta_ph = bem_create_1(bevt_3_ta_ph);
return (BEC_2_9_4_ContainerList) bevt_2_ta_ph;
} /* Line: 451*/
 else /* Line: 450*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_mlen.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 452*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_ta_ph, bevt_8_ta_ph);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 455*/
 else /* Line: 456*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_ta_ph);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 464*/
} /* Line: 450*/
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 469*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 470*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 476*/ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 498*/
while (true)
/* Line: 501*/ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 501*/ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 512*/
 else /* Line: 501*/ {
break;
} /* Line: 501*/
} /* Line: 501*/
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 518*/ {
while (true)
/* Line: 519*/ {
bevt_1_ta_ph = beva_val.bemd_0(-221472220);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 519*/ {
bevt_2_ta_ph = beva_val.bemd_0(571416905);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 520*/
 else /* Line: 519*/ {
break;
} /* Line: 519*/
} /* Line: 519*/
} /* Line: 519*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 526*/ {
bevt_1_ta_ph = beva_val.bemd_0(1406439869);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 527*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 532*/ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 543*/
 else /* Line: 544*/ {
bevt_1_ta_ph = bevp_length.bem_copy_0();
bem_put_2(bevt_1_ta_ph, beva_val);
} /* Line: 546*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 551*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_val, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 551*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 551*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 551*/
 else /* Line: 551*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 551*/ {
bem_addAll_1(beva_val);
} /* Line: 552*/
 else /* Line: 553*/ {
bem_addValueWhole_1(beva_val);
} /* Line: 554*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 560*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 560*/ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 562*/ {
bevt_3_ta_ph = beva_value.bemd_1(-1441152686, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 562*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 562*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 562*/
 else /* Line: 562*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 562*/ {
return bevl_i;
} /* Line: 563*/
bevl_i.bevi_int++;
} /* Line: 560*/
 else /* Line: 560*/ {
break;
} /* Line: 560*/
} /* Line: 560*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_find_1(beva_value);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 570*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 571*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_sortedFind_2(beva_value, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 590*/ {
bevt_3_ta_ph = bevl_high.bem_subtract_1(bevl_low);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = bevt_3_ta_ph.bem_divide_1(bevt_4_ta_ph);
bevl_mid = bevt_2_ta_ph.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_ta_ph = beva_value.bemd_1(-1441152686, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 593*/ {
return bevl_mid;
} /* Line: 594*/
 else /* Line: 593*/ {
bevt_6_ta_ph = beva_value.bemd_1(907131409, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 595*/ {
bevl_low = bevl_mid;
} /* Line: 597*/
 else /* Line: 593*/ {
bevt_7_ta_ph = beva_value.bemd_1(857646196, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 598*/ {
bevl_high = bevl_mid;
} /* Line: 600*/
} /* Line: 593*/
} /* Line: 593*/
if (bevl_lastMid == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 603*/ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 603*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 603*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 603*/
 else /* Line: 603*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 603*/ {
if (beva_returnNoMatch.bevi_bool)/* Line: 604*/ {
bevt_11_ta_ph = bem_get_1(bevl_low);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(857646196, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 604*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 604*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 604*/
 else /* Line: 604*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 604*/ {
return bevl_low;
} /* Line: 605*/
return null;
} /* Line: 607*/
bevl_lastMid = bevl_mid;
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_12_ta_ph.bevi_bool)/* Line: 610*/ {
return null;
} /* Line: 611*/
} /* Line: 610*/
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {221, 221, 221, 225, 229, 229, 0, 229, 229, 0, 0, 230, 230, 230, 232, 232, 235, 235, 236, 260, 261, 262, 267, 271, 275, 275, 275, 276, 276, 278, 278, 288, 288, 292, 292, 296, 296, 296, 300, 300, 300, 300, 304, 304, 304, 305, 305, 305, 307, 307, 308, 308, 308, 324, 324, 324, 324, 324, 0, 0, 0, 336, 340, 340, 341, 341, 342, 342, 343, 343, 343, 344, 344, 345, 343, 347, 348, 348, 348, 349, 349, 351, 351, 355, 355, 359, 359, 363, 363, 363, 364, 363, 366, 370, 371, 371, 371, 372, 372, 371, 374, 377, 377, 379, 379, 382, 382, 382, 382, 383, 0, 383, 383, 384, 386, 0, 386, 386, 387, 389, 393, 393, 397, 397, 401, 401, 401, 402, 403, 403, 403, 404, 404, 404, 405, 403, 408, 409, 409, 410, 401, 415, 416, 417, 418, 419, 420, 420, 421, 421, 421, 421, 0, 0, 0, 422, 423, 424, 425, 426, 428, 429, 431, 431, 432, 433, 434, 435, 435, 436, 437, 438, 440, 445, 445, 445, 449, 450, 450, 450, 451, 451, 451, 452, 452, 452, 453, 453, 454, 454, 454, 455, 457, 457, 458, 459, 460, 461, 462, 463, 464, 469, 470, 470, 470, 476, 476, 477, 498, 501, 501, 512, 514, 518, 518, 519, 520, 520, 526, 526, 527, 527, 532, 532, 543, 546, 546, 551, 551, 551, 551, 0, 0, 0, 552, 554, 560, 560, 560, 561, 562, 562, 562, 0, 0, 0, 563, 560, 566, 570, 570, 570, 571, 571, 573, 573, 579, 579, 579, 586, 587, 591, 591, 591, 591, 592, 593, 594, 595, 597, 598, 600, 603, 603, 603, 603, 0, 0, 0, 604, 604, 0, 0, 0, 605, 607, 609, 610, 611, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 42, 46, 57, 62, 63, 66, 71, 72, 75, 79, 80, 81, 83, 88, 89, 94, 95, 100, 101, 102, 106, 109, 117, 118, 123, 124, 125, 127, 128, 138, 139, 143, 144, 150, 151, 152, 158, 159, 160, 161, 171, 172, 177, 178, 179, 180, 182, 187, 188, 189, 190, 202, 203, 208, 209, 214, 215, 218, 222, 228, 243, 248, 249, 250, 251, 252, 253, 256, 261, 262, 263, 264, 265, 271, 272, 273, 274, 275, 276, 278, 279, 283, 284, 288, 289, 294, 297, 302, 303, 304, 310, 318, 319, 322, 327, 328, 329, 330, 336, 340, 341, 345, 346, 358, 359, 360, 361, 362, 362, 365, 367, 368, 374, 374, 377, 379, 380, 386, 390, 391, 395, 396, 410, 413, 418, 419, 420, 423, 428, 429, 430, 431, 433, 435, 441, 442, 443, 444, 445, 468, 469, 470, 471, 472, 475, 480, 481, 486, 487, 492, 493, 496, 500, 503, 504, 505, 507, 508, 511, 512, 516, 521, 522, 523, 524, 527, 532, 533, 534, 535, 539, 550, 551, 552, 572, 573, 574, 579, 580, 581, 582, 585, 586, 591, 592, 593, 594, 595, 596, 597, 600, 601, 602, 603, 604, 605, 606, 607, 608, 616, 618, 619, 620, 628, 633, 634, 637, 641, 646, 649, 655, 662, 667, 670, 672, 673, 685, 690, 691, 692, 699, 704, 707, 710, 711, 720, 725, 726, 727, 729, 732, 736, 739, 742, 753, 756, 761, 762, 763, 768, 769, 771, 774, 778, 781, 783, 789, 796, 797, 802, 803, 804, 806, 807, 812, 813, 814, 835, 836, 839, 840, 841, 842, 843, 844, 846, 849, 851, 854, 856, 860, 865, 866, 871, 872, 875, 879, 883, 884, 886, 889, 893, 896, 898, 900, 901, 903, 908, 911, 914, 917};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 221 40
new 0 221 40
assign 1 221 41
new 0 221 41
new 2 221 42
new 2 225 46
assign 1 229 57
undef 1 229 62
assign 1 0 63
assign 1 229 66
undef 1 229 71
assign 1 0 72
assign 1 0 75
assign 1 230 79
new 0 230 79
assign 1 230 80
new 1 230 80
throw 1 230 81
assign 1 232 83
def 1 232 88
assign 1 235 89
equals 1 235 94
return 1 236 95
assign 1 260 100
copy 0 260 100
assign 1 261 101
copy 0 261 101
assign 1 262 102
new 0 262 102
return 1 267 106
lengthSet 1 271 109
assign 1 275 117
new 0 275 117
assign 1 275 118
equals 1 275 123
assign 1 276 124
new 0 276 124
return 1 276 125
assign 1 278 127
new 0 278 127
return 1 278 128
assign 1 288 138
toString 0 288 138
return 1 288 139
assign 1 292 143
new 1 292 143
new 1 292 144
assign 1 296 150
new 0 296 150
assign 1 296 151
get 1 296 151
return 1 296 152
assign 1 300 158
new 0 300 158
assign 1 300 159
subtract 1 300 159
assign 1 300 160
get 1 300 160
return 1 300 161
assign 1 304 171
new 0 304 171
assign 1 304 172
lesser 1 304 177
assign 1 305 178
new 0 305 178
assign 1 305 179
new 1 305 179
throw 1 305 180
assign 1 307 182
greaterEquals 1 307 187
assign 1 308 188
new 0 308 188
assign 1 308 189
add 1 308 189
lengthSet 1 308 190
assign 1 324 202
new 0 324 202
assign 1 324 203
greaterEquals 1 324 208
assign 1 324 209
lesser 1 324 214
assign 1 0 215
assign 1 0 218
assign 1 0 222
return 1 336 228
assign 1 340 243
lesser 1 340 248
assign 1 341 249
new 0 341 249
assign 1 341 250
subtract 1 341 250
assign 1 342 251
new 0 342 251
assign 1 342 252
add 1 342 252
assign 1 343 253
copy 0 343 253
assign 1 343 256
lesser 1 343 261
assign 1 344 262
get 1 344 262
put 2 344 263
incrementValue 0 345 264
incrementValue 0 343 265
put 2 347 271
assign 1 348 272
new 0 348 272
assign 1 348 273
subtract 1 348 273
lengthSet 1 348 274
assign 1 349 275
new 0 349 275
return 1 349 276
assign 1 351 278
new 0 351 278
return 1 351 279
assign 1 355 283
new 1 355 283
return 1 355 284
assign 1 359 288
new 1 359 288
return 1 359 289
assign 1 363 294
new 0 363 294
assign 1 363 297
lesser 1 363 302
put 2 364 303
incrementValue 0 363 304
assign 1 366 310
new 0 366 310
assign 1 370 318
create 0 370 318
assign 1 371 319
new 0 371 319
assign 1 371 322
lesser 1 371 327
assign 1 372 328
get 1 372 328
put 2 372 329
incrementValue 0 371 330
return 1 374 336
assign 1 377 340
new 1 377 340
return 1 377 341
assign 1 379 345
new 1 379 345
return 1 379 346
assign 1 382 358
new 0 382 358
assign 1 382 359
lengthGet 0 382 359
assign 1 382 360
add 1 382 360
assign 1 382 361
new 2 382 361
assign 1 383 362
iteratorGet 0 0 362
assign 1 383 365
hasNextGet 0 383 365
assign 1 383 367
nextGet 0 383 367
addValueWhole 1 384 368
assign 1 386 374
iteratorGet 0 0 374
assign 1 386 377
hasNextGet 0 386 377
assign 1 386 379
nextGet 0 386 379
addValueWhole 1 387 380
return 1 389 386
assign 1 393 390
mergeSort 0 393 390
return 1 393 391
assign 1 397 395
new 0 397 395
sortValue 2 397 396
assign 1 401 410
copy 0 401 410
assign 1 401 413
lesser 1 401 418
assign 1 402 419
copy 0 402 419
assign 1 403 420
copy 0 403 420
assign 1 403 423
lesser 1 403 428
assign 1 404 429
get 1 404 429
assign 1 404 430
get 1 404 430
assign 1 404 431
lesser 1 404 431
assign 1 405 433
copy 0 405 433
incrementValue 0 403 435
assign 1 408 441
get 1 408 441
assign 1 409 442
get 1 409 442
put 2 409 443
put 2 410 444
incrementValue 0 401 445
assign 1 415 468
new 0 415 468
assign 1 416 469
new 0 416 469
assign 1 417 470
new 0 417 470
assign 1 418 471
lengthGet 0 418 471
assign 1 419 472
lengthGet 0 419 472
assign 1 420 475
lesser 1 420 480
assign 1 421 481
lesser 1 421 486
assign 1 421 487
lesser 1 421 492
assign 1 0 493
assign 1 0 496
assign 1 0 500
assign 1 422 503
get 1 422 503
assign 1 423 504
get 1 423 504
assign 1 424 505
lesser 1 424 505
incrementValue 0 425 507
put 2 426 508
incrementValue 0 428 511
put 2 429 512
assign 1 431 516
lesser 1 431 521
assign 1 432 522
get 1 432 522
incrementValue 0 433 523
put 2 434 524
assign 1 435 527
lesser 1 435 532
assign 1 436 533
get 1 436 533
incrementValue 0 437 534
put 2 438 535
incrementValue 0 440 539
assign 1 445 550
new 0 445 550
assign 1 445 551
mergeSort 2 445 551
return 1 445 552
assign 1 449 572
subtract 1 449 572
assign 1 450 573
new 0 450 573
assign 1 450 574
equals 1 450 579
assign 1 451 580
new 0 451 580
assign 1 451 581
create 1 451 581
return 1 451 582
assign 1 452 585
new 0 452 585
assign 1 452 586
equals 1 452 591
assign 1 453 592
new 0 453 592
assign 1 453 593
create 1 453 593
assign 1 454 594
new 0 454 594
assign 1 454 595
get 1 454 595
put 2 454 596
return 1 455 597
assign 1 457 600
new 0 457 600
assign 1 457 601
divide 1 457 601
assign 1 458 602
subtract 1 458 602
assign 1 459 603
add 1 459 603
assign 1 460 604
mergeSort 2 460 604
assign 1 461 605
mergeSort 2 461 605
assign 1 462 606
create 1 462 606
mergeIn 2 463 607
return 1 464 608
assign 1 469 616
new 0 469 616
assign 1 470 618
new 0 470 618
assign 1 470 619
new 1 470 619
throw 1 470 620
assign 1 476 628
greater 1 476 633
assign 1 477 634
multiply 1 477 634
assign 1 498 637
assign 1 501 641
lesser 1 501 646
incrementValue 0 512 649
setValue 1 514 655
assign 1 518 662
def 1 518 667
assign 1 519 670
hasNextGet 0 519 670
assign 1 520 672
nextGet 0 520 672
addValueWhole 1 520 673
assign 1 526 685
def 1 526 690
assign 1 527 691
iteratorGet 0 527 691
iterateAdd 1 527 692
assign 1 532 699
lesser 1 532 704
incrementValue 0 543 707
assign 1 546 710
copy 0 546 710
put 2 546 711
assign 1 551 720
def 1 551 725
assign 1 551 726
new 0 551 726
assign 1 551 727
sameType 2 551 727
assign 1 0 729
assign 1 0 732
assign 1 0 736
addAll 1 552 739
addValueWhole 1 554 742
assign 1 560 753
new 0 560 753
assign 1 560 756
lesser 1 560 761
assign 1 561 762
get 1 561 762
assign 1 562 763
def 1 562 768
assign 1 562 769
equals 1 562 769
assign 1 0 771
assign 1 0 774
assign 1 0 778
return 1 563 781
incrementValue 0 560 783
return 1 566 789
assign 1 570 796
find 1 570 796
assign 1 570 797
def 1 570 802
assign 1 571 803
new 0 571 803
return 1 571 804
assign 1 573 806
new 0 573 806
return 1 573 807
assign 1 579 812
new 0 579 812
assign 1 579 813
sortedFind 2 579 813
return 1 579 814
assign 1 586 835
assign 1 587 836
new 0 587 836
assign 1 591 839
subtract 1 591 839
assign 1 591 840
new 0 591 840
assign 1 591 841
divide 1 591 841
assign 1 591 842
add 1 591 842
assign 1 592 843
get 1 592 843
assign 1 593 844
equals 1 593 844
return 1 594 846
assign 1 595 849
greater 1 595 849
assign 1 597 851
assign 1 598 854
lesser 1 598 854
assign 1 600 856
assign 1 603 860
def 1 603 865
assign 1 603 866
equals 1 603 871
assign 1 0 872
assign 1 0 875
assign 1 0 879
assign 1 604 883
get 1 604 883
assign 1 604 884
lesser 1 604 884
assign 1 0 886
assign 1 0 889
assign 1 0 893
return 1 605 896
return 1 607 898
assign 1 609 900
assign 1 610 901
new 0 610 901
return 1 611 903
return 1 0 908
return 1 0 911
return 1 0 914
assign 1 0 917
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -507985549: return bem_new_0();
case 225823729: return bem_multiplierGet_0();
case -334139513: return bem_toString_0();
case -582936884: return bem_copy_0();
case -2001842977: return bem_anyrayGet_0();
case 1406439869: return bem_iteratorGet_0();
case 449507276: return bem_lastGet_0();
case -1349505949: return bem_sizeGet_0();
case -1277691905: return bem_create_0();
case 323586228: return bem_hashGet_0();
case -1409492948: return bem_sort_0();
case 1986831490: return bem_mergeSort_0();
case 533535769: return bem_isEmptyGet_0();
case -1182295625: return bem_clear_0();
case -281147384: return bem_lengthGet_0();
case 1589900128: return bem_capacityGet_0();
case 605689976: return bem_anyraySet_0();
case 1630763936: return bem_sortValue_0();
case -1756922540: return bem_firstGet_0();
case -1904974225: return bem_print_0();
case 78791175: return bem_arrayIteratorGet_0();
case -1109080542: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1958108314: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2083304692: return bem_copyTo_1(bevd_0);
case 536875010: return bem_addValue_1(bevd_0);
case 233653317: return bem_addValueWhole_1(bevd_0);
case 1685392883: return bem_sortedFind_1(bevd_0);
case -1822803485: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -900715304: return bem_notEquals_1(bevd_0);
case 1269907477: return bem_addAll_1(bevd_0);
case 53421766: return bem_find_1(bevd_0);
case -1441152686: return bem_equals_1(bevd_0);
case -2049829498: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -1497768755: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1286235874: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1564500571: return bem_def_1(bevd_0);
case -1716200248: return bem_iterateAdd_1(bevd_0);
case 1099146002: return bem_sizeSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1894221943: return bem_undef_1(bevd_0);
case -1412823423: return bem_has_1(bevd_0);
case 866108504: return bem_multiplierSet_1(bevd_0);
case -1571602101: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -259329005: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 796824038: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1506086904: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 894840986: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -92604267: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1170875190: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -506946318: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1280428261: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2064104272: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1092244912: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1171288796: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -191370959: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
