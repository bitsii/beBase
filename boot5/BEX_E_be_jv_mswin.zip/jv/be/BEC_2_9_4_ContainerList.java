package be;
/* IO:File: source/base/List.be */
public final class BEC_2_9_4_ContainerList extends BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
public static BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_4_ContainerList bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(16));
bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_leni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
if (beva_capi == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 221*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 221*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 222*/
if (bevp_length == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 224*/ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 227*/ {
return this;
} /* Line: 228*/
} /* Line: 227*/

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = (new BEC_2_4_3_MathInt(2));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sizeSet_1(BEC_2_4_3_MathInt beva_val) throws Throwable {
bem_lengthSet_1(beva_val);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 268*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_length.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevp_length.bem_subtract_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_3_ta_ph = (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 297*/
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 299*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_posi.bem_add_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
} /* Line: 300*/

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 316*/ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 316*/
 else /* Line: 316*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 316*/ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 322*/
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_fl = bevp_length.bem_subtract_1(bevt_1_ta_ph);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_j = beva_pos.bem_add_1(bevt_2_ta_ph);
bevl_i = beva_pos.bem_copy_0();
while (true)
/* Line: 335*/ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 335*/ {
bevt_4_ta_ph = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 335*/
 else /* Line: 335*/ {
break;
} /* Line: 335*/
} /* Line: 335*/
bem_put_2(bevl_fl, null);
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevp_length.bem_subtract_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 341*/
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 355*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 355*/ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 355*/
 else /* Line: 355*/ {
break;
} /* Line: 355*/
} /* Line: 355*/
bevp_length = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_copy_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_n = bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 363*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 363*/ {
bevt_1_ta_ph = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_ta_ph);
bevl_i.bevi_int++;
} /* Line: 363*/
 else /* Line: 363*/ {
break;
} /* Line: 363*/
} /* Line: 363*/
return (BEC_2_9_4_ContainerList) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_create_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) throws Throwable {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = beva_xi.bem_lengthGet_0();
bevt_3_ta_ph = bevp_length.bem_add_1(bevt_4_ta_ph);
bevl_yi = (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_loop = bem_iteratorGet_0();
while (true)
/* Line: 375*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(1754712773);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 375*/ {
bevl_c = bevt_0_ta_loop.bemd_0(-1352571190);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 376*/
 else /* Line: 375*/ {
break;
} /* Line: 375*/
} /* Line: 375*/
bevt_1_ta_loop = beva_xi.bem_iteratorGet_0();
while (true)
/* Line: 378*/ {
bevt_6_ta_ph = bevt_1_ta_loop.bemd_0(1754712773);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 378*/ {
bevl_c = bevt_1_ta_loop.bemd_0(-1352571190);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 379*/
 else /* Line: 378*/ {
break;
} /* Line: 378*/
} /* Line: 378*/
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_ta_ph, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_start.bem_copy_0();
while (true)
/* Line: 393*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 393*/ {
bevl_c = bevl_i.bem_copy_0();
bevl_j = bevl_i.bem_copy_0();
while (true)
/* Line: 395*/ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 395*/ {
bevt_3_ta_ph = bem_get_1(bevl_j);
bevt_4_ta_ph = bem_get_1(bevl_c);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(1983593963, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 396*/ {
bevl_c = bevl_j.bem_copy_0();
} /* Line: 397*/
bevl_j.bevi_int++;
} /* Line: 395*/
 else /* Line: 395*/ {
break;
} /* Line: 395*/
} /* Line: 395*/
bevl_hold = bem_get_1(bevl_i);
bevt_5_ta_ph = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_ta_ph);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 393*/
 else /* Line: 393*/ {
break;
} /* Line: 393*/
} /* Line: 393*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
/* Line: 412*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 412*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 413*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 413*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 413*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 413*/
 else /* Line: 413*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 413*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_ta_ph = bevl_so.bemd_1(1983593963, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 416*/ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 418*/
 else /* Line: 419*/ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 421*/
} /* Line: 416*/
 else /* Line: 413*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 423*/ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 426*/
 else /* Line: 413*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 427*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 430*/
} /* Line: 413*/
} /* Line: 413*/
bevl_i.bevi_int++;
} /* Line: 432*/
 else /* Line: 412*/ {
break;
} /* Line: 412*/
} /* Line: 412*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() throws Throwable {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_mergeSort_2(bevt_1_ta_ph, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_mlen.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 442*/ {
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_2_ta_ph = bem_create_1(bevt_3_ta_ph);
return (BEC_2_9_4_ContainerList) bevt_2_ta_ph;
} /* Line: 443*/
 else /* Line: 442*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevl_mlen.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 444*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_ta_ph, bevt_8_ta_ph);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 447*/
 else /* Line: 448*/ {
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_ta_ph);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 456*/
} /* Line: 442*/
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 461*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 462*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 468*/ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_list = java.util.Arrays.copyOf(this.bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 490*/
while (true)
/* Line: 493*/ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 493*/ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 504*/
 else /* Line: 493*/ {
break;
} /* Line: 493*/
} /* Line: 493*/
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 510*/ {
while (true)
/* Line: 511*/ {
bevt_1_ta_ph = beva_val.bemd_0(1754712773);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 511*/ {
bevt_2_ta_ph = beva_val.bemd_0(-1352571190);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 512*/
 else /* Line: 511*/ {
break;
} /* Line: 511*/
} /* Line: 511*/
} /* Line: 511*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 518*/ {
bevt_1_ta_ph = beva_val.bemd_0(-1003281216);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 519*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 524*/ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 535*/
 else /* Line: 536*/ {
bevt_1_ta_ph = bevp_length.bem_copy_0();
bem_put_2(bevt_1_ta_ph, beva_val);
} /* Line: 538*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 543*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_val, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 543*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 543*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 543*/
 else /* Line: 543*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 543*/ {
bem_addAll_1(beva_val);
} /* Line: 544*/
 else /* Line: 545*/ {
bem_addValueWhole_1(beva_val);
} /* Line: 546*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 552*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 552*/ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 554*/ {
bevt_3_ta_ph = beva_value.bemd_1(301931194, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 554*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 554*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 554*/
 else /* Line: 554*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 554*/ {
return bevl_i;
} /* Line: 555*/
bevl_i.bevi_int++;
} /* Line: 552*/
 else /* Line: 552*/ {
break;
} /* Line: 552*/
} /* Line: 552*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_find_1(beva_value);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 562*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 563*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_sortedFind_2(beva_value, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 582*/ {
bevt_3_ta_ph = bevl_high.bem_subtract_1(bevl_low);
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = bevt_3_ta_ph.bem_divide_1(bevt_4_ta_ph);
bevl_mid = bevt_2_ta_ph.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_ta_ph = beva_value.bemd_1(301931194, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 585*/ {
return bevl_mid;
} /* Line: 586*/
 else /* Line: 585*/ {
bevt_6_ta_ph = beva_value.bemd_1(1095851085, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 587*/ {
bevl_low = bevl_mid;
} /* Line: 589*/
 else /* Line: 585*/ {
bevt_7_ta_ph = beva_value.bemd_1(1983593963, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 590*/ {
bevl_high = bevl_mid;
} /* Line: 592*/
} /* Line: 585*/
} /* Line: 585*/
if (bevl_lastMid == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 595*/ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 595*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 595*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 595*/
 else /* Line: 595*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 595*/ {
if (beva_returnNoMatch.bevi_bool)/* Line: 596*/ {
bevt_11_ta_ph = bem_get_1(bevl_low);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(1983593963, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 596*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 596*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 596*/
 else /* Line: 596*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 596*/ {
return bevl_low;
} /* Line: 597*/
return null;
} /* Line: 599*/
bevl_lastMid = bevl_mid;
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
if (bevt_12_ta_ph.bevi_bool)/* Line: 602*/ {
return null;
} /* Line: 603*/
} /* Line: 602*/
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {213, 213, 213, 217, 221, 221, 0, 221, 221, 0, 0, 222, 222, 222, 224, 224, 227, 227, 228, 252, 253, 254, 259, 263, 267, 267, 267, 268, 268, 270, 270, 280, 280, 284, 284, 288, 288, 288, 292, 292, 292, 292, 296, 296, 296, 297, 297, 297, 299, 299, 300, 300, 300, 316, 316, 316, 316, 316, 0, 0, 0, 328, 332, 332, 333, 333, 334, 334, 335, 335, 335, 336, 336, 337, 335, 339, 340, 340, 340, 341, 341, 343, 343, 347, 347, 351, 351, 355, 355, 355, 356, 355, 358, 362, 363, 363, 363, 364, 364, 363, 366, 369, 369, 371, 371, 374, 374, 374, 374, 375, 0, 375, 375, 376, 378, 0, 378, 378, 379, 381, 385, 385, 389, 389, 393, 393, 393, 394, 395, 395, 395, 396, 396, 396, 397, 395, 400, 401, 401, 402, 393, 407, 408, 409, 410, 411, 412, 412, 413, 413, 413, 413, 0, 0, 0, 414, 415, 416, 417, 418, 420, 421, 423, 423, 424, 425, 426, 427, 427, 428, 429, 430, 432, 437, 437, 437, 441, 442, 442, 442, 443, 443, 443, 444, 444, 444, 445, 445, 446, 446, 446, 447, 449, 449, 450, 451, 452, 453, 454, 455, 456, 461, 462, 462, 462, 468, 468, 469, 490, 493, 493, 504, 506, 510, 510, 511, 512, 512, 518, 518, 519, 519, 524, 524, 535, 538, 538, 543, 543, 543, 543, 0, 0, 0, 544, 546, 552, 552, 552, 553, 554, 554, 554, 0, 0, 0, 555, 552, 558, 562, 562, 562, 563, 563, 565, 565, 571, 571, 571, 578, 579, 583, 583, 583, 583, 584, 585, 586, 587, 589, 590, 592, 595, 595, 595, 595, 0, 0, 0, 596, 596, 0, 0, 0, 597, 599, 601, 602, 603, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 42, 46, 57, 62, 63, 66, 71, 72, 75, 79, 80, 81, 83, 88, 89, 94, 95, 100, 101, 102, 106, 109, 117, 118, 123, 124, 125, 127, 128, 138, 139, 143, 144, 150, 151, 152, 158, 159, 160, 161, 171, 172, 177, 178, 179, 180, 182, 187, 188, 189, 190, 202, 203, 208, 209, 214, 215, 218, 222, 228, 243, 248, 249, 250, 251, 252, 253, 256, 261, 262, 263, 264, 265, 271, 272, 273, 274, 275, 276, 278, 279, 283, 284, 288, 289, 294, 297, 302, 303, 304, 310, 318, 319, 322, 327, 328, 329, 330, 336, 340, 341, 345, 346, 358, 359, 360, 361, 362, 362, 365, 367, 368, 374, 374, 377, 379, 380, 386, 390, 391, 395, 396, 410, 413, 418, 419, 420, 423, 428, 429, 430, 431, 433, 435, 441, 442, 443, 444, 445, 468, 469, 470, 471, 472, 475, 480, 481, 486, 487, 492, 493, 496, 500, 503, 504, 505, 507, 508, 511, 512, 516, 521, 522, 523, 524, 527, 532, 533, 534, 535, 539, 550, 551, 552, 572, 573, 574, 579, 580, 581, 582, 585, 586, 591, 592, 593, 594, 595, 596, 597, 600, 601, 602, 603, 604, 605, 606, 607, 608, 616, 618, 619, 620, 628, 633, 634, 637, 641, 646, 649, 655, 662, 667, 670, 672, 673, 685, 690, 691, 692, 699, 704, 707, 710, 711, 720, 725, 726, 727, 729, 732, 736, 739, 742, 753, 756, 761, 762, 763, 768, 769, 771, 774, 778, 781, 783, 789, 796, 797, 802, 803, 804, 806, 807, 812, 813, 814, 835, 836, 839, 840, 841, 842, 843, 844, 846, 849, 851, 854, 856, 860, 865, 866, 871, 872, 875, 879, 883, 884, 886, 889, 893, 896, 898, 900, 901, 903, 908, 911, 914, 917};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 213 40
new 0 213 40
assign 1 213 41
new 0 213 41
new 2 213 42
new 2 217 46
assign 1 221 57
undef 1 221 62
assign 1 0 63
assign 1 221 66
undef 1 221 71
assign 1 0 72
assign 1 0 75
assign 1 222 79
new 0 222 79
assign 1 222 80
new 1 222 80
throw 1 222 81
assign 1 224 83
def 1 224 88
assign 1 227 89
equals 1 227 94
return 1 228 95
assign 1 252 100
copy 0 252 100
assign 1 253 101
copy 0 253 101
assign 1 254 102
new 0 254 102
return 1 259 106
lengthSet 1 263 109
assign 1 267 117
new 0 267 117
assign 1 267 118
equals 1 267 123
assign 1 268 124
new 0 268 124
return 1 268 125
assign 1 270 127
new 0 270 127
return 1 270 128
assign 1 280 138
toString 0 280 138
return 1 280 139
assign 1 284 143
new 1 284 143
new 1 284 144
assign 1 288 150
new 0 288 150
assign 1 288 151
get 1 288 151
return 1 288 152
assign 1 292 158
new 0 292 158
assign 1 292 159
subtract 1 292 159
assign 1 292 160
get 1 292 160
return 1 292 161
assign 1 296 171
new 0 296 171
assign 1 296 172
lesser 1 296 177
assign 1 297 178
new 0 297 178
assign 1 297 179
new 1 297 179
throw 1 297 180
assign 1 299 182
greaterEquals 1 299 187
assign 1 300 188
new 0 300 188
assign 1 300 189
add 1 300 189
lengthSet 1 300 190
assign 1 316 202
new 0 316 202
assign 1 316 203
greaterEquals 1 316 208
assign 1 316 209
lesser 1 316 214
assign 1 0 215
assign 1 0 218
assign 1 0 222
return 1 328 228
assign 1 332 243
lesser 1 332 248
assign 1 333 249
new 0 333 249
assign 1 333 250
subtract 1 333 250
assign 1 334 251
new 0 334 251
assign 1 334 252
add 1 334 252
assign 1 335 253
copy 0 335 253
assign 1 335 256
lesser 1 335 261
assign 1 336 262
get 1 336 262
put 2 336 263
incrementValue 0 337 264
incrementValue 0 335 265
put 2 339 271
assign 1 340 272
new 0 340 272
assign 1 340 273
subtract 1 340 273
lengthSet 1 340 274
assign 1 341 275
new 0 341 275
return 1 341 276
assign 1 343 278
new 0 343 278
return 1 343 279
assign 1 347 283
new 1 347 283
return 1 347 284
assign 1 351 288
new 1 351 288
return 1 351 289
assign 1 355 294
new 0 355 294
assign 1 355 297
lesser 1 355 302
put 2 356 303
incrementValue 0 355 304
assign 1 358 310
new 0 358 310
assign 1 362 318
create 0 362 318
assign 1 363 319
new 0 363 319
assign 1 363 322
lesser 1 363 327
assign 1 364 328
get 1 364 328
put 2 364 329
incrementValue 0 363 330
return 1 366 336
assign 1 369 340
new 1 369 340
return 1 369 341
assign 1 371 345
new 1 371 345
return 1 371 346
assign 1 374 358
new 0 374 358
assign 1 374 359
lengthGet 0 374 359
assign 1 374 360
add 1 374 360
assign 1 374 361
new 2 374 361
assign 1 375 362
iteratorGet 0 0 362
assign 1 375 365
hasNextGet 0 375 365
assign 1 375 367
nextGet 0 375 367
addValueWhole 1 376 368
assign 1 378 374
iteratorGet 0 0 374
assign 1 378 377
hasNextGet 0 378 377
assign 1 378 379
nextGet 0 378 379
addValueWhole 1 379 380
return 1 381 386
assign 1 385 390
mergeSort 0 385 390
return 1 385 391
assign 1 389 395
new 0 389 395
sortValue 2 389 396
assign 1 393 410
copy 0 393 410
assign 1 393 413
lesser 1 393 418
assign 1 394 419
copy 0 394 419
assign 1 395 420
copy 0 395 420
assign 1 395 423
lesser 1 395 428
assign 1 396 429
get 1 396 429
assign 1 396 430
get 1 396 430
assign 1 396 431
lesser 1 396 431
assign 1 397 433
copy 0 397 433
incrementValue 0 395 435
assign 1 400 441
get 1 400 441
assign 1 401 442
get 1 401 442
put 2 401 443
put 2 402 444
incrementValue 0 393 445
assign 1 407 468
new 0 407 468
assign 1 408 469
new 0 408 469
assign 1 409 470
new 0 409 470
assign 1 410 471
lengthGet 0 410 471
assign 1 411 472
lengthGet 0 411 472
assign 1 412 475
lesser 1 412 480
assign 1 413 481
lesser 1 413 486
assign 1 413 487
lesser 1 413 492
assign 1 0 493
assign 1 0 496
assign 1 0 500
assign 1 414 503
get 1 414 503
assign 1 415 504
get 1 415 504
assign 1 416 505
lesser 1 416 505
incrementValue 0 417 507
put 2 418 508
incrementValue 0 420 511
put 2 421 512
assign 1 423 516
lesser 1 423 521
assign 1 424 522
get 1 424 522
incrementValue 0 425 523
put 2 426 524
assign 1 427 527
lesser 1 427 532
assign 1 428 533
get 1 428 533
incrementValue 0 429 534
put 2 430 535
incrementValue 0 432 539
assign 1 437 550
new 0 437 550
assign 1 437 551
mergeSort 2 437 551
return 1 437 552
assign 1 441 572
subtract 1 441 572
assign 1 442 573
new 0 442 573
assign 1 442 574
equals 1 442 579
assign 1 443 580
new 0 443 580
assign 1 443 581
create 1 443 581
return 1 443 582
assign 1 444 585
new 0 444 585
assign 1 444 586
equals 1 444 591
assign 1 445 592
new 0 445 592
assign 1 445 593
create 1 445 593
assign 1 446 594
new 0 446 594
assign 1 446 595
get 1 446 595
put 2 446 596
return 1 447 597
assign 1 449 600
new 0 449 600
assign 1 449 601
divide 1 449 601
assign 1 450 602
subtract 1 450 602
assign 1 451 603
add 1 451 603
assign 1 452 604
mergeSort 2 452 604
assign 1 453 605
mergeSort 2 453 605
assign 1 454 606
create 1 454 606
mergeIn 2 455 607
return 1 456 608
assign 1 461 616
new 0 461 616
assign 1 462 618
new 0 462 618
assign 1 462 619
new 1 462 619
throw 1 462 620
assign 1 468 628
greater 1 468 633
assign 1 469 634
multiply 1 469 634
assign 1 490 637
assign 1 493 641
lesser 1 493 646
incrementValue 0 504 649
setValue 1 506 655
assign 1 510 662
def 1 510 667
assign 1 511 670
hasNextGet 0 511 670
assign 1 512 672
nextGet 0 512 672
addValueWhole 1 512 673
assign 1 518 685
def 1 518 690
assign 1 519 691
iteratorGet 0 519 691
iterateAdd 1 519 692
assign 1 524 699
lesser 1 524 704
incrementValue 0 535 707
assign 1 538 710
copy 0 538 710
put 2 538 711
assign 1 543 720
def 1 543 725
assign 1 543 726
new 0 543 726
assign 1 543 727
sameType 2 543 727
assign 1 0 729
assign 1 0 732
assign 1 0 736
addAll 1 544 739
addValueWhole 1 546 742
assign 1 552 753
new 0 552 753
assign 1 552 756
lesser 1 552 761
assign 1 553 762
get 1 553 762
assign 1 554 763
def 1 554 768
assign 1 554 769
equals 1 554 769
assign 1 0 771
assign 1 0 774
assign 1 0 778
return 1 555 781
incrementValue 0 552 783
return 1 558 789
assign 1 562 796
find 1 562 796
assign 1 562 797
def 1 562 802
assign 1 563 803
new 0 563 803
return 1 563 804
assign 1 565 806
new 0 565 806
return 1 565 807
assign 1 571 812
new 0 571 812
assign 1 571 813
sortedFind 2 571 813
return 1 571 814
assign 1 578 835
assign 1 579 836
new 0 579 836
assign 1 583 839
subtract 1 583 839
assign 1 583 840
new 0 583 840
assign 1 583 841
divide 1 583 841
assign 1 583 842
add 1 583 842
assign 1 584 843
get 1 584 843
assign 1 585 844
equals 1 585 844
return 1 586 846
assign 1 587 849
greater 1 587 849
assign 1 589 851
assign 1 590 854
lesser 1 590 854
assign 1 592 856
assign 1 595 860
def 1 595 865
assign 1 595 866
equals 1 595 871
assign 1 0 872
assign 1 0 875
assign 1 0 879
assign 1 596 883
get 1 596 883
assign 1 596 884
lesser 1 596 884
assign 1 0 886
assign 1 0 889
assign 1 0 893
return 1 597 896
return 1 599 898
assign 1 601 900
assign 1 602 901
new 0 602 901
return 1 603 903
return 1 0 908
return 1 0 911
return 1 0 914
assign 1 0 917
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 238723039: return bem_mergeSort_0();
case -375591917: return bem_capacityGet_0();
case -292196644: return bem_lengthGet_0();
case 421264883: return bem_sort_0();
case 739878924: return bem_multiplierGet_0();
case -123880973: return bem_copy_0();
case -1983878186: return bem_new_0();
case 646757854: return bem_lastGet_0();
case 1438192594: return bem_hashGet_0();
case 220029167: return bem_anyrayGet_0();
case 621334352: return bem_print_0();
case -967930653: return bem_clear_0();
case -357206054: return bem_anyraySet_0();
case -1875512109: return bem_sortValue_0();
case -511716151: return bem_arrayIteratorGet_0();
case 767219130: return bem_serializeToString_0();
case 777000236: return bem_sizeGet_0();
case 1435982177: return bem_isEmptyGet_0();
case -1003281216: return bem_iteratorGet_0();
case -443343999: return bem_create_0();
case 1844906171: return bem_firstGet_0();
case 13717429: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -731871147: return bem_def_1(bevd_0);
case -1267331077: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1945196219: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1355165899: return bem_copyTo_1(bevd_0);
case 1246851524: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -1768460495: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1706161840: return bem_sizeSet_1((BEC_2_4_3_MathInt) bevd_0);
case 311290374: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case 301931194: return bem_equals_1(bevd_0);
case 1632076970: return bem_multiplierSet_1(bevd_0);
case 1481246761: return bem_sortedFind_1(bevd_0);
case 192977356: return bem_find_1(bevd_0);
case -623457359: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 2121815307: return bem_addValueWhole_1(bevd_0);
case -1950487742: return bem_iterateAdd_1(bevd_0);
case 103202225: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -1183629256: return bem_has_1(bevd_0);
case 667247388: return bem_addValue_1(bevd_0);
case -1469201190: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 311997717: return bem_addAll_1(bevd_0);
case -182879054: return bem_notEquals_1(bevd_0);
case 1713177550: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -433881604: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1378156325: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -671518758: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -347754536: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -876933608: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 258338321: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1927919346: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1473620469: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1548431016: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1808641530: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_4_ContainerList();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
