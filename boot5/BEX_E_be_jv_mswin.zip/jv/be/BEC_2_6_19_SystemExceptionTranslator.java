package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_19_SystemExceptionTranslator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemExceptionTranslator() { }
private static byte[] becc_BEC_2_6_19_SystemExceptionTranslator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x54,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemExceptionTranslator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_1 = {0x67,0x65,0x74,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_2 = {0x63,0x73};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_3 = {0x6A,0x73};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_4 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_5 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_6 = {0x61,0x74,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_7 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_8 = {0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_9 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_10 = {0x69,0x6E};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_11 = {0x3A};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_12 = {0x6C,0x69,0x6E,0x65,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_13 = {0x28};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_14 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_15 = {0x29};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_16 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_17 = {0x2E};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_18 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_19 = {0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_20 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_21 = {0x42,0x45,0x43,0x5F};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_22 = {0x5F};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_23 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_24 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_25 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_26 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_27 = {0x62,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_28 = {0x6A,0x76};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_29 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_30 = {0x62,0x65,0x6D,0x5F};
public static BEC_2_6_19_SystemExceptionTranslator bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;

public static BET_2_6_19_SystemExceptionTranslator bece_BEC_2_6_19_SystemExceptionTranslator_bevs_type;

public BEC_2_6_19_SystemExceptionTranslator bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemExceptionTranslator bem_translateEmittedException_1(BEC_2_6_9_SystemException beva_tt) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
try /* Line: 1085*/ {
bem_translateEmittedExceptionInner_1(beva_tt);
} /* Line: 1086*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_1_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_6_19_SystemExceptionTranslator_bels_0));
bevt_1_ta_ph.bem_print_0();
if (bevl_e == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1089*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_19_SystemExceptionTranslator_bels_1));
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = bevl_e.bemd_2(-281815906, bevt_4_ta_ph, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 1089*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1089*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1089*/
 else /* Line: 1089*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1089*/ {
bevt_6_ta_ph = bevl_e.bemd_0(-199251519);
bevt_6_ta_ph.bemd_0(636345);
} /* Line: 1090*/
} /* Line: 1089*/
return this;
} /*method end*/
public BEC_2_6_19_SystemExceptionTranslator bem_translateEmittedExceptionInner_1(BEC_2_6_9_SystemException beva_tt) throws Throwable {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_4_ContainerList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_5_4_LogicBool bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_3_MathInt bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_5_4_LogicBool bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_4_3_MathInt bevt_101_ta_ph = null;
BEC_2_4_3_MathInt bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_3_MathInt bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_4_3_MathInt bevt_116_ta_ph = null;
BEC_2_4_3_MathInt bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_3_MathInt bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_4_3_MathInt bevt_121_ta_ph = null;
BEC_2_4_3_MathInt bevt_122_ta_ph = null;
BEC_2_4_3_MathInt bevt_123_ta_ph = null;
BEC_2_4_3_MathInt bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_4_6_TextString bevt_127_ta_ph = null;
BEC_2_4_6_TextString bevt_128_ta_ph = null;
BEC_2_4_6_TextString bevt_129_ta_ph = null;
BEC_2_4_6_TextString bevt_130_ta_ph = null;
BEC_2_5_4_LogicBool bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_4_6_TextString bevt_134_ta_ph = null;
BEC_2_4_3_MathInt bevt_135_ta_ph = null;
BEC_2_4_3_MathInt bevt_136_ta_ph = null;
BEC_2_5_4_LogicBool bevt_137_ta_ph = null;
BEC_2_5_4_LogicBool bevt_138_ta_ph = null;
BEC_2_4_3_MathInt bevt_139_ta_ph = null;
BEC_2_5_4_LogicBool bevt_140_ta_ph = null;
BEC_2_4_6_TextString bevt_141_ta_ph = null;
BEC_2_4_6_TextString bevt_142_ta_ph = null;
BEC_2_4_6_TextString bevt_143_ta_ph = null;
BEC_2_4_6_TextString bevt_144_ta_ph = null;
BEC_2_5_4_LogicBool bevt_145_ta_ph = null;
BEC_2_4_6_TextString bevt_146_ta_ph = null;
BEC_2_4_6_TextString bevt_147_ta_ph = null;
BEC_2_4_6_TextString bevt_148_ta_ph = null;
BEC_2_4_6_TextString bevt_149_ta_ph = null;
BEC_2_4_6_TextString bevt_150_ta_ph = null;
BEC_2_4_6_TextString bevt_151_ta_ph = null;
BEC_2_5_4_LogicBool bevt_152_ta_ph = null;
BEC_2_4_6_TextString bevt_153_ta_ph = null;
BEC_2_5_4_LogicBool bevt_154_ta_ph = null;
BEC_2_4_6_TextString bevt_155_ta_ph = null;
BEC_2_4_6_TextString bevt_156_ta_ph = null;
BEC_2_4_6_TextString bevt_157_ta_ph = null;
BEC_2_5_4_LogicBool bevt_158_ta_ph = null;
BEC_2_9_4_ContainerList bevt_159_ta_ph = null;
BEC_2_5_4_LogicBool bevt_160_ta_ph = null;
BEC_2_4_6_TextString bevt_161_ta_ph = null;
BEC_2_5_4_LogicBool bevt_162_ta_ph = null;
BEC_2_4_6_TextString bevt_163_ta_ph = null;
BEC_2_4_6_TextString bevt_164_ta_ph = null;
BEC_2_9_4_ContainerList bevt_165_ta_ph = null;
BEC_2_6_6_SystemObject bevt_166_ta_ph = null;
BEC_2_4_6_TextString bevt_167_ta_ph = null;
BEC_2_4_6_TextString bevt_168_ta_ph = null;
BEC_2_4_6_TextString bevt_169_ta_ph = null;
BEC_2_4_6_TextString bevt_170_ta_ph = null;
BEC_2_4_6_TextString bevt_171_ta_ph = null;
BEC_2_4_6_TextString bevt_172_ta_ph = null;
BEC_2_4_6_TextString bevt_173_ta_ph = null;
BEC_2_4_6_TextString bevt_174_ta_ph = null;
BEC_2_5_4_LogicBool bevt_175_ta_ph = null;
BEC_2_4_6_TextString bevt_176_ta_ph = null;
bevt_13_ta_ph = beva_tt.bem_translatedGet_0();
if (bevt_13_ta_ph == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 1097*/ {
bevt_14_ta_ph = beva_tt.bem_translatedGet_0();
if (bevt_14_ta_ph.bevi_bool)/* Line: 1097*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1097*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1097*/
 else /* Line: 1097*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1097*/ {
return this;
} /* Line: 1098*/
bevt_16_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_16_ta_ph == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1100*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
beva_tt.bem_vvSet_1(bevt_17_ta_ph);
} /* Line: 1101*/
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
beva_tt.bem_translatedSet_1(bevt_18_ta_ph);
bevt_20_ta_ph = beva_tt.bem_framesTextGet_0();
if (bevt_20_ta_ph == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 1104*/ {
bevt_22_ta_ph = beva_tt.bem_langGet_0();
if (bevt_22_ta_ph == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1104*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1104*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1104*/
 else /* Line: 1104*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 1104*/ {
bevt_24_ta_ph = beva_tt.bem_langGet_0();
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_2));
bevt_23_ta_ph = bevt_24_ta_ph.bem_equals_1(bevt_25_ta_ph);
if (bevt_23_ta_ph.bevi_bool)/* Line: 1104*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1104*/ {
bevt_27_ta_ph = beva_tt.bem_langGet_0();
bevt_28_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_3));
bevt_26_ta_ph = bevt_27_ta_ph.bem_equals_1(bevt_28_ta_ph);
if (bevt_26_ta_ph.bevi_bool)/* Line: 1104*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1104*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1104*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 1104*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1104*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1104*/
 else /* Line: 1104*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 1104*/ {
bevt_29_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_4));
bevl_ltok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_29_ta_ph);
bevt_30_ta_ph = beva_tt.bem_framesTextGet_0();
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevt_30_ta_ph);
bevt_32_ta_ph = beva_tt.bem_langGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_2));
bevt_31_ta_ph = bevt_32_ta_ph.bem_equals_1(bevt_33_ta_ph);
if (bevt_31_ta_ph.bevi_bool)/* Line: 1107*/ {
bevl_isCs = be.BECS_Runtime.boolTrue;
} /* Line: 1108*/
 else /* Line: 1109*/ {
bevl_isCs = be.BECS_Runtime.boolFalse;
} /* Line: 1110*/
bevt_0_ta_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
/* Line: 1112*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 1112*/ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevt_35_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_35_ta_ph.bevi_bool)/* Line: 1113*/ {
bevt_37_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_19_SystemExceptionTranslator_bels_5));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevl_line);
bevt_36_ta_ph.bem_print_0();
} /* Line: 1114*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_19_SystemExceptionTranslator_bels_6));
bevl_start = bevl_line.bem_find_1(bevt_38_ta_ph);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 1119*/ {
bevt_41_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_start.bevi_int >= bevt_41_ta_ph.bevi_int) {
bevt_40_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_40_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_40_ta_ph.bevi_bool)/* Line: 1119*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1119*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1119*/
 else /* Line: 1119*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 1119*/ {
bevt_42_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_42_ta_ph.bevi_bool)/* Line: 1120*/ {
bevt_44_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_19_SystemExceptionTranslator_bels_7));
bevt_43_ta_ph = bevt_44_ta_ph.bem_add_1(bevl_start);
bevt_43_ta_ph.bem_print_0();
} /* Line: 1121*/
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_8));
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_46_ta_ph = bevl_start.bem_add_1(bevt_47_ta_ph);
bevl_end = bevl_line.bem_find_2(bevt_45_ta_ph, bevt_46_ta_ph);
if (bevl_end == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 1124*/ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 1124*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1124*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1124*/
 else /* Line: 1124*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 1124*/ {
bevt_50_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_50_ta_ph.bevi_bool)/* Line: 1125*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_19_SystemExceptionTranslator_bels_9));
bevt_51_ta_ph = bevt_52_ta_ph.bem_add_1(bevl_end);
bevt_51_ta_ph.bem_print_0();
} /* Line: 1126*/
bevt_54_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_53_ta_ph = bevl_start.bem_add_1(bevt_54_ta_ph);
bevl_callPart = bevl_line.bem_substring_2(bevt_53_ta_ph, bevl_end);
if (bevl_isCs.bevi_bool)/* Line: 1130*/ {
bevt_55_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_10));
bevl_start = bevl_line.bem_find_2(bevt_55_ta_ph, bevl_end);
if (bevl_start == null) {
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 1132*/ {
bevt_58_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_57_ta_ph = bevl_start.bem_add_1(bevt_58_ta_ph);
bevl_inPart = bevl_line.bem_substring_1(bevt_57_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_8));
bevt_59_ta_ph = bevl_inPart.bem_ends_1(bevt_60_ta_ph);
if (bevt_59_ta_ph.bevi_bool)/* Line: 1135*/ {
bevt_62_ta_ph = bevl_inPart.bem_sizeGet_0();
bevt_63_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_61_ta_ph = bevt_62_ta_ph.bem_subtract_1(bevt_63_ta_ph);
bevl_inPart.bem_sizeSet_1(bevt_61_ta_ph);
} /* Line: 1136*/
bevt_64_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_64_ta_ph);
if (bevl_pdelim == null) {
bevt_65_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_65_ta_ph.bevi_bool)/* Line: 1140*/ {
bevt_66_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_efile = bevl_inPart.bem_substring_2(bevt_66_ta_ph, bevl_pdelim);
bevt_68_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_67_ta_ph = bevl_pdelim.bem_add_1(bevt_68_ta_ph);
bevl_iv = bevl_inPart.bem_substring_1(bevt_67_ta_ph);
bevt_70_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_19_SystemExceptionTranslator_bels_12));
bevt_69_ta_ph = bevl_iv.bem_begins_1(bevt_70_ta_ph);
if (bevt_69_ta_ph.bevi_bool)/* Line: 1144*/ {
bevt_71_ta_ph = (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_71_ta_ph);
} /* Line: 1145*/
bevt_72_ta_ph = bevl_iv.bem_isInteger_0();
if (bevt_72_ta_ph.bevi_bool)/* Line: 1148*/ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 1149*/
} /* Line: 1148*/
} /* Line: 1140*/
} /* Line: 1132*/
 else /* Line: 1153*/ {
bevt_73_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_13));
bevl_start = bevl_line.bem_find_2(bevt_73_ta_ph, bevl_end);
if (bevl_start == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 1155*/ {
bevt_75_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_75_ta_ph.bevi_bool)/* Line: 1156*/ {
bevt_76_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_19_SystemExceptionTranslator_bels_14));
bevt_76_ta_ph.bem_print_0();
} /* Line: 1157*/
bevt_77_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_15));
bevt_79_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_78_ta_ph = bevl_start.bem_add_1(bevt_79_ta_ph);
bevl_end = bevl_line.bem_find_2(bevt_77_ta_ph, bevt_78_ta_ph);
if (bevl_end == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 1161*/ {
bevt_81_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_81_ta_ph.bevi_bool)/* Line: 1162*/ {
bevt_82_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_6_19_SystemExceptionTranslator_bels_16));
bevt_82_ta_ph.bem_print_0();
} /* Line: 1163*/
bevt_84_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_83_ta_ph = bevl_start.bem_add_1(bevt_84_ta_ph);
bevl_inPart = bevl_line.bem_substring_2(bevt_83_ta_ph, bevl_end);
bevt_85_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_85_ta_ph);
if (bevl_pdelim == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 1168*/ {
bevt_87_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_inPart = bevl_inPart.bem_substring_2(bevt_87_ta_ph, bevl_pdelim);
bevt_88_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_88_ta_ph);
if (bevl_pdelim == null) {
bevt_89_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_89_ta_ph.bevi_bool)/* Line: 1172*/ {
bevt_90_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_efile = bevl_inPart.bem_substring_2(bevt_90_ta_ph, bevl_pdelim);
} /* Line: 1173*/
bevt_92_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_91_ta_ph = bevl_pdelim.bem_add_1(bevt_92_ta_ph);
bevl_iv = bevl_inPart.bem_substring_1(bevt_91_ta_ph);
bevt_93_ta_ph = bevl_iv.bem_isInteger_0();
if (bevt_93_ta_ph.bevi_bool)/* Line: 1177*/ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 1178*/
} /* Line: 1177*/
} /* Line: 1168*/
} /* Line: 1161*/
} /* Line: 1155*/
} /* Line: 1130*/
 else /* Line: 1184*/ {
bevt_94_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_13));
bevt_96_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_95_ta_ph = bevl_start.bem_add_1(bevt_96_ta_ph);
bevl_end = bevl_line.bem_find_2(bevt_94_ta_ph, bevt_95_ta_ph);
if (bevl_end == null) {
bevt_97_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_97_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_97_ta_ph.bevi_bool)/* Line: 1186*/ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_98_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_98_ta_ph.bevi_bool)/* Line: 1186*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1186*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1186*/
 else /* Line: 1186*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 1186*/ {
bevt_100_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_99_ta_ph = bevl_start.bem_add_1(bevt_100_ta_ph);
bevl_callPart = bevl_line.bem_substring_2(bevt_99_ta_ph, bevl_end);
} /* Line: 1187*/
 else /* Line: 1188*/ {
bevt_102_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_101_ta_ph = bevl_start.bem_add_1(bevt_102_ta_ph);
bevl_callPart = bevl_line.bem_substring_1(bevt_101_ta_ph);
} /* Line: 1189*/
} /* Line: 1186*/
if (bevl_callPart == null) {
bevt_103_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_103_ta_ph.bevi_bool)/* Line: 1192*/ {
if (bevl_isCs.bevi_bool)/* Line: 1193*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_17));
bevl_parts = bevl_callPart.bem_split_1(bevt_104_ta_ph);
bevt_105_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_ta_ph);
bevt_106_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_ta_ph);
bevl_klass = bem_extractKlass_1(bevl_klass);
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_108_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_107_ta_ph = bem_getSourceFileName_1(bevt_108_ta_ph);
bevl_fr.bem_fileNameSet_1(bevt_107_ta_ph);
beva_tt.bem_addFrame_1(bevl_fr);
} /* Line: 1206*/
 else /* Line: 1207*/ {
bevt_109_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_109_ta_ph.bevi_bool)/* Line: 1209*/ {
bevt_112_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_19_SystemExceptionTranslator_bels_18));
bevt_111_ta_ph = bevt_112_ta_ph.bem_add_1(bevl_callPart);
bevt_113_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_110_ta_ph = bevt_111_ta_ph.bem_add_1(bevt_113_ta_ph);
bevt_110_ta_ph.bem_print_0();
} /* Line: 1210*/
bevt_114_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_17));
bevl_parts = bevl_callPart.bem_split_1(bevt_114_ta_ph);
bevt_116_ta_ph = bevl_parts.bem_sizeGet_0();
bevt_117_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_116_ta_ph.bevi_int > bevt_117_ta_ph.bevi_int) {
bevt_115_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_115_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_115_ta_ph.bevi_bool)/* Line: 1213*/ {
bevt_119_ta_ph = bevl_parts.bem_sizeGet_0();
bevt_120_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevt_119_ta_ph.bevi_int > bevt_120_ta_ph.bevi_int) {
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 1214*/ {
bevt_121_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_121_ta_ph);
bevt_122_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_122_ta_ph);
} /* Line: 1216*/
 else /* Line: 1217*/ {
bevt_123_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_123_ta_ph);
bevt_124_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_124_ta_ph);
} /* Line: 1219*/
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevt_125_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_125_ta_ph.bevi_bool)/* Line: 1222*/ {
bevt_128_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_19_SystemExceptionTranslator_bels_20));
bevt_127_ta_ph = bevt_128_ta_ph.bem_add_1(bevl_mtd);
bevt_129_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_126_ta_ph = bevt_127_ta_ph.bem_add_1(bevt_129_ta_ph);
bevt_126_ta_ph.bem_print_0();
} /* Line: 1223*/
bevt_130_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_19_SystemExceptionTranslator_bels_21));
bevl_start = bevl_klass.bem_find_1(bevt_130_ta_ph);
if (bevl_start == null) {
bevt_131_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_131_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_131_ta_ph.bevi_bool)/* Line: 1226*/ {
bevt_133_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_start.bevi_int > bevt_133_ta_ph.bevi_int) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 1226*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1226*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1226*/
 else /* Line: 1226*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 1226*/ {
bevt_134_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevt_136_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_135_ta_ph = bevl_start.bem_add_1(bevt_136_ta_ph);
bevl_end = bevl_klass.bem_find_2(bevt_134_ta_ph, bevt_135_ta_ph);
if (bevl_end == null) {
bevt_137_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_137_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_137_ta_ph.bevi_bool)/* Line: 1228*/ {
bevt_139_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_end.bevi_int > bevt_139_ta_ph.bevi_int) {
bevt_138_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_138_ta_ph.bevi_bool)/* Line: 1228*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1228*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1228*/
 else /* Line: 1228*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 1228*/ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
bevt_140_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_140_ta_ph.bevi_bool)/* Line: 1233*/ {
bevt_143_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_19_SystemExceptionTranslator_bels_23));
bevt_142_ta_ph = bevt_143_ta_ph.bem_add_1(bevl_klass);
bevt_144_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_141_ta_ph = bevt_142_ta_ph.bem_add_1(bevt_144_ta_ph);
bevt_141_ta_ph.bem_print_0();
} /* Line: 1234*/
bevl_klass = bem_extractKlass_1(bevl_klass);
bevt_145_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_145_ta_ph.bevi_bool)/* Line: 1237*/ {
bevt_148_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_6_19_SystemExceptionTranslator_bels_24));
bevt_147_ta_ph = bevt_148_ta_ph.bem_add_1(bevl_klass);
bevt_149_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_146_ta_ph = bevt_147_ta_ph.bem_add_1(bevt_149_ta_ph);
bevt_146_ta_ph.bem_print_0();
} /* Line: 1238*/
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_151_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_150_ta_ph = bem_getSourceFileName_1(bevt_151_ta_ph);
bevl_fr.bem_fileNameSet_1(bevt_150_ta_ph);
bevt_152_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_152_ta_ph.bevi_bool)/* Line: 1242*/ {
bevt_153_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_6_19_SystemExceptionTranslator_bels_25));
bevt_153_ta_ph.bem_print_0();
} /* Line: 1243*/
beva_tt.bem_addFrame_1(bevl_fr);
} /* Line: 1245*/
 else /* Line: 1246*/ {
bevt_154_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_154_ta_ph.bevi_bool)/* Line: 1247*/ {
bevt_155_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_6_19_SystemExceptionTranslator_bels_26));
bevt_155_ta_ph.bem_print_0();
} /* Line: 1248*/
} /* Line: 1247*/
} /* Line: 1228*/
} /* Line: 1226*/
} /* Line: 1213*/
} /* Line: 1193*/
} /* Line: 1192*/
} /* Line: 1119*/
 else /* Line: 1112*/ {
break;
} /* Line: 1112*/
} /* Line: 1112*/
bevt_156_ta_ph = beva_tt.bem_langGet_0();
beva_tt.bem_emitLangSet_1(bevt_156_ta_ph);
bevt_157_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_27));
beva_tt.bem_langSet_1(bevt_157_ta_ph);
beva_tt.bem_framesTextSet_1(null);
} /* Line: 1259*/
 else /* Line: 1104*/ {
bevt_159_ta_ph = beva_tt.bem_framesGet_0();
if (bevt_159_ta_ph == null) {
bevt_158_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_158_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_158_ta_ph.bevi_bool)/* Line: 1260*/ {
bevt_161_ta_ph = beva_tt.bem_langGet_0();
if (bevt_161_ta_ph == null) {
bevt_160_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_160_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_160_ta_ph.bevi_bool)/* Line: 1260*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1260*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1260*/
 else /* Line: 1260*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 1260*/ {
bevt_163_ta_ph = beva_tt.bem_langGet_0();
bevt_164_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_28));
bevt_162_ta_ph = bevt_163_ta_ph.bem_equals_1(bevt_164_ta_ph);
if (bevt_162_ta_ph.bevi_bool)/* Line: 1260*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1260*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1260*/
 else /* Line: 1260*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 1260*/ {
bevt_165_ta_ph = beva_tt.bem_framesGet_0();
bevt_1_ta_loop = bevt_165_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 1261*/ {
bevt_166_ta_ph = bevt_1_ta_loop.bemd_0(1757263953);
if (((BEC_2_5_4_LogicBool) bevt_166_ta_ph).bevi_bool)/* Line: 1261*/ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_ta_loop.bemd_0(1982151412);
bevt_168_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_167_ta_ph = bem_extractKlassLib_1(bevt_168_ta_ph);
bevl_fr.bem_klassNameSet_1(bevt_167_ta_ph);
bevt_170_ta_ph = bevl_fr.bem_methodNameGet_0();
bevt_169_ta_ph = bem_extractMethod_1(bevt_170_ta_ph);
bevl_fr.bem_methodNameSet_1(bevt_169_ta_ph);
bevt_172_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_171_ta_ph = bem_getSourceFileName_1(bevt_172_ta_ph);
bevl_fr.bem_fileNameSet_1(bevt_171_ta_ph);
/* Line: 1265*/ {
bevl_fr.bem_extractLine_0();
} /* Line: 1266*/
} /* Line: 1265*/
 else /* Line: 1261*/ {
break;
} /* Line: 1261*/
} /* Line: 1261*/
bevt_173_ta_ph = beva_tt.bem_langGet_0();
beva_tt.bem_emitLangSet_1(bevt_173_ta_ph);
bevt_174_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_27));
beva_tt.bem_langSet_1(bevt_174_ta_ph);
} /* Line: 1270*/
 else /* Line: 1271*/ {
} /* Line: 1271*/
} /* Line: 1104*/
bevt_175_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_175_ta_ph.bevi_bool)/* Line: 1274*/ {
bevt_176_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_19_SystemExceptionTranslator_bels_29));
bevt_176_ta_ph.bem_print_0();
} /* Line: 1275*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
bevl_i = bem_createInstance_2(beva_klassName, bevt_0_ta_ph);
if (bevl_i == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1282*/ {
bevt_2_ta_ph = bevl_i.bemd_0(-593469656);
return (BEC_2_4_6_TextString) bevt_2_ta_ph;
} /* Line: 1284*/
return null;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) throws Throwable {
BEC_2_9_4_ContainerList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_17));
bevl_parts = beva_callPart.bem_split_1(bevt_0_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevl_parts.bem_get_1(bevt_3_ta_ph);
bevt_1_ta_ph = bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_ta_ph );
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
try /* Line: 1298*/ {
bevt_0_ta_ph = bem_extractKlassInner_1(beva_klass);
return bevt_0_ta_ph;
} /* Line: 1299*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 1300*/
return beva_klass;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_9_4_ContainerList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
if (beva_klass == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1307*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1307*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_19_SystemExceptionTranslator_bels_21));
bevt_3_ta_ph = beva_klass.bem_begins_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1307*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1307*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1307*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1307*/ {
return beva_klass;
} /* Line: 1308*/
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_5_ta_ph = beva_klass.bem_substring_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevl_kparts = bevt_5_ta_ph.bem_split_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_kparts.bem_sizeGet_0();
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_kps = bevt_8_ta_ph.bem_subtract_1(bevt_9_ta_ph);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1315*/ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1315*/ {
bevt_11_ta_ph = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevl_sofar.bem_add_1(bevl_len);
bevt_12_ta_ph = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_ta_ph);
bevl_bec.bem_addValue_1(bevt_12_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_15_ta_ph = bevl_i.bem_add_1(bevt_16_ta_ph);
if (bevt_15_ta_ph.bevi_int < bevl_kps.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 1319*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_bec.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 1319*/
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 1315*/
 else /* Line: 1315*/ {
break;
} /* Line: 1315*/
} /* Line: 1315*/
return bevl_bec;
} /*method end*/
public BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) throws Throwable {
BEC_2_9_4_ContainerList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
if (beva_mtd == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1327*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1327*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_19_SystemExceptionTranslator_bels_30));
bevt_3_ta_ph = beva_mtd.bem_begins_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1327*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1327*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1327*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1327*/ {
return beva_mtd;
} /* Line: 1328*/
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_5_ta_ph = beva_mtd.bem_substring_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevl_mparts = bevt_5_ta_ph.bem_split_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_mparts.bem_sizeGet_0();
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_mps = bevt_8_ta_ph.bem_subtract_1(bevt_9_ta_ph);
bevl_bem = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1333*/ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1333*/ {
bevt_11_ta_ph = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_13_ta_ph = bevl_i.bem_add_1(bevt_14_ta_ph);
if (bevt_13_ta_ph.bevi_int < bevl_mps.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 1335*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevl_bem.bem_addValue_1(bevt_15_ta_ph);
} /* Line: 1335*/
bevl_i.bevi_int++;
} /* Line: 1333*/
 else /* Line: 1333*/ {
break;
} /* Line: 1333*/
} /* Line: 1333*/
return bevl_bem;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1086, 1088, 1088, 1089, 1089, 1089, 1089, 1089, 0, 0, 0, 1090, 1090, 1097, 1097, 1097, 1097, 0, 0, 0, 1098, 1100, 1100, 1100, 1101, 1101, 1103, 1103, 1104, 1104, 1104, 1104, 1104, 1104, 0, 0, 0, 1104, 1104, 1104, 0, 1104, 1104, 1104, 0, 0, 0, 0, 0, 1105, 1105, 1106, 1106, 1107, 1107, 1107, 1108, 1110, 1112, 0, 1112, 1112, 1113, 1114, 1114, 1114, 1116, 1116, 1117, 1118, 1119, 1119, 1119, 1119, 1119, 0, 0, 0, 1120, 1121, 1121, 1121, 1123, 1123, 1123, 1123, 1124, 1124, 1124, 1124, 0, 0, 0, 1125, 1126, 1126, 1126, 1128, 1128, 1128, 1131, 1131, 1132, 1132, 1134, 1134, 1134, 1135, 1135, 1136, 1136, 1136, 1136, 1139, 1139, 1140, 1140, 1141, 1141, 1143, 1143, 1143, 1144, 1144, 1145, 1145, 1148, 1149, 1154, 1154, 1155, 1155, 1156, 1157, 1157, 1160, 1160, 1160, 1160, 1161, 1161, 1162, 1163, 1163, 1165, 1165, 1165, 1167, 1167, 1168, 1168, 1169, 1169, 1171, 1171, 1172, 1172, 1173, 1173, 1175, 1175, 1175, 1177, 1178, 1185, 1185, 1185, 1185, 1186, 1186, 1186, 1186, 0, 0, 0, 1187, 1187, 1187, 1189, 1189, 1189, 1192, 1192, 1195, 1195, 1197, 1197, 1198, 1198, 1200, 1202, 1204, 1205, 1205, 1205, 1206, 1209, 1210, 1210, 1210, 1210, 1210, 1212, 1212, 1213, 1213, 1213, 1213, 1214, 1214, 1214, 1214, 1215, 1215, 1216, 1216, 1218, 1218, 1219, 1219, 1221, 1222, 1223, 1223, 1223, 1223, 1223, 1225, 1225, 1226, 1226, 1226, 1226, 1226, 0, 0, 0, 1227, 1227, 1227, 1227, 1228, 1228, 1228, 1228, 1228, 0, 0, 0, 1232, 1233, 1234, 1234, 1234, 1234, 1234, 1236, 1237, 1238, 1238, 1238, 1238, 1238, 1240, 1241, 1241, 1241, 1242, 1243, 1243, 1245, 1247, 1248, 1248, 1257, 1257, 1258, 1258, 1259, 1260, 1260, 1260, 1260, 1260, 1260, 0, 0, 0, 1260, 1260, 1260, 0, 0, 0, 1261, 1261, 0, 1261, 1261, 1262, 1262, 1262, 1263, 1263, 1263, 1264, 1264, 1264, 1266, 1269, 1269, 1270, 1270, 1274, 1275, 1275, 1281, 1281, 1282, 1282, 1284, 1284, 1287, 1292, 1292, 1294, 1294, 1294, 1294, 1299, 1299, 1303, 1307, 1307, 0, 1307, 1307, 1307, 1307, 0, 0, 1308, 1310, 1310, 1310, 1310, 1311, 1311, 1311, 1312, 1313, 1314, 1315, 1315, 1315, 1316, 1316, 1318, 1318, 1318, 1319, 1319, 1319, 1319, 1319, 1319, 1320, 1315, 1323, 1327, 1327, 0, 1327, 1327, 1327, 1327, 0, 0, 1328, 1330, 1330, 1330, 1330, 1331, 1331, 1331, 1332, 1333, 1333, 1333, 1334, 1334, 1335, 1335, 1335, 1335, 1335, 1335, 1333, 1338};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {57, 61, 62, 63, 68, 69, 70, 71, 73, 76, 80, 83, 84, 283, 284, 289, 290, 292, 295, 299, 302, 304, 305, 310, 311, 312, 314, 315, 316, 317, 322, 323, 324, 329, 330, 333, 337, 340, 341, 342, 344, 347, 348, 349, 351, 354, 358, 361, 365, 368, 369, 370, 371, 372, 373, 374, 376, 379, 381, 381, 384, 386, 387, 389, 390, 391, 393, 394, 395, 396, 397, 402, 403, 404, 409, 410, 413, 417, 420, 422, 423, 424, 426, 427, 428, 429, 430, 435, 436, 441, 442, 445, 449, 452, 454, 455, 456, 458, 459, 460, 462, 463, 464, 469, 470, 471, 472, 473, 474, 476, 477, 478, 479, 481, 482, 483, 488, 489, 490, 491, 492, 493, 494, 495, 497, 498, 500, 502, 508, 509, 510, 515, 516, 518, 519, 521, 522, 523, 524, 525, 530, 531, 533, 534, 536, 537, 538, 539, 540, 541, 546, 547, 548, 549, 550, 551, 556, 557, 558, 560, 561, 562, 563, 565, 573, 574, 575, 576, 577, 582, 583, 588, 589, 592, 596, 599, 600, 601, 604, 605, 606, 609, 614, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 631, 633, 634, 635, 636, 637, 639, 640, 641, 642, 643, 648, 649, 650, 651, 656, 657, 658, 659, 660, 663, 664, 665, 666, 668, 669, 671, 672, 673, 674, 675, 677, 678, 679, 684, 685, 686, 691, 692, 695, 699, 702, 703, 704, 705, 706, 711, 712, 713, 718, 719, 722, 726, 729, 730, 732, 733, 734, 735, 736, 738, 739, 741, 742, 743, 744, 745, 747, 748, 749, 750, 751, 753, 754, 756, 759, 761, 762, 775, 776, 777, 778, 779, 782, 783, 788, 789, 790, 795, 796, 799, 803, 806, 807, 808, 810, 813, 817, 820, 821, 821, 824, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 837, 844, 845, 846, 847, 852, 854, 855, 864, 865, 866, 871, 872, 873, 875, 883, 884, 885, 886, 887, 888, 894, 895, 900, 928, 933, 934, 937, 938, 939, 944, 945, 948, 952, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 967, 972, 973, 974, 975, 976, 977, 978, 979, 980, 985, 986, 987, 989, 990, 996, 1019, 1024, 1025, 1028, 1029, 1030, 1035, 1036, 1039, 1043, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1056, 1061, 1062, 1063, 1064, 1065, 1066, 1071, 1072, 1073, 1075, 1081};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
translateEmittedExceptionInner 1 1086 57
assign 1 1088 61
new 0 1088 61
print 0 1088 62
assign 1 1089 63
def 1 1089 68
assign 1 1089 69
new 0 1089 69
assign 1 1089 70
new 0 1089 70
assign 1 1089 71
can 2 1089 71
assign 1 0 73
assign 1 0 76
assign 1 0 80
assign 1 1090 83
descriptionGet 0 1090 83
print 0 1090 84
assign 1 1097 283
translatedGet 0 1097 283
assign 1 1097 284
def 1 1097 289
assign 1 1097 290
translatedGet 0 1097 290
assign 1 0 292
assign 1 0 295
assign 1 0 299
return 1 1098 302
assign 1 1100 304
vvGet 0 1100 304
assign 1 1100 305
undef 1 1100 310
assign 1 1101 311
new 0 1101 311
vvSet 1 1101 312
assign 1 1103 314
new 0 1103 314
translatedSet 1 1103 315
assign 1 1104 316
framesTextGet 0 1104 316
assign 1 1104 317
def 1 1104 322
assign 1 1104 323
langGet 0 1104 323
assign 1 1104 324
def 1 1104 329
assign 1 0 330
assign 1 0 333
assign 1 0 337
assign 1 1104 340
langGet 0 1104 340
assign 1 1104 341
new 0 1104 341
assign 1 1104 342
equals 1 1104 342
assign 1 0 344
assign 1 1104 347
langGet 0 1104 347
assign 1 1104 348
new 0 1104 348
assign 1 1104 349
equals 1 1104 349
assign 1 0 351
assign 1 0 354
assign 1 0 358
assign 1 0 361
assign 1 0 365
assign 1 1105 368
new 0 1105 368
assign 1 1105 369
new 1 1105 369
assign 1 1106 370
framesTextGet 0 1106 370
assign 1 1106 371
tokenize 1 1106 371
assign 1 1107 372
langGet 0 1107 372
assign 1 1107 373
new 0 1107 373
assign 1 1107 374
equals 1 1107 374
assign 1 1108 376
new 0 1108 376
assign 1 1110 379
new 0 1110 379
assign 1 1112 381
linkedListIteratorGet 0 0 381
assign 1 1112 384
hasNextGet 0 1112 384
assign 1 1112 386
nextGet 0 1112 386
assign 1 1113 387
vvGet 0 1113 387
assign 1 1114 389
new 0 1114 389
assign 1 1114 390
add 1 1114 390
print 0 1114 391
assign 1 1116 393
new 0 1116 393
assign 1 1116 394
find 1 1116 394
assign 1 1117 395
assign 1 1118 396
assign 1 1119 397
def 1 1119 402
assign 1 1119 403
new 0 1119 403
assign 1 1119 404
greaterEquals 1 1119 409
assign 1 0 410
assign 1 0 413
assign 1 0 417
assign 1 1120 420
vvGet 0 1120 420
assign 1 1121 422
new 0 1121 422
assign 1 1121 423
add 1 1121 423
print 0 1121 424
assign 1 1123 426
new 0 1123 426
assign 1 1123 427
new 0 1123 427
assign 1 1123 428
add 1 1123 428
assign 1 1123 429
find 2 1123 429
assign 1 1124 430
def 1 1124 435
assign 1 1124 436
greater 1 1124 441
assign 1 0 442
assign 1 0 445
assign 1 0 449
assign 1 1125 452
vvGet 0 1125 452
assign 1 1126 454
new 0 1126 454
assign 1 1126 455
add 1 1126 455
print 0 1126 456
assign 1 1128 458
new 0 1128 458
assign 1 1128 459
add 1 1128 459
assign 1 1128 460
substring 2 1128 460
assign 1 1131 462
new 0 1131 462
assign 1 1131 463
find 2 1131 463
assign 1 1132 464
def 1 1132 469
assign 1 1134 470
new 0 1134 470
assign 1 1134 471
add 1 1134 471
assign 1 1134 472
substring 1 1134 472
assign 1 1135 473
new 0 1135 473
assign 1 1135 474
ends 1 1135 474
assign 1 1136 476
sizeGet 0 1136 476
assign 1 1136 477
new 0 1136 477
assign 1 1136 478
subtract 1 1136 478
sizeSet 1 1136 479
assign 1 1139 481
new 0 1139 481
assign 1 1139 482
rfind 1 1139 482
assign 1 1140 483
def 1 1140 488
assign 1 1141 489
new 0 1141 489
assign 1 1141 490
substring 2 1141 490
assign 1 1143 491
new 0 1143 491
assign 1 1143 492
add 1 1143 492
assign 1 1143 493
substring 1 1143 493
assign 1 1144 494
new 0 1144 494
assign 1 1144 495
begins 1 1144 495
assign 1 1145 497
new 0 1145 497
assign 1 1145 498
substring 1 1145 498
assign 1 1148 500
isInteger 0 1148 500
assign 1 1149 502
new 1 1149 502
assign 1 1154 508
new 0 1154 508
assign 1 1154 509
find 2 1154 509
assign 1 1155 510
def 1 1155 515
assign 1 1156 516
vvGet 0 1156 516
assign 1 1157 518
new 0 1157 518
print 0 1157 519
assign 1 1160 521
new 0 1160 521
assign 1 1160 522
new 0 1160 522
assign 1 1160 523
add 1 1160 523
assign 1 1160 524
find 2 1160 524
assign 1 1161 525
def 1 1161 530
assign 1 1162 531
vvGet 0 1162 531
assign 1 1163 533
new 0 1163 533
print 0 1163 534
assign 1 1165 536
new 0 1165 536
assign 1 1165 537
add 1 1165 537
assign 1 1165 538
substring 2 1165 538
assign 1 1167 539
new 0 1167 539
assign 1 1167 540
rfind 1 1167 540
assign 1 1168 541
def 1 1168 546
assign 1 1169 547
new 0 1169 547
assign 1 1169 548
substring 2 1169 548
assign 1 1171 549
new 0 1171 549
assign 1 1171 550
rfind 1 1171 550
assign 1 1172 551
def 1 1172 556
assign 1 1173 557
new 0 1173 557
assign 1 1173 558
substring 2 1173 558
assign 1 1175 560
new 0 1175 560
assign 1 1175 561
add 1 1175 561
assign 1 1175 562
substring 1 1175 562
assign 1 1177 563
isInteger 0 1177 563
assign 1 1178 565
new 1 1178 565
assign 1 1185 573
new 0 1185 573
assign 1 1185 574
new 0 1185 574
assign 1 1185 575
add 1 1185 575
assign 1 1185 576
find 2 1185 576
assign 1 1186 577
def 1 1186 582
assign 1 1186 583
greater 1 1186 588
assign 1 0 589
assign 1 0 592
assign 1 0 596
assign 1 1187 599
new 0 1187 599
assign 1 1187 600
add 1 1187 600
assign 1 1187 601
substring 2 1187 601
assign 1 1189 604
new 0 1189 604
assign 1 1189 605
add 1 1189 605
assign 1 1189 606
substring 1 1189 606
assign 1 1192 609
def 1 1192 614
assign 1 1195 616
new 0 1195 616
assign 1 1195 617
split 1 1195 617
assign 1 1197 618
new 0 1197 618
assign 1 1197 619
get 1 1197 619
assign 1 1198 620
new 0 1198 620
assign 1 1198 621
get 1 1198 621
assign 1 1200 622
extractKlass 1 1200 622
assign 1 1202 623
extractMethod 1 1202 623
assign 1 1204 624
new 4 1204 624
assign 1 1205 625
klassNameGet 0 1205 625
assign 1 1205 626
getSourceFileName 1 1205 626
fileNameSet 1 1205 627
addFrame 1 1206 628
assign 1 1209 631
vvGet 0 1209 631
assign 1 1210 633
new 0 1210 633
assign 1 1210 634
add 1 1210 634
assign 1 1210 635
new 0 1210 635
assign 1 1210 636
add 1 1210 636
print 0 1210 637
assign 1 1212 639
new 0 1212 639
assign 1 1212 640
split 1 1212 640
assign 1 1213 641
sizeGet 0 1213 641
assign 1 1213 642
new 0 1213 642
assign 1 1213 643
greater 1 1213 648
assign 1 1214 649
sizeGet 0 1214 649
assign 1 1214 650
new 0 1214 650
assign 1 1214 651
greater 1 1214 656
assign 1 1215 657
new 0 1215 657
assign 1 1215 658
get 1 1215 658
assign 1 1216 659
new 0 1216 659
assign 1 1216 660
get 1 1216 660
assign 1 1218 663
new 0 1218 663
assign 1 1218 664
get 1 1218 664
assign 1 1219 665
new 0 1219 665
assign 1 1219 666
get 1 1219 666
assign 1 1221 668
extractMethod 1 1221 668
assign 1 1222 669
vvGet 0 1222 669
assign 1 1223 671
new 0 1223 671
assign 1 1223 672
add 1 1223 672
assign 1 1223 673
new 0 1223 673
assign 1 1223 674
add 1 1223 674
print 0 1223 675
assign 1 1225 677
new 0 1225 677
assign 1 1225 678
find 1 1225 678
assign 1 1226 679
def 1 1226 684
assign 1 1226 685
new 0 1226 685
assign 1 1226 686
greater 1 1226 691
assign 1 0 692
assign 1 0 695
assign 1 0 699
assign 1 1227 702
new 0 1227 702
assign 1 1227 703
new 0 1227 703
assign 1 1227 704
add 1 1227 704
assign 1 1227 705
find 2 1227 705
assign 1 1228 706
def 1 1228 711
assign 1 1228 712
new 0 1228 712
assign 1 1228 713
greater 1 1228 718
assign 1 0 719
assign 1 0 722
assign 1 0 726
assign 1 1232 729
substring 1 1232 729
assign 1 1233 730
vvGet 0 1233 730
assign 1 1234 732
new 0 1234 732
assign 1 1234 733
add 1 1234 733
assign 1 1234 734
new 0 1234 734
assign 1 1234 735
add 1 1234 735
print 0 1234 736
assign 1 1236 738
extractKlass 1 1236 738
assign 1 1237 739
vvGet 0 1237 739
assign 1 1238 741
new 0 1238 741
assign 1 1238 742
add 1 1238 742
assign 1 1238 743
new 0 1238 743
assign 1 1238 744
add 1 1238 744
print 0 1238 745
assign 1 1240 747
new 4 1240 747
assign 1 1241 748
klassNameGet 0 1241 748
assign 1 1241 749
getSourceFileName 1 1241 749
fileNameSet 1 1241 750
assign 1 1242 751
vvGet 0 1242 751
assign 1 1243 753
new 0 1243 753
print 0 1243 754
addFrame 1 1245 756
assign 1 1247 759
vvGet 0 1247 759
assign 1 1248 761
new 0 1248 761
print 0 1248 762
assign 1 1257 775
langGet 0 1257 775
emitLangSet 1 1257 776
assign 1 1258 777
new 0 1258 777
langSet 1 1258 778
framesTextSet 1 1259 779
assign 1 1260 782
framesGet 0 1260 782
assign 1 1260 783
def 1 1260 788
assign 1 1260 789
langGet 0 1260 789
assign 1 1260 790
def 1 1260 795
assign 1 0 796
assign 1 0 799
assign 1 0 803
assign 1 1260 806
langGet 0 1260 806
assign 1 1260 807
new 0 1260 807
assign 1 1260 808
equals 1 1260 808
assign 1 0 810
assign 1 0 813
assign 1 0 817
assign 1 1261 820
framesGet 0 1261 820
assign 1 1261 821
iteratorGet 0 0 821
assign 1 1261 824
hasNextGet 0 1261 824
assign 1 1261 826
nextGet 0 1261 826
assign 1 1262 827
klassNameGet 0 1262 827
assign 1 1262 828
extractKlassLib 1 1262 828
klassNameSet 1 1262 829
assign 1 1263 830
methodNameGet 0 1263 830
assign 1 1263 831
extractMethod 1 1263 831
methodNameSet 1 1263 832
assign 1 1264 833
klassNameGet 0 1264 833
assign 1 1264 834
getSourceFileName 1 1264 834
fileNameSet 1 1264 835
extractLine 0 1266 837
assign 1 1269 844
langGet 0 1269 844
emitLangSet 1 1269 845
assign 1 1270 846
new 0 1270 846
langSet 1 1270 847
assign 1 1274 852
vvGet 0 1274 852
assign 1 1275 854
new 0 1275 854
print 0 1275 855
assign 1 1281 864
new 0 1281 864
assign 1 1281 865
createInstance 2 1281 865
assign 1 1282 866
def 1 1282 871
assign 1 1284 872
sourceFileNameGet 0 1284 872
return 1 1284 873
return 1 1287 875
assign 1 1292 883
new 0 1292 883
assign 1 1292 884
split 1 1292 884
assign 1 1294 885
new 0 1294 885
assign 1 1294 886
get 1 1294 886
assign 1 1294 887
extractKlass 1 1294 887
return 1 1294 888
assign 1 1299 894
extractKlassInner 1 1299 894
return 1 1299 895
return 1 1303 900
assign 1 1307 928
undef 1 1307 933
assign 1 0 934
assign 1 1307 937
new 0 1307 937
assign 1 1307 938
begins 1 1307 938
assign 1 1307 939
not 0 1307 944
assign 1 0 945
assign 1 0 948
return 1 1308 952
assign 1 1310 954
new 0 1310 954
assign 1 1310 955
substring 1 1310 955
assign 1 1310 956
new 0 1310 956
assign 1 1310 957
split 1 1310 957
assign 1 1311 958
sizeGet 0 1311 958
assign 1 1311 959
new 0 1311 959
assign 1 1311 960
subtract 1 1311 960
assign 1 1312 961
get 1 1312 961
assign 1 1313 962
new 0 1313 962
assign 1 1314 963
new 0 1314 963
assign 1 1315 964
new 0 1315 964
assign 1 1315 967
lesser 1 1315 972
assign 1 1316 973
get 1 1316 973
assign 1 1316 974
new 1 1316 974
assign 1 1318 975
add 1 1318 975
assign 1 1318 976
substring 2 1318 976
addValue 1 1318 977
assign 1 1319 978
new 0 1319 978
assign 1 1319 979
add 1 1319 979
assign 1 1319 980
lesser 1 1319 985
assign 1 1319 986
new 0 1319 986
addValue 1 1319 987
addValue 1 1320 989
incrementValue 0 1315 990
return 1 1323 996
assign 1 1327 1019
undef 1 1327 1024
assign 1 0 1025
assign 1 1327 1028
new 0 1327 1028
assign 1 1327 1029
begins 1 1327 1029
assign 1 1327 1030
not 0 1327 1035
assign 1 0 1036
assign 1 0 1039
return 1 1328 1043
assign 1 1330 1045
new 0 1330 1045
assign 1 1330 1046
substring 1 1330 1046
assign 1 1330 1047
new 0 1330 1047
assign 1 1330 1048
split 1 1330 1048
assign 1 1331 1049
sizeGet 0 1331 1049
assign 1 1331 1050
new 0 1331 1050
assign 1 1331 1051
subtract 1 1331 1051
assign 1 1332 1052
new 0 1332 1052
assign 1 1333 1053
new 0 1333 1053
assign 1 1333 1056
lesser 1 1333 1061
assign 1 1334 1062
get 1 1334 1062
addValue 1 1334 1063
assign 1 1335 1064
new 0 1335 1064
assign 1 1335 1065
add 1 1335 1065
assign 1 1335 1066
lesser 1 1335 1071
assign 1 1335 1072
new 0 1335 1072
addValue 1 1335 1073
incrementValue 0 1333 1075
return 1 1338 1081
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 38127485: return bem_iteratorGet_0();
case 854710191: return bem_create_0();
case 636345: return bem_print_0();
case 2061432375: return bem_tagGet_0();
case -1849826772: return bem_default_0();
case 1847639727: return bem_new_0();
case 793589441: return bem_classNameGet_0();
case -1331374769: return bem_toString_0();
case -1818293830: return bem_fieldNamesGet_0();
case -1508036637: return bem_copy_0();
case -22788464: return bem_hashGet_0();
case -593469656: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 2051826551: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 225980093: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1656642280: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 882589836: return bem_sameObject_1(bevd_0);
case 278169461: return bem_sameType_1(bevd_0);
case -1389810691: return bem_translateEmittedException_1((BEC_2_6_9_SystemException) bevd_0);
case 2051383116: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1019066380: return bem_copyTo_1(bevd_0);
case 1281048000: return bem_notEquals_1(bevd_0);
case -57564164: return bem_otherType_1(bevd_0);
case -1226583321: return bem_undef_1(bevd_0);
case -502376443: return bem_equals_1(bevd_0);
case -1856168486: return bem_translateEmittedExceptionInner_1((BEC_2_6_9_SystemException) bevd_0);
case 437215975: return bem_sameClass_1(bevd_0);
case -392787159: return bem_def_1(bevd_0);
case -1967104333: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 424031125: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1437133284: return bem_otherClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 237737767: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 789059792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1571896201: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -804934117: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -281815906: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemExceptionTranslator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_19_SystemExceptionTranslator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemExceptionTranslator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst = (BEC_2_6_19_SystemExceptionTranslator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_type;
}
}
