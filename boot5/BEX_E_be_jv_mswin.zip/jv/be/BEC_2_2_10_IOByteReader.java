package be;
/* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_10_IOByteReader extends BEC_2_6_6_SystemObject {
public BEC_2_2_10_IOByteReader() { }
private static byte[] becc_BEC_2_2_10_IOByteReader_clname = {0x49,0x4F,0x3A,0x42,0x79,0x74,0x65,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_10_IOByteReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_inst;

public static BET_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_type;

public BEC_2_2_6_IOReader bevp_reader;
public BEC_2_4_6_TextString bevp_buf;
public BEC_2_4_12_TextByteIterator bevp_iter;
public BEC_2_2_10_IOByteReader bem_readerBufferNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_6_TextString beva__buf) throws Throwable {
bevp_reader = beva__reader;
bevp_buf = beva__buf;
bevp_iter = bevp_buf.bem_biterGet_0();
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerNew_1(BEC_2_2_6_IOReader beva__reader) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(256));
bevt_0_tmpany_phold = bem_readerBlockNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerBlockNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_3_MathInt beva__blockSize) throws Throwable {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva__blockSize);
bevt_0_tmpany_phold = bem_readerBufferNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 42 */
bevt_3_tmpany_phold = bevp_iter.bem_hasNextGet_0();
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_dest) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 54 */
bevt_3_tmpany_phold = bevp_iter.bem_next_1(beva_dest);
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_2_6_IOReader bem_readerGet_0() throws Throwable {
return bevp_reader;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_bufGet_0() throws Throwable {
return bevp_buf;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_bufSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_iterGet_0() throws Throwable {
return bevp_iter;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {25, 26, 27, 32, 32, 32, 36, 36, 36, 40, 40, 40, 41, 42, 42, 44, 44, 48, 48, 48, 48, 52, 52, 52, 53, 54, 54, 56, 56, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {15, 16, 17, 23, 24, 25, 30, 31, 32, 39, 40, 45, 46, 47, 48, 50, 51, 57, 58, 59, 60, 67, 68, 73, 74, 75, 76, 78, 79, 82, 85, 89, 92, 96, 99};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 25 15
assign 1 26 16
assign 1 27 17
biterGet 0 27 17
assign 1 32 23
new 0 32 23
assign 1 32 24
readerBlockNew 2 32 24
return 1 32 25
assign 1 36 30
new 1 36 30
assign 1 36 31
readerBufferNew 2 36 31
return 1 36 32
assign 1 40 39
hasNextGet 0 40 39
assign 1 40 40
not 0 40 45
readIntoBuffer 1 41 46
assign 1 42 47
new 0 42 47
posSet 1 42 48
assign 1 44 50
hasNextGet 0 44 50
return 1 44 51
assign 1 48 57
new 0 48 57
assign 1 48 58
new 1 48 58
assign 1 48 59
next 1 48 59
return 1 48 60
assign 1 52 67
hasNextGet 0 52 67
assign 1 52 68
not 0 52 73
readIntoBuffer 1 53 74
assign 1 54 75
new 0 54 75
posSet 1 54 76
assign 1 56 78
next 1 56 78
return 1 56 79
return 1 0 82
assign 1 0 85
return 1 0 89
assign 1 0 92
return 1 0 96
assign 1 0 99
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1224401856: return bem_iterGet_0();
case 2018781702: return bem_hasNextGet_0();
case 1891870089: return bem_print_0();
case -479209354: return bem_hashGet_0();
case -2026346603: return bem_new_0();
case 269301519: return bem_once_0();
case -415539380: return bem_many_0();
case 1663979256: return bem_iteratorGet_0();
case 692745146: return bem_nextGet_0();
case -1255628091: return bem_tagGet_0();
case -1084760201: return bem_create_0();
case -1531622162: return bem_copy_0();
case -127984856: return bem_deserializeClassNameGet_0();
case 1964378555: return bem_serializeContents_0();
case 1092154910: return bem_classNameGet_0();
case -2092271774: return bem_echo_0();
case 1419321950: return bem_bufGet_0();
case 102887971: return bem_fieldIteratorGet_0();
case 2115120452: return bem_serializeToString_0();
case 1039443154: return bem_readerGet_0();
case 1670566168: return bem_sourceFileNameGet_0();
case -333394073: return bem_toString_0();
case 1154933275: return bem_serializationIteratorGet_0();
case -911546686: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -2027519443: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1139979118: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2088579865: return bem_otherType_1(bevd_0);
case 1834339384: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 696911277: return bem_bufSet_1(bevd_0);
case -724252744: return bem_iterSet_1(bevd_0);
case 1674374988: return bem_sameObject_1(bevd_0);
case -326579864: return bem_sameClass_1(bevd_0);
case -164561823: return bem_readerSet_1(bevd_0);
case -1574704139: return bem_copyTo_1(bevd_0);
case -1148767287: return bem_readerNew_1((BEC_2_2_6_IOReader) bevd_0);
case -266225430: return bem_notEquals_1(bevd_0);
case -1020405356: return bem_otherClass_1(bevd_0);
case -2035847518: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1077702335: return bem_equals_1(bevd_0);
case -605366432: return bem_defined_1(bevd_0);
case -834006616: return bem_sameType_1(bevd_0);
case -2109819584: return bem_def_1(bevd_0);
case 1980041008: return bem_undefined_1(bevd_0);
case 8626873: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -91281186: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 926020368: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1052279432: return bem_readerBlockNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1571889490: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -730327046: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1287853651: return bem_readerBufferNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1129799281: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -783330142: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1456214761: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1743986647: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_2_10_IOByteReader_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_10_IOByteReader_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_2_10_IOByteReader();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst = (BEC_2_2_10_IOByteReader) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_type;
}
}
