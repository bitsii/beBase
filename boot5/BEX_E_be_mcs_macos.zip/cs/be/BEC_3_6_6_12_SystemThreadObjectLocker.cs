namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
static BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;

public static new BET_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
bem_new_0();
bevp_lock.bem_lock_0();
try /* Line: 951*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 953*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 956*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_oGet_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 962*/ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 964*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 967*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 974*/ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 977*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 980*/
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try /* Line: 988*/ {
if (bevp_obj == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 989*/ {
bevp_obj = beva__obj;
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 991*/
bevp_lock.bem_unlock_0();
} /* Line: 993*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 996*/
return bevl_res;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 1003*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1005*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1008*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_oGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_6_6_12_SystemThreadObjectLocker) bem_oSet_1(beva__obj);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objGet_0() {
return bevp_obj;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objGetDirect_0() {
return bevp_obj;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_obj = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_objSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_obj = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {941, 946, 950, 952, 953, 955, 956, 961, 963, 964, 966, 967, 969, 973, 975, 976, 977, 979, 980, 982, 986, 987, 989, 989, 990, 991, 993, 995, 996, 998, 1002, 1004, 1005, 1007, 1008, 1013, 1013, 1017, 1017, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 24, 25, 27, 28, 32, 33, 40, 42, 43, 47, 48, 50, 55, 57, 58, 59, 63, 64, 66, 72, 73, 75, 80, 81, 82, 84, 88, 89, 91, 95, 97, 98, 102, 103, 109, 110, 114, 115, 118, 121, 124, 128, 132, 135, 138, 142};
/* BEGIN LINEINFO 
assign 1 941 19
new 0 941 19
new 0 946 24
lock 0 950 25
assign 1 952 27
unlock 0 953 28
unlock 0 955 32
throw 1 956 33
lock 0 961 40
assign 1 963 42
unlock 0 964 43
unlock 0 966 47
throw 1 967 48
return 1 969 50
lock 0 973 55
assign 1 975 57
assign 1 976 58
unlock 0 977 59
unlock 0 979 63
throw 1 980 64
return 1 982 66
lock 0 986 72
assign 1 987 73
new 0 987 73
assign 1 989 75
undef 1 989 80
assign 1 990 81
assign 1 991 82
new 0 991 82
unlock 0 993 84
unlock 0 995 88
throw 1 996 89
return 1 998 91
lock 0 1002 95
assign 1 1004 97
unlock 0 1005 98
unlock 0 1007 102
throw 1 1008 103
assign 1 1013 109
oGet 0 1013 109
return 1 1013 110
assign 1 1017 114
oSet 1 1017 114
return 1 1017 115
return 1 0 118
return 1 0 121
assign 1 0 124
assign 1 0 128
return 1 0 132
return 1 0 135
assign 1 0 138
assign 1 0 142
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1562650783: return bem_fieldIteratorGet_0();
case 307193318: return bem_serializeContents_0();
case -1519150687: return bem_getAndClear_0();
case 1460710096: return bem_tagGet_0();
case -1746931542: return bem_lockGetDirect_0();
case -2124744990: return bem_objGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case -1574901722: return bem_objectGet_0();
case 480411455: return bem_lockGet_0();
case -2070846101: return bem_hashGet_0();
case -1906768398: return bem_classNameGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 1258729534: return bem_echo_0();
case 873076018: return bem_new_0();
case -1253293660: return bem_serializeToString_0();
case 1073122685: return bem_objGetDirect_0();
case -1777316122: return bem_serializationIteratorGet_0();
case -1036391864: return bem_copy_0();
case -1111775166: return bem_oGet_0();
case 1640157629: return bem_toString_0();
case 2037996040: return bem_create_0();
case -178385347: return bem_iteratorGet_0();
case 939713627: return bem_print_0();
case -1221104789: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1934630190: return bem_objSetDirect_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -1066238197: return bem_lockSetDirect_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -963219066: return bem_lockSet_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case -657718349: return bem_objSet_1(bevd_0);
case -493310448: return bem_new_1(bevd_0);
case -1817615660: return bem_oSet_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case -380486460: return bem_objectSet_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -652308692: return bem_setIfClear_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;
}
}
}
