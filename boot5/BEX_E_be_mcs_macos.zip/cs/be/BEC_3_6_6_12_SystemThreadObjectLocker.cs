namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
static BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 1143 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1145 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1148 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_oGet_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1154 */ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 1156 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1159 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1166 */ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 1169 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1172 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 1180 */ {
if (bevp_obj == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1181 */ {
bevp_obj = beva__obj;
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1183 */
bevp_lock.bem_unlock_0();
} /* Line: 1185 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1188 */
return bevl_res;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1195 */ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1197 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1200 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_oGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_6_6_12_SystemThreadObjectLocker) bem_oSet_1(beva__obj);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objGet_0() {
return bevp_obj;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_obj = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1133, 1138, 1142, 1144, 1145, 1147, 1148, 1153, 1155, 1156, 1158, 1159, 1161, 1165, 1167, 1168, 1169, 1171, 1172, 1174, 1178, 1179, 1181, 1181, 1182, 1183, 1185, 1187, 1188, 1190, 1194, 1196, 1197, 1199, 1200, 1205, 1205, 1209, 1209, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 22, 23, 25, 26, 30, 31, 38, 40, 41, 45, 46, 48, 53, 55, 56, 57, 61, 62, 64, 70, 71, 73, 78, 79, 80, 82, 86, 87, 89, 93, 95, 96, 100, 101, 107, 108, 112, 113, 116, 119, 123, 126};
/* BEGIN LINEINFO 
assign 1 1133 17
new 0 1133 17
new 0 1138 22
lock 0 1142 23
assign 1 1144 25
unlock 0 1145 26
unlock 0 1147 30
throw 1 1148 31
lock 0 1153 38
assign 1 1155 40
unlock 0 1156 41
unlock 0 1158 45
throw 1 1159 46
return 1 1161 48
lock 0 1165 53
assign 1 1167 55
assign 1 1168 56
unlock 0 1169 57
unlock 0 1171 61
throw 1 1172 62
return 1 1174 64
lock 0 1178 70
assign 1 1179 71
new 0 1179 71
assign 1 1181 73
undef 1 1181 78
assign 1 1182 79
assign 1 1183 80
new 0 1183 80
unlock 0 1185 82
unlock 0 1187 86
throw 1 1188 87
return 1 1190 89
lock 0 1194 93
assign 1 1196 95
unlock 0 1197 96
unlock 0 1199 100
throw 1 1200 101
assign 1 1205 107
oGet 0 1205 107
return 1 1205 108
assign 1 1209 112
oSet 1 1209 112
return 1 1209 113
return 1 0 116
assign 1 0 119
return 1 0 123
assign 1 0 126
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 509465600: return bem_iteratorGet_0();
case -22067602: return bem_objectGet_0();
case 913636711: return bem_toAny_0();
case -1484560218: return bem_lockGet_0();
case 876844323: return bem_serializationIteratorGet_0();
case -85596330: return bem_tagGet_0();
case 1796230342: return bem_toString_0();
case -1427622449: return bem_create_0();
case -853067962: return bem_serializeContents_0();
case -904557663: return bem_print_0();
case -945812364: return bem_once_0();
case 1398390067: return bem_classNameGet_0();
case 1547703569: return bem_getAndClear_0();
case -2066691170: return bem_hashGet_0();
case -1059501870: return bem_fieldIteratorGet_0();
case -1254976075: return bem_deserializeClassNameGet_0();
case -1643411377: return bem_oGet_0();
case -551829583: return bem_echo_0();
case 634265788: return bem_objGet_0();
case -1414488789: return bem_copy_0();
case 1965225689: return bem_sourceFileNameGet_0();
case 1395453592: return bem_serializeToString_0();
case 332749494: return bem_many_0();
case 627584199: return bem_new_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 1789153529: return bem_equals_1(bevd_0);
case 1081898105: return bem_def_1(bevd_0);
case 632969730: return bem_otherType_1(bevd_0);
case -1410322621: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1650785007: return bem_undefined_1(bevd_0);
case -1825570190: return bem_sameObject_1(bevd_0);
case -375396806: return bem_sameType_1(bevd_0);
case 1320933327: return bem_new_1(bevd_0);
case -2064416533: return bem_copyTo_1(bevd_0);
case 251217946: return bem_defined_1(bevd_0);
case 414867900: return bem_otherClass_1(bevd_0);
case -1398432640: return bem_sameClass_1(bevd_0);
case 789416045: return bem_setIfClear_1(bevd_0);
case -1868492738: return bem_lockSet_1(bevd_0);
case -2038649804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1121775076: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -423121136: return bem_objSet_1(bevd_0);
case -489249887: return bem_objectSet_1(bevd_0);
case 1213922529: return bem_notEquals_1(bevd_0);
case 2142029115: return bem_undef_1(bevd_0);
case -1752685865: return bem_oSet_1(bevd_0);
case -282488764: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1716376212: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -113794903: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1467397408: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1606481035: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 75445916: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1518297580: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1418573133: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
}
}
}
