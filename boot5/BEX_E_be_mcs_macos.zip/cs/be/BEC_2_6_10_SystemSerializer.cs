namespace be {
/* IO:File: source/extended/Serialize.be */
public sealed class BEC_2_6_10_SystemSerializer : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
static BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_BEC_2_6_10_SystemSerializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_10_SystemSerializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_0 = {0x7C};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_1 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_2 = {0x26};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_3 = {0x40};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_4 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_5 = {0x3F};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_6 = {0x5E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_7 = {};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_8 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_9 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_10 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
public static new BEC_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_inst;

public static new BET_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_type;

public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_2));
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_3));
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_5));
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_6));
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bem_new_10(bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph, bevt_6_ta_ph, bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_ta_ph = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_getReference);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_constructString);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_nullMark);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_defineClassTag);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_getClassTag);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_shift);
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_toker = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_7_ta_ph);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevp_saveIdentity = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_ta_ph = null;
if (beva_instance == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 92*/ {
bevt_1_ta_ph = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
bem_serializeI_2(beva_instance, bevt_1_ta_ph);
} /* Line: 93*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session );
bevt_0_ta_ph = beva_instance.bemd_0(-8643043);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 99*/ {
bem_serializeC_2(beva_instance, beva_session);
} /* Line: 100*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
bevl_instWriter = beva_session.bemd_0(-498788563);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = beva_instance.bemd_0(-1779062531);
bevt_0_ta_ph = bevl_iter.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 108*/ {
bevl_instWriter.bemd_1(-630618192, bevp_group);
while (true)
/* Line: 110*/ {
bevt_1_ta_ph = bevl_iter.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 110*/ {
bevl_i = bevl_iter.bemd_0(-894202533);
if (bevl_i == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 112*/ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 114*/
 else /* Line: 115*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 117*/ {
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 119*/
 else /* Line: 117*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 120*/ {
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 123*/
 else /* Line: 117*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 124*/ {
bevl_instWriter.bemd_1(-630618192, bevp_shift);
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevt_9_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(-630618192, bevt_9_ta_ph);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 128*/
} /* Line: 117*/
} /* Line: 117*/
if (bevp_saveIdentity.bevi_bool) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 130*/ {
bevl_instSerial = null;
} /* Line: 131*/
 else /* Line: 132*/ {
bevt_11_ta_ph = beva_session.bemd_0(1057424194);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_11_ta_ph.bemd_1(-609621197, bevl_i);
} /* Line: 133*/
if (bevl_instSerial == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 135*/ {
bem_serializeI_2(bevl_i, beva_session);
} /* Line: 137*/
 else /* Line: 138*/ {
bevl_instWriter.bemd_1(-630618192, bevp_getReference);
bevt_13_ta_ph = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(-630618192, bevt_13_ta_ph);
} /* Line: 141*/
} /* Line: 135*/
} /* Line: 112*/
 else /* Line: 110*/ {
break;
} /* Line: 110*/
} /* Line: 110*/
bevt_15_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_multiNull.bevi_int == bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 146*/ {
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 148*/
 else /* Line: 146*/ {
bevt_17_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 149*/ {
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 152*/
 else /* Line: 146*/ {
bevt_19_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (bevl_multiNull.bevi_int > bevt_19_ta_ph.bevi_int) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 153*/ {
bevl_instWriter.bemd_1(-630618192, bevp_shift);
bevl_instWriter.bemd_1(-630618192, bevp_nullMark);
bevt_20_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(-630618192, bevt_20_ta_ph);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 157*/
} /* Line: 146*/
} /* Line: 146*/
bevl_instWriter.bemd_1(-630618192, bevp_shift);
bevl_instWriter.bemd_1(-630618192, bevp_group);
} /* Line: 160*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_11_ContainerIdentityMap bevt_13_ta_ph = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevl_scount.bem_add_1(bevt_2_ta_ph);
beva_session.bem_serialCountSet_1(bevt_1_ta_ph);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(1809383255);
bevt_3_ta_ph = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 171*/ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevl_instClassTag.bem_add_1(bevt_6_ta_ph);
beva_session.bem_classTagCountSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = beva_session.bem_classTagMapGet_0();
bevt_7_ta_ph.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(-630618192, bevp_shift);
bevl_instWriter.bemd_1(-630618192, bevp_defineClassTag);
bevl_instWriter.bemd_1(-630618192, bevl_instClass);
bevl_instWriter.bemd_1(-630618192, bevp_shift);
bevl_instWriter.bemd_1(-630618192, bevp_defineClassTag);
bevl_instWriter.bemd_1(-630618192, bevl_instClassTagStr);
} /* Line: 181*/
 else /* Line: 182*/ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 183*/
if (bevp_saveIdentity.bevi_bool)/* Line: 185*/ {
bevl_instWriter.bemd_1(-630618192, bevp_defineReference);
bevt_8_ta_ph = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(-630618192, bevt_8_ta_ph);
} /* Line: 187*/
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(1688687204);
if (bevl_serializedString == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_10_SystemSerializer_bels_7));
bevt_10_ta_ph = bevl_serializedString.bem_notEquals_1(bevt_11_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 190*/
 else /* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 190*/ {
bevl_instWriter.bemd_1(-630618192, bevp_constructString);
bevt_12_ta_ph = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(-630618192, bevt_12_ta_ph);
} /* Line: 192*/
bevl_instWriter.bemd_1(-630618192, bevp_getClassTag);
bevl_instWriter.bemd_1(-630618192, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool)/* Line: 196*/ {
bevt_13_ta_ph = beva_session.bem_uniqueGet_0();
bevt_13_ta_ph.bem_put_2(beva_instance, bevl_scount);
} /* Line: 197*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_9_SystemException bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_6_9_SystemException bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (BEC_3_6_10_7_SystemSerializerSession) (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (BEC_2_9_5_ContainerStack) (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_1_ta_ph = beva_instReader.bemd_1(398725636, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 206*/ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 207*/
 else /* Line: 208*/ {
bevt_4_ta_ph = beva_instReader.bemd_0(114200084);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_4_ta_ph);
} /* Line: 209*/
bevl_instances = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 215*/ {
bevt_5_ta_ph = bevl_i.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 215*/ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(-894202533);
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_state.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_8_ta_ph = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_8_ta_ph.bevi_bool)/* Line: 218*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 219*/
 else /* Line: 218*/ {
bevt_9_ta_ph = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_9_ta_ph.bevi_bool)/* Line: 220*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 221*/
 else /* Line: 218*/ {
bevt_10_ta_ph = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_10_ta_ph.bevi_bool)/* Line: 222*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
} /* Line: 223*/
 else /* Line: 218*/ {
bevt_11_ta_ph = bevl_token.bem_equals_1(bevp_shift);
if (bevt_11_ta_ph.bevi_bool)/* Line: 224*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1000));
} /* Line: 225*/
 else /* Line: 218*/ {
bevt_12_ta_ph = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_12_ta_ph.bevi_bool)/* Line: 226*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 227*/
 else /* Line: 218*/ {
bevt_13_ta_ph = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_13_ta_ph.bevi_bool)/* Line: 228*/ {
if (bevl_groupInstIter == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 230*/ {
bevl_groupInstIter.bemd_1(497572181, null);
} /* Line: 231*/
} /* Line: 230*/
 else /* Line: 218*/ {
bevt_15_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_15_ta_ph.bevi_bool)/* Line: 233*/ {
if (bevl_inst == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 235*/ {
if (bevl_groupInstIter == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 236*/ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 237*/
bevl_groupInstIter = bevl_inst.bemd_0(-1779062531);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_18_ta_ph = bevl_groupInstIter.bemd_2(1885851803, bevt_19_ta_ph, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 240*/ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 241*/
} /* Line: 240*/
} /* Line: 235*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
 else /* Line: 217*/ {
bevt_22_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1000));
if (bevl_state.bevi_int == bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 245*/ {
bevt_23_ta_ph = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_23_ta_ph.bevi_bool)/* Line: 247*/ {
if (bevl_defineClassTagName == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 248*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
} /* Line: 249*/
 else /* Line: 250*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
} /* Line: 251*/
} /* Line: 248*/
 else /* Line: 247*/ {
bevt_25_ta_ph = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_25_ta_ph.bevi_bool)/* Line: 253*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
} /* Line: 254*/
 else /* Line: 247*/ {
bevt_26_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_26_ta_ph.bevi_bool)/* Line: 255*/ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 258*/
} /* Line: 247*/
} /* Line: 247*/
} /* Line: 247*/
 else /* Line: 260*/ {
bevt_28_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_state.bevi_int == bevt_28_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 261*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bece_BEC_2_6_10_SystemSerializer_bels_9));
bevt_30_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_31_ta_ph);
throw new be.BECS_ThrowBack(bevt_30_ta_ph);
} /* Line: 263*/
bevl_instSerial = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 266*/
 else /* Line: 261*/ {
bevt_33_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (bevl_state.bevi_int == bevt_33_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 267*/ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 269*/
 else /* Line: 261*/ {
bevt_35_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
if (bevl_state.bevi_int == bevt_35_ta_ph.bevi_int) {
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 270*/ {
bevl_glassTagVal = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_36_ta_ph = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_36_ta_ph.bem_get_1(bevl_glassTagVal);
bevt_38_ta_ph = bem_createInstance_1(bevl_klass);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(-502153488, bevl_instString);
bevl_inst = bevt_37_ta_ph.bemd_1(1310506003, bevl_instString);
if (bevl_rootInst == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 274*/ {
bevl_rootInst = bevl_inst;
} /* Line: 275*/
if (bevp_saveIdentity.bevi_bool)/* Line: 277*/ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 278*/
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_40_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_40_ta_ph.bevi_bool)/* Line: 282*/ {
bevl_groupInstIter.bemd_1(497572181, bevl_inst);
} /* Line: 283*/
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 285*/
 else /* Line: 261*/ {
bevt_42_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
if (bevl_state.bevi_int == bevt_42_ta_ph.bevi_int) {
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 286*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(66, bece_BEC_2_6_10_SystemSerializer_bels_10));
bevt_44_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_45_ta_ph);
throw new be.BECS_ThrowBack(bevt_44_ta_ph);
} /* Line: 288*/
bevl_instSerial = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 292*/ {
bevl_groupInstIter.bemd_1(497572181, bevl_inst);
} /* Line: 293*/
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 295*/
 else /* Line: 261*/ {
bevt_48_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
if (bevl_state.bevi_int == bevt_48_ta_ph.bevi_int) {
bevt_47_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_47_ta_ph.bevi_bool)/* Line: 296*/ {
bevl_defineClassTagName = bevl_token;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 298*/
 else /* Line: 261*/ {
bevt_50_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
if (bevl_state.bevi_int == bevt_50_ta_ph.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 299*/ {
bevl_defineClassTagValue = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_51_ta_ph = bevl_session.bem_classTagMapGet_0();
bevt_51_ta_ph.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 304*/
 else /* Line: 261*/ {
bevt_53_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
if (bevl_state.bevi_int == bevt_53_ta_ph.bevi_int) {
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 305*/ {
if (bevl_groupInstIter == null) {
bevt_54_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_54_ta_ph.bevi_bool)/* Line: 307*/ {
bevl_multiNullCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(1900634963, bevl_multiNullCount);
} /* Line: 309*/
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 311*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 217*/
} /* Line: 217*/
 else /* Line: 215*/ {
break;
} /* Line: 215*/
} /* Line: 215*/
bevl_inst = null;
bevt_0_ta_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
/* Line: 316*/ {
bevt_55_ta_ph = bevt_0_ta_loop.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_55_ta_ph).bevi_bool)/* Line: 316*/ {
bevl_groupInstIter = bevt_0_ta_loop.bemd_0(-894202533);
bevl_groupInstIter.bemd_0(1825804503);
} /* Line: 317*/
 else /* Line: 316*/ {
break;
} /* Line: 316*/
} /* Line: 316*/
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() {
return bevp_group;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGetDirect_0() {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() {
return bevp_defineReference;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGetDirect_0() {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() {
return bevp_getReference;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGetDirect_0() {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() {
return bevp_constructString;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGetDirect_0() {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() {
return bevp_nullMark;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGetDirect_0() {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() {
return bevp_getClassTag;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGetDirect_0() {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() {
return bevp_shift;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGetDirect_0() {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGetDirect_0() {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGetDirect_0() {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() {
return bevp_endGroup;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGetDirect_0() {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() {
return bevp_toker;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() {
return bevp_encoder;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGetDirect_0() {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGetDirect_0() {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 77, 77, 77, 77, 77, 77, 77, 78, 76, 80, 81, 86, 87, 88, 92, 92, 93, 93, 98, 99, 100, 105, 106, 107, 108, 109, 110, 111, 112, 112, 114, 117, 117, 117, 118, 119, 120, 120, 120, 121, 122, 123, 124, 124, 124, 125, 126, 127, 127, 128, 130, 130, 131, 133, 133, 135, 135, 137, 140, 141, 141, 146, 146, 146, 147, 148, 149, 149, 149, 150, 151, 152, 153, 153, 153, 154, 155, 156, 156, 157, 159, 160, 165, 166, 166, 166, 168, 169, 170, 170, 171, 171, 172, 173, 174, 174, 174, 175, 175, 176, 177, 178, 179, 180, 181, 183, 186, 187, 187, 189, 190, 190, 190, 190, 0, 0, 0, 191, 192, 192, 194, 195, 197, 197, 202, 203, 204, 205, 206, 206, 206, 207, 209, 209, 211, 215, 215, 216, 217, 217, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 230, 230, 231, 233, 235, 235, 236, 236, 237, 239, 240, 240, 240, 241, 245, 245, 245, 247, 248, 248, 249, 251, 253, 254, 255, 257, 258, 261, 261, 261, 262, 262, 263, 263, 263, 265, 266, 267, 267, 267, 268, 269, 270, 270, 270, 271, 272, 272, 273, 273, 273, 274, 274, 275, 278, 280, 282, 282, 283, 285, 286, 286, 286, 287, 287, 288, 288, 288, 290, 291, 292, 292, 293, 295, 296, 296, 296, 297, 298, 299, 299, 299, 301, 302, 302, 303, 304, 305, 305, 305, 307, 307, 308, 309, 311, 315, 316, 0, 316, 316, 317, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 94, 95, 96, 101, 106, 107, 108, 114, 115, 117, 148, 149, 150, 151, 153, 156, 158, 159, 164, 165, 168, 169, 174, 175, 176, 179, 180, 185, 186, 187, 188, 191, 192, 197, 198, 199, 200, 201, 202, 206, 211, 212, 215, 216, 218, 223, 224, 227, 228, 229, 237, 238, 243, 244, 245, 248, 249, 254, 255, 256, 257, 260, 261, 266, 267, 268, 269, 270, 271, 275, 276, 301, 302, 303, 304, 305, 306, 307, 308, 309, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 330, 333, 334, 335, 337, 338, 343, 344, 345, 347, 350, 354, 357, 358, 359, 361, 362, 364, 365, 444, 445, 446, 447, 448, 449, 450, 452, 455, 456, 458, 459, 462, 464, 465, 466, 471, 472, 474, 477, 479, 482, 484, 487, 489, 492, 494, 497, 499, 504, 505, 509, 511, 516, 517, 522, 523, 525, 526, 527, 528, 530, 542, 543, 548, 549, 551, 556, 557, 560, 564, 566, 569, 571, 572, 578, 579, 584, 585, 590, 591, 592, 593, 595, 596, 599, 600, 605, 606, 607, 610, 611, 616, 617, 618, 619, 620, 621, 622, 623, 628, 629, 632, 634, 635, 640, 641, 643, 646, 647, 652, 653, 658, 659, 660, 661, 663, 664, 665, 670, 671, 673, 676, 677, 682, 683, 684, 687, 688, 693, 694, 695, 696, 697, 698, 701, 702, 707, 708, 713, 714, 715, 717, 732, 733, 733, 736, 738, 739, 745, 748, 751, 754, 758, 762, 765, 768, 772, 776, 779, 782, 786, 790, 793, 796, 800, 804, 807, 810, 814, 818, 821, 824, 828, 832, 835, 838, 842, 846, 849, 852, 856, 860, 863, 866, 870, 874, 877, 880, 884, 888, 891, 894, 898, 902, 905, 908, 912, 916, 919, 922, 926};
/* BEGIN LINEINFO 
assign 1 60 47
new 0 60 47
assign 1 60 48
new 0 60 48
assign 1 60 49
new 0 60 49
assign 1 60 50
new 0 60 50
assign 1 60 51
new 0 60 51
assign 1 60 52
new 0 60 52
assign 1 60 53
new 0 60 53
assign 1 60 54
new 0 60 54
assign 1 60 55
new 0 60 55
assign 1 60 56
new 0 60 56
new 10 60 57
assign 1 66 69
assign 1 67 70
assign 1 68 71
assign 1 69 72
assign 1 70 73
assign 1 71 74
assign 1 72 75
assign 1 73 76
assign 1 74 77
assign 1 75 78
assign 1 77 79
add 1 77 79
assign 1 77 80
add 1 77 80
assign 1 77 81
add 1 77 81
assign 1 77 82
add 1 77 82
assign 1 77 83
add 1 77 83
assign 1 77 84
add 1 77 84
assign 1 77 85
add 1 77 85
assign 1 78 86
new 0 78 86
assign 1 76 87
new 2 76 87
assign 1 80 88
new 0 80 88
assign 1 81 89
new 0 81 89
assign 1 86 94
new 0 86 94
serialize 2 87 95
return 1 88 96
assign 1 92 101
def 1 92 106
assign 1 93 107
new 1 93 107
serializeI 2 93 108
defineInstance 2 98 114
assign 1 99 115
serializeContents 0 99 115
serializeC 2 100 117
assign 1 105 148
instWriterGet 0 105 148
assign 1 106 149
new 0 106 149
assign 1 107 150
serializationIteratorGet 0 107 150
assign 1 108 151
hasNextGet 0 108 151
write 1 109 153
assign 1 110 156
hasNextGet 0 110 156
assign 1 111 158
nextGet 0 111 158
assign 1 112 159
undef 1 112 164
assign 1 114 165
increment 0 114 165
assign 1 117 168
new 0 117 168
assign 1 117 169
equals 1 117 174
write 1 118 175
assign 1 119 176
new 0 119 176
assign 1 120 179
new 0 120 179
assign 1 120 180
equals 1 120 185
write 1 121 186
write 1 122 187
assign 1 123 188
new 0 123 188
assign 1 124 191
new 0 124 191
assign 1 124 192
greater 1 124 197
write 1 125 198
write 1 126 199
assign 1 127 200
toString 0 127 200
write 1 127 201
assign 1 128 202
new 0 128 202
assign 1 130 206
not 0 130 211
assign 1 131 212
assign 1 133 215
uniqueGet 0 133 215
assign 1 133 216
get 1 133 216
assign 1 135 218
undef 1 135 223
serializeI 2 137 224
write 1 140 227
assign 1 141 228
toString 0 141 228
write 1 141 229
assign 1 146 237
new 0 146 237
assign 1 146 238
equals 1 146 243
write 1 147 244
assign 1 148 245
new 0 148 245
assign 1 149 248
new 0 149 248
assign 1 149 249
equals 1 149 254
write 1 150 255
write 1 151 256
assign 1 152 257
new 0 152 257
assign 1 153 260
new 0 153 260
assign 1 153 261
greater 1 153 266
write 1 154 267
write 1 155 268
assign 1 156 269
toString 0 156 269
write 1 156 270
assign 1 157 271
new 0 157 271
write 1 159 275
write 1 160 276
assign 1 165 301
serialCountGet 0 165 301
assign 1 166 302
new 0 166 302
assign 1 166 303
add 1 166 303
serialCountSet 1 166 304
assign 1 168 305
instWriterGet 0 168 305
assign 1 169 306
deserializeClassNameGet 0 169 306
assign 1 170 307
classTagMapGet 0 170 307
assign 1 170 308
get 1 170 308
assign 1 171 309
undef 1 171 314
assign 1 172 315
classTagCountGet 0 172 315
assign 1 173 316
toString 0 173 316
assign 1 174 317
new 0 174 317
assign 1 174 318
add 1 174 318
classTagCountSet 1 174 319
assign 1 175 320
classTagMapGet 0 175 320
put 2 175 321
write 1 176 322
write 1 177 323
write 1 178 324
write 1 179 325
write 1 180 326
write 1 181 327
assign 1 183 330
toString 0 183 330
write 1 186 333
assign 1 187 334
toString 0 187 334
write 1 187 335
assign 1 189 337
serializeToString 0 189 337
assign 1 190 338
def 1 190 343
assign 1 190 344
new 0 190 344
assign 1 190 345
notEquals 1 190 345
assign 1 0 347
assign 1 0 350
assign 1 0 354
write 1 191 357
assign 1 192 358
encode 1 192 358
write 1 192 359
write 1 194 361
write 1 195 362
assign 1 197 364
uniqueGet 0 197 364
put 2 197 365
assign 1 202 444
new 0 202 444
assign 1 203 445
new 0 203 445
assign 1 204 446
new 0 204 446
assign 1 205 447
new 0 205 447
assign 1 206 448
new 0 206 448
assign 1 206 449
emptyGet 0 206 449
assign 1 206 450
sameType 1 206 450
assign 1 207 452
tokenize 1 207 452
assign 1 209 455
readString 0 209 455
assign 1 209 456
tokenize 1 209 456
assign 1 211 458
new 0 211 458
assign 1 215 459
linkedListIteratorGet 0 215 459
assign 1 215 462
hasNextGet 0 215 462
assign 1 216 464
nextGet 0 216 464
assign 1 217 465
new 0 217 465
assign 1 217 466
equals 1 217 471
assign 1 218 472
equals 1 218 472
assign 1 219 474
new 0 219 474
assign 1 220 477
equals 1 220 477
assign 1 221 479
new 0 221 479
assign 1 222 482
equals 1 222 482
assign 1 223 484
new 0 223 484
assign 1 224 487
equals 1 224 487
assign 1 225 489
new 0 225 489
assign 1 226 492
equals 1 226 492
assign 1 227 494
new 0 227 494
assign 1 228 497
equals 1 228 497
assign 1 230 499
def 1 230 504
nextSet 1 231 505
assign 1 233 509
equals 1 233 509
assign 1 235 511
def 1 235 516
assign 1 236 517
def 1 236 522
push 1 237 523
assign 1 239 525
serializationIteratorGet 0 239 525
assign 1 240 526
new 0 240 526
assign 1 240 527
new 0 240 527
assign 1 240 528
can 2 240 528
addValue 1 241 530
assign 1 245 542
new 0 245 542
assign 1 245 543
equals 1 245 548
assign 1 247 549
equals 1 247 549
assign 1 248 551
undef 1 248 556
assign 1 249 557
new 0 249 557
assign 1 251 560
new 0 251 560
assign 1 253 564
equals 1 253 564
assign 1 254 566
new 0 254 566
assign 1 255 569
equals 1 255 569
assign 1 257 571
pop 0 257 571
assign 1 258 572
new 0 258 572
assign 1 261 578
new 0 261 578
assign 1 261 579
equals 1 261 584
assign 1 262 585
not 0 262 590
assign 1 263 591
new 0 263 591
assign 1 263 592
new 1 263 592
throw 1 263 593
assign 1 265 595
new 1 265 595
assign 1 266 596
new 0 266 596
assign 1 267 599
new 0 267 599
assign 1 267 600
equals 1 267 605
assign 1 268 606
decode 1 268 606
assign 1 269 607
new 0 269 607
assign 1 270 610
new 0 270 610
assign 1 270 611
equals 1 270 616
assign 1 271 617
new 1 271 617
assign 1 272 618
classTagMapGet 0 272 618
assign 1 272 619
get 1 272 619
assign 1 273 620
createInstance 1 273 620
assign 1 273 621
deserializeFromStringNew 1 273 621
assign 1 273 622
deserializeFromString 1 273 622
assign 1 274 623
undef 1 274 628
assign 1 275 629
put 2 278 632
assign 1 280 634
assign 1 282 635
def 1 282 640
nextSet 1 283 641
assign 1 285 643
new 0 285 643
assign 1 286 646
new 0 286 646
assign 1 286 647
equals 1 286 652
assign 1 287 653
not 0 287 658
assign 1 288 659
new 0 288 659
assign 1 288 660
new 1 288 660
throw 1 288 661
assign 1 290 663
new 1 290 663
assign 1 291 664
get 1 291 664
assign 1 292 665
def 1 292 670
nextSet 1 293 671
assign 1 295 673
new 0 295 673
assign 1 296 676
new 0 296 676
assign 1 296 677
equals 1 296 682
assign 1 297 683
assign 1 298 684
new 0 298 684
assign 1 299 687
new 0 299 687
assign 1 299 688
equals 1 299 693
assign 1 301 694
new 1 301 694
assign 1 302 695
classTagMapGet 0 302 695
put 2 302 696
assign 1 303 697
assign 1 304 698
new 0 304 698
assign 1 305 701
new 0 305 701
assign 1 305 702
equals 1 305 707
assign 1 307 708
def 1 307 713
assign 1 308 714
new 1 308 714
skip 1 309 715
assign 1 311 717
new 0 311 717
assign 1 315 732
assign 1 316 733
iteratorGet 0 0 733
assign 1 316 736
hasNextGet 0 316 736
assign 1 316 738
nextGet 0 316 738
postDeserialize 0 317 739
return 1 319 745
return 1 0 748
return 1 0 751
assign 1 0 754
assign 1 0 758
return 1 0 762
return 1 0 765
assign 1 0 768
assign 1 0 772
return 1 0 776
return 1 0 779
assign 1 0 782
assign 1 0 786
return 1 0 790
return 1 0 793
assign 1 0 796
assign 1 0 800
return 1 0 804
return 1 0 807
assign 1 0 810
assign 1 0 814
return 1 0 818
return 1 0 821
assign 1 0 824
assign 1 0 828
return 1 0 832
return 1 0 835
assign 1 0 838
assign 1 0 842
return 1 0 846
return 1 0 849
assign 1 0 852
assign 1 0 856
return 1 0 860
return 1 0 863
assign 1 0 866
assign 1 0 870
return 1 0 874
return 1 0 877
assign 1 0 880
assign 1 0 884
return 1 0 888
return 1 0 891
assign 1 0 894
assign 1 0 898
return 1 0 902
return 1 0 905
assign 1 0 908
assign 1 0 912
return 1 0 916
return 1 0 919
assign 1 0 922
assign 1 0 926
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2122375894: return bem_groupGet_0();
case -876130083: return bem_saveIdentityGetDirect_0();
case -1844917728: return bem_many_0();
case 313850889: return bem_saveIdentityGet_0();
case -8643043: return bem_serializeContents_0();
case -1026733174: return bem_new_0();
case -31114048: return bem_iteratorGet_0();
case 719485984: return bem_defineReferenceGetDirect_0();
case 1227368362: return bem_defineClassTagGet_0();
case 123483815: return bem_getReferenceGetDirect_0();
case -21722744: return bem_encoderGetDirect_0();
case -240764908: return bem_endGroupGet_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case -842401127: return bem_tokerGet_0();
case -778582022: return bem_tokerGetDirect_0();
case -1902089216: return bem_toString_0();
case 1742396534: return bem_encoderGet_0();
case 479821077: return bem_getReferenceGet_0();
case 1137009070: return bem_once_0();
case 126670515: return bem_toAny_0();
case 1040204265: return bem_endGroupGetDirect_0();
case 1250910958: return bem_nullMarkGet_0();
case -12528853: return bem_shiftGetDirect_0();
case 185174991: return bem_copy_0();
case 1986838495: return bem_constructStringGetDirect_0();
case -530279936: return bem_groupGetDirect_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1567926970: return bem_multiNullMarkGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 1029695809: return bem_echo_0();
case 217968364: return bem_classNameGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 689929840: return bem_getClassTagGetDirect_0();
case -1549618302: return bem_constructStringGet_0();
case 1562608535: return bem_print_0();
case 268220194: return bem_getClassTagGet_0();
case 2065513151: return bem_defineClassTagGetDirect_0();
case 1688687204: return bem_serializeToString_0();
case -57961944: return bem_multiNullMarkGetDirect_0();
case 562236977: return bem_defineReferenceGet_0();
case -1848718184: return bem_hashGet_0();
case 1710661938: return bem_shiftGet_0();
case -785258946: return bem_create_0();
case -479166709: return bem_tagGet_0();
case 1635432073: return bem_nullMarkGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1811318132: return bem_defined_1(bevd_0);
case -971360690: return bem_defineReferenceSetDirect_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -1371462150: return bem_getClassTagSet_1(bevd_0);
case -663969501: return bem_nullMarkSetDirect_1(bevd_0);
case -1675476853: return bem_defineClassTagSet_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 1987145121: return bem_constructStringSet_1(bevd_0);
case -560759223: return bem_nullMarkSet_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case 561647588: return bem_groupSetDirect_1(bevd_0);
case 1741833533: return bem_tokerSet_1(bevd_0);
case 1439335756: return bem_multiNullMarkSet_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 142611936: return bem_tokerSetDirect_1(bevd_0);
case -1279285409: return bem_saveIdentitySet_1(bevd_0);
case -1523163764: return bem_groupSet_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case -1333620917: return bem_shiftSetDirect_1(bevd_0);
case -193048187: return bem_encoderSet_1(bevd_0);
case -980171799: return bem_multiNullMarkSetDirect_1(bevd_0);
case -1123127468: return bem_saveIdentitySetDirect_1(bevd_0);
case -826343269: return bem_getClassTagSetDirect_1(bevd_0);
case -387483147: return bem_serialize_1(bevd_0);
case 903869610: return bem_getReferenceSet_1(bevd_0);
case 2046118376: return bem_constructStringSetDirect_1(bevd_0);
case 493709913: return bem_endGroupSetDirect_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -1873430523: return bem_encoderSetDirect_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 594418708: return bem_defineClassTagSetDirect_1(bevd_0);
case -1030318147: return bem_getReferenceSetDirect_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1195463632: return bem_defineReferenceSet_1(bevd_0);
case 1334025728: return bem_shiftSet_1(bevd_0);
case -1103794714: return bem_endGroupSet_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1987728970: return bem_deserialize_1(bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 263893633: return bem_serializeC_2(bevd_0, bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2050514752: return bem_serializeI_2(bevd_0, bevd_1);
case -983607132: return bem_serialize_2(bevd_0, bevd_1);
case -40682572: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_x(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) {
switch (callId) {
case 23975070: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return base.bemd_x(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemSerializer_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_10_SystemSerializer_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemSerializer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst = (BEC_2_6_10_SystemSerializer) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_type;
}
}
}
