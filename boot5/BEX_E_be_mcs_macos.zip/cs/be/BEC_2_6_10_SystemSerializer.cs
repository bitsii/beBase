namespace be {
/* IO:File: source/extended/Serialize.be */
public sealed class BEC_2_6_10_SystemSerializer : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemSerializer() { }
static BEC_2_6_10_SystemSerializer() { }
private static byte[] becc_BEC_2_6_10_SystemSerializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_10_SystemSerializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_0 = {0x7C};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_1 = {0x23};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_2 = {0x26};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_3 = {0x40};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_4 = {0x3B};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_5 = {0x3F};
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_6 = {0x5E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_1 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_4 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_6 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_7 = {};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemSerializer_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemSerializer_bels_7, 0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_8 = {0x70,0x6F,0x73,0x74,0x44,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_10 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_9 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_12 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_13 = (new BEC_2_4_3_MathInt(8));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_14 = (new BEC_2_4_3_MathInt(4));
private static byte[] bece_BEC_2_6_10_SystemSerializer_bels_10 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x73,0x61,0x76,0x65,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x20,0x69,0x73,0x20,0x66,0x61,0x6C,0x73,0x65,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x64,0x65,0x73,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_15 = (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_16 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemSerializer_bevo_17 = (new BEC_2_4_3_MathInt(9));
public static new BEC_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_inst;

public static new BET_2_6_10_SystemSerializer bece_BEC_2_6_10_SystemSerializer_bevs_type;

public BEC_2_4_6_TextString bevp_group;
public BEC_2_4_6_TextString bevp_defineReference;
public BEC_2_4_6_TextString bevp_getReference;
public BEC_2_4_6_TextString bevp_constructString;
public BEC_2_4_6_TextString bevp_nullMark;
public BEC_2_4_6_TextString bevp_getClassTag;
public BEC_2_4_6_TextString bevp_shift;
public BEC_2_4_6_TextString bevp_defineClassTag;
public BEC_2_4_6_TextString bevp_multiNullMark;
public BEC_2_4_6_TextString bevp_endGroup;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_6_3_EncodeHex bevp_encoder;
public BEC_2_5_4_LogicBool bevp_saveIdentity;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_2));
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_3));
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_5));
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_6));
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_1));
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_4));
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_10_SystemSerializer_bels_0));
bem_new_10(bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph, bevt_6_ta_ph, bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_new_10(BEC_2_4_6_TextString beva__group, BEC_2_4_6_TextString beva__defineReference, BEC_2_4_6_TextString beva__getReference, BEC_2_4_6_TextString beva__constructString, BEC_2_4_6_TextString beva__nullMark, BEC_2_4_6_TextString beva__getClassTag, BEC_2_4_6_TextString beva__shift, BEC_2_4_6_TextString beva__defineClassTag, BEC_2_4_6_TextString beva__multiNullMark, BEC_2_4_6_TextString beva__endGroup) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
bevp_group = beva__group;
bevp_defineReference = beva__defineReference;
bevp_getReference = beva__getReference;
bevp_constructString = beva__constructString;
bevp_nullMark = beva__nullMark;
bevp_getClassTag = beva__getClassTag;
bevp_shift = beva__shift;
bevp_defineClassTag = beva__defineClassTag;
bevp_multiNullMark = beva__multiNullMark;
bevp_endGroup = beva__endGroup;
bevt_6_ta_ph = bevp_group.bem_add_1(bevp_defineReference);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_getReference);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevp_constructString);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_nullMark);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_defineClassTag);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_getClassTag);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_shift);
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_toker = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_7_ta_ph);
bevp_encoder = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevp_saveIdentity = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serialize_1(BEC_2_6_6_SystemObject beva_instance) {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_serialize_2(beva_instance, bevl_res);
return bevl_res;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serialize_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_instWriter) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_6_10_7_SystemSerializerSession bevt_1_ta_ph = null;
if (beva_instance == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 92*/ {
bevt_1_ta_ph = (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_1(beva_instWriter);
bem_serializeI_2(beva_instance, bevt_1_ta_ph);
} /* Line: 93*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeI_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bem_defineInstance_2(beva_instance, (BEC_3_6_10_7_SystemSerializerSession) beva_session );
bevt_0_ta_ph = beva_instance.bemd_0(1843544518);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 99*/ {
bem_serializeC_2(beva_instance, beva_session);
} /* Line: 100*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serializeC_2(BEC_2_6_6_SystemObject beva_instance, BEC_2_6_6_SystemObject beva_session) {
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_3_MathInt bevl_multiNull = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
bevl_instWriter = beva_session.bemd_0(-1875511872);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = beva_instance.bemd_0(-153156208);
bevt_0_ta_ph = bevl_iter.bemd_0(1091237859);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 108*/ {
bevl_instWriter.bemd_1(568704480, bevp_group);
while (true)
/* Line: 110*/ {
bevt_1_ta_ph = bevl_iter.bemd_0(1091237859);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 110*/ {
bevl_i = bevl_iter.bemd_0(1799618430);
if (bevl_i == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 112*/ {
bevl_multiNull = bevl_multiNull.bem_increment_0();
} /* Line: 114*/
 else /* Line: 115*/ {
bevt_4_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_0;
if (bevl_multiNull.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 117*/ {
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 119*/
 else /* Line: 117*/ {
bevt_6_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_1;
if (bevl_multiNull.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 120*/ {
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 123*/
 else /* Line: 117*/ {
bevt_8_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_2;
if (bevl_multiNull.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 124*/ {
bevl_instWriter.bemd_1(568704480, bevp_shift);
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevt_9_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(568704480, bevt_9_ta_ph);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 128*/
} /* Line: 117*/
} /* Line: 117*/
if (bevp_saveIdentity.bevi_bool) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 130*/ {
bevl_instSerial = null;
} /* Line: 131*/
 else /* Line: 132*/ {
bevt_11_ta_ph = beva_session.bemd_0(-1558191934);
bevl_instSerial = (BEC_2_4_3_MathInt) bevt_11_ta_ph.bemd_1(-1604611880, bevl_i);
} /* Line: 133*/
if (bevl_instSerial == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 135*/ {
bem_serializeI_2(bevl_i, beva_session);
} /* Line: 137*/
 else /* Line: 138*/ {
bevl_instWriter.bemd_1(568704480, bevp_getReference);
bevt_13_ta_ph = bevl_instSerial.bem_toString_0();
bevl_instWriter.bemd_1(568704480, bevt_13_ta_ph);
} /* Line: 141*/
} /* Line: 135*/
} /* Line: 112*/
 else /* Line: 110*/ {
break;
} /* Line: 110*/
} /* Line: 110*/
bevt_15_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_3;
if (bevl_multiNull.bevi_int == bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 146*/ {
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 148*/
 else /* Line: 146*/ {
bevt_17_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_4;
if (bevl_multiNull.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 149*/ {
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 152*/
 else /* Line: 146*/ {
bevt_19_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_5;
if (bevl_multiNull.bevi_int > bevt_19_ta_ph.bevi_int) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 153*/ {
bevl_instWriter.bemd_1(568704480, bevp_shift);
bevl_instWriter.bemd_1(568704480, bevp_nullMark);
bevt_20_ta_ph = bevl_multiNull.bem_toString_0();
bevl_instWriter.bemd_1(568704480, bevt_20_ta_ph);
bevl_multiNull = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 157*/
} /* Line: 146*/
} /* Line: 146*/
bevl_instWriter.bemd_1(568704480, bevp_shift);
bevl_instWriter.bemd_1(568704480, bevp_group);
} /* Line: 160*/
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineInstance_2(BEC_2_6_6_SystemObject beva_instance, BEC_3_6_10_7_SystemSerializerSession beva_session) {
BEC_2_4_3_MathInt bevl_scount = null;
BEC_2_6_6_SystemObject bevl_instWriter = null;
BEC_2_4_6_TextString bevl_instClass = null;
BEC_2_4_3_MathInt bevl_instClassTag = null;
BEC_2_4_6_TextString bevl_instClassTagStr = null;
BEC_2_4_6_TextString bevl_serializedString = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_9_11_ContainerIdentityMap bevt_13_ta_ph = null;
bevl_scount = beva_session.bem_serialCountGet_0();
bevt_2_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_6;
bevt_1_ta_ph = bevl_scount.bem_add_1(bevt_2_ta_ph);
beva_session.bem_serialCountSet_1(bevt_1_ta_ph);
bevl_instWriter = beva_session.bem_instWriterGet_0();
bevl_instClass = (BEC_2_4_6_TextString) beva_instance.bemd_0(-1262905199);
bevt_3_ta_ph = beva_session.bem_classTagMapGet_0();
bevl_instClassTag = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_get_1(bevl_instClass);
if (bevl_instClassTag == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 171*/ {
bevl_instClassTag = beva_session.bem_classTagCountGet_0();
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
bevt_6_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_7;
bevt_5_ta_ph = bevl_instClassTag.bem_add_1(bevt_6_ta_ph);
beva_session.bem_classTagCountSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = beva_session.bem_classTagMapGet_0();
bevt_7_ta_ph.bem_put_2(bevl_instClass, bevl_instClassTag);
bevl_instWriter.bemd_1(568704480, bevp_shift);
bevl_instWriter.bemd_1(568704480, bevp_defineClassTag);
bevl_instWriter.bemd_1(568704480, bevl_instClass);
bevl_instWriter.bemd_1(568704480, bevp_shift);
bevl_instWriter.bemd_1(568704480, bevp_defineClassTag);
bevl_instWriter.bemd_1(568704480, bevl_instClassTagStr);
} /* Line: 181*/
 else /* Line: 182*/ {
bevl_instClassTagStr = bevl_instClassTag.bem_toString_0();
} /* Line: 183*/
if (bevp_saveIdentity.bevi_bool)/* Line: 185*/ {
bevl_instWriter.bemd_1(568704480, bevp_defineReference);
bevt_8_ta_ph = bevl_scount.bem_toString_0();
bevl_instWriter.bemd_1(568704480, bevt_8_ta_ph);
} /* Line: 187*/
bevl_serializedString = (BEC_2_4_6_TextString) beva_instance.bemd_0(887739950);
if (bevl_serializedString == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_11_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_8;
bevt_10_ta_ph = bevl_serializedString.bem_notEquals_1(bevt_11_ta_ph);
if (bevt_10_ta_ph.bevi_bool)/* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 190*/
 else /* Line: 190*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 190*/ {
bevl_instWriter.bemd_1(568704480, bevp_constructString);
bevt_12_ta_ph = bevp_encoder.bem_encode_1(bevl_serializedString);
bevl_instWriter.bemd_1(568704480, bevt_12_ta_ph);
} /* Line: 192*/
bevl_instWriter.bemd_1(568704480, bevp_getClassTag);
bevl_instWriter.bemd_1(568704480, bevl_instClassTagStr);
if (bevp_saveIdentity.bevi_bool)/* Line: 196*/ {
bevt_13_ta_ph = beva_session.bem_uniqueGet_0();
bevt_13_ta_ph.bem_put_2(beva_instance, bevl_scount);
} /* Line: 197*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserialize_1(BEC_2_6_6_SystemObject beva_instReader) {
BEC_2_4_3_MathInt bevl_state = null;
BEC_2_9_4_ContainerList bevl_postDeserialize = null;
BEC_3_6_10_7_SystemSerializerSession bevl_session = null;
BEC_2_9_5_ContainerStack bevl_iterStack = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_9_3_ContainerMap bevl_instances = null;
BEC_2_6_6_SystemObject bevl_rootInst = null;
BEC_2_6_6_SystemObject bevl_groupInstIter = null;
BEC_2_4_6_TextString bevl_defineClassTagName = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_token = null;
BEC_2_4_3_MathInt bevl_instSerial = null;
BEC_2_4_6_TextString bevl_instString = null;
BEC_2_4_3_MathInt bevl_glassTagVal = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_6_6_SystemObject bevl_inst = null;
BEC_2_4_3_MathInt bevl_defineClassTagValue = null;
BEC_2_4_3_MathInt bevl_multiNullCount = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_9_SystemException bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_6_9_SystemException bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_postDeserialize = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_session = (BEC_3_6_10_7_SystemSerializerSession) (new BEC_3_6_10_7_SystemSerializerSession()).bem_new_0();
bevl_iterStack = (BEC_2_9_5_ContainerStack) (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_1_ta_ph = beva_instReader.bemd_1(1667241565, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 206*/ {
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(beva_instReader);
} /* Line: 207*/
 else /* Line: 208*/ {
bevt_4_ta_ph = beva_instReader.bemd_0(-117507549);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_toker.bem_tokenize_1(bevt_4_ta_ph);
} /* Line: 209*/
bevl_instances = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_i = bevl_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 215*/ {
bevt_5_ta_ph = bevl_i.bemd_0(1091237859);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 215*/ {
bevl_token = (BEC_2_4_6_TextString) bevl_i.bemd_0(1799618430);
bevt_7_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_9;
if (bevl_state.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_8_ta_ph = bevl_token.bem_equals_1(bevp_defineReference);
if (bevt_8_ta_ph.bevi_bool)/* Line: 218*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 219*/
 else /* Line: 218*/ {
bevt_9_ta_ph = bevl_token.bem_equals_1(bevp_constructString);
if (bevt_9_ta_ph.bevi_bool)/* Line: 220*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 221*/
 else /* Line: 218*/ {
bevt_10_ta_ph = bevl_token.bem_equals_1(bevp_getClassTag);
if (bevt_10_ta_ph.bevi_bool)/* Line: 222*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
} /* Line: 223*/
 else /* Line: 218*/ {
bevt_11_ta_ph = bevl_token.bem_equals_1(bevp_shift);
if (bevt_11_ta_ph.bevi_bool)/* Line: 224*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1000));
} /* Line: 225*/
 else /* Line: 218*/ {
bevt_12_ta_ph = bevl_token.bem_equals_1(bevp_getReference);
if (bevt_12_ta_ph.bevi_bool)/* Line: 226*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 227*/
 else /* Line: 218*/ {
bevt_13_ta_ph = bevl_token.bem_equals_1(bevp_nullMark);
if (bevt_13_ta_ph.bevi_bool)/* Line: 228*/ {
if (bevl_groupInstIter == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 230*/ {
bevl_groupInstIter.bemd_1(-7693770, null);
} /* Line: 231*/
} /* Line: 230*/
 else /* Line: 218*/ {
bevt_15_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_15_ta_ph.bevi_bool)/* Line: 233*/ {
if (bevl_inst == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 235*/ {
if (bevl_groupInstIter == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 236*/ {
bevl_iterStack.bem_push_1(bevl_groupInstIter);
} /* Line: 237*/
bevl_groupInstIter = bevl_inst.bemd_0(-153156208);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_6_10_SystemSerializer_bels_8));
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_18_ta_ph = bevl_groupInstIter.bemd_2(126363021, bevt_19_ta_ph, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 240*/ {
bevl_postDeserialize.bem_addValue_1(bevl_groupInstIter);
} /* Line: 241*/
} /* Line: 240*/
} /* Line: 235*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
} /* Line: 218*/
 else /* Line: 217*/ {
bevt_22_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_10;
if (bevl_state.bevi_int == bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 245*/ {
bevt_23_ta_ph = bevl_token.bem_equals_1(bevp_defineClassTag);
if (bevt_23_ta_ph.bevi_bool)/* Line: 247*/ {
if (bevl_defineClassTagName == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 248*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
} /* Line: 249*/
 else /* Line: 250*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
} /* Line: 251*/
} /* Line: 248*/
 else /* Line: 247*/ {
bevt_25_ta_ph = bevl_token.bem_equals_1(bevp_multiNullMark);
if (bevt_25_ta_ph.bevi_bool)/* Line: 253*/ {
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
} /* Line: 254*/
 else /* Line: 247*/ {
bevt_26_ta_ph = bevl_token.bem_equals_1(bevp_group);
if (bevt_26_ta_ph.bevi_bool)/* Line: 255*/ {
bevl_groupInstIter = bevl_iterStack.bem_pop_0();
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 258*/
} /* Line: 247*/
} /* Line: 247*/
} /* Line: 247*/
 else /* Line: 260*/ {
bevt_28_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_11;
if (bevl_state.bevi_int == bevt_28_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 261*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bece_BEC_2_6_10_SystemSerializer_bels_9));
bevt_30_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_31_ta_ph);
throw new be.BECS_ThrowBack(bevt_30_ta_ph);
} /* Line: 263*/
bevl_instSerial = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 266*/
 else /* Line: 261*/ {
bevt_33_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_12;
if (bevl_state.bevi_int == bevt_33_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 267*/ {
bevl_instString = bevp_encoder.bem_decode_1(bevl_token);
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 269*/
 else /* Line: 261*/ {
bevt_35_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_13;
if (bevl_state.bevi_int == bevt_35_ta_ph.bevi_int) {
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 270*/ {
bevl_glassTagVal = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_36_ta_ph = bevl_session.bem_classTagMapGet_0();
bevl_klass = (BEC_2_4_6_TextString) bevt_36_ta_ph.bem_get_1(bevl_glassTagVal);
bevt_38_ta_ph = bem_createInstance_1(bevl_klass);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(-846214228, bevl_instString);
bevl_inst = bevt_37_ta_ph.bemd_1(1178658080, bevl_instString);
if (bevl_rootInst == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 274*/ {
bevl_rootInst = bevl_inst;
} /* Line: 275*/
if (bevp_saveIdentity.bevi_bool)/* Line: 277*/ {
bevl_instances.bem_put_2(bevl_instSerial, bevl_inst);
} /* Line: 278*/
bevl_instString = null;
if (bevl_groupInstIter == null) {
bevt_40_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_40_ta_ph.bevi_bool)/* Line: 282*/ {
bevl_groupInstIter.bemd_1(-7693770, bevl_inst);
} /* Line: 283*/
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 285*/
 else /* Line: 261*/ {
bevt_42_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_14;
if (bevl_state.bevi_int == bevt_42_ta_ph.bevi_int) {
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 286*/ {
if (bevp_saveIdentity.bevi_bool) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(66, bece_BEC_2_6_10_SystemSerializer_bels_10));
bevt_44_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_45_ta_ph);
throw new be.BECS_ThrowBack(bevt_44_ta_ph);
} /* Line: 288*/
bevl_instSerial = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_inst = bevl_instances.bem_get_1(bevl_instSerial);
if (bevl_groupInstIter == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 292*/ {
bevl_groupInstIter.bemd_1(-7693770, bevl_inst);
} /* Line: 293*/
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 295*/
 else /* Line: 261*/ {
bevt_48_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_15;
if (bevl_state.bevi_int == bevt_48_ta_ph.bevi_int) {
bevt_47_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_47_ta_ph.bevi_bool)/* Line: 296*/ {
bevl_defineClassTagName = bevl_token;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 298*/
 else /* Line: 261*/ {
bevt_50_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_16;
if (bevl_state.bevi_int == bevt_50_ta_ph.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 299*/ {
bevl_defineClassTagValue = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevt_51_ta_ph = bevl_session.bem_classTagMapGet_0();
bevt_51_ta_ph.bem_put_2(bevl_defineClassTagValue, bevl_defineClassTagName);
bevl_defineClassTagName = null;
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 304*/
 else /* Line: 261*/ {
bevt_53_ta_ph = bece_BEC_2_6_10_SystemSerializer_bevo_17;
if (bevl_state.bevi_int == bevt_53_ta_ph.bevi_int) {
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 305*/ {
if (bevl_groupInstIter == null) {
bevt_54_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_54_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_54_ta_ph.bevi_bool)/* Line: 307*/ {
bevl_multiNullCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_token);
bevl_groupInstIter.bemd_1(-940674272, bevl_multiNullCount);
} /* Line: 309*/
bevl_state = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 311*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 261*/
} /* Line: 217*/
} /* Line: 217*/
 else /* Line: 215*/ {
break;
} /* Line: 215*/
} /* Line: 215*/
bevl_inst = null;
bevt_0_ta_loop = bevl_postDeserialize.bem_iteratorGet_0();
while (true)
/* Line: 316*/ {
bevt_55_ta_ph = bevt_0_ta_loop.bemd_0(1091237859);
if (((BEC_2_5_4_LogicBool) bevt_55_ta_ph).bevi_bool)/* Line: 316*/ {
bevl_groupInstIter = bevt_0_ta_loop.bemd_0(1799618430);
bevl_groupInstIter.bemd_0(-1222257752);
} /* Line: 317*/
 else /* Line: 316*/ {
break;
} /* Line: 316*/
} /* Line: 316*/
return bevl_rootInst;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGet_0() {
return bevp_group;
} /*method end*/
public BEC_2_4_6_TextString bem_groupGetDirect_0() {
return bevp_group;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_groupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_group = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGet_0() {
return bevp_defineReference;
} /*method end*/
public BEC_2_4_6_TextString bem_defineReferenceGetDirect_0() {
return bevp_defineReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGet_0() {
return bevp_getReference;
} /*method end*/
public BEC_2_4_6_TextString bem_getReferenceGetDirect_0() {
return bevp_getReference;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getReferenceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getReference = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGet_0() {
return bevp_constructString;
} /*method end*/
public BEC_2_4_6_TextString bem_constructStringGetDirect_0() {
return bevp_constructString;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_constructStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constructString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGet_0() {
return bevp_nullMark;
} /*method end*/
public BEC_2_4_6_TextString bem_nullMarkGetDirect_0() {
return bevp_nullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_nullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGet_0() {
return bevp_getClassTag;
} /*method end*/
public BEC_2_4_6_TextString bem_getClassTagGetDirect_0() {
return bevp_getClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_getClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_getClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGet_0() {
return bevp_shift;
} /*method end*/
public BEC_2_4_6_TextString bem_shiftGetDirect_0() {
return bevp_shift;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_shiftSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shift = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGet_0() {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_4_6_TextString bem_defineClassTagGetDirect_0() {
return bevp_defineClassTag;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_defineClassTagSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defineClassTag = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGet_0() {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_4_6_TextString bem_multiNullMarkGetDirect_0() {
return bevp_multiNullMark;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_multiNullMarkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multiNullMark = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGet_0() {
return bevp_endGroup;
} /*method end*/
public BEC_2_4_6_TextString bem_endGroupGetDirect_0() {
return bevp_endGroup;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_endGroupSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_endGroup = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGet_0() {
return bevp_toker;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() {
return bevp_toker;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGet_0() {
return bevp_encoder;
} /*method end*/
public BEC_2_6_3_EncodeHex bem_encoderGetDirect_0() {
return bevp_encoder;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_encoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_encoder = (BEC_2_6_3_EncodeHex) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGet_0() {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdentityGetDirect_0() {
return bevp_saveIdentity;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_saveIdentitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIdentity = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 77, 77, 77, 77, 77, 77, 77, 78, 76, 80, 81, 86, 87, 88, 92, 92, 93, 93, 98, 99, 100, 105, 106, 107, 108, 109, 110, 111, 112, 112, 114, 117, 117, 117, 118, 119, 120, 120, 120, 121, 122, 123, 124, 124, 124, 125, 126, 127, 127, 128, 130, 130, 131, 133, 133, 135, 135, 137, 140, 141, 141, 146, 146, 146, 147, 148, 149, 149, 149, 150, 151, 152, 153, 153, 153, 154, 155, 156, 156, 157, 159, 160, 165, 166, 166, 166, 168, 169, 170, 170, 171, 171, 172, 173, 174, 174, 174, 175, 175, 176, 177, 178, 179, 180, 181, 183, 186, 187, 187, 189, 190, 190, 190, 190, 0, 0, 0, 191, 192, 192, 194, 195, 197, 197, 202, 203, 204, 205, 206, 206, 206, 207, 209, 209, 211, 215, 215, 216, 217, 217, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 230, 230, 231, 233, 235, 235, 236, 236, 237, 239, 240, 240, 240, 241, 245, 245, 245, 247, 248, 248, 249, 251, 253, 254, 255, 257, 258, 261, 261, 261, 262, 262, 263, 263, 263, 265, 266, 267, 267, 267, 268, 269, 270, 270, 270, 271, 272, 272, 273, 273, 273, 274, 274, 275, 278, 280, 282, 282, 283, 285, 286, 286, 286, 287, 287, 288, 288, 288, 290, 291, 292, 292, 293, 295, 296, 296, 296, 297, 298, 299, 299, 299, 301, 302, 302, 303, 304, 305, 305, 305, 307, 307, 308, 309, 311, 315, 316, 0, 316, 316, 317, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 112, 113, 114, 119, 124, 125, 126, 132, 133, 135, 166, 167, 168, 169, 171, 174, 176, 177, 182, 183, 186, 187, 192, 193, 194, 197, 198, 203, 204, 205, 206, 209, 210, 215, 216, 217, 218, 219, 220, 224, 229, 230, 233, 234, 236, 241, 242, 245, 246, 247, 255, 256, 261, 262, 263, 266, 267, 272, 273, 274, 275, 278, 279, 284, 285, 286, 287, 288, 289, 293, 294, 319, 320, 321, 322, 323, 324, 325, 326, 327, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 348, 351, 352, 353, 355, 356, 361, 362, 363, 365, 368, 372, 375, 376, 377, 379, 380, 382, 383, 462, 463, 464, 465, 466, 467, 468, 470, 473, 474, 476, 477, 480, 482, 483, 484, 489, 490, 492, 495, 497, 500, 502, 505, 507, 510, 512, 515, 517, 522, 523, 527, 529, 534, 535, 540, 541, 543, 544, 545, 546, 548, 560, 561, 566, 567, 569, 574, 575, 578, 582, 584, 587, 589, 590, 596, 597, 602, 603, 608, 609, 610, 611, 613, 614, 617, 618, 623, 624, 625, 628, 629, 634, 635, 636, 637, 638, 639, 640, 641, 646, 647, 650, 652, 653, 658, 659, 661, 664, 665, 670, 671, 676, 677, 678, 679, 681, 682, 683, 688, 689, 691, 694, 695, 700, 701, 702, 705, 706, 711, 712, 713, 714, 715, 716, 719, 720, 725, 726, 731, 732, 733, 735, 750, 751, 751, 754, 756, 757, 763, 766, 769, 772, 776, 780, 783, 786, 790, 794, 797, 800, 804, 808, 811, 814, 818, 822, 825, 828, 832, 836, 839, 842, 846, 850, 853, 856, 860, 864, 867, 870, 874, 878, 881, 884, 888, 892, 895, 898, 902, 906, 909, 912, 916, 920, 923, 926, 930, 934, 937, 940, 944};
/* BEGIN LINEINFO 
assign 1 60 65
new 0 60 65
assign 1 60 66
new 0 60 66
assign 1 60 67
new 0 60 67
assign 1 60 68
new 0 60 68
assign 1 60 69
new 0 60 69
assign 1 60 70
new 0 60 70
assign 1 60 71
new 0 60 71
assign 1 60 72
new 0 60 72
assign 1 60 73
new 0 60 73
assign 1 60 74
new 0 60 74
new 10 60 75
assign 1 66 87
assign 1 67 88
assign 1 68 89
assign 1 69 90
assign 1 70 91
assign 1 71 92
assign 1 72 93
assign 1 73 94
assign 1 74 95
assign 1 75 96
assign 1 77 97
add 1 77 97
assign 1 77 98
add 1 77 98
assign 1 77 99
add 1 77 99
assign 1 77 100
add 1 77 100
assign 1 77 101
add 1 77 101
assign 1 77 102
add 1 77 102
assign 1 77 103
add 1 77 103
assign 1 78 104
new 0 78 104
assign 1 76 105
new 2 76 105
assign 1 80 106
new 0 80 106
assign 1 81 107
new 0 81 107
assign 1 86 112
new 0 86 112
serialize 2 87 113
return 1 88 114
assign 1 92 119
def 1 92 124
assign 1 93 125
new 1 93 125
serializeI 2 93 126
defineInstance 2 98 132
assign 1 99 133
serializeContents 0 99 133
serializeC 2 100 135
assign 1 105 166
instWriterGet 0 105 166
assign 1 106 167
new 0 106 167
assign 1 107 168
serializationIteratorGet 0 107 168
assign 1 108 169
hasNextGet 0 108 169
write 1 109 171
assign 1 110 174
hasNextGet 0 110 174
assign 1 111 176
nextGet 0 111 176
assign 1 112 177
undef 1 112 182
assign 1 114 183
increment 0 114 183
assign 1 117 186
new 0 117 186
assign 1 117 187
equals 1 117 192
write 1 118 193
assign 1 119 194
new 0 119 194
assign 1 120 197
new 0 120 197
assign 1 120 198
equals 1 120 203
write 1 121 204
write 1 122 205
assign 1 123 206
new 0 123 206
assign 1 124 209
new 0 124 209
assign 1 124 210
greater 1 124 215
write 1 125 216
write 1 126 217
assign 1 127 218
toString 0 127 218
write 1 127 219
assign 1 128 220
new 0 128 220
assign 1 130 224
not 0 130 229
assign 1 131 230
assign 1 133 233
uniqueGet 0 133 233
assign 1 133 234
get 1 133 234
assign 1 135 236
undef 1 135 241
serializeI 2 137 242
write 1 140 245
assign 1 141 246
toString 0 141 246
write 1 141 247
assign 1 146 255
new 0 146 255
assign 1 146 256
equals 1 146 261
write 1 147 262
assign 1 148 263
new 0 148 263
assign 1 149 266
new 0 149 266
assign 1 149 267
equals 1 149 272
write 1 150 273
write 1 151 274
assign 1 152 275
new 0 152 275
assign 1 153 278
new 0 153 278
assign 1 153 279
greater 1 153 284
write 1 154 285
write 1 155 286
assign 1 156 287
toString 0 156 287
write 1 156 288
assign 1 157 289
new 0 157 289
write 1 159 293
write 1 160 294
assign 1 165 319
serialCountGet 0 165 319
assign 1 166 320
new 0 166 320
assign 1 166 321
add 1 166 321
serialCountSet 1 166 322
assign 1 168 323
instWriterGet 0 168 323
assign 1 169 324
deserializeClassNameGet 0 169 324
assign 1 170 325
classTagMapGet 0 170 325
assign 1 170 326
get 1 170 326
assign 1 171 327
undef 1 171 332
assign 1 172 333
classTagCountGet 0 172 333
assign 1 173 334
toString 0 173 334
assign 1 174 335
new 0 174 335
assign 1 174 336
add 1 174 336
classTagCountSet 1 174 337
assign 1 175 338
classTagMapGet 0 175 338
put 2 175 339
write 1 176 340
write 1 177 341
write 1 178 342
write 1 179 343
write 1 180 344
write 1 181 345
assign 1 183 348
toString 0 183 348
write 1 186 351
assign 1 187 352
toString 0 187 352
write 1 187 353
assign 1 189 355
serializeToString 0 189 355
assign 1 190 356
def 1 190 361
assign 1 190 362
new 0 190 362
assign 1 190 363
notEquals 1 190 363
assign 1 0 365
assign 1 0 368
assign 1 0 372
write 1 191 375
assign 1 192 376
encode 1 192 376
write 1 192 377
write 1 194 379
write 1 195 380
assign 1 197 382
uniqueGet 0 197 382
put 2 197 383
assign 1 202 462
new 0 202 462
assign 1 203 463
new 0 203 463
assign 1 204 464
new 0 204 464
assign 1 205 465
new 0 205 465
assign 1 206 466
new 0 206 466
assign 1 206 467
emptyGet 0 206 467
assign 1 206 468
sameType 1 206 468
assign 1 207 470
tokenize 1 207 470
assign 1 209 473
readString 0 209 473
assign 1 209 474
tokenize 1 209 474
assign 1 211 476
new 0 211 476
assign 1 215 477
linkedListIteratorGet 0 215 477
assign 1 215 480
hasNextGet 0 215 480
assign 1 216 482
nextGet 0 216 482
assign 1 217 483
new 0 217 483
assign 1 217 484
equals 1 217 489
assign 1 218 490
equals 1 218 490
assign 1 219 492
new 0 219 492
assign 1 220 495
equals 1 220 495
assign 1 221 497
new 0 221 497
assign 1 222 500
equals 1 222 500
assign 1 223 502
new 0 223 502
assign 1 224 505
equals 1 224 505
assign 1 225 507
new 0 225 507
assign 1 226 510
equals 1 226 510
assign 1 227 512
new 0 227 512
assign 1 228 515
equals 1 228 515
assign 1 230 517
def 1 230 522
nextSet 1 231 523
assign 1 233 527
equals 1 233 527
assign 1 235 529
def 1 235 534
assign 1 236 535
def 1 236 540
push 1 237 541
assign 1 239 543
serializationIteratorGet 0 239 543
assign 1 240 544
new 0 240 544
assign 1 240 545
new 0 240 545
assign 1 240 546
can 2 240 546
addValue 1 241 548
assign 1 245 560
new 0 245 560
assign 1 245 561
equals 1 245 566
assign 1 247 567
equals 1 247 567
assign 1 248 569
undef 1 248 574
assign 1 249 575
new 0 249 575
assign 1 251 578
new 0 251 578
assign 1 253 582
equals 1 253 582
assign 1 254 584
new 0 254 584
assign 1 255 587
equals 1 255 587
assign 1 257 589
pop 0 257 589
assign 1 258 590
new 0 258 590
assign 1 261 596
new 0 261 596
assign 1 261 597
equals 1 261 602
assign 1 262 603
not 0 262 608
assign 1 263 609
new 0 263 609
assign 1 263 610
new 1 263 610
throw 1 263 611
assign 1 265 613
new 1 265 613
assign 1 266 614
new 0 266 614
assign 1 267 617
new 0 267 617
assign 1 267 618
equals 1 267 623
assign 1 268 624
decode 1 268 624
assign 1 269 625
new 0 269 625
assign 1 270 628
new 0 270 628
assign 1 270 629
equals 1 270 634
assign 1 271 635
new 1 271 635
assign 1 272 636
classTagMapGet 0 272 636
assign 1 272 637
get 1 272 637
assign 1 273 638
createInstance 1 273 638
assign 1 273 639
deserializeFromStringNew 1 273 639
assign 1 273 640
deserializeFromString 1 273 640
assign 1 274 641
undef 1 274 646
assign 1 275 647
put 2 278 650
assign 1 280 652
assign 1 282 653
def 1 282 658
nextSet 1 283 659
assign 1 285 661
new 0 285 661
assign 1 286 664
new 0 286 664
assign 1 286 665
equals 1 286 670
assign 1 287 671
not 0 287 676
assign 1 288 677
new 0 288 677
assign 1 288 678
new 1 288 678
throw 1 288 679
assign 1 290 681
new 1 290 681
assign 1 291 682
get 1 291 682
assign 1 292 683
def 1 292 688
nextSet 1 293 689
assign 1 295 691
new 0 295 691
assign 1 296 694
new 0 296 694
assign 1 296 695
equals 1 296 700
assign 1 297 701
assign 1 298 702
new 0 298 702
assign 1 299 705
new 0 299 705
assign 1 299 706
equals 1 299 711
assign 1 301 712
new 1 301 712
assign 1 302 713
classTagMapGet 0 302 713
put 2 302 714
assign 1 303 715
assign 1 304 716
new 0 304 716
assign 1 305 719
new 0 305 719
assign 1 305 720
equals 1 305 725
assign 1 307 726
def 1 307 731
assign 1 308 732
new 1 308 732
skip 1 309 733
assign 1 311 735
new 0 311 735
assign 1 315 750
assign 1 316 751
iteratorGet 0 0 751
assign 1 316 754
hasNextGet 0 316 754
assign 1 316 756
nextGet 0 316 756
postDeserialize 0 317 757
return 1 319 763
return 1 0 766
return 1 0 769
assign 1 0 772
assign 1 0 776
return 1 0 780
return 1 0 783
assign 1 0 786
assign 1 0 790
return 1 0 794
return 1 0 797
assign 1 0 800
assign 1 0 804
return 1 0 808
return 1 0 811
assign 1 0 814
assign 1 0 818
return 1 0 822
return 1 0 825
assign 1 0 828
assign 1 0 832
return 1 0 836
return 1 0 839
assign 1 0 842
assign 1 0 846
return 1 0 850
return 1 0 853
assign 1 0 856
assign 1 0 860
return 1 0 864
return 1 0 867
assign 1 0 870
assign 1 0 874
return 1 0 878
return 1 0 881
assign 1 0 884
assign 1 0 888
return 1 0 892
return 1 0 895
assign 1 0 898
assign 1 0 902
return 1 0 906
return 1 0 909
assign 1 0 912
assign 1 0 916
return 1 0 920
return 1 0 923
assign 1 0 926
assign 1 0 930
return 1 0 934
return 1 0 937
assign 1 0 940
assign 1 0 944
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1198763281: return bem_getReferenceGetDirect_0();
case 298152866: return bem_getClassTagGet_0();
case 31758106: return bem_groupGetDirect_0();
case -2129983068: return bem_toAny_0();
case 1306734605: return bem_nullMarkGet_0();
case -1620241576: return bem_groupGet_0();
case -1471688827: return bem_getClassTagGetDirect_0();
case 879975179: return bem_classNameGet_0();
case -1017761794: return bem_saveIdentityGetDirect_0();
case -1651994031: return bem_getReferenceGet_0();
case 416632967: return bem_endGroupGetDirect_0();
case -1166358053: return bem_shiftGet_0();
case -1084228149: return bem_print_0();
case 1843544518: return bem_serializeContents_0();
case -153156208: return bem_serializationIteratorGet_0();
case -1588532100: return bem_echo_0();
case 244835657: return bem_defineClassTagGet_0();
case 162533386: return bem_fieldNamesGet_0();
case -900342017: return bem_constructStringGetDirect_0();
case 233362262: return bem_many_0();
case 887739950: return bem_serializeToString_0();
case -576606140: return bem_multiNullMarkGet_0();
case 718635374: return bem_tokerGet_0();
case -1198993305: return bem_defineReferenceGet_0();
case -110068459: return bem_encoderGet_0();
case 110382217: return bem_sourceFileNameGet_0();
case 543983438: return bem_nullMarkGetDirect_0();
case 2071597061: return bem_create_0();
case 769443612: return bem_multiNullMarkGetDirect_0();
case 1989693945: return bem_toString_0();
case 888041456: return bem_tagGet_0();
case 123098580: return bem_saveIdentityGet_0();
case 714460463: return bem_once_0();
case -183049389: return bem_tokerGetDirect_0();
case -1947471791: return bem_shiftGetDirect_0();
case 1105152133: return bem_new_0();
case 357289889: return bem_defineReferenceGetDirect_0();
case -814889959: return bem_endGroupGet_0();
case 1330536458: return bem_encoderGetDirect_0();
case 1986590366: return bem_hashGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case -893186176: return bem_constructStringGet_0();
case -1632464134: return bem_defineClassTagGetDirect_0();
case 1732513565: return bem_copy_0();
case 1383646476: return bem_iteratorGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1361940521: return bem_tokerSet_1(bevd_0);
case -830979728: return bem_getClassTagSet_1(bevd_0);
case 113086579: return bem_serialize_1(bevd_0);
case -456968726: return bem_nullMarkSet_1(bevd_0);
case -1886440569: return bem_constructStringSetDirect_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -84465750: return bem_defineClassTagSetDirect_1(bevd_0);
case 864433802: return bem_endGroupSet_1(bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 451160433: return bem_groupSetDirect_1(bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 1029956488: return bem_shiftSetDirect_1(bevd_0);
case -493029314: return bem_multiNullMarkSet_1(bevd_0);
case -244672718: return bem_getReferenceSetDirect_1(bevd_0);
case 1522095539: return bem_constructStringSet_1(bevd_0);
case 911555243: return bem_defineReferenceSetDirect_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case 1792481033: return bem_defineClassTagSet_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case 1370958627: return bem_saveIdentitySet_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1834634347: return bem_encoderSet_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case -1962009975: return bem_deserialize_1(bevd_0);
case 1889214515: return bem_tokerSetDirect_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case 583291895: return bem_shiftSet_1(bevd_0);
case -1346034833: return bem_multiNullMarkSetDirect_1(bevd_0);
case -871185505: return bem_saveIdentitySetDirect_1(bevd_0);
case 1096112827: return bem_endGroupSetDirect_1(bevd_0);
case 185221574: return bem_getReferenceSet_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case -1477983858: return bem_encoderSetDirect_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case -2036432339: return bem_nullMarkSetDirect_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -741066589: return bem_groupSet_1(bevd_0);
case -1763749286: return bem_getClassTagSetDirect_1(bevd_0);
case 1529199228: return bem_defineReferenceSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1541327486: return bem_serializeC_2(bevd_0, bevd_1);
case -231541291: return bem_serializeI_2(bevd_0, bevd_1);
case 1394700235: return bem_defineInstance_2(bevd_0, (BEC_3_6_10_7_SystemSerializerSession) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -907076590: return bem_serialize_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_x(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5, BEC_2_6_6_SystemObject bevd_6, BEC_2_6_6_SystemObject[] bevd_x) {
switch (callId) {
case -1356102942: return bem_new_10((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4, (BEC_2_4_6_TextString) bevd_5, (BEC_2_4_6_TextString) bevd_6, (BEC_2_4_6_TextString) bevd_x[0], (BEC_2_4_6_TextString) bevd_x[1], (BEC_2_4_6_TextString) bevd_x[2]);
}
return base.bemd_x(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5, bevd_6, bevd_x);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemSerializer_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_10_SystemSerializer_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemSerializer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst = (BEC_2_6_10_SystemSerializer) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemSerializer.bece_BEC_2_6_10_SystemSerializer_bevs_type;
}
}
}
