namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_10_TestAssertions : BEC_2_6_6_SystemObject {
public BEC_2_4_10_TestAssertions() { }
static BEC_2_4_10_TestAssertions() { }
private static byte[] becc_BEC_2_4_10_TestAssertions_clname = {0x54,0x65,0x73,0x74,0x3A,0x41,0x73,0x73,0x65,0x72,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_2_4_10_TestAssertions_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_0 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_1 = {0x20,0x68,0x61,0x76,0x65,0x72,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_2 = {0x20,0x68,0x61,0x76,0x65,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_3 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x61,0x6E,0x6F,0x74,0x68,0x65,0x72,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x64,0x6F,0x65,0x73};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_4 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_5 = {0x7C,0x6E,0x75,0x6C,0x6C,0x7C};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_6 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_6, 36));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_7 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_10_TestAssertions_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_10_TestAssertions_bels_7, 1));
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_8 = {0x56,0x61,0x6C,0x75,0x65,0x73,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x55,0x4E,0x45,0x51,0x55,0x41,0x4C,0x20,0x61,0x72,0x65,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_9 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_10 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x4E,0x4F,0x54,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_11 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x54,0x52,0x55,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
private static byte[] bece_BEC_2_4_10_TestAssertions_bels_12 = {0x56,0x61,0x6C,0x75,0x65,0x20,0x77,0x68,0x69,0x63,0x68,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x46,0x41,0x4C,0x53,0x45,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74};
public static new BEC_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_inst;

public static new BET_2_4_10_TestAssertions bece_BEC_2_4_10_TestAssertions_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_10_tmpany_phold = null;
bevt_2_tmpany_phold = beva_v1.bemd_1(-1323914976, beva_v2);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1636905789);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 26 */ {
bevl_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_0));
if (beva_v1 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 28 */ {
if (beva_v2 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 28 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 28 */
 else  /* Line: 28 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 28 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_msg.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_v1);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 29 */
bevt_10_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 31 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotHas_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_msg = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v1.bemd_1(-1323914976, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 35 */ {
bevl_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_4_10_TestAssertions_bels_3));
if (beva_v1 == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 37 */ {
if (beva_v2 == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 37 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 37 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_1));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_msg.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(beva_v1);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_4_10_TestAssertions_bels_2));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(beva_v2);
} /* Line: 38 */
bevt_9_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevl_msg);
throw new be.BECS_ThrowBack(bevt_9_tmpany_phold);
} /* Line: 40 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_assertEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_10_TestAssertions) bem_assertEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_assertNotEquals_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_10_TestAssertions bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_10_TestAssertions) bem_assertNotEqual_2(beva_v1, beva_v2);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_4_6_TextString bevl_v1v = null;
BEC_2_4_6_TextString bevl_v2v = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (beva_v1 == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bece_BEC_2_4_10_TestAssertions_bels_4));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 51 */
bevt_3_tmpany_phold = beva_v1.bemd_1(-458239489, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 53 */ {
if (beva_v1 == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevl_v1v = (BEC_2_4_6_TextString) beva_v1.bemd_0(996718380);
} /* Line: 55 */
 else  /* Line: 56 */ {
bevl_v1v = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_5));
} /* Line: 57 */
if (beva_v2 == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevl_v2v = (BEC_2_4_6_TextString) beva_v2.bemd_0(996718380);
} /* Line: 60 */
 else  /* Line: 61 */ {
bevl_v2v = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_10_TestAssertions_bels_5));
} /* Line: 62 */
bevt_10_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_0;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_v1v);
bevt_11_tmpany_phold = bece_BEC_2_4_10_TestAssertions_bevo_1;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_v2v);
bevt_6_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 64 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotEqual_2(BEC_2_6_6_SystemObject beva_v1, BEC_2_6_6_SystemObject beva_v2) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v1.bemd_1(1570647300, beva_v2);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 68 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_4_10_TestAssertions_bels_8));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 69 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_9));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 74 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertIsNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_9));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 79 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertNotNull_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_v == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_4_10_TestAssertions_bels_10));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 84 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertTrue_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TestFailure bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bemd_0(1636905789);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_10_TestAssertions_bels_11));
bevt_1_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 89 */
return this;
} /*method end*/
public virtual BEC_2_4_10_TestAssertions bem_assertFalse_1(BEC_2_6_6_SystemObject beva_v) {
BEC_2_4_7_TestFailure bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (((BEC_2_5_4_LogicBool) beva_v).bevi_bool) /* Line: 93 */ {
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_4_10_TestAssertions_bels_12));
bevt_0_tmpany_phold = (BEC_2_4_7_TestFailure) (new BEC_2_4_7_TestFailure()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 94 */
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {26, 26, 27, 28, 28, 28, 28, 0, 0, 0, 29, 29, 29, 29, 29, 29, 31, 31, 35, 36, 37, 37, 37, 37, 0, 0, 0, 38, 38, 38, 38, 38, 38, 40, 40, 44, 44, 47, 47, 50, 50, 51, 51, 51, 53, 54, 54, 55, 57, 59, 59, 60, 62, 64, 64, 64, 64, 64, 64, 64, 68, 69, 69, 69, 73, 73, 74, 74, 74, 78, 78, 79, 79, 79, 83, 83, 84, 84, 84, 88, 89, 89, 89, 94, 94, 94};
public static new int[] bevs_smnlec
 = new int[] {46, 47, 49, 50, 55, 56, 61, 62, 65, 69, 72, 73, 74, 75, 76, 77, 79, 80, 96, 98, 99, 104, 105, 110, 111, 114, 118, 121, 122, 123, 124, 125, 126, 128, 129, 135, 136, 140, 141, 158, 163, 164, 165, 166, 168, 170, 175, 176, 179, 181, 186, 187, 190, 192, 193, 194, 195, 196, 197, 198, 206, 208, 209, 210, 218, 223, 224, 225, 226, 234, 239, 240, 241, 242, 250, 255, 256, 257, 258, 266, 268, 269, 270, 278, 279, 280};
/* BEGIN LINEINFO 
assign 1 26 46
has 1 26 46
assign 1 26 47
not 0 26 47
assign 1 27 49
new 0 27 49
assign 1 28 50
def 1 28 55
assign 1 28 56
def 1 28 61
assign 1 0 62
assign 1 0 65
assign 1 0 69
assign 1 29 72
new 0 29 72
assign 1 29 73
addValue 1 29 73
assign 1 29 74
addValue 1 29 74
assign 1 29 75
new 0 29 75
assign 1 29 76
addValue 1 29 76
addValue 1 29 77
assign 1 31 79
new 1 31 79
throw 1 31 80
assign 1 35 96
has 1 35 96
assign 1 36 98
new 0 36 98
assign 1 37 99
def 1 37 104
assign 1 37 105
def 1 37 110
assign 1 0 111
assign 1 0 114
assign 1 0 118
assign 1 38 121
new 0 38 121
assign 1 38 122
addValue 1 38 122
assign 1 38 123
addValue 1 38 123
assign 1 38 124
new 0 38 124
assign 1 38 125
addValue 1 38 125
addValue 1 38 126
assign 1 40 128
new 1 40 128
throw 1 40 129
assign 1 44 135
assertEqual 2 44 135
return 1 44 136
assign 1 47 140
assertNotEqual 2 47 140
return 1 47 141
assign 1 50 158
undef 1 50 163
assign 1 51 164
new 0 51 164
assign 1 51 165
new 1 51 165
throw 1 51 166
assign 1 53 168
notEquals 1 53 168
assign 1 54 170
def 1 54 175
assign 1 55 176
toString 0 55 176
assign 1 57 179
new 0 57 179
assign 1 59 181
def 1 59 186
assign 1 60 187
toString 0 60 187
assign 1 62 190
new 0 62 190
assign 1 64 192
new 0 64 192
assign 1 64 193
add 1 64 193
assign 1 64 194
new 0 64 194
assign 1 64 195
add 1 64 195
assign 1 64 196
add 1 64 196
assign 1 64 197
new 1 64 197
throw 1 64 198
assign 1 68 206
equals 1 68 206
assign 1 69 208
new 0 69 208
assign 1 69 209
new 1 69 209
throw 1 69 210
assign 1 73 218
def 1 73 223
assign 1 74 224
new 0 74 224
assign 1 74 225
new 1 74 225
throw 1 74 226
assign 1 78 234
def 1 78 239
assign 1 79 240
new 0 79 240
assign 1 79 241
new 1 79 241
throw 1 79 242
assign 1 83 250
undef 1 83 255
assign 1 84 256
new 0 84 256
assign 1 84 257
new 1 84 257
throw 1 84 258
assign 1 88 266
not 0 88 266
assign 1 89 268
new 0 89 268
assign 1 89 269
new 1 89 269
throw 1 89 270
assign 1 94 278
new 0 94 278
assign 1 94 279
new 1 94 279
throw 1 94 280
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1852877275: return bem_new_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -236887613: return bem_classNameGet_0();
case 1076647192: return bem_create_0();
case -2092760709: return bem_once_0();
case 1359360249: return bem_echo_0();
case 1064677251: return bem_many_0();
case 605836827: return bem_sourceFileNameGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 928457034: return bem_serializeContents_0();
case -1430066973: return bem_print_0();
case -323661464: return bem_serializeToString_0();
case 849387251: return bem_toAny_0();
case 1910979786: return bem_default_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
case 996718380: return bem_toString_0();
case -1369483363: return bem_fieldNamesGet_0();
case 864393987: return bem_tagGet_0();
case 2070502838: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -960159496: return bem_otherClass_1(bevd_0);
case -1044828842: return bem_assertNull_1(bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case -1376276932: return bem_assertNotNull_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1541829658: return bem_assertTrue_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -930360359: return bem_assertIsNull_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -607225837: return bem_assertFalse_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -325185720: return bem_assertEquals_2(bevd_0, bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1153334514: return bem_assertNotEqual_2(bevd_0, bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 66545439: return bem_assertEqual_2(bevd_0, bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1609093490: return bem_assertNotEquals_2(bevd_0, bevd_1);
case 1420657331: return bem_assertHas_2(bevd_0, bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 600439848: return bem_assertNotHas_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_TestAssertions_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_10_TestAssertions_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_10_TestAssertions();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst = (BEC_2_4_10_TestAssertions) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_10_TestAssertions.bece_BEC_2_4_10_TestAssertions_bevs_type;
}
}
}
