namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerSets : BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerSets() { }
static BEC_2_9_4_ContainerSets() { }
private static byte[] becc_BEC_2_9_4_ContainerSets_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x73};
private static byte[] becc_BEC_2_9_4_ContainerSets_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerSets_bevo_0 = (new BEC_2_4_3_MathInt(2));
public static new BEC_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_inst;

public static new BET_2_9_4_ContainerSets bece_BEC_2_9_4_ContainerSets_bevs_type;

public virtual BEC_2_9_4_ContainerSets bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_9_3_ContainerSet bevl_set = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = beva_list.bem_sizeGet_0();
bevt_2_ta_ph = bece_BEC_2_9_4_ContainerSets_bevo_0;
bevl_ssz = bevt_1_ta_ph.bem_multiply_1(bevt_2_ta_ph);
bevl_ssz.bevi_int++;
bevl_set = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_1(bevl_ssz);
bevt_0_ta_loop = beva_list.bem_iteratorGet_0();
while (true)
/* Line: 710*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(1091237859);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 710*/ {
bevl_v = bevt_0_ta_loop.bemd_0(1799618430);
bevl_set.bem_put_1(bevl_v);
} /* Line: 711*/
 else /* Line: 710*/ {
break;
} /* Line: 710*/
} /* Line: 710*/
return bevl_set;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {707, 707, 707, 708, 709, 710, 0, 710, 710, 711, 713};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 27, 28, 29, 29, 32, 34, 35, 41};
/* BEGIN LINEINFO 
assign 1 707 24
sizeGet 0 707 24
assign 1 707 25
new 0 707 25
assign 1 707 26
multiply 1 707 26
incrementValue 0 708 27
assign 1 709 28
new 1 709 28
assign 1 710 29
iteratorGet 0 0 29
assign 1 710 32
hasNextGet 0 710 32
assign 1 710 34
nextGet 0 710 34
put 1 711 35
return 1 713 41
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 110382217: return bem_sourceFileNameGet_0();
case 1986590366: return bem_hashGet_0();
case 879975179: return bem_classNameGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 887739950: return bem_serializeToString_0();
case -2129983068: return bem_toAny_0();
case 233362262: return bem_many_0();
case -354002036: return bem_default_0();
case 888041456: return bem_tagGet_0();
case 1843544518: return bem_serializeContents_0();
case 1732513565: return bem_copy_0();
case -1588532100: return bem_echo_0();
case 1383646476: return bem_iteratorGet_0();
case 1989693945: return bem_toString_0();
case 2071597061: return bem_create_0();
case -1084228149: return bem_print_0();
case 714460463: return bem_once_0();
case 162533386: return bem_fieldNamesGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 1105152133: return bem_new_0();
case -153156208: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1538844769: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerSets_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerSets_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerSets();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst = (BEC_2_9_4_ContainerSets) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerSets.bece_BEC_2_9_4_ContainerSets_bevs_type;
}
}
}
