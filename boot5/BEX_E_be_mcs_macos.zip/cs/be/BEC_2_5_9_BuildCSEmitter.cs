namespace be {
/* IO:File: source/build/CSEmitter.be */
public sealed class BEC_2_5_9_BuildCSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
static BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x28,0x29,0x20,0x7B,0x20,0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_24, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_31 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_32 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_33 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_33, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_34 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_34, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_35 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_35, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_36, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_37 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_38 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_38, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_39 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_40 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_41 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_42 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_43 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_44 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_45 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_45, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_46 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_46, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_47 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_47, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_48 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_48, 3));
public static new BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;

public static new BET_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
bevt_4_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_existsGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_6_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 28 */
bevt_9_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_7_tmpany_phold.bemd_0(2054457963);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_6));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCSEmitter_bels_7));
bevt_16_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_21_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_22_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_22_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 38 */ {
bevt_23_tmpany_phold = bevt_0_tmpany_loop.bemd_0(335515617);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-1921829025);
if (bevl_firstmnsyn.bevi_bool) /* Line: 39 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 40 */
 else  /* Line: 41 */ {
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_24_tmpany_phold);
} /* Line: 42 */
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_27_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevt_26_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 44 */
 else  /* Line: 38 */ {
break;
} /* Line: 38 */
} /* Line: 38 */
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
bevt_31_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCSEmitter_bels_15));
bevl_bet.bem_addValue_1(bevt_36_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCSEmitter_bels_16));
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevt_38_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_17));
bevt_37_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_18));
bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_19));
bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_20));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
bevl_tout.bemd_1(967524718, bevl_bet);
bevl_tout.bemd_0(1785282761);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1711305847);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(2136205572);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_27));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_28));
return bevt_4_tmpany_phold;
} /* Line: 75 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_29));
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_30));
return bevt_3_tmpany_phold;
} /* Line: 82 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_31));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_32));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_40));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_41));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_42));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_43));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1084186110);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_44));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 27, 27, 27, 27, 27, 28, 28, 28, 30, 30, 30, 30, 31, 32, 32, 33, 33, 33, 33, 33, 33, 34, 34, 34, 34, 34, 34, 36, 36, 37, 38, 38, 0, 38, 38, 40, 42, 42, 44, 44, 44, 44, 46, 46, 47, 47, 48, 48, 50, 50, 50, 50, 50, 50, 51, 51, 52, 52, 52, 52, 52, 52, 53, 53, 54, 54, 55, 55, 56, 57, 61, 61, 61, 62, 63, 63, 63, 63, 63, 63, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 65, 70, 70, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 75, 77, 77, 81, 81, 81, 0, 0, 0, 82, 82, 84, 84, 88, 88, 92, 92, 92, 92, 92, 97, 98, 99, 99, 99, 100, 106, 106, 106, 106, 106, 106, 110, 110, 110, 110, 110, 111, 111, 111, 111, 111, 111, 112, 112, 112, 113, 113, 113, 113, 113, 113, 113, 113, 114, 118, 118, 118, 122, 122, 122, 122, 122, 122, 122, 126, 126, 130, 130, 130, 134, 134, 134, 134, 138, 138};
public static new int[] bevs_smnlec
 = new int[] {76, 77, 78, 79, 132, 133, 134, 135, 140, 141, 142, 143, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 168, 171, 173, 175, 178, 179, 181, 182, 183, 184, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 264, 265, 274, 276, 279, 284, 285, 287, 290, 294, 297, 300, 304, 305, 307, 308, 316, 321, 322, 324, 327, 331, 334, 335, 337, 338, 342, 343, 350, 351, 352, 353, 354, 360, 361, 362, 363, 364, 365, 374, 375, 376, 377, 378, 379, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 428, 429, 430, 439, 440, 441, 442, 443, 444, 445, 449, 450, 455, 456, 457, 463, 464, 465, 466, 470, 471};
/* BEGIN LINEINFO 
assign 1 17 76
new 0 17 76
assign 1 18 77
new 0 18 77
assign 1 19 78
new 0 19 78
new 1 23 79
assign 1 27 132
classDirGet 0 27 132
assign 1 27 133
fileGet 0 27 133
assign 1 27 134
existsGet 0 27 134
assign 1 27 135
not 0 27 140
assign 1 28 141
classDirGet 0 28 141
assign 1 28 142
fileGet 0 28 142
makeDirs 0 28 143
assign 1 30 145
typePathGet 0 30 145
assign 1 30 146
fileGet 0 30 146
assign 1 30 147
writerGet 0 30 147
assign 1 30 148
open 0 30 148
assign 1 31 149
new 0 31 149
assign 1 32 150
new 0 32 150
addValue 1 32 151
assign 1 33 152
new 0 33 152
assign 1 33 153
addValue 1 33 153
assign 1 33 154
typeEmitNameGet 0 33 154
assign 1 33 155
addValue 1 33 155
assign 1 33 156
new 0 33 156
addValue 1 33 157
assign 1 34 158
new 0 34 158
assign 1 34 159
addValue 1 34 159
assign 1 34 160
typeEmitNameGet 0 34 160
assign 1 34 161
addValue 1 34 161
assign 1 34 162
new 0 34 162
addValue 1 34 163
assign 1 36 164
new 0 36 164
addValue 1 36 165
assign 1 37 166
new 0 37 166
assign 1 38 167
mtdListGet 0 38 167
assign 1 38 168
iteratorGet 0 0 168
assign 1 38 171
hasNextGet 0 38 171
assign 1 38 173
nextGet 0 38 173
assign 1 40 175
new 0 40 175
assign 1 42 178
new 0 42 178
addValue 1 42 179
assign 1 44 181
addValue 1 44 181
assign 1 44 182
nameGet 0 44 182
assign 1 44 183
addValue 1 44 183
addValue 1 44 184
assign 1 46 190
new 0 46 190
addValue 1 46 191
assign 1 47 192
new 0 47 192
addValue 1 47 193
assign 1 48 194
new 0 48 194
addValue 1 48 195
assign 1 50 196
new 0 50 196
assign 1 50 197
addValue 1 50 197
assign 1 50 198
typeEmitNameGet 0 50 198
assign 1 50 199
addValue 1 50 199
assign 1 50 200
new 0 50 200
addValue 1 50 201
assign 1 51 202
new 0 51 202
addValue 1 51 203
assign 1 52 204
new 0 52 204
assign 1 52 205
addValue 1 52 205
assign 1 52 206
emitNameGet 0 52 206
assign 1 52 207
addValue 1 52 207
assign 1 52 208
new 0 52 208
addValue 1 52 209
assign 1 53 210
new 0 53 210
addValue 1 53 211
assign 1 54 212
new 0 54 212
addValue 1 54 213
assign 1 55 214
new 0 55 214
addValue 1 55 215
write 1 56 216
close 0 57 217
assign 1 61 239
new 0 61 239
assign 1 61 240
toString 0 61 240
assign 1 61 241
add 1 61 241
incrementValue 0 62 242
assign 1 63 243
new 0 63 243
assign 1 63 244
addValue 1 63 244
assign 1 63 245
addValue 1 63 245
assign 1 63 246
new 0 63 246
assign 1 63 247
addValue 1 63 247
addValue 1 63 248
assign 1 65 249
containedGet 0 65 249
assign 1 65 250
firstGet 0 65 250
assign 1 65 251
containedGet 0 65 251
assign 1 65 252
firstGet 0 65 252
assign 1 65 253
new 0 65 253
assign 1 65 254
add 1 65 254
assign 1 65 255
new 0 65 255
assign 1 65 256
add 1 65 256
assign 1 65 257
new 0 65 257
assign 1 65 258
finalAssign 4 65 258
addValue 1 65 259
assign 1 70 264
new 0 70 264
return 1 70 265
assign 1 74 274
isFinalGet 0 74 274
assign 1 0 276
assign 1 74 279
def 1 74 284
assign 1 74 285
isFinalGet 0 74 285
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 0 297
assign 1 0 300
assign 1 75 304
new 0 75 304
return 1 75 305
assign 1 77 307
new 0 77 307
return 1 77 308
assign 1 81 316
def 1 81 321
assign 1 81 322
isFinalGet 0 81 322
assign 1 0 324
assign 1 0 327
assign 1 0 331
assign 1 82 334
new 0 82 334
return 1 82 335
assign 1 84 337
new 0 84 337
return 1 84 338
assign 1 88 342
new 0 88 342
return 1 88 343
assign 1 92 350
new 0 92 350
assign 1 92 351
add 1 92 351
assign 1 92 352
new 0 92 352
assign 1 92 353
add 1 92 353
return 1 92 354
getCode 2 97 360
assign 1 98 361
toHexString 1 98 361
assign 1 99 362
new 0 99 362
assign 1 99 363
once 0 99 363
addValue 1 99 364
addValue 1 100 365
assign 1 106 374
new 0 106 374
assign 1 106 375
add 1 106 375
assign 1 106 376
new 0 106 376
assign 1 106 377
add 1 106 377
assign 1 106 378
add 1 106 378
return 1 106 379
assign 1 110 401
new 0 110 401
assign 1 110 402
add 1 110 402
assign 1 110 403
new 0 110 403
assign 1 110 404
add 1 110 404
assign 1 110 405
add 1 110 405
assign 1 111 406
new 0 111 406
assign 1 111 407
addValue 1 111 407
assign 1 111 408
addValue 1 111 408
assign 1 111 409
new 0 111 409
assign 1 111 410
addValue 1 111 410
addValue 1 111 411
assign 1 112 412
new 0 112 412
assign 1 112 413
addValue 1 112 413
addValue 1 112 414
assign 1 113 415
new 0 113 415
assign 1 113 416
addValue 1 113 416
assign 1 113 417
outputPlatformGet 0 113 417
assign 1 113 418
nameGet 0 113 418
assign 1 113 419
addValue 1 113 419
assign 1 113 420
new 0 113 420
assign 1 113 421
addValue 1 113 421
addValue 1 113 422
return 1 114 423
assign 1 118 428
libNameGet 0 118 428
assign 1 118 429
beginNs 1 118 429
return 1 118 430
assign 1 122 439
new 0 122 439
assign 1 122 440
libNs 1 122 440
assign 1 122 441
add 1 122 441
assign 1 122 442
new 0 122 442
assign 1 122 443
add 1 122 443
assign 1 122 444
add 1 122 444
return 1 122 445
assign 1 126 449
getNameSpace 1 126 449
return 1 126 450
assign 1 130 455
new 0 130 455
assign 1 130 456
add 1 130 456
return 1 130 457
assign 1 134 463
new 0 134 463
assign 1 134 464
once 0 134 464
assign 1 134 465
add 1 134 465
return 1 134 466
assign 1 138 470
new 0 138 470
return 1 138 471
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1308475342: return bem_classConfGet_0();
case -673156839: return bem_methodBodyGet_0();
case -1513278614: return bem_nameToIdGet_0();
case -316832884: return bem_spropDecGet_0();
case 1482055069: return bem_baseSmtdDecGet_0();
case 1361238708: return bem_serializeContents_0();
case -137928340: return bem_useDynMethodsGet_0();
case -328171317: return bem_hashGet_0();
case 975002362: return bem_tagGet_0();
case -1782076823: return bem_coanyiantReturnsGet_0();
case -1660465258: return bem_classEmitsGet_0();
case 1827175540: return bem_preClassGet_0();
case 2007736336: return bem_methodCallsGet_0();
case 1969740353: return bem_smnlecsGet_0();
case 2020012871: return bem_onceDecsGet_0();
case 679733985: return bem_callNamesGet_0();
case -1541410288: return bem_classEndGet_0();
case -292278476: return bem_smnlcsGet_0();
case -955735029: return bem_emitLangGet_0();
case 189986949: return bem_toAny_0();
case -939745371: return bem_buildClassInfo_0();
case -684664695: return bem_csynGet_0();
case -441004525: return bem_objectNpGet_0();
case 832983257: return bem_instanceEqualGet_0();
case -987640535: return bem_invpGet_0();
case 1724059441: return bem_beginNs_0();
case 813260751: return bem_methodCatchGet_0();
case -1196025536: return bem_ccCacheGet_0();
case 807055146: return bem_dynMethodsGet_0();
case -799094825: return bem_inFilePathedGet_0();
case 193583610: return bem_methodsGet_0();
case 1456355628: return bem_instanceNotEqualGet_0();
case 492718056: return bem_floatNpGet_0();
case -873085717: return bem_iteratorGet_0();
case 1476217873: return bem_overrideMtdDecGet_0();
case 1412735652: return bem_exceptDecGet_0();
case 713197195: return bem_deserializeClassNameGet_0();
case -820052986: return bem_afterCast_0();
case -620085107: return bem_getClassOutput_0();
case 415983442: return bem_nlGet_0();
case -1684113280: return bem_boolCcGet_0();
case 1327161698: return bem_fileExtGet_0();
case 1501280282: return bem_mainOutsideNsGet_0();
case -322366998: return bem_initialDecGet_0();
case 296913713: return bem_instOfGet_0();
case -1698152847: return bem_serializationIteratorGet_0();
case 1730436169: return bem_lastMethodsSizeGet_0();
case -1435450334: return bem_classNameGet_0();
case 670707830: return bem_runtimeInitGet_0();
case 397396426: return bem_classCallsGet_0();
case 566811100: return bem_buildInitial_0();
case -585503536: return bem_libEmitPathGet_0();
case 1418537405: return bem_fieldIteratorGet_0();
case -100075913: return bem_new_0();
case 2135066141: return bem_randGet_0();
case -1342816490: return bem_propDecGet_0();
case -287138068: return bem_onceCountGet_0();
case -252012421: return bem_buildGet_0();
case -1085098870: return bem_superNameGet_0();
case -867933703: return bem_synEmitPathGet_0();
case 793463112: return bem_maxDynArgsGet_0();
case -2040997955: return bem_trueValueGet_0();
case -1860874246: return bem_writeBET_0();
case -1320125172: return bem_once_0();
case -2080318285: return bem_sourceFileNameGet_0();
case -59630375: return bem_lastMethodsLinesGet_0();
case -385236862: return bem_mainStartGet_0();
case 634130004: return bem_maxSpillArgsLenGet_0();
case 397352351: return bem_qGet_0();
case 1373944985: return bem_boolTypeGet_0();
case -913517241: return bem_constGet_0();
case 1348777534: return bem_many_0();
case -489600264: return bem_lineCountGet_0();
case 980826049: return bem_idToNameGet_0();
case 862472561: return bem_getLibOutput_0();
case 1993845682: return bem_mainInClassGet_0();
case 1907596400: return bem_copy_0();
case -1628969899: return bem_baseMtdDecGet_0();
case -1042054180: return bem_emitLib_0();
case 1060353928: return bem_lastMethodBodySizeGet_0();
case 596758489: return bem_create_0();
case -334082222: return bem_intNpGet_0();
case -1536265330: return bem_scvpGet_0();
case 1983867826: return bem_typeDecGet_0();
case 1802842091: return bem_fullLibEmitNameGet_0();
case 1817726047: return bem_parentConfGet_0();
case 354181094: return bem_ntypesGet_0();
case -80012080: return bem_superCallsGet_0();
case -2093575949: return bem_cnodeGet_0();
case 1291090410: return bem_falseValueGet_0();
case 1122699349: return bem_propertyDecsGet_0();
case 193799733: return bem_buildCreate_0();
case -413963391: return bem_doEmit_0();
case -290478797: return bem_classesInDepthOrderGet_0();
case -1388858818: return bem_libEmitNameGet_0();
case 814129208: return bem_lastMethodBodyLinesGet_0();
case 1873174156: return bem_boolNpGet_0();
case 860486461: return bem_transGet_0();
case -2101819017: return bem_stringNpGet_0();
case -92908170: return bem_print_0();
case -1647403047: return bem_saveSyns_0();
case 1384800737: return bem_mnodeGet_0();
case -2023914601: return bem_msynGet_0();
case -254285341: return bem_nativeCSlotsGet_0();
case 1230633165: return bem_lastCallGet_0();
case 820842677: return bem_endNs_0();
case 1714984646: return bem_serializeToString_0();
case 331486658: return bem_objectCcGet_0();
case -1133998532: return bem_returnTypeGet_0();
case 1732066970: return bem_echo_0();
case -977833063: return bem_toString_0();
case 243062114: return bem_nullValueGet_0();
case 1051179895: return bem_mainEndGet_0();
case 30357708: return bem_ccMethodsGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1447207109: return bem_instanceEqualSet_1(bevd_0);
case 877470536: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 319541017: return bem_falseValueSet_1(bevd_0);
case 1563484758: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 621962696: return bem_msynSet_1(bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case -1104348131: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1394748376: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -86845573: return bem_preClassSet_1(bevd_0);
case -539476548: return bem_onceDecsSet_1(bevd_0);
case -1016756392: return bem_propertyDecsSet_1(bevd_0);
case 765387264: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1910980701: return bem_intNpSet_1(bevd_0);
case -492245111: return bem_classEmitsSet_1(bevd_0);
case -520226247: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 674338363: return bem_parentConfSet_1(bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2094167267: return bem_randSet_1(bevd_0);
case 441494844: return bem_synEmitPathSet_1(bevd_0);
case 1505565824: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -112061979: return bem_transSet_1(bevd_0);
case 801271220: return bem_mnodeSet_1(bevd_0);
case -254684649: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1385168038: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -1961515217: return bem_objectNpSet_1(bevd_0);
case 961279963: return bem_instanceNotEqualSet_1(bevd_0);
case 1399988217: return bem_nullValueSet_1(bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
case 407062049: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -1549602328: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 894301672: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1774313375: return bem_dynMethodsSet_1(bevd_0);
case -1188563089: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1373427301: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 349095211: return bem_boolNpSet_1(bevd_0);
case 1518904216: return bem_trueValueSet_1(bevd_0);
case 73072589: return bem_constSet_1(bevd_0);
case 56705809: return bem_cnodeSet_1(bevd_0);
case -870824756: return bem_nlSet_1(bevd_0);
case -1196402645: return bem_invpSet_1(bevd_0);
case 497255219: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -661990214: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1847293238: return bem_returnTypeSet_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case 1611925447: return bem_maxSpillArgsLenSet_1(bevd_0);
case 359610201: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1720314182: return bem_nativeCSlotsSet_1(bevd_0);
case -255952352: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1561813566: return bem_csynSet_1(bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case -2024436739: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1202484434: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1983328572: return bem_lastMethodsSizeSet_1(bevd_0);
case -1521922084: return bem_libEmitNameSet_1(bevd_0);
case -1982286208: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1049871219: return bem_smnlecsSet_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2044078816: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 846732778: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1083753625: return bem_lineCountSet_1(bevd_0);
case 834003630: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1257197831: return bem_lastCallSet_1(bevd_0);
case -1413559776: return bem_onceCountSet_1(bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1419225109: return bem_scvpSet_1(bevd_0);
case 518909919: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -559049744: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 462628500: return bem_inFilePathedSet_1(bevd_0);
case -13055318: return bem_methodsSet_1(bevd_0);
case -535255173: return bem_maxDynArgsSet_1(bevd_0);
case -319239479: return bem_methodCatchSet_1(bevd_0);
case -1561753781: return bem_lastMethodsLinesSet_1(bevd_0);
case -932574616: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -112779591: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 743432929: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -711863568: return bem_classConfSet_1(bevd_0);
case -1264255776: return bem_classCallsSet_1(bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case -1127458829: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2099420063: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -89256529: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -87592719: return bem_floatNpSet_1(bevd_0);
case -1678389319: return bem_classesInDepthOrderSet_1(bevd_0);
case -2073361835: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1288701278: return bem_instOfSet_1(bevd_0);
case 2087668546: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1344159330: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1534402048: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 101577200: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1606353322: return bem_fileExtSet_1(bevd_0);
case -1683675402: return bem_exceptDecSet_1(bevd_0);
case -679802562: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1511873480: return bem_begin_1(bevd_0);
case 95874929: return bem_callNamesSet_1(bevd_0);
case -1478697358: return bem_nameToIdSet_1(bevd_0);
case 519340526: return bem_ntypesSet_1(bevd_0);
case 1559826621: return bem_libEmitPathSet_1(bevd_0);
case -1661388914: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -68157520: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case 757129306: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 212801765: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1654570228: return bem_ccMethodsSet_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -375129687: return bem_methodCallsSet_1(bevd_0);
case -2069473122: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case -657914021: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -549281668: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -2026429776: return bem_boolCcSet_1(bevd_0);
case 243907104: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1285483395: return bem_qSet_1(bevd_0);
case 1630274613: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1881313761: return bem_superCallsSet_1(bevd_0);
case -1770840264: return bem_buildSet_1(bevd_0);
case -36926033: return bem_notEquals_1(bevd_0);
case 1418621263: return bem_fullLibEmitNameSet_1(bevd_0);
case -1626290117: return bem_emitLangSet_1(bevd_0);
case -208834388: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 214760315: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1339550637: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case -1794073662: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 557787506: return bem_stringNpSet_1(bevd_0);
case -1615050563: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case 972597890: return bem_objectCcSet_1(bevd_0);
case -559671883: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 928074191: return bem_idToNameSet_1(bevd_0);
case -1466906055: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1142002035: return bem_smnlcsSet_1(bevd_0);
case 785497828: return bem_end_1(bevd_0);
case 238115635: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -353170424: return bem_methodBodySet_1(bevd_0);
case -1685745238: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -2141976779: return bem_ccCacheSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 625816831: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -461399118: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1047502590: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 2079902211: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2047432789: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -276482679: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1885577798: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 989595745: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1376215298: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 163403839: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2090677741: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -2041682246: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1682290529: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1123055579: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 82186356: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 766947381: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1388809114: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1846775647: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 484978005: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_type;
}
}
}
