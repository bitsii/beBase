namespace be {
/* IO:File: source/build/Transport.be */
public sealed class BEC_2_5_9_BuildTransport : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
static BEC_2_5_9_BuildTransport() { }
private static byte[] becc_BEC_2_5_9_BuildTransport_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransport_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_1, 37));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_2, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_3 = {0x4E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_4 = {0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x62,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_4, 12));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_5 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_5, 44));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_6 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_6, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_7 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_8 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_9 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_11 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_12 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static new BEC_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_inst;

public static new BET_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_type;

public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildTransport_bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
try  /* Line: 35 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 40 */ {
if (bevl_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 41 */
 else  /* Line: 40 */ {
break;
} /* Line: 40 */
} /* Line: 40 */
beva_visitor.bem_end_1(this);
} /* Line: 44 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_1;
bevt_3_tmpany_phold.bem_print_0();
bevl_e.bemd_0(-92908170);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_2;
bevt_4_tmpany_phold.bem_print_0();
bevl_node.bem_print_0();
bevl_nc = bevl_node.bem_containerGet_0();
while (true)
 /* Line: 53 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_3;
bevt_6_tmpany_phold.bem_print_0();
bevl_nc.bemd_0(-92908170);
bevl_nc = bevl_nc.bemd_0(-1154130332);
} /* Line: 56 */
 else  /* Line: 53 */ {
break;
} /* Line: 53 */
} /* Line: 53 */
} /* Line: 53 */
 else  /* Line: 58 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_4;
bevt_7_tmpany_phold.bem_print_0();
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_5;
bevt_8_tmpany_phold.bem_print_0();
bevl_e.bemd_0(-92908170);
} /* Line: 61 */
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 63 */
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_contain_0() {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
bevt_7_tmpany_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpany_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 72 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 72 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_12_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpany_phold.bevi_int == bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_15_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 77 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 81 */ {
if (bevl_wf == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_19_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpany_phold.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_22_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_25_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpany_phold.bevi_int == bevt_26_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 83 */
 else  /* Line: 81 */ {
break;
} /* Line: 81 */
} /* Line: 81 */
if (bevl_wf == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_29_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpany_phold.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_32_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevl_cnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildTransport_bels_7));
bevl_cnode.bem_heldSet_1(bevt_35_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 92 */
} /* Line: 85 */
bevt_37_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_41_tmpany_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_typenameGet_0();
bevt_42_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpany_phold.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevt_44_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpany_phold.bevi_int == bevt_45_tmpany_phold.bevi_int) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_8));
bevl_mnode.bem_heldSet_1(bevt_47_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 101 */
bevt_49_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpany_phold.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_52_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpany_phold.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 104 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_9));
bevl_mnode.bem_heldSet_1(bevt_55_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 110 */
bevt_57_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpany_phold.bevi_int == bevt_58_tmpany_phold.bevi_int) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 114 */
 else  /* Line: 113 */ {
bevt_60_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpany_phold.bevi_int == bevt_61_tmpany_phold.bevi_int) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 116 */
 else  /* Line: 113 */ {
bevt_63_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_10));
bevt_66_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_66_tmpany_phold);
} /* Line: 120 */
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_11));
bevt_69_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_69_tmpany_phold);
} /* Line: 124 */
} /* Line: 123 */
 else  /* Line: 126 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 127 */
} /* Line: 113 */
} /* Line: 113 */
bevt_72_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpany_phold = bevl_conTypes.bem_has_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevl_curr = bevl_node;
} /* Line: 130 */
} /* Line: 129 */
} /* Line: 76 */
 else  /* Line: 72 */ {
break;
} /* Line: 72 */
} /* Line: 72 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_12));
bevt_1_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpany_phold, beva_curr);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 139 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() {
return bevp_outermost;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 18, 19, 20, 22, 22, 23, 23, 27, 28, 28, 29, 30, 36, 38, 40, 40, 41, 44, 46, 46, 47, 47, 48, 48, 49, 50, 50, 51, 52, 53, 53, 54, 54, 55, 56, 59, 59, 60, 60, 61, 63, 68, 68, 69, 70, 71, 72, 72, 75, 76, 76, 76, 77, 77, 77, 77, 77, 77, 77, 77, 0, 0, 0, 80, 81, 81, 81, 81, 81, 81, 0, 81, 81, 81, 81, 0, 0, 0, 82, 82, 82, 82, 0, 0, 0, 0, 0, 83, 85, 85, 85, 85, 85, 85, 0, 85, 85, 85, 85, 0, 0, 0, 0, 0, 88, 89, 89, 90, 90, 91, 92, 95, 95, 95, 95, 95, 95, 95, 95, 95, 0, 0, 0, 95, 95, 95, 95, 0, 0, 0, 97, 98, 98, 99, 99, 100, 101, 104, 104, 104, 104, 104, 104, 104, 104, 0, 0, 0, 106, 107, 107, 108, 108, 109, 110, 113, 113, 113, 113, 114, 115, 115, 115, 115, 116, 117, 117, 117, 117, 118, 119, 119, 120, 120, 120, 122, 123, 123, 124, 124, 124, 127, 129, 129, 130, 137, 138, 138, 139, 139, 139, 141, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 52, 53, 54, 55, 56, 73, 74, 77, 82, 83, 89, 93, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 110, 115, 116, 117, 118, 119, 127, 128, 129, 130, 131, 133, 219, 220, 221, 222, 223, 224, 227, 229, 230, 231, 236, 237, 238, 239, 244, 245, 246, 247, 252, 253, 256, 260, 263, 266, 271, 272, 273, 274, 279, 280, 283, 284, 285, 290, 291, 294, 298, 301, 302, 303, 308, 309, 312, 316, 319, 323, 326, 332, 337, 338, 339, 340, 345, 346, 349, 350, 351, 356, 357, 360, 364, 367, 371, 374, 375, 376, 377, 378, 379, 380, 383, 384, 385, 390, 391, 392, 393, 394, 399, 400, 403, 407, 410, 411, 412, 417, 418, 421, 425, 428, 429, 430, 431, 432, 433, 434, 436, 437, 438, 443, 444, 445, 446, 451, 452, 455, 459, 462, 463, 464, 465, 466, 467, 468, 470, 471, 472, 477, 478, 481, 482, 483, 488, 489, 492, 493, 494, 499, 500, 501, 506, 507, 508, 509, 511, 512, 517, 518, 519, 520, 524, 528, 529, 531, 546, 547, 552, 553, 554, 555, 557, 560, 563, 567, 570, 574, 577, 581, 584};
/* BEGIN LINEINFO 
assign 1 17 39
assign 1 18 40
constantsGet 0 18 40
assign 1 18 41
ntypesGet 0 18 41
assign 1 19 42
new 1 19 42
assign 1 20 43
assign 1 22 44
TRANSUNITGet 0 22 44
typenameSet 1 22 45
assign 1 23 46
new 0 23 46
heldSet 1 23 47
assign 1 27 52
assign 1 28 53
constantsGet 0 28 53
assign 1 28 54
ntypesGet 0 28 54
assign 1 29 55
assign 1 30 56
begin 1 36 73
assign 1 38 74
accept 1 38 74
assign 1 40 77
def 1 40 82
assign 1 41 83
accept 1 41 83
end 1 44 89
assign 1 46 93
def 1 46 98
assign 1 47 99
new 0 47 99
print 0 47 100
assign 1 48 101
new 0 48 101
print 0 48 102
print 0 49 103
assign 1 50 104
new 0 50 104
print 0 50 105
print 0 51 106
assign 1 52 107
containerGet 0 52 107
assign 1 53 110
def 1 53 115
assign 1 54 116
new 0 54 116
print 0 54 117
print 0 55 118
assign 1 56 119
containerGet 0 56 119
assign 1 59 127
new 0 59 127
print 0 59 128
assign 1 60 129
new 0 60 129
print 0 60 130
print 0 61 131
throw 1 63 133
assign 1 68 219
constantsGet 0 68 219
assign 1 68 220
conTypesGet 0 68 220
assign 1 69 221
assign 1 70 222
containedGet 0 70 222
containedSet 1 71 223
assign 1 72 224
linkedListIteratorGet 0 72 224
assign 1 72 227
hasNextGet 0 72 227
assign 1 75 229
nextGet 0 75 229
assign 1 76 230
delayDeleteGet 0 76 230
assign 1 76 231
not 0 76 236
assign 1 77 237
typenameGet 0 77 237
assign 1 77 238
TRANSUNITGet 0 77 238
assign 1 77 239
equals 1 77 244
assign 1 77 245
typenameGet 0 77 245
assign 1 77 246
IDGet 0 77 246
assign 1 77 247
equals 1 77 252
assign 1 0 253
assign 1 0 256
assign 1 0 260
assign 1 80 263
assign 1 81 266
def 1 81 271
assign 1 81 272
typenameGet 0 81 272
assign 1 81 273
IDGet 0 81 273
assign 1 81 274
equals 1 81 279
assign 1 0 280
assign 1 81 283
typenameGet 0 81 283
assign 1 81 284
COLONGet 0 81 284
assign 1 81 285
equals 1 81 290
assign 1 0 291
assign 1 0 294
assign 1 0 298
assign 1 82 301
typenameGet 0 82 301
assign 1 82 302
SPACEGet 0 82 302
assign 1 82 303
equals 1 82 308
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 0 319
assign 1 0 323
assign 1 83 326
nextPeerGet 0 83 326
assign 1 85 332
def 1 85 337
assign 1 85 338
typenameGet 0 85 338
assign 1 85 339
PARENSGet 0 85 339
assign 1 85 340
equals 1 85 345
assign 1 0 346
assign 1 85 349
typenameGet 0 85 349
assign 1 85 350
BRACESGet 0 85 350
assign 1 85 351
equals 1 85 356
assign 1 0 357
assign 1 0 360
assign 1 0 364
assign 1 0 367
assign 1 0 371
assign 1 88 374
new 1 88 374
assign 1 89 375
CLASSGet 0 89 375
typenameSet 1 89 376
assign 1 90 377
new 0 90 377
heldSet 1 90 378
addValue 1 91 379
assign 1 92 380
assign 1 95 383
typenameGet 0 95 383
assign 1 95 384
BRACESGet 0 95 384
assign 1 95 385
equals 1 95 390
assign 1 95 391
containerGet 0 95 391
assign 1 95 392
typenameGet 0 95 392
assign 1 95 393
CLASSGet 0 95 393
assign 1 95 394
equals 1 95 399
assign 1 0 400
assign 1 0 403
assign 1 0 407
assign 1 95 410
typenameGet 0 95 410
assign 1 95 411
IDGet 0 95 411
assign 1 95 412
equals 1 95 417
assign 1 0 418
assign 1 0 421
assign 1 0 425
assign 1 97 428
new 1 97 428
assign 1 98 429
METHODGet 0 98 429
typenameSet 1 98 430
assign 1 99 431
new 0 99 431
heldSet 1 99 432
addValue 1 100 433
assign 1 101 434
assign 1 104 436
typenameGet 0 104 436
assign 1 104 437
BRACESGet 0 104 437
assign 1 104 438
equals 1 104 443
assign 1 104 444
typenameGet 0 104 444
assign 1 104 445
BRACESGet 0 104 445
assign 1 104 446
equals 1 104 451
assign 1 0 452
assign 1 0 455
assign 1 0 459
assign 1 106 462
new 1 106 462
assign 1 107 463
PROPERTIESGet 0 107 463
typenameSet 1 107 464
assign 1 108 465
new 0 108 465
heldSet 1 108 466
addValue 1 109 467
assign 1 110 468
assign 1 113 470
typenameGet 0 113 470
assign 1 113 471
RPARENSGet 0 113 471
assign 1 113 472
equals 1 113 477
assign 1 114 478
stepBack 1 114 478
assign 1 115 481
typenameGet 0 115 481
assign 1 115 482
RIDXGet 0 115 482
assign 1 115 483
equals 1 115 488
assign 1 116 489
stepBack 1 116 489
assign 1 117 492
typenameGet 0 117 492
assign 1 117 493
RBRACESGet 0 117 493
assign 1 117 494
equals 1 117 499
assign 1 118 500
stepBack 1 118 500
assign 1 119 501
undef 1 119 506
assign 1 120 507
new 0 120 507
assign 1 120 508
new 2 120 508
throw 1 120 509
assign 1 122 511
stepBack 1 122 511
assign 1 123 512
undef 1 123 517
assign 1 124 518
new 0 124 518
assign 1 124 519
new 2 124 519
throw 1 124 520
addValue 1 127 524
assign 1 129 528
typenameGet 0 129 528
assign 1 129 529
has 1 129 529
assign 1 130 531
assign 1 137 546
containerGet 0 137 546
assign 1 138 547
undef 1 138 552
assign 1 139 553
new 0 139 553
assign 1 139 554
new 2 139 554
throw 1 139 555
return 1 141 557
return 1 0 560
assign 1 0 563
return 1 0 567
assign 1 0 570
return 1 0 574
assign 1 0 577
return 1 0 581
assign 1 0 584
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1714984646: return bem_serializeToString_0();
case 1348777534: return bem_many_0();
case -873085717: return bem_iteratorGet_0();
case 1907596400: return bem_copy_0();
case 1757823922: return bem_contain_0();
case -1320125172: return bem_once_0();
case 713197195: return bem_deserializeClassNameGet_0();
case -977833063: return bem_toString_0();
case -252012421: return bem_buildGet_0();
case 354181094: return bem_ntypesGet_0();
case -1698152847: return bem_serializationIteratorGet_0();
case -1435450334: return bem_classNameGet_0();
case -100075913: return bem_new_0();
case 975002362: return bem_tagGet_0();
case -2080318285: return bem_sourceFileNameGet_0();
case -1186534443: return bem_outermostGet_0();
case -58474533: return bem_currentGet_0();
case 1418537405: return bem_fieldIteratorGet_0();
case -92908170: return bem_print_0();
case 596758489: return bem_create_0();
case 189986949: return bem_toAny_0();
case 1732066970: return bem_echo_0();
case -328171317: return bem_hashGet_0();
case 1361238708: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -36926033: return bem_notEquals_1(bevd_0);
case 1663612489: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case -1685745238: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 519340526: return bem_ntypesSet_1(bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1456864247: return bem_currentSet_1(bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 747361344: return bem_outermostSet_1(bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 483185479: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
case -1770840264: return bem_buildSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2141155402: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransport_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildTransport_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransport();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst = (BEC_2_5_9_BuildTransport) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_type;
}
}
}
