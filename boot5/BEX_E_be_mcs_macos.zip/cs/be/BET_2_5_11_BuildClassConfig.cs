namespace be {
public class BET_2_5_11_BuildClassConfig : BETS_Object {
public BET_2_5_11_BuildClassConfig() {
string[] bevs_mtnames = new string[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "new_4", "relEmitName_1", "npGet_0", "npGetDirect_0", "npSet_1", "npSetDirect_1", "emitterGet_0", "emitterGetDirect_0", "emitterSet_1", "emitterSetDirect_1", "emitPathGet_0", "emitPathGetDirect_0", "emitPathSet_1", "emitPathSetDirect_1", "libNameGet_0", "libNameGetDirect_0", "libNameSet_1", "libNameSetDirect_1", "nameSpaceGet_0", "nameSpaceGetDirect_0", "nameSpaceSet_1", "nameSpaceSetDirect_1", "emitNameGet_0", "emitNameGetDirect_0", "emitNameSet_1", "emitNameSetDirect_1", "typeEmitNameGet_0", "typeEmitNameGetDirect_0", "typeEmitNameSet_1", "typeEmitNameSetDirect_1", "fullEmitNameGet_0", "fullEmitNameGetDirect_0", "fullEmitNameSet_1", "fullEmitNameSetDirect_1", "classPathGet_0", "classPathGetDirect_0", "classPathSet_1", "classPathSetDirect_1", "typePathGet_0", "typePathGetDirect_0", "typePathSet_1", "typePathSetDirect_1", "classDirGet_0", "classDirGetDirect_0", "classDirSet_1", "classDirSetDirect_1", "synPathGet_0", "synPathGetDirect_0", "synPathSet_1", "synPathSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "np", "emitter", "emitPath", "libName", "nameSpace", "emitName", "typeEmitName", "fullEmitName", "classPath", "typePath", "classDir", "synPath" };
}
static BET_2_5_11_BuildClassConfig() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_11_BuildClassConfig();
}
}
}
