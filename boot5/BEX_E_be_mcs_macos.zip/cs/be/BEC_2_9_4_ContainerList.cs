namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_2_9_4_ContainerList : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }
static BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
public static new BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static new BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_9_SystemException bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_leni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 212*/ {
if (beva_capi == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 212*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 212*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 212*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_ta_ph);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 213*/
if (bevp_length == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 215*/ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 218*/ {
return this;
} /* Line: 219*/
} /* Line: 218*/

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_2_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_2_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sizeSet_1(BEC_2_4_3_MathInt beva_val) {
bem_lengthSet_1(beva_val);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_length.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 258*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 259*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_length.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevp_length.bem_subtract_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_get_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_9_SystemException bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 291*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_ta_ph);
throw new be.BECS_ThrowBack(bevt_2_ta_ph);
} /* Line: 292*/
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 294*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_posi.bem_add_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
} /* Line: 295*/

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_posi.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 311*/ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 311*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 311*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 311*/
 else /* Line: 311*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 311*/ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 317*/
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 327*/ {
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_fl = bevp_length.bem_subtract_1(bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_j = beva_pos.bem_add_1(bevt_2_ta_ph);
bevl_i = (BEC_2_4_3_MathInt) beva_pos.bem_copy_0();
while (true)
/* Line: 330*/ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_4_ta_ph = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_ta_ph);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 330*/
 else /* Line: 330*/ {
break;
} /* Line: 330*/
} /* Line: 330*/
bem_put_2(bevl_fl, null);
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = bevp_length.bem_subtract_1(bevt_6_ta_ph);
bem_lengthSet_1(bevt_5_ta_ph);
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 336*/
bevt_8_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 350*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 350*/ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 350*/
 else /* Line: 350*/ {
break;
} /* Line: 350*/
} /* Line: 350*/
bevp_length = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_n = (BEC_2_9_4_ContainerList) bem_create_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 358*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 358*/ {
bevt_1_ta_ph = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_ta_ph);
bevl_i.bevi_int++;
} /* Line: 358*/
 else /* Line: 358*/ {
break;
} /* Line: 358*/
} /* Line: 358*/
return (BEC_2_6_6_SystemObject) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = beva_xi.bem_lengthGet_0();
bevt_3_ta_ph = bevp_length.bem_add_1(bevt_4_ta_ph);
bevl_yi = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_loop = bem_iteratorGet_0();
while (true)
/* Line: 370*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 370*/ {
bevl_c = bevt_0_ta_loop.bemd_0(-894202533);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 371*/
 else /* Line: 370*/ {
break;
} /* Line: 370*/
} /* Line: 370*/
bevt_1_ta_loop = beva_xi.bem_iteratorGet_0();
while (true)
/* Line: 373*/ {
bevt_6_ta_ph = bevt_1_ta_loop.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 373*/ {
bevl_c = bevt_1_ta_loop.bemd_0(-894202533);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 374*/
 else /* Line: 373*/ {
break;
} /* Line: 373*/
} /* Line: 373*/
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_ta_ph, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
while (true)
/* Line: 388*/ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 388*/ {
bevl_c = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
bevl_j = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
while (true)
/* Line: 390*/ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 390*/ {
bevt_3_ta_ph = bem_get_1(bevl_j);
bevt_4_ta_ph = bem_get_1(bevl_c);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-128042273, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 391*/ {
bevl_c = (BEC_2_4_3_MathInt) bevl_j.bem_copy_0();
} /* Line: 392*/
bevl_j.bevi_int++;
} /* Line: 390*/
 else /* Line: 390*/ {
break;
} /* Line: 390*/
} /* Line: 390*/
bevl_hold = bem_get_1(bevl_i);
bevt_5_ta_ph = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_ta_ph);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 388*/
 else /* Line: 388*/ {
break;
} /* Line: 388*/
} /* Line: 388*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_si = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
/* Line: 407*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 407*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 408*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 408*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 408*/
 else /* Line: 408*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 408*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_ta_ph = bevl_so.bemd_1(-128042273, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 411*/ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 413*/
 else /* Line: 414*/ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 416*/
} /* Line: 411*/
 else /* Line: 408*/ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 418*/ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 421*/
 else /* Line: 408*/ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 422*/ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 425*/
} /* Line: 408*/
} /* Line: 408*/
bevl_i.bevi_int++;
} /* Line: 427*/
 else /* Line: 407*/ {
break;
} /* Line: 407*/
} /* Line: 407*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevt_1_ta_ph, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_mlen.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 437*/ {
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_2_ta_ph = bem_create_1(bevt_3_ta_ph);
return (BEC_2_9_4_ContainerList) bevt_2_ta_ph;
} /* Line: 438*/
 else /* Line: 437*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_mlen.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 439*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_ta_ph);
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_ta_ph, bevt_8_ta_ph);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 442*/
 else /* Line: 443*/ {
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_ta_ph);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 451*/
} /* Line: 437*/
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_9_SystemException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 456*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 457*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 463*/ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 485*/
while (true)
/* Line: 488*/ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 488*/ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 499*/
 else /* Line: 488*/ {
break;
} /* Line: 488*/
} /* Line: 488*/
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 505*/ {
while (true)
/* Line: 506*/ {
bevt_1_ta_ph = beva_val.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 506*/ {
bevt_2_ta_ph = beva_val.bemd_0(-894202533);
bem_addValueWhole_1(bevt_2_ta_ph);
} /* Line: 507*/
 else /* Line: 506*/ {
break;
} /* Line: 506*/
} /* Line: 506*/
} /* Line: 506*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (beva_val == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 513*/ {
bevt_1_ta_ph = beva_val.bemd_0(-31114048);
bem_iterateAdd_1(bevt_1_ta_ph);
} /* Line: 514*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 519*/ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 530*/
 else /* Line: 531*/ {
bevt_1_ta_ph = (BEC_2_4_3_MathInt) bevp_length.bem_copy_0();
bem_put_2(bevt_1_ta_ph, beva_val);
} /* Line: 533*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_val == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 538*/ {
bevt_2_ta_ph = beva_val.bemd_1(398725636, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 538*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 538*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 538*/
 else /* Line: 538*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 538*/ {
bem_addAll_1(beva_val);
} /* Line: 539*/
 else /* Line: 540*/ {
bem_addValueWhole_1(beva_val);
} /* Line: 541*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 547*/ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 547*/ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 549*/ {
bevt_3_ta_ph = beva_value.bemd_1(-1289000200, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 549*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 549*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 549*/
 else /* Line: 549*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 549*/ {
return bevl_i;
} /* Line: 550*/
bevl_i.bevi_int++;
} /* Line: 547*/
 else /* Line: 547*/ {
break;
} /* Line: 547*/
} /* Line: 547*/
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_find_1(beva_value);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 557*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 558*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_sortedFind_2(beva_value, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_high = bevp_length;
bevl_low = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 577*/ {
bevt_3_ta_ph = bevl_high.bem_subtract_1(bevl_low);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = bevt_3_ta_ph.bem_divide_1(bevt_4_ta_ph);
bevl_mid = bevt_2_ta_ph.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_ta_ph = beva_value.bemd_1(-1289000200, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 580*/ {
return bevl_mid;
} /* Line: 581*/
 else /* Line: 580*/ {
bevt_6_ta_ph = beva_value.bemd_1(1415352188, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 582*/ {
bevl_low = bevl_mid;
} /* Line: 584*/
 else /* Line: 580*/ {
bevt_7_ta_ph = beva_value.bemd_1(-128042273, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 585*/ {
bevl_high = bevl_mid;
} /* Line: 587*/
} /* Line: 580*/
} /* Line: 580*/
if (bevl_lastMid == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 590*/ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 590*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 590*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 590*/
 else /* Line: 590*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 590*/ {
if (beva_returnNoMatch.bevi_bool)/* Line: 591*/ {
bevt_11_ta_ph = bem_get_1(bevl_low);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(-128042273, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 591*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 591*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 591*/
 else /* Line: 591*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 591*/ {
return bevl_low;
} /* Line: 592*/
return null;
} /* Line: 594*/
bevl_lastMid = bevl_mid;
bevt_12_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_12_ta_ph.bevi_bool)/* Line: 597*/ {
return null;
} /* Line: 598*/
} /* Line: 597*/
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGetDirect_0() {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGetDirect_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {204, 204, 204, 208, 212, 212, 0, 212, 212, 0, 0, 213, 213, 213, 215, 215, 218, 218, 219, 243, 244, 245, 250, 254, 258, 258, 258, 259, 259, 261, 261, 271, 271, 275, 275, 279, 279, 283, 283, 283, 287, 287, 287, 287, 291, 291, 291, 292, 292, 292, 294, 294, 295, 295, 295, 311, 311, 311, 311, 311, 0, 0, 0, 323, 327, 327, 328, 328, 329, 329, 330, 330, 330, 331, 331, 332, 330, 334, 335, 335, 335, 336, 336, 338, 338, 342, 342, 346, 346, 350, 350, 350, 351, 350, 353, 357, 358, 358, 358, 359, 359, 358, 361, 364, 364, 366, 366, 369, 369, 369, 369, 370, 0, 370, 370, 371, 373, 0, 373, 373, 374, 376, 380, 380, 384, 384, 388, 388, 388, 389, 390, 390, 390, 391, 391, 391, 392, 390, 395, 396, 396, 397, 388, 402, 403, 404, 405, 406, 407, 407, 408, 408, 408, 408, 0, 0, 0, 409, 410, 411, 412, 413, 415, 416, 418, 418, 419, 420, 421, 422, 422, 423, 424, 425, 427, 432, 432, 432, 436, 437, 437, 437, 438, 438, 438, 439, 439, 439, 440, 440, 441, 441, 441, 442, 444, 444, 445, 446, 447, 448, 449, 450, 451, 456, 457, 457, 457, 463, 463, 464, 485, 488, 488, 499, 501, 505, 505, 506, 507, 507, 513, 513, 514, 514, 519, 519, 530, 533, 533, 538, 538, 538, 0, 0, 0, 539, 541, 547, 547, 547, 548, 549, 549, 549, 0, 0, 0, 550, 547, 553, 557, 557, 557, 558, 558, 560, 560, 566, 566, 566, 573, 574, 578, 578, 578, 578, 579, 580, 581, 582, 584, 585, 587, 590, 590, 590, 590, 0, 0, 0, 591, 591, 0, 0, 0, 592, 594, 596, 597, 598, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {43, 44, 45, 49, 60, 65, 66, 69, 74, 75, 78, 82, 83, 84, 86, 91, 92, 97, 98, 103, 104, 105, 109, 112, 120, 121, 126, 127, 128, 130, 131, 141, 142, 146, 147, 152, 153, 158, 159, 160, 166, 167, 168, 169, 179, 180, 185, 186, 187, 188, 190, 195, 196, 197, 198, 210, 211, 216, 217, 222, 223, 226, 230, 236, 251, 256, 257, 258, 259, 260, 261, 264, 269, 270, 271, 272, 273, 279, 280, 281, 282, 283, 284, 286, 287, 291, 292, 296, 297, 302, 305, 310, 311, 312, 318, 326, 327, 330, 335, 336, 337, 338, 344, 348, 349, 353, 354, 366, 367, 368, 369, 370, 370, 373, 375, 376, 382, 382, 385, 387, 388, 394, 398, 399, 403, 404, 418, 421, 426, 427, 428, 431, 436, 437, 438, 439, 441, 443, 449, 450, 451, 452, 453, 476, 477, 478, 479, 480, 483, 488, 489, 494, 495, 500, 501, 504, 508, 511, 512, 513, 515, 516, 519, 520, 524, 529, 530, 531, 532, 535, 540, 541, 542, 543, 547, 558, 559, 560, 580, 581, 582, 587, 588, 589, 590, 593, 594, 599, 600, 601, 602, 603, 604, 605, 608, 609, 610, 611, 612, 613, 614, 615, 616, 624, 626, 627, 628, 636, 641, 642, 645, 649, 654, 657, 663, 670, 675, 678, 680, 681, 693, 698, 699, 700, 707, 712, 715, 718, 719, 727, 732, 733, 735, 738, 742, 745, 748, 759, 762, 767, 768, 769, 774, 775, 777, 780, 784, 787, 789, 795, 802, 803, 808, 809, 810, 812, 813, 818, 819, 820, 841, 842, 845, 846, 847, 848, 849, 850, 852, 855, 857, 860, 862, 866, 871, 872, 877, 878, 881, 885, 889, 890, 892, 895, 899, 902, 904, 906, 907, 909, 914, 917, 920, 924, 927, 930, 934, 937, 940, 944};
/* BEGIN LINEINFO 
assign 1 204 43
new 0 204 43
assign 1 204 44
new 0 204 44
new 2 204 45
new 2 208 49
assign 1 212 60
undef 1 212 65
assign 1 0 66
assign 1 212 69
undef 1 212 74
assign 1 0 75
assign 1 0 78
assign 1 213 82
new 0 213 82
assign 1 213 83
new 1 213 83
throw 1 213 84
assign 1 215 86
def 1 215 91
assign 1 218 92
equals 1 218 97
return 1 219 98
assign 1 243 103
copy 0 243 103
assign 1 244 104
copy 0 244 104
assign 1 245 105
new 0 245 105
return 1 250 109
lengthSet 1 254 112
assign 1 258 120
new 0 258 120
assign 1 258 121
equals 1 258 126
assign 1 259 127
new 0 259 127
return 1 259 128
assign 1 261 130
new 0 261 130
return 1 261 131
assign 1 271 141
toString 0 271 141
return 1 271 142
assign 1 275 146
new 1 275 146
new 1 275 147
assign 1 279 152
iteratorGet 0 279 152
return 1 279 153
assign 1 283 158
new 0 283 158
assign 1 283 159
get 1 283 159
return 1 283 160
assign 1 287 166
new 0 287 166
assign 1 287 167
subtract 1 287 167
assign 1 287 168
get 1 287 168
return 1 287 169
assign 1 291 179
new 0 291 179
assign 1 291 180
lesser 1 291 185
assign 1 292 186
new 0 292 186
assign 1 292 187
new 1 292 187
throw 1 292 188
assign 1 294 190
greaterEquals 1 294 195
assign 1 295 196
new 0 295 196
assign 1 295 197
add 1 295 197
lengthSet 1 295 198
assign 1 311 210
new 0 311 210
assign 1 311 211
greaterEquals 1 311 216
assign 1 311 217
lesser 1 311 222
assign 1 0 223
assign 1 0 226
assign 1 0 230
return 1 323 236
assign 1 327 251
lesser 1 327 256
assign 1 328 257
new 0 328 257
assign 1 328 258
subtract 1 328 258
assign 1 329 259
new 0 329 259
assign 1 329 260
add 1 329 260
assign 1 330 261
copy 0 330 261
assign 1 330 264
lesser 1 330 269
assign 1 331 270
get 1 331 270
put 2 331 271
incrementValue 0 332 272
incrementValue 0 330 273
put 2 334 279
assign 1 335 280
new 0 335 280
assign 1 335 281
subtract 1 335 281
lengthSet 1 335 282
assign 1 336 283
new 0 336 283
return 1 336 284
assign 1 338 286
new 0 338 286
return 1 338 287
assign 1 342 291
new 1 342 291
return 1 342 292
assign 1 346 296
new 1 346 296
return 1 346 297
assign 1 350 302
new 0 350 302
assign 1 350 305
lesser 1 350 310
put 2 351 311
incrementValue 0 350 312
assign 1 353 318
new 0 353 318
assign 1 357 326
create 0 357 326
assign 1 358 327
new 0 358 327
assign 1 358 330
lesser 1 358 335
assign 1 359 336
get 1 359 336
put 2 359 337
incrementValue 0 358 338
return 1 361 344
assign 1 364 348
new 1 364 348
return 1 364 349
assign 1 366 353
new 1 366 353
return 1 366 354
assign 1 369 366
new 0 369 366
assign 1 369 367
lengthGet 0 369 367
assign 1 369 368
add 1 369 368
assign 1 369 369
new 2 369 369
assign 1 370 370
iteratorGet 0 0 370
assign 1 370 373
hasNextGet 0 370 373
assign 1 370 375
nextGet 0 370 375
addValueWhole 1 371 376
assign 1 373 382
iteratorGet 0 0 382
assign 1 373 385
hasNextGet 0 373 385
assign 1 373 387
nextGet 0 373 387
addValueWhole 1 374 388
return 1 376 394
assign 1 380 398
mergeSort 0 380 398
return 1 380 399
assign 1 384 403
new 0 384 403
sortValue 2 384 404
assign 1 388 418
copy 0 388 418
assign 1 388 421
lesser 1 388 426
assign 1 389 427
copy 0 389 427
assign 1 390 428
copy 0 390 428
assign 1 390 431
lesser 1 390 436
assign 1 391 437
get 1 391 437
assign 1 391 438
get 1 391 438
assign 1 391 439
lesser 1 391 439
assign 1 392 441
copy 0 392 441
incrementValue 0 390 443
assign 1 395 449
get 1 395 449
assign 1 396 450
get 1 396 450
put 2 396 451
put 2 397 452
incrementValue 0 388 453
assign 1 402 476
new 0 402 476
assign 1 403 477
new 0 403 477
assign 1 404 478
new 0 404 478
assign 1 405 479
lengthGet 0 405 479
assign 1 406 480
lengthGet 0 406 480
assign 1 407 483
lesser 1 407 488
assign 1 408 489
lesser 1 408 494
assign 1 408 495
lesser 1 408 500
assign 1 0 501
assign 1 0 504
assign 1 0 508
assign 1 409 511
get 1 409 511
assign 1 410 512
get 1 410 512
assign 1 411 513
lesser 1 411 513
incrementValue 0 412 515
put 2 413 516
incrementValue 0 415 519
put 2 416 520
assign 1 418 524
lesser 1 418 529
assign 1 419 530
get 1 419 530
incrementValue 0 420 531
put 2 421 532
assign 1 422 535
lesser 1 422 540
assign 1 423 541
get 1 423 541
incrementValue 0 424 542
put 2 425 543
incrementValue 0 427 547
assign 1 432 558
new 0 432 558
assign 1 432 559
mergeSort 2 432 559
return 1 432 560
assign 1 436 580
subtract 1 436 580
assign 1 437 581
new 0 437 581
assign 1 437 582
equals 1 437 587
assign 1 438 588
new 0 438 588
assign 1 438 589
create 1 438 589
return 1 438 590
assign 1 439 593
new 0 439 593
assign 1 439 594
equals 1 439 599
assign 1 440 600
new 0 440 600
assign 1 440 601
create 1 440 601
assign 1 441 602
new 0 441 602
assign 1 441 603
get 1 441 603
put 2 441 604
return 1 442 605
assign 1 444 608
new 0 444 608
assign 1 444 609
divide 1 444 609
assign 1 445 610
subtract 1 445 610
assign 1 446 611
add 1 446 611
assign 1 447 612
mergeSort 2 447 612
assign 1 448 613
mergeSort 2 448 613
assign 1 449 614
create 1 449 614
mergeIn 2 450 615
return 1 451 616
assign 1 456 624
new 0 456 624
assign 1 457 626
new 0 457 626
assign 1 457 627
new 1 457 627
throw 1 457 628
assign 1 463 636
greater 1 463 641
assign 1 464 642
multiply 1 464 642
assign 1 485 645
assign 1 488 649
lesser 1 488 654
incrementValue 0 499 657
setValue 1 501 663
assign 1 505 670
def 1 505 675
assign 1 506 678
hasNextGet 0 506 678
assign 1 507 680
nextGet 0 507 680
addValueWhole 1 507 681
assign 1 513 693
def 1 513 698
assign 1 514 699
iteratorGet 0 514 699
iterateAdd 1 514 700
assign 1 519 707
lesser 1 519 712
incrementValue 0 530 715
assign 1 533 718
copy 0 533 718
put 2 533 719
assign 1 538 727
def 1 538 732
assign 1 538 733
sameType 1 538 733
assign 1 0 735
assign 1 0 738
assign 1 0 742
addAll 1 539 745
addValueWhole 1 541 748
assign 1 547 759
new 0 547 759
assign 1 547 762
lesser 1 547 767
assign 1 548 768
get 1 548 768
assign 1 549 769
def 1 549 774
assign 1 549 775
equals 1 549 775
assign 1 0 777
assign 1 0 780
assign 1 0 784
return 1 550 787
incrementValue 0 547 789
return 1 553 795
assign 1 557 802
find 1 557 802
assign 1 557 803
def 1 557 808
assign 1 558 809
new 0 558 809
return 1 558 810
assign 1 560 812
new 0 560 812
return 1 560 813
assign 1 566 818
new 0 566 818
assign 1 566 819
sortedFind 2 566 819
return 1 566 820
assign 1 573 841
assign 1 574 842
new 0 574 842
assign 1 578 845
subtract 1 578 845
assign 1 578 846
new 0 578 846
assign 1 578 847
divide 1 578 847
assign 1 578 848
add 1 578 848
assign 1 579 849
get 1 579 849
assign 1 580 850
equals 1 580 850
return 1 581 852
assign 1 582 855
greater 1 582 855
assign 1 584 857
assign 1 585 860
lesser 1 585 860
assign 1 587 862
assign 1 590 866
def 1 590 871
assign 1 590 872
equals 1 590 877
assign 1 0 878
assign 1 0 881
assign 1 0 885
assign 1 591 889
get 1 591 889
assign 1 591 890
lesser 1 591 890
assign 1 0 892
assign 1 0 895
assign 1 0 899
return 1 592 902
return 1 594 904
assign 1 596 906
assign 1 597 907
new 0 597 907
return 1 598 909
return 1 0 914
return 1 0 917
assign 1 0 920
return 1 0 924
return 1 0 927
assign 1 0 930
return 1 0 934
return 1 0 937
assign 1 0 940
assign 1 0 944
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1148520836: return bem_firstGet_0();
case -1276210111: return bem_anyrayGet_0();
case 1858447626: return bem_sortValue_0();
case -1844917728: return bem_many_0();
case -8643043: return bem_serializeContents_0();
case 986273074: return bem_multiplierGetDirect_0();
case -1026733174: return bem_new_0();
case -31114048: return bem_iteratorGet_0();
case -2107273200: return bem_mergeSort_0();
case 1552561843: return bem_lengthGet_0();
case -488310469: return bem_capacityGetDirect_0();
case -12700454: return bem_arrayIteratorGet_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case -1902089216: return bem_toString_0();
case -1299196556: return bem_lastGet_0();
case 871858110: return bem_lengthGetDirect_0();
case 1137009070: return bem_once_0();
case 126670515: return bem_toAny_0();
case 856892061: return bem_capacityGet_0();
case 185174991: return bem_copy_0();
case 917961899: return bem_clear_0();
case -1035430934: return bem_sort_0();
case 2038193605: return bem_fieldNamesGet_0();
case 942868024: return bem_sizeGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 1029695809: return bem_echo_0();
case 217968364: return bem_classNameGet_0();
case -1149310710: return bem_isEmptyGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 1562608535: return bem_print_0();
case -1184088152: return bem_anyraySet_0();
case 1688687204: return bem_serializeToString_0();
case -1848718184: return bem_hashGet_0();
case -785258946: return bem_create_0();
case -2065828145: return bem_multiplierGet_0();
case -479166709: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -647382222: return bem_lengthSetDirect_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case -501683705: return bem_addAll_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -1967529308: return bem_iterateAdd_1(bevd_0);
case -312701209: return bem_find_1(bevd_0);
case -1439746501: return bem_addValue_1(bevd_0);
case -609621197: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 2135398250: return bem_sizeSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1634314384: return bem_has_1(bevd_0);
case -1260458138: return bem_multiplierSetDirect_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case -1724964778: return bem_addValueWhole_1(bevd_0);
case -494021932: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case 926458045: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -811834991: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case 582435246: return bem_sortedFind_1(bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 1911551406: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 389177729: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 658284291: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case -384085405: return bem_multiplierSet_1(bevd_0);
case -1953410302: return bem_capacitySetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 497465062: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1786595962: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1296376286: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -41179128: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 899790406: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2119188118: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
}
