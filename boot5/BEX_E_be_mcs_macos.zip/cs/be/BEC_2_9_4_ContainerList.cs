namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_2_9_4_ContainerList : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }
static BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_15 = (new BEC_2_4_3_MathInt(2));
public static new BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static new BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bem_new_2(bevt_0_tmpany_phold, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_leni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
if (beva_capi == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 196 */
if (bevp_length == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 198 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 201 */ {
return this;
} /* Line: 202 */
} /* Line: 201 */

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_2_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_2_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bece_BEC_2_9_4_ContainerList_bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 238 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_length.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_4;
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_5;
bevt_1_tmpany_phold = bevp_length.bem_subtract_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 271 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_7;
bevt_5_tmpany_phold = beva_posi.bem_add_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
} /* Line: 274 */

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 290 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 290 */ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 296 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_10;
bevl_j = beva_pos.bem_add_1(bevt_2_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) beva_pos.bem_copy_0();
while (true)
 /* Line: 309 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevt_4_tmpany_phold = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 309 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bem_put_2(bevl_fl, null);
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_11;
bevt_5_tmpany_phold = bevp_length.bem_subtract_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 315 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 329 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 329 */ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 329 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
bevp_length = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_n = (BEC_2_9_4_ContainerList) bem_create_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 337 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 337 */ {
bevt_1_tmpany_phold = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 337 */
 else  /* Line: 337 */ {
break;
} /* Line: 337 */
} /* Line: 337 */
return (BEC_2_6_6_SystemObject) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_tmpany_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpany_phold = bevp_length.bem_add_1(bevt_4_tmpany_phold);
bevl_yi = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_loop = bem_iteratorGet_0();
while (true)
 /* Line: 349 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(622925673);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 349 */ {
bevl_c = bevt_0_tmpany_loop.bemd_0(-1809371867);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 350 */
 else  /* Line: 349 */ {
break;
} /* Line: 349 */
} /* Line: 349 */
bevt_1_tmpany_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 352 */ {
bevt_6_tmpany_phold = bevt_1_tmpany_loop.bemd_0(622925673);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 352 */ {
bevl_c = bevt_1_tmpany_loop.bemd_0(-1809371867);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 353 */
 else  /* Line: 352 */ {
break;
} /* Line: 352 */
} /* Line: 352 */
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_tmpany_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
while (true)
 /* Line: 367 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 367 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
bevl_j = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
while (true)
 /* Line: 369 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 369 */ {
bevt_3_tmpany_phold = bem_get_1(bevl_j);
bevt_4_tmpany_phold = bem_get_1(bevl_c);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-557886178, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 370 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_j.bem_copy_0();
} /* Line: 371 */
bevl_j.bevi_int++;
} /* Line: 369 */
 else  /* Line: 369 */ {
break;
} /* Line: 369 */
} /* Line: 369 */
bevl_hold = bem_get_1(bevl_i);
bevt_5_tmpany_phold = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_tmpany_phold);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 367 */
 else  /* Line: 367 */ {
break;
} /* Line: 367 */
} /* Line: 367 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_si = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 386 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 386 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 387 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 387 */
 else  /* Line: 387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 387 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpany_phold = bevl_so.bemd_1(-557886178, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 390 */ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 392 */
 else  /* Line: 393 */ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 395 */
} /* Line: 390 */
 else  /* Line: 387 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 400 */
 else  /* Line: 387 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 404 */
} /* Line: 387 */
} /* Line: 387 */
bevl_i.bevi_int++;
} /* Line: 406 */
 else  /* Line: 386 */ {
break;
} /* Line: 386 */
} /* Line: 386 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevt_1_tmpany_phold, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_2_tmpany_phold = bem_create_1(bevt_3_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevt_2_tmpany_phold;
} /* Line: 417 */
 else  /* Line: 416 */ {
bevt_5_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_tmpany_phold = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 421 */
 else  /* Line: 422 */ {
bevt_9_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpany_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 430 */
} /* Line: 416 */
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 435 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 436 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 442 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 464 */
while (true)
 /* Line: 467 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 467 */ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 478 */
 else  /* Line: 467 */ {
break;
} /* Line: 467 */
} /* Line: 467 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
while (true)
 /* Line: 485 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(622925673);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 485 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-1809371867);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 486 */
 else  /* Line: 485 */ {
break;
} /* Line: 485 */
} /* Line: 485 */
} /* Line: 485 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 492 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-212376625);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 493 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 498 */ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 509 */
 else  /* Line: 510 */ {
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevp_length.bem_copy_0();
bem_put_2(bevt_1_tmpany_phold, beva_val);
} /* Line: 512 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 517 */ {
bevt_2_tmpany_phold = beva_val.bemd_1(-363168387, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 517 */
 else  /* Line: 517 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 517 */ {
bem_addAll_1(beva_val);
} /* Line: 518 */
 else  /* Line: 519 */ {
bem_addValueWhole_1(beva_val);
} /* Line: 520 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 526 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 526 */ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 528 */ {
bevt_3_tmpany_phold = beva_value.bemd_1(-1698354185, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 528 */
 else  /* Line: 528 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 528 */ {
return bevl_i;
} /* Line: 529 */
bevl_i.bevi_int++;
} /* Line: 526 */
 else  /* Line: 526 */ {
break;
} /* Line: 526 */
} /* Line: 526 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_find_1(beva_value);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 536 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 537 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_sortedFind_2(beva_value, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 556 */ {
bevt_3_tmpany_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_divide_1(bevt_4_tmpany_phold);
bevl_mid = bevt_2_tmpany_phold.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_tmpany_phold = beva_value.bemd_1(-1698354185, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 559 */ {
return bevl_mid;
} /* Line: 560 */
 else  /* Line: 559 */ {
bevt_6_tmpany_phold = beva_value.bemd_1(-978184840, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 561 */ {
bevl_low = bevl_mid;
} /* Line: 563 */
 else  /* Line: 559 */ {
bevt_7_tmpany_phold = beva_value.bemd_1(-557886178, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 564 */ {
bevl_high = bevl_mid;
} /* Line: 566 */
} /* Line: 559 */
} /* Line: 559 */
if (bevl_lastMid == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 569 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 569 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 569 */
 else  /* Line: 569 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 569 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 570 */ {
bevt_11_tmpany_phold = bem_get_1(bevl_low);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(-557886178, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 570 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 570 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 570 */
 else  /* Line: 570 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 570 */ {
return bevl_low;
} /* Line: 571 */
return null;
} /* Line: 573 */
bevl_lastMid = bevl_mid;
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 576 */ {
return null;
} /* Line: 577 */
} /* Line: 576 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGetDirect_0() {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGetDirect_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {187, 187, 187, 187, 187, 191, 195, 195, 0, 195, 195, 0, 0, 196, 196, 196, 198, 198, 201, 201, 202, 226, 227, 228, 233, 237, 237, 237, 238, 238, 240, 240, 250, 250, 254, 254, 258, 258, 262, 262, 262, 266, 266, 266, 266, 270, 270, 270, 271, 271, 271, 273, 273, 274, 274, 274, 290, 290, 290, 290, 290, 0, 0, 0, 302, 306, 306, 307, 307, 308, 308, 309, 309, 309, 310, 310, 311, 309, 313, 314, 314, 314, 315, 315, 317, 317, 321, 321, 325, 325, 329, 329, 329, 330, 329, 332, 336, 337, 337, 337, 338, 338, 337, 340, 343, 343, 345, 345, 348, 348, 348, 348, 349, 0, 349, 349, 350, 352, 0, 352, 352, 353, 355, 359, 359, 363, 363, 367, 367, 367, 368, 369, 369, 369, 370, 370, 370, 371, 369, 374, 375, 375, 376, 367, 381, 382, 383, 384, 385, 386, 386, 387, 387, 387, 387, 0, 0, 0, 388, 389, 390, 391, 392, 394, 395, 397, 397, 398, 399, 400, 401, 401, 402, 403, 404, 406, 411, 411, 411, 415, 416, 416, 416, 417, 417, 417, 418, 418, 418, 419, 419, 420, 420, 420, 421, 423, 423, 424, 425, 426, 427, 428, 429, 430, 435, 436, 436, 436, 442, 442, 443, 464, 467, 467, 478, 480, 484, 484, 485, 486, 486, 492, 492, 493, 493, 498, 498, 509, 512, 512, 517, 517, 517, 0, 0, 0, 518, 520, 526, 526, 526, 527, 528, 528, 528, 0, 0, 0, 529, 526, 532, 536, 536, 536, 537, 537, 539, 539, 545, 545, 545, 552, 553, 557, 557, 557, 557, 558, 559, 560, 561, 563, 564, 566, 569, 569, 569, 569, 0, 0, 0, 570, 570, 0, 0, 0, 571, 573, 575, 576, 577, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {61, 62, 63, 64, 65, 69, 80, 85, 86, 89, 94, 95, 98, 102, 103, 104, 106, 111, 112, 117, 118, 123, 124, 125, 129, 136, 137, 142, 143, 144, 146, 147, 157, 158, 162, 163, 168, 169, 174, 175, 176, 182, 183, 184, 185, 195, 196, 201, 202, 203, 204, 206, 211, 212, 213, 214, 226, 227, 232, 233, 238, 239, 242, 246, 252, 267, 272, 273, 274, 275, 276, 277, 280, 285, 286, 287, 288, 289, 295, 296, 297, 298, 299, 300, 302, 303, 307, 308, 312, 313, 318, 321, 326, 327, 328, 334, 342, 343, 346, 351, 352, 353, 354, 360, 364, 365, 369, 370, 382, 383, 384, 385, 386, 386, 389, 391, 392, 398, 398, 401, 403, 404, 410, 414, 415, 419, 420, 434, 437, 442, 443, 444, 447, 452, 453, 454, 455, 457, 459, 465, 466, 467, 468, 469, 492, 493, 494, 495, 496, 499, 504, 505, 510, 511, 516, 517, 520, 524, 527, 528, 529, 531, 532, 535, 536, 540, 545, 546, 547, 548, 551, 556, 557, 558, 559, 563, 574, 575, 576, 596, 597, 598, 603, 604, 605, 606, 609, 610, 615, 616, 617, 618, 619, 620, 621, 624, 625, 626, 627, 628, 629, 630, 631, 632, 640, 642, 643, 644, 652, 657, 658, 661, 665, 670, 673, 679, 686, 691, 694, 696, 697, 709, 714, 715, 716, 723, 728, 731, 734, 735, 743, 748, 749, 751, 754, 758, 761, 764, 775, 778, 783, 784, 785, 790, 791, 793, 796, 800, 803, 805, 811, 818, 819, 824, 825, 826, 828, 829, 834, 835, 836, 857, 858, 861, 862, 863, 864, 865, 866, 868, 871, 873, 876, 878, 882, 887, 888, 893, 894, 897, 901, 905, 906, 908, 911, 915, 918, 920, 922, 923, 925, 930, 933, 936, 940, 943, 946, 950, 953, 956, 960};
/* BEGIN LINEINFO 
assign 1 187 61
new 0 187 61
assign 1 187 62
once 0 187 62
assign 1 187 63
new 0 187 63
assign 1 187 64
once 0 187 64
new 2 187 65
new 2 191 69
assign 1 195 80
undef 1 195 85
assign 1 0 86
assign 1 195 89
undef 1 195 94
assign 1 0 95
assign 1 0 98
assign 1 196 102
new 0 196 102
assign 1 196 103
new 1 196 103
throw 1 196 104
assign 1 198 106
def 1 198 111
assign 1 201 112
equals 1 201 117
return 1 202 118
assign 1 226 123
copy 0 226 123
assign 1 227 124
copy 0 227 124
assign 1 228 125
new 0 228 125
return 1 233 129
assign 1 237 136
new 0 237 136
assign 1 237 137
equals 1 237 142
assign 1 238 143
new 0 238 143
return 1 238 144
assign 1 240 146
new 0 240 146
return 1 240 147
assign 1 250 157
toString 0 250 157
return 1 250 158
assign 1 254 162
new 1 254 162
new 1 254 163
assign 1 258 168
iteratorGet 0 258 168
return 1 258 169
assign 1 262 174
new 0 262 174
assign 1 262 175
get 1 262 175
return 1 262 176
assign 1 266 182
new 0 266 182
assign 1 266 183
subtract 1 266 183
assign 1 266 184
get 1 266 184
return 1 266 185
assign 1 270 195
new 0 270 195
assign 1 270 196
lesser 1 270 201
assign 1 271 202
new 0 271 202
assign 1 271 203
new 1 271 203
throw 1 271 204
assign 1 273 206
greaterEquals 1 273 211
assign 1 274 212
new 0 274 212
assign 1 274 213
add 1 274 213
lengthSet 1 274 214
assign 1 290 226
new 0 290 226
assign 1 290 227
greaterEquals 1 290 232
assign 1 290 233
lesser 1 290 238
assign 1 0 239
assign 1 0 242
assign 1 0 246
return 1 302 252
assign 1 306 267
lesser 1 306 272
assign 1 307 273
new 0 307 273
assign 1 307 274
subtract 1 307 274
assign 1 308 275
new 0 308 275
assign 1 308 276
add 1 308 276
assign 1 309 277
copy 0 309 277
assign 1 309 280
lesser 1 309 285
assign 1 310 286
get 1 310 286
put 2 310 287
incrementValue 0 311 288
incrementValue 0 309 289
put 2 313 295
assign 1 314 296
new 0 314 296
assign 1 314 297
subtract 1 314 297
lengthSet 1 314 298
assign 1 315 299
new 0 315 299
return 1 315 300
assign 1 317 302
new 0 317 302
return 1 317 303
assign 1 321 307
new 1 321 307
return 1 321 308
assign 1 325 312
new 1 325 312
return 1 325 313
assign 1 329 318
new 0 329 318
assign 1 329 321
lesser 1 329 326
put 2 330 327
incrementValue 0 329 328
assign 1 332 334
new 0 332 334
assign 1 336 342
create 0 336 342
assign 1 337 343
new 0 337 343
assign 1 337 346
lesser 1 337 351
assign 1 338 352
get 1 338 352
put 2 338 353
incrementValue 0 337 354
return 1 340 360
assign 1 343 364
new 1 343 364
return 1 343 365
assign 1 345 369
new 1 345 369
return 1 345 370
assign 1 348 382
new 0 348 382
assign 1 348 383
lengthGet 0 348 383
assign 1 348 384
add 1 348 384
assign 1 348 385
new 2 348 385
assign 1 349 386
iteratorGet 0 0 386
assign 1 349 389
hasNextGet 0 349 389
assign 1 349 391
nextGet 0 349 391
addValueWhole 1 350 392
assign 1 352 398
iteratorGet 0 0 398
assign 1 352 401
hasNextGet 0 352 401
assign 1 352 403
nextGet 0 352 403
addValueWhole 1 353 404
return 1 355 410
assign 1 359 414
mergeSort 0 359 414
return 1 359 415
assign 1 363 419
new 0 363 419
sortValue 2 363 420
assign 1 367 434
copy 0 367 434
assign 1 367 437
lesser 1 367 442
assign 1 368 443
copy 0 368 443
assign 1 369 444
copy 0 369 444
assign 1 369 447
lesser 1 369 452
assign 1 370 453
get 1 370 453
assign 1 370 454
get 1 370 454
assign 1 370 455
lesser 1 370 455
assign 1 371 457
copy 0 371 457
incrementValue 0 369 459
assign 1 374 465
get 1 374 465
assign 1 375 466
get 1 375 466
put 2 375 467
put 2 376 468
incrementValue 0 367 469
assign 1 381 492
new 0 381 492
assign 1 382 493
new 0 382 493
assign 1 383 494
new 0 383 494
assign 1 384 495
lengthGet 0 384 495
assign 1 385 496
lengthGet 0 385 496
assign 1 386 499
lesser 1 386 504
assign 1 387 505
lesser 1 387 510
assign 1 387 511
lesser 1 387 516
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 388 527
get 1 388 527
assign 1 389 528
get 1 389 528
assign 1 390 529
lesser 1 390 529
incrementValue 0 391 531
put 2 392 532
incrementValue 0 394 535
put 2 395 536
assign 1 397 540
lesser 1 397 545
assign 1 398 546
get 1 398 546
incrementValue 0 399 547
put 2 400 548
assign 1 401 551
lesser 1 401 556
assign 1 402 557
get 1 402 557
incrementValue 0 403 558
put 2 404 559
incrementValue 0 406 563
assign 1 411 574
new 0 411 574
assign 1 411 575
mergeSort 2 411 575
return 1 411 576
assign 1 415 596
subtract 1 415 596
assign 1 416 597
new 0 416 597
assign 1 416 598
equals 1 416 603
assign 1 417 604
new 0 417 604
assign 1 417 605
create 1 417 605
return 1 417 606
assign 1 418 609
new 0 418 609
assign 1 418 610
equals 1 418 615
assign 1 419 616
new 0 419 616
assign 1 419 617
create 1 419 617
assign 1 420 618
new 0 420 618
assign 1 420 619
get 1 420 619
put 2 420 620
return 1 421 621
assign 1 423 624
new 0 423 624
assign 1 423 625
divide 1 423 625
assign 1 424 626
subtract 1 424 626
assign 1 425 627
add 1 425 627
assign 1 426 628
mergeSort 2 426 628
assign 1 427 629
mergeSort 2 427 629
assign 1 428 630
create 1 428 630
mergeIn 2 429 631
return 1 430 632
assign 1 435 640
new 0 435 640
assign 1 436 642
new 0 436 642
assign 1 436 643
new 1 436 643
throw 1 436 644
assign 1 442 652
greater 1 442 657
assign 1 443 658
multiply 1 443 658
assign 1 464 661
assign 1 467 665
lesser 1 467 670
incrementValue 0 478 673
setValue 1 480 679
assign 1 484 686
def 1 484 691
assign 1 485 694
hasNextGet 0 485 694
assign 1 486 696
nextGet 0 486 696
addValueWhole 1 486 697
assign 1 492 709
def 1 492 714
assign 1 493 715
iteratorGet 0 493 715
iterateAdd 1 493 716
assign 1 498 723
lesser 1 498 728
incrementValue 0 509 731
assign 1 512 734
copy 0 512 734
put 2 512 735
assign 1 517 743
def 1 517 748
assign 1 517 749
sameType 1 517 749
assign 1 0 751
assign 1 0 754
assign 1 0 758
addAll 1 518 761
addValueWhole 1 520 764
assign 1 526 775
new 0 526 775
assign 1 526 778
lesser 1 526 783
assign 1 527 784
get 1 527 784
assign 1 528 785
def 1 528 790
assign 1 528 791
equals 1 528 791
assign 1 0 793
assign 1 0 796
assign 1 0 800
return 1 529 803
incrementValue 0 526 805
return 1 532 811
assign 1 536 818
find 1 536 818
assign 1 536 819
def 1 536 824
assign 1 537 825
new 0 537 825
return 1 537 826
assign 1 539 828
new 0 539 828
return 1 539 829
assign 1 545 834
new 0 545 834
assign 1 545 835
sortedFind 2 545 835
return 1 545 836
assign 1 552 857
assign 1 553 858
new 0 553 858
assign 1 557 861
subtract 1 557 861
assign 1 557 862
new 0 557 862
assign 1 557 863
divide 1 557 863
assign 1 557 864
add 1 557 864
assign 1 558 865
get 1 558 865
assign 1 559 866
equals 1 559 866
return 1 560 868
assign 1 561 871
greater 1 561 871
assign 1 563 873
assign 1 564 876
lesser 1 564 876
assign 1 566 878
assign 1 569 882
def 1 569 887
assign 1 569 888
equals 1 569 893
assign 1 0 894
assign 1 0 897
assign 1 0 901
assign 1 570 905
get 1 570 905
assign 1 570 906
lesser 1 570 906
assign 1 0 908
assign 1 0 911
assign 1 0 915
return 1 571 918
return 1 573 920
assign 1 575 922
assign 1 576 923
new 0 576 923
return 1 577 925
return 1 0 930
return 1 0 933
assign 1 0 936
return 1 0 940
return 1 0 943
assign 1 0 946
return 1 0 950
return 1 0 953
assign 1 0 956
assign 1 0 960
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1598817457: return bem_multiplierGetDirect_0();
case -1108167878: return bem_serializeToString_0();
case 1603326601: return bem_many_0();
case 741606418: return bem_lengthGetDirect_0();
case -2048609488: return bem_tagGet_0();
case -811598956: return bem_fieldNamesGet_0();
case 1457945060: return bem_sortValue_0();
case -632169362: return bem_print_0();
case 1730620110: return bem_serializationIteratorGet_0();
case -1004079418: return bem_once_0();
case 2077040828: return bem_copy_0();
case -39142453: return bem_clear_0();
case 429419643: return bem_echo_0();
case -1051309538: return bem_sort_0();
case 794507746: return bem_lastGet_0();
case -1767320597: return bem_firstGet_0();
case -963755335: return bem_fieldIteratorGet_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -212376625: return bem_iteratorGet_0();
case -1918539521: return bem_toString_0();
case 1909096874: return bem_create_0();
case -918033785: return bem_sizeGet_0();
case -23670747: return bem_anyrayGet_0();
case 2106068500: return bem_arrayIteratorGet_0();
case -1291635912: return bem_lengthGet_0();
case -1762032434: return bem_anyraySet_0();
case -469171007: return bem_serializeContents_0();
case 1419414154: return bem_new_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case -545958368: return bem_toAny_0();
case -519287702: return bem_capacityGet_0();
case 1613601767: return bem_capacityGetDirect_0();
case -424311241: return bem_multiplierGet_0();
case 1242200180: return bem_mergeSort_0();
case -683861355: return bem_isEmptyGet_0();
case 1741010261: return bem_classNameGet_0();
case 1687921048: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1434304379: return bem_otherType_1(bevd_0);
case -449871089: return bem_iterateAdd_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case 1225776887: return bem_has_1(bevd_0);
case -1051761580: return bem_addAll_1(bevd_0);
case -363168387: return bem_sameType_1(bevd_0);
case -924726538: return bem_addValueWhole_1(bevd_0);
case 1446190158: return bem_sortedFind_1(bevd_0);
case 783920007: return bem_multiplierSetDirect_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case -536126381: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -800861931: return bem_capacitySetDirect_1(bevd_0);
case -145531582: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 633502395: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -1753080609: return bem_find_1(bevd_0);
case 1558522473: return bem_multiplierSet_1(bevd_0);
case 1188023351: return bem_addValue_1(bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -568151023: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case 1238334884: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case 672338113: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case -1224908964: return bem_lengthSetDirect_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -974831903: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -998795103: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1339848514: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -338587975: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1821476135: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1072657757: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 292579960: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
}
