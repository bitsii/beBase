namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject : be.BECS_Object {
public BEC_2_6_6_SystemObject() { }
static BEC_2_6_6_SystemObject() { }

   public virtual BEC_2_6_6_SystemObject bems_methodNotDefined(string name, BEC_2_6_6_SystemObject[] args) { 
     name = name.Substring(0, name.LastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(name)), new BEC_2_9_4_ContainerList(args));
   }
   public virtual BEC_2_6_6_SystemObject bems_forwardCallCp(BEC_2_4_6_TextString name, BEC_2_9_4_ContainerList args) { 
     args = (BEC_2_9_4_ContainerList) args.bem_copy_0();
     return bem_forwardCall_2(name, args);
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_2, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_3, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_5, 16));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_8, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_6 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_7 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_11 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_11, 1));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_12 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_11 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;
public virtual BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toAny_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 73 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_3;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 79 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = bem_createInstance_2(beva_cname, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_11_SystemInitializer bevt_8_tmpany_phold = null;
if (beva_cname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 89 */
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        Type ti = be.BECS_Runtime.typeInstances[key];
        if (ti != null) {
            bevl_result = (BEC_2_6_6_SystemObject) Activator.CreateInstance(ti);
        }
        if (bevl_result == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 124 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 125 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_4;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(beva_cname);
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 126 */
 else  /* Line: 127 */ {
return null;
} /* Line: 128 */
} /* Line: 125 */
bevt_8_tmpany_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_initializeIfShould_1(bevl_result);
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 139 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 140 */
if (beva_args == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 143 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_5;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
 /* Line: 151 */ {
bevt_10_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_6;
if (bevl_numargs.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_12_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_7;
bevt_11_tmpany_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpany_phold);
bevl_args2 = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 154 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_8;
bevt_14_tmpany_phold = bevl_i.bem_subtract_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpany_phold, bevt_16_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 154 */
 else  /* Line: 154 */ {
break;
} /* Line: 154 */
} /* Line: 154 */
} /* Line: 154 */
} /* Line: 152 */

        int ci = be.BECS_Ids.callIds[System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int)];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevl_rval.bemd_0(-327890059);
} /* Line: 207 */
return bevl_rval;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_9));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 235 */
if (beva_numargs == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_10));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 238 */
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_9;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      string name = "bem_" + System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      System.Reflection.MethodInfo[] methods = this.GetType().GetMethods();
      for (int i = 0;i < methods.Length;i++) {
        if (methods[i].Name.Equals(name)) {
            return be.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevl_rval.bemd_0(-327890059);
} /* Line: 295 */
if (bevl_rval == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /* Line: 298 */
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clnames();
      return bevl_xi;
} /*method end*/
public BEC_2_4_6_TextString bem_sourceFileNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clfiles();
      return bevl_xi;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_tagGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_print_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_echo_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_6_SystemObject) bem_create_0();
bevt_0_tmpany_phold = (BEC_2_6_6_SystemObject) bem_copyTo_1(bevt_1_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
if (beva_copy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 523 */
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpany_phold);
while (true)
 /* Line: 527 */ {
bevt_3_tmpany_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 527 */ {
bevt_4_tmpany_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpany_phold);
} /* Line: 528 */
 else  /* Line: 527 */ {
break;
} /* Line: 527 */
} /* Line: 527 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameType_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_1(BEC_2_4_6_TextString beva_nameac) {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemMethod bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_12));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_10;
bevl_name = beva_nameac.bem_substring_2(bevt_1_tmpany_phold, bevl_cd);
bevt_4_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_11;
bevt_3_tmpany_phold = bevl_cd.bem_add_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = beva_nameac.bem_substring_1(bevt_3_tmpany_phold);
bevl_ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bem_getMethod_2(bevl_name, bevl_ac);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_ac) {
BEC_2_6_6_SystemMethod bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_6_SystemMethod) (new BEC_2_6_6_SystemMethod()).bem_new_3(this, beva_name, beva_ac);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_getInvocation_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_10_SystemInvocation bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_10_SystemInvocation) (new BEC_2_6_10_SystemInvocation()).bem_new_3(this, beva_name, beva_args);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_once_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_many_0() {
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {31, 31, 42, 42, 53, 53, 64, 64, 68, 72, 73, 73, 73, 73, 73, 73, 73, 73, 78, 79, 79, 79, 79, 79, 79, 79, 79, 84, 84, 84, 88, 88, 89, 89, 89, 91, 124, 124, 126, 126, 126, 126, 128, 131, 131, 131, 139, 139, 140, 140, 140, 142, 142, 143, 143, 143, 145, 146, 146, 146, 146, 152, 152, 152, 153, 153, 153, 154, 154, 154, 155, 155, 155, 155, 154, 205, 207, 209, 234, 234, 235, 235, 235, 237, 237, 238, 238, 238, 240, 240, 240, 240, 241, 294, 295, 297, 297, 298, 298, 300, 300, 336, 360, 392, 392, 424, 424, 435, 461, 472, 498, 502, 502, 502, 506, 506, 510, 510, 514, 514, 518, 518, 518, 522, 522, 523, 525, 525, 526, 526, 527, 528, 528, 534, 534, 540, 546, 546, 550, 550, 554, 554, 558, 558, 581, 628, 628, 632, 632, 632, 687, 687, 691, 691, 691, 695, 695, 696, 696, 697, 697, 697, 697, 698, 698, 702, 702, 706, 706};
public static int[] bevs_smnlec
 = new int[] {50, 51, 55, 56, 60, 61, 65, 66, 69, 80, 82, 83, 84, 85, 86, 87, 88, 89, 102, 104, 105, 106, 107, 108, 109, 110, 111, 118, 119, 120, 133, 138, 139, 140, 141, 143, 150, 155, 157, 158, 159, 160, 163, 166, 167, 168, 194, 199, 200, 201, 202, 204, 209, 210, 211, 212, 214, 215, 216, 217, 218, 220, 221, 226, 227, 228, 229, 230, 233, 238, 239, 240, 241, 242, 243, 273, 275, 277, 296, 301, 302, 303, 304, 306, 311, 312, 313, 314, 316, 317, 318, 319, 320, 329, 331, 333, 338, 339, 340, 342, 343, 351, 359, 367, 368, 376, 377, 381, 384, 388, 391, 396, 397, 402, 406, 407, 411, 412, 417, 418, 424, 425, 426, 436, 441, 442, 444, 445, 446, 447, 450, 452, 453, 463, 464, 470, 477, 478, 482, 483, 487, 488, 492, 493, 499, 507, 508, 513, 514, 519, 527, 528, 533, 534, 539, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 564, 565, 569, 570};
/* BEGIN LINEINFO 
assign 1 31 50
new 0 31 50
return 1 31 51
assign 1 42 55
new 0 42 55
return 1 42 56
assign 1 53 60
new 0 53 60
return 1 53 61
assign 1 64 65
new 0 64 65
return 1 64 66
return 1 68 69
assign 1 72 80
new 0 72 80
assign 1 73 82
new 0 73 82
assign 1 73 83
add 1 73 83
assign 1 73 84
new 0 73 84
assign 1 73 85
add 1 73 85
assign 1 73 86
classNameGet 0 73 86
assign 1 73 87
add 1 73 87
assign 1 73 88
new 1 73 88
throw 1 73 89
assign 1 78 102
new 0 78 102
assign 1 79 104
new 0 79 104
assign 1 79 105
add 1 79 105
assign 1 79 106
new 0 79 106
assign 1 79 107
add 1 79 107
assign 1 79 108
classNameGet 0 79 108
assign 1 79 109
add 1 79 109
assign 1 79 110
new 1 79 110
throw 1 79 111
assign 1 84 118
new 0 84 118
assign 1 84 119
createInstance 2 84 119
return 1 84 120
assign 1 88 133
undef 1 88 138
assign 1 89 139
new 0 89 139
assign 1 89 140
new 1 89 140
throw 1 89 141
assign 1 91 143
assign 1 124 150
undef 1 124 155
assign 1 126 157
new 0 126 157
assign 1 126 158
add 1 126 158
assign 1 126 159
new 1 126 159
throw 1 126 160
return 1 128 163
assign 1 131 166
new 0 131 166
assign 1 131 167
initializeIfShould 1 131 167
return 1 131 168
assign 1 139 194
undef 1 139 199
assign 1 140 200
new 0 140 200
assign 1 140 201
new 1 140 201
throw 1 140 202
assign 1 142 204
undef 1 142 209
assign 1 143 210
new 0 143 210
assign 1 143 211
new 1 143 211
throw 1 143 212
assign 1 145 214
lengthGet 0 145 214
assign 1 146 215
new 0 146 215
assign 1 146 216
add 1 146 216
assign 1 146 217
toString 0 146 217
assign 1 146 218
add 1 146 218
assign 1 152 220
new 0 152 220
assign 1 152 221
greater 1 152 226
assign 1 153 227
new 0 153 227
assign 1 153 228
subtract 1 153 228
assign 1 153 229
new 1 153 229
assign 1 154 230
new 0 154 230
assign 1 154 233
lesser 1 154 238
assign 1 155 239
new 0 155 239
assign 1 155 240
subtract 1 155 240
assign 1 155 241
get 1 155 241
put 2 155 242
incrementValue 0 154 243
assign 1 205 273
new 0 205 273
toString 0 207 275
return 1 209 277
assign 1 234 296
undef 1 234 301
assign 1 235 302
new 0 235 302
assign 1 235 303
new 1 235 303
throw 1 235 304
assign 1 237 306
undef 1 237 311
assign 1 238 312
new 0 238 312
assign 1 238 313
new 1 238 313
throw 1 238 314
assign 1 240 316
new 0 240 316
assign 1 240 317
add 1 240 317
assign 1 240 318
toString 0 240 318
assign 1 240 319
add 1 240 319
assign 1 241 320
hashGet 0 241 320
assign 1 294 329
new 0 294 329
toString 0 295 331
assign 1 297 333
def 1 297 338
assign 1 298 339
new 0 298 339
return 1 298 340
assign 1 300 342
new 0 300 342
return 1 300 343
return 1 336 351
return 1 360 359
assign 1 392 367
new 0 392 367
return 1 392 368
assign 1 424 376
new 0 424 376
return 1 424 377
assign 1 435 381
new 0 435 381
return 1 461 384
assign 1 472 388
new 0 472 388
return 1 498 391
assign 1 502 396
equals 1 502 396
assign 1 502 397
not 0 502 402
return 1 502 402
assign 1 506 406
classNameGet 0 506 406
return 1 506 407
assign 1 510 411
toString 0 510 411
print 0 510 412
assign 1 514 417
toString 0 514 417
echo 0 514 418
assign 1 518 424
create 0 518 424
assign 1 518 425
copyTo 1 518 425
return 1 518 426
assign 1 522 436
undef 1 522 441
return 1 523 442
assign 1 525 444
new 0 525 444
assign 1 525 445
new 2 525 445
assign 1 526 446
new 0 526 446
assign 1 526 447
new 2 526 447
assign 1 527 450
hasNextGet 0 527 450
assign 1 528 452
nextGet 0 528 452
nextSet 1 528 453
assign 1 534 463
classNameGet 0 534 463
return 1 534 464
return 1 540 470
assign 1 546 477
new 1 546 477
return 1 546 478
assign 1 550 482
new 1 550 482
return 1 550 483
assign 1 554 487
new 1 554 487
return 1 554 488
assign 1 558 492
new 0 558 492
return 1 558 493
return 1 581 499
assign 1 628 507
new 0 628 507
return 1 628 508
assign 1 632 513
sameClass 1 632 513
assign 1 632 514
not 0 632 519
return 1 632 519
assign 1 687 527
new 0 687 527
return 1 687 528
assign 1 691 533
sameType 1 691 533
assign 1 691 534
not 0 691 539
return 1 691 539
assign 1 695 551
new 0 695 551
assign 1 695 552
rfind 1 695 552
assign 1 696 553
new 0 696 553
assign 1 696 554
substring 2 696 554
assign 1 697 555
new 0 697 555
assign 1 697 556
add 1 697 556
assign 1 697 557
substring 1 697 557
assign 1 697 558
new 1 697 558
assign 1 698 559
getMethod 2 698 559
return 1 698 560
assign 1 702 564
new 3 702 564
return 1 702 565
assign 1 706 569
new 3 706 569
return 1 706 570
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1170883362: return bem_deserializeClassNameGet_0();
case -869030838: return bem_hashGet_0();
case -694642189: return bem_serializationIteratorGet_0();
case 716581775: return bem_fieldIteratorGet_0();
case 1276785109: return bem_once_0();
case -838633237: return bem_serializeToString_0();
case -327890059: return bem_toString_0();
case 1885938794: return bem_toAny_0();
case 1778404598: return bem_tagGet_0();
case 1207509984: return bem_print_0();
case -864977132: return bem_echo_0();
case -1626502172: return bem_iteratorGet_0();
case -231534902: return bem_new_0();
case 1964495741: return bem_serializeContents_0();
case -108593702: return bem_sourceFileNameGet_0();
case -296700272: return bem_create_0();
case -640694898: return bem_many_0();
case -1470416551: return bem_copy_0();
case 498230251: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1697977276: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -898771829: return bem_otherType_1(bevd_0);
case 1971930884: return bem_notEquals_1(bevd_0);
case 871367475: return bem_def_1(bevd_0);
case -1118008475: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2022931262: return bem_defined_1(bevd_0);
case 873867702: return bem_undef_1(bevd_0);
case -996916931: return bem_copyTo_1(bevd_0);
case -341054699: return bem_undefined_1(bevd_0);
case 1349020478: return bem_sameObject_1(bevd_0);
case 1029744872: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1805705632: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1363115649: return bem_equals_1(bevd_0);
case 41506532: return bem_otherClass_1(bevd_0);
case -1237205225: return bem_sameClass_1(bevd_0);
case -1073870688: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 508127182: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1597816100: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -282965627: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1721714391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -48765507: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1009765426: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1302207765: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
}
}
