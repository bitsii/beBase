namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject : be.BECS_Object {
public BEC_2_6_6_SystemObject() { }
static BEC_2_6_6_SystemObject() { }

   public virtual BEC_2_6_6_SystemObject bems_methodNotDefined(string name, BEC_2_6_6_SystemObject[] args) { 
     name = name.Substring(0, name.LastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(name)), new BEC_2_9_4_ContainerList(args));
   }
   public virtual BEC_2_6_6_SystemObject bems_forwardCallCp(BEC_2_4_6_TextString name, BEC_2_9_4_ContainerList args) { 
     args = (BEC_2_9_4_ContainerList) args.bem_copy_0();
     return bem_forwardCall_2(name, args);
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_2, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_3, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_5, 16));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_8, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_6 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_7 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_11 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_11, 1));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_12 = {0x5F};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_11 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public virtual BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toAny_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 73 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 78 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(beva_name);
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_3;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 79 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = bem_createInstance_2(beva_cname, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_11_SystemInitializer bevt_8_tmpany_phold = null;
if (beva_cname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 89 */
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        Type ti = be.BECS_Runtime.typeInstances[key];
        if (ti != null) {
            bevl_result = (BEC_2_6_6_SystemObject) Activator.CreateInstance(ti);
        }
        if (bevl_result == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 124 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 125 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_4;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(beva_cname);
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 126 */
 else  /* Line: 127 */ {
return null;
} /* Line: 128 */
} /* Line: 125 */
bevt_8_tmpany_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_initializeIfShould_1(bevl_result);
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 139 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 140 */
if (beva_args == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 143 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_5;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
 /* Line: 151 */ {
bevt_10_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_6;
if (bevl_numargs.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_12_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_7;
bevt_11_tmpany_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpany_phold);
bevl_args2 = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 154 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_8;
bevt_14_tmpany_phold = bevl_i.bem_subtract_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpany_phold, bevt_16_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 154 */
 else  /* Line: 154 */ {
break;
} /* Line: 154 */
} /* Line: 154 */
} /* Line: 154 */
} /* Line: 152 */

        int ci = be.BECS_Ids.callIds[System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int)];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevl_rval.bemd_0(-977833063);
} /* Line: 207 */
return bevl_rval;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_9));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 235 */
if (beva_numargs == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_10));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 238 */
bevt_7_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_9;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      string name = "bem_" + System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      System.Reflection.MethodInfo[] methods = this.GetType().GetMethods();
      for (int i = 0;i < methods.Length;i++) {
        if (methods[i].Name.Equals(name)) {
            return be.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevl_rval.bemd_0(-977833063);
} /* Line: 295 */
if (bevl_rval == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /* Line: 298 */
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clnames();
      return bevl_xi;
} /*method end*/
public BEC_2_4_6_TextString bem_sourceFileNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clfiles();
      return bevl_xi;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_tagGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_print_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_echo_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
bevt_0_tmpany_phold.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_6_SystemObject) bem_create_0();
bevt_0_tmpany_phold = (BEC_2_6_6_SystemObject) bem_copyTo_1(bevt_1_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
if (beva_copy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 523 */
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpany_phold);
while (true)
 /* Line: 527 */ {
bevt_3_tmpany_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 527 */ {
bevt_4_tmpany_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpany_phold);
} /* Line: 528 */
 else  /* Line: 527 */ {
break;
} /* Line: 527 */
} /* Line: 527 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sameType_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_1(BEC_2_4_6_TextString beva_nameac) {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemMethod bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_12));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_10;
bevl_name = beva_nameac.bem_substring_2(bevt_1_tmpany_phold, bevl_cd);
bevt_4_tmpany_phold = bece_BEC_2_6_6_SystemObject_bevo_11;
bevt_3_tmpany_phold = bevl_cd.bem_add_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = beva_nameac.bem_substring_1(bevt_3_tmpany_phold);
bevl_ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bem_getMethod_2(bevl_name, bevl_ac);
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_ac) {
BEC_2_6_6_SystemMethod bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_6_SystemMethod) (new BEC_2_6_6_SystemMethod()).bem_new_3(this, beva_name, beva_ac);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_getInvocation_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_10_SystemInvocation bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_10_SystemInvocation) (new BEC_2_6_10_SystemInvocation()).bem_new_3(this, beva_name, beva_args);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_once_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_many_0() {
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {31, 31, 42, 42, 53, 53, 64, 64, 68, 72, 73, 73, 73, 73, 73, 73, 73, 73, 78, 79, 79, 79, 79, 79, 79, 79, 79, 84, 84, 84, 88, 88, 89, 89, 89, 91, 124, 124, 126, 126, 126, 126, 128, 131, 131, 131, 139, 139, 140, 140, 140, 142, 142, 143, 143, 143, 145, 146, 146, 146, 146, 152, 152, 152, 153, 153, 153, 154, 154, 154, 155, 155, 155, 155, 154, 205, 207, 209, 234, 234, 235, 235, 235, 237, 237, 238, 238, 238, 240, 240, 240, 240, 241, 294, 295, 297, 297, 298, 298, 300, 300, 336, 360, 392, 392, 424, 424, 435, 461, 472, 498, 502, 502, 502, 506, 506, 510, 510, 514, 514, 518, 518, 518, 522, 522, 523, 525, 525, 526, 526, 527, 528, 528, 534, 534, 540, 546, 546, 550, 550, 554, 554, 558, 558, 581, 628, 628, 632, 632, 632, 664, 664, 668, 668, 668, 672, 672, 673, 673, 674, 674, 674, 674, 675, 675, 679, 679, 683, 683};
public static int[] bevs_smnlec
 = new int[] {53, 54, 58, 59, 63, 64, 68, 69, 72, 83, 85, 86, 87, 88, 89, 90, 91, 92, 105, 107, 108, 109, 110, 111, 112, 113, 114, 121, 122, 123, 136, 141, 142, 143, 144, 146, 153, 158, 160, 161, 162, 163, 166, 169, 170, 171, 197, 202, 203, 204, 205, 207, 212, 213, 214, 215, 217, 218, 219, 220, 221, 223, 224, 229, 230, 231, 232, 233, 236, 241, 242, 243, 244, 245, 246, 276, 278, 280, 299, 304, 305, 306, 307, 309, 314, 315, 316, 317, 319, 320, 321, 322, 323, 332, 334, 336, 341, 342, 343, 345, 346, 354, 362, 370, 371, 379, 380, 384, 387, 391, 394, 399, 400, 405, 409, 410, 414, 415, 420, 421, 427, 428, 429, 439, 444, 445, 447, 448, 449, 450, 453, 455, 456, 466, 467, 473, 480, 481, 485, 486, 490, 491, 495, 496, 502, 510, 511, 516, 517, 522, 530, 531, 536, 537, 542, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 567, 568, 572, 573};
/* BEGIN LINEINFO 
assign 1 31 53
new 0 31 53
return 1 31 54
assign 1 42 58
new 0 42 58
return 1 42 59
assign 1 53 63
new 0 53 63
return 1 53 64
assign 1 64 68
new 0 64 68
return 1 64 69
return 1 68 72
assign 1 72 83
new 0 72 83
assign 1 73 85
new 0 73 85
assign 1 73 86
add 1 73 86
assign 1 73 87
new 0 73 87
assign 1 73 88
add 1 73 88
assign 1 73 89
classNameGet 0 73 89
assign 1 73 90
add 1 73 90
assign 1 73 91
new 1 73 91
throw 1 73 92
assign 1 78 105
new 0 78 105
assign 1 79 107
new 0 79 107
assign 1 79 108
add 1 79 108
assign 1 79 109
new 0 79 109
assign 1 79 110
add 1 79 110
assign 1 79 111
classNameGet 0 79 111
assign 1 79 112
add 1 79 112
assign 1 79 113
new 1 79 113
throw 1 79 114
assign 1 84 121
new 0 84 121
assign 1 84 122
createInstance 2 84 122
return 1 84 123
assign 1 88 136
undef 1 88 141
assign 1 89 142
new 0 89 142
assign 1 89 143
new 1 89 143
throw 1 89 144
assign 1 91 146
assign 1 124 153
undef 1 124 158
assign 1 126 160
new 0 126 160
assign 1 126 161
add 1 126 161
assign 1 126 162
new 1 126 162
throw 1 126 163
return 1 128 166
assign 1 131 169
new 0 131 169
assign 1 131 170
initializeIfShould 1 131 170
return 1 131 171
assign 1 139 197
undef 1 139 202
assign 1 140 203
new 0 140 203
assign 1 140 204
new 1 140 204
throw 1 140 205
assign 1 142 207
undef 1 142 212
assign 1 143 213
new 0 143 213
assign 1 143 214
new 1 143 214
throw 1 143 215
assign 1 145 217
lengthGet 0 145 217
assign 1 146 218
new 0 146 218
assign 1 146 219
add 1 146 219
assign 1 146 220
toString 0 146 220
assign 1 146 221
add 1 146 221
assign 1 152 223
new 0 152 223
assign 1 152 224
greater 1 152 229
assign 1 153 230
new 0 153 230
assign 1 153 231
subtract 1 153 231
assign 1 153 232
new 1 153 232
assign 1 154 233
new 0 154 233
assign 1 154 236
lesser 1 154 241
assign 1 155 242
new 0 155 242
assign 1 155 243
subtract 1 155 243
assign 1 155 244
get 1 155 244
put 2 155 245
incrementValue 0 154 246
assign 1 205 276
new 0 205 276
toString 0 207 278
return 1 209 280
assign 1 234 299
undef 1 234 304
assign 1 235 305
new 0 235 305
assign 1 235 306
new 1 235 306
throw 1 235 307
assign 1 237 309
undef 1 237 314
assign 1 238 315
new 0 238 315
assign 1 238 316
new 1 238 316
throw 1 238 317
assign 1 240 319
new 0 240 319
assign 1 240 320
add 1 240 320
assign 1 240 321
toString 0 240 321
assign 1 240 322
add 1 240 322
assign 1 241 323
hashGet 0 241 323
assign 1 294 332
new 0 294 332
toString 0 295 334
assign 1 297 336
def 1 297 341
assign 1 298 342
new 0 298 342
return 1 298 343
assign 1 300 345
new 0 300 345
return 1 300 346
return 1 336 354
return 1 360 362
assign 1 392 370
new 0 392 370
return 1 392 371
assign 1 424 379
new 0 424 379
return 1 424 380
assign 1 435 384
new 0 435 384
return 1 461 387
assign 1 472 391
new 0 472 391
return 1 498 394
assign 1 502 399
equals 1 502 399
assign 1 502 400
not 0 502 405
return 1 502 405
assign 1 506 409
classNameGet 0 506 409
return 1 506 410
assign 1 510 414
toString 0 510 414
print 0 510 415
assign 1 514 420
toString 0 514 420
echo 0 514 421
assign 1 518 427
create 0 518 427
assign 1 518 428
copyTo 1 518 428
return 1 518 429
assign 1 522 439
undef 1 522 444
return 1 523 445
assign 1 525 447
new 0 525 447
assign 1 525 448
new 2 525 448
assign 1 526 449
new 0 526 449
assign 1 526 450
new 2 526 450
assign 1 527 453
hasNextGet 0 527 453
assign 1 528 455
nextGet 0 528 455
nextSet 1 528 456
assign 1 534 466
classNameGet 0 534 466
return 1 534 467
return 1 540 473
assign 1 546 480
new 1 546 480
return 1 546 481
assign 1 550 485
new 1 550 485
return 1 550 486
assign 1 554 490
new 1 554 490
return 1 554 491
assign 1 558 495
new 0 558 495
return 1 558 496
return 1 581 502
assign 1 628 510
new 0 628 510
return 1 628 511
assign 1 632 516
sameClass 1 632 516
assign 1 632 517
not 0 632 522
return 1 632 522
assign 1 664 530
new 0 664 530
return 1 664 531
assign 1 668 536
sameType 1 668 536
assign 1 668 537
not 0 668 542
return 1 668 542
assign 1 672 554
new 0 672 554
assign 1 672 555
rfind 1 672 555
assign 1 673 556
new 0 673 556
assign 1 673 557
substring 2 673 557
assign 1 674 558
new 0 674 558
assign 1 674 559
add 1 674 559
assign 1 674 560
substring 1 674 560
assign 1 674 561
new 1 674 561
assign 1 675 562
getMethod 2 675 562
return 1 675 563
assign 1 679 567
new 3 679 567
return 1 679 568
assign 1 683 572
new 3 683 572
return 1 683 573
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1714984646: return bem_serializeToString_0();
case 1348777534: return bem_many_0();
case -873085717: return bem_iteratorGet_0();
case 1907596400: return bem_copy_0();
case -1320125172: return bem_once_0();
case 713197195: return bem_deserializeClassNameGet_0();
case -977833063: return bem_toString_0();
case -1698152847: return bem_serializationIteratorGet_0();
case -1435450334: return bem_classNameGet_0();
case -100075913: return bem_new_0();
case 975002362: return bem_tagGet_0();
case -2080318285: return bem_sourceFileNameGet_0();
case 1418537405: return bem_fieldIteratorGet_0();
case -92908170: return bem_print_0();
case 596758489: return bem_create_0();
case 189986949: return bem_toAny_0();
case 1732066970: return bem_echo_0();
case -328171317: return bem_hashGet_0();
case 1361238708: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -36926033: return bem_notEquals_1(bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
}
