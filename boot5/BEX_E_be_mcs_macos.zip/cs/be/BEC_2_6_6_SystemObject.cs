namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject : be.BECS_Object {
public BEC_2_6_6_SystemObject() { }
static BEC_2_6_6_SystemObject() { }

   public virtual BEC_2_6_6_SystemObject bems_methodNotDefined(string name, BEC_2_6_6_SystemObject[] args) { 
     name = name.Substring(0, name.LastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(name)), new BEC_2_9_4_ContainerList(args));
   }
   public virtual BEC_2_6_6_SystemObject bems_forwardCallCp(BEC_2_4_6_TextString name, BEC_2_9_4_ContainerList args) { 
     args = (BEC_2_9_4_ContainerList) args.bem_copy_0();
     return bem_forwardCall_2(name, args);
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_0, 8));
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_1, 23));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_3, 16));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_6, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_6 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_7 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_6_SystemObject_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_6_SystemObject_bels_6, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemObject_bevo_11 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public virtual BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toAny_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_5_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_0;
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(beva_name);
bevt_6_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_1;
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bem_classNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 72*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_5_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_2;
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(beva_name);
bevt_6_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_3;
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bem_classNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 78*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = bem_createInstance_2(beva_cname, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_11_SystemInitializer bevt_8_ta_ph = null;
if (beva_cname == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 87*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_2));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 88*/
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        BETS_Object ti = be.BECS_Runtime.typeRefs[key];
        if (ti != null) {
            bevl_result = ti.bems_createInstance();
        }
        if (bevl_result == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 144*/ {
if (beva_throwOnFail.bevi_bool)/* Line: 145*/ {
bevt_6_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_4;
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(beva_cname);
bevt_4_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 146*/
 else /* Line: 147*/ {
return null;
} /* Line: 148*/
} /* Line: 145*/
bevt_8_ta_ph = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_ta_ph = bevt_8_ta_ph.bem_initializeIfShould_1(bevl_result);
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_fieldNamesGet_0() {
BEC_2_9_4_ContainerList bevl_names = null;
bevl_names = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();

     BETS_Object bevs_cano = bemc_getType();
     string[] fnames = bevs_cano.bevs_fieldNames;
     
     for (int i = 0;i < fnames.Length;i++) {
     
       bevl_names.bem_addValue_1(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(fnames[i])));

     }
     return bevl_names;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 222*/
if (beva_args == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 224*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_5));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 225*/
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_5;
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
/* Line: 233*/ {
bevt_10_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_6;
if (bevl_numargs.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 234*/ {
bevt_12_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_7;
bevt_11_ta_ph = bevl_numargs.bem_subtract_1(bevt_12_ta_ph);
bevl_args2 = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_ta_ph);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
while (true)
/* Line: 236*/ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_15_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_8;
bevt_14_ta_ph = bevl_i.bem_subtract_1(bevt_15_ta_ph);
bevt_16_ta_ph = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_ta_ph, bevt_16_ta_ph);
bevl_i.bevi_int++;
} /* Line: 236*/
 else /* Line: 236*/ {
break;
} /* Line: 236*/
} /* Line: 236*/
} /* Line: 236*/
} /* Line: 234*/

        int ci = be.BECS_Ids.callIds[bevl_cname.bems_toCsString()];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_17_ta_ph.bevi_bool)/* Line: 316*/ {
bevl_rval.bemd_0(1989693945);
} /* Line: 318*/
return bevl_rval;
} /*method end*/
public BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 328*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 329*/
if (beva_numargs == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 331*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_8));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 332*/
bevt_7_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_9;
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);

      
      string name = System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.ContainsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_9_ta_ph.bevi_bool)/* Line: 382*/ {
bevl_rval.bemd_0(1989693945);
} /* Line: 383*/
if (bevl_rval == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 385*/ {
bevt_11_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /* Line: 386*/
bevt_12_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clnames();
      return bevl_xi;
} /*method end*/
public BEC_2_4_6_TextString bem_sourceFileNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clfiles();
      return bevl_xi;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_tagGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_print_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_echo_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_6_SystemObject) bem_create_0();
bevt_0_ta_ph = (BEC_2_6_6_SystemObject) bem_copyTo_1(bevt_1_ta_ph);
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
if (beva_copy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 645*/ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 646*/
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_ta_ph);
while (true)
/* Line: 650*/ {
bevt_3_ta_ph = bevl_siter.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 650*/ {
bevt_4_ta_ph = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_ta_ph);
} /* Line: 651*/
 else /* Line: 650*/ {
break;
} /* Line: 650*/
} /* Line: 650*/
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sameClass_1(beva_other);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sameType_1(beva_other);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_1(BEC_2_4_6_TextString beva_nameac) {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemMethod bevt_5_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_6));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_ta_ph);
bevt_1_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_10;
bevl_name = beva_nameac.bem_substring_2(bevt_1_ta_ph, bevl_cd);
bevt_4_ta_ph = bece_BEC_2_6_6_SystemObject_bevo_11;
bevt_3_ta_ph = bevl_cd.bem_add_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_nameac.bem_substring_1(bevt_3_ta_ph);
bevl_ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_ta_ph);
bevt_5_ta_ph = bem_getMethod_2(bevl_name, bevl_ac);
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_getMethod_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_ac) {
BEC_2_6_6_SystemMethod bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_6_SystemMethod) (new BEC_2_6_6_SystemMethod()).bem_new_3(this, beva_name, beva_ac);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_getInvocation_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_10_SystemInvocation bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_10_SystemInvocation) (new BEC_2_6_10_SystemInvocation()).bem_new_3(this, beva_name, beva_args);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_once_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_many_0() {
return this;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {30, 30, 41, 41, 52, 52, 63, 63, 67, 71, 72, 72, 72, 72, 72, 72, 72, 72, 77, 78, 78, 78, 78, 78, 78, 78, 78, 83, 83, 83, 87, 87, 88, 88, 88, 90, 144, 144, 146, 146, 146, 146, 148, 151, 151, 151, 156, 212, 221, 221, 222, 222, 222, 224, 224, 225, 225, 225, 227, 228, 228, 228, 228, 234, 234, 234, 235, 235, 235, 236, 236, 236, 237, 237, 237, 237, 236, 316, 318, 320, 328, 328, 329, 329, 329, 331, 331, 332, 332, 332, 334, 334, 334, 334, 382, 383, 385, 385, 386, 386, 388, 388, 429, 453, 492, 492, 531, 531, 542, 576, 587, 621, 625, 625, 625, 629, 629, 633, 633, 637, 637, 641, 641, 641, 645, 645, 646, 648, 648, 649, 649, 650, 651, 651, 657, 657, 663, 669, 669, 673, 673, 677, 677, 681, 681, 709, 765, 765, 769, 769, 769, 817, 817, 821, 821, 821, 825, 825, 826, 826, 827, 827, 827, 827, 828, 828, 832, 832, 836, 836};
public static int[] bevs_smnlec
 = new int[] {49, 50, 54, 55, 59, 60, 64, 65, 68, 79, 81, 82, 83, 84, 85, 86, 87, 88, 101, 103, 104, 105, 106, 107, 108, 109, 110, 117, 118, 119, 132, 137, 138, 139, 140, 142, 149, 154, 156, 157, 158, 159, 162, 165, 166, 167, 171, 181, 207, 212, 213, 214, 215, 217, 222, 223, 224, 225, 227, 228, 229, 230, 231, 233, 234, 239, 240, 241, 242, 243, 246, 251, 252, 253, 254, 255, 256, 286, 288, 290, 309, 314, 315, 316, 317, 319, 324, 325, 326, 327, 329, 330, 331, 332, 343, 345, 347, 352, 353, 354, 356, 357, 365, 373, 381, 382, 390, 391, 395, 398, 402, 405, 410, 411, 416, 420, 421, 425, 426, 431, 432, 438, 439, 440, 450, 455, 456, 458, 459, 460, 461, 464, 466, 467, 477, 478, 484, 491, 492, 496, 497, 501, 502, 506, 507, 513, 521, 522, 527, 528, 533, 541, 542, 547, 548, 553, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 578, 579, 583, 584};
/* BEGIN LINEINFO 
assign 1 30 49
new 0 30 49
return 1 30 50
assign 1 41 54
new 0 41 54
return 1 41 55
assign 1 52 59
new 0 52 59
return 1 52 60
assign 1 63 64
new 0 63 64
return 1 63 65
return 1 67 68
assign 1 71 79
new 0 71 79
assign 1 72 81
new 0 72 81
assign 1 72 82
add 1 72 82
assign 1 72 83
new 0 72 83
assign 1 72 84
add 1 72 84
assign 1 72 85
classNameGet 0 72 85
assign 1 72 86
add 1 72 86
assign 1 72 87
new 1 72 87
throw 1 72 88
assign 1 77 101
new 0 77 101
assign 1 78 103
new 0 78 103
assign 1 78 104
add 1 78 104
assign 1 78 105
new 0 78 105
assign 1 78 106
add 1 78 106
assign 1 78 107
classNameGet 0 78 107
assign 1 78 108
add 1 78 108
assign 1 78 109
new 1 78 109
throw 1 78 110
assign 1 83 117
new 0 83 117
assign 1 83 118
createInstance 2 83 118
return 1 83 119
assign 1 87 132
undef 1 87 137
assign 1 88 138
new 0 88 138
assign 1 88 139
new 1 88 139
throw 1 88 140
assign 1 90 142
assign 1 144 149
undef 1 144 154
assign 1 146 156
new 0 146 156
assign 1 146 157
add 1 146 157
assign 1 146 158
new 1 146 158
throw 1 146 159
return 1 148 162
assign 1 151 165
new 0 151 165
assign 1 151 166
initializeIfShould 1 151 166
return 1 151 167
assign 1 156 171
new 0 156 171
return 1 212 181
assign 1 221 207
undef 1 221 212
assign 1 222 213
new 0 222 213
assign 1 222 214
new 1 222 214
throw 1 222 215
assign 1 224 217
undef 1 224 222
assign 1 225 223
new 0 225 223
assign 1 225 224
new 1 225 224
throw 1 225 225
assign 1 227 227
lengthGet 0 227 227
assign 1 228 228
new 0 228 228
assign 1 228 229
add 1 228 229
assign 1 228 230
toString 0 228 230
assign 1 228 231
add 1 228 231
assign 1 234 233
new 0 234 233
assign 1 234 234
greater 1 234 239
assign 1 235 240
new 0 235 240
assign 1 235 241
subtract 1 235 241
assign 1 235 242
new 1 235 242
assign 1 236 243
new 0 236 243
assign 1 236 246
lesser 1 236 251
assign 1 237 252
new 0 237 252
assign 1 237 253
subtract 1 237 253
assign 1 237 254
get 1 237 254
put 2 237 255
incrementValue 0 236 256
assign 1 316 286
new 0 316 286
toString 0 318 288
return 1 320 290
assign 1 328 309
undef 1 328 314
assign 1 329 315
new 0 329 315
assign 1 329 316
new 1 329 316
throw 1 329 317
assign 1 331 319
undef 1 331 324
assign 1 332 325
new 0 332 325
assign 1 332 326
new 1 332 326
throw 1 332 327
assign 1 334 329
new 0 334 329
assign 1 334 330
add 1 334 330
assign 1 334 331
toString 0 334 331
assign 1 334 332
add 1 334 332
assign 1 382 343
new 0 382 343
toString 0 383 345
assign 1 385 347
def 1 385 352
assign 1 386 353
new 0 386 353
return 1 386 354
assign 1 388 356
new 0 388 356
return 1 388 357
return 1 429 365
return 1 453 373
assign 1 492 381
new 0 492 381
return 1 492 382
assign 1 531 390
new 0 531 390
return 1 531 391
assign 1 542 395
new 0 542 395
return 1 576 398
assign 1 587 402
new 0 587 402
return 1 621 405
assign 1 625 410
equals 1 625 410
assign 1 625 411
not 0 625 416
return 1 625 416
assign 1 629 420
classNameGet 0 629 420
return 1 629 421
assign 1 633 425
toString 0 633 425
print 0 633 426
assign 1 637 431
toString 0 637 431
echo 0 637 432
assign 1 641 438
create 0 641 438
assign 1 641 439
copyTo 1 641 439
return 1 641 440
assign 1 645 450
undef 1 645 455
return 1 646 456
assign 1 648 458
new 0 648 458
assign 1 648 459
new 2 648 459
assign 1 649 460
new 0 649 460
assign 1 649 461
new 2 649 461
assign 1 650 464
hasNextGet 0 650 464
assign 1 651 466
nextGet 0 651 466
nextSet 1 651 467
assign 1 657 477
classNameGet 0 657 477
return 1 657 478
return 1 663 484
assign 1 669 491
new 1 669 491
return 1 669 492
assign 1 673 496
new 1 673 496
return 1 673 497
assign 1 677 501
new 1 677 501
return 1 677 502
assign 1 681 506
new 0 681 506
return 1 681 507
return 1 709 513
assign 1 765 521
new 0 765 521
return 1 765 522
assign 1 769 527
sameClass 1 769 527
assign 1 769 528
not 0 769 533
return 1 769 533
assign 1 817 541
new 0 817 541
return 1 817 542
assign 1 821 547
sameType 1 821 547
assign 1 821 548
not 0 821 553
return 1 821 553
assign 1 825 565
new 0 825 565
assign 1 825 566
rfind 1 825 566
assign 1 826 567
new 0 826 567
assign 1 826 568
substring 2 826 568
assign 1 827 569
new 0 827 569
assign 1 827 570
add 1 827 570
assign 1 827 571
substring 1 827 571
assign 1 827 572
new 1 827 572
assign 1 828 573
getMethod 2 828 573
return 1 828 574
assign 1 832 578
new 3 832 578
return 1 832 579
assign 1 836 583
new 3 836 583
return 1 836 584
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 110382217: return bem_sourceFileNameGet_0();
case 1986590366: return bem_hashGet_0();
case 879975179: return bem_classNameGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 887739950: return bem_serializeToString_0();
case -2129983068: return bem_toAny_0();
case 233362262: return bem_many_0();
case 888041456: return bem_tagGet_0();
case 1843544518: return bem_serializeContents_0();
case 1732513565: return bem_copy_0();
case -1588532100: return bem_echo_0();
case 1383646476: return bem_iteratorGet_0();
case 1989693945: return bem_toString_0();
case 2071597061: return bem_create_0();
case -1084228149: return bem_print_0();
case 714460463: return bem_once_0();
case 162533386: return bem_fieldNamesGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 1105152133: return bem_new_0();
case -153156208: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1096638030: return bem_undefined_1(bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
}
