namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile : BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
static BEC_2_2_4_IOFile() { }
private static byte[] becc_BEC_2_2_4_IOFile_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_2_4_IOFile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_inst;

public static new BET_2_2_4_IOFile bece_BEC_2_2_4_IOFile_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) {
bem_pathSet_1(beva__path);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_readerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 60 */
return bevp_reader;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_writerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_writer == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 67 */
return bevp_writer;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_delete_0() {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          File.Delete(bevls_path);
          } /* Line: 96 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bemd_0(-1230109757);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-232766621);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-967823026);
bevt_0_tmpany_phold.bemd_0(-465136955);
bevt_3_tmpany_phold = beva_other.bemd_0(1891529279);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_tmpany_phold.bemd_0(2029687354);
bevt_4_tmpany_phold = bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_tmpany_phold.bemd_0(2029687354);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdirs_0() {
bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdir_0() {
bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeDirs_0() {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_t = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevl_strn.bemd_0(1320930157);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_5_tmpany_phold = bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpany_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 137 */ {
return this;
} /* Line: 139 */
bevt_7_tmpany_phold = bevl_parentpath.bemd_0(-967823026);
bevt_7_tmpany_phold.bemd_0(-465136955);

         Directory.CreateDirectory(
         System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int)
         );
         } /* Line: 164 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirectoryGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isDirGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (Directory.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 216 */
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isFileGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 239 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (File.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 264 */
return bevl_result;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeFile_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_writerGet_0();
bevt_0_tmpany_phold.bemd_0(2029687354);
bevt_1_tmpany_phold = bem_writerGet_0();
bevt_1_tmpany_phold.bemd_0(388298950);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 282 */ {
return null;
} /* Line: 283 */
bevt_2_tmpany_phold = bem_contentsNoCheckGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsNoCheckGet_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
bevl_r = bem_readerGet_0();
bevl_r.bemd_0(2029687354);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(1571649994);
bevl_r.bemd_0(388298950);
return bevl_res;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
bevt_4_tmpany_phold = bem_pathGet_0();
bevt_3_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_4_tmpany_phold.bem_parentGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_7_tmpany_phold = bem_pathGet_0();
bevt_6_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 298 */
bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_6_6_SystemObject bevl_w = null;
bevl_w = bem_writerGet_0();
bevl_w.bemd_0(2029687354);
bevl_w.bemd_1(-204857228, beva_contents);
bevl_w.bemd_0(388298950);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_sz;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_existsGet_0() {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
bevl_tvala = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
      if (File.Exists(bevls_path) || Directory.Exists(bevls_path)) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_absPathGet_0() {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
 /* Line: 374 */ {
} /* Line: 375 */
 /* Line: 383 */ {
bevl_abstr = bevp_path.bem_pathGet_0();
} /* Line: 384 */
bevl_absp = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_close_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevp_reader.bemd_0(388298950);
} /* Line: 392 */
if (bevp_writer == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevp_writer.bemd_0(388298950);
} /* Line: 395 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_17_IOFileDirectoryIterator) (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readerGetDirect_0() {
return bevp_reader;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writerGetDirect_0() {
return bevp_writer;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_writerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {47, 47, 51, 51, 55, 59, 59, 60, 60, 62, 66, 66, 67, 67, 69, 83, 106, 106, 106, 106, 107, 107, 108, 108, 109, 110, 111, 112, 112, 117, 120, 131, 132, 133, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 136, 137, 139, 141, 141, 177, 177, 189, 190, 191, 225, 237, 238, 239, 273, 277, 277, 278, 278, 282, 282, 282, 283, 285, 285, 289, 290, 291, 292, 293, 297, 297, 297, 297, 297, 297, 298, 298, 298, 298, 300, 304, 305, 306, 307, 312, 319, 331, 332, 366, 384, 386, 387, 391, 391, 392, 394, 394, 395, 400, 400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 34, 35, 39, 45, 50, 51, 52, 54, 59, 64, 65, 66, 68, 73, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 105, 109, 126, 127, 128, 129, 130, 131, 132, 134, 135, 140, 141, 144, 148, 151, 152, 154, 156, 157, 167, 168, 174, 175, 176, 184, 190, 191, 192, 200, 205, 206, 207, 208, 215, 216, 221, 222, 224, 225, 230, 231, 232, 233, 234, 245, 246, 247, 248, 249, 254, 255, 256, 257, 258, 260, 265, 266, 267, 268, 273, 274, 279, 280, 286, 294, 296, 297, 302, 307, 308, 310, 315, 316, 322, 323, 326, 329, 332, 336, 340, 343, 347, 351, 354, 358};
/* BEGIN LINEINFO 
assign 1 47 28
new 1 47 28
pathSet 1 47 29
assign 1 51 34
apNew 1 51 34
pathSet 1 51 35
pathSet 1 55 39
assign 1 59 45
undef 1 59 50
assign 1 60 51
toString 0 60 51
assign 1 60 52
new 1 60 52
return 1 62 54
assign 1 66 59
undef 1 66 64
assign 1 67 65
toString 0 67 65
assign 1 67 66
new 1 67 66
return 1 69 68
assign 1 83 73
existsGet 0 83 73
assign 1 106 90
pathGet 0 106 90
assign 1 106 91
parentGet 0 106 91
assign 1 106 92
fileGet 0 106 92
makeDirs 0 106 93
assign 1 107 94
writerGet 0 107 94
assign 1 107 95
open 0 107 95
assign 1 108 96
readerGet 0 108 96
assign 1 108 97
open 0 108 97
copyData 1 109 98
close 0 110 99
close 0 111 100
assign 1 112 101
new 0 112 101
return 1 112 102
makeDirs 0 117 105
makeDirs 0 120 109
assign 1 131 126
toString 0 131 126
assign 1 132 127
new 0 132 127
assign 1 133 128
new 0 133 128
assign 1 134 129
new 0 134 129
assign 1 135 130
toString 0 135 130
assign 1 135 131
emptyGet 0 135 131
assign 1 135 132
notEquals 1 135 132
assign 1 135 134
existsGet 0 135 134
assign 1 135 135
not 0 135 140
assign 1 0 141
assign 1 0 144
assign 1 0 148
assign 1 136 151
parentGet 0 136 151
assign 1 137 152
equals 1 137 152
return 1 139 154
assign 1 141 156
fileGet 0 141 156
makeDirs 0 141 157
assign 1 177 167
isDirGet 0 177 167
return 1 177 168
assign 1 189 174
new 0 189 174
assign 1 190 175
toString 0 190 175
assign 1 191 176
existsGet 0 191 176
return 1 225 184
assign 1 237 190
new 0 237 190
assign 1 238 191
toString 0 238 191
assign 1 239 192
existsGet 0 239 192
return 1 273 200
assign 1 277 205
writerGet 0 277 205
open 0 277 206
assign 1 278 207
writerGet 0 278 207
close 0 278 208
assign 1 282 215
existsGet 0 282 215
assign 1 282 216
not 0 282 221
return 1 283 222
assign 1 285 224
contentsNoCheckGet 0 285 224
return 1 285 225
assign 1 289 230
readerGet 0 289 230
open 0 290 231
assign 1 291 232
readString 0 291 232
close 0 292 233
return 1 293 234
assign 1 297 245
pathGet 0 297 245
assign 1 297 246
parentGet 0 297 246
assign 1 297 247
fileGet 0 297 247
assign 1 297 248
existsGet 0 297 248
assign 1 297 249
not 0 297 254
assign 1 298 255
pathGet 0 298 255
assign 1 298 256
parentGet 0 298 256
assign 1 298 257
fileGet 0 298 257
makeDirs 0 298 258
contentsNoCheckSet 1 300 260
assign 1 304 265
writerGet 0 304 265
open 0 305 266
write 1 306 267
close 0 307 268
assign 1 312 273
new 0 312 273
return 1 319 274
assign 1 331 279
new 0 331 279
assign 1 332 280
toString 0 332 280
return 1 366 286
assign 1 384 294
pathGet 0 384 294
assign 1 386 296
apNew 1 386 296
return 1 387 297
assign 1 391 302
def 1 391 307
close 0 392 308
assign 1 394 310
def 1 394 315
close 0 395 316
assign 1 400 322
new 1 400 322
return 1 400 323
return 1 0 326
return 1 0 329
assign 1 0 332
assign 1 0 336
return 1 0 340
assign 1 0 343
assign 1 0 347
return 1 0 351
assign 1 0 354
assign 1 0 358
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -608731890: return bem_contentsGet_0();
case 1845726878: return bem_mkdirs_0();
case 1291413833: return bem_readerGetDirect_0();
case 912896996: return bem_sourceFileNameGet_0();
case 1216997746: return bem_writerGetDirect_0();
case 521003555: return bem_absPathGet_0();
case 1443041557: return bem_echo_0();
case 1002966538: return bem_mkdir_0();
case 1540192904: return bem_once_0();
case 1891529279: return bem_writerGet_0();
case -1759721369: return bem_pathGetDirect_0();
case -1230109757: return bem_pathGet_0();
case -844998411: return bem_fieldNamesGet_0();
case 80739218: return bem_isFileGet_0();
case -1762451596: return bem_print_0();
case -1737970926: return bem_toString_0();
case -1945273283: return bem_sizeGet_0();
case 942168519: return bem_serializationIteratorGet_0();
case 918246902: return bem_fieldIteratorGet_0();
case 833786164: return bem_create_0();
case 102772895: return bem_isDirGet_0();
case -1599008676: return bem_serializeToString_0();
case 212273782: return bem_hashGet_0();
case -2050938340: return bem_iteratorGet_0();
case -831239083: return bem_delete_0();
case -1156669906: return bem_makeFile_0();
case -2096345679: return bem_existsGet_0();
case 388298950: return bem_close_0();
case -677806483: return bem_toAny_0();
case 664995964: return bem_many_0();
case -465136955: return bem_makeDirs_0();
case 2045377383: return bem_classNameGet_0();
case -1065178102: return bem_deserializeClassNameGet_0();
case 536183275: return bem_tagGet_0();
case -163001642: return bem_serializeContents_0();
case 1500504504: return bem_new_0();
case 523449404: return bem_isDirectoryGet_0();
case 1804886446: return bem_contentsNoCheckGet_0();
case -296810667: return bem_copy_0();
case -1132447289: return bem_readerGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1687414608: return bem_readerSet_1(bevd_0);
case -1921250269: return bem_copyFile_1(bevd_0);
case 1564488030: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case -257578830: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 1999927566: return bem_undef_1(bevd_0);
case 1329377857: return bem_sameObject_1(bevd_0);
case 658098740: return bem_undefined_1(bevd_0);
case -653746224: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1171277060: return bem_apNew_1(bevd_0);
case -785982807: return bem_new_1(bevd_0);
case -1424462703: return bem_notEquals_1(bevd_0);
case 723799991: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1142778017: return bem_defined_1(bevd_0);
case -896840024: return bem_def_1(bevd_0);
case 595968186: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 860343971: return bem_otherClass_1(bevd_0);
case -1238755292: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
case -850057288: return bem_copyTo_1(bevd_0);
case 598878525: return bem_sameClass_1(bevd_0);
case 873957775: return bem_sameType_1(bevd_0);
case -1017562914: return bem_pathSetDirect_1(bevd_0);
case -414895087: return bem_pathSet_1(bevd_0);
case -236948784: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1686430384: return bem_otherType_1(bevd_0);
case -650068928: return bem_equals_1(bevd_0);
case -1472783276: return bem_writerSet_1(bevd_0);
case 1282101842: return bem_readerSetDirect_1(bevd_0);
case -1095472166: return bem_writerSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 348982157: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 422466535: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1266547135: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450087500: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1218154238: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1431615808: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1528949086: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOFile_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_2_4_IOFile_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_4_IOFile();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst = (BEC_2_2_4_IOFile) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_4_IOFile.bece_BEC_2_2_4_IOFile_bevs_type;
}
}
}
