namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_8_JsonParseLog : BEC_2_6_6_SystemObject {
public BEC_2_4_8_JsonParseLog() { }
static BEC_2_4_8_JsonParseLog() { }
private static byte[] becc_BEC_2_4_8_JsonParseLog_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_4_8_JsonParseLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_0 = {0x47,0x6F,0x74,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_0, 12));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_1 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_1, 1));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_2 = {0x62,0x65,0x67,0x69,0x6E,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_2, 8));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_3 = {0x65,0x6E,0x64,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_3, 6));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_4 = {0x6B,0x76,0x4D,0x69,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_4, 5));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_5 = {0x62,0x65,0x67,0x69,0x6E,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_5, 9));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_6 = {0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_6, 7));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_7 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x72,0x75,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_7, 10));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_8 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x46,0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_8, 11));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_9 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x4E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_9, 10));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_10 = {0x47,0x6F,0x74,0x20,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_10, 13));
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_1, 1));
public static new BEC_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_inst;

public static new BET_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleString_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_str);
bevt_3_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_beginMap_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_2;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_endMap_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_3;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_kvMid_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_4;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_beginList_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_5;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_endList_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_6;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleTrue_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_7;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleFalse_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_8;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleNull_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_9;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_int);
bevt_3_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {580, 580, 580, 580, 580, 584, 584, 588, 588, 592, 592, 596, 596, 600, 600, 604, 604, 608, 608, 612, 612, 616, 616, 616, 616, 616};
public static new int[] bevs_smnlec
 = new int[] {43, 44, 45, 46, 47, 52, 53, 58, 59, 64, 65, 70, 71, 76, 77, 82, 83, 88, 89, 94, 95, 103, 104, 105, 106, 107};
/* BEGIN LINEINFO 
assign 1 580 43
new 0 580 43
assign 1 580 44
add 1 580 44
assign 1 580 45
new 0 580 45
assign 1 580 46
add 1 580 46
print 0 580 47
assign 1 584 52
new 0 584 52
print 0 584 53
assign 1 588 58
new 0 588 58
print 0 588 59
assign 1 592 64
new 0 592 64
print 0 592 65
assign 1 596 70
new 0 596 70
print 0 596 71
assign 1 600 76
new 0 600 76
print 0 600 77
assign 1 604 82
new 0 604 82
print 0 604 83
assign 1 608 88
new 0 608 88
print 0 608 89
assign 1 612 94
new 0 612 94
print 0 612 95
assign 1 616 103
new 0 616 103
assign 1 616 104
add 1 616 104
assign 1 616 105
new 0 616 105
assign 1 616 106
add 1 616 106
print 0 616 107
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1941453123: return bem_kvMid_0();
case -1852877275: return bem_new_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case 926057805: return bem_endList_0();
case -20123619: return bem_serializationIteratorGet_0();
case -236887613: return bem_classNameGet_0();
case 1076647192: return bem_create_0();
case -2092760709: return bem_once_0();
case 1359360249: return bem_echo_0();
case -1084590902: return bem_handleFalse_0();
case 1064677251: return bem_many_0();
case 904040729: return bem_beginMap_0();
case -1805276332: return bem_handleTrue_0();
case 605836827: return bem_sourceFileNameGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 928457034: return bem_serializeContents_0();
case 1026614229: return bem_endMap_0();
case -1430066973: return bem_print_0();
case -323661464: return bem_serializeToString_0();
case 849387251: return bem_toAny_0();
case -509257890: return bem_handleNull_0();
case -1172133725: return bem_beginList_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
case 996718380: return bem_toString_0();
case -1369483363: return bem_fieldNamesGet_0();
case 864393987: return bem_tagGet_0();
case 2070502838: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1385644069: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case -960159496: return bem_otherClass_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -828125239: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_JsonParseLog_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_8_JsonParseLog_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_8_JsonParseLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst = (BEC_2_4_8_JsonParseLog) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_type;
}
}
}
