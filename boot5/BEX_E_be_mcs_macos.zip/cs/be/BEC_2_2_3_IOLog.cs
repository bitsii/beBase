namespace be {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog : BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
static BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x6C,0x6F,0x67,0x67,0x65,0x64,0x20};
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 1));
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_2 = (new BEC_2_4_3_MathInt(400));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_3 = (new BEC_2_4_3_MathInt(300));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_4 = (new BEC_2_4_3_MathInt(200));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_5 = (new BEC_2_4_3_MathInt(100));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_6 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static new BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_6_6_SystemObject bevp_sink;
public virtual BEC_2_2_3_IOLog bem_new_3(BEC_2_6_6_SystemObject beva__sink, BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
bevp_sink = beva__sink;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 146*/
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 153*/
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_out_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 159*/ {
beva_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_2_3_IOLog_bels_0));
} /* Line: 160*/
if (bevp_sink == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 162*/ {
bevp_sink.bemd_1(-220546221, beva_msg);
} /* Line: 163*/
 else /* Line: 164*/ {
beva_msg.bem_print_0();
} /* Line: 165*/
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_elog_1(BEC_2_6_6_SystemObject beva_e) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_2_3_IOLog_bels_1));
bem_elog_2(bevt_0_ta_ph, beva_e);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_elog_2(BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_2_3_IOLog_bevo_0;
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 178*/ {
bem_out_1(beva_msg);
} /* Line: 179*/
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_elog_3(BEC_2_4_3_MathInt beva_level, BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_2_3_IOLog_bevo_1;
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_2(beva_level, bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 188*/ {
bem_out_1(beva_msg);
} /* Line: 189*/
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_2;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_3;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_4;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_5;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_6;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) {
bem_out_1(beva_msg);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_outputLevelGet_0() {
return bevp_outputLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() {
return bevp_outputLevel;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_levelGet_0() {
return bevp_level;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGetDirect_0() {
return bevp_level;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sinkGet_0() {
return bevp_sink;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGetDirect_0() {
return bevp_sink;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {138, 139, 140, 145, 145, 146, 146, 148, 148, 152, 152, 153, 153, 155, 155, 159, 159, 160, 162, 162, 163, 165, 170, 170, 174, 174, 174, 174, 174, 174, 178, 178, 179, 184, 184, 184, 184, 184, 184, 188, 188, 189, 194, 195, 199, 200, 204, 205, 209, 210, 214, 215, 219, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 35, 40, 41, 42, 44, 45, 51, 56, 57, 58, 60, 61, 66, 71, 72, 74, 79, 80, 83, 89, 90, 99, 100, 101, 102, 103, 104, 109, 114, 115, 125, 126, 127, 128, 129, 130, 135, 140, 141, 147, 148, 153, 154, 159, 160, 165, 166, 171, 172, 176, 180, 183, 186, 190, 194, 197, 200, 204, 208, 211, 214, 218};
/* BEGIN LINEINFO 
assign 1 138 26
assign 1 139 27
assign 1 140 28
assign 1 145 35
lesserEquals 1 145 40
assign 1 146 41
new 0 146 41
return 1 146 42
assign 1 148 44
new 0 148 44
return 1 148 45
assign 1 152 51
lesserEquals 1 152 56
assign 1 153 57
new 0 153 57
return 1 153 58
assign 1 155 60
new 0 155 60
return 1 155 61
assign 1 159 66
undef 1 159 71
assign 1 160 72
new 0 160 72
assign 1 162 74
def 1 162 79
out 1 163 80
print 0 165 83
assign 1 170 89
new 0 170 89
elog 2 170 90
assign 1 174 99
new 0 174 99
assign 1 174 100
add 1 174 100
assign 1 174 101
new 0 174 101
assign 1 174 102
tS 1 174 102
assign 1 174 103
add 1 174 103
log 1 174 104
assign 1 178 109
lesserEquals 1 178 114
out 1 179 115
assign 1 184 125
new 0 184 125
assign 1 184 126
add 1 184 126
assign 1 184 127
new 0 184 127
assign 1 184 128
tS 1 184 128
assign 1 184 129
add 1 184 129
log 2 184 130
assign 1 188 135
lesserEquals 1 188 140
out 1 189 141
assign 1 194 147
new 0 194 147
log 2 195 148
assign 1 199 153
new 0 199 153
log 2 200 154
assign 1 204 159
new 0 204 159
log 2 205 160
assign 1 209 165
new 0 209 165
log 2 210 166
assign 1 214 171
new 0 214 171
log 2 215 172
out 1 219 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
return 1 0 194
return 1 0 197
assign 1 0 200
assign 1 0 204
return 1 0 208
return 1 0 211
assign 1 0 214
assign 1 0 218
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 110382217: return bem_sourceFileNameGet_0();
case 1986590366: return bem_hashGet_0();
case 879975179: return bem_classNameGet_0();
case -667667406: return bem_will_0();
case -293461293: return bem_outputLevelGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 887739950: return bem_serializeToString_0();
case -155673190: return bem_sinkGet_0();
case -2129983068: return bem_toAny_0();
case 1246541992: return bem_levelGet_0();
case 233362262: return bem_many_0();
case 888041456: return bem_tagGet_0();
case 1296976384: return bem_levelGetDirect_0();
case 1843544518: return bem_serializeContents_0();
case 1732513565: return bem_copy_0();
case -1588532100: return bem_echo_0();
case 1383646476: return bem_iteratorGet_0();
case -1670576940: return bem_outputLevelGetDirect_0();
case 1989693945: return bem_toString_0();
case 2071597061: return bem_create_0();
case -1084228149: return bem_print_0();
case 714460463: return bem_once_0();
case 1150666657: return bem_sinkGetDirect_0();
case 162533386: return bem_fieldNamesGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 1105152133: return bem_new_0();
case -153156208: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1981222187: return bem_elog_1(bevd_0);
case 2097893024: return bem_sinkSet_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case 383257964: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case -1945878244: return bem_sinkSetDirect_1(bevd_0);
case -220546221: return bem_out_1((BEC_2_4_6_TextString) bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 1154838779: return bem_levelSet_1(bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 1286212249: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case -467771719: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case -1545022420: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case 1032239948: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1136736060: return bem_outputLevelSet_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 8996051: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case 1833406470: return bem_outputLevelSetDirect_1(bevd_0);
case -1688154617: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case -1912171072: return bem_levelSetDirect_1(bevd_0);
case 2095893025: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 973144854: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2038826872: return bem_elog_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 2003161197: return bem_elog_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1, bevd_2);
case 1979678378: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_3_IOLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
}
