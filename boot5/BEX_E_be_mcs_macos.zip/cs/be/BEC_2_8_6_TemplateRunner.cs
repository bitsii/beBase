namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner : BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
static BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_BEC_2_8_6_TemplateRunner_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_BEC_2_8_6_TemplateRunner_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_inst;

public static new BET_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_swapGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_swap == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevp_swap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 182 */
return bevp_swap;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_handOffGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_handOff == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevp_handOff = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 187 */
return bevp_handOff;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) {
bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) {
bem_new_0();
bem_load_1(beva_template);
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) {
bevp_replace = (BEC_2_8_7_TemplateReplace) (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_restart_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 209 */
bevp_stepIter = null;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_stepIterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
if (bevp_stepIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevt_1_tmpany_phold = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_tmpany_phold.bem_iteratorGet_0();
} /* Line: 216 */
return bevp_stepIter;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_1_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_1_tmpany_phold = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_tmpany_phold;
} /* Line: 223 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentNodeGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_currentRunnerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_stepIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(447389470);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = bem_stepIterGet_0();
bevl_iter.bemd_1(-1442641899, beva_node);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_4_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 241 */
 else  /* Line: 242 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 245 */
} /* Line: 240 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 249 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(622925673);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 249 */ {
bevl_s = bevl_iter.bemd_0(-1809371867);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(-363168387, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(1767861110);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(1767861110);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 256 */
 else  /* Line: 257 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 260 */
} /* Line: 255 */
 else  /* Line: 251 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(-363168387, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(1767861110);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-1698354185, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
 else  /* Line: 262 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 262 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 263 */
 else  /* Line: 264 */ {
bevt_18_tmpany_phold = bevl_s.bemd_1(1500441625, this);
bevp_output.bemd_1(-215826876, bevt_18_tmpany_phold);
} /* Line: 265 */
} /* Line: 251 */
} /* Line: 251 */
 else  /* Line: 249 */ {
break;
} /* Line: 249 */
} /* Line: 249 */
bevt_19_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_19_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_4_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 273 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 274 */
 else  /* Line: 275 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 278 */
} /* Line: 273 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 282 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(622925673);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevl_s = bevl_iter.bemd_0(-1809371867);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(-363168387, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(1767861110);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(1767861110);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 288 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 289 */
 else  /* Line: 290 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 293 */
} /* Line: 288 */
 else  /* Line: 284 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(-363168387, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(1767861110);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-1698354185, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 295 */
 else  /* Line: 295 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 295 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 296 */
} /* Line: 284 */
} /* Line: 284 */
 else  /* Line: 282 */ {
break;
} /* Line: 282 */
} /* Line: 282 */
bevt_18_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_18_tmpany_phold;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_run_0() {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
if (bevp_baton == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 303 */ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 306 */
bevl_iter = bem_stepIterGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpany_phold = bevl_iter.bemd_0(622925673);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_s = bevl_iter.bemd_0(-1809371867);
if (bevp_handOff == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_5_tmpany_phold = bevl_s.bemd_1(-363168387, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(1767861110);
bevt_6_tmpany_phold = bevp_handOff.bem_has_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 311 */
 else  /* Line: 311 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 311 */ {
bevt_8_tmpany_phold = bevl_s.bemd_0(1767861110);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 317 */
 else  /* Line: 318 */ {
bevt_9_tmpany_phold = bevl_s.bemd_1(1500441625, this);
bevp_output.bemd_1(-215826876, bevt_9_tmpany_phold);
} /* Line: 319 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_replaceGet_0() {
return bevp_replace;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGetDirect_0() {
return bevp_replace;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_outputGet_0() {
return bevp_output;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGetDirect_0() {
return bevp_output;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_output = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_output = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGetDirect_0() {
return bevp_stepIter;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_stepIter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_stepIter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGetDirect_0() {
return bevp_swap;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGetDirect_0() {
return bevp_handOff;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_batonGet_0() {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGetDirect_0() {
return bevp_baton;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() {
return bevp_runStep;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGetDirect_0() {
return bevp_runStep;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {177, 182, 182, 182, 183, 187, 187, 187, 188, 192, 193, 197, 198, 202, 203, 207, 207, 208, 209, 211, 215, 215, 216, 216, 218, 222, 222, 223, 223, 225, 229, 229, 229, 229, 234, 235, 239, 239, 240, 241, 241, 244, 245, 248, 249, 250, 251, 251, 251, 0, 0, 0, 251, 251, 0, 0, 0, 252, 252, 253, 254, 255, 256, 256, 259, 260, 262, 262, 262, 0, 0, 0, 263, 263, 265, 265, 268, 268, 272, 272, 273, 274, 274, 277, 278, 281, 282, 283, 284, 284, 284, 0, 0, 0, 284, 284, 0, 0, 0, 285, 285, 286, 287, 288, 289, 289, 292, 293, 295, 295, 295, 0, 0, 0, 296, 296, 299, 299, 303, 303, 304, 305, 306, 308, 309, 310, 311, 311, 311, 0, 0, 0, 311, 311, 0, 0, 0, 312, 312, 313, 314, 315, 316, 317, 319, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 25, 30, 31, 33, 37, 42, 43, 45, 48, 49, 53, 54, 58, 59, 64, 69, 70, 71, 73, 79, 84, 85, 86, 88, 93, 98, 99, 100, 102, 108, 109, 110, 111, 115, 116, 142, 147, 148, 150, 151, 154, 155, 158, 161, 163, 164, 169, 170, 172, 175, 179, 182, 183, 185, 188, 192, 195, 196, 197, 198, 199, 201, 202, 205, 206, 210, 212, 213, 215, 218, 222, 225, 226, 229, 230, 238, 239, 263, 268, 269, 271, 272, 275, 276, 279, 282, 284, 285, 290, 291, 293, 296, 300, 303, 304, 306, 309, 313, 316, 317, 318, 319, 320, 322, 323, 326, 327, 331, 333, 334, 336, 339, 343, 346, 347, 355, 356, 371, 376, 377, 378, 379, 381, 384, 386, 387, 392, 393, 395, 398, 402, 405, 406, 408, 411, 415, 418, 419, 420, 421, 422, 423, 424, 427, 428, 438, 441, 444, 448, 452, 455, 458, 462, 466, 469, 473, 477, 480, 484, 488, 491, 495, 499, 502, 505, 509, 513, 516, 519, 523};
/* BEGIN LINEINFO 
assign 1 177 20
new 0 177 20
assign 1 182 25
undef 1 182 30
assign 1 182 31
new 0 182 31
return 1 183 33
assign 1 187 37
undef 1 187 42
assign 1 187 43
new 0 187 43
return 1 188 45
new 1 192 48
assign 1 193 49
new 0 197 53
load 1 198 54
assign 1 202 58
new 0 202 58
load 2 203 59
assign 1 207 64
def 1 207 69
restart 0 208 70
assign 1 209 71
assign 1 211 73
assign 1 215 79
undef 1 215 84
assign 1 216 85
stepsGet 0 216 85
assign 1 216 86
iteratorGet 0 216 86
return 1 218 88
assign 1 222 93
def 1 222 98
assign 1 223 99
currentRunnerGet 0 223 99
return 1 223 100
return 1 225 102
assign 1 229 108
currentRunnerGet 0 229 108
assign 1 229 109
stepIterGet 0 229 109
assign 1 229 110
currentNodeGet 0 229 110
return 1 229 111
assign 1 234 115
stepIterGet 0 234 115
currentNodeSet 1 235 116
assign 1 239 142
def 1 239 147
assign 1 240 148
runToLabel 1 240 148
assign 1 241 150
new 0 241 150
return 1 241 151
restart 0 244 154
assign 1 245 155
assign 1 248 158
stepIterGet 0 248 158
assign 1 249 161
hasNextGet 0 249 161
assign 1 250 163
nextGet 0 250 163
assign 1 251 164
def 1 251 169
assign 1 251 170
sameType 1 251 170
assign 1 0 172
assign 1 0 175
assign 1 0 179
assign 1 251 182
strGet 0 251 182
assign 1 251 183
has 1 251 183
assign 1 0 185
assign 1 0 188
assign 1 0 192
assign 1 252 195
strGet 0 252 195
assign 1 252 196
get 1 252 196
outputSet 1 253 197
swapSet 1 254 198
assign 1 255 199
runToLabel 1 255 199
assign 1 256 201
new 0 256 201
return 1 256 202
restart 0 259 205
assign 1 260 206
assign 1 262 210
sameType 1 262 210
assign 1 262 212
strGet 0 262 212
assign 1 262 213
equals 1 262 213
assign 1 0 215
assign 1 0 218
assign 1 0 222
assign 1 263 225
new 0 263 225
return 1 263 226
assign 1 265 229
handle 1 265 229
write 1 265 230
assign 1 268 238
new 0 268 238
return 1 268 239
assign 1 272 263
def 1 272 268
assign 1 273 269
skipToLabel 1 273 269
assign 1 274 271
new 0 274 271
return 1 274 272
restart 0 277 275
assign 1 278 276
assign 1 281 279
stepIterGet 0 281 279
assign 1 282 282
hasNextGet 0 282 282
assign 1 283 284
nextGet 0 283 284
assign 1 284 285
def 1 284 290
assign 1 284 291
sameType 1 284 291
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 284 303
strGet 0 284 303
assign 1 284 304
has 1 284 304
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 285 316
strGet 0 285 316
assign 1 285 317
get 1 285 317
outputSet 1 286 318
swapSet 1 287 319
assign 1 288 320
skipToLabel 1 288 320
assign 1 289 322
new 0 289 322
return 1 289 323
restart 0 292 326
assign 1 293 327
assign 1 295 331
sameType 1 295 331
assign 1 295 333
strGet 0 295 333
assign 1 295 334
equals 1 295 334
assign 1 0 336
assign 1 0 339
assign 1 0 343
assign 1 296 346
new 0 296 346
return 1 296 347
assign 1 299 355
new 0 299 355
return 1 299 356
assign 1 303 371
def 1 303 376
run 0 304 377
restart 0 305 378
assign 1 306 379
assign 1 308 381
stepIterGet 0 308 381
assign 1 309 384
hasNextGet 0 309 384
assign 1 310 386
nextGet 0 310 386
assign 1 311 387
def 1 311 392
assign 1 311 393
sameType 1 311 393
assign 1 0 395
assign 1 0 398
assign 1 0 402
assign 1 311 405
strGet 0 311 405
assign 1 311 406
has 1 311 406
assign 1 0 408
assign 1 0 411
assign 1 0 415
assign 1 312 418
strGet 0 312 418
assign 1 312 419
get 1 312 419
outputSet 1 313 420
swapSet 1 314 421
run 0 315 422
restart 0 316 423
assign 1 317 424
assign 1 319 427
handle 1 319 427
write 1 319 428
return 1 0 438
return 1 0 441
assign 1 0 444
assign 1 0 448
return 1 0 452
return 1 0 455
assign 1 0 458
assign 1 0 462
return 1 0 466
assign 1 0 469
assign 1 0 473
return 1 0 477
assign 1 0 480
assign 1 0 484
return 1 0 488
assign 1 0 491
assign 1 0 495
return 1 0 499
return 1 0 502
assign 1 0 505
assign 1 0 509
return 1 0 513
return 1 0 516
assign 1 0 519
assign 1 0 523
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1036539736: return bem_outputGet_0();
case 2077040828: return bem_copy_0();
case 429419643: return bem_echo_0();
case 1909096874: return bem_create_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case -212376625: return bem_iteratorGet_0();
case 672569510: return bem_currentRunnerGet_0();
case 1419414154: return bem_new_0();
case 226644924: return bem_swapGetDirect_0();
case 1832702199: return bem_runStepGetDirect_0();
case -1004079418: return bem_once_0();
case 1026333638: return bem_replaceGet_0();
case -811598956: return bem_fieldNamesGet_0();
case -652211209: return bem_restart_0();
case 1603326601: return bem_many_0();
case 1730620110: return bem_serializationIteratorGet_0();
case -129390569: return bem_replaceGetDirect_0();
case 1952361038: return bem_stepIterGet_0();
case 1912399207: return bem_swapGet_0();
case -1565036598: return bem_batonGet_0();
case -963755335: return bem_fieldIteratorGet_0();
case 1687921048: return bem_hashGet_0();
case -1918539521: return bem_toString_0();
case -469171007: return bem_serializeContents_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -165092018: return bem_handOffGetDirect_0();
case 1741010261: return bem_classNameGet_0();
case -1108167878: return bem_serializeToString_0();
case 447389470: return bem_currentNodeGet_0();
case 2147101731: return bem_outputGetDirect_0();
case -632169362: return bem_print_0();
case -545958368: return bem_toAny_0();
case -2048609488: return bem_tagGet_0();
case 1088031318: return bem_handOffGet_0();
case 1076621388: return bem_runStepGet_0();
case 1597345904: return bem_stepIterGetDirect_0();
case -848412400: return bem_run_0();
case -817917946: return bem_batonGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1434304379: return bem_otherType_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case -1925568616: return bem_stepIterSetDirect_1(bevd_0);
case -363168387: return bem_sameType_1(bevd_0);
case 677806890: return bem_swapSet_1(bevd_0);
case -1412336739: return bem_replaceSet_1(bevd_0);
case -2040557722: return bem_runStepSetDirect_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1113947968: return bem_runStepSet_1(bevd_0);
case 552521041: return bem_swapSetDirect_1(bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case 335073855: return bem_stepIterSet_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case -536126381: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1778853951: return bem_handOffSetDirect_1(bevd_0);
case 812112809: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case 1504098178: return bem_batonSetDirect_1(bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case -1406088826: return bem_outputSet_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 802335743: return bem_handOffSet_1(bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case 1821826716: return bem_batonSet_1(bevd_0);
case 1987200820: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case 1503466776: return bem_outputSetDirect_1(bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1442641899: return bem_currentNodeSet_1(bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case 1113670570: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1969671644: return bem_replaceSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1339848514: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_TemplateRunner_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_6_TemplateRunner_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_8_6_TemplateRunner();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst = (BEC_2_8_6_TemplateRunner) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_type;
}
}
}
