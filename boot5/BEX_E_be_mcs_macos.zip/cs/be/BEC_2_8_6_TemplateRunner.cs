namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner : BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
static BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_BEC_2_8_6_TemplateRunner_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_BEC_2_8_6_TemplateRunner_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_inst;

public static new BET_2_8_6_TemplateRunner bece_BEC_2_8_6_TemplateRunner_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_swapGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_swap == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 181*/ {
bevp_swap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 181*/
return bevp_swap;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_handOffGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_handOff == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 186*/ {
bevp_handOff = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 186*/
return bevp_handOff;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) {
bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) {
bem_new_0();
bem_load_1(beva_template);
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) {
bevp_replace = (BEC_2_8_7_TemplateReplace) (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_restart_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 206*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 208*/
bevp_stepIter = null;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_stepIterGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
if (bevp_stepIter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_1_ta_ph = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_ta_ph.bem_iteratorGet_0();
} /* Line: 215*/
return bevp_stepIter;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_1_ta_ph = null;
if (bevp_baton == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_1_ta_ph = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_ta_ph;
} /* Line: 222*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentNodeGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_8_6_TemplateRunner bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_currentRunnerGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_stepIterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(552713137);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = bem_stepIterGet_0();
bevl_iter.bemd_1(1068584740, beva_node);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_4_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 240*/
 else /* Line: 241*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 244*/
} /* Line: 239*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 248*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(36836391);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 248*/ {
bevl_s = bevl_iter.bemd_0(528131764);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 250*/ {
bevt_8_ta_ph = bevl_s.bemd_1(1601584010, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 250*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 250*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 250*/
 else /* Line: 250*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 250*/ {
bevt_10_ta_ph = bevl_s.bemd_0(-1974793116);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 250*/
 else /* Line: 250*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 250*/ {
bevt_11_ta_ph = bevl_s.bemd_0(-1974793116);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_13_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 255*/
 else /* Line: 256*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 259*/
} /* Line: 254*/
 else /* Line: 250*/ {
bevt_14_ta_ph = bevl_s.bemd_1(1601584010, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 261*/ {
bevt_16_ta_ph = bevl_s.bemd_0(-1974793116);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(92268189, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 261*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 261*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 261*/
 else /* Line: 261*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 261*/ {
bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 262*/
 else /* Line: 263*/ {
bevt_18_ta_ph = bevl_s.bemd_1(283118697, this);
bevp_output.bemd_1(1757357435, bevt_18_ta_ph);
} /* Line: 264*/
} /* Line: 250*/
} /* Line: 250*/
 else /* Line: 248*/ {
break;
} /* Line: 248*/
} /* Line: 248*/
bevt_19_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_19_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
if (bevp_baton == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 271*/ {
bevt_4_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_ta_ph.bevi_bool)/* Line: 272*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 273*/
 else /* Line: 274*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 277*/
} /* Line: 272*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 281*/ {
bevt_6_ta_ph = bevl_iter.bemd_0(36836391);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 281*/ {
bevl_s = bevl_iter.bemd_0(528131764);
if (bevp_handOff == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_8_ta_ph = bevl_s.bemd_1(1601584010, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 283*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 283*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 283*/
 else /* Line: 283*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 283*/ {
bevt_10_ta_ph = bevl_s.bemd_0(-1974793116);
bevt_9_ta_ph = bevp_handOff.bem_has_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 283*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 283*/
 else /* Line: 283*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 283*/ {
bevt_11_ta_ph = bevl_s.bemd_0(-1974793116);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_ta_ph = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_ta_ph.bevi_bool)/* Line: 287*/ {
bevt_13_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_13_ta_ph;
} /* Line: 288*/
 else /* Line: 289*/ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 292*/
} /* Line: 287*/
 else /* Line: 283*/ {
bevt_14_ta_ph = bevl_s.bemd_1(1601584010, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 294*/ {
bevt_16_ta_ph = bevl_s.bemd_0(-1974793116);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(92268189, beva_label);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 294*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 294*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 294*/
 else /* Line: 294*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 294*/ {
bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /* Line: 295*/
} /* Line: 283*/
} /* Line: 283*/
 else /* Line: 281*/ {
break;
} /* Line: 281*/
} /* Line: 281*/
bevt_18_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_18_ta_ph;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_run_0() {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (bevp_baton == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 302*/ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 305*/
bevl_iter = bem_stepIterGet_0();
while (true)
/* Line: 308*/ {
bevt_3_ta_ph = bevl_iter.bemd_0(36836391);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 308*/ {
bevl_s = bevl_iter.bemd_0(528131764);
if (bevp_handOff == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 310*/ {
bevt_5_ta_ph = bevl_s.bemd_1(1601584010, bevp_runStep);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 310*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 310*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 310*/
 else /* Line: 310*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 310*/ {
bevt_7_ta_ph = bevl_s.bemd_0(-1974793116);
bevt_6_ta_ph = bevp_handOff.bem_has_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 310*/
 else /* Line: 310*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 310*/ {
bevt_8_ta_ph = bevl_s.bemd_0(-1974793116);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_ta_ph);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 316*/
 else /* Line: 317*/ {
bevt_9_ta_ph = bevl_s.bemd_1(283118697, this);
bevp_output.bemd_1(1757357435, bevt_9_ta_ph);
} /* Line: 318*/
} /* Line: 310*/
 else /* Line: 308*/ {
break;
} /* Line: 308*/
} /* Line: 308*/
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_replaceGet_0() {
return bevp_replace;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGetDirect_0() {
return bevp_replace;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_outputGet_0() {
return bevp_output;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGetDirect_0() {
return bevp_output;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_output = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_output = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGetDirect_0() {
return bevp_stepIter;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_stepIter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_stepIter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGetDirect_0() {
return bevp_swap;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGetDirect_0() {
return bevp_handOff;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_batonGet_0() {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGetDirect_0() {
return bevp_baton;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() {
return bevp_runStep;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGetDirect_0() {
return bevp_runStep;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {176, 181, 181, 181, 182, 186, 186, 186, 187, 191, 192, 196, 197, 201, 202, 206, 206, 207, 208, 210, 214, 214, 215, 215, 217, 221, 221, 222, 222, 224, 228, 228, 228, 228, 233, 234, 238, 238, 239, 240, 240, 243, 244, 247, 248, 249, 250, 250, 250, 0, 0, 0, 250, 250, 0, 0, 0, 251, 251, 252, 253, 254, 255, 255, 258, 259, 261, 261, 261, 0, 0, 0, 262, 262, 264, 264, 267, 267, 271, 271, 272, 273, 273, 276, 277, 280, 281, 282, 283, 283, 283, 0, 0, 0, 283, 283, 0, 0, 0, 284, 284, 285, 286, 287, 288, 288, 291, 292, 294, 294, 294, 0, 0, 0, 295, 295, 298, 298, 302, 302, 303, 304, 305, 307, 308, 309, 310, 310, 310, 0, 0, 0, 310, 310, 0, 0, 0, 311, 311, 312, 313, 314, 315, 316, 318, 318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 25, 30, 31, 33, 37, 42, 43, 45, 48, 49, 53, 54, 58, 59, 64, 69, 70, 71, 73, 79, 84, 85, 86, 88, 93, 98, 99, 100, 102, 108, 109, 110, 111, 115, 116, 142, 147, 148, 150, 151, 154, 155, 158, 161, 163, 164, 169, 170, 172, 175, 179, 182, 183, 185, 188, 192, 195, 196, 197, 198, 199, 201, 202, 205, 206, 210, 212, 213, 215, 218, 222, 225, 226, 229, 230, 238, 239, 263, 268, 269, 271, 272, 275, 276, 279, 282, 284, 285, 290, 291, 293, 296, 300, 303, 304, 306, 309, 313, 316, 317, 318, 319, 320, 322, 323, 326, 327, 331, 333, 334, 336, 339, 343, 346, 347, 355, 356, 371, 376, 377, 378, 379, 381, 384, 386, 387, 392, 393, 395, 398, 402, 405, 406, 408, 411, 415, 418, 419, 420, 421, 422, 423, 424, 427, 428, 438, 441, 444, 448, 452, 455, 458, 462, 466, 469, 473, 477, 480, 484, 488, 491, 495, 499, 502, 505, 509, 513, 516, 519, 523};
/* BEGIN LINEINFO 
assign 1 176 20
new 0 176 20
assign 1 181 25
undef 1 181 30
assign 1 181 31
new 0 181 31
return 1 182 33
assign 1 186 37
undef 1 186 42
assign 1 186 43
new 0 186 43
return 1 187 45
new 1 191 48
assign 1 192 49
new 0 196 53
load 1 197 54
assign 1 201 58
new 0 201 58
load 2 202 59
assign 1 206 64
def 1 206 69
restart 0 207 70
assign 1 208 71
assign 1 210 73
assign 1 214 79
undef 1 214 84
assign 1 215 85
stepsGet 0 215 85
assign 1 215 86
iteratorGet 0 215 86
return 1 217 88
assign 1 221 93
def 1 221 98
assign 1 222 99
currentRunnerGet 0 222 99
return 1 222 100
return 1 224 102
assign 1 228 108
currentRunnerGet 0 228 108
assign 1 228 109
stepIterGet 0 228 109
assign 1 228 110
currentNodeGet 0 228 110
return 1 228 111
assign 1 233 115
stepIterGet 0 233 115
currentNodeSet 1 234 116
assign 1 238 142
def 1 238 147
assign 1 239 148
runToLabel 1 239 148
assign 1 240 150
new 0 240 150
return 1 240 151
restart 0 243 154
assign 1 244 155
assign 1 247 158
stepIterGet 0 247 158
assign 1 248 161
hasNextGet 0 248 161
assign 1 249 163
nextGet 0 249 163
assign 1 250 164
def 1 250 169
assign 1 250 170
sameType 1 250 170
assign 1 0 172
assign 1 0 175
assign 1 0 179
assign 1 250 182
strGet 0 250 182
assign 1 250 183
has 1 250 183
assign 1 0 185
assign 1 0 188
assign 1 0 192
assign 1 251 195
strGet 0 251 195
assign 1 251 196
get 1 251 196
outputSet 1 252 197
swapSet 1 253 198
assign 1 254 199
runToLabel 1 254 199
assign 1 255 201
new 0 255 201
return 1 255 202
restart 0 258 205
assign 1 259 206
assign 1 261 210
sameType 1 261 210
assign 1 261 212
strGet 0 261 212
assign 1 261 213
equals 1 261 213
assign 1 0 215
assign 1 0 218
assign 1 0 222
assign 1 262 225
new 0 262 225
return 1 262 226
assign 1 264 229
handle 1 264 229
write 1 264 230
assign 1 267 238
new 0 267 238
return 1 267 239
assign 1 271 263
def 1 271 268
assign 1 272 269
skipToLabel 1 272 269
assign 1 273 271
new 0 273 271
return 1 273 272
restart 0 276 275
assign 1 277 276
assign 1 280 279
stepIterGet 0 280 279
assign 1 281 282
hasNextGet 0 281 282
assign 1 282 284
nextGet 0 282 284
assign 1 283 285
def 1 283 290
assign 1 283 291
sameType 1 283 291
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 283 303
strGet 0 283 303
assign 1 283 304
has 1 283 304
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 284 316
strGet 0 284 316
assign 1 284 317
get 1 284 317
outputSet 1 285 318
swapSet 1 286 319
assign 1 287 320
skipToLabel 1 287 320
assign 1 288 322
new 0 288 322
return 1 288 323
restart 0 291 326
assign 1 292 327
assign 1 294 331
sameType 1 294 331
assign 1 294 333
strGet 0 294 333
assign 1 294 334
equals 1 294 334
assign 1 0 336
assign 1 0 339
assign 1 0 343
assign 1 295 346
new 0 295 346
return 1 295 347
assign 1 298 355
new 0 298 355
return 1 298 356
assign 1 302 371
def 1 302 376
run 0 303 377
restart 0 304 378
assign 1 305 379
assign 1 307 381
stepIterGet 0 307 381
assign 1 308 384
hasNextGet 0 308 384
assign 1 309 386
nextGet 0 309 386
assign 1 310 387
def 1 310 392
assign 1 310 393
sameType 1 310 393
assign 1 0 395
assign 1 0 398
assign 1 0 402
assign 1 310 405
strGet 0 310 405
assign 1 310 406
has 1 310 406
assign 1 0 408
assign 1 0 411
assign 1 0 415
assign 1 311 418
strGet 0 311 418
assign 1 311 419
get 1 311 419
outputSet 1 312 420
swapSet 1 313 421
run 0 314 422
restart 0 315 423
assign 1 316 424
assign 1 318 427
handle 1 318 427
write 1 318 428
return 1 0 438
return 1 0 441
assign 1 0 444
assign 1 0 448
return 1 0 452
return 1 0 455
assign 1 0 458
assign 1 0 462
return 1 0 466
assign 1 0 469
assign 1 0 473
return 1 0 477
assign 1 0 480
assign 1 0 484
return 1 0 488
assign 1 0 491
assign 1 0 495
return 1 0 499
return 1 0 502
assign 1 0 505
assign 1 0 509
return 1 0 513
return 1 0 516
assign 1 0 519
assign 1 0 523
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1530460997: return bem_stepIterGetDirect_0();
case 1410677193: return bem_swapGetDirect_0();
case 1460710096: return bem_tagGet_0();
case -1705094422: return bem_runStepGetDirect_0();
case 1394329: return bem_batonGet_0();
case -1253293660: return bem_serializeToString_0();
case 1562650783: return bem_fieldIteratorGet_0();
case 307193318: return bem_serializeContents_0();
case -726400745: return bem_batonGetDirect_0();
case -1749321642: return bem_outputGetDirect_0();
case 552713137: return bem_currentNodeGet_0();
case -1036391864: return bem_copy_0();
case -178385347: return bem_iteratorGet_0();
case -1906768398: return bem_classNameGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 605934441: return bem_swapGet_0();
case 995223481: return bem_stepIterGet_0();
case 2142385851: return bem_restart_0();
case 1640157629: return bem_toString_0();
case -2017788998: return bem_currentRunnerGet_0();
case 2037996040: return bem_create_0();
case 755413195: return bem_handOffGet_0();
case -2070846101: return bem_hashGet_0();
case -1221104789: return bem_sourceFileNameGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case 939713627: return bem_print_0();
case -1762730269: return bem_replaceGet_0();
case 818287646: return bem_runStepGet_0();
case 1732141216: return bem_handOffGetDirect_0();
case 873076018: return bem_new_0();
case 1413602483: return bem_replaceGetDirect_0();
case 1049137909: return bem_run_0();
case 1258729534: return bem_echo_0();
case 754480318: return bem_outputGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 986422534: return bem_handOffSetDirect_1(bevd_0);
case -493310448: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 215925762: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -130009564: return bem_stepIterSet_1(bevd_0);
case 1876934831: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -1060582335: return bem_stepIterSetDirect_1(bevd_0);
case -1050684733: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 1424736244: return bem_outputSetDirect_1(bevd_0);
case 1210624279: return bem_swapSet_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case -1198094844: return bem_outputSet_1(bevd_0);
case 1111503620: return bem_replaceSet_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -1123979824: return bem_swapSetDirect_1(bevd_0);
case 1068584740: return bem_currentNodeSet_1(bevd_0);
case -1568405913: return bem_runStepSet_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case -674025440: return bem_batonSet_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -39011350: return bem_replaceSetDirect_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case 1572749393: return bem_handOffSet_1(bevd_0);
case 649232319: return bem_runStepSetDirect_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1632476535: return bem_batonSetDirect_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1988117707: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_TemplateRunner_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_6_TemplateRunner_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_8_6_TemplateRunner();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst = (BEC_2_8_6_TemplateRunner) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_8_6_TemplateRunner.bece_BEC_2_8_6_TemplateRunner_bevs_type;
}
}
}
