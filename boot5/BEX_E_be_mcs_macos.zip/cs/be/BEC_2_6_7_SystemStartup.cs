namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_7_SystemStartup : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemStartup() { }
static BEC_2_6_7_SystemStartup() { }
private static byte[] becc_BEC_2_6_7_SystemStartup_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70};
private static byte[] becc_BEC_2_6_7_SystemStartup_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemStartup_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_7_SystemStartup_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemStartup_bevo_1 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_6_7_SystemStartup bece_BEC_2_6_7_SystemStartup_bevs_inst;

public static new BET_2_6_7_SystemStartup bece_BEC_2_6_7_SystemStartup_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_7_SystemStartup bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_2_tmpany_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_6_7_SystemStartup_bevo_0;
if (bevt_2_tmpany_phold.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 31 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(136, bece_BEC_2_6_7_SystemStartup_bels_0));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 32 */
bevt_8_tmpany_phold = bece_BEC_2_6_7_SystemStartup_bevo_1;
bevt_7_tmpany_phold = bevp_args.bem_get_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) bevt_7_tmpany_phold );
bevl_x = bevt_6_tmpany_phold.bemd_0(1340694490);
bevt_9_tmpany_phold = bevl_x.bemd_0(-1186600628);
return bevt_9_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_7_SystemStartup bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemStartup bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {30, 30, 31, 31, 31, 31, 32, 32, 32, 34, 34, 34, 34, 35, 35, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {34, 35, 36, 37, 38, 43, 44, 45, 46, 48, 49, 50, 51, 52, 53, 56, 59, 62, 66};
/* BEGIN LINEINFO 
assign 1 30 34
new 0 30 34
assign 1 30 35
argsGet 0 30 35
assign 1 31 36
sizeGet 0 31 36
assign 1 31 37
new 0 31 37
assign 1 31 38
lesser 1 31 43
assign 1 32 44
new 0 32 44
assign 1 32 45
new 1 32 45
throw 1 32 46
assign 1 34 48
new 0 34 48
assign 1 34 49
get 1 34 49
assign 1 34 50
createInstance 1 34 50
assign 1 34 51
new 0 34 51
assign 1 35 52
main 0 35 52
return 1 35 53
return 1 0 56
return 1 0 59
assign 1 0 62
assign 1 0 66
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1045627857: return bem_create_0();
case -1723287273: return bem_fieldIteratorGet_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case 1927956798: return bem_argsGetDirect_0();
case 1690848108: return bem_echo_0();
case 1426474238: return bem_once_0();
case -2091217929: return bem_toAny_0();
case -1159894170: return bem_argsGet_0();
case 237106258: return bem_default_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 805348767: return bem_serializationIteratorGet_0();
case 1776712568: return bem_iteratorGet_0();
case 1340694490: return bem_new_0();
case -856707590: return bem_tagGet_0();
case 1365471067: return bem_print_0();
case 756642383: return bem_fieldNamesGet_0();
case -1287943088: return bem_copy_0();
case -348782970: return bem_serializeToString_0();
case 1963695386: return bem_toString_0();
case -1303115743: return bem_hashGet_0();
case 353377191: return bem_classNameGet_0();
case -1186600628: return bem_main_0();
case -835303456: return bem_many_0();
case -723282878: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2129603513: return bem_defined_1(bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
case -793887534: return bem_otherClass_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case -1412377002: return bem_undef_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -480348635: return bem_def_1(bevd_0);
case -550139783: return bem_otherType_1(bevd_0);
case -458868888: return bem_argsSet_1(bevd_0);
case 475132769: return bem_argsSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemStartup_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemStartup_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemStartup();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst = (BEC_2_6_7_SystemStartup) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_type;
}
}
}
