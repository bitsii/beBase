namespace be {
/* IO:File: source/extended/Properties.be */
public class BEC_2_9_11_ContainerPropertyMap : BEC_2_6_6_SystemObject {
public BEC_2_9_11_ContainerPropertyMap() { }
static BEC_2_9_11_ContainerPropertyMap() { }
private static byte[] becc_BEC_2_9_11_ContainerPropertyMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerPropertyMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerPropertyMap bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst;

public static new BET_2_9_11_ContainerPropertyMap bece_BEC_2_9_11_ContainerPropertyMap_bevs_type;

public BEC_2_9_3_ContainerMap bevp_map;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_set_2(BEC_2_4_6_TextString beva_key, BEC_2_4_6_TextString beva_value) {
bevp_map.bem_put_2(beva_key, beva_value);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_get_1(BEC_2_4_6_TextString beva_key) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getCached_1(BEC_2_4_6_TextString beva_key) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_unset_1(BEC_2_4_6_TextString beva_key) {
bevp_map.bem_delete_1(beva_key);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mapGet_0() {
return null;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_mapSet_1(BEC_2_9_3_ContainerMap beva__map) {
return this;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_load_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_map.bem_iteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGetDirect_0() {
return bevp_map;
} /*method end*/
public BEC_2_9_11_ContainerPropertyMap bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 23, 27, 27, 31, 31, 35, 38, 39, 44, 44, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 18, 23, 24, 28, 29, 32, 36, 39, 46, 47, 50, 53};
/* BEGIN LINEINFO 
assign 1 17 14
new 0 17 14
put 2 23 18
assign 1 27 23
get 1 27 23
return 1 27 24
assign 1 31 28
get 1 31 28
return 1 31 29
delete 1 35 32
return 1 38 36
return 1 39 39
assign 1 44 46
iteratorGet 0 44 46
return 1 44 47
return 1 0 50
assign 1 0 53
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1562608535: return bem_print_0();
case -104654255: return bem_mapGetDirect_0();
case 1688687204: return bem_serializeToString_0();
case 1029695809: return bem_echo_0();
case -1844917728: return bem_many_0();
case -1026733174: return bem_new_0();
case -1902089216: return bem_toString_0();
case 102554564: return bem_fieldIteratorGet_0();
case -1047617175: return bem_load_0();
case -479166709: return bem_tagGet_0();
case 185174991: return bem_copy_0();
case -1848718184: return bem_hashGet_0();
case 126670515: return bem_toAny_0();
case -31114048: return bem_iteratorGet_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -8643043: return bem_serializeContents_0();
case 1137009070: return bem_once_0();
case -785258946: return bem_create_0();
case -1549714711: return bem_mapGet_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 217968364: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1811318132: return bem_defined_1(bevd_0);
case -609621197: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -505102764: return bem_mapSet_1((BEC_2_9_3_ContainerMap) bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 196855935: return bem_getCached_1((BEC_2_4_6_TextString) bevd_0);
case -902436107: return bem_mapSetDirect_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1199492007: return bem_unset_1((BEC_2_4_6_TextString) bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 927478278: return bem_set_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerPropertyMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(29, becc_BEC_2_9_11_ContainerPropertyMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerPropertyMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst = (BEC_2_9_11_ContainerPropertyMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_type;
}
}
}
