namespace be {
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor : BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
static BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static new BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;

public static new BET_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;

public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) {
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildTransport bem_transGet_0() {
return bevp_trans;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_transGetDirect_0() {
return bevp_trans;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_transSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGetDirect_0() {
return bevp_build;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildConstants bem_constGet_0() {
return bevp_const;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constGetDirect_0() {
return bevp_const;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_constSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 16, 17, 18, 23, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 25, 26, 32, 35, 38, 42, 46, 49, 52, 56, 60, 63, 66, 70, 74, 77, 80, 84};
/* BEGIN LINEINFO 
assign 1 15 17
assign 1 16 18
buildGet 0 16 18
assign 1 17 19
constantsGet 0 17 19
assign 1 18 20
ntypesGet 0 18 20
assign 1 23 25
nextDescendGet 0 23 25
return 1 23 26
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
return 1 0 74
return 1 0 77
assign 1 0 80
assign 1 0 84
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -963755335: return bem_fieldIteratorGet_0();
case -615183710: return bem_constGet_0();
case -1004079418: return bem_once_0();
case -1108167878: return bem_serializeToString_0();
case 486528825: return bem_buildGet_0();
case 1603326601: return bem_many_0();
case -918875161: return bem_transGetDirect_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -469171007: return bem_serializeContents_0();
case -545958368: return bem_toAny_0();
case -632169362: return bem_print_0();
case -2048609488: return bem_tagGet_0();
case -212376625: return bem_iteratorGet_0();
case 667887186: return bem_ntypesGet_0();
case 1262389595: return bem_ntypesGetDirect_0();
case 1909096874: return bem_create_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case 1419414154: return bem_new_0();
case 603416881: return bem_constGetDirect_0();
case 2077040828: return bem_copy_0();
case 429419643: return bem_echo_0();
case 1730620110: return bem_serializationIteratorGet_0();
case 1741010261: return bem_classNameGet_0();
case -1918539521: return bem_toString_0();
case -31138328: return bem_transGet_0();
case -274080024: return bem_buildGetDirect_0();
case -811598956: return bem_fieldNamesGet_0();
case 1687921048: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -363168387: return bem_sameType_1(bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case 9850015: return bem_end_1(bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case 1136316771: return bem_constSetDirect_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1702353157: return bem_begin_1(bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
case 455477536: return bem_buildSetDirect_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case 943569262: return bem_transSet_1(bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case -1434304379: return bem_otherType_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case -425873190: return bem_buildSet_1(bevd_0);
case 292605993: return bem_transSetDirect_1(bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1208686813: return bem_constSet_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1521312747: return bem_ntypesSet_1(bevd_0);
case 1162742389: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case -641770360: return bem_ntypesSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;
}
}
}
