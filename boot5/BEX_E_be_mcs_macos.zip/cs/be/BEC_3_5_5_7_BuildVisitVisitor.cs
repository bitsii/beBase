namespace be {
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor : BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
static BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static new BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) {
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildTransport bem_transGet_0() {
return bevp_trans;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildConstants bem_constGet_0() {
return bevp_const;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 16, 17, 18, 23, 23, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 16, 17, 22, 23, 29, 32, 36, 39, 43, 46, 50, 53};
/* BEGIN LINEINFO 
assign 1 15 14
assign 1 16 15
buildGet 0 16 15
assign 1 17 16
constantsGet 0 17 16
assign 1 18 17
ntypesGet 0 18 17
assign 1 23 22
nextDescendGet 0 23 22
return 1 23 23
return 1 0 29
assign 1 0 32
return 1 0 36
assign 1 0 39
return 1 0 43
assign 1 0 46
return 1 0 50
assign 1 0 53
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1170883362: return bem_deserializeClassNameGet_0();
case -869030838: return bem_hashGet_0();
case -694642189: return bem_serializationIteratorGet_0();
case 716581775: return bem_fieldIteratorGet_0();
case -222699673: return bem_ntypesGet_0();
case 1276785109: return bem_once_0();
case -838633237: return bem_serializeToString_0();
case -912670062: return bem_buildGet_0();
case -327890059: return bem_toString_0();
case 1885938794: return bem_toAny_0();
case 1778404598: return bem_tagGet_0();
case 1207509984: return bem_print_0();
case -864977132: return bem_echo_0();
case 201753632: return bem_constGet_0();
case -1626502172: return bem_iteratorGet_0();
case -231534902: return bem_new_0();
case -2131755969: return bem_transGet_0();
case 1964495741: return bem_serializeContents_0();
case -108593702: return bem_sourceFileNameGet_0();
case -296700272: return bem_create_0();
case -640694898: return bem_many_0();
case -1470416551: return bem_copy_0();
case 498230251: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1697977276: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -898771829: return bem_otherType_1(bevd_0);
case -254805022: return bem_transSet_1(bevd_0);
case -1285310872: return bem_buildSet_1(bevd_0);
case 398724989: return bem_constSet_1(bevd_0);
case 1971930884: return bem_notEquals_1(bevd_0);
case 871367475: return bem_def_1(bevd_0);
case -1118008475: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2022931262: return bem_defined_1(bevd_0);
case 873867702: return bem_undef_1(bevd_0);
case 1654000102: return bem_ntypesSet_1(bevd_0);
case -996916931: return bem_copyTo_1(bevd_0);
case -341054699: return bem_undefined_1(bevd_0);
case 1992587527: return bem_end_1(bevd_0);
case 1349020478: return bem_sameObject_1(bevd_0);
case 1029744872: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1805705632: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1129766768: return bem_begin_1(bevd_0);
case -1363115649: return bem_equals_1(bevd_0);
case 41506532: return bem_otherClass_1(bevd_0);
case 2041683748: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1237205225: return bem_sameClass_1(bevd_0);
case -1073870688: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 508127182: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1597816100: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -282965627: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1721714391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -48765507: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1009765426: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1302207765: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
}
}
