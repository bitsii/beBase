namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerSetSerializationIterator : BEC_3_9_3_11_ContainerSetKeyIterator {
public BEC_3_9_3_21_ContainerSetSerializationIterator() { }
static BEC_3_9_3_21_ContainerSetSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_21_ContainerSetSerializationIterator bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst;

public static new BET_3_9_3_21_ContainerSetSerializationIterator bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public override BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
bevp_contents = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
base.bem_new_1(beva__set);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerSetSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerSetSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 552 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 552 */ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 552 */
 else  /* Line: 552 */ {
break;
} /* Line: 552 */
} /* Line: 552 */
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerSetSerializationIterator bem_postDeserialize_0() {
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_loop = bevp_contents.bem_iteratorGet_0();
while (true)
 /* Line: 558 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1870774273);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 558 */ {
bevl_value = bevt_0_tmpany_loop.bemd_0(-175035894);
bevp_set.bem_put_1(bevl_value);
} /* Line: 559 */
 else  /* Line: 558 */ {
break;
} /* Line: 558 */
} /* Line: 558 */
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_contentsGet_0() {
return bevp_contents;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGetDirect_0() {
return bevp_contents;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerSetSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerSetSerializationIterator bem_contentsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {542, 544, 548, 552, 552, 552, 553, 552, 558, 0, 558, 558, 559, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 25, 28, 33, 34, 35, 47, 47, 50, 52, 53, 62, 65, 68, 72};
/* BEGIN LINEINFO 
assign 1 542 14
new 0 542 14
new 1 544 15
addValue 1 548 19
assign 1 552 25
new 0 552 25
assign 1 552 28
lesser 1 552 33
nextSet 1 553 34
assign 1 552 35
increment 0 552 35
assign 1 558 47
iteratorGet 0 0 47
assign 1 558 50
hasNextGet 0 558 50
assign 1 558 52
nextGet 0 558 52
put 1 559 53
return 1 0 62
return 1 0 65
assign 1 0 68
assign 1 0 72
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1870774273: return bem_hasNextGet_0();
case -139353918: return bem_toAny_0();
case 1525064550: return bem_currentGetDirect_0();
case -1081619576: return bem_postDeserialize_0();
case 866115098: return bem_contentsGetDirect_0();
case -320545548: return bem_sourceFileNameGet_0();
case 369493742: return bem_currentGet_0();
case -1917983924: return bem_delete_0();
case 734060929: return bem_serializationIteratorGet_0();
case -1456235115: return bem_echo_0();
case -865211167: return bem_many_0();
case 942985440: return bem_setGetDirect_0();
case 257728248: return bem_moduGet_0();
case -175035894: return bem_nextGet_0();
case 2121617532: return bem_hashGet_0();
case 170810947: return bem_contentsGet_0();
case 1147856721: return bem_fieldIteratorGet_0();
case -1797964019: return bem_classNameGet_0();
case -41276197: return bem_create_0();
case -1943120126: return bem_serializeToString_0();
case 655269162: return bem_nodeIteratorIteratorGet_0();
case -740937572: return bem_print_0();
case -2027679173: return bem_deserializeClassNameGet_0();
case -1611636826: return bem_moduGetDirect_0();
case 332613786: return bem_serializeContents_0();
case -2058654018: return bem_toString_0();
case 378920737: return bem_slotsGet_0();
case 1310168666: return bem_copy_0();
case 148319359: return bem_new_0();
case -720365125: return bem_slotsGetDirect_0();
case -902713842: return bem_setGet_0();
case -1845563587: return bem_containerGet_0();
case 1990625095: return bem_tagGet_0();
case 903178719: return bem_fieldNamesGet_0();
case -256176855: return bem_iteratorGet_0();
case 341148236: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2090399878: return bem_setSetDirect_1(bevd_0);
case 1985783592: return bem_otherType_1(bevd_0);
case 55946271: return bem_notEquals_1(bevd_0);
case 746499770: return bem_moduSetDirect_1(bevd_0);
case 906711890: return bem_sameObject_1(bevd_0);
case -1450485572: return bem_nextSet_1(bevd_0);
case 303322036: return bem_slotsSet_1(bevd_0);
case 116775656: return bem_slotsSetDirect_1(bevd_0);
case 2070971991: return bem_def_1(bevd_0);
case -809700639: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 5956357: return bem_contentsSet_1(bevd_0);
case -342517705: return bem_setSet_1(bevd_0);
case 649776492: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2023862139: return bem_equals_1(bevd_0);
case -579051109: return bem_contentsSetDirect_1(bevd_0);
case -116587458: return bem_sameType_1(bevd_0);
case -264091635: return bem_copyTo_1(bevd_0);
case 261224447: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 635105057: return bem_defined_1(bevd_0);
case 1865504944: return bem_sameClass_1(bevd_0);
case 931107624: return bem_currentSet_1(bevd_0);
case 1350346500: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1998892078: return bem_currentSetDirect_1(bevd_0);
case 1868139329: return bem_moduSet_1(bevd_0);
case -1829045189: return bem_otherClass_1(bevd_0);
case 825055568: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -245605778: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 306277101: return bem_undefined_1(bevd_0);
case -1679251333: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 710095661: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1286703705: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 704289821: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1372536257: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1105189015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1798728092: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -275173380: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerSetSerializationIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_21_ContainerSetSerializationIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerSetSerializationIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_21_ContainerSetSerializationIterator.bece_BEC_3_9_3_21_ContainerSetSerializationIterator_bevs_type;
}
}
}
