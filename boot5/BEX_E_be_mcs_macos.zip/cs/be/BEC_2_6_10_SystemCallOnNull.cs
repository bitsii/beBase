namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_10_SystemCallOnNull : BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
static BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static new BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {366};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
assign 1 366 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2122180596: return bem_descriptionGet_0();
case 1274839480: return bem_framesGet_0();
case 759724391: return bem_klassNameGet_0();
case -100075913: return bem_new_0();
case -92908170: return bem_print_0();
case -1435450334: return bem_classNameGet_0();
case 259392180: return bem_lineNumberGet_0();
case 513446030: return bem_translatedGet_0();
case -977833063: return bem_toString_0();
case 975002362: return bem_tagGet_0();
case 1732066970: return bem_echo_0();
case 772942409: return bem_translateEmittedExceptionInner_0();
case -1795223946: return bem_getFrameText_0();
case 1714984646: return bem_serializeToString_0();
case -189801915: return bem_fileNameGet_0();
case 254421979: return bem_vvGet_0();
case 189986949: return bem_toAny_0();
case 1348777534: return bem_many_0();
case -955735029: return bem_emitLangGet_0();
case -2080318285: return bem_sourceFileNameGet_0();
case -1698152847: return bem_serializationIteratorGet_0();
case 713197195: return bem_deserializeClassNameGet_0();
case 596758489: return bem_create_0();
case 1418537405: return bem_fieldIteratorGet_0();
case 1907596400: return bem_copy_0();
case 1361238708: return bem_serializeContents_0();
case -1320125172: return bem_once_0();
case 1572891172: return bem_methodNameGet_0();
case -328171317: return bem_hashGet_0();
case -1891886196: return bem_translateEmittedException_0();
case -873085717: return bem_iteratorGet_0();
case 600569054: return bem_framesTextGet_0();
case 361863966: return bem_langGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -36926033: return bem_notEquals_1(bevd_0);
case 670363805: return bem_fileNameSet_1(bevd_0);
case -303259867: return bem_methodNameSet_1(bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case -177225278: return bem_translatedSet_1(bevd_0);
case 851657069: return bem_framesSet_1(bevd_0);
case 441223442: return bem_descriptionSet_1(bevd_0);
case 1642807478: return bem_langSet_1(bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case -1626290117: return bem_emitLangSet_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case -1297918919: return bem_lineNumberSet_1(bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case 1838644488: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2059458880: return bem_framesTextSet_1(bevd_0);
case 2073095277: return bem_klassNameSet_1(bevd_0);
case 1266007579: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 105306985: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case -1685745238: return bem_new_1(bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case -977194200: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -232827127: return bem_vvSet_1(bevd_0);
case -417378403: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1527415224: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -264075074: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemCallOnNull();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
}
