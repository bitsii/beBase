namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_10_SystemCallOnNull : BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
static BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static new BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {366};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
assign 1 366 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2085367340: return bem_emitLangGet_0();
case 1530618180: return bem_framesTextGetDirect_0();
case 2012783525: return bem_framesGetDirect_0();
case -1265013519: return bem_fieldNamesGet_0();
case 925769704: return bem_langGet_0();
case -23361149: return bem_sourceFileNameGet_0();
case 1821622439: return bem_lineNumberGet_0();
case -387683013: return bem_descriptionGet_0();
case 2119526452: return bem_deserializeClassNameGet_0();
case -399473397: return bem_descriptionGetDirect_0();
case 2077386451: return bem_translateEmittedException_0();
case -32017232: return bem_vvGetDirect_0();
case -1302207362: return bem_serializeToString_0();
case -606275227: return bem_tagGet_0();
case 1836085521: return bem_translatedGet_0();
case -1713867889: return bem_serializationIteratorGet_0();
case 1659508682: return bem_iteratorGet_0();
case 439322172: return bem_classNameGet_0();
case -1472038924: return bem_toAny_0();
case 922739318: return bem_fieldIteratorGet_0();
case -1474180855: return bem_copy_0();
case -468958884: return bem_langGetDirect_0();
case 1011957835: return bem_methodNameGetDirect_0();
case -1389578561: return bem_translatedGetDirect_0();
case -1504177720: return bem_translateEmittedExceptionInner_0();
case 1979675315: return bem_toString_0();
case -1684408485: return bem_serializeContents_0();
case -771906040: return bem_emitLangGetDirect_0();
case -1231582645: return bem_methodNameGet_0();
case 435214471: return bem_fileNameGet_0();
case -865640764: return bem_klassNameGet_0();
case 1937136245: return bem_create_0();
case -941995054: return bem_print_0();
case -1858345160: return bem_many_0();
case -2111176711: return bem_lineNumberGetDirect_0();
case -183071211: return bem_new_0();
case -589985085: return bem_getFrameText_0();
case 163561636: return bem_echo_0();
case 1192685509: return bem_klassNameGetDirect_0();
case -436164110: return bem_hashGet_0();
case 1992383723: return bem_once_0();
case -970838975: return bem_vvGet_0();
case -1972338751: return bem_fileNameGetDirect_0();
case 1173910891: return bem_framesGet_0();
case -1111230291: return bem_framesTextGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -69698825: return bem_translatedSet_1(bevd_0);
case 1662418823: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1106603847: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 247362895: return bem_emitLangSet_1(bevd_0);
case 766930230: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1145705536: return bem_methodNameSetDirect_1(bevd_0);
case -339333895: return bem_equals_1(bevd_0);
case 1495973768: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 823462848: return bem_framesTextSetDirect_1(bevd_0);
case 938978423: return bem_otherClass_1(bevd_0);
case -1473811380: return bem_defined_1(bevd_0);
case 1988597288: return bem_emitLangSetDirect_1(bevd_0);
case -413588868: return bem_framesSetDirect_1(bevd_0);
case -786679146: return bem_vvSet_1(bevd_0);
case -17441095: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1175812062: return bem_klassNameSetDirect_1(bevd_0);
case 1070735389: return bem_undef_1(bevd_0);
case 1741909493: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 2017705831: return bem_def_1(bevd_0);
case 987555878: return bem_sameType_1(bevd_0);
case -805702504: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -15814459: return bem_framesSet_1(bevd_0);
case -885473602: return bem_translatedSetDirect_1(bevd_0);
case -1356493689: return bem_fileNameSet_1(bevd_0);
case 1204456657: return bem_langSet_1(bevd_0);
case 1524591721: return bem_sameClass_1(bevd_0);
case 1959069618: return bem_new_1(bevd_0);
case -1581273032: return bem_otherType_1(bevd_0);
case -667409412: return bem_vvSetDirect_1(bevd_0);
case 247807492: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1031512776: return bem_fileNameSetDirect_1(bevd_0);
case 551028761: return bem_lineNumberSetDirect_1(bevd_0);
case -1031049575: return bem_copyTo_1(bevd_0);
case -1723181188: return bem_descriptionSetDirect_1(bevd_0);
case -264806622: return bem_undefined_1(bevd_0);
case -1684536662: return bem_framesTextSet_1(bevd_0);
case 1617129647: return bem_sameObject_1(bevd_0);
case -788131506: return bem_descriptionSet_1(bevd_0);
case 233690225: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 64576699: return bem_methodNameSet_1(bevd_0);
case 1068272152: return bem_klassNameSet_1(bevd_0);
case 498921169: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1049219900: return bem_lineNumberSet_1(bevd_0);
case 1920500467: return bem_langSetDirect_1(bevd_0);
case 1960686692: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1628937971: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -727572211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 391353131: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -881140199: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 923430668: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 838418125: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -779217973: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -229754857: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemCallOnNull();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
}
