namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller : BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
static BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_12_JsonUnmarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bece_BEC_2_4_12_JsonUnmarshaller_bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static new BEC_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;

public static new BET_2_4_12_JsonUnmarshaller bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;

public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_parser = (BEC_2_4_6_JsonParser) (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (BEC_2_9_4_ContainerPair) (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (BEC_2_9_5_ContainerStack) (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) {
bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_first == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevp_first = beva_o;
} /* Line: 485 */
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_2_tmpany_phold = bevl_top.bemd_1(1865504944, bevp_pair);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_4_tmpany_phold = bevl_top.bemd_0(-1170503369);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 490 */ {
bevt_5_tmpany_phold = bevl_top.bemd_0(372321487);
bevt_6_tmpany_phold = bevl_top.bemd_0(-1170503369);
bevt_5_tmpany_phold.bemd_2(312899493, bevt_6_tmpany_phold, beva_o);
bevl_top.bemd_1(-228958196, null);
} /* Line: 492 */
 else  /* Line: 493 */ {
bevl_top.bemd_1(-228958196, beva_o);
} /* Line: 494 */
} /* Line: 490 */
 else  /* Line: 489 */ {
bevt_7_tmpany_phold = bevl_top.bemd_1(1865504944, bevp_list);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevl_top.bemd_1(-1272586012, beva_o);
} /* Line: 497 */
 else  /* Line: 498 */ {
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_4_12_JsonUnmarshaller_bels_0));
bevt_8_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 499 */
} /* Line: 489 */
} /* Line: 489 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_tmpany_phold = null;
bevl_m = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bem_addIn_1(bevl_m);
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerPair) (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_endMap_0() {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 513 */ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 514 */
 else  /* Line: 515 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_4_12_JsonUnmarshaller_bels_1));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 516 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_stack.bem_peek_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(1865504944, bevp_pair);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(900791764);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_6_tmpany_phold = bevp_stack.bem_peek_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1170503369);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 522 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 522 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 522 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_4_12_JsonUnmarshaller_bels_2));
bevt_7_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 523 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_beginList_0() {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_endList_0() {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 536 */ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 537 */
 else  /* Line: 538 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_4_12_JsonUnmarshaller_bels_3));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 539 */
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) {
bem_addIn_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() {
bem_addIn_1(null);
return this;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) {
bem_addIn_1(beva_int);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parserGet_0() {
return bevp_parser;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGetDirect_0() {
return bevp_parser;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGetDirect_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_pairGet_0() {
return bevp_pair;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGetDirect_0() {
return bevp_pair;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mapGet_0() {
return bevp_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGetDirect_0() {
return bevp_map;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
return bevp_first;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGetDirect_0() {
return bevp_first;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_stackGet_0() {
return bevp_stack;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGetDirect_0() {
return bevp_stack;
} /*method end*/
public virtual BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {467, 468, 469, 470, 472, 473, 478, 479, 480, 484, 484, 485, 487, 488, 488, 489, 490, 490, 490, 491, 491, 491, 492, 494, 496, 497, 499, 499, 499, 506, 507, 508, 508, 513, 514, 516, 516, 516, 522, 522, 522, 0, 522, 522, 522, 522, 0, 0, 523, 523, 523, 529, 530, 531, 536, 537, 539, 539, 539, 546, 551, 551, 556, 556, 561, 566, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 26, 27, 28, 32, 33, 34, 48, 53, 54, 56, 57, 62, 63, 65, 66, 71, 72, 73, 74, 75, 78, 82, 84, 87, 88, 89, 98, 99, 100, 101, 109, 111, 114, 115, 116, 130, 131, 132, 134, 137, 138, 139, 144, 145, 148, 152, 153, 154, 160, 161, 162, 170, 172, 175, 176, 177, 182, 187, 188, 193, 194, 198, 202, 206, 209, 212, 216, 220, 223, 226, 230, 234, 237, 240, 244, 248, 251, 254, 258, 262, 265, 268, 272, 276, 279, 282, 286};
/* BEGIN LINEINFO 
assign 1 467 23
new 0 467 23
assign 1 468 24
new 0 468 24
assign 1 469 25
new 0 469 25
assign 1 470 26
new 0 470 26
assign 1 472 27
assign 1 473 28
new 0 473 28
new 0 478 32
parse 2 479 33
return 1 480 34
assign 1 484 48
undef 1 484 53
assign 1 485 54
assign 1 487 56
peek 0 487 56
assign 1 488 57
def 1 488 62
assign 1 489 63
sameClass 1 489 63
assign 1 490 65
secondGet 0 490 65
assign 1 490 66
def 1 490 71
assign 1 491 72
firstGet 0 491 72
assign 1 491 73
secondGet 0 491 73
put 2 491 74
secondSet 1 492 75
secondSet 1 494 78
assign 1 496 82
sameClass 1 496 82
addValueWhole 1 497 84
assign 1 499 87
new 0 499 87
assign 1 499 88
new 1 499 88
throw 1 499 89
assign 1 506 98
new 0 506 98
addIn 1 507 99
assign 1 508 100
new 2 508 100
push 1 508 101
assign 1 513 109
isEmptyGet 0 513 109
assign 1 514 111
pop 0 514 111
assign 1 516 114
new 0 516 114
assign 1 516 115
new 1 516 115
throw 1 516 116
assign 1 522 130
peek 0 522 130
assign 1 522 131
sameClass 1 522 131
assign 1 522 132
not 0 522 132
assign 1 0 134
assign 1 522 137
peek 0 522 137
assign 1 522 138
secondGet 0 522 138
assign 1 522 139
undef 1 522 144
assign 1 0 145
assign 1 0 148
assign 1 523 152
new 0 523 152
assign 1 523 153
new 1 523 153
throw 1 523 154
assign 1 529 160
new 0 529 160
addIn 1 530 161
push 1 531 162
assign 1 536 170
isEmptyGet 0 536 170
assign 1 537 172
pop 0 537 172
assign 1 539 175
new 0 539 175
assign 1 539 176
new 1 539 176
throw 1 539 177
addIn 1 546 182
assign 1 551 187
new 0 551 187
addIn 1 551 188
assign 1 556 193
new 0 556 193
addIn 1 556 194
addIn 1 561 198
addIn 1 566 202
return 1 0 206
return 1 0 209
assign 1 0 212
assign 1 0 216
return 1 0 220
return 1 0 223
assign 1 0 226
assign 1 0 230
return 1 0 234
return 1 0 237
assign 1 0 240
assign 1 0 244
return 1 0 248
return 1 0 251
assign 1 0 254
assign 1 0 258
return 1 0 262
return 1 0 265
assign 1 0 268
assign 1 0 272
return 1 0 276
return 1 0 279
assign 1 0 282
assign 1 0 286
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -418691942: return bem_listGet_0();
case 1052713401: return bem_parserGet_0();
case -1644248106: return bem_handleTrue_0();
case -139353918: return bem_toAny_0();
case -2058654018: return bem_toString_0();
case -1943120126: return bem_serializeToString_0();
case -228119093: return bem_mapGet_0();
case 1990625095: return bem_tagGet_0();
case -1515260031: return bem_pairGet_0();
case 1310168666: return bem_copy_0();
case -320545548: return bem_sourceFileNameGet_0();
case -1461486060: return bem_beginList_0();
case -1456235115: return bem_echo_0();
case 1147856721: return bem_fieldIteratorGet_0();
case -408128705: return bem_endMap_0();
case -1908255152: return bem_endList_0();
case 341148236: return bem_once_0();
case -256176855: return bem_iteratorGet_0();
case -1957026970: return bem_stackGet_0();
case 148319359: return bem_new_0();
case -883816415: return bem_beginMap_0();
case 2121617532: return bem_hashGet_0();
case -1134862538: return bem_pairGetDirect_0();
case -387740661: return bem_kvMid_0();
case -740937572: return bem_print_0();
case -1671058912: return bem_handleNull_0();
case -1797964019: return bem_classNameGet_0();
case 1339355944: return bem_stackGetDirect_0();
case 1656998106: return bem_listGetDirect_0();
case 332613786: return bem_serializeContents_0();
case 2140271053: return bem_mapGetDirect_0();
case 734060929: return bem_serializationIteratorGet_0();
case -41276197: return bem_create_0();
case 1258133877: return bem_parserGetDirect_0();
case 372321487: return bem_firstGet_0();
case -865211167: return bem_many_0();
case 903178719: return bem_fieldNamesGet_0();
case -2027679173: return bem_deserializeClassNameGet_0();
case -2001594089: return bem_firstGetDirect_0();
case -492136394: return bem_handleFalse_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1459223224: return bem_firstSet_1(bevd_0);
case 1350346500: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 82092287: return bem_addIn_1(bevd_0);
case -1477715687: return bem_parserSetDirect_1(bevd_0);
case -116587458: return bem_sameType_1(bevd_0);
case -1829045189: return bem_otherClass_1(bevd_0);
case -2023862139: return bem_equals_1(bevd_0);
case -1580667702: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 55946271: return bem_notEquals_1(bevd_0);
case 1985783592: return bem_otherType_1(bevd_0);
case -456666001: return bem_parserSet_1(bevd_0);
case -245605778: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 825055568: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 297846495: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case 649776492: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1360048007: return bem_mapSet_1(bevd_0);
case 1424763816: return bem_firstSetDirect_1(bevd_0);
case -288650023: return bem_pairSetDirect_1(bevd_0);
case 1689942820: return bem_mapSetDirect_1(bevd_0);
case -1458784174: return bem_pairSet_1(bevd_0);
case 376359026: return bem_listSet_1(bevd_0);
case -1275596503: return bem_stackSetDirect_1(bevd_0);
case 525362407: return bem_listSetDirect_1(bevd_0);
case 306277101: return bem_undefined_1(bevd_0);
case -264091635: return bem_copyTo_1(bevd_0);
case 787635506: return bem_stackSet_1(bevd_0);
case 808198388: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 906711890: return bem_sameObject_1(bevd_0);
case -1679251333: return bem_undef_1(bevd_0);
case 1865504944: return bem_sameClass_1(bevd_0);
case 2070971991: return bem_def_1(bevd_0);
case 635105057: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 710095661: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1286703705: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 704289821: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1372536257: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1105189015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1798728092: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -275173380: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_JsonUnmarshaller_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_12_JsonUnmarshaller_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_JsonUnmarshaller();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst = (BEC_2_4_12_JsonUnmarshaller) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_12_JsonUnmarshaller.bece_BEC_2_4_12_JsonUnmarshaller_bevs_type;
}
}
}
