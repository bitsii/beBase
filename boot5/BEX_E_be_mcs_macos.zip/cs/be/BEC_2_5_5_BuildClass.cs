namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_5_BuildClass : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
static BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
public static new BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static new BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevp_methods = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLocal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isNotNull = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isList = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_belsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_ta_ph);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_ta_ph);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_emits == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 137*/ {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 138*/
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_2));
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
if (bevp_extends == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_3));
bevt_5_ta_ph = bevl_ret.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
} /* Line: 148*/
} /* Line: 147*/
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() {
return bevp_extends;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGetDirect_0() {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGetDirect_0() {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGetDirect_0() {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGetDirect_0() {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() {
return bevp_used;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGetDirect_0() {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGetDirect_0() {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGetDirect_0() {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGetDirect_0() {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() {
return bevp_isList;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGetDirect_0() {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGetDirect_0() {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGetDirect_0() {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGetDirect_0() {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() {
return bevp_belsCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGetDirect_0() {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 123, 124, 124, 125, 127, 128, 128, 129, 133, 137, 137, 138, 140, 144, 145, 145, 146, 146, 146, 146, 147, 147, 148, 148, 148, 148, 151, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 70, 75, 80, 81, 83, 96, 97, 102, 103, 104, 105, 106, 107, 112, 113, 114, 115, 116, 119, 122, 125, 128, 132, 136, 139, 142, 146, 150, 153, 156, 160, 164, 167, 170, 174, 178, 181, 184, 188, 192, 195, 198, 202, 206, 209, 212, 216, 220, 223, 226, 230, 234, 237, 240, 244, 248, 251, 254, 258, 262, 265, 268, 272, 276, 279, 282, 286, 290, 293, 296, 300, 304, 307, 310, 314, 318, 321, 324, 328, 332, 335, 338, 342, 346, 349, 352, 356, 360, 363, 366, 370, 374, 377, 380, 384, 388, 391, 394, 398, 402, 405, 408, 412, 416, 419, 422, 426, 430, 433, 436, 440};
/* BEGIN LINEINFO 
assign 1 103 43
new 0 103 43
assign 1 104 44
new 0 104 44
assign 1 105 45
new 0 105 45
assign 1 106 46
new 0 106 46
assign 1 107 47
new 0 107 47
assign 1 108 48
new 0 108 48
assign 1 109 49
new 0 109 49
assign 1 110 50
new 0 110 50
assign 1 111 51
new 0 111 51
assign 1 112 52
new 0 112 52
assign 1 113 53
new 0 113 53
assign 1 114 54
new 0 114 54
assign 1 115 55
new 0 115 55
assign 1 116 56
new 0 116 56
assign 1 117 57
new 0 117 57
assign 1 118 58
new 0 118 58
assign 1 123 59
new 0 123 59
assign 1 124 60
new 0 124 60
fromString 1 124 61
addUsed 1 125 62
assign 1 127 63
new 0 127 63
assign 1 128 64
new 0 128 64
fromString 1 128 65
addUsed 1 129 66
addValue 1 133 70
assign 1 137 75
undef 1 137 80
assign 1 138 81
new 0 138 81
addValue 1 140 83
assign 1 144 96
classNameGet 0 144 96
assign 1 145 97
def 1 145 102
assign 1 146 103
new 0 146 103
assign 1 146 104
add 1 146 104
assign 1 146 105
toString 0 146 105
assign 1 146 106
add 1 146 106
assign 1 147 107
def 1 147 112
assign 1 148 113
new 0 148 113
assign 1 148 114
add 1 148 114
assign 1 148 115
toString 0 148 115
assign 1 148 116
add 1 148 116
return 1 151 119
return 1 0 122
return 1 0 125
assign 1 0 128
assign 1 0 132
return 1 0 136
return 1 0 139
assign 1 0 142
assign 1 0 146
return 1 0 150
return 1 0 153
assign 1 0 156
assign 1 0 160
return 1 0 164
return 1 0 167
assign 1 0 170
assign 1 0 174
return 1 0 178
return 1 0 181
assign 1 0 184
assign 1 0 188
return 1 0 192
return 1 0 195
assign 1 0 198
assign 1 0 202
return 1 0 206
return 1 0 209
assign 1 0 212
assign 1 0 216
return 1 0 220
return 1 0 223
assign 1 0 226
assign 1 0 230
return 1 0 234
return 1 0 237
assign 1 0 240
assign 1 0 244
return 1 0 248
return 1 0 251
assign 1 0 254
assign 1 0 258
return 1 0 262
return 1 0 265
assign 1 0 268
assign 1 0 272
return 1 0 276
return 1 0 279
assign 1 0 282
assign 1 0 286
return 1 0 290
return 1 0 293
assign 1 0 296
assign 1 0 300
return 1 0 304
return 1 0 307
assign 1 0 310
assign 1 0 314
return 1 0 318
return 1 0 321
assign 1 0 324
assign 1 0 328
return 1 0 332
return 1 0 335
assign 1 0 338
assign 1 0 342
return 1 0 346
return 1 0 349
assign 1 0 352
assign 1 0 356
return 1 0 360
return 1 0 363
assign 1 0 366
assign 1 0 370
return 1 0 374
return 1 0 377
assign 1 0 380
assign 1 0 384
return 1 0 388
return 1 0 391
assign 1 0 394
assign 1 0 398
return 1 0 402
return 1 0 405
assign 1 0 408
assign 1 0 412
return 1 0 416
return 1 0 419
assign 1 0 422
assign 1 0 426
return 1 0 430
return 1 0 433
assign 1 0 436
assign 1 0 440
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1906768398: return bem_classNameGet_0();
case -1445273167: return bem_namepathGetDirect_0();
case 1730426232: return bem_usedGet_0();
case -1036391864: return bem_copy_0();
case 1640157629: return bem_toString_0();
case 1444826768: return bem_orderedVarsGet_0();
case 1460710096: return bem_tagGet_0();
case 1778806910: return bem_fromFileGetDirect_0();
case 1092637488: return bem_nativeSlotsGet_0();
case -1538031889: return bem_libNameGetDirect_0();
case 1562650783: return bem_fieldIteratorGet_0();
case 99255499: return bem_isFinalGetDirect_0();
case -1251683014: return bem_emitsGetDirect_0();
case 938661719: return bem_fromFileGet_0();
case 307193318: return bem_serializeContents_0();
case 993405018: return bem_isLocalGet_0();
case -729649677: return bem_isListGet_0();
case 327704603: return bem_orderedMethodsGet_0();
case -1432171810: return bem_nameGet_0();
case -1608519010: return bem_anyMapGet_0();
case -709713572: return bem_isFinalGet_0();
case -178385347: return bem_iteratorGet_0();
case 1906801093: return bem_isNotNullGetDirect_0();
case -1729645430: return bem_anyMapGetDirect_0();
case -433449325: return bem_belsCountGetDirect_0();
case -2122670641: return bem_usedGetDirect_0();
case -1494250482: return bem_freeFirstSlotGetDirect_0();
case 2029153076: return bem_orderedMethodsGetDirect_0();
case 2015407809: return bem_onceEvalCountGet_0();
case 1427502984: return bem_referencedPropertiesGetDirect_0();
case 939713627: return bem_print_0();
case 978367668: return bem_shouldWriteGet_0();
case -1253293660: return bem_serializeToString_0();
case 898575293: return bem_nativeSlotsGetDirect_0();
case -2070846101: return bem_hashGet_0();
case 662769826: return bem_methodsGet_0();
case 181578174: return bem_belsCountGet_0();
case 314670399: return bem_extendsGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case -885565369: return bem_firstSlotNativeGetDirect_0();
case -1540868113: return bem_namepathGet_0();
case 8951651: return bem_methodsGetDirect_0();
case 31572024: return bem_isLocalGetDirect_0();
case -88066791: return bem_isListGetDirect_0();
case 1258729534: return bem_echo_0();
case 1975378871: return bem_orderedVarsGetDirect_0();
case -366823845: return bem_onceEvalCountGetDirect_0();
case 1506889517: return bem_isNotNullGet_0();
case -231490902: return bem_referencedPropertiesGet_0();
case -188052393: return bem_extendsGetDirect_0();
case -1214013759: return bem_firstSlotNativeGet_0();
case 1287356270: return bem_freeFirstSlotGet_0();
case 560600297: return bem_synGetDirect_0();
case -322487712: return bem_synGet_0();
case 1464392478: return bem_shouldWriteGetDirect_0();
case -1221104789: return bem_sourceFileNameGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case -1259517399: return bem_emitsGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 873076018: return bem_new_0();
case -1157472713: return bem_libNameGet_0();
case 2037996040: return bem_create_0();
case -527531531: return bem_nameGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1757058182: return bem_methodsSet_1(bevd_0);
case 1810487790: return bem_usedSet_1(bevd_0);
case 797382162: return bem_firstSlotNativeSetDirect_1(bevd_0);
case 1178499383: return bem_referencedPropertiesSetDirect_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 1287644608: return bem_emitsSet_1(bevd_0);
case 357327570: return bem_isLocalSetDirect_1(bevd_0);
case 814409401: return bem_isListSet_1(bevd_0);
case -360055925: return bem_emitsSetDirect_1(bevd_0);
case 991562918: return bem_orderedVarsSet_1(bevd_0);
case 1991188562: return bem_onceEvalCountSet_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -794778842: return bem_belsCountSetDirect_1(bevd_0);
case 1485244902: return bem_orderedMethodsSetDirect_1(bevd_0);
case -414678688: return bem_synSetDirect_1(bevd_0);
case 463143475: return bem_namepathSet_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case -502764541: return bem_extendsSetDirect_1(bevd_0);
case -1842819776: return bem_libNameSet_1(bevd_0);
case 1139379171: return bem_onceEvalCountSetDirect_1(bevd_0);
case 1918603672: return bem_namepathSetDirect_1(bevd_0);
case 1196289458: return bem_freeFirstSlotSet_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1693424644: return bem_fromFileSet_1(bevd_0);
case 9740524: return bem_extendsSet_1(bevd_0);
case -1241178007: return bem_isNotNullSet_1(bevd_0);
case 1574512337: return bem_anyMapSetDirect_1(bevd_0);
case -463891624: return bem_isLocalSet_1(bevd_0);
case -1142753093: return bem_libNameSetDirect_1(bevd_0);
case -1080231322: return bem_isListSetDirect_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 67465497: return bem_nameSetDirect_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case -791379592: return bem_addEmit_1(bevd_0);
case 582707263: return bem_usedSetDirect_1(bevd_0);
case 1363126078: return bem_fromFileSetDirect_1(bevd_0);
case 730381469: return bem_orderedVarsSetDirect_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1232791091: return bem_nameSet_1(bevd_0);
case 513813209: return bem_shouldWriteSetDirect_1(bevd_0);
case 1907425369: return bem_firstSlotNativeSet_1(bevd_0);
case -1667281034: return bem_isFinalSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -1227682327: return bem_isFinalSet_1(bevd_0);
case 1514571233: return bem_isNotNullSetDirect_1(bevd_0);
case 246084698: return bem_nativeSlotsSet_1(bevd_0);
case -1869877106: return bem_synSet_1(bevd_0);
case 1364566591: return bem_shouldWriteSet_1(bevd_0);
case -1080341798: return bem_anyMapSet_1(bevd_0);
case -1866401110: return bem_referencedPropertiesSet_1(bevd_0);
case -1083331384: return bem_orderedMethodsSet_1(bevd_0);
case 424646938: return bem_freeFirstSlotSetDirect_1(bevd_0);
case -70002848: return bem_nativeSlotsSetDirect_1(bevd_0);
case -807975863: return bem_addUsed_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case 902177872: return bem_belsCountSet_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case 255533381: return bem_methodsSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildClass();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
}
