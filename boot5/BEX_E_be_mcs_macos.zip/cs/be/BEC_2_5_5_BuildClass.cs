namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_5_BuildClass : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
static BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_2, 11));
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildClass_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildClass_bels_3, 10));
public static new BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static new BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevp_methods = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLocal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isNotNull = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isList = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_belsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_tmpany_phold);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_tmpany_phold);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_emits == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 139 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 146 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_0;
bevt_1_tmpany_phold = bevl_ret.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
if (bevp_extends == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_5_BuildClass_bevo_1;
bevt_5_tmpany_phold = bevl_ret.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
} /* Line: 149 */
} /* Line: 148 */
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() {
return bevp_extends;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGetDirect_0() {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGetDirect_0() {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGetDirect_0() {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGetDirect_0() {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() {
return bevp_used;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGetDirect_0() {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGetDirect_0() {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGetDirect_0() {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGetDirect_0() {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() {
return bevp_isList;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGetDirect_0() {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGetDirect_0() {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGetDirect_0() {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGetDirect_0() {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() {
return bevp_belsCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGetDirect_0() {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 124, 125, 125, 126, 128, 129, 129, 130, 134, 138, 138, 139, 141, 145, 146, 146, 147, 147, 147, 147, 148, 148, 149, 149, 149, 149, 152, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 72, 77, 82, 83, 85, 98, 99, 104, 105, 106, 107, 108, 109, 114, 115, 116, 117, 118, 121, 124, 127, 130, 134, 138, 141, 144, 148, 152, 155, 158, 162, 166, 169, 172, 176, 180, 183, 186, 190, 194, 197, 200, 204, 208, 211, 214, 218, 222, 225, 228, 232, 236, 239, 242, 246, 250, 253, 256, 260, 264, 267, 270, 274, 278, 281, 284, 288, 292, 295, 298, 302, 306, 309, 312, 316, 320, 323, 326, 330, 334, 337, 340, 344, 348, 351, 354, 358, 362, 365, 368, 372, 376, 379, 382, 386, 390, 393, 396, 400, 404, 407, 410, 414, 418, 421, 424, 428, 432, 435, 438, 442};
/* BEGIN LINEINFO 
assign 1 104 45
new 0 104 45
assign 1 105 46
new 0 105 46
assign 1 106 47
new 0 106 47
assign 1 107 48
new 0 107 48
assign 1 108 49
new 0 108 49
assign 1 109 50
new 0 109 50
assign 1 110 51
new 0 110 51
assign 1 111 52
new 0 111 52
assign 1 112 53
new 0 112 53
assign 1 113 54
new 0 113 54
assign 1 114 55
new 0 114 55
assign 1 115 56
new 0 115 56
assign 1 116 57
new 0 116 57
assign 1 117 58
new 0 117 58
assign 1 118 59
new 0 118 59
assign 1 119 60
new 0 119 60
assign 1 124 61
new 0 124 61
assign 1 125 62
new 0 125 62
fromString 1 125 63
addUsed 1 126 64
assign 1 128 65
new 0 128 65
assign 1 129 66
new 0 129 66
fromString 1 129 67
addUsed 1 130 68
addValue 1 134 72
assign 1 138 77
undef 1 138 82
assign 1 139 83
new 0 139 83
addValue 1 141 85
assign 1 145 98
classNameGet 0 145 98
assign 1 146 99
def 1 146 104
assign 1 147 105
new 0 147 105
assign 1 147 106
add 1 147 106
assign 1 147 107
toString 0 147 107
assign 1 147 108
add 1 147 108
assign 1 148 109
def 1 148 114
assign 1 149 115
new 0 149 115
assign 1 149 116
add 1 149 116
assign 1 149 117
toString 0 149 117
assign 1 149 118
add 1 149 118
return 1 152 121
return 1 0 124
return 1 0 127
assign 1 0 130
assign 1 0 134
return 1 0 138
return 1 0 141
assign 1 0 144
assign 1 0 148
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
return 1 0 194
return 1 0 197
assign 1 0 200
assign 1 0 204
return 1 0 208
return 1 0 211
assign 1 0 214
assign 1 0 218
return 1 0 222
return 1 0 225
assign 1 0 228
assign 1 0 232
return 1 0 236
return 1 0 239
assign 1 0 242
assign 1 0 246
return 1 0 250
return 1 0 253
assign 1 0 256
assign 1 0 260
return 1 0 264
return 1 0 267
assign 1 0 270
assign 1 0 274
return 1 0 278
return 1 0 281
assign 1 0 284
assign 1 0 288
return 1 0 292
return 1 0 295
assign 1 0 298
assign 1 0 302
return 1 0 306
return 1 0 309
assign 1 0 312
assign 1 0 316
return 1 0 320
return 1 0 323
assign 1 0 326
assign 1 0 330
return 1 0 334
return 1 0 337
assign 1 0 340
assign 1 0 344
return 1 0 348
return 1 0 351
assign 1 0 354
assign 1 0 358
return 1 0 362
return 1 0 365
assign 1 0 368
assign 1 0 372
return 1 0 376
return 1 0 379
assign 1 0 382
assign 1 0 386
return 1 0 390
return 1 0 393
assign 1 0 396
assign 1 0 400
return 1 0 404
return 1 0 407
assign 1 0 410
assign 1 0 414
return 1 0 418
return 1 0 421
assign 1 0 424
assign 1 0 428
return 1 0 432
return 1 0 435
assign 1 0 438
assign 1 0 442
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 457529483: return bem_serializeContents_0();
case 1623857679: return bem_fromFileGet_0();
case -457703447: return bem_deserializeClassNameGet_0();
case -292945961: return bem_create_0();
case 1705775657: return bem_freeFirstSlotGet_0();
case 1792980139: return bem_shouldWriteGetDirect_0();
case -711514807: return bem_sourceFileNameGet_0();
case 1094851260: return bem_libNameGetDirect_0();
case 615981380: return bem_fieldNamesGet_0();
case -213411150: return bem_extendsGetDirect_0();
case 55842129: return bem_nameGetDirect_0();
case -1922780248: return bem_iteratorGet_0();
case 460117727: return bem_usedGetDirect_0();
case -1261904738: return bem_orderedMethodsGet_0();
case 173878376: return bem_firstSlotNativeGet_0();
case 678840299: return bem_emitsGetDirect_0();
case 1655276270: return bem_isListGet_0();
case -2091478387: return bem_synGetDirect_0();
case 1440687481: return bem_libNameGet_0();
case 87072509: return bem_toAny_0();
case -952410751: return bem_namepathGetDirect_0();
case 566545286: return bem_extendsGet_0();
case 1377184268: return bem_referencedPropertiesGetDirect_0();
case 658678414: return bem_new_0();
case 366604178: return bem_methodsGetDirect_0();
case -714858011: return bem_belsCountGetDirect_0();
case -1280718876: return bem_nameGet_0();
case 945522219: return bem_hashGet_0();
case 1230578475: return bem_methodsGet_0();
case -1028722738: return bem_synGet_0();
case -1780673079: return bem_namepathGet_0();
case -1370312638: return bem_isFinalGet_0();
case -274680383: return bem_usedGet_0();
case -1976427092: return bem_fromFileGetDirect_0();
case 1922799574: return bem_emitsGet_0();
case -1030237664: return bem_shouldWriteGet_0();
case 624386533: return bem_serializeToString_0();
case -969337960: return bem_anyMapGet_0();
case -1725699695: return bem_fieldIteratorGet_0();
case 1388714354: return bem_onceEvalCountGetDirect_0();
case -1994887926: return bem_onceEvalCountGet_0();
case 1855506680: return bem_toString_0();
case -2014357505: return bem_orderedVarsGet_0();
case -84103940: return bem_many_0();
case 1284640786: return bem_copy_0();
case 1878894995: return bem_classNameGet_0();
case -1354126741: return bem_tagGet_0();
case 1170010265: return bem_belsCountGet_0();
case -1288455455: return bem_freeFirstSlotGetDirect_0();
case 1095611429: return bem_once_0();
case 1643408175: return bem_isNotNullGetDirect_0();
case 2134619061: return bem_anyMapGetDirect_0();
case 1656156599: return bem_firstSlotNativeGetDirect_0();
case -1828799546: return bem_orderedMethodsGetDirect_0();
case -1267287483: return bem_referencedPropertiesGet_0();
case -1213741382: return bem_isLocalGet_0();
case -1138581063: return bem_isListGetDirect_0();
case 1835544527: return bem_print_0();
case -571164244: return bem_isNotNullGet_0();
case 1962974167: return bem_nativeSlotsGet_0();
case 705946713: return bem_serializationIteratorGet_0();
case -246566366: return bem_isLocalGetDirect_0();
case 603827296: return bem_isFinalGetDirect_0();
case 2087771877: return bem_echo_0();
case -974843879: return bem_nativeSlotsGetDirect_0();
case -601926142: return bem_orderedVarsGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 21274005: return bem_orderedVarsSet_1(bevd_0);
case -1064214375: return bem_onceEvalCountSet_1(bevd_0);
case -656840793: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -701846850: return bem_otherType_1(bevd_0);
case 1831091397: return bem_nameSetDirect_1(bevd_0);
case -614382368: return bem_orderedVarsSetDirect_1(bevd_0);
case -109988470: return bem_usedSetDirect_1(bevd_0);
case -993087763: return bem_referencedPropertiesSet_1(bevd_0);
case -597509561: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1536327958: return bem_isNotNullSet_1(bevd_0);
case 69791278: return bem_libNameSetDirect_1(bevd_0);
case -1359550071: return bem_fromFileSet_1(bevd_0);
case -2087045820: return bem_orderedMethodsSetDirect_1(bevd_0);
case -1971460437: return bem_otherClass_1(bevd_0);
case -586455400: return bem_defined_1(bevd_0);
case 2046383829: return bem_isListSet_1(bevd_0);
case -1470453303: return bem_belsCountSet_1(bevd_0);
case 350009649: return bem_addUsed_1(bevd_0);
case -1246468421: return bem_synSet_1(bevd_0);
case 126395237: return bem_sameObject_1(bevd_0);
case -1018021281: return bem_extendsSetDirect_1(bevd_0);
case -1030641994: return bem_isFinalSetDirect_1(bevd_0);
case 103652206: return bem_emitsSetDirect_1(bevd_0);
case -1897607279: return bem_equals_1(bevd_0);
case -18883527: return bem_nativeSlotsSetDirect_1(bevd_0);
case 1894284601: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -97743331: return bem_isNotNullSetDirect_1(bevd_0);
case -1368724020: return bem_sameType_1(bevd_0);
case -754260669: return bem_def_1(bevd_0);
case 568669560: return bem_anyMapSet_1(bevd_0);
case 689460542: return bem_synSetDirect_1(bevd_0);
case -303057571: return bem_extendsSet_1(bevd_0);
case -1971090959: return bem_anyMapSetDirect_1(bevd_0);
case 696668731: return bem_firstSlotNativeSetDirect_1(bevd_0);
case 538103812: return bem_shouldWriteSetDirect_1(bevd_0);
case 722424997: return bem_nativeSlotsSet_1(bevd_0);
case -195954973: return bem_nameSet_1(bevd_0);
case 302884708: return bem_isFinalSet_1(bevd_0);
case -1492965942: return bem_fromFileSetDirect_1(bevd_0);
case -2109400999: return bem_copyTo_1(bevd_0);
case -1383533410: return bem_undef_1(bevd_0);
case -770705921: return bem_referencedPropertiesSetDirect_1(bevd_0);
case 185103794: return bem_usedSet_1(bevd_0);
case 58606191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1537452480: return bem_addEmit_1(bevd_0);
case -1457810647: return bem_namepathSet_1(bevd_0);
case 934765991: return bem_libNameSet_1(bevd_0);
case 1417672878: return bem_onceEvalCountSetDirect_1(bevd_0);
case -790570338: return bem_freeFirstSlotSetDirect_1(bevd_0);
case 1353756696: return bem_methodsSet_1(bevd_0);
case 1362826155: return bem_isListSetDirect_1(bevd_0);
case 701289319: return bem_methodsSetDirect_1(bevd_0);
case 320223191: return bem_shouldWriteSet_1(bevd_0);
case -529890686: return bem_orderedMethodsSet_1(bevd_0);
case 2066426218: return bem_namepathSetDirect_1(bevd_0);
case -341234740: return bem_notEquals_1(bevd_0);
case 465199415: return bem_sameClass_1(bevd_0);
case -1887885797: return bem_freeFirstSlotSet_1(bevd_0);
case -1165111606: return bem_firstSlotNativeSet_1(bevd_0);
case 1372592790: return bem_belsCountSetDirect_1(bevd_0);
case -516112068: return bem_emitsSet_1(bevd_0);
case 1150742403: return bem_isLocalSet_1(bevd_0);
case -255579070: return bem_isLocalSetDirect_1(bevd_0);
case -1551748546: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1810583739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -687329733: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 703022748: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -871246707: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1013064550: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1390383369: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1845172722: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildClass();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
}
