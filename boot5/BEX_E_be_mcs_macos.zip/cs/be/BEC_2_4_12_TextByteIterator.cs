namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator : BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
static BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
public static new BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static new BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_emptyGet_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_containerGet_0() {
return bevp_str;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return bevp_str;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) {
bem_new_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) {
bevp_str = beva__str;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1396*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1397*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1407*/ {
bevt_3_ta_ph = beva_buf.bem_capacityGet_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1408*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_ta_ph);
} /* Line: 1409*/
bevt_7_ta_ph = beva_buf.bem_sizeGet_0();
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_7_ta_ph.bevi_int != bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1411*/ {
bevt_9_ta_ph = beva_buf.bem_sizeGet_0();
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_9_ta_ph.bevi_int = bevt_10_ta_ph.bevi_int;
} /* Line: 1412*/
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_12_ta_ph = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_11_ta_ph, bevt_12_ta_ph);
bevp_pos.bevi_int++;
} /* Line: 1418*/
return beva_buf;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1424*/ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1426*/
return beva_into;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1432*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1432*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1432*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1432*/
 else /* Line: 1432*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1432*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1435*/
return beva_into;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1441*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1441*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1441*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1441*/
 else /* Line: 1441*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1441*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1444*/
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGetDirect_0() {
return bevp_pos;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vcopyGet_0() {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGetDirect_0() {
return bevp_vcopy;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1372, 1372, 1372, 1376, 1380, 1384, 1389, 1390, 1391, 1396, 1396, 1396, 1397, 1397, 1399, 1399, 1403, 1403, 1403, 1403, 1407, 1407, 1407, 1408, 1408, 1408, 1408, 1409, 1409, 1411, 1411, 1411, 1411, 1412, 1412, 1412, 1414, 1414, 1414, 1418, 1420, 1424, 1424, 1424, 1425, 1426, 1428, 1432, 1432, 1432, 1432, 1432, 1432, 0, 0, 0, 1433, 1434, 1435, 1437, 1441, 1441, 1441, 1441, 1441, 1441, 0, 0, 0, 1442, 1443, 1444, 1450, 1454, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 27, 30, 33, 37, 38, 39, 47, 48, 53, 54, 55, 57, 58, 64, 65, 66, 67, 85, 86, 91, 92, 93, 94, 99, 100, 101, 103, 104, 105, 110, 111, 112, 113, 115, 116, 117, 118, 120, 125, 126, 131, 132, 133, 135, 143, 144, 149, 150, 151, 156, 157, 160, 164, 167, 168, 169, 171, 179, 180, 185, 186, 187, 192, 193, 196, 200, 203, 204, 205, 210, 213, 216, 219, 222, 226, 230, 233, 236, 240, 244, 247, 250, 254};
/* BEGIN LINEINFO 
assign 1 1372 21
new 0 1372 21
assign 1 1372 22
emptyGet 0 1372 22
new 1 1372 23
return 1 1376 27
return 1 1380 30
new 1 1384 33
assign 1 1389 37
assign 1 1390 38
new 0 1390 38
assign 1 1391 39
new 0 1391 39
assign 1 1396 47
sizeGet 0 1396 47
assign 1 1396 48
greater 1 1396 53
assign 1 1397 54
new 0 1397 54
return 1 1397 55
assign 1 1399 57
new 0 1399 57
return 1 1399 58
assign 1 1403 64
new 0 1403 64
assign 1 1403 65
new 1 1403 65
assign 1 1403 66
next 1 1403 66
return 1 1403 67
assign 1 1407 85
sizeGet 0 1407 85
assign 1 1407 86
greater 1 1407 91
assign 1 1408 92
capacityGet 0 1408 92
assign 1 1408 93
new 0 1408 93
assign 1 1408 94
lesser 1 1408 99
assign 1 1409 100
new 0 1409 100
capacitySet 1 1409 101
assign 1 1411 103
sizeGet 0 1411 103
assign 1 1411 104
new 0 1411 104
assign 1 1411 105
notEquals 1 1411 110
assign 1 1412 111
sizeGet 0 1412 111
assign 1 1412 112
new 0 1412 112
setValue 1 1412 113
assign 1 1414 115
new 0 1414 115
assign 1 1414 116
getInt 2 1414 116
setIntUnchecked 2 1414 117
incrementValue 0 1418 118
return 1 1420 120
assign 1 1424 125
sizeGet 0 1424 125
assign 1 1424 126
greater 1 1424 131
getInt 2 1425 132
incrementValue 0 1426 133
return 1 1428 135
assign 1 1432 143
new 0 1432 143
assign 1 1432 144
greater 1 1432 149
assign 1 1432 150
sizeGet 0 1432 150
assign 1 1432 151
greaterEquals 1 1432 156
assign 1 0 157
assign 1 0 160
assign 1 0 164
decrementValue 0 1433 167
getInt 2 1434 168
incrementValue 0 1435 169
return 1 1437 171
assign 1 1441 179
new 0 1441 179
assign 1 1441 180
greater 1 1441 185
assign 1 1441 186
sizeGet 0 1441 186
assign 1 1441 187
greaterEquals 1 1441 192
assign 1 0 193
assign 1 0 196
assign 1 0 200
decrementValue 0 1442 203
setIntUnchecked 2 1443 204
incrementValue 0 1444 205
return 1 1450 210
return 1 1454 213
return 1 0 216
return 1 0 219
assign 1 0 222
assign 1 0 226
return 1 0 230
return 1 0 233
assign 1 0 236
assign 1 0 240
return 1 0 244
return 1 0 247
assign 1 0 250
assign 1 0 254
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1688687204: return bem_serializeToString_0();
case 2038193605: return bem_fieldNamesGet_0();
case 781122608: return bem_byteIteratorIteratorGet_0();
case 1029695809: return bem_echo_0();
case -479166709: return bem_tagGet_0();
case 681169612: return bem_vcopyGetDirect_0();
case 126670515: return bem_toAny_0();
case -1902089216: return bem_toString_0();
case -1844917728: return bem_many_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -894202533: return bem_nextGet_0();
case -948653934: return bem_strGet_0();
case 1562608535: return bem_print_0();
case -8643043: return bem_serializeContents_0();
case 1106918243: return bem_posGetDirect_0();
case 1514961045: return bem_posGet_0();
case -785258946: return bem_create_0();
case -31114048: return bem_iteratorGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 1822484156: return bem_vcopyGet_0();
case 304019159: return bem_containerGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 217968364: return bem_classNameGet_0();
case 1137009070: return bem_once_0();
case 1086967570: return bem_strGetDirect_0();
case -1026733174: return bem_new_0();
case -1725405782: return bem_sourceFileNameGet_0();
case -262847282: return bem_hasNextGet_0();
case -1848718184: return bem_hashGet_0();
case 185174991: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1081287538: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 1443498796: return bem_strSet_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1903992967: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 113148064: return bem_vcopySet_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case -1328834396: return bem_posSetDirect_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1992537839: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1468052728: return bem_posSet_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 389177729: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 967943666: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 572345712: return bem_strSetDirect_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case 1528024450: return bem_vcopySetDirect_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_TextByteIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
}
