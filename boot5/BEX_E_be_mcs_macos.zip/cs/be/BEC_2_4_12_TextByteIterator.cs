namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator : BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
static BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
public static new BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static new BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_emptyGet_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_containerGet_0() {
return bevp_str;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return bevp_str;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) {
bem_new_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) {
bevp_str = beva__str;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1362*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1372*/ {
bevt_3_ta_ph = beva_buf.bem_capacityGet_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1373*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_ta_ph);
} /* Line: 1374*/
bevt_7_ta_ph = beva_buf.bem_sizeGet_0();
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_7_ta_ph.bevi_int != bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1376*/ {
bevt_9_ta_ph = beva_buf.bem_sizeGet_0();
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_9_ta_ph.bevi_int = bevt_10_ta_ph.bevi_int;
} /* Line: 1377*/
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_12_ta_ph = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_11_ta_ph, bevt_12_ta_ph);
bevp_pos.bevi_int++;
} /* Line: 1383*/
return beva_buf;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1389*/ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1391*/
return beva_into;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1397*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1397*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1397*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1397*/
 else /* Line: 1397*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1397*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1400*/
return beva_into;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1406*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1406*/
 else /* Line: 1406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1406*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1409*/
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGetDirect_0() {
return bevp_pos;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vcopyGet_0() {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGetDirect_0() {
return bevp_vcopy;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1337, 1337, 1337, 1341, 1345, 1349, 1354, 1355, 1356, 1361, 1361, 1361, 1362, 1362, 1364, 1364, 1368, 1368, 1368, 1368, 1372, 1372, 1372, 1373, 1373, 1373, 1373, 1374, 1374, 1376, 1376, 1376, 1376, 1377, 1377, 1377, 1379, 1379, 1379, 1383, 1385, 1389, 1389, 1389, 1390, 1391, 1393, 1397, 1397, 1397, 1397, 1397, 1397, 0, 0, 0, 1398, 1399, 1400, 1402, 1406, 1406, 1406, 1406, 1406, 1406, 0, 0, 0, 1407, 1408, 1409, 1415, 1419, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 27, 30, 33, 37, 38, 39, 47, 48, 53, 54, 55, 57, 58, 64, 65, 66, 67, 85, 86, 91, 92, 93, 94, 99, 100, 101, 103, 104, 105, 110, 111, 112, 113, 115, 116, 117, 118, 120, 125, 126, 131, 132, 133, 135, 143, 144, 149, 150, 151, 156, 157, 160, 164, 167, 168, 169, 171, 179, 180, 185, 186, 187, 192, 193, 196, 200, 203, 204, 205, 210, 213, 216, 219, 222, 226, 230, 233, 236, 240, 244, 247, 250, 254};
/* BEGIN LINEINFO 
assign 1 1337 21
new 0 1337 21
assign 1 1337 22
emptyGet 0 1337 22
new 1 1337 23
return 1 1341 27
return 1 1345 30
new 1 1349 33
assign 1 1354 37
assign 1 1355 38
new 0 1355 38
assign 1 1356 39
new 0 1356 39
assign 1 1361 47
sizeGet 0 1361 47
assign 1 1361 48
greater 1 1361 53
assign 1 1362 54
new 0 1362 54
return 1 1362 55
assign 1 1364 57
new 0 1364 57
return 1 1364 58
assign 1 1368 64
new 0 1368 64
assign 1 1368 65
new 1 1368 65
assign 1 1368 66
next 1 1368 66
return 1 1368 67
assign 1 1372 85
sizeGet 0 1372 85
assign 1 1372 86
greater 1 1372 91
assign 1 1373 92
capacityGet 0 1373 92
assign 1 1373 93
new 0 1373 93
assign 1 1373 94
lesser 1 1373 99
assign 1 1374 100
new 0 1374 100
capacitySet 1 1374 101
assign 1 1376 103
sizeGet 0 1376 103
assign 1 1376 104
new 0 1376 104
assign 1 1376 105
notEquals 1 1376 110
assign 1 1377 111
sizeGet 0 1377 111
assign 1 1377 112
new 0 1377 112
setValue 1 1377 113
assign 1 1379 115
new 0 1379 115
assign 1 1379 116
getInt 2 1379 116
setIntUnchecked 2 1379 117
incrementValue 0 1383 118
return 1 1385 120
assign 1 1389 125
sizeGet 0 1389 125
assign 1 1389 126
greater 1 1389 131
getInt 2 1390 132
incrementValue 0 1391 133
return 1 1393 135
assign 1 1397 143
new 0 1397 143
assign 1 1397 144
greater 1 1397 149
assign 1 1397 150
sizeGet 0 1397 150
assign 1 1397 151
greaterEquals 1 1397 156
assign 1 0 157
assign 1 0 160
assign 1 0 164
decrementValue 0 1398 167
getInt 2 1399 168
incrementValue 0 1400 169
return 1 1402 171
assign 1 1406 179
new 0 1406 179
assign 1 1406 180
greater 1 1406 185
assign 1 1406 186
sizeGet 0 1406 186
assign 1 1406 187
greaterEquals 1 1406 192
assign 1 0 193
assign 1 0 196
assign 1 0 200
decrementValue 0 1407 203
setIntUnchecked 2 1408 204
incrementValue 0 1409 205
return 1 1415 210
return 1 1419 213
return 1 0 216
return 1 0 219
assign 1 0 222
assign 1 0 226
return 1 0 230
return 1 0 233
assign 1 0 236
assign 1 0 240
return 1 0 244
return 1 0 247
assign 1 0 250
assign 1 0 254
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2070846101: return bem_hashGet_0();
case -1036391864: return bem_copy_0();
case -2019183300: return bem_vcopyGet_0();
case 1640157629: return bem_toString_0();
case 73704721: return bem_containerGet_0();
case 354825588: return bem_vcopyGetDirect_0();
case -1906768398: return bem_classNameGet_0();
case 939713627: return bem_print_0();
case 36836391: return bem_hasNextGet_0();
case -178385347: return bem_iteratorGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 1258729534: return bem_echo_0();
case 818191735: return bem_posGetDirect_0();
case 1562650783: return bem_fieldIteratorGet_0();
case -1221104789: return bem_sourceFileNameGet_0();
case 528131764: return bem_nextGet_0();
case 1460710096: return bem_tagGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case -908283292: return bem_byteIteratorIteratorGet_0();
case -1921331379: return bem_posGet_0();
case -1253293660: return bem_serializeToString_0();
case -2101550465: return bem_strGetDirect_0();
case 307193318: return bem_serializeContents_0();
case 873076018: return bem_new_0();
case 2037996040: return bem_create_0();
case 1794395999: return bem_fieldNamesGet_0();
case -1974793116: return bem_strGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1420800859: return bem_otherType_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case 53025044: return bem_strSetDirect_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 915310200: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -1828524821: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -378149099: return bem_strSet_1(bevd_0);
case -1911965968: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -1652399230: return bem_posSet_1(bevd_0);
case -493310448: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1948028762: return bem_vcopySetDirect_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 689144780: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 527256555: return bem_posSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -294249106: return bem_vcopySet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_TextByteIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
}
