namespace be {
public class BET_3_3_6_8_NetSocketListener : BETS_Object {
public BET_3_3_6_8_NetSocketListener() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "new_2", "new_1", "bind_0", "accept_0", "addressGet_0", "addressGetDirect_0", "addressSet_1", "addressSetDirect_1", "portGet_0", "portGetDirect_0", "portSet_1", "portSetDirect_1", "backlogGet_0", "backlogGetDirect_0", "backlogSet_1", "backlogSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "address", "port", "backlog" };
}
static BET_3_3_6_8_NetSocketListener() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_3_6_8_NetSocketListener();
}
}
}
