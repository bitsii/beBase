namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_14_DbDirStoreString : BEC_2_2_8_DbDirStore {
public BEC_2_2_14_DbDirStoreString() { }
static BEC_2_2_14_DbDirStoreString() { }
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_14_DbDirStoreString_bels_0 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_14_DbDirStoreString_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_14_DbDirStoreString_bels_0, 0));
private static byte[] bece_BEC_2_2_14_DbDirStoreString_bels_1 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_14_DbDirStoreString_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_14_DbDirStoreString_bels_1, 0));
public static new BEC_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_inst;

public static new BET_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_type;

public override BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_14_DbDirStoreString_bevo_0;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 330 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 330 */
 else  /* Line: 330 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 330 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 332 */ {
bevt_5_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = beva_object.bemd_0(-1918539521);
bevt_5_tmpany_phold.bem_contentsSet_1((BEC_2_4_6_TextString) bevt_6_tmpany_phold );
} /* Line: 333 */
} /* Line: 332 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
if (beva_id == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 339 */ {
bevt_4_tmpany_phold = bece_BEC_2_2_14_DbDirStoreString_bevo_1;
bevt_3_tmpany_phold = beva_id.bem_notEquals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 339 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 339 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 339 */
 else  /* Line: 339 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 339 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_existsGet_0();
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 341 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 341 */
 else  /* Line: 341 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 341 */ {
bevt_9_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_contentsGet_0();
return bevt_8_tmpany_phold;
} /* Line: 342 */
} /* Line: 341 */
return null;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {330, 330, 330, 330, 0, 0, 0, 331, 332, 332, 333, 333, 333, 339, 339, 339, 339, 0, 0, 0, 340, 341, 341, 341, 341, 0, 0, 0, 342, 342, 342, 345};
public static new int[] bevs_smnlec
 = new int[] {25, 30, 31, 32, 34, 37, 41, 44, 45, 50, 51, 52, 53, 70, 75, 76, 77, 79, 82, 86, 89, 90, 95, 96, 97, 99, 102, 106, 109, 110, 111, 114};
/* BEGIN LINEINFO 
assign 1 330 25
def 1 330 30
assign 1 330 31
new 0 330 31
assign 1 330 32
notEquals 1 330 32
assign 1 0 34
assign 1 0 37
assign 1 0 41
assign 1 331 44
getPath 1 331 44
assign 1 332 45
def 1 332 50
assign 1 333 51
fileGet 0 333 51
assign 1 333 52
toString 0 333 52
contentsSet 1 333 53
assign 1 339 70
def 1 339 75
assign 1 339 76
new 0 339 76
assign 1 339 77
notEquals 1 339 77
assign 1 0 79
assign 1 0 82
assign 1 0 86
assign 1 340 89
getPath 1 340 89
assign 1 341 90
def 1 341 95
assign 1 341 96
fileGet 0 341 96
assign 1 341 97
existsGet 0 341 97
assign 1 0 99
assign 1 0 102
assign 1 0 106
assign 1 342 109
fileGet 0 342 109
assign 1 342 110
contentsGet 0 342 110
return 1 342 111
return 1 345 114
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -963755335: return bem_fieldIteratorGet_0();
case -282248516: return bem_serGet_0();
case -1004079418: return bem_once_0();
case -1108167878: return bem_serializeToString_0();
case -30248005: return bem_storageDirGet_0();
case 689725942: return bem_storageDirGetDirect_0();
case 1603326601: return bem_many_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -469171007: return bem_serializeContents_0();
case -545958368: return bem_toAny_0();
case 1137010475: return bem_keyEncoderGetDirect_0();
case -632169362: return bem_print_0();
case -2048609488: return bem_tagGet_0();
case -212376625: return bem_iteratorGet_0();
case 1909096874: return bem_create_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case 1419414154: return bem_new_0();
case 2077040828: return bem_copy_0();
case -1859385288: return bem_keyEncoderGet_0();
case 429419643: return bem_echo_0();
case -1300310388: return bem_serGetDirect_0();
case 1730620110: return bem_serializationIteratorGet_0();
case 1741010261: return bem_classNameGet_0();
case -1918539521: return bem_toString_0();
case -811598956: return bem_fieldNamesGet_0();
case 1687921048: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1033294101: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case 1238334884: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -363168387: return bem_sameType_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -887095005: return bem_storageDirSet_1(bevd_0);
case -1726851212: return bem_serSet_1(bevd_0);
case 1672361973: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case -548679080: return bem_keyEncoderSet_1(bevd_0);
case 1598238417: return bem_serSetDirect_1(bevd_0);
case 672338113: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case 1668168685: return bem_keyEncoderSetDirect_1(bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case -536126381: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1225776887: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 513625449: return bem_storageDirSetDirect_1(bevd_0);
case 2079174059: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -1434304379: return bem_otherType_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1339848514: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -338587975: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_2_14_DbDirStoreString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_14_DbDirStoreString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_14_DbDirStoreString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst = (BEC_2_2_14_DbDirStoreString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_type;
}
}
}
