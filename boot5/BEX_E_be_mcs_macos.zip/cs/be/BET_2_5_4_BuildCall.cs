namespace be {
public class BET_2_5_4_BuildCall : BETS_Object {
public BET_2_5_4_BuildCall() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "toAccessorName_0", "nameGet_0", "nameSet_1", "orgNameGet_0", "orgNameSet_1", "accessorTypeGet_0", "accessorTypeSet_1", "numargsGet_0", "numargsSet_1", "literalValueGet_0", "literalValueSet_1", "newNpGet_0", "newNpSet_1", "cposGet_0", "cposSet_1", "isConstructGet_0", "isConstructSet_1", "boundGet_0", "boundSet_1", "wasBoundGet_0", "wasBoundSet_1", "wasAccessorGet_0", "wasAccessorSet_1", "wasOperGet_0", "wasOperSet_1", "isLiteralGet_0", "isLiteralSet_1", "isOnceGet_0", "isOnceSet_1", "isManyGet_0", "isManySet_1", "checkTypesGet_0", "checkTypesSet_1", "checkTypesTypeGet_0", "checkTypesTypeSet_1", "superCallGet_0", "superCallSet_1", "wasImpliedConstructGet_0", "wasImpliedConstructSet_1", "wasForeachGennedGet_0", "wasForeachGennedSet_1", "untypedGet_0", "untypedSet_1", "isForwardGet_0", "isForwardSet_1", "argCastsGet_0", "argCastsSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
static BET_2_5_4_BuildCall() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_4_BuildCall();
}
}
}
