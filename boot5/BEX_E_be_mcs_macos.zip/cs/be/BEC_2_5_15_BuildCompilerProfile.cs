namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_15_BuildCompilerProfile : BEC_2_6_6_SystemObject {
public BEC_2_5_15_BuildCompilerProfile() { }
static BEC_2_5_15_BuildCompilerProfile() { }
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72,0x50,0x72,0x6F,0x66,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_0 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_1 = {0x2E,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_2 = {0x2D,0x49,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_3 = {0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_4 = {0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_5 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_6 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_7 = {0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_8 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_9 = {0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_10 = {0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_11 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_12 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_13 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_14 = {0x61,0x70,0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_15 = {0x61,0x70,0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_16 = {0x61,0x70,0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_17 = {0x61,0x70,0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_18 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_19 = {0x2E,0x64,0x79,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_20 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_20, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_21 = {0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_21, 10));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_22 = {0x6C,0x69,0x62,0x74,0x6F,0x6F,0x6C,0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6C,0x63,0x63,0x5F,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_23 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_24 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_25 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_26 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_23, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_27 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_28 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_29 = {0x2E,0x73,0x6F};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_20, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_30 = {0x20,0x2D,0x66,0x50,0x49,0x43,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_30, 7));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_31 = {0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_31, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_23, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_32 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_33 = {0x6D,0x73,0x76,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_34 = {0x63,0x6C,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_35 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_36 = {0x2D,0x6E,0x6F,0x6C,0x6F,0x67,0x6F,0x20,0x2D,0x4D,0x44,0x20,0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x4D,0x53,0x56,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_36, 45));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_37 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x53,0x45,0x43,0x55,0x52,0x45,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x4E,0x4F,0x4E,0x53,0x54,0x44,0x43,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_37, 76));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_38 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x44,0x4C,0x4C,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_39 = {0x20,0x2D,0x46,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_40 = {0x63,0x6F,0x70,0x79,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_41 = {0x6D,0x6B,0x64,0x69,0x72,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_42 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_43 = {0x2E,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_44 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_44, 32));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_45 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_45, 19));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_46 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_46, 37));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_47 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_47, 29));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_48 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_48, 22));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_49 = {0x65,0x78,0x65,0x45,0x78,0x74,0x4F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_49, 15));
public static new BEC_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;

public static new BET_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;

public BEC_2_4_6_TextString bevp_exeExt;
public BEC_2_4_6_TextString bevp_libExt;
public BEC_2_4_6_TextString bevp_ccObj;
public BEC_2_4_6_TextString bevp_cc;
public BEC_2_4_6_TextString bevp_cext;
public BEC_2_4_6_TextString bevp_oext;
public BEC_2_4_6_TextString bevp_lBuild;
public BEC_2_4_6_TextString bevp_ccout;
public BEC_2_4_6_TextString bevp_doCopy;
public BEC_2_4_6_TextString bevp_mkdirs;
public BEC_2_4_6_TextString bevp_lexe;
public BEC_2_4_6_TextString bevp_exeLibExt;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_di;
public BEC_2_4_6_TextString bevp_smac;
public BEC_2_4_6_TextString bevp_dialect;
public BEC_2_4_6_TextString bevp_compiler;
public virtual BEC_2_5_15_BuildCompilerProfile bem_new_1(BEC_2_6_6_SystemObject beva_build) {
BEC_2_4_6_TextString bevl_dialectMacro = null;
BEC_2_6_6_SystemObject bevl_exeExtOverride = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
bevp_exeExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_2_tmpany_phold = beva_build.bemd_0(-2105926539);
bevp_name = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(841151954);
bevp_oext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_1));
bevp_di = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_2));
bevp_smac = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_3));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_15_BuildCompilerProfile_bels_4));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_5));
bevt_4_tmpany_phold = beva_build.bemd_0(-2112649677);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 847 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
beva_build.bemd_1(1413101946, bevt_5_tmpany_phold);
} /* Line: 848 */
bevp_compiler = (BEC_2_4_6_TextString) beva_build.bemd_0(-2112649677);
bevt_7_tmpany_phold = beva_build.bemd_0(-2112649677);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(-346349789, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 851 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_7));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 853 */
 else  /* Line: 851 */ {
bevt_10_tmpany_phold = beva_build.bemd_0(-2112649677);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_9));
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(-346349789, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 854 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_10));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 859 */
 else  /* Line: 851 */ {
bevt_13_tmpany_phold = beva_build.bemd_0(-2112649677);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_14));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(-346349789, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 860 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_15));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
} /* Line: 863 */
 else  /* Line: 851 */ {
bevt_16_tmpany_phold = beva_build.bemd_0(-2112649677);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_16));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-346349789, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 864 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_17));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
} /* Line: 869 */
} /* Line: 851 */
} /* Line: 851 */
} /* Line: 851 */
bevt_20_tmpany_phold = beva_build.bemd_0(-2105926539);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(841151954);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_18));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-346349789, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 871 */ {
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_19));
bevt_24_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_0;
bevt_23_tmpany_phold = bevp_cc.bem_add_1(bevt_24_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_25_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_1;
bevp_ccObj = bevt_22_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevp_lBuild = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_15_BuildCompilerProfile_bels_22));
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_28_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_2;
bevt_27_tmpany_phold = bevp_cc.bem_add_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_29_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_3;
bevp_lexe = bevt_26_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 879 */
bevt_32_tmpany_phold = beva_build.bemd_0(-2105926539);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(841151954);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_27));
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_1(-346349789, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 881 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 881 */ {
bevt_36_tmpany_phold = beva_build.bemd_0(-2105926539);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(841151954);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_28));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(-346349789, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 881 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 881 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 881 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 881 */ {
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_29));
bevt_40_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_4;
bevt_39_tmpany_phold = bevp_cc.bem_add_1(bevt_40_tmpany_phold);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_41_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_5;
bevp_ccObj = bevt_38_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_6;
bevt_43_tmpany_phold = bevp_cc.bem_add_1(bevt_44_tmpany_phold);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_45_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_7;
bevp_lBuild = bevt_42_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_48_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_8;
bevt_47_tmpany_phold = bevp_cc.bem_add_1(bevt_48_tmpany_phold);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_49_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_9;
bevp_lexe = bevt_46_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 889 */
bevt_52_tmpany_phold = beva_build.bemd_0(-2105926539);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(841151954);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_32));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_1(-346349789, bevt_53_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 891 */ {
bevp_exeExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_55_tmpany_phold = beva_build.bemd_0(-2112649677);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_33));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_1(-346349789, bevt_56_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_54_tmpany_phold).bevi_bool) /* Line: 893 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_34));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_59_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_10;
bevt_58_tmpany_phold = bevp_cc.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_60_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_11;
bevp_ccObj = bevt_57_tmpany_phold.bem_add_1(bevt_60_tmpany_phold);
bevp_lBuild = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_15_BuildCompilerProfile_bels_38));
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_39));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_40));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_41));
bevp_lexe = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_42));
bevp_exeLibExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_43));
} /* Line: 905 */
 else  /* Line: 906 */ {
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_63_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_12;
bevt_62_tmpany_phold = bevp_cc.bem_add_1(bevt_63_tmpany_phold);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_64_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_13;
bevp_ccObj = bevt_61_tmpany_phold.bem_add_1(bevt_64_tmpany_phold);
bevt_65_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_14;
bevp_lBuild = bevp_cc.bem_add_1(bevt_65_tmpany_phold);
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_25));
bevt_68_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_15;
bevt_67_tmpany_phold = bevp_cc.bem_add_1(bevt_68_tmpany_phold);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_69_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_16;
bevp_lexe = bevt_66_tmpany_phold.bem_add_1(bevt_69_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 914 */
} /* Line: 893 */
bevt_70_tmpany_phold = beva_build.bemd_0(935976660);
bevt_72_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_17;
bevt_74_tmpany_phold = beva_build.bemd_0(-2105926539);
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(841151954);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_exeExtOverride = bevt_70_tmpany_phold.bemd_1(-1974306504, bevt_71_tmpany_phold);
if (bevl_exeExtOverride == null) {
bevt_75_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 918 */ {
bevt_77_tmpany_phold = bevl_exeExtOverride.bemd_0(1856255588);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 918 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 918 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 918 */
 else  /* Line: 918 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 918 */ {
bevp_exeExt = (BEC_2_4_6_TextString) bevl_exeExtOverride.bemd_0(1856255588);
} /* Line: 919 */
return this;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_doMakeDirs_1(BEC_2_4_6_TextString beva_path) {
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(beva_path);
bevt_0_tmpany_phold.bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_exeExtGet_0() {
return bevp_exeExt;
} /*method end*/
public BEC_2_4_6_TextString bem_exeExtGetDirect_0() {
return bevp_exeExt;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_exeExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libExtGet_0() {
return bevp_libExt;
} /*method end*/
public BEC_2_4_6_TextString bem_libExtGetDirect_0() {
return bevp_libExt;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_libExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_libExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_ccObjGet_0() {
return bevp_ccObj;
} /*method end*/
public BEC_2_4_6_TextString bem_ccObjGetDirect_0() {
return bevp_ccObj;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_ccObjSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccObjSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_ccGet_0() {
return bevp_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_ccGetDirect_0() {
return bevp_cc;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_ccSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_cextGet_0() {
return bevp_cext;
} /*method end*/
public BEC_2_4_6_TextString bem_cextGetDirect_0() {
return bevp_cext;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_cextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_oextGet_0() {
return bevp_oext;
} /*method end*/
public BEC_2_4_6_TextString bem_oextGetDirect_0() {
return bevp_oext;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_oextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_oextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lBuildGet_0() {
return bevp_lBuild;
} /*method end*/
public BEC_2_4_6_TextString bem_lBuildGetDirect_0() {
return bevp_lBuild;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_lBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_ccoutGet_0() {
return bevp_ccout;
} /*method end*/
public BEC_2_4_6_TextString bem_ccoutGetDirect_0() {
return bevp_ccout;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_ccoutSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_ccoutSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_doCopyGet_0() {
return bevp_doCopy;
} /*method end*/
public BEC_2_4_6_TextString bem_doCopyGetDirect_0() {
return bevp_doCopy;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_doCopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_doCopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_mkdirsGet_0() {
return bevp_mkdirs;
} /*method end*/
public BEC_2_4_6_TextString bem_mkdirsGetDirect_0() {
return bevp_mkdirs;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_mkdirsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_mkdirsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lexeGet_0() {
return bevp_lexe;
} /*method end*/
public BEC_2_4_6_TextString bem_lexeGetDirect_0() {
return bevp_lexe;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_lexeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_lexeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_exeLibExtGet_0() {
return bevp_exeLibExt;
} /*method end*/
public BEC_2_4_6_TextString bem_exeLibExtGetDirect_0() {
return bevp_exeLibExt;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_diGet_0() {
return bevp_di;
} /*method end*/
public BEC_2_4_6_TextString bem_diGetDirect_0() {
return bevp_di;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_diSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_di = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_diSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_di = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_smacGet_0() {
return bevp_smac;
} /*method end*/
public BEC_2_4_6_TextString bem_smacGetDirect_0() {
return bevp_smac;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_smacSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_smacSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_dialectGet_0() {
return bevp_dialect;
} /*method end*/
public BEC_2_4_6_TextString bem_dialectGetDirect_0() {
return bevp_dialect;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_dialectSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_dialectSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {840, 841, 841, 842, 843, 844, 845, 846, 847, 847, 847, 848, 848, 850, 851, 851, 851, 852, 853, 854, 854, 854, 856, 857, 858, 859, 860, 860, 860, 862, 863, 864, 864, 864, 866, 867, 868, 869, 871, 871, 871, 871, 872, 873, 873, 873, 873, 873, 874, 875, 876, 877, 878, 878, 878, 878, 878, 879, 881, 881, 881, 881, 0, 881, 881, 881, 881, 0, 0, 882, 883, 883, 883, 883, 883, 884, 884, 884, 884, 884, 885, 886, 887, 888, 888, 888, 888, 888, 889, 891, 891, 891, 891, 892, 893, 893, 893, 894, 895, 896, 897, 898, 899, 899, 899, 899, 899, 900, 901, 902, 903, 904, 905, 907, 908, 908, 908, 908, 908, 909, 909, 910, 911, 912, 913, 913, 913, 913, 913, 914, 917, 917, 917, 917, 917, 917, 918, 918, 918, 918, 918, 0, 0, 0, 919, 924, 924, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 192, 193, 194, 196, 197, 198, 199, 201, 202, 205, 206, 207, 209, 210, 211, 212, 215, 216, 217, 219, 220, 223, 224, 225, 227, 228, 229, 230, 235, 236, 237, 238, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 257, 258, 259, 260, 262, 265, 266, 267, 268, 270, 273, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 298, 299, 300, 301, 303, 304, 305, 306, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 345, 346, 347, 348, 349, 350, 351, 356, 357, 358, 363, 364, 367, 371, 374, 380, 381, 385, 388, 391, 395, 399, 402, 405, 409, 413, 416, 419, 423, 427, 430, 433, 437, 441, 444, 447, 451, 455, 458, 461, 465, 469, 472, 475, 479, 483, 486, 489, 493, 497, 500, 503, 507, 511, 514, 517, 521, 525, 528, 531, 535, 539, 542, 545, 549, 553, 556, 559, 563, 567, 570, 573, 577, 581, 584, 587, 591, 595, 598, 601, 605, 609, 612, 615, 619};
/* BEGIN LINEINFO 
assign 1 840 178
new 0 840 178
assign 1 841 179
platformGet 0 841 179
assign 1 841 180
nameGet 0 841 180
assign 1 842 181
new 0 842 181
assign 1 843 182
new 0 843 182
assign 1 844 183
new 0 844 183
assign 1 845 184
new 0 845 184
assign 1 846 185
new 0 846 185
assign 1 847 186
compilerGet 0 847 186
assign 1 847 187
undef 1 847 192
assign 1 848 193
new 0 848 193
compilerSet 1 848 194
assign 1 850 196
compilerGet 0 850 196
assign 1 851 197
compilerGet 0 851 197
assign 1 851 198
new 0 851 198
assign 1 851 199
equals 1 851 199
assign 1 852 201
new 0 852 201
assign 1 853 202
new 0 853 202
assign 1 854 205
compilerGet 0 854 205
assign 1 854 206
new 0 854 206
assign 1 854 207
equals 1 854 207
assign 1 856 209
new 0 856 209
assign 1 857 210
new 0 857 210
assign 1 858 211
new 0 858 211
assign 1 859 212
new 0 859 212
assign 1 860 215
compilerGet 0 860 215
assign 1 860 216
new 0 860 216
assign 1 860 217
equals 1 860 217
assign 1 862 219
new 0 862 219
assign 1 863 220
new 0 863 220
assign 1 864 223
compilerGet 0 864 223
assign 1 864 224
new 0 864 224
assign 1 864 225
equals 1 864 225
assign 1 866 227
new 0 866 227
assign 1 867 228
new 0 867 228
assign 1 868 229
new 0 868 229
assign 1 869 230
new 0 869 230
assign 1 871 235
platformGet 0 871 235
assign 1 871 236
nameGet 0 871 236
assign 1 871 237
new 0 871 237
assign 1 871 238
equals 1 871 238
assign 1 872 240
new 0 872 240
assign 1 873 241
new 0 873 241
assign 1 873 242
add 1 873 242
assign 1 873 243
add 1 873 243
assign 1 873 244
new 0 873 244
assign 1 873 245
add 1 873 245
assign 1 874 246
new 0 874 246
assign 1 875 247
new 0 875 247
assign 1 876 248
new 0 876 248
assign 1 877 249
new 0 877 249
assign 1 878 250
new 0 878 250
assign 1 878 251
add 1 878 251
assign 1 878 252
add 1 878 252
assign 1 878 253
new 0 878 253
assign 1 878 254
add 1 878 254
assign 1 879 255
assign 1 881 257
platformGet 0 881 257
assign 1 881 258
nameGet 0 881 258
assign 1 881 259
new 0 881 259
assign 1 881 260
equals 1 881 260
assign 1 0 262
assign 1 881 265
platformGet 0 881 265
assign 1 881 266
nameGet 0 881 266
assign 1 881 267
new 0 881 267
assign 1 881 268
equals 1 881 268
assign 1 0 270
assign 1 0 273
assign 1 882 277
new 0 882 277
assign 1 883 278
new 0 883 278
assign 1 883 279
add 1 883 279
assign 1 883 280
add 1 883 280
assign 1 883 281
new 0 883 281
assign 1 883 282
add 1 883 282
assign 1 884 283
new 0 884 283
assign 1 884 284
add 1 884 284
assign 1 884 285
add 1 884 285
assign 1 884 286
new 0 884 286
assign 1 884 287
add 1 884 287
assign 1 885 288
new 0 885 288
assign 1 886 289
new 0 886 289
assign 1 887 290
new 0 887 290
assign 1 888 291
new 0 888 291
assign 1 888 292
add 1 888 292
assign 1 888 293
add 1 888 293
assign 1 888 294
new 0 888 294
assign 1 888 295
add 1 888 295
assign 1 889 296
assign 1 891 298
platformGet 0 891 298
assign 1 891 299
nameGet 0 891 299
assign 1 891 300
new 0 891 300
assign 1 891 301
equals 1 891 301
assign 1 892 303
new 0 892 303
assign 1 893 304
compilerGet 0 893 304
assign 1 893 305
new 0 893 305
assign 1 893 306
equals 1 893 306
assign 1 894 308
new 0 894 308
assign 1 895 309
new 0 895 309
assign 1 896 310
new 0 896 310
assign 1 897 311
new 0 897 311
assign 1 898 312
new 0 898 312
assign 1 899 313
new 0 899 313
assign 1 899 314
add 1 899 314
assign 1 899 315
add 1 899 315
assign 1 899 316
new 0 899 316
assign 1 899 317
add 1 899 317
assign 1 900 318
new 0 900 318
assign 1 901 319
new 0 901 319
assign 1 902 320
new 0 902 320
assign 1 903 321
new 0 903 321
assign 1 904 322
new 0 904 322
assign 1 905 323
new 0 905 323
assign 1 907 326
new 0 907 326
assign 1 908 327
new 0 908 327
assign 1 908 328
add 1 908 328
assign 1 908 329
add 1 908 329
assign 1 908 330
new 0 908 330
assign 1 908 331
add 1 908 331
assign 1 909 332
new 0 909 332
assign 1 909 333
add 1 909 333
assign 1 910 334
new 0 910 334
assign 1 911 335
new 0 911 335
assign 1 912 336
new 0 912 336
assign 1 913 337
new 0 913 337
assign 1 913 338
add 1 913 338
assign 1 913 339
add 1 913 339
assign 1 913 340
new 0 913 340
assign 1 913 341
add 1 913 341
assign 1 914 342
assign 1 917 345
paramsGet 0 917 345
assign 1 917 346
new 0 917 346
assign 1 917 347
platformGet 0 917 347
assign 1 917 348
nameGet 0 917 348
assign 1 917 349
add 1 917 349
assign 1 917 350
get 1 917 350
assign 1 918 351
def 1 918 356
assign 1 918 357
firstGet 0 918 357
assign 1 918 358
def 1 918 363
assign 1 0 364
assign 1 0 367
assign 1 0 371
assign 1 919 374
firstGet 0 919 374
assign 1 924 380
new 1 924 380
makeDirs 0 924 381
return 1 0 385
return 1 0 388
assign 1 0 391
assign 1 0 395
return 1 0 399
return 1 0 402
assign 1 0 405
assign 1 0 409
return 1 0 413
return 1 0 416
assign 1 0 419
assign 1 0 423
return 1 0 427
return 1 0 430
assign 1 0 433
assign 1 0 437
return 1 0 441
return 1 0 444
assign 1 0 447
assign 1 0 451
return 1 0 455
return 1 0 458
assign 1 0 461
assign 1 0 465
return 1 0 469
return 1 0 472
assign 1 0 475
assign 1 0 479
return 1 0 483
return 1 0 486
assign 1 0 489
assign 1 0 493
return 1 0 497
return 1 0 500
assign 1 0 503
assign 1 0 507
return 1 0 511
return 1 0 514
assign 1 0 517
assign 1 0 521
return 1 0 525
return 1 0 528
assign 1 0 531
assign 1 0 535
return 1 0 539
return 1 0 542
assign 1 0 545
assign 1 0 549
return 1 0 553
return 1 0 556
assign 1 0 559
assign 1 0 563
return 1 0 567
return 1 0 570
assign 1 0 573
assign 1 0 577
return 1 0 581
return 1 0 584
assign 1 0 587
assign 1 0 591
return 1 0 595
return 1 0 598
assign 1 0 601
assign 1 0 605
return 1 0 609
return 1 0 612
assign 1 0 615
assign 1 0 619
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1129248846: return bem_cextGet_0();
case 2055850034: return bem_diGet_0();
case 1314557887: return bem_compilerGetDirect_0();
case 1301816333: return bem_smacGet_0();
case -105919061: return bem_dialectGet_0();
case 1794073241: return bem_exeLibExtGet_0();
case 447398905: return bem_copy_0();
case -1160093527: return bem_fieldIteratorGet_0();
case 265775004: return bem_tagGet_0();
case 324558137: return bem_serializationIteratorGet_0();
case 1698440478: return bem_classNameGet_0();
case 1259379161: return bem_sourceFileNameGet_0();
case -2145124906: return bem_fieldNamesGet_0();
case 375359876: return bem_diGetDirect_0();
case -686764903: return bem_exeExtGetDirect_0();
case -698592158: return bem_once_0();
case -1973371956: return bem_ccGet_0();
case 857744439: return bem_serializeToString_0();
case 1928168621: return bem_libExtGetDirect_0();
case 782702371: return bem_oextGet_0();
case 64930083: return bem_new_0();
case -378410635: return bem_mkdirsGet_0();
case 329705261: return bem_doCopyGet_0();
case 1574541715: return bem_echo_0();
case 299415139: return bem_smacGetDirect_0();
case -1873508927: return bem_doCopyGetDirect_0();
case 1351329475: return bem_ccObjGetDirect_0();
case 2094316555: return bem_libExtGet_0();
case -980253199: return bem_ccoutGet_0();
case -1924670591: return bem_print_0();
case -112881226: return bem_lBuildGet_0();
case -383409287: return bem_hashGet_0();
case -766985723: return bem_nameGetDirect_0();
case 1685630819: return bem_toAny_0();
case -1754254090: return bem_oextGetDirect_0();
case 841151954: return bem_nameGet_0();
case -1926559334: return bem_ccoutGetDirect_0();
case 1065556949: return bem_exeExtGet_0();
case 65129479: return bem_mkdirsGetDirect_0();
case -2112649677: return bem_compilerGet_0();
case -1279701215: return bem_dialectGetDirect_0();
case 621904783: return bem_many_0();
case -1487797251: return bem_lBuildGetDirect_0();
case 1409367716: return bem_iteratorGet_0();
case 682352814: return bem_lexeGetDirect_0();
case 1165255608: return bem_ccObjGet_0();
case -477793454: return bem_deserializeClassNameGet_0();
case 2097625828: return bem_lexeGet_0();
case 2080693239: return bem_cextGetDirect_0();
case -514830068: return bem_ccGetDirect_0();
case 338892103: return bem_serializeContents_0();
case 611869431: return bem_exeLibExtGetDirect_0();
case 24523401: return bem_create_0();
case 1616298039: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1662953083: return bem_nameSetDirect_1(bevd_0);
case -454090959: return bem_defined_1(bevd_0);
case -1482467029: return bem_smacSetDirect_1(bevd_0);
case 604959651: return bem_otherClass_1(bevd_0);
case -63936152: return bem_exeLibExtSet_1(bevd_0);
case 935780523: return bem_mkdirsSet_1(bevd_0);
case 1413101946: return bem_compilerSet_1(bevd_0);
case 239977955: return bem_ccSet_1(bevd_0);
case -1735879825: return bem_exeExtSetDirect_1(bevd_0);
case 854851905: return bem_sameType_1(bevd_0);
case 1464921499: return bem_def_1(bevd_0);
case -190537644: return bem_dialectSetDirect_1(bevd_0);
case 1952254152: return bem_libExtSet_1(bevd_0);
case -1859292781: return bem_new_1(bevd_0);
case 1582703619: return bem_undef_1(bevd_0);
case -1921243842: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1823065240: return bem_diSetDirect_1(bevd_0);
case -1154352610: return bem_cextSetDirect_1(bevd_0);
case -907096239: return bem_otherType_1(bevd_0);
case -93314313: return bem_lexeSetDirect_1(bevd_0);
case -514510141: return bem_smacSet_1(bevd_0);
case 631636912: return bem_ccObjSet_1(bevd_0);
case -346349789: return bem_equals_1(bevd_0);
case 1635542344: return bem_nameSet_1(bevd_0);
case -1270041233: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -544906574: return bem_exeExtSet_1(bevd_0);
case -1768544084: return bem_notEquals_1(bevd_0);
case -1122375213: return bem_doCopySet_1(bevd_0);
case -52657747: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 186968188: return bem_lBuildSet_1(bevd_0);
case 1882195140: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 21131889: return bem_diSet_1(bevd_0);
case 29326558: return bem_doCopySetDirect_1(bevd_0);
case -1425595191: return bem_ccObjSetDirect_1(bevd_0);
case 2143817101: return bem_copyTo_1(bevd_0);
case 1821671212: return bem_libExtSetDirect_1(bevd_0);
case 949930278: return bem_ccoutSet_1(bevd_0);
case -1932510652: return bem_sameClass_1(bevd_0);
case -1161346669: return bem_cextSet_1(bevd_0);
case 1569897365: return bem_exeLibExtSetDirect_1(bevd_0);
case 1920508627: return bem_ccSetDirect_1(bevd_0);
case 1892757980: return bem_oextSet_1(bevd_0);
case 2121449586: return bem_mkdirsSetDirect_1(bevd_0);
case 485096265: return bem_lexeSet_1(bevd_0);
case 179032541: return bem_ccoutSetDirect_1(bevd_0);
case 803573795: return bem_doMakeDirs_1((BEC_2_4_6_TextString) bevd_0);
case 1246974431: return bem_lBuildSetDirect_1(bevd_0);
case 948237881: return bem_oextSetDirect_1(bevd_0);
case -968521563: return bem_sameObject_1(bevd_0);
case 964528026: return bem_dialectSet_1(bevd_0);
case -388850310: return bem_compilerSetDirect_1(bevd_0);
case -685667652: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1030898412: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1425194636: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1465437715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -918533412: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1025227425: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2024613175: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1438061795: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_15_BuildCompilerProfile_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_15_BuildCompilerProfile_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_15_BuildCompilerProfile();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst = (BEC_2_5_15_BuildCompilerProfile) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_type;
}
}
}
