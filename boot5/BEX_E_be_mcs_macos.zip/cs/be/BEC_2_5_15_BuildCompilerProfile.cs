namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_15_BuildCompilerProfile : BEC_2_6_6_SystemObject {
public BEC_2_5_15_BuildCompilerProfile() { }
static BEC_2_5_15_BuildCompilerProfile() { }
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72,0x50,0x72,0x6F,0x66,0x69,0x6C,0x65};
private static byte[] becc_BEC_2_5_15_BuildCompilerProfile_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_0 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_1 = {0x2E,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_2 = {0x2D,0x49,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_3 = {0x2D,0x44,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_4 = {0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_5 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_6 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_7 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_8 = {0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_9 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_10 = {0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_11 = {0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_12 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_13 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_14 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_15 = {0x61,0x70,0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_16 = {0x61,0x70,0x67,0x63,0x63,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_17 = {0x2E,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_18 = {0x61,0x70,0x67,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_19 = {0x61,0x70,0x67,0x2B,0x2B,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_20 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_21 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_22 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_23 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_24 = {0x2E,0x64,0x79,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_25 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_25, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_26 = {0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_26, 10));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_27 = {0x6C,0x69,0x62,0x74,0x6F,0x6F,0x6C,0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6C,0x63,0x63,0x5F,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_28 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_29 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_30 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_31 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_31, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_32 = {0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_32, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_33 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_34 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_35 = {0x2E,0x73,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_36 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_36, 20));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_37 = {0x20,0x2D,0x66,0x50,0x49,0x43,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_37, 7));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_38 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_38, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_39 = {0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_39, 12));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_40 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_41 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_42 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_43 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_43, 17));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_44 = {0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_44, 4));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_45 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_46 = {0x2E,0x65,0x78,0x65};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_47 = {0x6D,0x73,0x76,0x63};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_48 = {0x63,0x6C,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_49 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_50 = {0x63,0x2B,0x2B};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_51 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_52 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_53 = {0x2D,0x6E,0x6F,0x6C,0x6F,0x67,0x6F,0x20,0x2D,0x4D,0x44,0x20,0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x4D,0x53,0x56,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_53, 45));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_54 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x53,0x45,0x43,0x55,0x52,0x45,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x4E,0x4F,0x4E,0x53,0x54,0x44,0x43,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_54, 76));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_55 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x44,0x4C,0x4C,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_56 = {0x20,0x2D,0x46,0x6F};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_57 = {0x63,0x6F,0x70,0x79,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_58 = {0x6D,0x6B,0x64,0x69,0x72,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_59 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_60 = {0x2E,0x6C,0x69,0x62};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_61 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_62 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_62, 32));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_63 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_63, 19));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_64 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_64, 37));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_65 = {0x20,0x2D,0x6F,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_66 = {0x63,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_67 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_68 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_68, 29));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_69 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x6F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_69, 22));
private static byte[] bece_BEC_2_5_15_BuildCompilerProfile_bels_70 = {0x65,0x78,0x65,0x45,0x78,0x74,0x4F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_15_BuildCompilerProfile_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_15_BuildCompilerProfile_bels_70, 15));
public static new BEC_2_5_15_BuildCompilerProfile bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;
public BEC_2_4_6_TextString bevp_exeExt;
public BEC_2_4_6_TextString bevp_libExt;
public BEC_2_4_6_TextString bevp_ccObj;
public BEC_2_4_6_TextString bevp_cc;
public BEC_2_4_6_TextString bevp_cext;
public BEC_2_4_6_TextString bevp_oext;
public BEC_2_4_6_TextString bevp_lBuild;
public BEC_2_4_6_TextString bevp_ccout;
public BEC_2_4_6_TextString bevp_doCopy;
public BEC_2_4_6_TextString bevp_mkdirs;
public BEC_2_4_6_TextString bevp_lexe;
public BEC_2_4_6_TextString bevp_exeLibExt;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_di;
public BEC_2_4_6_TextString bevp_smac;
public BEC_2_4_6_TextString bevp_dialect;
public BEC_2_4_6_TextString bevp_compiler;
public virtual BEC_2_5_15_BuildCompilerProfile bem_new_1(BEC_2_6_6_SystemObject beva_build) {
BEC_2_4_6_TextString bevl_dialectMacro = null;
BEC_2_6_6_SystemObject bevl_exeExtOverride = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
bevp_exeExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_0));
bevt_2_tmpany_phold = beva_build.bemd_0(-1380678914);
bevp_name = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(1318168996);
bevp_oext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_1));
bevp_di = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_2));
bevp_smac = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_3));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_15_BuildCompilerProfile_bels_4));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_5));
bevt_4_tmpany_phold = beva_build.bemd_0(621834866);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 848 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_6));
beva_build.bemd_1(-187774933, bevt_5_tmpany_phold);
} /* Line: 849 */
bevp_compiler = (BEC_2_4_6_TextString) beva_build.bemd_0(621834866);
bevt_7_tmpany_phold = beva_build.bemd_0(621834866);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_7));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_1(1219927083, bevt_8_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 852 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_8));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_9));
} /* Line: 854 */
 else  /* Line: 852 */ {
bevt_10_tmpany_phold = beva_build.bemd_0(621834866);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_10));
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_1(1219927083, bevt_11_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 855 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_11));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_12));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_13));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_14));
} /* Line: 860 */
 else  /* Line: 852 */ {
bevt_13_tmpany_phold = beva_build.bemd_0(621834866);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_15));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(1219927083, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 861 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_16));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_15_BuildCompilerProfile_bels_17));
} /* Line: 864 */
 else  /* Line: 852 */ {
bevt_16_tmpany_phold = beva_build.bemd_0(621834866);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_18));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(1219927083, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 865 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_19));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_20));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_21));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_22));
} /* Line: 870 */
} /* Line: 852 */
} /* Line: 852 */
} /* Line: 852 */
bevt_20_tmpany_phold = beva_build.bemd_0(-1380678914);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1318168996);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_23));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1219927083, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 872 */ {
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_24));
bevt_24_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_0;
bevt_23_tmpany_phold = bevp_cc.bem_add_1(bevt_24_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_25_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_1;
bevp_ccObj = bevt_22_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevp_lBuild = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_15_BuildCompilerProfile_bels_27));
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_28));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_29));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_30));
bevt_28_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_2;
bevt_27_tmpany_phold = bevp_cc.bem_add_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_29_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_3;
bevp_lexe = bevt_26_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 880 */
bevt_32_tmpany_phold = beva_build.bemd_0(-1380678914);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(1318168996);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_33));
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_1(1219927083, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 882 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 882 */ {
bevt_36_tmpany_phold = beva_build.bemd_0(-1380678914);
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(1318168996);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_15_BuildCompilerProfile_bels_34));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1219927083, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 882 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 882 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 882 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 882 */ {
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_35));
bevt_40_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_4;
bevt_39_tmpany_phold = bevp_cc.bem_add_1(bevt_40_tmpany_phold);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_41_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_5;
bevp_ccObj = bevt_38_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_6;
bevt_43_tmpany_phold = bevp_cc.bem_add_1(bevt_44_tmpany_phold);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_45_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_7;
bevp_lBuild = bevt_42_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_40));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_41));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_42));
bevt_48_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_8;
bevt_47_tmpany_phold = bevp_cc.bem_add_1(bevt_48_tmpany_phold);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_49_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_9;
bevp_lexe = bevt_46_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 890 */
bevt_52_tmpany_phold = beva_build.bemd_0(-1380678914);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1318168996);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_45));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_1(1219927083, bevt_53_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_50_tmpany_phold).bevi_bool) /* Line: 892 */ {
bevp_exeExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_46));
bevt_55_tmpany_phold = beva_build.bemd_0(621834866);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_47));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_1(1219927083, bevt_56_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_54_tmpany_phold).bevi_bool) /* Line: 894 */ {
bevp_cc = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_48));
bevp_cext = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_49));
bevp_dialect = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_50));
bevl_dialectMacro = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_51));
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_52));
bevt_59_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_10;
bevt_58_tmpany_phold = bevp_cc.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_60_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_11;
bevp_ccObj = bevt_57_tmpany_phold.bem_add_1(bevt_60_tmpany_phold);
bevp_lBuild = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_15_BuildCompilerProfile_bels_55));
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_56));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_15_BuildCompilerProfile_bels_57));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_15_BuildCompilerProfile_bels_58));
bevp_lexe = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_15_BuildCompilerProfile_bels_59));
bevp_exeLibExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_60));
} /* Line: 906 */
 else  /* Line: 907 */ {
bevp_libExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_61));
bevt_63_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_12;
bevt_62_tmpany_phold = bevp_cc.bem_add_1(bevt_63_tmpany_phold);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_64_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_13;
bevp_ccObj = bevt_61_tmpany_phold.bem_add_1(bevt_64_tmpany_phold);
bevt_65_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_14;
bevp_lBuild = bevp_cc.bem_add_1(bevt_65_tmpany_phold);
bevp_ccout = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_15_BuildCompilerProfile_bels_65));
bevp_doCopy = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_15_BuildCompilerProfile_bels_66));
bevp_mkdirs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_15_BuildCompilerProfile_bels_67));
bevt_68_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_15;
bevt_67_tmpany_phold = bevp_cc.bem_add_1(bevt_68_tmpany_phold);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_add_1(bevl_dialectMacro);
bevt_69_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_16;
bevp_lexe = bevt_66_tmpany_phold.bem_add_1(bevt_69_tmpany_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 915 */
} /* Line: 894 */
bevt_70_tmpany_phold = beva_build.bemd_0(-1932509809);
bevt_72_tmpany_phold = bece_BEC_2_5_15_BuildCompilerProfile_bevo_17;
bevt_74_tmpany_phold = beva_build.bemd_0(-1380678914);
bevt_73_tmpany_phold = bevt_74_tmpany_phold.bemd_0(1318168996);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_exeExtOverride = bevt_70_tmpany_phold.bemd_1(-439947503, bevt_71_tmpany_phold);
if (bevl_exeExtOverride == null) {
bevt_75_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 919 */ {
bevt_77_tmpany_phold = bevl_exeExtOverride.bemd_0(1449653483);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 919 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 919 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 919 */
 else  /* Line: 919 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 919 */ {
bevp_exeExt = (BEC_2_4_6_TextString) bevl_exeExtOverride.bemd_0(1449653483);
} /* Line: 920 */
return this;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_doMakeDirs_1(BEC_2_4_6_TextString beva_path) {
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(beva_path);
bevt_0_tmpany_phold.bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_exeExtGet_0() {
return bevp_exeExt;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_exeExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libExtGet_0() {
return bevp_libExt;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_libExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_ccObjGet_0() {
return bevp_ccObj;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_ccObjSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObj = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_ccGet_0() {
return bevp_cc;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_ccSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cc = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_cextGet_0() {
return bevp_cext;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_cextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_oextGet_0() {
return bevp_oext;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_oextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oext = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lBuildGet_0() {
return bevp_lBuild;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_lBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_ccoutGet_0() {
return bevp_ccout;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_ccoutSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccout = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_doCopyGet_0() {
return bevp_doCopy;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_doCopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doCopy = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_mkdirsGet_0() {
return bevp_mkdirs;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_mkdirsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mkdirs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lexeGet_0() {
return bevp_lexe;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_lexeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lexe = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_exeLibExtGet_0() {
return bevp_exeLibExt;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_exeLibExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeLibExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_diGet_0() {
return bevp_di;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_diSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_di = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_smacGet_0() {
return bevp_smac;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_smacSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_smac = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_dialectGet_0() {
return bevp_dialect;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_dialectSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dialect = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public virtual BEC_2_5_15_BuildCompilerProfile bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {841, 842, 842, 843, 844, 845, 846, 847, 848, 848, 848, 849, 849, 851, 852, 852, 852, 853, 854, 855, 855, 855, 857, 858, 859, 860, 861, 861, 861, 863, 864, 865, 865, 865, 867, 868, 869, 870, 872, 872, 872, 872, 873, 874, 874, 874, 874, 874, 875, 876, 877, 878, 879, 879, 879, 879, 879, 880, 882, 882, 882, 882, 0, 882, 882, 882, 882, 0, 0, 883, 884, 884, 884, 884, 884, 885, 885, 885, 885, 885, 886, 887, 888, 889, 889, 889, 889, 889, 890, 892, 892, 892, 892, 893, 894, 894, 894, 895, 896, 897, 898, 899, 900, 900, 900, 900, 900, 901, 902, 903, 904, 905, 906, 908, 909, 909, 909, 909, 909, 910, 910, 911, 912, 913, 914, 914, 914, 914, 914, 915, 918, 918, 918, 918, 918, 918, 919, 919, 919, 919, 919, 0, 0, 0, 920, 925, 925, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 210, 211, 212, 214, 215, 216, 217, 219, 220, 223, 224, 225, 227, 228, 229, 230, 233, 234, 235, 237, 238, 241, 242, 243, 245, 246, 247, 248, 253, 254, 255, 256, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 275, 276, 277, 278, 280, 283, 284, 285, 286, 288, 291, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 316, 317, 318, 319, 321, 322, 323, 324, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 363, 364, 365, 366, 367, 368, 369, 374, 375, 376, 381, 382, 385, 389, 392, 398, 399, 403, 406, 410, 413, 417, 420, 424, 427, 431, 434, 438, 441, 445, 448, 452, 455, 459, 462, 466, 469, 473, 476, 480, 483, 487, 490, 494, 497, 501, 504, 508, 511, 515, 518};
/* BEGIN LINEINFO 
assign 1 841 196
new 0 841 196
assign 1 842 197
platformGet 0 842 197
assign 1 842 198
nameGet 0 842 198
assign 1 843 199
new 0 843 199
assign 1 844 200
new 0 844 200
assign 1 845 201
new 0 845 201
assign 1 846 202
new 0 846 202
assign 1 847 203
new 0 847 203
assign 1 848 204
compilerGet 0 848 204
assign 1 848 205
undef 1 848 210
assign 1 849 211
new 0 849 211
compilerSet 1 849 212
assign 1 851 214
compilerGet 0 851 214
assign 1 852 215
compilerGet 0 852 215
assign 1 852 216
new 0 852 216
assign 1 852 217
equals 1 852 217
assign 1 853 219
new 0 853 219
assign 1 854 220
new 0 854 220
assign 1 855 223
compilerGet 0 855 223
assign 1 855 224
new 0 855 224
assign 1 855 225
equals 1 855 225
assign 1 857 227
new 0 857 227
assign 1 858 228
new 0 858 228
assign 1 859 229
new 0 859 229
assign 1 860 230
new 0 860 230
assign 1 861 233
compilerGet 0 861 233
assign 1 861 234
new 0 861 234
assign 1 861 235
equals 1 861 235
assign 1 863 237
new 0 863 237
assign 1 864 238
new 0 864 238
assign 1 865 241
compilerGet 0 865 241
assign 1 865 242
new 0 865 242
assign 1 865 243
equals 1 865 243
assign 1 867 245
new 0 867 245
assign 1 868 246
new 0 868 246
assign 1 869 247
new 0 869 247
assign 1 870 248
new 0 870 248
assign 1 872 253
platformGet 0 872 253
assign 1 872 254
nameGet 0 872 254
assign 1 872 255
new 0 872 255
assign 1 872 256
equals 1 872 256
assign 1 873 258
new 0 873 258
assign 1 874 259
new 0 874 259
assign 1 874 260
add 1 874 260
assign 1 874 261
add 1 874 261
assign 1 874 262
new 0 874 262
assign 1 874 263
add 1 874 263
assign 1 875 264
new 0 875 264
assign 1 876 265
new 0 876 265
assign 1 877 266
new 0 877 266
assign 1 878 267
new 0 878 267
assign 1 879 268
new 0 879 268
assign 1 879 269
add 1 879 269
assign 1 879 270
add 1 879 270
assign 1 879 271
new 0 879 271
assign 1 879 272
add 1 879 272
assign 1 880 273
assign 1 882 275
platformGet 0 882 275
assign 1 882 276
nameGet 0 882 276
assign 1 882 277
new 0 882 277
assign 1 882 278
equals 1 882 278
assign 1 0 280
assign 1 882 283
platformGet 0 882 283
assign 1 882 284
nameGet 0 882 284
assign 1 882 285
new 0 882 285
assign 1 882 286
equals 1 882 286
assign 1 0 288
assign 1 0 291
assign 1 883 295
new 0 883 295
assign 1 884 296
new 0 884 296
assign 1 884 297
add 1 884 297
assign 1 884 298
add 1 884 298
assign 1 884 299
new 0 884 299
assign 1 884 300
add 1 884 300
assign 1 885 301
new 0 885 301
assign 1 885 302
add 1 885 302
assign 1 885 303
add 1 885 303
assign 1 885 304
new 0 885 304
assign 1 885 305
add 1 885 305
assign 1 886 306
new 0 886 306
assign 1 887 307
new 0 887 307
assign 1 888 308
new 0 888 308
assign 1 889 309
new 0 889 309
assign 1 889 310
add 1 889 310
assign 1 889 311
add 1 889 311
assign 1 889 312
new 0 889 312
assign 1 889 313
add 1 889 313
assign 1 890 314
assign 1 892 316
platformGet 0 892 316
assign 1 892 317
nameGet 0 892 317
assign 1 892 318
new 0 892 318
assign 1 892 319
equals 1 892 319
assign 1 893 321
new 0 893 321
assign 1 894 322
compilerGet 0 894 322
assign 1 894 323
new 0 894 323
assign 1 894 324
equals 1 894 324
assign 1 895 326
new 0 895 326
assign 1 896 327
new 0 896 327
assign 1 897 328
new 0 897 328
assign 1 898 329
new 0 898 329
assign 1 899 330
new 0 899 330
assign 1 900 331
new 0 900 331
assign 1 900 332
add 1 900 332
assign 1 900 333
add 1 900 333
assign 1 900 334
new 0 900 334
assign 1 900 335
add 1 900 335
assign 1 901 336
new 0 901 336
assign 1 902 337
new 0 902 337
assign 1 903 338
new 0 903 338
assign 1 904 339
new 0 904 339
assign 1 905 340
new 0 905 340
assign 1 906 341
new 0 906 341
assign 1 908 344
new 0 908 344
assign 1 909 345
new 0 909 345
assign 1 909 346
add 1 909 346
assign 1 909 347
add 1 909 347
assign 1 909 348
new 0 909 348
assign 1 909 349
add 1 909 349
assign 1 910 350
new 0 910 350
assign 1 910 351
add 1 910 351
assign 1 911 352
new 0 911 352
assign 1 912 353
new 0 912 353
assign 1 913 354
new 0 913 354
assign 1 914 355
new 0 914 355
assign 1 914 356
add 1 914 356
assign 1 914 357
add 1 914 357
assign 1 914 358
new 0 914 358
assign 1 914 359
add 1 914 359
assign 1 915 360
assign 1 918 363
paramsGet 0 918 363
assign 1 918 364
new 0 918 364
assign 1 918 365
platformGet 0 918 365
assign 1 918 366
nameGet 0 918 366
assign 1 918 367
add 1 918 367
assign 1 918 368
get 1 918 368
assign 1 919 369
def 1 919 374
assign 1 919 375
firstGet 0 919 375
assign 1 919 376
def 1 919 381
assign 1 0 382
assign 1 0 385
assign 1 0 389
assign 1 920 392
firstGet 0 920 392
assign 1 925 398
new 1 925 398
makeDirs 0 925 399
return 1 0 403
assign 1 0 406
return 1 0 410
assign 1 0 413
return 1 0 417
assign 1 0 420
return 1 0 424
assign 1 0 427
return 1 0 431
assign 1 0 434
return 1 0 438
assign 1 0 441
return 1 0 445
assign 1 0 448
return 1 0 452
assign 1 0 455
return 1 0 459
assign 1 0 462
return 1 0 466
assign 1 0 469
return 1 0 473
assign 1 0 476
return 1 0 480
assign 1 0 483
return 1 0 487
assign 1 0 490
return 1 0 494
assign 1 0 497
return 1 0 501
assign 1 0 504
return 1 0 508
assign 1 0 511
return 1 0 515
assign 1 0 518
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2084463022: return bem_libExtGet_0();
case -1498444598: return bem_dialectGet_0();
case 1121843415: return bem_exeExtGet_0();
case -829112796: return bem_sourceFileNameGet_0();
case 1318168996: return bem_nameGet_0();
case 862777188: return bem_ccoutGet_0();
case 1738566514: return bem_cextGet_0();
case 621834866: return bem_compilerGet_0();
case 462697424: return bem_many_0();
case 1611504589: return bem_new_0();
case -587183431: return bem_diGet_0();
case -1779073385: return bem_toString_0();
case 1011044651: return bem_lBuildGet_0();
case -310579539: return bem_smacGet_0();
case -993607120: return bem_fieldIteratorGet_0();
case -1620217339: return bem_serializeContents_0();
case 1959393086: return bem_ccObjGet_0();
case 570560636: return bem_serializeToString_0();
case 32699518: return bem_copy_0();
case 1467676516: return bem_iteratorGet_0();
case -817841652: return bem_toAny_0();
case 1007010882: return bem_hashGet_0();
case -1418716942: return bem_lexeGet_0();
case -313480583: return bem_doCopyGet_0();
case -593487297: return bem_mkdirsGet_0();
case -604042750: return bem_once_0();
case 1670877559: return bem_exeLibExtGet_0();
case 984657505: return bem_serializationIteratorGet_0();
case -349248390: return bem_deserializeClassNameGet_0();
case -386274073: return bem_tagGet_0();
case -68587803: return bem_print_0();
case -1616726900: return bem_oextGet_0();
case 1113679576: return bem_echo_0();
case 1612357662: return bem_ccGet_0();
case 967087648: return bem_classNameGet_0();
case -1683940834: return bem_create_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1915157348: return bem_defined_1(bevd_0);
case -337289143: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 794005350: return bem_mkdirsSet_1(bevd_0);
case -1232302101: return bem_lexeSet_1(bevd_0);
case -690797068: return bem_otherClass_1(bevd_0);
case 705985194: return bem_doMakeDirs_1((BEC_2_4_6_TextString) bevd_0);
case 400917403: return bem_sameClass_1(bevd_0);
case -1371950595: return bem_sameType_1(bevd_0);
case -1738089053: return bem_exeExtSet_1(bevd_0);
case -187774933: return bem_compilerSet_1(bevd_0);
case -1503584026: return bem_ccObjSet_1(bevd_0);
case -122563801: return bem_cextSet_1(bevd_0);
case 1412822362: return bem_new_1(bevd_0);
case 186027133: return bem_sameObject_1(bevd_0);
case -1163022531: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 871077747: return bem_copyTo_1(bevd_0);
case -487758162: return bem_doCopySet_1(bevd_0);
case 250983012: return bem_nameSet_1(bevd_0);
case 1017703126: return bem_def_1(bevd_0);
case 1085789341: return bem_exeLibExtSet_1(bevd_0);
case -1003116355: return bem_undefined_1(bevd_0);
case -149661057: return bem_ccSet_1(bevd_0);
case -1388929410: return bem_smacSet_1(bevd_0);
case 768529536: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1394703037: return bem_notEquals_1(bevd_0);
case 976341280: return bem_lBuildSet_1(bevd_0);
case 1645467992: return bem_dialectSet_1(bevd_0);
case 1219927083: return bem_equals_1(bevd_0);
case -497225509: return bem_undef_1(bevd_0);
case -1320126626: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -23654406: return bem_diSet_1(bevd_0);
case -1857123920: return bem_otherType_1(bevd_0);
case -2141735180: return bem_oextSet_1(bevd_0);
case -1356820387: return bem_libExtSet_1(bevd_0);
case 1164637193: return bem_ccoutSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 963667386: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 194196311: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 5892141: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 980645593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -74821886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1893386943: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -423405168: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_15_BuildCompilerProfile_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_15_BuildCompilerProfile_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_15_BuildCompilerProfile();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst = (BEC_2_5_15_BuildCompilerProfile) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_15_BuildCompilerProfile.bece_BEC_2_5_15_BuildCompilerProfile_bevs_inst;
}
}
}
