namespace be {
public class BET_2_5_8_BuildEmitData : BETS_Object {
public BET_2_5_8_BuildEmitData() {
string[] bevs_mtnames = new string[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "addSynClass_2", "addParsedClass_1", "ptspGet_0", "ptspGetDirect_0", "ptspSet_1", "ptspSetDirect_1", "allNamesGet_0", "allNamesGetDirect_0", "allNamesSet_1", "allNamesSetDirect_1", "foreignClassesGet_0", "foreignClassesGetDirect_0", "foreignClassesSet_1", "foreignClassesSetDirect_1", "nameEntriesGet_0", "nameEntriesGetDirect_0", "nameEntriesSet_1", "nameEntriesSetDirect_1", "classesGet_0", "classesGetDirect_0", "classesSet_1", "classesSetDirect_1", "parseOrderClassNamesGet_0", "parseOrderClassNamesGetDirect_0", "parseOrderClassNamesSet_1", "parseOrderClassNamesSetDirect_1", "justParsedGet_0", "justParsedGetDirect_0", "justParsedSet_1", "justParsedSetDirect_1", "synClassesGet_0", "synClassesGetDirect_0", "synClassesSet_1", "synClassesSetDirect_1", "midNamesGet_0", "midNamesGetDirect_0", "midNamesSet_1", "midNamesSetDirect_1", "usedByGet_0", "usedByGetDirect_0", "usedBySet_1", "usedBySetDirect_1", "subClassesGet_0", "subClassesGetDirect_0", "subClassesSet_1", "subClassesSetDirect_1", "propertyIndexesGet_0", "propertyIndexesGetDirect_0", "propertyIndexesSet_1", "propertyIndexesSetDirect_1", "methodIndexesGet_0", "methodIndexesGetDirect_0", "methodIndexesSet_1", "methodIndexesSetDirect_1", "shouldEmitGet_0", "shouldEmitGetDirect_0", "shouldEmitSet_1", "shouldEmitSetDirect_1", "aliasedGet_0", "aliasedGetDirect_0", "aliasedSet_1", "aliasedSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "ptsp", "allNames", "foreignClasses", "nameEntries", "classes", "parseOrderClassNames", "justParsed", "synClasses", "midNames", "usedBy", "subClasses", "propertyIndexes", "methodIndexes", "shouldEmit", "aliased" };
}
static BET_2_5_8_BuildEmitData() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_8_BuildEmitData();
}
}
}
