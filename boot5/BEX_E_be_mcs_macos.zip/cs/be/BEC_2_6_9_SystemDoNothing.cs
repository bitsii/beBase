namespace be {
/* IO:File: source/base/DoNothing.be */
public class BEC_2_6_9_SystemDoNothing : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemDoNothing() { }
static BEC_2_6_9_SystemDoNothing() { }
private static byte[] becc_BEC_2_6_9_SystemDoNothing_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x44,0x6F,0x4E,0x6F,0x74,0x68,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_6_9_SystemDoNothing_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x44,0x6F,0x4E,0x6F,0x74,0x68,0x69,0x6E,0x67,0x2E,0x62,0x65};
public static new BEC_2_6_9_SystemDoNothing bece_BEC_2_6_9_SystemDoNothing_bevs_inst;

public static new BET_2_6_9_SystemDoNothing bece_BEC_2_6_9_SystemDoNothing_bevs_type;

public virtual BEC_2_6_9_SystemDoNothing bem_main_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1852877275: return bem_new_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -236887613: return bem_classNameGet_0();
case 1076647192: return bem_create_0();
case -2092760709: return bem_once_0();
case 1359360249: return bem_echo_0();
case 1064677251: return bem_many_0();
case 605836827: return bem_sourceFileNameGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 928457034: return bem_serializeContents_0();
case -1430066973: return bem_print_0();
case -323661464: return bem_serializeToString_0();
case 849387251: return bem_toAny_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
case 996718380: return bem_toString_0();
case 823327627: return bem_main_0();
case -1369483363: return bem_fieldNamesGet_0();
case 864393987: return bem_tagGet_0();
case 2070502838: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -960159496: return bem_otherClass_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemDoNothing_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_9_SystemDoNothing_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemDoNothing();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_inst = (BEC_2_6_9_SystemDoNothing) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_9_SystemDoNothing.bece_BEC_2_6_9_SystemDoNothing_bevs_type;
}
}
}
