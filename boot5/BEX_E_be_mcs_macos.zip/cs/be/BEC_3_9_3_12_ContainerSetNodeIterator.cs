namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_12_ContainerSetNodeIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_3_12_ContainerSetNodeIterator() { }
static BEC_3_9_3_12_ContainerSetNodeIterator() { }
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4E,0x6F,0x64,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2 = (new BEC_2_4_3_MathInt(0));
public static new BEC_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;

public static new BET_3_9_3_12_ContainerSetNodeIterator bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;

public BEC_2_9_3_ContainerSet bevp_set;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_current;
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
bevp_set = beva__set;
bevp_slots = bevp_set.bem_slotsGet_0();
bevp_modu = bevp_slots.bem_sizeGet_0();
bevp_current = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_containerGet_0() {
return bevp_set;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 657 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 657 */ {
bevt_2_tmpany_phold = bevp_slots.bem_get_1(bevl_i);
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 658 */ {
bevp_current = bevl_i;
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 660 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 657 */
 else  /* Line: 657 */ {
break;
} /* Line: 657 */
} /* Line: 657 */
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_i = bevp_current;
while (true)
 /* Line: 667 */ {
if (bevl_i.bevi_int < bevp_modu.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 667 */ {
bevl_toRet = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_toRet == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 669 */ {
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_0;
bevp_current = bevl_i.bem_add_1(bevt_2_tmpany_phold);
return bevl_toRet;
} /* Line: 671 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 667 */
 else  /* Line: 667 */ {
break;
} /* Line: 667 */
} /* Line: 667 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_delete_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_1;
bevl_i = bevp_current.bem_subtract_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevo_2;
if (bevl_i.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 679 */ {
bevl_sn = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_sn == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 681 */ {
bevt_5_tmpany_phold = bevl_sn.bem_keyGet_0();
bevt_4_tmpany_phold = bevp_set.bem_delete_1(bevt_5_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 682 */ {
bevp_current = bevl_i;
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 684 */
} /* Line: 682 */
} /* Line: 681 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_setGet_0() {
return bevp_set;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_setSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_set = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentGet_0() {
return bevp_current;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {644, 645, 646, 647, 653, 657, 657, 657, 658, 658, 658, 659, 660, 660, 657, 663, 663, 667, 667, 667, 668, 669, 669, 670, 670, 671, 667, 674, 678, 678, 679, 679, 679, 680, 681, 681, 682, 682, 683, 684, 684, 688, 688, 693, 697, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 23, 27, 36, 39, 44, 45, 46, 51, 52, 53, 54, 56, 62, 63, 71, 74, 79, 80, 81, 86, 87, 88, 89, 91, 97, 110, 111, 112, 113, 118, 119, 120, 125, 126, 127, 129, 130, 131, 135, 136, 139, 142, 145, 148, 152, 155, 159, 162, 166, 169};
/* BEGIN LINEINFO 
assign 1 644 20
assign 1 645 21
slotsGet 0 645 21
assign 1 646 22
sizeGet 0 646 22
assign 1 647 23
new 0 647 23
return 1 653 27
assign 1 657 36
assign 1 657 39
lesser 1 657 44
assign 1 658 45
get 1 658 45
assign 1 658 46
def 1 658 51
assign 1 659 52
assign 1 660 53
new 0 660 53
return 1 660 54
assign 1 657 56
increment 0 657 56
assign 1 663 62
new 0 663 62
return 1 663 63
assign 1 667 71
assign 1 667 74
lesser 1 667 79
assign 1 668 80
get 1 668 80
assign 1 669 81
def 1 669 86
assign 1 670 87
new 0 670 87
assign 1 670 88
add 1 670 88
return 1 671 89
assign 1 667 91
increment 0 667 91
return 1 674 97
assign 1 678 110
new 0 678 110
assign 1 678 111
subtract 1 678 111
assign 1 679 112
new 0 679 112
assign 1 679 113
greaterEquals 1 679 118
assign 1 680 119
get 1 680 119
assign 1 681 120
def 1 681 125
assign 1 682 126
keyGet 0 682 126
assign 1 682 127
delete 1 682 127
assign 1 683 129
assign 1 684 130
new 0 684 130
return 1 684 131
assign 1 688 135
new 0 688 135
return 1 688 136
return 1 693 139
return 1 697 142
return 1 0 145
assign 1 0 148
return 1 0 152
assign 1 0 155
return 1 0 159
assign 1 0 162
return 1 0 166
assign 1 0 169
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1714984646: return bem_serializeToString_0();
case 1348777534: return bem_many_0();
case -873085717: return bem_iteratorGet_0();
case 1907596400: return bem_copy_0();
case -1939566740: return bem_delete_0();
case -1799121498: return bem_moduGet_0();
case -1921829025: return bem_nextGet_0();
case -1320125172: return bem_once_0();
case 713197195: return bem_deserializeClassNameGet_0();
case -1201589976: return bem_slotsGet_0();
case -977833063: return bem_toString_0();
case -102559792: return bem_setGet_0();
case -1698152847: return bem_serializationIteratorGet_0();
case -1435450334: return bem_classNameGet_0();
case -100075913: return bem_new_0();
case 975002362: return bem_tagGet_0();
case -2080318285: return bem_sourceFileNameGet_0();
case -1026810920: return bem_nodeIteratorIteratorGet_0();
case -58474533: return bem_currentGet_0();
case 1418537405: return bem_fieldIteratorGet_0();
case 335515617: return bem_hasNextGet_0();
case -92908170: return bem_print_0();
case 596758489: return bem_create_0();
case 189986949: return bem_toAny_0();
case 1732066970: return bem_echo_0();
case -328171317: return bem_hashGet_0();
case 1361238708: return bem_serializeContents_0();
case -1154130332: return bem_containerGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1208346138: return bem_setSet_1(bevd_0);
case -36926033: return bem_notEquals_1(bevd_0);
case 1456864247: return bem_currentSet_1(bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case -2063815757: return bem_moduSet_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case -1685745238: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 63543588: return bem_slotsSet_1(bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_12_ContainerSetNodeIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_12_ContainerSetNodeIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst = (BEC_3_9_3_12_ContainerSetNodeIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_12_ContainerSetNodeIterator.bece_BEC_3_9_3_12_ContainerSetNodeIterator_bevs_type;
}
}
}
