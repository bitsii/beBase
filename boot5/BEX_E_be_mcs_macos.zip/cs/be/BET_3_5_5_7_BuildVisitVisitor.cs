namespace be {
public class BET_3_5_5_7_BuildVisitVisitor : BETS_Object {
public BET_3_5_5_7_BuildVisitVisitor() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "begin_1", "accept_1", "end_1", "transGet_0", "transSet_1", "buildGet_0", "buildSet_1", "constGet_0", "constSet_1", "ntypesGet_0", "ntypesSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
static BET_3_5_5_7_BuildVisitVisitor() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
}
}
