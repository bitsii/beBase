namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_6_BuildMethod : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMethod() { }
static BEC_2_5_6_BuildMethod() { }
private static byte[] becc_BEC_2_5_6_BuildMethod_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_5_6_BuildMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_0 = {0x20};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_6_BuildMethod_bels_2 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
public static new BEC_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_inst;

public static new BET_2_5_6_BuildMethod bece_BEC_2_5_6_BuildMethod_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_6_6_SystemObject bevp_property;
public BEC_2_6_6_SystemObject bevp_rtype;
public BEC_2_6_6_SystemObject bevp_tmpVars;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_4_3_MathInt bevp_tmpCnt;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_4_3_MathInt bevp_tryDepth;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_3_MathInt bevp_amax;
public BEC_2_4_3_MathInt bevp_hmax;
public BEC_2_4_3_MathInt bevp_mmax;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_tmpCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_tryDepth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_amax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_hmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_mmax = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_6_BuildMethod_bels_0));
bevl_ret = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
if (bevp_name == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 182*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMethod_bels_1));
bevt_3_ta_ph = bevl_ret.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
} /* Line: 183*/
if (bevp_numargs == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 185*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_6_BuildMethod_bels_2));
bevt_7_ta_ph = bevl_ret.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_numargs.bem_toString_0();
bevl_ret = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
} /* Line: 186*/
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGetDirect_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGetDirect_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGet_0() {
return bevp_property;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyGetDirect_0() {
return bevp_property;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_property = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_propertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_property = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGet_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rtypeGetDirect_0() {
return bevp_rtype;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rtype = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_rtypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rtype = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGet_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVarsGetDirect_0() {
return bevp_tmpVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tmpVars = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tmpVars = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGet_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_tmpCntGetDirect_0() {
return bevp_tmpCnt;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tmpCntSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tmpCnt = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGet_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_4_3_MathInt bem_tryDepthGetDirect_0() {
return bevp_tryDepth;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_tryDepthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tryDepth = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGet_0() {
return bevp_amax;
} /*method end*/
public BEC_2_4_3_MathInt bem_amaxGetDirect_0() {
return bevp_amax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_amaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_amax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGet_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmaxGetDirect_0() {
return bevp_hmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_hmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGet_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_4_3_MathInt bem_mmaxGetDirect_0() {
return bevp_mmax;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMethod bem_mmaxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mmax = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {166, 167, 168, 169, 170, 171, 173, 174, 175, 181, 181, 181, 182, 182, 183, 183, 183, 183, 185, 185, 186, 186, 186, 186, 188, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {31, 32, 33, 34, 35, 36, 37, 38, 39, 54, 55, 56, 57, 62, 63, 64, 65, 66, 68, 73, 74, 75, 76, 77, 79, 82, 85, 88, 92, 96, 99, 102, 106, 110, 113, 116, 120, 124, 127, 130, 134, 138, 141, 144, 148, 152, 155, 158, 162, 166, 169, 172, 176, 180, 183, 186, 190, 194, 197, 200, 204, 208, 211, 214, 218, 222, 225, 228, 232, 236, 239, 242, 246, 250, 253, 256, 260, 264, 267, 270, 274, 278, 281, 284, 288};
/* BEGIN LINEINFO 
assign 1 166 31
new 0 166 31
assign 1 167 32
new 0 167 32
assign 1 168 33
new 0 168 33
assign 1 169 34
new 0 169 34
assign 1 170 35
new 0 170 35
assign 1 171 36
new 0 171 36
assign 1 173 37
new 0 173 37
assign 1 174 38
new 0 174 38
assign 1 175 39
new 0 175 39
assign 1 181 54
classNameGet 0 181 54
assign 1 181 55
new 0 181 55
assign 1 181 56
add 1 181 56
assign 1 182 57
def 1 182 62
assign 1 183 63
new 0 183 63
assign 1 183 64
add 1 183 64
assign 1 183 65
toString 0 183 65
assign 1 183 66
add 1 183 66
assign 1 185 68
def 1 185 73
assign 1 186 74
new 0 186 74
assign 1 186 75
add 1 186 75
assign 1 186 76
toString 0 186 76
assign 1 186 77
add 1 186 77
return 1 188 79
return 1 0 82
return 1 0 85
assign 1 0 88
assign 1 0 92
return 1 0 96
return 1 0 99
assign 1 0 102
assign 1 0 106
return 1 0 110
return 1 0 113
assign 1 0 116
assign 1 0 120
return 1 0 124
return 1 0 127
assign 1 0 130
assign 1 0 134
return 1 0 138
return 1 0 141
assign 1 0 144
assign 1 0 148
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
return 1 0 194
return 1 0 197
assign 1 0 200
assign 1 0 204
return 1 0 208
return 1 0 211
assign 1 0 214
assign 1 0 218
return 1 0 222
return 1 0 225
assign 1 0 228
assign 1 0 232
return 1 0 236
return 1 0 239
assign 1 0 242
assign 1 0 246
return 1 0 250
return 1 0 253
assign 1 0 256
assign 1 0 260
return 1 0 264
return 1 0 267
assign 1 0 270
assign 1 0 274
return 1 0 278
return 1 0 281
assign 1 0 284
assign 1 0 288
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1777316122: return bem_serializationIteratorGet_0();
case 1928620786: return bem_orgNameGetDirect_0();
case 652045549: return bem_mmaxGet_0();
case 1444826768: return bem_orderedVarsGet_0();
case 182725714: return bem_tmpCntGetDirect_0();
case -2070846101: return bem_hashGet_0();
case -527531531: return bem_nameGetDirect_0();
case -1729645430: return bem_anyMapGetDirect_0();
case 1519304391: return bem_amaxGetDirect_0();
case -1729758892: return bem_rtypeGetDirect_0();
case 112496763: return bem_tryDepthGet_0();
case 99255499: return bem_isFinalGetDirect_0();
case 2037996040: return bem_create_0();
case -1036391864: return bem_copy_0();
case -1511561092: return bem_isGenAccessorGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case 1004407968: return bem_tmpCntGet_0();
case 2130842692: return bem_hmaxGetDirect_0();
case -1582364614: return bem_isGenAccessorGetDirect_0();
case -1083737341: return bem_numargsGet_0();
case -1608519010: return bem_anyMapGet_0();
case 1932841787: return bem_propertyGetDirect_0();
case 2071133624: return bem_tmpVarsGet_0();
case 260637178: return bem_propertyGet_0();
case -1906768398: return bem_classNameGet_0();
case 405170711: return bem_orgNameGet_0();
case 873076018: return bem_new_0();
case 939713627: return bem_print_0();
case -178385347: return bem_iteratorGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 1562650783: return bem_fieldIteratorGet_0();
case 1640157629: return bem_toString_0();
case -1432171810: return bem_nameGet_0();
case -1254594531: return bem_tmpVarsGetDirect_0();
case 1975378871: return bem_orderedVarsGetDirect_0();
case 1094135240: return bem_mmaxGetDirect_0();
case -1221104789: return bem_sourceFileNameGet_0();
case 1460710096: return bem_tagGet_0();
case -709713572: return bem_isFinalGet_0();
case 1679255742: return bem_rtypeGet_0();
case 386490961: return bem_numargsGetDirect_0();
case 220241123: return bem_tryDepthGetDirect_0();
case -1253293660: return bem_serializeToString_0();
case -1630000479: return bem_hmaxGet_0();
case 1515806364: return bem_amaxGet_0();
case 307193318: return bem_serializeContents_0();
case 1258729534: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1574512337: return bem_anyMapSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case 599003895: return bem_tryDepthSetDirect_1(bevd_0);
case 654358227: return bem_mmaxSetDirect_1(bevd_0);
case 67465497: return bem_nameSetDirect_1(bevd_0);
case 1975462345: return bem_hmaxSet_1(bevd_0);
case -2061704016: return bem_numargsSet_1(bevd_0);
case -652339272: return bem_amaxSetDirect_1(bevd_0);
case 1999487773: return bem_tryDepthSet_1(bevd_0);
case 1755520527: return bem_tmpCntSetDirect_1(bevd_0);
case -1227682327: return bem_isFinalSet_1(bevd_0);
case 1024944136: return bem_propertySetDirect_1(bevd_0);
case -1515786375: return bem_rtypeSet_1(bevd_0);
case -303642929: return bem_hmaxSetDirect_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case -1614879729: return bem_rtypeSetDirect_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -1310054765: return bem_tmpVarsSetDirect_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -304560290: return bem_orgNameSet_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -1232791091: return bem_nameSet_1(bevd_0);
case -523107318: return bem_orgNameSetDirect_1(bevd_0);
case -709695472: return bem_tmpCntSet_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 935034563: return bem_numargsSetDirect_1(bevd_0);
case 1477222712: return bem_isGenAccessorSetDirect_1(bevd_0);
case 2076479608: return bem_propertySet_1(bevd_0);
case 991562918: return bem_orderedVarsSet_1(bevd_0);
case 1194164287: return bem_mmaxSet_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1667281034: return bem_isFinalSetDirect_1(bevd_0);
case -1335895023: return bem_tmpVarsSet_1(bevd_0);
case 138898026: return bem_amaxSet_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -1080341798: return bem_anyMapSet_1(bevd_0);
case 730381469: return bem_orderedVarsSetDirect_1(bevd_0);
case 1830656527: return bem_isGenAccessorSet_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_6_BuildMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst = (BEC_2_5_6_BuildMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildMethod.bece_BEC_2_5_6_BuildMethod_bevs_type;
}
}
}
