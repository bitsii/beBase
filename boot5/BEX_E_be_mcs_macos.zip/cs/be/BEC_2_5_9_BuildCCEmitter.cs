namespace be {
/* IO:File: source/build/CCEmitter.be */
public sealed class BEC_2_5_9_BuildCCEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
static BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_21, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_22, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_31, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_32, 14));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_10, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_46, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_51, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_21, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_52, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_55, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_56, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_57, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_60, 28));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_39, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_62, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x2A,0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_66, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_39, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x63,0x63,0x53,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 45));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 8));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_77, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 45));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x66,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 3));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 8));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 3));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_39, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_2, 0));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_53 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 45));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_55 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_56 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 8));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_59 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_60 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_21, 7));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_61 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_22, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_62 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_63 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_52, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_64 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_83, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x7D,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_65 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_66 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_10, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_67 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x5D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_68 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_106, 22));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x66,0x6F,0x72,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x69,0x20,0x3D,0x20,0x30,0x3B,0x20,0x69,0x20,0x3C,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x20,0x69,0x2B,0x2B,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x67,0x5F,0x6C,0x65,0x20,0x3D,0x20,0x2A,0x28,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B,0x69,0x5D,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x62,0x65,0x76,0x67,0x5F,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x5D,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x7D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_69 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_119, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_70 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_120, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_71 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_121, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_72 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_120, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_73 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_131, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_74 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x63,0x63,0x42,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_75 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_135, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x2C,0x20,0x67,0x63,0x5F,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x5D,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_76 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_77 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_140, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_78 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_79 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_140, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_80 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_81 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_140, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_82 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_5, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_83 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_141, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_84 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_10, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_85 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_86 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_10, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_87 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_158, 52));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_88 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_89 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_51, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_90 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_5, 2));
public static new BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static new BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_6_TextString bevp_onceDecRefs;
public BEC_2_4_3_MathInt bevp_onceDecRefsCount;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
base.bem_new_1(beva__build);
bevp_invp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 44 */
 else  /* Line: 45 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 46 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 55 */
 else  /* Line: 56 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_tmpany_phold);
} /* Line: 61 */
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_31_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevp_heow.bem_write_1(bevt_26_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevp_heow.bem_write_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_45_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_49_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_50_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_51_tmpany_phold);
bevp_deow.bem_write_1(bevt_47_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_52_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_7_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_22_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-1875982602);
bevt_20_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_tmpany_phold );
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_26_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_0_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_classHeadBody.bem_addValue_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_22_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_17_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevp_classHeadBody.bem_addValue_1(bevt_26_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 140 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 141 */
 else  /* Line: 140 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-1547082045);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1570647300, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
} /* Line: 143 */
 else  /* Line: 140 */ {
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1547082045);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(1570647300, bevt_10_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
} /* Line: 145 */
 else  /* Line: 146 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_tmpany_phold );
} /* Line: 147 */
} /* Line: 140 */
} /* Line: 140 */
return bevl_tcall;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-1547082045);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1570647300, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 155 */
bevt_5_tmpany_phold = base.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(2133739390);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1323914976, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 165 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-1282393990);
bevp_classHeaders.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 166 */
 else  /* Line: 167 */ {
base.bem_handleClassEmit_1(beva_node);
} /* Line: 168 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_8_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevl_clh = bevt_4_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_11_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevt_24_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevt_22_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_32_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-902248231);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(512136633);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_4_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_2_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 200 */
 else  /* Line: 201 */ {
bevt_9_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_8_tmpany_phold = bem_getClassConfig_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_6_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
} /* Line: 202 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
} /* Line: 208 */
 else  /* Line: 209 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 210 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_afterCast_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 228 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1286003110);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 229 */
bevt_12_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_23_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_24_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = beva_node.bem_heldGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bemd_0(-1286003110);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevl_newCall = bevt_14_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
} /* Line: 232 */
 else  /* Line: 233 */ {
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_36_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_35_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_37_tmpany_phold);
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = beva_node.bem_heldGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-1286003110);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevl_newCall = bevt_29_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
} /* Line: 234 */
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 240 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1286003110);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 241 */
bevt_12_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_23_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_24_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = beva_node.bem_heldGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bemd_0(-1286003110);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevl_newCall = bevt_14_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
} /* Line: 244 */
 else  /* Line: 245 */ {
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_36_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_35_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_37_tmpany_phold);
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_43;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = beva_node.bem_heldGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-1286003110);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_44;
bevl_newCall = bevt_29_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
} /* Line: 246 */
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 252 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_45;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_46;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_47;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_48;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 253 */
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_49;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_50;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevl_litArgs = bevt_12_tmpany_phold.bem_add_1(beva_belsName);
bevt_17_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_51;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_has_1(bevt_18_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_52;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_53;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_28_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_54;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevl_litArgs);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_55;
bevl_newCall = bevt_19_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
} /* Line: 258 */
 else  /* Line: 259 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_56;
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_57;
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_41_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_42_tmpany_phold);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_58;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevl_litArgs);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_59;
bevl_newCall = bevt_32_tmpany_phold.bem_add_1(bevt_44_tmpany_phold);
} /* Line: 260 */
return bevl_newCall;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevp_onceDecRefsCount.bevi_int++;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_notEmpty_1(bevp_onceDecRefs);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevp_onceDecRefs.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 268 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecRefs.bem_addValue_1(bevt_4_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(beva_anyName);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_60;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_typeName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_61;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_62;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_63;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainInClassGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_64;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_preClassOutput_0() {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
bevp_setOutputTime = null;
bevt_1_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 318 */ {
return this;
} /* Line: 319 */
 else  /* Line: 320 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevl_outts = bevt_6_tmpany_phold.bem_lastUpdatedGet_0();
bevt_9_tmpany_phold = bevp_inClass.bem_fromFileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1252286644);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bemd_0(1975954967);
bevt_10_tmpany_phold = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 323 */ {
return this;
} /* Line: 326 */
bevp_setOutputTime = bevl_outts;
} /* Line: 329 */
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_1_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_1_tmpany_phold = bem_getLibOutput_0();
return bevt_1_tmpany_phold;
} /* Line: 335 */
bevt_2_tmpany_phold = base.bem_getClassOutput_0();
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 341 */ {
bevl_clns = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 344 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 349 */ {
bevl_clend = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevt_4_tmpany_phold = beva_cle.bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 357 */
} /* Line: 355 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_65;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_has_1(bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 364 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 367 */
return bevl_bet;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_66;
bevt_5_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_67;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevp_deow.bem_write_1(bevt_2_tmpany_phold);
bevl_beh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevl_beh.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevl_beh.bem_addValue_1(bevt_17_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_20_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_18_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevl_beh.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevl_beh.bem_addValue_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_beh.bem_addValue_1(bevt_24_tmpany_phold);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_28_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevt_26_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevt_25_tmpany_phold.bem_addValue_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevl_bet.bem_addValue_1(bevt_32_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_33_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_33_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 390 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 390 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1532131234);
if (bevl_firstmnsyn.bevi_bool) /* Line: 391 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 392 */
 else  /* Line: 393 */ {
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_bet.bem_addValue_1(bevt_35_tmpany_phold);
} /* Line: 394 */
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_38_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevt_37_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 396 */
 else  /* Line: 390 */ {
break;
} /* Line: 390 */
} /* Line: 390 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevl_bet.bem_addValue_1(bevt_41_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_42_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_42_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 403 */ {
bevt_43_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_43_tmpany_phold).bevi_bool) /* Line: 403 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1532131234);
if (bevl_firstptsyn.bevi_bool) /* Line: 404 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 405 */
 else  /* Line: 406 */ {
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
} /* Line: 407 */
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_47_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) bevt_46_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_45_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 409 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_bet.bem_addValue_1(bevt_49_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevt_50_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_57_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_68;
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_60_tmpany_phold);
bevt_61_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) bevt_59_tmpany_phold.bem_addValue_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_58_tmpany_phold.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 417 */
 else  /* Line: 418 */ {
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_63_tmpany_phold.bem_addValue_1(bevt_67_tmpany_phold);
} /* Line: 419 */
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_bet.bem_addValue_1(bevt_68_tmpany_phold);
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) bevt_70_tmpany_phold.bem_addValue_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_69_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevl_bet.bem_addValue_1(bevt_74_tmpany_phold);
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_75_tmpany_phold = bem_genMark_1(bevt_76_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevl_bet.bem_addValue_1(bevt_77_tmpany_phold);
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevl_bet.bem_addValue_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_79_tmpany_phold = bem_genMark_1(bevt_80_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_79_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_bet.bem_addValue_1(bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevl_bet.bem_addValue_1(bevt_82_tmpany_phold);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) bevt_87_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) bevt_86_tmpany_phold.bem_addValue_1(bevt_93_tmpany_phold);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevt_85_tmpany_phold.bem_addValue_1(bevp_onceDecRefs);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) bevt_84_tmpany_phold.bem_addValue_1(bevt_94_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_101_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) bevt_96_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_95_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevp_onceDecRefs.bem_clear_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_103_tmpany_phold = bem_getClassOutput_0();
bevt_103_tmpany_phold.bem_write_1(bevl_bet);
bevt_104_tmpany_phold = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_104_tmpany_phold.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_20_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_31_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
if (bevp_deow == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 450 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_69;
bevt_8_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_70;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_4_tmpany_phold.bem_add_1(bevp_headExt);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_71;
bevt_14_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_72;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_10_tmpany_phold.bem_add_1(bevp_headExt);
bevt_16_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_21_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_existsGet_0();
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_23_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_fileGet_0();
bevt_22_tmpany_phold.bem_makeDirs_0();
} /* Line: 457 */
bevt_25_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_tmpany_phold.bemd_0(642173546);
bevt_27_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_tmpany_phold.bemd_0(642173546);
bevt_29_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_has_1(bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_32_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_get_1(bevt_33_tmpany_phold);
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 464 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 464 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1532131234);
bevt_35_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_tmpany_phold.bem_fileGet_0();
bevt_37_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(642173546);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bemd_0(-13840373);
bevt_38_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_38_tmpany_phold.bemd_0(77620147);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 470 */
 else  /* Line: 464 */ {
break;
} /* Line: 464 */
} /* Line: 464 */
} /* Line: 464 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevp_deow.bem_write_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_has_1(bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevt_47_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_get_1(bevt_48_tmpany_phold);
bevt_1_tmpany_loop = bevt_46_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 486 */ {
bevt_49_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_49_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1532131234);
bevt_50_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_tmpany_phold.bem_fileGet_0();
bevt_52_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(642173546);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bemd_0(-13840373);
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_53_tmpany_phold.bemd_0(77620147);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 492 */
 else  /* Line: 486 */ {
break;
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 486 */
bevt_55_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_has_1(bevt_56_tmpany_phold);
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 495 */ {
bevt_58_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_get_1(bevt_59_tmpany_phold);
bevt_2_tmpany_loop = bevt_57_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_60_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 497 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(1532131234);
bevt_61_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_tmpany_phold.bem_fileGet_0();
bevt_63_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(642173546);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bemd_0(-13840373);
bevt_64_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_64_tmpany_phold.bemd_0(77620147);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 503 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
} /* Line: 497 */
} /* Line: 495 */
return this;
} /*method end*/
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_27_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 516 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_6_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_existsGet_0();
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 519 */
bevt_10_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_tmpany_phold.bemd_0(642173546);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevp_shlibe.bem_write_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_has_1(bevt_14_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 525 */ {
bevt_16_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_get_1(bevt_17_tmpany_phold);
bevt_0_tmpany_loop = bevt_15_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 527 */ {
bevt_18_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 527 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1532131234);
bevt_19_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(642173546);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bemd_0(-13840373);
bevt_22_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_22_tmpany_phold.bemd_0(77620147);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 533 */
 else  /* Line: 527 */ {
break;
} /* Line: 527 */
} /* Line: 527 */
} /* Line: 527 */
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevp_shlibe.bem_write_1(bevt_23_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_25_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_has_1(bevt_26_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 539 */ {
bevt_28_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_get_1(bevt_29_tmpany_phold);
bevt_1_tmpany_loop = bevt_27_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 540 */ {
bevt_30_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 540 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1532131234);
bevt_31_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_tmpany_phold.bem_fileGet_0();
bevt_33_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(642173546);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bemd_0(-13840373);
bevt_34_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_34_tmpany_phold.bemd_0(77620147);
bevt_35_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 545 */
 else  /* Line: 540 */ {
break;
} /* Line: 540 */
} /* Line: 540 */
} /* Line: 540 */
} /* Line: 539 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_73;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_has_1(bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 563 */ {
bevl_mh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevl_mh.bem_addValue_1(bevt_6_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 566 */
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_74;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_has_1(bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 579 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 580 */
 else  /* Line: 579 */ {
bevt_8_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_75;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_has_1(bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 581 */ {
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_10_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
} /* Line: 582 */
} /* Line: 579 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1889367965);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 594 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 594 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1532131234);
if (bevl_first.bevi_bool) /* Line: 595 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 596 */
 else  /* Line: 597 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 598 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 600 */
 else  /* Line: 594 */ {
break;
} /* Line: 594 */
} /* Line: 594 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_76;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_77;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_78;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_79;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_80;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_81;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_82;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_runtimeInitGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_83;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
bevt_1_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_tmpany_phold.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-1875982602);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_20_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 641 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_tmpany_phold, bevl_asnr);
} /* Line: 642 */
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevt_24_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_29_tmpany_phold);
bevt_28_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_45_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) bevt_44_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) bevt_43_tmpany_phold.bem_addValue_1(bevt_46_tmpany_phold);
bevt_42_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_48_tmpany_phold);
bevt_47_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_55_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_55_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) bevt_54_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_57_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevt_53_tmpany_phold.bem_addValue_1(bevt_57_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_49_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_62_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-2101296861);
if (bevt_61_tmpany_phold == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_65_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_0(-2101296861);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(1570647300, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_67_tmpany_phold);
bevt_66_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 662 */
 else  /* Line: 663 */ {
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_69_tmpany_phold);
bevt_68_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 664 */
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_71_tmpany_phold);
bevt_70_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_78_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) bevt_77_tmpany_phold.bem_addValue_1(bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) bevt_76_tmpany_phold.bem_addValue_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) bevt_75_tmpany_phold.bem_addValue_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) bevt_74_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) bevt_73_tmpany_phold.bem_addValue_1(bevt_82_tmpany_phold);
bevt_72_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_84_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_86_tmpany_phold);
bevt_85_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_96_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevt_95_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) bevt_94_tmpany_phold.bem_addValue_1(bevt_97_tmpany_phold);
bevt_93_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_99_tmpany_phold);
bevt_98_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_84;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_libEmitName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_85;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_86;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevp_libEmitName);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_87;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevp_heow.bem_write_1(bevt_4_tmpany_phold);
base.bem_emitLib_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_88;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_89;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_90;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGetDirect_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGetDirect_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGet_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGetDirect_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGet_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGetDirect_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() {
return bevp_deon;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGetDirect_0() {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() {
return bevp_heon;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGetDirect_0() {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() {
return bevp_deop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() {
return bevp_heop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() {
return bevp_deow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() {
return bevp_heow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 21, 22, 23, 24, 25, 29, 31, 32, 33, 34, 35, 39, 43, 43, 44, 44, 44, 46, 46, 48, 48, 48, 48, 48, 48, 50, 50, 51, 51, 53, 53, 55, 55, 55, 55, 55, 55, 55, 57, 57, 59, 59, 61, 61, 64, 64, 66, 66, 68, 70, 72, 74, 76, 76, 77, 77, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 86, 86, 87, 87, 87, 87, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 98, 98, 98, 102, 104, 105, 106, 106, 107, 111, 111, 115, 115, 119, 119, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 126, 128, 128, 128, 128, 128, 128, 130, 130, 130, 130, 130, 130, 130, 130, 130, 130, 132, 134, 134, 140, 140, 140, 140, 141, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 147, 147, 149, 153, 153, 153, 153, 154, 154, 155, 157, 157, 161, 161, 161, 161, 161, 161, 161, 161, 165, 165, 165, 165, 166, 166, 166, 168, 174, 174, 174, 174, 174, 176, 176, 176, 176, 176, 176, 176, 176, 178, 180, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 191, 191, 191, 192, 193, 193, 193, 193, 193, 193, 195, 195, 195, 195, 195, 195, 195, 195, 195, 195, 199, 199, 199, 200, 200, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 207, 207, 208, 210, 212, 212, 212, 212, 212, 212, 212, 212, 217, 217, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 222, 222, 222, 222, 222, 222, 222, 222, 222, 224, 224, 224, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 231, 231, 231, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 236, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 243, 243, 243, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 256, 256, 256, 256, 256, 257, 257, 257, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 262, 266, 267, 267, 268, 268, 270, 270, 270, 271, 271, 271, 271, 271, 276, 277, 278, 278, 278, 279, 285, 285, 285, 285, 289, 289, 293, 293, 298, 298, 302, 302, 306, 306, 310, 310, 310, 310, 317, 318, 0, 318, 318, 318, 318, 318, 0, 0, 319, 321, 321, 321, 322, 322, 322, 323, 326, 329, 334, 335, 335, 337, 337, 341, 342, 343, 343, 344, 349, 351, 352, 352, 353, 354, 355, 355, 356, 356, 356, 357, 363, 364, 364, 364, 365, 365, 365, 365, 365, 365, 365, 365, 365, 366, 366, 366, 366, 367, 367, 367, 369, 373, 373, 373, 373, 373, 373, 374, 375, 375, 375, 375, 375, 375, 376, 376, 377, 377, 377, 377, 378, 378, 379, 379, 380, 380, 380, 380, 380, 381, 381, 382, 382, 383, 383, 384, 386, 387, 387, 387, 387, 387, 387, 387, 387, 388, 388, 389, 390, 390, 0, 390, 390, 392, 394, 394, 396, 396, 396, 396, 398, 398, 399, 399, 401, 401, 402, 403, 403, 0, 403, 403, 405, 407, 407, 409, 409, 409, 409, 411, 411, 413, 413, 415, 415, 415, 415, 415, 415, 416, 416, 416, 417, 417, 417, 417, 417, 417, 419, 419, 419, 419, 419, 419, 421, 421, 423, 423, 423, 423, 423, 423, 424, 424, 425, 425, 425, 426, 426, 427, 427, 428, 428, 428, 429, 429, 430, 430, 432, 432, 432, 432, 432, 432, 432, 432, 432, 432, 432, 432, 432, 433, 433, 433, 433, 433, 433, 433, 433, 433, 434, 435, 437, 437, 438, 438, 450, 450, 451, 452, 452, 452, 452, 452, 452, 452, 453, 453, 453, 453, 453, 453, 453, 454, 454, 455, 455, 456, 456, 456, 456, 456, 457, 457, 457, 459, 459, 459, 460, 460, 460, 462, 462, 462, 464, 464, 464, 464, 0, 464, 464, 466, 466, 467, 467, 467, 468, 468, 470, 474, 474, 475, 475, 477, 477, 478, 478, 484, 484, 484, 486, 486, 486, 486, 0, 486, 486, 488, 488, 489, 489, 489, 490, 490, 492, 495, 495, 495, 497, 497, 497, 497, 0, 497, 497, 499, 499, 500, 500, 500, 501, 501, 503, 510, 511, 516, 516, 517, 518, 518, 518, 518, 518, 519, 519, 519, 521, 521, 521, 523, 523, 525, 525, 525, 527, 527, 527, 527, 0, 527, 527, 529, 529, 530, 530, 530, 531, 531, 533, 537, 537, 538, 539, 539, 539, 540, 540, 540, 540, 0, 540, 540, 541, 541, 542, 542, 542, 543, 543, 544, 544, 545, 551, 556, 557, 559, 559, 561, 561, 563, 563, 563, 564, 565, 565, 565, 566, 569, 570, 575, 575, 579, 579, 579, 580, 580, 580, 580, 580, 581, 581, 581, 582, 582, 582, 582, 582, 588, 588, 589, 591, 591, 591, 591, 593, 594, 0, 594, 594, 596, 598, 598, 600, 600, 600, 600, 600, 600, 604, 604, 604, 609, 611, 611, 611, 611, 611, 613, 613, 613, 613, 613, 613, 613, 613, 613, 613, 613, 615, 619, 619, 620, 620, 620, 620, 621, 625, 625, 626, 626, 626, 626, 627, 627, 627, 627, 631, 631, 631, 635, 635, 635, 636, 636, 636, 637, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 639, 640, 641, 641, 642, 642, 645, 645, 645, 645, 645, 645, 645, 647, 647, 647, 650, 650, 650, 650, 650, 650, 650, 650, 650, 650, 650, 650, 650, 655, 655, 655, 655, 655, 655, 658, 658, 658, 660, 660, 660, 660, 660, 660, 660, 660, 660, 660, 660, 660, 661, 661, 661, 661, 0, 661, 661, 661, 0, 0, 662, 662, 662, 664, 664, 664, 666, 667, 670, 670, 670, 672, 672, 672, 672, 672, 672, 672, 672, 672, 672, 672, 672, 673, 673, 673, 675, 675, 675, 677, 679, 679, 679, 679, 679, 679, 679, 681, 681, 681, 681, 681, 681, 683, 683, 683, 689, 689, 689, 689, 689, 690, 690, 690, 690, 690, 692, 697, 697, 698, 698, 698, 698, 699, 699, 699, 699, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 293, 352, 357, 358, 359, 360, 363, 364, 366, 367, 368, 369, 370, 371, 372, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 391, 392, 393, 394, 395, 396, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 514, 515, 516, 517, 518, 519, 523, 524, 528, 529, 533, 534, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 613, 614, 615, 620, 621, 624, 625, 626, 627, 629, 632, 633, 634, 635, 637, 640, 641, 645, 655, 656, 657, 658, 660, 661, 662, 664, 665, 675, 676, 677, 678, 679, 680, 681, 682, 692, 693, 694, 695, 697, 698, 699, 702, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 839, 840, 845, 846, 847, 848, 849, 850, 853, 854, 855, 856, 857, 858, 859, 874, 875, 877, 880, 882, 883, 884, 885, 886, 887, 888, 889, 893, 894, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1010, 1011, 1012, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1049, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1111, 1112, 1113, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 1142, 1143, 1144, 1145, 1146, 1147, 1148, 1150, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1224, 1225, 1226, 1227, 1228, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1240, 1241, 1242, 1243, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1255, 1267, 1268, 1269, 1271, 1272, 1274, 1275, 1276, 1277, 1278, 1279, 1280, 1281, 1287, 1288, 1289, 1290, 1291, 1292, 1299, 1300, 1301, 1302, 1306, 1307, 1311, 1312, 1316, 1317, 1321, 1322, 1326, 1327, 1333, 1334, 1335, 1336, 1352, 1353, 1355, 1358, 1359, 1360, 1361, 1366, 1367, 1370, 1374, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1385, 1387, 1395, 1397, 1398, 1400, 1401, 1407, 1409, 1410, 1411, 1412, 1423, 1425, 1426, 1427, 1428, 1429, 1430, 1435, 1436, 1437, 1438, 1439, 1462, 1463, 1464, 1465, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1476, 1477, 1478, 1479, 1480, 1481, 1482, 1484, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 1609, 1610, 1611, 1612, 1613, 1614, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1646, 1649, 1651, 1653, 1656, 1657, 1659, 1660, 1661, 1662, 1668, 1669, 1670, 1671, 1672, 1673, 1674, 1675, 1676, 1676, 1679, 1681, 1683, 1686, 1687, 1689, 1690, 1691, 1692, 1698, 1699, 1700, 1701, 1702, 1703, 1704, 1705, 1706, 1707, 1708, 1709, 1710, 1712, 1713, 1714, 1715, 1716, 1717, 1720, 1721, 1722, 1723, 1724, 1725, 1727, 1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1770, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1851, 1856, 1857, 1858, 1859, 1860, 1861, 1862, 1863, 1864, 1865, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1884, 1885, 1886, 1887, 1889, 1890, 1891, 1892, 1893, 1894, 1895, 1896, 1897, 1899, 1900, 1901, 1902, 1902, 1905, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1930, 1931, 1932, 1934, 1935, 1936, 1937, 1937, 1940, 1942, 1943, 1944, 1945, 1946, 1947, 1948, 1949, 1950, 1957, 1958, 1959, 1961, 1962, 1963, 1964, 1964, 1967, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1988, 1989, 2032, 2037, 2038, 2039, 2040, 2041, 2042, 2047, 2048, 2049, 2050, 2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2061, 2062, 2063, 2064, 2064, 2067, 2069, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2077, 2084, 2085, 2086, 2087, 2088, 2089, 2091, 2092, 2093, 2094, 2094, 2097, 2099, 2100, 2101, 2102, 2103, 2104, 2105, 2106, 2107, 2108, 2109, 2117, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2138, 2139, 2140, 2141, 2142, 2144, 2145, 2150, 2151, 2168, 2169, 2170, 2172, 2173, 2174, 2175, 2176, 2179, 2180, 2181, 2183, 2184, 2185, 2186, 2187, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2219, 2222, 2224, 2226, 2229, 2230, 2232, 2233, 2234, 2235, 2236, 2237, 2243, 2244, 2245, 2265, 2266, 2267, 2268, 2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2291, 2292, 2293, 2294, 2295, 2296, 2297, 2309, 2310, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2323, 2324, 2325, 2433, 2434, 2435, 2436, 2437, 2438, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2452, 2453, 2454, 2455, 2456, 2457, 2459, 2460, 2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480, 2481, 2482, 2483, 2484, 2485, 2486, 2487, 2488, 2489, 2490, 2491, 2492, 2493, 2494, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502, 2503, 2504, 2505, 2506, 2507, 2508, 2513, 2514, 2517, 2518, 2519, 2521, 2524, 2528, 2529, 2530, 2533, 2534, 2535, 2537, 2538, 2539, 2540, 2541, 2542, 2543, 2544, 2545, 2546, 2547, 2548, 2549, 2550, 2551, 2552, 2553, 2554, 2555, 2556, 2557, 2558, 2559, 2560, 2561, 2562, 2563, 2564, 2565, 2566, 2567, 2568, 2569, 2570, 2571, 2572, 2573, 2574, 2575, 2576, 2588, 2589, 2590, 2591, 2592, 2593, 2594, 2595, 2596, 2597, 2598, 2611, 2612, 2613, 2614, 2615, 2616, 2617, 2618, 2619, 2620, 2623, 2626, 2629, 2633, 2637, 2640, 2643, 2647, 2651, 2654, 2657, 2661, 2665, 2668, 2671, 2675, 2679, 2682, 2685, 2689, 2693, 2696, 2699, 2703, 2707, 2710, 2713, 2717, 2721, 2724, 2727, 2731, 2735, 2738, 2741, 2745, 2749, 2752, 2755, 2759, 2763, 2766, 2769, 2773, 2777, 2780, 2783, 2787, 2791, 2794, 2797, 2801};
/* BEGIN LINEINFO 
assign 1 17 276
new 0 17 276
assign 1 18 277
new 0 18 277
assign 1 19 278
new 0 19 278
assign 1 21 279
new 0 21 279
assign 1 22 280
new 0 22 280
assign 1 23 281
new 0 23 281
assign 1 24 282
new 0 24 282
assign 1 25 283
new 0 25 283
new 1 29 284
assign 1 31 285
new 0 31 285
assign 1 32 286
new 0 32 286
assign 1 33 287
new 0 33 287
assign 1 34 288
new 0 34 288
assign 1 35 289
new 0 35 289
addValue 1 39 293
assign 1 43 352
def 1 43 357
assign 1 44 358
libNameGet 0 44 358
assign 1 44 359
relEmitName 1 44 359
assign 1 44 360
extend 1 44 360
assign 1 46 363
new 0 46 363
assign 1 46 364
extend 1 46 364
assign 1 48 366
new 0 48 366
assign 1 48 367
emitNameGet 0 48 367
assign 1 48 368
addValue 1 48 368
assign 1 48 369
addValue 1 48 369
assign 1 48 370
new 0 48 370
assign 1 48 371
addValue 1 48 371
assign 1 50 372
def 1 50 377
assign 1 51 378
new 0 51 378
addValue 1 51 379
assign 1 53 380
new 0 53 380
addValue 1 53 381
assign 1 55 382
new 0 55 382
assign 1 55 383
addValue 1 55 383
assign 1 55 384
libNameGet 0 55 384
assign 1 55 385
relEmitName 1 55 385
assign 1 55 386
addValue 1 55 386
assign 1 55 387
new 0 55 387
addValue 1 55 388
assign 1 57 391
new 0 57 391
addValue 1 57 392
assign 1 59 393
new 0 59 393
addValue 1 59 394
assign 1 61 395
new 0 61 395
addValue 1 61 396
assign 1 64 398
new 0 64 398
addValue 1 64 399
assign 1 66 400
new 0 66 400
addValue 1 66 401
write 1 68 402
write 1 70 403
write 1 72 404
clear 0 74 405
assign 1 76 406
new 0 76 406
write 1 76 407
assign 1 77 408
new 0 77 408
write 1 77 409
assign 1 78 410
new 0 78 410
write 1 78 411
assign 1 79 412
new 0 79 412
assign 1 79 413
emitNameGet 0 79 413
assign 1 79 414
add 1 79 414
assign 1 79 415
new 0 79 415
assign 1 79 416
add 1 79 416
assign 1 79 417
getHeaderInitialInst 1 79 417
assign 1 79 418
add 1 79 418
assign 1 79 419
new 0 79 419
assign 1 79 420
add 1 79 420
write 1 79 421
assign 1 80 422
new 0 80 422
write 1 80 423
assign 1 81 424
new 0 81 424
write 1 81 425
assign 1 82 426
new 0 82 426
write 1 82 427
assign 1 83 428
new 0 83 428
write 1 83 429
assign 1 84 430
new 0 84 430
write 1 84 431
assign 1 85 432
new 0 85 432
write 1 85 433
assign 1 86 434
new 0 86 434
write 1 86 435
assign 1 87 436
new 0 87 436
assign 1 87 437
emitNameGet 0 87 437
assign 1 87 438
add 1 87 438
assign 1 87 439
new 0 87 439
assign 1 87 440
add 1 87 440
write 1 87 441
assign 1 89 442
new 0 89 442
assign 1 89 443
emitNameGet 0 89 443
assign 1 89 444
add 1 89 444
assign 1 89 445
new 0 89 445
assign 1 89 446
add 1 89 446
write 1 89 447
assign 1 91 448
new 0 91 448
return 1 91 449
assign 1 95 479
overrideMtdDecGet 0 95 479
assign 1 95 480
addValue 1 95 480
assign 1 95 481
getClassConfig 1 95 481
assign 1 95 482
libNameGet 0 95 482
assign 1 95 483
relEmitName 1 95 483
assign 1 95 484
addValue 1 95 484
assign 1 95 485
new 0 95 485
assign 1 95 486
addValue 1 95 486
assign 1 95 487
emitNameGet 0 95 487
assign 1 95 488
addValue 1 95 488
assign 1 95 489
new 0 95 489
assign 1 95 490
addValue 1 95 490
assign 1 95 491
addValue 1 95 491
assign 1 95 492
new 0 95 492
assign 1 95 493
addValue 1 95 493
addValue 1 95 494
assign 1 96 495
new 0 96 495
assign 1 96 496
addValue 1 96 496
assign 1 96 497
heldGet 0 96 497
assign 1 96 498
namepathGet 0 96 498
assign 1 96 499
getClassConfig 1 96 499
assign 1 96 500
libNameGet 0 96 500
assign 1 96 501
relEmitName 1 96 501
assign 1 96 502
addValue 1 96 502
assign 1 96 503
new 0 96 503
assign 1 96 504
addValue 1 96 504
addValue 1 96 505
assign 1 98 506
new 0 98 506
assign 1 98 507
addValue 1 98 507
addValue 1 98 508
assign 1 102 514
new 0 102 514
write 1 104 515
clear 0 105 516
assign 1 106 517
new 0 106 517
write 1 106 518
return 1 107 519
assign 1 111 523
new 0 111 523
return 1 111 524
assign 1 115 528
new 0 115 528
return 1 115 529
assign 1 119 533
new 0 119 533
return 1 119 534
assign 1 124 564
addValue 1 124 564
assign 1 124 565
libNameGet 0 124 565
assign 1 124 566
relEmitName 1 124 566
assign 1 124 567
addValue 1 124 567
assign 1 124 568
new 0 124 568
assign 1 124 569
addValue 1 124 569
assign 1 124 570
emitNameGet 0 124 570
assign 1 124 571
addValue 1 124 571
assign 1 124 572
new 0 124 572
assign 1 124 573
addValue 1 124 573
assign 1 124 574
addValue 1 124 574
assign 1 124 575
new 0 124 575
addValue 1 124 576
addValue 1 126 577
assign 1 128 578
new 0 128 578
assign 1 128 579
addValue 1 128 579
assign 1 128 580
addValue 1 128 580
assign 1 128 581
new 0 128 581
assign 1 128 582
addValue 1 128 582
addValue 1 128 583
assign 1 130 584
new 0 130 584
assign 1 130 585
addValue 1 130 585
assign 1 130 586
libNameGet 0 130 586
assign 1 130 587
relEmitName 1 130 587
assign 1 130 588
addValue 1 130 588
assign 1 130 589
new 0 130 589
assign 1 130 590
addValue 1 130 590
assign 1 130 591
addValue 1 130 591
assign 1 130 592
new 0 130 592
addValue 1 130 593
addValue 1 132 594
assign 1 134 595
new 0 134 595
addValue 1 134 596
assign 1 140 613
typenameGet 0 140 613
assign 1 140 614
NULLGet 0 140 614
assign 1 140 615
equals 1 140 620
assign 1 141 621
new 0 141 621
assign 1 142 624
heldGet 0 142 624
assign 1 142 625
nameGet 0 142 625
assign 1 142 626
new 0 142 626
assign 1 142 627
equals 1 142 627
assign 1 143 629
new 0 143 629
assign 1 144 632
heldGet 0 144 632
assign 1 144 633
nameGet 0 144 633
assign 1 144 634
new 0 144 634
assign 1 144 635
equals 1 144 635
assign 1 145 637
new 0 145 637
assign 1 147 640
heldGet 0 147 640
assign 1 147 641
nameForVar 1 147 641
return 1 149 645
assign 1 153 655
heldGet 0 153 655
assign 1 153 656
nameGet 0 153 656
assign 1 153 657
new 0 153 657
assign 1 153 658
equals 1 153 658
assign 1 154 660
new 0 154 660
assign 1 154 661
add 1 154 661
return 1 155 662
assign 1 157 664
formCallTarg 1 157 664
return 1 157 665
assign 1 161 675
new 0 161 675
assign 1 161 676
addValue 1 161 676
assign 1 161 677
secondGet 0 161 677
assign 1 161 678
formTarg 1 161 678
assign 1 161 679
addValue 1 161 679
assign 1 161 680
new 0 161 680
assign 1 161 681
addValue 1 161 681
addValue 1 161 682
assign 1 165 692
heldGet 0 165 692
assign 1 165 693
langsGet 0 165 693
assign 1 165 694
new 0 165 694
assign 1 165 695
has 1 165 695
assign 1 166 697
heldGet 0 166 697
assign 1 166 698
textGet 0 166 698
addValue 1 166 699
handleClassEmit 1 168 702
assign 1 174 744
new 0 174 744
assign 1 174 745
emitNameGet 0 174 745
assign 1 174 746
add 1 174 746
assign 1 174 747
new 0 174 747
assign 1 174 748
add 1 174 748
assign 1 176 749
new 0 176 749
assign 1 176 750
typeEmitNameGet 0 176 750
assign 1 176 751
add 1 176 751
assign 1 176 752
new 0 176 752
assign 1 176 753
add 1 176 753
assign 1 176 754
add 1 176 754
assign 1 176 755
new 0 176 755
assign 1 176 756
add 1 176 756
addClassHeader 1 178 757
assign 1 180 758
new 0 180 758
assign 1 182 759
typeEmitNameGet 0 182 759
assign 1 182 760
addValue 1 182 760
assign 1 182 761
new 0 182 761
assign 1 182 762
addValue 1 182 762
assign 1 182 763
emitNameGet 0 182 763
assign 1 182 764
addValue 1 182 764
assign 1 182 765
new 0 182 765
assign 1 182 766
addValue 1 182 766
assign 1 182 767
addValue 1 182 767
assign 1 182 768
new 0 182 768
addValue 1 182 769
assign 1 184 770
new 0 184 770
assign 1 184 771
addValue 1 184 771
assign 1 184 772
typeEmitNameGet 0 184 772
assign 1 184 773
addValue 1 184 773
assign 1 184 774
new 0 184 774
assign 1 184 775
addValue 1 184 775
assign 1 184 776
emitNameGet 0 184 776
assign 1 184 777
addValue 1 184 777
assign 1 184 778
new 0 184 778
assign 1 184 779
emitNameGet 0 184 779
assign 1 184 780
add 1 184 780
assign 1 184 781
new 0 184 781
assign 1 184 782
add 1 184 782
addValue 1 184 783
return 1 186 784
assign 1 191 804
new 0 191 804
assign 1 191 805
toString 0 191 805
assign 1 191 806
add 1 191 806
incrementValue 0 192 807
assign 1 193 808
new 0 193 808
assign 1 193 809
addValue 1 193 809
assign 1 193 810
addValue 1 193 810
assign 1 193 811
new 0 193 811
assign 1 193 812
addValue 1 193 812
addValue 1 193 813
assign 1 195 814
containedGet 0 195 814
assign 1 195 815
firstGet 0 195 815
assign 1 195 816
containedGet 0 195 816
assign 1 195 817
firstGet 0 195 817
assign 1 195 818
new 0 195 818
assign 1 195 819
add 1 195 819
assign 1 195 820
new 0 195 820
assign 1 195 821
add 1 195 821
assign 1 195 822
finalAssign 4 195 822
addValue 1 195 823
assign 1 199 839
isTypedGet 0 199 839
assign 1 199 840
not 0 199 845
assign 1 200 846
libNameGet 0 200 846
assign 1 200 847
relEmitName 1 200 847
assign 1 200 848
addValue 1 200 848
assign 1 200 849
new 0 200 849
addValue 1 200 850
assign 1 202 853
namepathGet 0 202 853
assign 1 202 854
getClassConfig 1 202 854
assign 1 202 855
libNameGet 0 202 855
assign 1 202 856
relEmitName 1 202 856
assign 1 202 857
addValue 1 202 857
assign 1 202 858
new 0 202 858
addValue 1 202 859
assign 1 207 874
new 0 207 874
assign 1 207 875
equals 1 207 875
assign 1 208 877
new 0 208 877
assign 1 210 880
new 0 210 880
assign 1 212 882
new 0 212 882
assign 1 212 883
add 1 212 883
assign 1 212 884
libNameGet 0 212 884
assign 1 212 885
relEmitName 1 212 885
assign 1 212 886
add 1 212 886
assign 1 212 887
new 0 212 887
assign 1 212 888
add 1 212 888
return 1 212 889
assign 1 217 893
new 0 217 893
return 1 217 894
assign 1 221 921
overrideMtdDecGet 0 221 921
assign 1 221 922
addValue 1 221 922
assign 1 221 923
new 0 221 923
assign 1 221 924
addValue 1 221 924
assign 1 221 925
emitNameGet 0 221 925
assign 1 221 926
addValue 1 221 926
assign 1 221 927
new 0 221 927
assign 1 221 928
addValue 1 221 928
assign 1 221 929
addValue 1 221 929
assign 1 221 930
new 0 221 930
assign 1 221 931
addValue 1 221 931
assign 1 221 932
addValue 1 221 932
assign 1 221 933
new 0 221 933
assign 1 221 934
addValue 1 221 934
addValue 1 221 935
assign 1 222 936
new 0 222 936
assign 1 222 937
addValue 1 222 937
assign 1 222 938
addValue 1 222 938
assign 1 222 939
new 0 222 939
assign 1 222 940
addValue 1 222 940
assign 1 222 941
addValue 1 222 941
assign 1 222 942
new 0 222 942
assign 1 222 943
addValue 1 222 943
addValue 1 222 944
assign 1 224 945
new 0 224 945
assign 1 224 946
addValue 1 224 946
addValue 1 224 947
assign 1 229 997
new 0 229 997
assign 1 229 998
libNameGet 0 229 998
assign 1 229 999
relEmitName 1 229 999
assign 1 229 1000
add 1 229 1000
assign 1 229 1001
new 0 229 1001
assign 1 229 1002
add 1 229 1002
assign 1 229 1003
heldGet 0 229 1003
assign 1 229 1004
literalValueGet 0 229 1004
assign 1 229 1005
add 1 229 1005
assign 1 229 1006
new 0 229 1006
assign 1 229 1007
add 1 229 1007
return 1 229 1008
assign 1 231 1010
emitChecksGet 0 231 1010
assign 1 231 1011
new 0 231 1011
assign 1 231 1012
has 1 231 1012
assign 1 232 1014
new 0 232 1014
assign 1 232 1015
libNameGet 0 232 1015
assign 1 232 1016
relEmitName 1 232 1016
assign 1 232 1017
add 1 232 1017
assign 1 232 1018
new 0 232 1018
assign 1 232 1019
add 1 232 1019
assign 1 232 1020
libNameGet 0 232 1020
assign 1 232 1021
relEmitName 1 232 1021
assign 1 232 1022
add 1 232 1022
assign 1 232 1023
new 0 232 1023
assign 1 232 1024
add 1 232 1024
assign 1 232 1025
heldGet 0 232 1025
assign 1 232 1026
literalValueGet 0 232 1026
assign 1 232 1027
add 1 232 1027
assign 1 232 1028
new 0 232 1028
assign 1 232 1029
add 1 232 1029
assign 1 234 1032
new 0 234 1032
assign 1 234 1033
libNameGet 0 234 1033
assign 1 234 1034
relEmitName 1 234 1034
assign 1 234 1035
add 1 234 1035
assign 1 234 1036
new 0 234 1036
assign 1 234 1037
add 1 234 1037
assign 1 234 1038
libNameGet 0 234 1038
assign 1 234 1039
relEmitName 1 234 1039
assign 1 234 1040
add 1 234 1040
assign 1 234 1041
new 0 234 1041
assign 1 234 1042
add 1 234 1042
assign 1 234 1043
heldGet 0 234 1043
assign 1 234 1044
literalValueGet 0 234 1044
assign 1 234 1045
add 1 234 1045
assign 1 234 1046
new 0 234 1046
assign 1 234 1047
add 1 234 1047
return 1 236 1049
assign 1 241 1098
new 0 241 1098
assign 1 241 1099
libNameGet 0 241 1099
assign 1 241 1100
relEmitName 1 241 1100
assign 1 241 1101
add 1 241 1101
assign 1 241 1102
new 0 241 1102
assign 1 241 1103
add 1 241 1103
assign 1 241 1104
heldGet 0 241 1104
assign 1 241 1105
literalValueGet 0 241 1105
assign 1 241 1106
add 1 241 1106
assign 1 241 1107
new 0 241 1107
assign 1 241 1108
add 1 241 1108
return 1 241 1109
assign 1 243 1111
emitChecksGet 0 243 1111
assign 1 243 1112
new 0 243 1112
assign 1 243 1113
has 1 243 1113
assign 1 244 1115
new 0 244 1115
assign 1 244 1116
libNameGet 0 244 1116
assign 1 244 1117
relEmitName 1 244 1117
assign 1 244 1118
add 1 244 1118
assign 1 244 1119
new 0 244 1119
assign 1 244 1120
add 1 244 1120
assign 1 244 1121
libNameGet 0 244 1121
assign 1 244 1122
relEmitName 1 244 1122
assign 1 244 1123
add 1 244 1123
assign 1 244 1124
new 0 244 1124
assign 1 244 1125
add 1 244 1125
assign 1 244 1126
heldGet 0 244 1126
assign 1 244 1127
literalValueGet 0 244 1127
assign 1 244 1128
add 1 244 1128
assign 1 244 1129
new 0 244 1129
assign 1 244 1130
add 1 244 1130
assign 1 246 1133
new 0 246 1133
assign 1 246 1134
libNameGet 0 246 1134
assign 1 246 1135
relEmitName 1 246 1135
assign 1 246 1136
add 1 246 1136
assign 1 246 1137
new 0 246 1137
assign 1 246 1138
add 1 246 1138
assign 1 246 1139
libNameGet 0 246 1139
assign 1 246 1140
relEmitName 1 246 1140
assign 1 246 1141
add 1 246 1141
assign 1 246 1142
new 0 246 1142
assign 1 246 1143
add 1 246 1143
assign 1 246 1144
heldGet 0 246 1144
assign 1 246 1145
literalValueGet 0 246 1145
assign 1 246 1146
add 1 246 1146
assign 1 246 1147
new 0 246 1147
assign 1 246 1148
add 1 246 1148
return 1 248 1150
assign 1 253 1201
new 0 253 1201
assign 1 253 1202
libNameGet 0 253 1202
assign 1 253 1203
relEmitName 1 253 1203
assign 1 253 1204
add 1 253 1204
assign 1 253 1205
new 0 253 1205
assign 1 253 1206
add 1 253 1206
assign 1 253 1207
add 1 253 1207
assign 1 253 1208
new 0 253 1208
assign 1 253 1209
add 1 253 1209
assign 1 253 1210
add 1 253 1210
assign 1 253 1211
new 0 253 1211
assign 1 253 1212
add 1 253 1212
return 1 253 1213
assign 1 256 1215
new 0 256 1215
assign 1 256 1216
add 1 256 1216
assign 1 256 1217
new 0 256 1217
assign 1 256 1218
add 1 256 1218
assign 1 256 1219
add 1 256 1219
assign 1 257 1220
emitChecksGet 0 257 1220
assign 1 257 1221
new 0 257 1221
assign 1 257 1222
has 1 257 1222
assign 1 258 1224
new 0 258 1224
assign 1 258 1225
libNameGet 0 258 1225
assign 1 258 1226
relEmitName 1 258 1226
assign 1 258 1227
add 1 258 1227
assign 1 258 1228
new 0 258 1228
assign 1 258 1229
add 1 258 1229
assign 1 258 1230
libNameGet 0 258 1230
assign 1 258 1231
relEmitName 1 258 1231
assign 1 258 1232
add 1 258 1232
assign 1 258 1233
new 0 258 1233
assign 1 258 1234
add 1 258 1234
assign 1 258 1235
add 1 258 1235
assign 1 258 1236
new 0 258 1236
assign 1 258 1237
add 1 258 1237
assign 1 260 1240
new 0 260 1240
assign 1 260 1241
libNameGet 0 260 1241
assign 1 260 1242
relEmitName 1 260 1242
assign 1 260 1243
add 1 260 1243
assign 1 260 1244
new 0 260 1244
assign 1 260 1245
add 1 260 1245
assign 1 260 1246
libNameGet 0 260 1246
assign 1 260 1247
relEmitName 1 260 1247
assign 1 260 1248
add 1 260 1248
assign 1 260 1249
new 0 260 1249
assign 1 260 1250
add 1 260 1250
assign 1 260 1251
add 1 260 1251
assign 1 260 1252
new 0 260 1252
assign 1 260 1253
add 1 260 1253
return 1 262 1255
incrementValue 0 266 1267
assign 1 267 1268
new 0 267 1268
assign 1 267 1269
notEmpty 1 267 1269
assign 1 268 1271
new 0 268 1271
addValue 1 268 1272
assign 1 270 1274
new 0 270 1274
assign 1 270 1275
addValue 1 270 1275
addValue 1 270 1276
assign 1 271 1277
new 0 271 1277
assign 1 271 1278
add 1 271 1278
assign 1 271 1279
new 0 271 1279
assign 1 271 1280
add 1 271 1280
return 1 271 1281
getCode 2 276 1287
assign 1 277 1288
toHexString 1 277 1288
assign 1 278 1289
new 0 278 1289
assign 1 278 1290
once 0 278 1290
addValue 1 278 1291
addValue 1 279 1292
assign 1 285 1299
new 0 285 1299
assign 1 285 1300
add 1 285 1300
assign 1 285 1301
add 1 285 1301
return 1 285 1302
assign 1 289 1306
new 0 289 1306
return 1 289 1307
assign 1 293 1311
new 0 293 1311
return 1 293 1312
assign 1 298 1316
new 0 298 1316
return 1 298 1317
assign 1 302 1321
new 0 302 1321
return 1 302 1322
assign 1 306 1326
new 0 306 1326
return 1 306 1327
assign 1 310 1333
new 0 310 1333
assign 1 310 1334
once 0 310 1334
assign 1 310 1335
add 1 310 1335
return 1 310 1336
assign 1 317 1352
assign 1 318 1353
singleCCGet 0 318 1353
assign 1 0 1355
assign 1 318 1358
classPathGet 0 318 1358
assign 1 318 1359
fileGet 0 318 1359
assign 1 318 1360
existsGet 0 318 1360
assign 1 318 1361
not 0 318 1366
assign 1 0 1367
assign 1 0 1370
return 1 319 1374
assign 1 321 1377
classPathGet 0 321 1377
assign 1 321 1378
fileGet 0 321 1378
assign 1 321 1379
lastUpdatedGet 0 321 1379
assign 1 322 1380
fromFileGet 0 322 1380
assign 1 322 1381
fileGet 0 322 1381
assign 1 322 1382
lastUpdatedGet 0 322 1382
assign 1 323 1383
greater 1 323 1383
return 1 326 1385
assign 1 329 1387
assign 1 334 1395
singleCCGet 0 334 1395
assign 1 335 1397
getLibOutput 0 335 1397
return 1 335 1398
assign 1 337 1400
getClassOutput 0 337 1400
return 1 337 1401
assign 1 341 1407
singleCCGet 0 341 1407
assign 1 342 1409
new 0 342 1409
assign 1 343 1410
countLines 1 343 1410
addValue 1 343 1411
write 1 344 1412
assign 1 349 1423
singleCCGet 0 349 1423
assign 1 351 1425
new 0 351 1425
assign 1 352 1426
countLines 1 352 1426
addValue 1 352 1427
write 1 353 1428
close 0 354 1429
assign 1 355 1430
def 1 355 1435
assign 1 356 1436
pathGet 0 356 1436
assign 1 356 1437
fileGet 0 356 1437
lastUpdatedSet 1 356 1438
assign 1 357 1439
assign 1 363 1462
new 0 363 1462
assign 1 364 1463
emitChecksGet 0 364 1463
assign 1 364 1464
new 0 364 1464
assign 1 364 1465
has 1 364 1465
assign 1 365 1467
new 0 365 1467
assign 1 365 1468
addValue 1 365 1468
assign 1 365 1469
addValue 1 365 1469
assign 1 365 1470
new 0 365 1470
assign 1 365 1471
addValue 1 365 1471
assign 1 365 1472
addValue 1 365 1472
assign 1 365 1473
new 0 365 1473
assign 1 365 1474
addValue 1 365 1474
addValue 1 365 1475
assign 1 366 1476
addValue 1 366 1476
assign 1 366 1477
new 0 366 1477
assign 1 366 1478
addValue 1 366 1478
addValue 1 366 1479
assign 1 367 1480
new 0 367 1480
assign 1 367 1481
addValue 1 367 1481
addValue 1 367 1482
return 1 369 1484
assign 1 373 1598
new 0 373 1598
assign 1 373 1599
typeEmitNameGet 0 373 1599
assign 1 373 1600
add 1 373 1600
assign 1 373 1601
new 0 373 1601
assign 1 373 1602
add 1 373 1602
write 1 373 1603
assign 1 374 1604
new 0 374 1604
assign 1 375 1605
new 0 375 1605
assign 1 375 1606
addValue 1 375 1606
assign 1 375 1607
typeEmitNameGet 0 375 1607
assign 1 375 1608
addValue 1 375 1608
assign 1 375 1609
new 0 375 1609
addValue 1 375 1610
assign 1 376 1611
new 0 376 1611
addValue 1 376 1612
assign 1 377 1613
typeEmitNameGet 0 377 1613
assign 1 377 1614
addValue 1 377 1614
assign 1 377 1615
new 0 377 1615
addValue 1 377 1616
assign 1 378 1617
new 0 378 1617
addValue 1 378 1618
assign 1 379 1619
new 0 379 1619
addValue 1 379 1620
assign 1 380 1621
new 0 380 1621
assign 1 380 1622
addValue 1 380 1622
assign 1 380 1623
addValue 1 380 1623
assign 1 380 1624
new 0 380 1624
addValue 1 380 1625
assign 1 381 1626
new 0 381 1626
addValue 1 381 1627
assign 1 382 1628
new 0 382 1628
addValue 1 382 1629
assign 1 383 1630
new 0 383 1630
addValue 1 383 1631
write 1 384 1632
assign 1 386 1633
new 0 386 1633
assign 1 387 1634
typeEmitNameGet 0 387 1634
assign 1 387 1635
addValue 1 387 1635
assign 1 387 1636
new 0 387 1636
assign 1 387 1637
addValue 1 387 1637
assign 1 387 1638
typeEmitNameGet 0 387 1638
assign 1 387 1639
addValue 1 387 1639
assign 1 387 1640
new 0 387 1640
addValue 1 387 1641
assign 1 388 1642
new 0 388 1642
addValue 1 388 1643
assign 1 389 1644
new 0 389 1644
assign 1 390 1645
mtdListGet 0 390 1645
assign 1 390 1646
iteratorGet 0 0 1646
assign 1 390 1649
hasNextGet 0 390 1649
assign 1 390 1651
nextGet 0 390 1651
assign 1 392 1653
new 0 392 1653
assign 1 394 1656
new 0 394 1656
addValue 1 394 1657
assign 1 396 1659
addValue 1 396 1659
assign 1 396 1660
nameGet 0 396 1660
assign 1 396 1661
addValue 1 396 1661
addValue 1 396 1662
assign 1 398 1668
new 0 398 1668
addValue 1 398 1669
assign 1 399 1670
new 0 399 1670
addValue 1 399 1671
assign 1 401 1672
new 0 401 1672
addValue 1 401 1673
assign 1 402 1674
new 0 402 1674
assign 1 403 1675
ptyListGet 0 403 1675
assign 1 403 1676
iteratorGet 0 0 1676
assign 1 403 1679
hasNextGet 0 403 1679
assign 1 403 1681
nextGet 0 403 1681
assign 1 405 1683
new 0 405 1683
assign 1 407 1686
new 0 407 1686
addValue 1 407 1687
assign 1 409 1689
addValue 1 409 1689
assign 1 409 1690
nameGet 0 409 1690
assign 1 409 1691
addValue 1 409 1691
addValue 1 409 1692
assign 1 411 1698
new 0 411 1698
addValue 1 411 1699
assign 1 413 1700
new 0 413 1700
addValue 1 413 1701
assign 1 415 1702
new 0 415 1702
assign 1 415 1703
addValue 1 415 1703
assign 1 415 1704
typeEmitNameGet 0 415 1704
assign 1 415 1705
addValue 1 415 1705
assign 1 415 1706
new 0 415 1706
addValue 1 415 1707
assign 1 416 1708
emitNameGet 0 416 1708
assign 1 416 1709
new 0 416 1709
assign 1 416 1710
equals 1 416 1710
assign 1 417 1712
new 0 417 1712
assign 1 417 1713
addValue 1 417 1713
assign 1 417 1714
emitNameGet 0 417 1714
assign 1 417 1715
addValue 1 417 1715
assign 1 417 1716
new 0 417 1716
addValue 1 417 1717
assign 1 419 1720
new 0 419 1720
assign 1 419 1721
addValue 1 419 1721
assign 1 419 1722
emitNameGet 0 419 1722
assign 1 419 1723
addValue 1 419 1723
assign 1 419 1724
new 0 419 1724
addValue 1 419 1725
assign 1 421 1727
new 0 421 1727
addValue 1 421 1728
assign 1 423 1729
new 0 423 1729
assign 1 423 1730
addValue 1 423 1730
assign 1 423 1731
typeEmitNameGet 0 423 1731
assign 1 423 1732
addValue 1 423 1732
assign 1 423 1733
new 0 423 1733
addValue 1 423 1734
assign 1 424 1735
new 0 424 1735
addValue 1 424 1736
assign 1 425 1737
new 0 425 1737
assign 1 425 1738
genMark 1 425 1738
addValue 1 425 1739
assign 1 426 1740
new 0 426 1740
addValue 1 426 1741
assign 1 427 1742
new 0 427 1742
addValue 1 427 1743
assign 1 428 1744
new 0 428 1744
assign 1 428 1745
genMark 1 428 1745
addValue 1 428 1746
assign 1 429 1747
new 0 429 1747
addValue 1 429 1748
assign 1 430 1749
new 0 430 1749
addValue 1 430 1750
assign 1 432 1751
new 0 432 1751
assign 1 432 1752
addValue 1 432 1752
assign 1 432 1753
typeEmitNameGet 0 432 1753
assign 1 432 1754
addValue 1 432 1754
assign 1 432 1755
new 0 432 1755
assign 1 432 1756
addValue 1 432 1756
assign 1 432 1757
addValue 1 432 1757
assign 1 432 1758
new 0 432 1758
assign 1 432 1759
addValue 1 432 1759
assign 1 432 1760
addValue 1 432 1760
assign 1 432 1761
new 0 432 1761
assign 1 432 1762
addValue 1 432 1762
addValue 1 432 1763
assign 1 433 1764
new 0 433 1764
assign 1 433 1765
addValue 1 433 1765
assign 1 433 1766
typeEmitNameGet 0 433 1766
assign 1 433 1767
addValue 1 433 1767
assign 1 433 1768
new 0 433 1768
assign 1 433 1769
addValue 1 433 1769
assign 1 433 1770
addValue 1 433 1770
assign 1 433 1771
new 0 433 1771
addValue 1 433 1772
clear 0 434 1773
assign 1 435 1774
new 0 435 1774
assign 1 437 1775
getClassOutput 0 437 1775
write 1 437 1776
assign 1 438 1777
countLines 1 438 1777
addValue 1 438 1778
assign 1 450 1851
undef 1 450 1856
assign 1 451 1857
libNameGet 0 451 1857
assign 1 452 1858
new 0 452 1858
assign 1 452 1859
sizeGet 0 452 1859
assign 1 452 1860
add 1 452 1860
assign 1 452 1861
new 0 452 1861
assign 1 452 1862
add 1 452 1862
assign 1 452 1863
add 1 452 1863
assign 1 452 1864
add 1 452 1864
assign 1 453 1865
new 0 453 1865
assign 1 453 1866
sizeGet 0 453 1866
assign 1 453 1867
add 1 453 1867
assign 1 453 1868
new 0 453 1868
assign 1 453 1869
add 1 453 1869
assign 1 453 1870
add 1 453 1870
assign 1 453 1871
add 1 453 1871
assign 1 454 1872
parentGet 0 454 1872
assign 1 454 1873
addStep 1 454 1873
assign 1 455 1874
parentGet 0 455 1874
assign 1 455 1875
addStep 1 455 1875
assign 1 456 1876
parentGet 0 456 1876
assign 1 456 1877
fileGet 0 456 1877
assign 1 456 1878
existsGet 0 456 1878
assign 1 456 1879
not 0 456 1884
assign 1 457 1885
parentGet 0 457 1885
assign 1 457 1886
fileGet 0 457 1886
makeDirs 0 457 1887
assign 1 459 1889
fileGet 0 459 1889
assign 1 459 1890
writerGet 0 459 1890
assign 1 459 1891
open 0 459 1891
assign 1 460 1892
fileGet 0 460 1892
assign 1 460 1893
writerGet 0 460 1893
assign 1 460 1894
open 0 460 1894
assign 1 462 1895
paramsGet 0 462 1895
assign 1 462 1896
new 0 462 1896
assign 1 462 1897
has 1 462 1897
assign 1 464 1899
paramsGet 0 464 1899
assign 1 464 1900
new 0 464 1900
assign 1 464 1901
get 1 464 1901
assign 1 464 1902
iteratorGet 0 0 1902
assign 1 464 1905
hasNextGet 0 464 1905
assign 1 464 1907
nextGet 0 464 1907
assign 1 466 1908
apNew 1 466 1908
assign 1 466 1909
fileGet 0 466 1909
assign 1 467 1910
readerGet 0 467 1910
assign 1 467 1911
open 0 467 1911
assign 1 467 1912
readString 0 467 1912
assign 1 468 1913
readerGet 0 468 1913
close 0 468 1914
write 1 470 1915
assign 1 474 1922
new 0 474 1922
write 1 474 1923
assign 1 475 1924
new 0 475 1924
write 1 475 1925
assign 1 477 1926
new 0 477 1926
write 1 477 1927
assign 1 478 1928
new 0 478 1928
write 1 478 1929
assign 1 484 1930
paramsGet 0 484 1930
assign 1 484 1931
new 0 484 1931
assign 1 484 1932
has 1 484 1932
assign 1 486 1934
paramsGet 0 486 1934
assign 1 486 1935
new 0 486 1935
assign 1 486 1936
get 1 486 1936
assign 1 486 1937
iteratorGet 0 0 1937
assign 1 486 1940
hasNextGet 0 486 1940
assign 1 486 1942
nextGet 0 486 1942
assign 1 488 1943
apNew 1 488 1943
assign 1 488 1944
fileGet 0 488 1944
assign 1 489 1945
readerGet 0 489 1945
assign 1 489 1946
open 0 489 1946
assign 1 489 1947
readString 0 489 1947
assign 1 490 1948
readerGet 0 490 1948
close 0 490 1949
write 1 492 1950
assign 1 495 1957
paramsGet 0 495 1957
assign 1 495 1958
new 0 495 1958
assign 1 495 1959
has 1 495 1959
assign 1 497 1961
paramsGet 0 497 1961
assign 1 497 1962
new 0 497 1962
assign 1 497 1963
get 1 497 1963
assign 1 497 1964
iteratorGet 0 0 1964
assign 1 497 1967
hasNextGet 0 497 1967
assign 1 497 1969
nextGet 0 497 1969
assign 1 499 1970
apNew 1 499 1970
assign 1 499 1971
fileGet 0 499 1971
assign 1 500 1972
readerGet 0 500 1972
assign 1 500 1973
open 0 500 1973
assign 1 500 1974
readString 0 500 1974
assign 1 501 1975
readerGet 0 501 1975
close 0 501 1976
write 1 503 1977
begin 1 510 1988
prepHeaderOutput 0 511 1989
assign 1 516 2032
undef 1 516 2037
assign 1 517 2038
new 0 517 2038
assign 1 518 2039
parentGet 0 518 2039
assign 1 518 2040
fileGet 0 518 2040
assign 1 518 2041
existsGet 0 518 2041
assign 1 518 2042
not 0 518 2047
assign 1 519 2048
parentGet 0 519 2048
assign 1 519 2049
fileGet 0 519 2049
makeDirs 0 519 2050
assign 1 521 2052
fileGet 0 521 2052
assign 1 521 2053
writerGet 0 521 2053
assign 1 521 2054
open 0 521 2054
assign 1 523 2055
new 0 523 2055
write 1 523 2056
assign 1 525 2057
paramsGet 0 525 2057
assign 1 525 2058
new 0 525 2058
assign 1 525 2059
has 1 525 2059
assign 1 527 2061
paramsGet 0 527 2061
assign 1 527 2062
new 0 527 2062
assign 1 527 2063
get 1 527 2063
assign 1 527 2064
iteratorGet 0 0 2064
assign 1 527 2067
hasNextGet 0 527 2067
assign 1 527 2069
nextGet 0 527 2069
assign 1 529 2070
apNew 1 529 2070
assign 1 529 2071
fileGet 0 529 2071
assign 1 530 2072
readerGet 0 530 2072
assign 1 530 2073
open 0 530 2073
assign 1 530 2074
readString 0 530 2074
assign 1 531 2075
readerGet 0 531 2075
close 0 531 2076
write 1 533 2077
assign 1 537 2084
new 0 537 2084
write 1 537 2085
increment 0 538 2086
assign 1 539 2087
paramsGet 0 539 2087
assign 1 539 2088
new 0 539 2088
assign 1 539 2089
has 1 539 2089
assign 1 540 2091
paramsGet 0 540 2091
assign 1 540 2092
new 0 540 2092
assign 1 540 2093
get 1 540 2093
assign 1 540 2094
iteratorGet 0 0 2094
assign 1 540 2097
hasNextGet 0 540 2097
assign 1 540 2099
nextGet 0 540 2099
assign 1 541 2100
apNew 1 541 2100
assign 1 541 2101
fileGet 0 541 2101
assign 1 542 2102
readerGet 0 542 2102
assign 1 542 2103
open 0 542 2103
assign 1 542 2104
readString 0 542 2104
assign 1 543 2105
readerGet 0 543 2105
close 0 543 2106
assign 1 544 2107
countLines 1 544 2107
addValue 1 544 2108
write 1 545 2109
return 1 551 2117
close 0 556 2128
assign 1 557 2129
assign 1 559 2130
new 0 559 2130
write 1 559 2131
assign 1 561 2132
new 0 561 2132
write 1 561 2133
assign 1 563 2134
emitChecksGet 0 563 2134
assign 1 563 2135
new 0 563 2135
assign 1 563 2136
has 1 563 2136
assign 1 564 2138
new 0 564 2138
assign 1 565 2139
new 0 565 2139
assign 1 565 2140
addValue 1 565 2140
addValue 1 565 2141
write 1 566 2142
close 0 569 2144
close 0 570 2145
assign 1 575 2150
new 0 575 2150
return 1 575 2151
assign 1 579 2168
emitChecksGet 0 579 2168
assign 1 579 2169
new 0 579 2169
assign 1 579 2170
has 1 579 2170
assign 1 580 2172
new 0 580 2172
assign 1 580 2173
addValue 1 580 2173
assign 1 580 2174
addValue 1 580 2174
assign 1 580 2175
new 0 580 2175
addValue 1 580 2176
assign 1 581 2179
emitChecksGet 0 581 2179
assign 1 581 2180
new 0 581 2180
assign 1 581 2181
has 1 581 2181
assign 1 582 2183
new 0 582 2183
assign 1 582 2184
addValue 1 582 2184
assign 1 582 2185
addValue 1 582 2185
assign 1 582 2186
new 0 582 2186
addValue 1 582 2187
assign 1 588 2211
heldGet 0 588 2211
assign 1 588 2212
synGet 0 588 2212
assign 1 589 2213
ptyListGet 0 589 2213
assign 1 591 2214
emitNameGet 0 591 2214
assign 1 591 2215
addValue 1 591 2215
assign 1 591 2216
new 0 591 2216
addValue 1 591 2217
assign 1 593 2218
new 0 593 2218
assign 1 594 2219
iteratorGet 0 0 2219
assign 1 594 2222
hasNextGet 0 594 2222
assign 1 594 2224
nextGet 0 594 2224
assign 1 596 2226
new 0 596 2226
assign 1 598 2229
new 0 598 2229
addValue 1 598 2230
assign 1 600 2232
addValue 1 600 2232
assign 1 600 2233
new 0 600 2233
assign 1 600 2234
addValue 1 600 2234
assign 1 600 2235
nameGet 0 600 2235
assign 1 600 2236
addValue 1 600 2236
addValue 1 600 2237
assign 1 604 2243
new 0 604 2243
assign 1 604 2244
addValue 1 604 2244
addValue 1 604 2245
assign 1 609 2265
new 0 609 2265
assign 1 611 2266
new 0 611 2266
assign 1 611 2267
emitNameGet 0 611 2267
assign 1 611 2268
add 1 611 2268
assign 1 611 2269
new 0 611 2269
assign 1 611 2270
add 1 611 2270
assign 1 613 2271
emitNameGet 0 613 2271
assign 1 613 2272
addValue 1 613 2272
assign 1 613 2273
new 0 613 2273
assign 1 613 2274
addValue 1 613 2274
assign 1 613 2275
emitNameGet 0 613 2275
assign 1 613 2276
addValue 1 613 2276
assign 1 613 2277
new 0 613 2277
assign 1 613 2278
addValue 1 613 2278
assign 1 613 2279
addValue 1 613 2279
assign 1 613 2280
new 0 613 2280
addValue 1 613 2281
return 1 615 2282
assign 1 619 2291
libNameGet 0 619 2291
assign 1 619 2292
relEmitName 1 619 2292
assign 1 620 2293
new 0 620 2293
assign 1 620 2294
add 1 620 2294
assign 1 620 2295
new 0 620 2295
assign 1 620 2296
add 1 620 2296
return 1 621 2297
assign 1 625 2309
libNameGet 0 625 2309
assign 1 625 2310
relEmitName 1 625 2310
assign 1 626 2311
new 0 626 2311
assign 1 626 2312
add 1 626 2312
assign 1 626 2313
new 0 626 2313
assign 1 626 2314
add 1 626 2314
assign 1 627 2315
new 0 627 2315
assign 1 627 2316
add 1 627 2316
assign 1 627 2317
add 1 627 2317
return 1 627 2318
assign 1 631 2323
new 0 631 2323
assign 1 631 2324
add 1 631 2324
return 1 631 2325
assign 1 635 2433
getClassConfig 1 635 2433
assign 1 635 2434
libNameGet 0 635 2434
assign 1 635 2435
relEmitName 1 635 2435
assign 1 636 2436
heldGet 0 636 2436
assign 1 636 2437
namepathGet 0 636 2437
assign 1 636 2438
getClassConfig 1 636 2438
assign 1 637 2439
getInitialInst 1 637 2439
assign 1 639 2440
overrideMtdDecGet 0 639 2440
assign 1 639 2441
addValue 1 639 2441
assign 1 639 2442
new 0 639 2442
assign 1 639 2443
addValue 1 639 2443
assign 1 639 2444
emitNameGet 0 639 2444
assign 1 639 2445
addValue 1 639 2445
assign 1 639 2446
new 0 639 2446
assign 1 639 2447
addValue 1 639 2447
assign 1 639 2448
addValue 1 639 2448
assign 1 639 2449
new 0 639 2449
assign 1 639 2450
addValue 1 639 2450
assign 1 639 2451
addValue 1 639 2451
assign 1 639 2452
new 0 639 2452
assign 1 639 2453
addValue 1 639 2453
addValue 1 639 2454
assign 1 640 2455
new 0 640 2455
assign 1 641 2456
emitNameGet 0 641 2456
assign 1 641 2457
notEquals 1 641 2457
assign 1 642 2459
new 0 642 2459
assign 1 642 2460
formCast 3 642 2460
assign 1 645 2462
addValue 1 645 2462
assign 1 645 2463
new 0 645 2463
assign 1 645 2464
addValue 1 645 2464
assign 1 645 2465
addValue 1 645 2465
assign 1 645 2466
new 0 645 2466
assign 1 645 2467
addValue 1 645 2467
addValue 1 645 2468
assign 1 647 2469
new 0 647 2469
assign 1 647 2470
addValue 1 647 2470
addValue 1 647 2471
assign 1 650 2472
overrideMtdDecGet 0 650 2472
assign 1 650 2473
addValue 1 650 2473
assign 1 650 2474
addValue 1 650 2474
assign 1 650 2475
new 0 650 2475
assign 1 650 2476
addValue 1 650 2476
assign 1 650 2477
emitNameGet 0 650 2477
assign 1 650 2478
addValue 1 650 2478
assign 1 650 2479
new 0 650 2479
assign 1 650 2480
addValue 1 650 2480
assign 1 650 2481
addValue 1 650 2481
assign 1 650 2482
new 0 650 2482
assign 1 650 2483
addValue 1 650 2483
addValue 1 650 2484
assign 1 655 2485
new 0 655 2485
assign 1 655 2486
addValue 1 655 2486
assign 1 655 2487
addValue 1 655 2487
assign 1 655 2488
new 0 655 2488
assign 1 655 2489
addValue 1 655 2489
addValue 1 655 2490
assign 1 658 2491
new 0 658 2491
assign 1 658 2492
addValue 1 658 2492
addValue 1 658 2493
assign 1 660 2494
overrideMtdDecGet 0 660 2494
assign 1 660 2495
addValue 1 660 2495
assign 1 660 2496
new 0 660 2496
assign 1 660 2497
addValue 1 660 2497
assign 1 660 2498
emitNameGet 0 660 2498
assign 1 660 2499
addValue 1 660 2499
assign 1 660 2500
new 0 660 2500
assign 1 660 2501
addValue 1 660 2501
assign 1 660 2502
addValue 1 660 2502
assign 1 660 2503
new 0 660 2503
assign 1 660 2504
addValue 1 660 2504
addValue 1 660 2505
assign 1 661 2506
heldGet 0 661 2506
assign 1 661 2507
extendsGet 0 661 2507
assign 1 661 2508
undef 1 661 2513
assign 1 0 2514
assign 1 661 2517
heldGet 0 661 2517
assign 1 661 2518
extendsGet 0 661 2518
assign 1 661 2519
equals 1 661 2519
assign 1 0 2521
assign 1 0 2524
assign 1 662 2528
new 0 662 2528
assign 1 662 2529
addValue 1 662 2529
addValue 1 662 2530
assign 1 664 2533
new 0 664 2533
assign 1 664 2534
addValue 1 664 2534
addValue 1 664 2535
addValue 1 666 2537
clear 0 667 2538
assign 1 670 2539
new 0 670 2539
assign 1 670 2540
addValue 1 670 2540
addValue 1 670 2541
assign 1 672 2542
overrideMtdDecGet 0 672 2542
assign 1 672 2543
addValue 1 672 2543
assign 1 672 2544
new 0 672 2544
assign 1 672 2545
addValue 1 672 2545
assign 1 672 2546
emitNameGet 0 672 2546
assign 1 672 2547
addValue 1 672 2547
assign 1 672 2548
new 0 672 2548
assign 1 672 2549
addValue 1 672 2549
assign 1 672 2550
addValue 1 672 2550
assign 1 672 2551
new 0 672 2551
assign 1 672 2552
addValue 1 672 2552
addValue 1 672 2553
assign 1 673 2554
new 0 673 2554
assign 1 673 2555
addValue 1 673 2555
addValue 1 673 2556
assign 1 675 2557
new 0 675 2557
assign 1 675 2558
addValue 1 675 2558
addValue 1 675 2559
assign 1 677 2560
getTypeInst 1 677 2560
assign 1 679 2561
new 0 679 2561
assign 1 679 2562
addValue 1 679 2562
assign 1 679 2563
emitNameGet 0 679 2563
assign 1 679 2564
addValue 1 679 2564
assign 1 679 2565
new 0 679 2565
assign 1 679 2566
addValue 1 679 2566
addValue 1 679 2567
assign 1 681 2568
new 0 681 2568
assign 1 681 2569
addValue 1 681 2569
assign 1 681 2570
addValue 1 681 2570
assign 1 681 2571
new 0 681 2571
assign 1 681 2572
addValue 1 681 2572
addValue 1 681 2573
assign 1 683 2574
new 0 683 2574
assign 1 683 2575
addValue 1 683 2575
addValue 1 683 2576
assign 1 689 2588
new 0 689 2588
assign 1 689 2589
add 1 689 2589
assign 1 689 2590
new 0 689 2590
assign 1 689 2591
add 1 689 2591
write 1 689 2592
assign 1 690 2593
new 0 690 2593
assign 1 690 2594
add 1 690 2594
assign 1 690 2595
new 0 690 2595
assign 1 690 2596
add 1 690 2596
write 1 690 2597
emitLib 0 692 2598
assign 1 697 2611
libNameGet 0 697 2611
assign 1 697 2612
relEmitName 1 697 2612
assign 1 698 2613
new 0 698 2613
assign 1 698 2614
add 1 698 2614
assign 1 698 2615
new 0 698 2615
assign 1 698 2616
add 1 698 2616
assign 1 699 2617
new 0 699 2617
assign 1 699 2618
add 1 699 2618
assign 1 699 2619
add 1 699 2619
return 1 699 2620
return 1 0 2623
return 1 0 2626
assign 1 0 2629
assign 1 0 2633
return 1 0 2637
return 1 0 2640
assign 1 0 2643
assign 1 0 2647
return 1 0 2651
return 1 0 2654
assign 1 0 2657
assign 1 0 2661
return 1 0 2665
return 1 0 2668
assign 1 0 2671
assign 1 0 2675
return 1 0 2679
return 1 0 2682
assign 1 0 2685
assign 1 0 2689
return 1 0 2693
return 1 0 2696
assign 1 0 2699
assign 1 0 2703
return 1 0 2707
return 1 0 2710
assign 1 0 2713
assign 1 0 2717
return 1 0 2721
return 1 0 2724
assign 1 0 2727
assign 1 0 2731
return 1 0 2735
return 1 0 2738
assign 1 0 2741
assign 1 0 2745
return 1 0 2749
return 1 0 2752
assign 1 0 2755
assign 1 0 2759
return 1 0 2763
return 1 0 2766
assign 1 0 2769
assign 1 0 2773
return 1 0 2777
return 1 0 2780
assign 1 0 2783
assign 1 0 2787
return 1 0 2791
return 1 0 2794
assign 1 0 2797
assign 1 0 2801
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 928457034: return bem_serializeContents_0();
case -125524636: return bem_trueValueGetDirect_0();
case 347302975: return bem_methodsGetDirect_0();
case 1404793640: return bem_heowGet_0();
case 8896887: return bem_emitLib_0();
case -2124948120: return bem_idToNamePathGetDirect_0();
case -154534625: return bem_propertyDecsGet_0();
case -2092760709: return bem_once_0();
case -2019897330: return bem_maxDynArgsGetDirect_0();
case 328737182: return bem_ccMethodsGet_0();
case -1376265700: return bem_ccCacheGet_0();
case 594637567: return bem_nameToIdPathGetDirect_0();
case 105255020: return bem_endNs_0();
case -1303987182: return bem_methodBodyGet_0();
case 1632896250: return bem_libEmitNameGetDirect_0();
case -1237796461: return bem_floatNpGet_0();
case -842207018: return bem_iteratorGet_0();
case -612656985: return bem_ccMethodsGetDirect_0();
case 1904373316: return bem_propertyDecsGetDirect_0();
case -25708308: return bem_heopGetDirect_0();
case -1257851297: return bem_classEmitsGetDirect_0();
case -792061706: return bem_callNamesGetDirect_0();
case -1127978038: return bem_baseMtdDecGet_0();
case 1372644764: return bem_hashGet_0();
case 108102557: return bem_buildGetDirect_0();
case 864393987: return bem_tagGet_0();
case -1406862989: return bem_objectNpGetDirect_0();
case -121392599: return bem_libEmitNameGet_0();
case 719416320: return bem_dynMethodsGetDirect_0();
case 1101301306: return bem_classCallsGetDirect_0();
case -624034502: return bem_onceDecRefsCountGetDirect_0();
case 542757790: return bem_boolTypeGet_0();
case -115989431: return bem_inClassGetDirect_0();
case 1959303394: return bem_mnodeGet_0();
case 1772750247: return bem_onceCountGetDirect_0();
case 720605991: return bem_instanceNotEqualGet_0();
case -1523845400: return bem_dynMethodsGet_0();
case -697367643: return bem_getLibOutput_0();
case -1852877275: return bem_new_0();
case 246857431: return bem_onceDecRefsGet_0();
case -1587280835: return bem_boolCcGetDirect_0();
case -2146062281: return bem_inFilePathedGet_0();
case -358025207: return bem_loadIds_0();
case -236887613: return bem_classNameGet_0();
case 1458282518: return bem_deonGet_0();
case -330630087: return bem_propDecGet_0();
case 1762117364: return bem_lastMethodBodyLinesGetDirect_0();
case -935219004: return bem_headExtGet_0();
case 729042411: return bem_ccCacheGetDirect_0();
case -149693501: return bem_idToNamePathGet_0();
case 1083526105: return bem_falseValueGetDirect_0();
case 568312566: return bem_methodCallsGetDirect_0();
case 746102407: return bem_instOfGet_0();
case -935142269: return bem_inClassGet_0();
case -413504769: return bem_lastMethodsSizeGetDirect_0();
case 206517704: return bem_instanceNotEqualGetDirect_0();
case -1719324678: return bem_buildInitial_0();
case -1013325988: return bem_smnlecsGetDirect_0();
case -473973046: return bem_methodBodyGetDirect_0();
case -1318034253: return bem_returnTypeGet_0();
case -1360044135: return bem_writeBET_0();
case 237248432: return bem_onceDecsGet_0();
case -1503172150: return bem_classEmitsGet_0();
case 513195392: return bem_synEmitPathGet_0();
case 493050059: return bem_nameToIdGet_0();
case -459694510: return bem_maxSpillArgsLenGet_0();
case 1303216922: return bem_prepHeaderOutput_0();
case 251809488: return bem_nameToIdPathGet_0();
case 1241985807: return bem_lastMethodsLinesGet_0();
case 1217147975: return bem_nativeCSlotsGet_0();
case -194064343: return bem_mainEndGet_0();
case -23390772: return bem_floatNpGetDirect_0();
case -766421348: return bem_cnodeGet_0();
case 379846963: return bem_heopGet_0();
case -418366255: return bem_maxSpillArgsLenGetDirect_0();
case -1082955259: return bem_preClassOutput_0();
case -1153104759: return bem_methodCatchGetDirect_0();
case -2144558196: return bem_csynGet_0();
case 889222919: return bem_onceCountGet_0();
case 2003290617: return bem_runtimeInitGet_0();
case -309697524: return bem_libEmitPathGetDirect_0();
case 756781626: return bem_newDecGet_0();
case -464061736: return bem_ntypesGetDirect_0();
case 38519833: return bem_heonGetDirect_0();
case 406173825: return bem_transGet_0();
case -323661464: return bem_serializeToString_0();
case -2131693464: return bem_belslitsGet_0();
case -958451534: return bem_nlGet_0();
case 1332706034: return bem_smnlecsGet_0();
case -1234395424: return bem_preClassGet_0();
case 19237238: return bem_fullLibEmitNameGetDirect_0();
case 197246584: return bem_idToNameGetDirect_0();
case 1587224391: return bem_transGetDirect_0();
case -242748600: return bem_doEmit_0();
case -369327771: return bem_deopGet_0();
case 437793387: return bem_classHeadersGet_0();
case 1956892328: return bem_classesInDepthOrderGetDirect_0();
case -1447984583: return bem_deonGetDirect_0();
case 110735570: return bem_returnTypeGetDirect_0();
case -358783907: return bem_typeDecGet_0();
case -400027824: return bem_fileExtGetDirect_0();
case -718262525: return bem_stringNpGetDirect_0();
case -2141866060: return bem_gcMarksGetDirect_0();
case 1602807836: return bem_superCallsGetDirect_0();
case -777234183: return bem_heowGetDirect_0();
case 2070872321: return bem_onceDecRefsGetDirect_0();
case -2043449555: return bem_belslitsGetDirect_0();
case -615551128: return bem_methodsGet_0();
case -878568774: return bem_intNpGetDirect_0();
case -1642983427: return bem_falseValueGet_0();
case 866152174: return bem_stringNpGet_0();
case 1998217747: return bem_constGet_0();
case -1179760370: return bem_covariantReturnsGet_0();
case 1997175524: return bem_mainInClassGet_0();
case -483843588: return bem_gcMarksGet_0();
case 78334972: return bem_preClassGetDirect_0();
case -659151350: return bem_afterCast_0();
case -1369483363: return bem_fieldNamesGet_0();
case -1980635940: return bem_exceptDecGetDirect_0();
case -359634505: return bem_deowGetDirect_0();
case 1133949906: return bem_setOutputTimeGetDirect_0();
case -483998687: return bem_invpGetDirect_0();
case 709473305: return bem_deowGet_0();
case -1163840990: return bem_lastMethodBodySizeGet_0();
case -1654552861: return bem_msynGetDirect_0();
case 2048527497: return bem_buildClassInfo_0();
case -1324555499: return bem_classConfGet_0();
case -604212258: return bem_inFilePathedGetDirect_0();
case 1469097267: return bem_onceDecsGetDirect_0();
case -170941628: return bem_nativeCSlotsGetDirect_0();
case -112726755: return bem_callNamesGet_0();
case 447174096: return bem_saveSyns_0();
case -805378630: return bem_classEndGet_0();
case -457387997: return bem_lineCountGetDirect_0();
case -1495186160: return bem_maxDynArgsGet_0();
case 1390552893: return bem_invpGet_0();
case 747166857: return bem_fileExtGet_0();
case 438154477: return bem_lastMethodsLinesGetDirect_0();
case 274871933: return bem_objectNpGet_0();
case -1469438108: return bem_parentConfGet_0();
case -1166217280: return bem_getClassOutput_0();
case -704475466: return bem_heonGet_0();
case -1129392639: return bem_qGetDirect_0();
case -1556646105: return bem_objectCcGet_0();
case -727732299: return bem_onceDecRefsCountGet_0();
case -1878228619: return bem_classHeadBodyGetDirect_0();
case 1359360249: return bem_echo_0();
case -945243357: return bem_libEmitPathGet_0();
case -1430066973: return bem_print_0();
case -2093692014: return bem_nlGetDirect_0();
case 105074959: return bem_nullValueGetDirect_0();
case 849387251: return bem_toAny_0();
case 1211773133: return bem_spropDecGet_0();
case -11008638: return bem_buildGet_0();
case -1013237770: return bem_synEmitPathGetDirect_0();
case 1703080589: return bem_methodCallsGet_0();
case 1095008762: return bem_smnlcsGetDirect_0();
case 1523041979: return bem_lastMethodBodyLinesGet_0();
case 767554897: return bem_idToNameGet_0();
case -1321677625: return bem_instOfGetDirect_0();
case -1831288423: return bem_lastCallGet_0();
case -898522649: return bem_msynGet_0();
case 2070502838: return bem_copy_0();
case 1688433670: return bem_objectCcGetDirect_0();
case 2066980023: return bem_deopGetDirect_0();
case -355490341: return bem_csynGetDirect_0();
case -1733665536: return bem_nullValueGet_0();
case 1406913158: return bem_headExtGetDirect_0();
case -1466971571: return bem_smnlcsGet_0();
case -599048812: return bem_emitLangGet_0();
case 1064677251: return bem_many_0();
case 1076647192: return bem_create_0();
case -1523626920: return bem_buildCreate_0();
case 2116313447: return bem_fullLibEmitNameGet_0();
case -477961898: return bem_superCallsGet_0();
case -197125980: return bem_intNpGet_0();
case -917153037: return bem_mnodeGetDirect_0();
case 528681379: return bem_initialDecGet_0();
case 1283855332: return bem_saveIds_0();
case 122012304: return bem_exceptDecGet_0();
case -625690319: return bem_boolNpGet_0();
case 1057952466: return bem_mainOutsideNsGet_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -751021546: return bem_emitLangGetDirect_0();
case -344994104: return bem_nameToIdGetDirect_0();
case 1230859494: return bem_baseSmtdDecGet_0();
case -1045979493: return bem_lastCallGetDirect_0();
case 1000052293: return bem_shlibeGetDirect_0();
case 75076650: return bem_setOutputTimeGet_0();
case -440973066: return bem_classCallsGet_0();
case 1530844557: return bem_randGetDirect_0();
case -1137979748: return bem_boolCcGet_0();
case -2033658389: return bem_cnodeGetDirect_0();
case 1193129232: return bem_lastMethodsSizeGet_0();
case 1037110303: return bem_boolNpGetDirect_0();
case -761459611: return bem_methodCatchGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case -944560558: return bem_buildPropList_0();
case 624288951: return bem_beginNs_0();
case -1611952469: return bem_superNameGet_0();
case -105260941: return bem_scvpGetDirect_0();
case 2032023655: return bem_shlibeGet_0();
case 1916077436: return bem_classHeadBodyGet_0();
case 1466941053: return bem_scvpGet_0();
case 1549038999: return bem_mainStartGet_0();
case 354924131: return bem_classHeadersGetDirect_0();
case -1012327793: return bem_instanceEqualGetDirect_0();
case 996718380: return bem_toString_0();
case -752215908: return bem_parentConfGetDirect_0();
case -918936873: return bem_useDynMethodsGet_0();
case -308422861: return bem_ntypesGet_0();
case -837718502: return bem_overrideMtdDecGet_0();
case -1482576615: return bem_lineCountGet_0();
case 874226959: return bem_constGetDirect_0();
case 404513897: return bem_lastMethodBodySizeGetDirect_0();
case 1423913538: return bem_randGet_0();
case 605836827: return bem_sourceFileNameGet_0();
case 1078156339: return bem_trueValueGet_0();
case 611032821: return bem_classConfGetDirect_0();
case -1096178781: return bem_classesInDepthOrderGet_0();
case -1367565265: return bem_instanceEqualGet_0();
case 1418382979: return bem_qGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2093159546: return bem_lineCountSetDirect_1(bevd_0);
case -1759404254: return bem_classConfSet_1(bevd_0);
case 1798179660: return bem_cnodeSetDirect_1(bevd_0);
case 129091253: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -541620175: return bem_instanceNotEqualSet_1(bevd_0);
case 716468183: return bem_objectNpSetDirect_1(bevd_0);
case -2003929528: return bem_randSet_1(bevd_0);
case 766062035: return bem_classHeadBodySetDirect_1(bevd_0);
case -1833873139: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1151345369: return bem_cnodeSet_1(bevd_0);
case 600603910: return bem_smnlecsSetDirect_1(bevd_0);
case -882719021: return bem_qSet_1(bevd_0);
case -1318519422: return bem_returnTypeSetDirect_1(bevd_0);
case 87196635: return bem_deopSet_1(bevd_0);
case 485531858: return bem_ccCacheSet_1(bevd_0);
case -375669347: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1320996402: return bem_preClassSet_1(bevd_0);
case -244151254: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case -663200006: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 397175289: return bem_classesInDepthOrderSet_1(bevd_0);
case 1223948856: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 830966729: return bem_objectNpSet_1(bevd_0);
case 163013157: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -130988432: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1715575939: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1784248642: return bem_onceDecsSetDirect_1(bevd_0);
case -745810773: return bem_methodBodySet_1(bevd_0);
case -1504042722: return bem_setOutputTimeSetDirect_1(bevd_0);
case 1251968409: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1632478803: return bem_ccCacheSetDirect_1(bevd_0);
case -1855679040: return bem_superCallsSetDirect_1(bevd_0);
case 994472454: return bem_heopSet_1(bevd_0);
case -1715607270: return bem_idToNamePathSet_1(bevd_0);
case 831416193: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -883954848: return bem_libEmitNameSetDirect_1(bevd_0);
case 1200621550: return bem_onceCountSet_1(bevd_0);
case -1672483365: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1451891079: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1084102046: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1262206781: return bem_inClassSet_1(bevd_0);
case -446663451: return bem_inFilePathedSet_1(bevd_0);
case 778191497: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 709026002: return bem_randSetDirect_1(bevd_0);
case -1061847705: return bem_scvpSetDirect_1(bevd_0);
case -96343748: return bem_onceDecRefsCountSet_1(bevd_0);
case 1588026259: return bem_transSet_1(bevd_0);
case -1725777167: return bem_classEmitsSet_1(bevd_0);
case -2027776037: return bem_classConfSetDirect_1(bevd_0);
case -486905268: return bem_mnodeSetDirect_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case 919966779: return bem_nameToIdPathSet_1(bevd_0);
case -1051715753: return bem_qSetDirect_1(bevd_0);
case 1955884120: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -932463615: return bem_end_1(bevd_0);
case -373605190: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1789802068: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1875763038: return bem_lineCountSet_1(bevd_0);
case -165372393: return bem_methodCatchSet_1(bevd_0);
case -1365381661: return bem_emitLangSet_1(bevd_0);
case -861744627: return bem_classCallsSetDirect_1(bevd_0);
case -1215290057: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case 1255375634: return bem_instOfSet_1(bevd_0);
case -246579278: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1881596575: return bem_classHeadersSetDirect_1(bevd_0);
case -1161198028: return bem_deonSetDirect_1(bevd_0);
case -794825249: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -893956741: return bem_boolNpSet_1(bevd_0);
case 467714536: return bem_boolCcSetDirect_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 452185681: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 932813340: return bem_falseValueSetDirect_1(bevd_0);
case -261197521: return bem_preClassSetDirect_1(bevd_0);
case 280482386: return bem_callNamesSet_1(bevd_0);
case 202151827: return bem_instanceEqualSetDirect_1(bevd_0);
case 1180738980: return bem_heowSetDirect_1(bevd_0);
case 444493310: return bem_libEmitPathSetDirect_1(bevd_0);
case 716282878: return bem_constSet_1(bevd_0);
case 1783950494: return bem_nullValueSet_1(bevd_0);
case -1983523746: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1761009834: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 478028121: return bem_libEmitPathSet_1(bevd_0);
case -1579648363: return bem_buildSet_1(bevd_0);
case 1066958558: return bem_smnlcsSetDirect_1(bevd_0);
case 1839140886: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -2056825925: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -964557971: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1359973316: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 116509435: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -960159496: return bem_otherClass_1(bevd_0);
case -518744023: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1293621630: return bem_methodBodySetDirect_1(bevd_0);
case 405281625: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 860535262: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2099500845: return bem_methodCatchSetDirect_1(bevd_0);
case -48797702: return bem_shlibeSetDirect_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 661373943: return bem_fullLibEmitNameSet_1(bevd_0);
case 1481902274: return bem_ntypesSetDirect_1(bevd_0);
case -8574927: return bem_classHeadBodySet_1(bevd_0);
case -644360289: return bem_ccMethodsSetDirect_1(bevd_0);
case -775666342: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 442428894: return bem_buildSetDirect_1(bevd_0);
case -1003514744: return bem_belslitsSetDirect_1(bevd_0);
case 214898958: return bem_floatNpSetDirect_1(bevd_0);
case -62966840: return bem_mnodeSet_1(bevd_0);
case -1500326399: return bem_gcMarksSet_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1095034835: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1396790309: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -545965444: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1102315799: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -272173180: return bem_synEmitPathSet_1(bevd_0);
case 594217907: return bem_onceDecsSet_1(bevd_0);
case -602178882: return bem_stringNpSet_1(bevd_0);
case -1721262103: return bem_begin_1(bevd_0);
case -1436645165: return bem_instanceEqualSet_1(bevd_0);
case 1569354941: return bem_onceDecRefsSet_1(bevd_0);
case -969568702: return bem_dynMethodsSet_1(bevd_0);
case 327956204: return bem_maxSpillArgsLenSet_1(bevd_0);
case -716159304: return bem_intNpSet_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case 443090784: return bem_onceDecRefsSetDirect_1(bevd_0);
case 2005673292: return bem_invpSet_1(bevd_0);
case -160208307: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1329852354: return bem_smnlecsSet_1(bevd_0);
case -34904310: return bem_heonSet_1(bevd_0);
case 1163807713: return bem_idToNameSet_1(bevd_0);
case -387595023: return bem_scvpSet_1(bevd_0);
case 2073578713: return bem_classHeadersSet_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case -1585582932: return bem_exceptDecSet_1(bevd_0);
case -625263640: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 2003564846: return bem_idToNameSetDirect_1(bevd_0);
case 653158270: return bem_msynSet_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 651411427: return bem_csynSetDirect_1(bevd_0);
case -1846267283: return bem_lastMethodsLinesSet_1(bevd_0);
case -492578982: return bem_methodsSetDirect_1(bevd_0);
case -292631601: return bem_emitLangSetDirect_1(bevd_0);
case 1851258596: return bem_idToNamePathSetDirect_1(bevd_0);
case 704062473: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1427867692: return bem_heopSetDirect_1(bevd_0);
case 850005288: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1984324119: return bem_boolNpSetDirect_1(bevd_0);
case -226099053: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -738801361: return bem_inFilePathedSetDirect_1(bevd_0);
case -2082083044: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -673248215: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 441506828: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case -1433139758: return bem_constSetDirect_1(bevd_0);
case -372834197: return bem_libEmitNameSet_1(bevd_0);
case 789811530: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 168338507: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -822921971: return bem_inClassSetDirect_1(bevd_0);
case 842175531: return bem_nativeCSlotsSet_1(bevd_0);
case -85971300: return bem_shlibeSet_1(bevd_0);
case -2105697821: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 2028646193: return bem_fileExtSet_1(bevd_0);
case 1289075138: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1339916782: return bem_returnTypeSet_1(bevd_0);
case 454452952: return bem_superCallsSet_1(bevd_0);
case 928136567: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1916949496: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1140106751: return bem_lastCallSet_1(bevd_0);
case 741715452: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -85360188: return bem_onceDecRefsCountSetDirect_1(bevd_0);
case -389860844: return bem_deonSet_1(bevd_0);
case -1943477938: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1283217046: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1587075092: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1917317859: return bem_csynSet_1(bevd_0);
case -442474446: return bem_maxDynArgsSet_1(bevd_0);
case 1531473182: return bem_parentConfSetDirect_1(bevd_0);
case 2055324647: return bem_callNamesSetDirect_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -419028433: return bem_headExtSetDirect_1(bevd_0);
case -1587905121: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 63555219: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 791078773: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 513449544: return bem_dynMethodsSetDirect_1(bevd_0);
case 1612967236: return bem_ccMethodsSet_1(bevd_0);
case -1873289547: return bem_exceptDecSetDirect_1(bevd_0);
case 1961814740: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -567479502: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1858565734: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -107209806: return bem_heonSetDirect_1(bevd_0);
case 205155870: return bem_setOutputTimeSet_1(bevd_0);
case 1318149803: return bem_nameToIdSetDirect_1(bevd_0);
case -523725486: return bem_onceCountSetDirect_1(bevd_0);
case -474768129: return bem_lastMethodsSizeSet_1(bevd_0);
case -987670113: return bem_deowSet_1(bevd_0);
case 274995382: return bem_smnlcsSet_1(bevd_0);
case -107534388: return bem_nlSet_1(bevd_0);
case -1291078940: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 538412265: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 956456469: return bem_transSetDirect_1(bevd_0);
case -144269694: return bem_nullValueSetDirect_1(bevd_0);
case 1462258451: return bem_methodsSet_1(bevd_0);
case -1818686320: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -237692528: return bem_invpSetDirect_1(bevd_0);
case -1434027048: return bem_falseValueSet_1(bevd_0);
case -463588041: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1522857961: return bem_floatNpSet_1(bevd_0);
case 81399418: return bem_classCallsSet_1(bevd_0);
case -1204406980: return bem_propertyDecsSetDirect_1(bevd_0);
case 631941336: return bem_stringNpSetDirect_1(bevd_0);
case 790386981: return bem_ntypesSet_1(bevd_0);
case -721327501: return bem_classEmitsSetDirect_1(bevd_0);
case -1903692910: return bem_nameToIdSet_1(bevd_0);
case 2024249127: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1511397097: return bem_boolCcSet_1(bevd_0);
case 1441539029: return bem_fileExtSetDirect_1(bevd_0);
case -1426708999: return bem_belslitsSet_1(bevd_0);
case 201238382: return bem_nlSetDirect_1(bevd_0);
case 1835394700: return bem_deopSetDirect_1(bevd_0);
case 1326810173: return bem_heowSet_1(bevd_0);
case -2042978766: return bem_synEmitPathSetDirect_1(bevd_0);
case 1051071357: return bem_nameToIdPathSetDirect_1(bevd_0);
case -1572907584: return bem_intNpSetDirect_1(bevd_0);
case 134712052: return bem_headExtSet_1(bevd_0);
case -1989797599: return bem_methodCallsSet_1(bevd_0);
case 1950647904: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -572209496: return bem_deowSetDirect_1(bevd_0);
case -2007098411: return bem_lastCallSetDirect_1(bevd_0);
case 1462003221: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 177979611: return bem_msynSetDirect_1(bevd_0);
case -1024256293: return bem_instOfSetDirect_1(bevd_0);
case -143970869: return bem_propertyDecsSet_1(bevd_0);
case -812242675: return bem_methodCallsSetDirect_1(bevd_0);
case -1234722829: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1991744387: return bem_objectCcSetDirect_1(bevd_0);
case 1395501902: return bem_parentConfSet_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case 886262275: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1701400110: return bem_gcMarksSetDirect_1(bevd_0);
case -608739103: return bem_trueValueSet_1(bevd_0);
case -363908270: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1928356294: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case -1328551341: return bem_objectCcSet_1(bevd_0);
case -1981562519: return bem_trueValueSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1795024150: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -298165990: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1806622672: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -856996376: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1650562428: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2038093316: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -835651430: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 165354965: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2010601293: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -747880859: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1466676333: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1944839781: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1947957571: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 471618185: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 815586935: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1137281105: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -808244447: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1792824748: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -61116913: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 656033829: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -736594313: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCCEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
}
