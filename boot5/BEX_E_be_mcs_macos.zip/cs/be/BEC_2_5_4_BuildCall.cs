namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_4_BuildCall : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildCall() { }
static BEC_2_5_4_BuildCall() { }
private static byte[] becc_BEC_2_5_4_BuildCall_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C};
private static byte[] becc_BEC_2_5_4_BuildCall_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_0 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_1 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_2 = {0x20,0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_3 = {0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_4 = {0x20,0x6E,0x6F,0x74,0x42,0x6F,0x75,0x6E,0x64};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_5 = {0x20,0x77,0x61,0x73,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_6 = {0x47,0x45,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_7 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_8 = {0x53,0x45,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_9 = {0x53,0x65,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_10 = {0x47,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_11 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_12 = {0x53,0x45,0x54,0x44,0x49,0x52,0x45,0x43,0x54};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_13 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_4_BuildCall_bels_14 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72,0x20,0x74,0x79,0x70,0x65,0x20};
public static new BEC_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_inst;

public static new BET_2_5_4_BuildCall bece_BEC_2_5_4_BuildCall_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_4_6_TextString bevp_accessorType;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_literalValue;
public BEC_2_5_8_BuildNamePath bevp_newNp;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_2_5_4_LogicBool bevp_isConstruct;
public BEC_2_5_4_LogicBool bevp_bound;
public BEC_2_5_4_LogicBool bevp_wasBound;
public BEC_2_5_4_LogicBool bevp_wasAccessor;
public BEC_2_5_4_LogicBool bevp_wasOper;
public BEC_2_5_4_LogicBool bevp_isLiteral;
public BEC_2_5_4_LogicBool bevp_isOnce;
public BEC_2_5_4_LogicBool bevp_isMany;
public BEC_2_5_4_LogicBool bevp_checkTypes;
public BEC_2_4_6_TextString bevp_checkTypesType;
public BEC_2_5_4_LogicBool bevp_superCall;
public BEC_2_5_4_LogicBool bevp_wasImpliedConstruct;
public BEC_2_5_4_LogicBool bevp_wasForeachGenned;
public BEC_2_5_4_LogicBool bevp_untyped;
public BEC_2_5_4_LogicBool bevp_isForward;
public BEC_2_9_4_ContainerList bevp_argCasts;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_bound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasBound = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_wasAccessor = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasOper = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLiteral = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isOnce = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isMany = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_checkTypes = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_checkTypesType = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_0));
bevp_superCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_untyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isForward = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_argCasts = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 324*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildCall_bels_1));
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
} /* Line: 325*/
if (bevp_orgName == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 327*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildCall_bels_2));
bevt_5_ta_ph = bevl_ret.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bevp_orgName.bem_toString_0();
bevl_ret = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
} /* Line: 328*/
if (bevp_numargs == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 330*/ {
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_4_BuildCall_bels_3));
bevt_9_ta_ph = bevl_ret.bem_add_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_numargs.bem_toString_0();
bevl_ret = bevt_9_ta_ph.bem_add_1(bevt_11_ta_ph);
} /* Line: 331*/
if (bevp_bound.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 333*/ {
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_4));
bevl_ret = bevl_ret.bem_add_1(bevt_13_ta_ph);
} /* Line: 334*/
if (bevp_wasAccessor.bevi_bool)/* Line: 336*/ {
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_4_BuildCall_bels_5));
bevl_ret = bevl_ret.bem_add_1(bevt_14_ta_ph);
} /* Line: 337*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildCall bem_toAccessorName_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_9_SystemException bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_6));
bevt_0_ta_ph = bevp_accessorType.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 343*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_7));
bevp_name = bevp_name.bem_add_1(bevt_2_ta_ph);
} /* Line: 344*/
 else /* Line: 343*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_8));
bevt_3_ta_ph = bevp_accessorType.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_4_BuildCall_bels_9));
bevp_name = bevp_name.bem_add_1(bevt_5_ta_ph);
} /* Line: 346*/
 else /* Line: 343*/ {
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_10));
bevt_6_ta_ph = bevp_accessorType.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 347*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_11));
bevp_name = bevp_name.bem_add_1(bevt_8_ta_ph);
} /* Line: 348*/
 else /* Line: 343*/ {
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_12));
bevt_9_ta_ph = bevp_accessorType.bem_equals_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 349*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_4_BuildCall_bels_13));
bevp_name = bevp_name.bem_add_1(bevt_11_ta_ph);
} /* Line: 350*/
 else /* Line: 351*/ {
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildCall_bels_14));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevp_accessorType);
bevt_12_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_13_ta_ph);
throw new be.BECS_ThrowBack(bevt_12_ta_ph);
} /* Line: 352*/
} /* Line: 343*/
} /* Line: 343*/
} /* Line: 343*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGetDirect_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGet_0() {
return bevp_accessorType;
} /*method end*/
public BEC_2_4_6_TextString bem_accessorTypeGetDirect_0() {
return bevp_accessorType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_accessorTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_accessorType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGetDirect_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGet_0() {
return bevp_literalValue;
} /*method end*/
public BEC_2_4_6_TextString bem_literalValueGetDirect_0() {
return bevp_literalValue;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_literalValueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_literalValue = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGet_0() {
return bevp_newNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_newNpGetDirect_0() {
return bevp_newNp;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_newNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGetDirect_0() {
return bevp_cpos;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_cposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGet_0() {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isConstructGetDirect_0() {
return bevp_isConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGet_0() {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boundGetDirect_0() {
return bevp_bound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_boundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_bound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGet_0() {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasBoundGetDirect_0() {
return bevp_wasBound;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasBoundSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasBound = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGet_0() {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasAccessorGetDirect_0() {
return bevp_wasAccessor;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGet_0() {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasOperGetDirect_0() {
return bevp_wasOper;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasOperSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasOper = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGet_0() {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralGetDirect_0() {
return bevp_isLiteral;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isLiteralSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLiteral = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGet_0() {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOnceGetDirect_0() {
return bevp_isOnce;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isOnceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isOnce = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGet_0() {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isManyGetDirect_0() {
return bevp_isMany;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isManySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isMany = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGet_0() {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkTypesGetDirect_0() {
return bevp_checkTypes;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_checkTypes = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGet_0() {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_4_6_TextString bem_checkTypesTypeGetDirect_0() {
return bevp_checkTypesType;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_checkTypesTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_checkTypesType = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGet_0() {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_LogicBool bem_superCallGetDirect_0() {
return bevp_superCall;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_superCallSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_superCall = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGet_0() {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasImpliedConstructGetDirect_0() {
return bevp_wasImpliedConstruct;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasImpliedConstructSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasImpliedConstruct = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGet_0() {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wasForeachGennedGetDirect_0() {
return bevp_wasForeachGenned;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_wasForeachGennedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wasForeachGenned = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGet_0() {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_LogicBool bem_untypedGetDirect_0() {
return bevp_untyped;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_untypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_untyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGet_0() {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isForwardGetDirect_0() {
return bevp_isForward;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_isForwardSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isForward = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGet_0() {
return bevp_argCasts;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argCastsGetDirect_0() {
return bevp_argCasts;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildCall bem_argCastsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_argCasts = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 316, 323, 324, 324, 325, 325, 325, 325, 327, 327, 328, 328, 328, 328, 330, 330, 331, 331, 331, 331, 333, 333, 334, 334, 337, 337, 339, 343, 343, 344, 344, 345, 345, 346, 346, 347, 347, 348, 348, 349, 349, 350, 350, 352, 352, 352, 352, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 86, 87, 92, 93, 94, 95, 96, 98, 103, 104, 105, 106, 107, 109, 114, 115, 116, 117, 118, 120, 125, 126, 127, 130, 131, 133, 151, 152, 154, 155, 158, 159, 161, 162, 165, 166, 168, 169, 172, 173, 175, 176, 179, 180, 181, 182, 190, 193, 196, 200, 204, 207, 210, 214, 218, 221, 224, 228, 232, 235, 238, 242, 246, 249, 252, 256, 260, 263, 266, 270, 274, 277, 280, 284, 288, 291, 294, 298, 302, 305, 308, 312, 316, 319, 322, 326, 330, 333, 336, 340, 344, 347, 350, 354, 358, 361, 364, 368, 372, 375, 378, 382, 386, 389, 392, 396, 400, 403, 406, 410, 414, 417, 420, 424, 428, 431, 434, 438, 442, 445, 448, 452, 456, 459, 462, 466, 470, 473, 476, 480, 484, 487, 490, 494, 498, 501, 504, 508};
/* BEGIN LINEINFO 
assign 1 300 51
new 0 300 51
assign 1 301 52
new 0 301 52
assign 1 302 53
new 0 302 53
assign 1 303 54
new 0 303 54
assign 1 304 55
new 0 304 55
assign 1 305 56
new 0 305 56
assign 1 306 57
new 0 306 57
assign 1 307 58
new 0 307 58
assign 1 308 59
new 0 308 59
assign 1 309 60
new 0 309 60
assign 1 310 61
new 0 310 61
assign 1 311 62
new 0 311 62
assign 1 312 63
new 0 312 63
assign 1 313 64
new 0 313 64
assign 1 314 65
new 0 314 65
assign 1 316 66
new 0 316 66
assign 1 323 86
classNameGet 0 323 86
assign 1 324 87
def 1 324 92
assign 1 325 93
new 0 325 93
assign 1 325 94
add 1 325 94
assign 1 325 95
toString 0 325 95
assign 1 325 96
add 1 325 96
assign 1 327 98
def 1 327 103
assign 1 328 104
new 0 328 104
assign 1 328 105
add 1 328 105
assign 1 328 106
toString 0 328 106
assign 1 328 107
add 1 328 107
assign 1 330 109
def 1 330 114
assign 1 331 115
new 0 331 115
assign 1 331 116
add 1 331 116
assign 1 331 117
toString 0 331 117
assign 1 331 118
add 1 331 118
assign 1 333 120
not 0 333 125
assign 1 334 126
new 0 334 126
assign 1 334 127
add 1 334 127
assign 1 337 130
new 0 337 130
assign 1 337 131
add 1 337 131
return 1 339 133
assign 1 343 151
new 0 343 151
assign 1 343 152
equals 1 343 152
assign 1 344 154
new 0 344 154
assign 1 344 155
add 1 344 155
assign 1 345 158
new 0 345 158
assign 1 345 159
equals 1 345 159
assign 1 346 161
new 0 346 161
assign 1 346 162
add 1 346 162
assign 1 347 165
new 0 347 165
assign 1 347 166
equals 1 347 166
assign 1 348 168
new 0 348 168
assign 1 348 169
add 1 348 169
assign 1 349 172
new 0 349 172
assign 1 349 173
equals 1 349 173
assign 1 350 175
new 0 350 175
assign 1 350 176
add 1 350 176
assign 1 352 179
new 0 352 179
assign 1 352 180
add 1 352 180
assign 1 352 181
new 1 352 181
throw 1 352 182
return 1 0 190
return 1 0 193
assign 1 0 196
assign 1 0 200
return 1 0 204
return 1 0 207
assign 1 0 210
assign 1 0 214
return 1 0 218
return 1 0 221
assign 1 0 224
assign 1 0 228
return 1 0 232
return 1 0 235
assign 1 0 238
assign 1 0 242
return 1 0 246
return 1 0 249
assign 1 0 252
assign 1 0 256
return 1 0 260
return 1 0 263
assign 1 0 266
assign 1 0 270
return 1 0 274
return 1 0 277
assign 1 0 280
assign 1 0 284
return 1 0 288
return 1 0 291
assign 1 0 294
assign 1 0 298
return 1 0 302
return 1 0 305
assign 1 0 308
assign 1 0 312
return 1 0 316
return 1 0 319
assign 1 0 322
assign 1 0 326
return 1 0 330
return 1 0 333
assign 1 0 336
assign 1 0 340
return 1 0 344
return 1 0 347
assign 1 0 350
assign 1 0 354
return 1 0 358
return 1 0 361
assign 1 0 364
assign 1 0 368
return 1 0 372
return 1 0 375
assign 1 0 378
assign 1 0 382
return 1 0 386
return 1 0 389
assign 1 0 392
assign 1 0 396
return 1 0 400
return 1 0 403
assign 1 0 406
assign 1 0 410
return 1 0 414
return 1 0 417
assign 1 0 420
assign 1 0 424
return 1 0 428
return 1 0 431
assign 1 0 434
assign 1 0 438
return 1 0 442
return 1 0 445
assign 1 0 448
assign 1 0 452
return 1 0 456
return 1 0 459
assign 1 0 462
assign 1 0 466
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
return 1 0 498
return 1 0 501
assign 1 0 504
assign 1 0 508
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2038193605: return bem_fieldNamesGet_0();
case -8643043: return bem_serializeContents_0();
case 1244272026: return bem_orgNameGetDirect_0();
case 1274233410: return bem_accessorTypeGet_0();
case 1930226354: return bem_superCallGet_0();
case -1922426092: return bem_numargsGet_0();
case 217968364: return bem_classNameGet_0();
case 791304310: return bem_argCastsGet_0();
case -785258946: return bem_create_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 1593170174: return bem_checkTypesTypeGetDirect_0();
case 581586279: return bem_toAccessorName_0();
case -1848718184: return bem_hashGet_0();
case -1779834881: return bem_wasForeachGennedGetDirect_0();
case -1095441109: return bem_isManyGet_0();
case -1881972728: return bem_cposGet_0();
case 1091541845: return bem_isConstructGet_0();
case -148327670: return bem_checkTypesTypeGet_0();
case 1226541332: return bem_wasAccessorGetDirect_0();
case 1710132065: return bem_boundGetDirect_0();
case -1026733174: return bem_new_0();
case -1779062531: return bem_serializationIteratorGet_0();
case 1562608535: return bem_print_0();
case 1807701568: return bem_wasOperGetDirect_0();
case -428799817: return bem_accessorTypeGetDirect_0();
case 1688687204: return bem_serializeToString_0();
case -841339726: return bem_wasAccessorGet_0();
case -119388582: return bem_nameGet_0();
case -1568319884: return bem_boundGet_0();
case -1755316165: return bem_untypedGet_0();
case -1898263973: return bem_newNpGet_0();
case -479166709: return bem_tagGet_0();
case -1914533564: return bem_wasOperGet_0();
case 1499014865: return bem_literalValueGet_0();
case -1602285681: return bem_isForwardGetDirect_0();
case 1908006922: return bem_isLiteralGetDirect_0();
case -810288484: return bem_numargsGetDirect_0();
case -1980166000: return bem_nameGetDirect_0();
case 1278157977: return bem_literalValueGetDirect_0();
case -15696174: return bem_wasImpliedConstructGetDirect_0();
case 950101994: return bem_newNpGetDirect_0();
case -1139107068: return bem_isForwardGet_0();
case 126670515: return bem_toAny_0();
case 1029695809: return bem_echo_0();
case 1084527566: return bem_cposGetDirect_0();
case 185174991: return bem_copy_0();
case 1813554540: return bem_superCallGetDirect_0();
case 2113901931: return bem_isOnceGetDirect_0();
case 1417905354: return bem_wasImpliedConstructGet_0();
case 784324125: return bem_isManyGetDirect_0();
case -1844917728: return bem_many_0();
case -392334411: return bem_wasBoundGetDirect_0();
case -389446529: return bem_checkTypesGetDirect_0();
case -31114048: return bem_iteratorGet_0();
case 955127771: return bem_untypedGetDirect_0();
case 1137009070: return bem_once_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -1747123395: return bem_isLiteralGet_0();
case 832832728: return bem_isOnceGet_0();
case -134971264: return bem_isConstructGetDirect_0();
case -1047534358: return bem_argCastsGetDirect_0();
case -687145133: return bem_checkTypesGet_0();
case 260849803: return bem_orgNameGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 1964587254: return bem_wasBoundGet_0();
case -1902089216: return bem_toString_0();
case -1882608417: return bem_wasForeachGennedGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1776984803: return bem_wasImpliedConstructSet_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -296707431: return bem_boundSetDirect_1(bevd_0);
case 1055142423: return bem_wasAccessorSet_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -125280485: return bem_cposSet_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case 573231166: return bem_isOnceSetDirect_1(bevd_0);
case 1633976094: return bem_argCastsSet_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case -1319353854: return bem_untypedSetDirect_1(bevd_0);
case 1552960497: return bem_untypedSet_1(bevd_0);
case 84785916: return bem_wasOperSet_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -901541083: return bem_numargsSet_1(bevd_0);
case 286782806: return bem_argCastsSetDirect_1(bevd_0);
case 1498054791: return bem_boundSet_1(bevd_0);
case 2145906960: return bem_isManySet_1(bevd_0);
case -2025659516: return bem_literalValueSet_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case -496825807: return bem_wasForeachGennedSetDirect_1(bevd_0);
case 1745958482: return bem_isForwardSetDirect_1(bevd_0);
case -568059986: return bem_orgNameSetDirect_1(bevd_0);
case 516780894: return bem_isLiteralSetDirect_1(bevd_0);
case 690035928: return bem_isManySetDirect_1(bevd_0);
case -1938628956: return bem_isForwardSet_1(bevd_0);
case 2001682630: return bem_nameSetDirect_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 1047920335: return bem_literalValueSetDirect_1(bevd_0);
case -529447501: return bem_cposSetDirect_1(bevd_0);
case 1620876864: return bem_nameSet_1(bevd_0);
case -581166689: return bem_accessorTypeSetDirect_1(bevd_0);
case 1949589694: return bem_wasImpliedConstructSetDirect_1(bevd_0);
case 1705323788: return bem_wasOperSetDirect_1(bevd_0);
case 1201874893: return bem_numargsSetDirect_1(bevd_0);
case -994929661: return bem_checkTypesTypeSet_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1902850714: return bem_accessorTypeSet_1(bevd_0);
case -1158410946: return bem_newNpSet_1(bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -458322204: return bem_wasForeachGennedSet_1(bevd_0);
case -366697115: return bem_newNpSetDirect_1(bevd_0);
case 150674012: return bem_wasBoundSetDirect_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 1274497893: return bem_checkTypesSetDirect_1(bevd_0);
case -2003499717: return bem_wasBoundSet_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 2109698345: return bem_isLiteralSet_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -1908585050: return bem_checkTypesSet_1(bevd_0);
case -1679154276: return bem_superCallSetDirect_1(bevd_0);
case -1873120807: return bem_isConstructSetDirect_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -834609433: return bem_isConstructSet_1(bevd_0);
case -36938413: return bem_wasAccessorSetDirect_1(bevd_0);
case -1905061515: return bem_superCallSet_1(bevd_0);
case -1809678814: return bem_checkTypesTypeSetDirect_1(bevd_0);
case -861277369: return bem_isOnceSet_1(bevd_0);
case 614764020: return bem_orgNameSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildCall_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildCall_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildCall();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst = (BEC_2_5_4_BuildCall) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_BuildCall.bece_BEC_2_5_4_BuildCall_bevs_type;
}
}
}
