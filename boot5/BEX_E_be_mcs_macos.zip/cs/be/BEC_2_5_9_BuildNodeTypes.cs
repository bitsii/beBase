namespace be {
/* IO:File: source/build/NodeTypes.be */
public sealed class BEC_2_5_9_BuildNodeTypes : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildNodeTypes() { }
static BEC_2_5_9_BuildNodeTypes() { }
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;

public static new BET_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_TRANSUNIT;
public BEC_2_4_3_MathInt bevp_VAR;
public BEC_2_4_3_MathInt bevp_NULL;
public BEC_2_4_3_MathInt bevp_CALL;
public BEC_2_4_3_MathInt bevp_NAMEPATH;
public BEC_2_4_3_MathInt bevp_CLASS;
public BEC_2_4_3_MathInt bevp_EMIT;
public BEC_2_4_3_MathInt bevp_IFEMIT;
public BEC_2_4_3_MathInt bevp_TRUE;
public BEC_2_4_3_MathInt bevp_FALSE;
public BEC_2_4_3_MathInt bevp_BRACES;
public BEC_2_4_3_MathInt bevp_RBRACES;
public BEC_2_4_3_MathInt bevp_RPARENS;
public BEC_2_4_3_MathInt bevp_LOOP;
public BEC_2_4_3_MathInt bevp_PROPERTIES;
public BEC_2_4_3_MathInt bevp_ELSE;
public BEC_2_4_3_MathInt bevp_FINALLY;
public BEC_2_4_3_MathInt bevp_TRY;
public BEC_2_4_3_MathInt bevp_CATCH;
public BEC_2_4_3_MathInt bevp_IF;
public BEC_2_4_3_MathInt bevp_SPACE;
public BEC_2_4_3_MathInt bevp_METHOD;
public BEC_2_4_3_MathInt bevp_DEFMOD;
public BEC_2_4_3_MathInt bevp_PARENS;
public BEC_2_4_3_MathInt bevp_FLOATL;
public BEC_2_4_3_MathInt bevp_INTL;
public BEC_2_4_3_MathInt bevp_DIVIDE;
public BEC_2_4_3_MathInt bevp_DIVIDE_ASSIGN;
public BEC_2_4_3_MathInt bevp_MULTIPLY;
public BEC_2_4_3_MathInt bevp_MULTIPLY_ASSIGN;
public BEC_2_4_3_MathInt bevp_STRQ;
public BEC_2_4_3_MathInt bevp_WSTRQ;
public BEC_2_4_3_MathInt bevp_STRINGL;
public BEC_2_4_3_MathInt bevp_WSTRINGL;
public BEC_2_4_3_MathInt bevp_NEWLINE;
public BEC_2_4_3_MathInt bevp_ASSIGN;
public BEC_2_4_3_MathInt bevp_EQUALS;
public BEC_2_4_3_MathInt bevp_NOT;
public BEC_2_4_3_MathInt bevp_ONCE;
public BEC_2_4_3_MathInt bevp_MANY;
public BEC_2_4_3_MathInt bevp_NOT_EQUALS;
public BEC_2_4_3_MathInt bevp_OR;
public BEC_2_4_3_MathInt bevp_AND;
public BEC_2_4_3_MathInt bevp_OR_ASSIGN;
public BEC_2_4_3_MathInt bevp_AND_ASSIGN;
public BEC_2_4_3_MathInt bevp_LOGICAL_OR;
public BEC_2_4_3_MathInt bevp_GET_METHOD;
public BEC_2_4_3_MathInt bevp_LOGICAL_AND;
public BEC_2_4_3_MathInt bevp_GREATER;
public BEC_2_4_3_MathInt bevp_GREATER_EQUALS;
public BEC_2_4_3_MathInt bevp_LESSER;
public BEC_2_4_3_MathInt bevp_LESSER_EQUALS;
public BEC_2_4_3_MathInt bevp_ADD;
public BEC_2_4_3_MathInt bevp_INCREMENT;
public BEC_2_4_3_MathInt bevp_ADD_ASSIGN;
public BEC_2_4_3_MathInt bevp_INCREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_SUBTRACT;
public BEC_2_4_3_MathInt bevp_DECREMENT;
public BEC_2_4_3_MathInt bevp_SUBTRACT_ASSIGN;
public BEC_2_4_3_MathInt bevp_DECREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_ID;
public BEC_2_4_3_MathInt bevp_COLON;
public BEC_2_4_3_MathInt bevp_WHILE;
public BEC_2_4_3_MathInt bevp_FOREACH;
public BEC_2_4_3_MathInt bevp_BLOCK;
public BEC_2_4_3_MathInt bevp_USE;
public BEC_2_4_3_MathInt bevp_AS;
public BEC_2_4_3_MathInt bevp_SEMI;
public BEC_2_4_3_MathInt bevp_EXPR;
public BEC_2_4_3_MathInt bevp_COMMA;
public BEC_2_4_3_MathInt bevp_ACCESSOR;
public BEC_2_4_3_MathInt bevp_DOT;
public BEC_2_4_3_MathInt bevp_BREAK;
public BEC_2_4_3_MathInt bevp_IDX;
public BEC_2_4_3_MathInt bevp_IDXACC;
public BEC_2_4_3_MathInt bevp_RIDX;
public BEC_2_4_3_MathInt bevp_TOKEN;
public BEC_2_4_3_MathInt bevp_MODULUS;
public BEC_2_4_3_MathInt bevp_MODULUS_ASSIGN;
public BEC_2_4_3_MathInt bevp_ELIF;
public BEC_2_4_3_MathInt bevp_FOR;
public BEC_2_4_3_MathInt bevp_IN;
public BEC_2_4_3_MathInt bevp_CONTINUE;
public BEC_2_4_3_MathInt bevp_ATYPE;
public BEC_2_4_3_MathInt bevp_FSLASH;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_default_0() {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_VAR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_NULL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_CALL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_NAMEPATH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_CLASS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_EMIT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_IFEMIT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_TRUE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevp_FALSE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bevp_BRACES = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevp_RBRACES = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_RPARENS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(14));
bevp_LOOP = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(15));
bevp_PROPERTIES = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(23));
bevp_ELSE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevp_FINALLY = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(93));
bevp_TRY = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(17));
bevp_CATCH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(18));
bevp_IF = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(19));
bevp_SPACE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(20));
bevp_METHOD = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(21));
bevp_DEFMOD = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(74));
bevp_PARENS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(22));
bevp_FLOATL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(25));
bevp_INTL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevp_DIVIDE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(27));
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(86));
bevp_MULTIPLY = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(28));
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevp_STRQ = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(29));
bevp_WSTRQ = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(30));
bevp_STRINGL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
bevp_WSTRINGL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(33));
bevp_NEWLINE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevp_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(35));
bevp_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(36));
bevp_NOT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(37));
bevp_ONCE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(81));
bevp_MANY = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(82));
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(38));
bevp_OR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(39));
bevp_AND = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(40));
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(92));
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(89));
bevp_GET_METHOD = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(94));
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(90));
bevp_GREATER = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(41));
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
bevp_LESSER = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(43));
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(44));
bevp_ADD = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
bevp_INCREMENT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(46));
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(84));
bevp_SUBTRACT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevp_DECREMENT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(49));
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(83));
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(85));
bevp_ID = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(50));
bevp_COLON = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(51));
bevp_WHILE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(52));
bevp_FOREACH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(53));
bevp_BLOCK = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(72));
bevp_USE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(54));
bevp_AS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevp_SEMI = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56));
bevp_EXPR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
bevp_COMMA = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
bevp_ACCESSOR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(59));
bevp_DOT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(60));
bevp_BREAK = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(61));
bevp_IDX = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(62));
bevp_IDXACC = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(73));
bevp_RIDX = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(63));
bevp_TOKEN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
bevp_MODULUS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(88));
bevp_ELIF = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(66));
bevp_FOR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(67));
bevp_IN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(68));
bevp_CONTINUE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(69));
bevp_ATYPE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(71));
bevp_FSLASH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(80));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRANSUNITGet_0() {
return bevp_TRANSUNIT;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRANSUNITGetDirect_0() {
return bevp_TRANSUNIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_VARGet_0() {
return bevp_VAR;
} /*method end*/
public BEC_2_4_3_MathInt bem_VARGetDirect_0() {
return bevp_VAR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_VARSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_VARSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NULLGet_0() {
return bevp_NULL;
} /*method end*/
public BEC_2_4_3_MathInt bem_NULLGetDirect_0() {
return bevp_NULL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NULLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NULLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CALLGet_0() {
return bevp_CALL;
} /*method end*/
public BEC_2_4_3_MathInt bem_CALLGetDirect_0() {
return bevp_CALL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CALLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CALLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NAMEPATHGet_0() {
return bevp_NAMEPATH;
} /*method end*/
public BEC_2_4_3_MathInt bem_NAMEPATHGetDirect_0() {
return bevp_NAMEPATH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CLASSGet_0() {
return bevp_CLASS;
} /*method end*/
public BEC_2_4_3_MathInt bem_CLASSGetDirect_0() {
return bevp_CLASS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CLASSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CLASSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EMITGet_0() {
return bevp_EMIT;
} /*method end*/
public BEC_2_4_3_MathInt bem_EMITGetDirect_0() {
return bevp_EMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EMITSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFEMITGet_0() {
return bevp_IFEMIT;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFEMITGetDirect_0() {
return bevp_IFEMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFEMITSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFEMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRUEGet_0() {
return bevp_TRUE;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRUEGetDirect_0() {
return bevp_TRUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRUESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FALSEGet_0() {
return bevp_FALSE;
} /*method end*/
public BEC_2_4_3_MathInt bem_FALSEGetDirect_0() {
return bevp_FALSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FALSESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FALSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BRACESGet_0() {
return bevp_BRACES;
} /*method end*/
public BEC_2_4_3_MathInt bem_BRACESGetDirect_0() {
return bevp_BRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BRACESSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RBRACESGet_0() {
return bevp_RBRACES;
} /*method end*/
public BEC_2_4_3_MathInt bem_RBRACESGetDirect_0() {
return bevp_RBRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RBRACESSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RBRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RPARENSGet_0() {
return bevp_RPARENS;
} /*method end*/
public BEC_2_4_3_MathInt bem_RPARENSGetDirect_0() {
return bevp_RPARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RPARENSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RPARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOOPGet_0() {
return bevp_LOOP;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOOPGetDirect_0() {
return bevp_LOOP;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOOPSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOOPSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PROPERTIESGet_0() {
return bevp_PROPERTIES;
} /*method end*/
public BEC_2_4_3_MathInt bem_PROPERTIESGetDirect_0() {
return bevp_PROPERTIES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELSEGet_0() {
return bevp_ELSE;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELSEGetDirect_0() {
return bevp_ELSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELSESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FINALLYGet_0() {
return bevp_FINALLY;
} /*method end*/
public BEC_2_4_3_MathInt bem_FINALLYGetDirect_0() {
return bevp_FINALLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FINALLYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FINALLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRYGet_0() {
return bevp_TRY;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRYGetDirect_0() {
return bevp_TRY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CATCHGet_0() {
return bevp_CATCH;
} /*method end*/
public BEC_2_4_3_MathInt bem_CATCHGetDirect_0() {
return bevp_CATCH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CATCHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CATCHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFGet_0() {
return bevp_IF;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFGetDirect_0() {
return bevp_IF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SPACEGet_0() {
return bevp_SPACE;
} /*method end*/
public BEC_2_4_3_MathInt bem_SPACEGetDirect_0() {
return bevp_SPACE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SPACESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SPACESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_METHODGet_0() {
return bevp_METHOD;
} /*method end*/
public BEC_2_4_3_MathInt bem_METHODGetDirect_0() {
return bevp_METHOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_METHODSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_METHODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DEFMODGet_0() {
return bevp_DEFMOD;
} /*method end*/
public BEC_2_4_3_MathInt bem_DEFMODGetDirect_0() {
return bevp_DEFMOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DEFMODSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DEFMODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PARENSGet_0() {
return bevp_PARENS;
} /*method end*/
public BEC_2_4_3_MathInt bem_PARENSGetDirect_0() {
return bevp_PARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PARENSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FLOATLGet_0() {
return bevp_FLOATL;
} /*method end*/
public BEC_2_4_3_MathInt bem_FLOATLGetDirect_0() {
return bevp_FLOATL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FLOATLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FLOATLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INTLGet_0() {
return bevp_INTL;
} /*method end*/
public BEC_2_4_3_MathInt bem_INTLGetDirect_0() {
return bevp_INTL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INTLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INTLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDEGet_0() {
return bevp_DIVIDE;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDEGetDirect_0() {
return bevp_DIVIDE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGet_0() {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGetDirect_0() {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLYGet_0() {
return bevp_MULTIPLY;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLYGetDirect_0() {
return bevp_MULTIPLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGet_0() {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGetDirect_0() {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRQGet_0() {
return bevp_STRQ;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRQGetDirect_0() {
return bevp_STRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRQSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRQGet_0() {
return bevp_WSTRQ;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRQGetDirect_0() {
return bevp_WSTRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRQSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRINGLGet_0() {
return bevp_STRINGL;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRINGLGetDirect_0() {
return bevp_STRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRINGLGet_0() {
return bevp_WSTRINGL;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRINGLGetDirect_0() {
return bevp_WSTRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NEWLINEGet_0() {
return bevp_NEWLINE;
} /*method end*/
public BEC_2_4_3_MathInt bem_NEWLINEGetDirect_0() {
return bevp_NEWLINE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NEWLINESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NEWLINESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASSIGNGet_0() {
return bevp_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASSIGNGetDirect_0() {
return bevp_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EQUALSGet_0() {
return bevp_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_EQUALSGetDirect_0() {
return bevp_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOTGet_0() {
return bevp_NOT;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOTGetDirect_0() {
return bevp_NOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ONCEGet_0() {
return bevp_ONCE;
} /*method end*/
public BEC_2_4_3_MathInt bem_ONCEGetDirect_0() {
return bevp_ONCE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ONCESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ONCE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ONCESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ONCE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MANYGet_0() {
return bevp_MANY;
} /*method end*/
public BEC_2_4_3_MathInt bem_MANYGetDirect_0() {
return bevp_MANY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MANYSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MANY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MANYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MANY = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOT_EQUALSGet_0() {
return bevp_NOT_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOT_EQUALSGetDirect_0() {
return bevp_NOT_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ORGet_0() {
return bevp_OR;
} /*method end*/
public BEC_2_4_3_MathInt bem_ORGetDirect_0() {
return bevp_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ANDGet_0() {
return bevp_AND;
} /*method end*/
public BEC_2_4_3_MathInt bem_ANDGetDirect_0() {
return bevp_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_OR_ASSIGNGet_0() {
return bevp_OR_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_OR_ASSIGNGetDirect_0() {
return bevp_OR_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_AND_ASSIGNGet_0() {
return bevp_AND_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_AND_ASSIGNGetDirect_0() {
return bevp_AND_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ORGet_0() {
return bevp_LOGICAL_OR;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ORGetDirect_0() {
return bevp_LOGICAL_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GET_METHODGet_0() {
return bevp_GET_METHOD;
} /*method end*/
public BEC_2_4_3_MathInt bem_GET_METHODGetDirect_0() {
return bevp_GET_METHOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GET_METHODSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_GET_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GET_METHODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_GET_METHOD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ANDGet_0() {
return bevp_LOGICAL_AND;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ANDGetDirect_0() {
return bevp_LOGICAL_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATERGet_0() {
return bevp_GREATER;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATERGetDirect_0() {
return bevp_GREATER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATERSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATER_EQUALSGet_0() {
return bevp_GREATER_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATER_EQUALSGetDirect_0() {
return bevp_GREATER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSERGet_0() {
return bevp_LESSER;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSERGetDirect_0() {
return bevp_LESSER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSERSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSER_EQUALSGet_0() {
return bevp_LESSER_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSER_EQUALSGetDirect_0() {
return bevp_LESSER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADDGet_0() {
return bevp_ADD;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADDGetDirect_0() {
return bevp_ADD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENTGet_0() {
return bevp_INCREMENT;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENTGetDirect_0() {
return bevp_INCREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADD_ASSIGNGet_0() {
return bevp_ADD_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADD_ASSIGNGetDirect_0() {
return bevp_ADD_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGet_0() {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGetDirect_0() {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACTGet_0() {
return bevp_SUBTRACT;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACTGetDirect_0() {
return bevp_SUBTRACT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENTGet_0() {
return bevp_DECREMENT;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENTGetDirect_0() {
return bevp_DECREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGet_0() {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGetDirect_0() {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGet_0() {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGetDirect_0() {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDGet_0() {
return bevp_ID;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDGetDirect_0() {
return bevp_ID;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COLONGet_0() {
return bevp_COLON;
} /*method end*/
public BEC_2_4_3_MathInt bem_COLONGetDirect_0() {
return bevp_COLON;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COLONSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COLONSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WHILEGet_0() {
return bevp_WHILE;
} /*method end*/
public BEC_2_4_3_MathInt bem_WHILEGetDirect_0() {
return bevp_WHILE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WHILESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WHILESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FOREACHGet_0() {
return bevp_FOREACH;
} /*method end*/
public BEC_2_4_3_MathInt bem_FOREACHGetDirect_0() {
return bevp_FOREACH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FOREACHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FOREACHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BLOCKGet_0() {
return bevp_BLOCK;
} /*method end*/
public BEC_2_4_3_MathInt bem_BLOCKGetDirect_0() {
return bevp_BLOCK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BLOCKSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BLOCKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_USEGet_0() {
return bevp_USE;
} /*method end*/
public BEC_2_4_3_MathInt bem_USEGetDirect_0() {
return bevp_USE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_USESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_USESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASGet_0() {
return bevp_AS;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASGetDirect_0() {
return bevp_AS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SEMIGet_0() {
return bevp_SEMI;
} /*method end*/
public BEC_2_4_3_MathInt bem_SEMIGetDirect_0() {
return bevp_SEMI;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SEMISet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SEMISetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EXPRGet_0() {
return bevp_EXPR;
} /*method end*/
public BEC_2_4_3_MathInt bem_EXPRGetDirect_0() {
return bevp_EXPR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EXPRSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EXPRSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COMMAGet_0() {
return bevp_COMMA;
} /*method end*/
public BEC_2_4_3_MathInt bem_COMMAGetDirect_0() {
return bevp_COMMA;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COMMASet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COMMASetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ACCESSORGet_0() {
return bevp_ACCESSOR;
} /*method end*/
public BEC_2_4_3_MathInt bem_ACCESSORGetDirect_0() {
return bevp_ACCESSOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ACCESSORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ACCESSORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DOTGet_0() {
return bevp_DOT;
} /*method end*/
public BEC_2_4_3_MathInt bem_DOTGetDirect_0() {
return bevp_DOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DOTSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BREAKGet_0() {
return bevp_BREAK;
} /*method end*/
public BEC_2_4_3_MathInt bem_BREAKGetDirect_0() {
return bevp_BREAK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BREAKSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BREAKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXGet_0() {
return bevp_IDX;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXGetDirect_0() {
return bevp_IDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXACCGet_0() {
return bevp_IDXACC;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXACCGetDirect_0() {
return bevp_IDXACC;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXACCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXACCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RIDXGet_0() {
return bevp_RIDX;
} /*method end*/
public BEC_2_4_3_MathInt bem_RIDXGetDirect_0() {
return bevp_RIDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RIDXSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RIDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TOKENGet_0() {
return bevp_TOKEN;
} /*method end*/
public BEC_2_4_3_MathInt bem_TOKENGetDirect_0() {
return bevp_TOKEN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TOKENSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TOKENSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUSGet_0() {
return bevp_MODULUS;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUSGetDirect_0() {
return bevp_MODULUS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUSSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGet_0() {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGetDirect_0() {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELIFGet_0() {
return bevp_ELIF;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELIFGetDirect_0() {
return bevp_ELIF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELIFSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELIFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FORGet_0() {
return bevp_FOR;
} /*method end*/
public BEC_2_4_3_MathInt bem_FORGetDirect_0() {
return bevp_FOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FORSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INGet_0() {
return bevp_IN;
} /*method end*/
public BEC_2_4_3_MathInt bem_INGetDirect_0() {
return bevp_IN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CONTINUEGet_0() {
return bevp_CONTINUE;
} /*method end*/
public BEC_2_4_3_MathInt bem_CONTINUEGetDirect_0() {
return bevp_CONTINUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CONTINUESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CONTINUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ATYPEGet_0() {
return bevp_ATYPE;
} /*method end*/
public BEC_2_4_3_MathInt bem_ATYPEGetDirect_0() {
return bevp_ATYPE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ATYPESet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ATYPESetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FSLASHGet_0() {
return bevp_FSLASH;
} /*method end*/
public BEC_2_4_3_MathInt bem_FSLASHGetDirect_0() {
return bevp_FSLASH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FSLASHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FSLASHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 189, 192, 195, 199, 203, 206, 209, 213, 217, 220, 223, 227, 231, 234, 237, 241, 245, 248, 251, 255, 259, 262, 265, 269, 273, 276, 279, 283, 287, 290, 293, 297, 301, 304, 307, 311, 315, 318, 321, 325, 329, 332, 335, 339, 343, 346, 349, 353, 357, 360, 363, 367, 371, 374, 377, 381, 385, 388, 391, 395, 399, 402, 405, 409, 413, 416, 419, 423, 427, 430, 433, 437, 441, 444, 447, 451, 455, 458, 461, 465, 469, 472, 475, 479, 483, 486, 489, 493, 497, 500, 503, 507, 511, 514, 517, 521, 525, 528, 531, 535, 539, 542, 545, 549, 553, 556, 559, 563, 567, 570, 573, 577, 581, 584, 587, 591, 595, 598, 601, 605, 609, 612, 615, 619, 623, 626, 629, 633, 637, 640, 643, 647, 651, 654, 657, 661, 665, 668, 671, 675, 679, 682, 685, 689, 693, 696, 699, 703, 707, 710, 713, 717, 721, 724, 727, 731, 735, 738, 741, 745, 749, 752, 755, 759, 763, 766, 769, 773, 777, 780, 783, 787, 791, 794, 797, 801, 805, 808, 811, 815, 819, 822, 825, 829, 833, 836, 839, 843, 847, 850, 853, 857, 861, 864, 867, 871, 875, 878, 881, 885, 889, 892, 895, 899, 903, 906, 909, 913, 917, 920, 923, 927, 931, 934, 937, 941, 945, 948, 951, 955, 959, 962, 965, 969, 973, 976, 979, 983, 987, 990, 993, 997, 1001, 1004, 1007, 1011, 1015, 1018, 1021, 1025, 1029, 1032, 1035, 1039, 1043, 1046, 1049, 1053, 1057, 1060, 1063, 1067, 1071, 1074, 1077, 1081, 1085, 1088, 1091, 1095, 1099, 1102, 1105, 1109, 1113, 1116, 1119, 1123, 1127, 1130, 1133, 1137, 1141, 1144, 1147, 1151, 1155, 1158, 1161, 1165, 1169, 1172, 1175, 1179, 1183, 1186, 1189, 1193, 1197, 1200, 1203, 1207, 1211, 1214, 1217, 1221, 1225, 1228, 1231, 1235, 1239, 1242, 1245, 1249, 1253, 1256, 1259, 1263, 1267, 1270, 1273, 1277, 1281, 1284, 1287, 1291, 1295, 1298, 1301, 1305, 1309, 1312, 1315, 1319, 1323, 1326, 1329, 1333, 1337, 1340, 1343, 1347, 1351, 1354, 1357, 1361, 1365, 1368, 1371, 1375};
/* BEGIN LINEINFO 
assign 1 12 101
new 0 12 101
assign 1 13 102
new 0 13 102
assign 1 14 103
new 0 14 103
assign 1 15 104
new 0 15 104
assign 1 16 105
new 0 16 105
assign 1 17 106
new 0 17 106
assign 1 18 107
new 0 18 107
assign 1 19 108
new 0 19 108
assign 1 20 109
new 0 20 109
assign 1 21 110
new 0 21 110
assign 1 22 111
new 0 22 111
assign 1 23 112
new 0 23 112
assign 1 24 113
new 0 24 113
assign 1 25 114
new 0 25 114
assign 1 26 115
new 0 26 115
assign 1 27 116
new 0 27 116
assign 1 28 117
new 0 28 117
assign 1 29 118
new 0 29 118
assign 1 30 119
new 0 30 119
assign 1 31 120
new 0 31 120
assign 1 32 121
new 0 32 121
assign 1 33 122
new 0 33 122
assign 1 34 123
new 0 34 123
assign 1 35 124
new 0 35 124
assign 1 36 125
new 0 36 125
assign 1 37 126
new 0 37 126
assign 1 38 127
new 0 38 127
assign 1 39 128
new 0 39 128
assign 1 40 129
new 0 40 129
assign 1 41 130
new 0 41 130
assign 1 42 131
new 0 42 131
assign 1 43 132
new 0 43 132
assign 1 44 133
new 0 44 133
assign 1 45 134
new 0 45 134
assign 1 46 135
new 0 46 135
assign 1 47 136
new 0 47 136
assign 1 48 137
new 0 48 137
assign 1 49 138
new 0 49 138
assign 1 50 139
new 0 50 139
assign 1 51 140
new 0 51 140
assign 1 52 141
new 0 52 141
assign 1 53 142
new 0 53 142
assign 1 54 143
new 0 54 143
assign 1 55 144
new 0 55 144
assign 1 56 145
new 0 56 145
assign 1 57 146
new 0 57 146
assign 1 58 147
new 0 58 147
assign 1 59 148
new 0 59 148
assign 1 60 149
new 0 60 149
assign 1 61 150
new 0 61 150
assign 1 62 151
new 0 62 151
assign 1 63 152
new 0 63 152
assign 1 64 153
new 0 64 153
assign 1 65 154
new 0 65 154
assign 1 66 155
new 0 66 155
assign 1 67 156
new 0 67 156
assign 1 68 157
new 0 68 157
assign 1 69 158
new 0 69 158
assign 1 70 159
new 0 70 159
assign 1 71 160
new 0 71 160
assign 1 72 161
new 0 72 161
assign 1 73 162
new 0 73 162
assign 1 74 163
new 0 74 163
assign 1 75 164
new 0 75 164
assign 1 76 165
new 0 76 165
assign 1 77 166
new 0 77 166
assign 1 78 167
new 0 78 167
assign 1 79 168
new 0 79 168
assign 1 80 169
new 0 80 169
assign 1 81 170
new 0 81 170
assign 1 82 171
new 0 82 171
assign 1 83 172
new 0 83 172
assign 1 84 173
new 0 84 173
assign 1 85 174
new 0 85 174
assign 1 86 175
new 0 86 175
assign 1 87 176
new 0 87 176
assign 1 88 177
new 0 88 177
assign 1 89 178
new 0 89 178
assign 1 90 179
new 0 90 179
assign 1 91 180
new 0 91 180
assign 1 92 181
new 0 92 181
assign 1 93 182
new 0 93 182
assign 1 94 183
new 0 94 183
assign 1 95 184
new 0 95 184
assign 1 96 185
new 0 96 185
return 1 0 189
return 1 0 192
assign 1 0 195
assign 1 0 199
return 1 0 203
return 1 0 206
assign 1 0 209
assign 1 0 213
return 1 0 217
return 1 0 220
assign 1 0 223
assign 1 0 227
return 1 0 231
return 1 0 234
assign 1 0 237
assign 1 0 241
return 1 0 245
return 1 0 248
assign 1 0 251
assign 1 0 255
return 1 0 259
return 1 0 262
assign 1 0 265
assign 1 0 269
return 1 0 273
return 1 0 276
assign 1 0 279
assign 1 0 283
return 1 0 287
return 1 0 290
assign 1 0 293
assign 1 0 297
return 1 0 301
return 1 0 304
assign 1 0 307
assign 1 0 311
return 1 0 315
return 1 0 318
assign 1 0 321
assign 1 0 325
return 1 0 329
return 1 0 332
assign 1 0 335
assign 1 0 339
return 1 0 343
return 1 0 346
assign 1 0 349
assign 1 0 353
return 1 0 357
return 1 0 360
assign 1 0 363
assign 1 0 367
return 1 0 371
return 1 0 374
assign 1 0 377
assign 1 0 381
return 1 0 385
return 1 0 388
assign 1 0 391
assign 1 0 395
return 1 0 399
return 1 0 402
assign 1 0 405
assign 1 0 409
return 1 0 413
return 1 0 416
assign 1 0 419
assign 1 0 423
return 1 0 427
return 1 0 430
assign 1 0 433
assign 1 0 437
return 1 0 441
return 1 0 444
assign 1 0 447
assign 1 0 451
return 1 0 455
return 1 0 458
assign 1 0 461
assign 1 0 465
return 1 0 469
return 1 0 472
assign 1 0 475
assign 1 0 479
return 1 0 483
return 1 0 486
assign 1 0 489
assign 1 0 493
return 1 0 497
return 1 0 500
assign 1 0 503
assign 1 0 507
return 1 0 511
return 1 0 514
assign 1 0 517
assign 1 0 521
return 1 0 525
return 1 0 528
assign 1 0 531
assign 1 0 535
return 1 0 539
return 1 0 542
assign 1 0 545
assign 1 0 549
return 1 0 553
return 1 0 556
assign 1 0 559
assign 1 0 563
return 1 0 567
return 1 0 570
assign 1 0 573
assign 1 0 577
return 1 0 581
return 1 0 584
assign 1 0 587
assign 1 0 591
return 1 0 595
return 1 0 598
assign 1 0 601
assign 1 0 605
return 1 0 609
return 1 0 612
assign 1 0 615
assign 1 0 619
return 1 0 623
return 1 0 626
assign 1 0 629
assign 1 0 633
return 1 0 637
return 1 0 640
assign 1 0 643
assign 1 0 647
return 1 0 651
return 1 0 654
assign 1 0 657
assign 1 0 661
return 1 0 665
return 1 0 668
assign 1 0 671
assign 1 0 675
return 1 0 679
return 1 0 682
assign 1 0 685
assign 1 0 689
return 1 0 693
return 1 0 696
assign 1 0 699
assign 1 0 703
return 1 0 707
return 1 0 710
assign 1 0 713
assign 1 0 717
return 1 0 721
return 1 0 724
assign 1 0 727
assign 1 0 731
return 1 0 735
return 1 0 738
assign 1 0 741
assign 1 0 745
return 1 0 749
return 1 0 752
assign 1 0 755
assign 1 0 759
return 1 0 763
return 1 0 766
assign 1 0 769
assign 1 0 773
return 1 0 777
return 1 0 780
assign 1 0 783
assign 1 0 787
return 1 0 791
return 1 0 794
assign 1 0 797
assign 1 0 801
return 1 0 805
return 1 0 808
assign 1 0 811
assign 1 0 815
return 1 0 819
return 1 0 822
assign 1 0 825
assign 1 0 829
return 1 0 833
return 1 0 836
assign 1 0 839
assign 1 0 843
return 1 0 847
return 1 0 850
assign 1 0 853
assign 1 0 857
return 1 0 861
return 1 0 864
assign 1 0 867
assign 1 0 871
return 1 0 875
return 1 0 878
assign 1 0 881
assign 1 0 885
return 1 0 889
return 1 0 892
assign 1 0 895
assign 1 0 899
return 1 0 903
return 1 0 906
assign 1 0 909
assign 1 0 913
return 1 0 917
return 1 0 920
assign 1 0 923
assign 1 0 927
return 1 0 931
return 1 0 934
assign 1 0 937
assign 1 0 941
return 1 0 945
return 1 0 948
assign 1 0 951
assign 1 0 955
return 1 0 959
return 1 0 962
assign 1 0 965
assign 1 0 969
return 1 0 973
return 1 0 976
assign 1 0 979
assign 1 0 983
return 1 0 987
return 1 0 990
assign 1 0 993
assign 1 0 997
return 1 0 1001
return 1 0 1004
assign 1 0 1007
assign 1 0 1011
return 1 0 1015
return 1 0 1018
assign 1 0 1021
assign 1 0 1025
return 1 0 1029
return 1 0 1032
assign 1 0 1035
assign 1 0 1039
return 1 0 1043
return 1 0 1046
assign 1 0 1049
assign 1 0 1053
return 1 0 1057
return 1 0 1060
assign 1 0 1063
assign 1 0 1067
return 1 0 1071
return 1 0 1074
assign 1 0 1077
assign 1 0 1081
return 1 0 1085
return 1 0 1088
assign 1 0 1091
assign 1 0 1095
return 1 0 1099
return 1 0 1102
assign 1 0 1105
assign 1 0 1109
return 1 0 1113
return 1 0 1116
assign 1 0 1119
assign 1 0 1123
return 1 0 1127
return 1 0 1130
assign 1 0 1133
assign 1 0 1137
return 1 0 1141
return 1 0 1144
assign 1 0 1147
assign 1 0 1151
return 1 0 1155
return 1 0 1158
assign 1 0 1161
assign 1 0 1165
return 1 0 1169
return 1 0 1172
assign 1 0 1175
assign 1 0 1179
return 1 0 1183
return 1 0 1186
assign 1 0 1189
assign 1 0 1193
return 1 0 1197
return 1 0 1200
assign 1 0 1203
assign 1 0 1207
return 1 0 1211
return 1 0 1214
assign 1 0 1217
assign 1 0 1221
return 1 0 1225
return 1 0 1228
assign 1 0 1231
assign 1 0 1235
return 1 0 1239
return 1 0 1242
assign 1 0 1245
assign 1 0 1249
return 1 0 1253
return 1 0 1256
assign 1 0 1259
assign 1 0 1263
return 1 0 1267
return 1 0 1270
assign 1 0 1273
assign 1 0 1277
return 1 0 1281
return 1 0 1284
assign 1 0 1287
assign 1 0 1291
return 1 0 1295
return 1 0 1298
assign 1 0 1301
assign 1 0 1305
return 1 0 1309
return 1 0 1312
assign 1 0 1315
assign 1 0 1319
return 1 0 1323
return 1 0 1326
assign 1 0 1329
assign 1 0 1333
return 1 0 1337
return 1 0 1340
assign 1 0 1343
assign 1 0 1347
return 1 0 1351
return 1 0 1354
assign 1 0 1357
assign 1 0 1361
return 1 0 1365
return 1 0 1368
assign 1 0 1371
assign 1 0 1375
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1690848108: return bem_echo_0();
case -1389370531: return bem_LOGICAL_ANDGetDirect_0();
case -1721272864: return bem_DIVIDEGetDirect_0();
case -731330661: return bem_FORGet_0();
case -1160936393: return bem_ONCEGetDirect_0();
case 1817211361: return bem_VARGetDirect_0();
case -70332712: return bem_GREATER_EQUALSGetDirect_0();
case -1719205062: return bem_CONTINUEGet_0();
case 2120574506: return bem_RIDXGet_0();
case 1365471067: return bem_print_0();
case 620261886: return bem_NULLGet_0();
case -1913375641: return bem_FINALLYGet_0();
case 1535667820: return bem_STRINGLGetDirect_0();
case 1918293439: return bem_IDGetDirect_0();
case -1897759930: return bem_INTLGet_0();
case -837948795: return bem_INCREMENTGet_0();
case 1532728326: return bem_ASGet_0();
case 1226716250: return bem_ADD_ASSIGNGet_0();
case -2073634812: return bem_NOTGet_0();
case 1640332253: return bem_TOKENGetDirect_0();
case -1634564465: return bem_BREAKGet_0();
case -1781686814: return bem_WSTRINGLGetDirect_0();
case 1952541849: return bem_VARGet_0();
case -623875502: return bem_TRYGet_0();
case 1083324837: return bem_PARENSGetDirect_0();
case -1688721927: return bem_WHILEGet_0();
case 1822243872: return bem_GET_METHODGetDirect_0();
case 678762432: return bem_MULTIPLYGetDirect_0();
case 664559305: return bem_LOOPGetDirect_0();
case 478082384: return bem_MULTIPLYGet_0();
case -1372577602: return bem_PROPERTIESGetDirect_0();
case -1930639107: return bem_ACCESSORGetDirect_0();
case -1356121127: return bem_GET_METHODGet_0();
case -1254832154: return bem_SUBTRACT_ASSIGNGet_0();
case -300572500: return bem_WSTRQGet_0();
case -1987025206: return bem_NEWLINEGet_0();
case 1869159231: return bem_EXPRGet_0();
case -912874952: return bem_GREATERGet_0();
case -1287943088: return bem_copy_0();
case -829383971: return bem_NEWLINEGetDirect_0();
case -1625471025: return bem_GREATERGetDirect_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case -348782970: return bem_serializeToString_0();
case -713313886: return bem_SEMIGet_0();
case 1611416307: return bem_FLOATLGetDirect_0();
case 1589442403: return bem_LOOPGet_0();
case -906090368: return bem_USEGet_0();
case 1273959575: return bem_PROPERTIESGet_0();
case 831448950: return bem_COLONGetDirect_0();
case -567950478: return bem_BREAKGetDirect_0();
case -835303456: return bem_many_0();
case 1073217730: return bem_TRYGetDirect_0();
case 1390103972: return bem_INTLGetDirect_0();
case -1951123594: return bem_LOGICAL_ORGet_0();
case 350872746: return bem_ELIFGetDirect_0();
case -501797012: return bem_NOTGetDirect_0();
case -1019338628: return bem_DEFMODGetDirect_0();
case 1329894502: return bem_ONCEGet_0();
case -890848868: return bem_LESSERGetDirect_0();
case 1854075563: return bem_ACCESSORGet_0();
case -885300540: return bem_MULTIPLY_ASSIGNGetDirect_0();
case 1340694490: return bem_new_0();
case -844335532: return bem_NOT_EQUALSGetDirect_0();
case -723069423: return bem_ATYPEGetDirect_0();
case -72163562: return bem_ELIFGet_0();
case -1322194876: return bem_LOGICAL_ORGetDirect_0();
case 805348767: return bem_serializationIteratorGet_0();
case -1338530829: return bem_LESSERGet_0();
case -759713274: return bem_BLOCKGet_0();
case -1135541817: return bem_IDXACCGetDirect_0();
case 2057883855: return bem_ELSEGet_0();
case -1428194621: return bem_IFGetDirect_0();
case 311660510: return bem_DECREMENTGet_0();
case 1874952340: return bem_OR_ASSIGNGetDirect_0();
case 775894747: return bem_PARENSGet_0();
case 1655142078: return bem_NAMEPATHGet_0();
case -1435359618: return bem_DECREMENT_ASSIGNGet_0();
case -723282878: return bem_serializeContents_0();
case 765954147: return bem_STRINGLGet_0();
case -1045627857: return bem_create_0();
case -1304397127: return bem_SUBTRACTGet_0();
case 1043297277: return bem_MANYGet_0();
case 1412826333: return bem_DOTGet_0();
case -1680772760: return bem_FLOATLGet_0();
case -1221950913: return bem_COMMAGet_0();
case -863126031: return bem_DIVIDE_ASSIGNGetDirect_0();
case -1193940311: return bem_FOREACHGet_0();
case -2020513898: return bem_SEMIGetDirect_0();
case 1665923656: return bem_USEGetDirect_0();
case 1292200122: return bem_IDGet_0();
case -1763623993: return bem_DEFMODGet_0();
case -1279635258: return bem_CLASSGetDirect_0();
case 924460854: return bem_AND_ASSIGNGetDirect_0();
case 856916324: return bem_FALSEGet_0();
case -1479496273: return bem_IDXGetDirect_0();
case 1263410727: return bem_STRQGetDirect_0();
case 2130754619: return bem_SPACEGetDirect_0();
case -1480500967: return bem_FSLASHGet_0();
case 1963695386: return bem_toString_0();
case 1093965279: return bem_BRACESGet_0();
case -928170248: return bem_DECREMENT_ASSIGNGetDirect_0();
case -1417926843: return bem_WSTRINGLGet_0();
case 273428455: return bem_IFEMITGetDirect_0();
case 353377191: return bem_classNameGet_0();
case -1182204139: return bem_INCREMENT_ASSIGNGetDirect_0();
case 203856294: return bem_COMMAGetDirect_0();
case 1460252033: return bem_FALSEGetDirect_0();
case -302827085: return bem_CATCHGetDirect_0();
case -884253473: return bem_RBRACESGet_0();
case 237106258: return bem_default_0();
case 1323605146: return bem_INCREMENTGetDirect_0();
case -2091217929: return bem_toAny_0();
case 117750445: return bem_MULTIPLY_ASSIGNGet_0();
case 656419016: return bem_IDXACCGet_0();
case -1805359176: return bem_EMITGetDirect_0();
case -1363077263: return bem_RPARENSGetDirect_0();
case 2124387487: return bem_SUBTRACT_ASSIGNGetDirect_0();
case 561618124: return bem_FINALLYGetDirect_0();
case -1067868302: return bem_DIVIDE_ASSIGNGet_0();
case -1861229100: return bem_ANDGetDirect_0();
case 408295300: return bem_MANYGetDirect_0();
case -1265986004: return bem_COLONGet_0();
case 1314907267: return bem_ASSIGNGetDirect_0();
case 1795035392: return bem_CLASSGet_0();
case 1138905762: return bem_RBRACESGetDirect_0();
case 1080658965: return bem_EMITGet_0();
case -1283054556: return bem_IFGet_0();
case -1738303269: return bem_ORGet_0();
case -209800730: return bem_NAMEPATHGetDirect_0();
case 572690313: return bem_LESSER_EQUALSGet_0();
case 1420975086: return bem_ATYPEGet_0();
case -1723287273: return bem_fieldIteratorGet_0();
case -15030716: return bem_TRANSUNITGet_0();
case 669311967: return bem_EXPRGetDirect_0();
case -2015142660: return bem_BLOCKGetDirect_0();
case -38064962: return bem_ANDGet_0();
case -1904466436: return bem_AND_ASSIGNGet_0();
case 1009677583: return bem_RPARENSGet_0();
case -1720916691: return bem_MODULUSGet_0();
case 328377930: return bem_DECREMENTGetDirect_0();
case 871757188: return bem_ORGetDirect_0();
case 1426474238: return bem_once_0();
case -790361943: return bem_ADD_ASSIGNGetDirect_0();
case 576878938: return bem_TRUEGet_0();
case -996352386: return bem_CALLGetDirect_0();
case 1284894153: return bem_BRACESGetDirect_0();
case 1739753357: return bem_ADDGetDirect_0();
case 372625704: return bem_ELSEGetDirect_0();
case -2096640239: return bem_STRQGet_0();
case -737951023: return bem_EQUALSGet_0();
case 1975921259: return bem_GREATER_EQUALSGet_0();
case 1870273985: return bem_TRUEGetDirect_0();
case -1143607704: return bem_FORGetDirect_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 1608738322: return bem_ADDGet_0();
case -1063254102: return bem_LESSER_EQUALSGetDirect_0();
case -2077497755: return bem_FSLASHGetDirect_0();
case 756642383: return bem_fieldNamesGet_0();
case 1776712568: return bem_iteratorGet_0();
case -1303115743: return bem_hashGet_0();
case -1803746480: return bem_IFEMITGet_0();
case -1498371141: return bem_LOGICAL_ANDGet_0();
case 1595539838: return bem_NOT_EQUALSGet_0();
case 1498986276: return bem_TOKENGet_0();
case -521636825: return bem_METHODGetDirect_0();
case -1121213559: return bem_CATCHGet_0();
case 1838912852: return bem_ASSIGNGet_0();
case 9019251: return bem_OR_ASSIGNGet_0();
case 1618638955: return bem_WHILEGetDirect_0();
case -1059464728: return bem_CALLGet_0();
case -1094593947: return bem_CONTINUEGetDirect_0();
case 2085024539: return bem_FOREACHGetDirect_0();
case -707783127: return bem_DOTGetDirect_0();
case -451656686: return bem_SUBTRACTGetDirect_0();
case 686418158: return bem_MODULUS_ASSIGNGetDirect_0();
case -1459761673: return bem_EQUALSGetDirect_0();
case -262484470: return bem_INGet_0();
case -856707590: return bem_tagGet_0();
case -1561242314: return bem_NULLGetDirect_0();
case 599721863: return bem_ASGetDirect_0();
case 1741472352: return bem_MODULUS_ASSIGNGet_0();
case 1344897069: return bem_DIVIDEGet_0();
case -1692402748: return bem_INGetDirect_0();
case 178468059: return bem_MODULUSGetDirect_0();
case -639033254: return bem_RIDXGetDirect_0();
case 1661783340: return bem_METHODGet_0();
case 12141392: return bem_INCREMENT_ASSIGNGet_0();
case 1262296343: return bem_TRANSUNITGetDirect_0();
case -581692165: return bem_IDXGet_0();
case -830443482: return bem_WSTRQGetDirect_0();
case 1354723473: return bem_SPACEGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1412377002: return bem_undef_1(bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case -895575467: return bem_SUBTRACT_ASSIGNSetDirect_1(bevd_0);
case -897704133: return bem_PARENSSetDirect_1(bevd_0);
case -345174663: return bem_EQUALSSetDirect_1(bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case -1588928453: return bem_SPACESetDirect_1(bevd_0);
case 859074959: return bem_BLOCKSet_1(bevd_0);
case 574784360: return bem_TRANSUNITSet_1(bevd_0);
case 515318482: return bem_OR_ASSIGNSet_1(bevd_0);
case -996631064: return bem_USESetDirect_1(bevd_0);
case 1240862006: return bem_ACCESSORSet_1(bevd_0);
case 172694635: return bem_SUBTRACT_ASSIGNSet_1(bevd_0);
case 115484625: return bem_NOTSet_1(bevd_0);
case 110293352: return bem_GET_METHODSet_1(bevd_0);
case -1489030733: return bem_LOOPSetDirect_1(bevd_0);
case -1177266118: return bem_TRYSetDirect_1(bevd_0);
case -2015246793: return bem_MODULUSSet_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2146326831: return bem_WSTRINGLSet_1(bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case 1643116511: return bem_TRUESetDirect_1(bevd_0);
case -1362990087: return bem_WHILESet_1(bevd_0);
case 1653474362: return bem_AND_ASSIGNSet_1(bevd_0);
case 1935422252: return bem_IFSetDirect_1(bevd_0);
case 400873963: return bem_RIDXSet_1(bevd_0);
case -1105652150: return bem_LOOPSet_1(bevd_0);
case -793887534: return bem_otherClass_1(bevd_0);
case 342844765: return bem_TOKENSetDirect_1(bevd_0);
case -670707755: return bem_TRYSet_1(bevd_0);
case -1890649112: return bem_RBRACESSet_1(bevd_0);
case 222513559: return bem_DEFMODSetDirect_1(bevd_0);
case -1424023160: return bem_LOGICAL_ANDSet_1(bevd_0);
case -952472674: return bem_FSLASHSetDirect_1(bevd_0);
case -1886162298: return bem_METHODSet_1(bevd_0);
case -1004959954: return bem_GREATERSet_1(bevd_0);
case 1109593123: return bem_ONCESet_1(bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case 939269502: return bem_FOREACHSetDirect_1(bevd_0);
case -1850356898: return bem_GREATERSetDirect_1(bevd_0);
case 1378992588: return bem_LOGICAL_ORSetDirect_1(bevd_0);
case -1822011004: return bem_ADDSetDirect_1(bevd_0);
case -733568605: return bem_ADD_ASSIGNSetDirect_1(bevd_0);
case 888867555: return bem_DIVIDE_ASSIGNSetDirect_1(bevd_0);
case -1778081874: return bem_INCREMENTSet_1(bevd_0);
case 1451469419: return bem_SUBTRACTSet_1(bevd_0);
case -1874594501: return bem_DECREMENTSet_1(bevd_0);
case -620585317: return bem_AND_ASSIGNSetDirect_1(bevd_0);
case 453482585: return bem_DECREMENT_ASSIGNSetDirect_1(bevd_0);
case -1143968397: return bem_INTLSetDirect_1(bevd_0);
case -2099046998: return bem_STRINGLSetDirect_1(bevd_0);
case 854135831: return bem_DECREMENT_ASSIGNSet_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -424081770: return bem_MULTIPLYSetDirect_1(bevd_0);
case 1040924040: return bem_ONCESetDirect_1(bevd_0);
case -672026990: return bem_COLONSet_1(bevd_0);
case -2095562377: return bem_DECREMENTSetDirect_1(bevd_0);
case 1616493336: return bem_BRACESSetDirect_1(bevd_0);
case -345330811: return bem_INCREMENT_ASSIGNSetDirect_1(bevd_0);
case -811100454: return bem_RIDXSetDirect_1(bevd_0);
case -1839316740: return bem_CONTINUESet_1(bevd_0);
case 1615882132: return bem_NEWLINESet_1(bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case -480348635: return bem_def_1(bevd_0);
case -2032022419: return bem_COMMASet_1(bevd_0);
case -1713884268: return bem_IDXACCSetDirect_1(bevd_0);
case 387178011: return bem_GREATER_EQUALSSet_1(bevd_0);
case -2045321924: return bem_INSetDirect_1(bevd_0);
case -755175206: return bem_IDXSetDirect_1(bevd_0);
case 1431948827: return bem_EQUALSSet_1(bevd_0);
case -340176936: return bem_NEWLINESetDirect_1(bevd_0);
case 742170595: return bem_WHILESetDirect_1(bevd_0);
case -904100653: return bem_RBRACESSetDirect_1(bevd_0);
case 1963148365: return bem_ADD_ASSIGNSet_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -517119351: return bem_EXPRSetDirect_1(bevd_0);
case -1257740302: return bem_FINALLYSetDirect_1(bevd_0);
case 1655929676: return bem_ASSetDirect_1(bevd_0);
case 1674473210: return bem_NOT_EQUALSSetDirect_1(bevd_0);
case 180568035: return bem_ELIFSetDirect_1(bevd_0);
case -927869743: return bem_SEMISetDirect_1(bevd_0);
case -1274471741: return bem_LESSER_EQUALSSetDirect_1(bevd_0);
case -1851623547: return bem_TOKENSet_1(bevd_0);
case 1850996750: return bem_LESSER_EQUALSSet_1(bevd_0);
case 154505989: return bem_PROPERTIESSetDirect_1(bevd_0);
case -668207639: return bem_EMITSet_1(bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 807746507: return bem_DIVIDESet_1(bevd_0);
case 941066916: return bem_ATYPESet_1(bevd_0);
case 1112008093: return bem_WSTRQSet_1(bevd_0);
case 1770666401: return bem_DIVIDESetDirect_1(bevd_0);
case 2019101904: return bem_BLOCKSetDirect_1(bevd_0);
case 58157975: return bem_ELIFSet_1(bevd_0);
case 1310445014: return bem_FLOATLSetDirect_1(bevd_0);
case 2008573469: return bem_DIVIDE_ASSIGNSet_1(bevd_0);
case 1428104576: return bem_BREAKSetDirect_1(bevd_0);
case 567161719: return bem_INSet_1(bevd_0);
case -1522801953: return bem_NOT_EQUALSSet_1(bevd_0);
case -1164569961: return bem_IDSet_1(bevd_0);
case -227172313: return bem_VARSetDirect_1(bevd_0);
case -575639222: return bem_NAMEPATHSetDirect_1(bevd_0);
case -1445512535: return bem_DEFMODSet_1(bevd_0);
case 987841759: return bem_ASSet_1(bevd_0);
case -600410511: return bem_STRQSetDirect_1(bevd_0);
case -1643741518: return bem_TRUESet_1(bevd_0);
case -722231218: return bem_BREAKSet_1(bevd_0);
case 1592694092: return bem_CLASSSet_1(bevd_0);
case 661527241: return bem_IFEMITSet_1(bevd_0);
case 1832140235: return bem_CATCHSet_1(bevd_0);
case 582633516: return bem_LOGICAL_ANDSetDirect_1(bevd_0);
case -1739813590: return bem_PROPERTIESSet_1(bevd_0);
case -2002451523: return bem_STRINGLSet_1(bevd_0);
case 2121386411: return bem_ELSESetDirect_1(bevd_0);
case 1489432541: return bem_SPACESet_1(bevd_0);
case 97004765: return bem_INTLSet_1(bevd_0);
case -1771088803: return bem_CLASSSetDirect_1(bevd_0);
case 870443063: return bem_NAMEPATHSet_1(bevd_0);
case 2121889177: return bem_ADDSet_1(bevd_0);
case 1653609255: return bem_METHODSetDirect_1(bevd_0);
case 1629402755: return bem_ANDSetDirect_1(bevd_0);
case -265733619: return bem_LESSERSetDirect_1(bevd_0);
case -295398328: return bem_MODULUS_ASSIGNSetDirect_1(bevd_0);
case -786953907: return bem_IFEMITSetDirect_1(bevd_0);
case -1010025495: return bem_STRQSet_1(bevd_0);
case -1757060337: return bem_EXPRSet_1(bevd_0);
case -470420017: return bem_ASSIGNSet_1(bevd_0);
case 1444327645: return bem_MODULUSSetDirect_1(bevd_0);
case -1082173451: return bem_FALSESetDirect_1(bevd_0);
case 2129603513: return bem_defined_1(bevd_0);
case 1197176861: return bem_ORSet_1(bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
case 551262636: return bem_IDSetDirect_1(bevd_0);
case -656879447: return bem_ELSESet_1(bevd_0);
case 413824565: return bem_RPARENSSetDirect_1(bevd_0);
case 1692254393: return bem_CALLSet_1(bevd_0);
case 2096497722: return bem_NOTSetDirect_1(bevd_0);
case 911539606: return bem_LESSERSet_1(bevd_0);
case 1589033139: return bem_SEMISet_1(bevd_0);
case 1520307955: return bem_ASSIGNSetDirect_1(bevd_0);
case 1304922536: return bem_GET_METHODSetDirect_1(bevd_0);
case -1072712640: return bem_OR_ASSIGNSetDirect_1(bevd_0);
case -923976546: return bem_FLOATLSet_1(bevd_0);
case 402182275: return bem_CALLSetDirect_1(bevd_0);
case -1131914801: return bem_ANDSet_1(bevd_0);
case 784257791: return bem_NULLSet_1(bevd_0);
case 932801511: return bem_RPARENSSet_1(bevd_0);
case -1928966911: return bem_FALSESet_1(bevd_0);
case -973165356: return bem_VARSet_1(bevd_0);
case -1382060124: return bem_MANYSetDirect_1(bevd_0);
case -553404011: return bem_ACCESSORSetDirect_1(bevd_0);
case 457623730: return bem_DOTSet_1(bevd_0);
case 2040799176: return bem_CATCHSetDirect_1(bevd_0);
case -615026574: return bem_MULTIPLYSet_1(bevd_0);
case 643782105: return bem_MODULUS_ASSIGNSet_1(bevd_0);
case -1049927577: return bem_COMMASetDirect_1(bevd_0);
case -550139783: return bem_otherType_1(bevd_0);
case -392352251: return bem_FSLASHSet_1(bevd_0);
case -2122622302: return bem_PARENSSet_1(bevd_0);
case 1386674484: return bem_TRANSUNITSetDirect_1(bevd_0);
case 882958311: return bem_MULTIPLY_ASSIGNSetDirect_1(bevd_0);
case 143997498: return bem_INCREMENT_ASSIGNSet_1(bevd_0);
case 2075940824: return bem_IFSet_1(bevd_0);
case 405822453: return bem_BRACESSet_1(bevd_0);
case -1229768259: return bem_FINALLYSet_1(bevd_0);
case -809777218: return bem_CONTINUESetDirect_1(bevd_0);
case 1911388769: return bem_SUBTRACTSetDirect_1(bevd_0);
case -266457440: return bem_IDXACCSet_1(bevd_0);
case 547219990: return bem_FOREACHSet_1(bevd_0);
case -937431549: return bem_NULLSetDirect_1(bevd_0);
case -988901024: return bem_WSTRINGLSetDirect_1(bevd_0);
case -519798795: return bem_DOTSetDirect_1(bevd_0);
case 414278183: return bem_GREATER_EQUALSSetDirect_1(bevd_0);
case 433200281: return bem_INCREMENTSetDirect_1(bevd_0);
case -1014209134: return bem_COLONSetDirect_1(bevd_0);
case 361713419: return bem_ORSetDirect_1(bevd_0);
case 72395934: return bem_LOGICAL_ORSet_1(bevd_0);
case -943476326: return bem_EMITSetDirect_1(bevd_0);
case 372313337: return bem_USESet_1(bevd_0);
case 1629717208: return bem_FORSetDirect_1(bevd_0);
case -1876874263: return bem_IDXSet_1(bevd_0);
case 2130702803: return bem_FORSet_1(bevd_0);
case -575839151: return bem_ATYPESetDirect_1(bevd_0);
case -995249963: return bem_MANYSet_1(bevd_0);
case 1983865787: return bem_WSTRQSetDirect_1(bevd_0);
case -402449769: return bem_MULTIPLY_ASSIGNSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildNodeTypes_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildNodeTypes_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildNodeTypes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst = (BEC_2_5_9_BuildNodeTypes) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_type;
}
}
}
