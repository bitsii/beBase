namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_10_XmlEndElement : BEC_2_3_3_XmlTag {
public BEC_2_3_10_XmlEndElement() { }
static BEC_2_3_10_XmlEndElement() { }
private static byte[] becc_BEC_2_3_10_XmlEndElement_clname = {0x58,0x6D,0x6C,0x3A,0x45,0x6E,0x64,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_10_XmlEndElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_0 = {0x3C,0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_10_XmlEndElement_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_3_10_XmlEndElement_bels_0, 2));
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_1 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_10_XmlEndElement_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_3_10_XmlEndElement_bels_1, 1));
public static new BEC_2_3_10_XmlEndElement bece_BEC_2_3_10_XmlEndElement_bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_3_10_XmlEndElement_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_3_tmpany_phold = bece_BEC_2_3_10_XmlEndElement_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_3_10_XmlEndElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {78, 78, 78, 78, 78, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 26, 29, 32};
/* BEGIN LINEINFO 
assign 1 78 22
new 0 78 22
assign 1 78 23
add 1 78 23
assign 1 78 24
new 0 78 24
assign 1 78 25
add 1 78 25
return 1 78 26
return 1 0 29
assign 1 0 32
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1170883362: return bem_deserializeClassNameGet_0();
case -869030838: return bem_hashGet_0();
case -694642189: return bem_serializationIteratorGet_0();
case 716581775: return bem_fieldIteratorGet_0();
case 1276785109: return bem_once_0();
case -838633237: return bem_serializeToString_0();
case -327890059: return bem_toString_0();
case 1885938794: return bem_toAny_0();
case 1778404598: return bem_tagGet_0();
case 1207509984: return bem_print_0();
case -864977132: return bem_echo_0();
case -1626502172: return bem_iteratorGet_0();
case -231534902: return bem_new_0();
case 1964495741: return bem_serializeContents_0();
case -108593702: return bem_sourceFileNameGet_0();
case -296700272: return bem_create_0();
case -640694898: return bem_many_0();
case -2071511275: return bem_nameGet_0();
case -1470416551: return bem_copy_0();
case 498230251: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1697977276: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1849236093: return bem_nameSet_1(bevd_0);
case -898771829: return bem_otherType_1(bevd_0);
case 1971930884: return bem_notEquals_1(bevd_0);
case 871367475: return bem_def_1(bevd_0);
case -1118008475: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2022931262: return bem_defined_1(bevd_0);
case 873867702: return bem_undef_1(bevd_0);
case -996916931: return bem_copyTo_1(bevd_0);
case -341054699: return bem_undefined_1(bevd_0);
case 1349020478: return bem_sameObject_1(bevd_0);
case 1029744872: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1805705632: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1363115649: return bem_equals_1(bevd_0);
case 41506532: return bem_otherClass_1(bevd_0);
case -1237205225: return bem_sameClass_1(bevd_0);
case -1073870688: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 508127182: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1597816100: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -282965627: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1721714391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -48765507: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1009765426: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1302207765: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_3_10_XmlEndElement_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_10_XmlEndElement_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_10_XmlEndElement();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst = (BEC_2_3_10_XmlEndElement) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst;
}
}
}
