namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_10_XmlEndElement : BEC_2_3_3_XmlTag {
public BEC_2_3_10_XmlEndElement() { }
static BEC_2_3_10_XmlEndElement() { }
private static byte[] becc_BEC_2_3_10_XmlEndElement_clname = {0x58,0x6D,0x6C,0x3A,0x45,0x6E,0x64,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_10_XmlEndElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_0 = {0x3C,0x2F};
private static byte[] bece_BEC_2_3_10_XmlEndElement_bels_1 = {0x3E};
public static new BEC_2_3_10_XmlEndElement bece_BEC_2_3_10_XmlEndElement_bevs_inst;

public static new BET_2_3_10_XmlEndElement bece_BEC_2_3_10_XmlEndElement_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_10_XmlEndElement_bels_0));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_10_XmlEndElement_bels_1));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_3_10_XmlEndElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlEndElement bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {77, 77, 77, 77, 77, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 26, 27, 30, 33, 36, 40};
/* BEGIN LINEINFO 
assign 1 77 23
new 0 77 23
assign 1 77 24
add 1 77 24
assign 1 77 25
new 0 77 25
assign 1 77 26
add 1 77 26
return 1 77 27
return 1 0 30
return 1 0 33
assign 1 0 36
assign 1 0 40
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1980166000: return bem_nameGetDirect_0();
case 1562608535: return bem_print_0();
case 1688687204: return bem_serializeToString_0();
case 1029695809: return bem_echo_0();
case -1844917728: return bem_many_0();
case -1026733174: return bem_new_0();
case -1902089216: return bem_toString_0();
case 102554564: return bem_fieldIteratorGet_0();
case -479166709: return bem_tagGet_0();
case 185174991: return bem_copy_0();
case -1848718184: return bem_hashGet_0();
case 126670515: return bem_toAny_0();
case -31114048: return bem_iteratorGet_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -8643043: return bem_serializeContents_0();
case -119388582: return bem_nameGet_0();
case 1137009070: return bem_once_0();
case -785258946: return bem_create_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 217968364: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 2001682630: return bem_nameSetDirect_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 1620876864: return bem_nameSet_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_3_10_XmlEndElement_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_10_XmlEndElement_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_10_XmlEndElement();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst = (BEC_2_3_10_XmlEndElement) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_10_XmlEndElement.bece_BEC_2_3_10_XmlEndElement_bevs_type;
}
}
}
