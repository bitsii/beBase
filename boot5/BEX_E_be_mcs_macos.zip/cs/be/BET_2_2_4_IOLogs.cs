namespace be {
public class BET_2_2_4_IOLogs : BETS_Object {
public BET_2_2_4_IOLogs() {
string[] bevs_mtnames = new string[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "default_0", "setDefaultLevels_2", "putKeyLevels_3", "putLevels_3", "getKey_1", "get_1", "turnOn_1", "turnOnAll_0", "setAllSinks_1", "debugGet_0", "debugGetDirect_0", "debugSet_1", "debugSetDirect_1", "infoGet_0", "infoGetDirect_0", "infoSet_1", "infoSetDirect_1", "warnGet_0", "warnGetDirect_0", "warnSet_1", "warnSetDirect_1", "errorGet_0", "errorGetDirect_0", "errorSet_1", "errorSetDirect_1", "fatalGet_0", "fatalGetDirect_0", "fatalSet_1", "fatalSetDirect_1", "overridesGet_0", "overridesGetDirect_0", "overridesSet_1", "overridesSetDirect_1", "loggersGet_0", "loggersGetDirect_0", "loggersSet_1", "loggersSetDirect_1", "lockGet_0", "lockGetDirect_0", "lockSet_1", "lockSetDirect_1", "defaultOutputLevelGet_0", "defaultOutputLevelGetDirect_0", "defaultOutputLevelSet_1", "defaultOutputLevelSetDirect_1", "defaultLevelGet_0", "defaultLevelGetDirect_0", "defaultLevelSet_1", "defaultLevelSetDirect_1", "sinkGet_0", "sinkGetDirect_0", "sinkSet_1", "sinkSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "debug", "info", "warn", "error", "fatal", "overrides", "loggers", "lock", "defaultOutputLevel", "defaultLevel", "sink" };
}
static BET_2_2_4_IOLogs() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_2_4_IOLogs();
}
}
}
