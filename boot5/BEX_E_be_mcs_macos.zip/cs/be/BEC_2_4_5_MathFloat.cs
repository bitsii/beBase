namespace be {
/* IO:File: source/base/Float.be */
public sealed class BEC_2_4_5_MathFloat : BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }
static BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
public static new BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static new BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_5_MathFloat bevt_21_ta_ph = null;
BEC_2_4_5_MathFloat bevt_22_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_ta_ph = beva_si.bemd_1(367251836, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 64*/ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(-1034868642, bevt_2_ta_ph);
} /* Line: 66*/
 else /* Line: 67*/ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 68*/
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(-312701209, bevt_3_ta_ph);
if (bevl_dec == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_dec.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_7_ta_ph = beva_si.bemd_2(654782849, bevt_8_ta_ph, bevl_dec);
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_ta_ph);
} /* Line: 73*/
 else /* Line: 74*/ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 75*/
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_10_ta_ph = bevl_dec.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = beva_si.bemd_0(942868024);
bevt_9_ta_ph = bevt_10_ta_ph.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_ta_ph );
if (bevt_9_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_15_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_14_ta_ph = bevl_dec.bem_add_1(bevt_15_ta_ph);
bevt_13_ta_ph = beva_si.bemd_1(-1034868642, bevt_14_ta_ph);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_ta_ph);
} /* Line: 78*/
 else /* Line: 79*/ {
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 80*/
} /* Line: 77*/
 else /* Line: 82*/ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 84*/
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_18_ta_ph = bevl_rhs.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bem_sizeGet_0();
bevl_divby = bevt_16_ta_ph.bem_power_1(bevt_17_ta_ph);
if (bevl_neg.bevi_bool)/* Line: 87*/ {
bevt_19_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_ta_ph);
} /* Line: 89*/
bevt_21_ta_ph = bevl_rhs.bem_toFloat_0();
bevt_22_ta_ph = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_ta_ph.bem_divide_1(bevt_22_ta_ph);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toInt_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
BEC_2_4_5_MathFloat bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_lhi = bem_toInt_0();
bevt_0_ta_ph = bevl_lhi.bem_toFloat_0();
bevl_rh = bem_subtract_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_ta_ph);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_ta_ph = bevl_lhi.bem_toString_0();
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = bevl_rhi.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 144*/ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 156*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 164*/ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 176*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 184*/ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 196*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 204*/ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 216*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 224*/ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 236*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
/* Line: 244*/ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 256*/
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float == bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float != bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {64, 64, 65, 66, 66, 68, 70, 70, 71, 71, 72, 72, 72, 73, 73, 73, 75, 77, 77, 77, 77, 78, 78, 78, 78, 80, 83, 84, 86, 86, 86, 86, 88, 88, 89, 89, 91, 91, 91, 92, 93, 94, 97, 97, 100, 100, 104, 108, 108, 119, 127, 132, 132, 136, 137, 137, 138, 138, 139, 140, 140, 140, 140, 140, 140, 145, 156, 165, 176, 185, 196, 205, 216, 225, 236, 245, 256, 264, 264, 306, 306, 348, 348, 376, 376, 404, 404, 432, 432, 460, 460};
public static new int[] bevs_smnlec
 = new int[] {60, 61, 63, 64, 65, 68, 70, 71, 72, 77, 78, 79, 84, 85, 86, 87, 90, 92, 93, 94, 95, 97, 98, 99, 100, 103, 107, 108, 110, 111, 112, 113, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 129, 130, 134, 135, 138, 143, 144, 148, 149, 153, 154, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 184, 187, 194, 197, 204, 207, 214, 217, 224, 227, 234, 237, 242, 243, 253, 254, 264, 265, 274, 275, 284, 285, 294, 295, 304, 305};
/* BEGIN LINEINFO 
assign 1 64 60
new 0 64 60
assign 1 64 61
begins 1 64 61
assign 1 65 63
new 0 65 63
assign 1 66 64
new 0 66 64
assign 1 66 65
substring 1 66 65
assign 1 68 68
new 0 68 68
assign 1 70 70
new 0 70 70
assign 1 70 71
find 1 70 71
assign 1 71 72
def 1 71 77
assign 1 72 78
new 0 72 78
assign 1 72 79
greater 1 72 84
assign 1 73 85
new 0 73 85
assign 1 73 86
substring 2 73 86
assign 1 73 87
new 1 73 87
assign 1 75 90
new 0 75 90
assign 1 77 92
new 0 77 92
assign 1 77 93
add 1 77 93
assign 1 77 94
sizeGet 0 77 94
assign 1 77 95
lesser 1 77 95
assign 1 78 97
new 0 78 97
assign 1 78 98
add 1 78 98
assign 1 78 99
substring 1 78 99
assign 1 78 100
new 1 78 100
assign 1 80 103
new 0 80 103
assign 1 83 107
new 1 83 107
assign 1 84 108
new 0 84 108
assign 1 86 110
new 0 86 110
assign 1 86 111
toString 0 86 111
assign 1 86 112
sizeGet 0 86 112
assign 1 86 113
power 1 86 113
assign 1 88 115
new 0 88 115
multiplyValue 1 88 116
assign 1 89 117
new 0 89 117
multiplyValue 1 89 118
assign 1 91 120
toFloat 0 91 120
assign 1 91 121
toFloat 0 91 121
assign 1 91 122
divide 1 91 122
assign 1 92 123
toFloat 0 92 123
assign 1 93 124
add 1 93 124
return 1 94 125
assign 1 97 129
new 0 97 129
return 1 97 130
assign 1 100 134
toString 0 100 134
return 1 100 135
new 1 104 138
assign 1 108 143
new 0 108 143
return 1 108 144
assign 1 119 148
new 0 119 148
return 1 127 149
assign 1 132 153
toInt 0 132 153
return 1 132 154
assign 1 136 167
toInt 0 136 167
assign 1 137 168
toFloat 0 137 168
assign 1 137 169
subtract 1 137 169
assign 1 138 170
new 0 138 170
assign 1 138 171
multiply 1 138 171
assign 1 139 172
toInt 0 139 172
assign 1 140 173
toString 0 140 173
assign 1 140 174
new 0 140 174
assign 1 140 175
add 1 140 175
assign 1 140 176
toString 0 140 176
assign 1 140 177
add 1 140 177
return 1 140 178
assign 1 145 184
new 0 145 184
return 1 156 187
assign 1 165 194
new 0 165 194
return 1 176 197
assign 1 185 204
new 0 185 204
return 1 196 207
assign 1 205 214
new 0 205 214
return 1 216 217
assign 1 225 224
new 0 225 224
return 1 236 227
assign 1 245 234
new 0 245 234
return 1 256 237
assign 1 264 242
new 0 264 242
return 1 264 243
assign 1 306 253
new 0 306 253
return 1 306 254
assign 1 348 264
new 0 348 264
return 1 348 265
assign 1 376 274
new 0 376 274
return 1 376 275
assign 1 404 284
new 0 404 284
return 1 404 285
assign 1 432 294
new 0 432 294
return 1 432 295
assign 1 460 304
new 0 460 304
return 1 460 305
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1688687204: return bem_serializeToString_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1029695809: return bem_echo_0();
case -479166709: return bem_tagGet_0();
case 126670515: return bem_toAny_0();
case -1902089216: return bem_toString_0();
case -1844917728: return bem_many_0();
case -1779062531: return bem_serializationIteratorGet_0();
case 1562608535: return bem_print_0();
case -8643043: return bem_serializeContents_0();
case -785258946: return bem_create_0();
case -31114048: return bem_iteratorGet_0();
case 567722655: return bem_vfloatGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 1726192558: return bem_vfloatSet_0();
case 754751963: return bem_increment_0();
case 102554564: return bem_fieldIteratorGet_0();
case 217968364: return bem_classNameGet_0();
case 1137009070: return bem_once_0();
case -1026733174: return bem_new_0();
case 1016538274: return bem_toInt_0();
case 1176473379: return bem_decrement_0();
case -1725405782: return bem_sourceFileNameGet_0();
case -1848718184: return bem_hashGet_0();
case 185174991: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1057358062: return bem_otherType_1(bevd_0);
case -128042273: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -1581256201: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 973522576: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 926458045: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case 1415352188: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case 2053451306: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case -2126240104: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 1951191518: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case 389177729: return bem_new_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1508355839: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_MathFloat();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
}
