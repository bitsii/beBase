namespace be {
/* IO:File: source/build/CEmitter.be */
public sealed class BEC_2_5_9_BuildClassInfo : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
static BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x46,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x58,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x42,0x45,0x4B,0x5F};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x2E,0x68};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x2E,0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x2E,0x73,0x79,0x6E};
public static new BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;

public static new BET_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_ta_ph = bevp_emitter.bemd_0(1878268220);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_ph.bemd_0(-50186538);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_ta_ph = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(138455959, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_0));
bevp_incBlock = bevt_2_ta_ph.bem_add_1(bevp_midName);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevp_midName);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildClassInfo_bels_2));
bevp_mtdName = bevt_3_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_midName);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildClassInfo_bels_4));
bevp_cldefName = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_midName);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_5));
bevp_shClassName = bevt_9_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevp_midName);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildClassInfo_bels_6));
bevp_shFileName = bevt_12_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_15_ta_ph = bevt_16_ta_ph.bem_add_1(bevp_midName);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildClassInfo_bels_4));
bevp_cldefBuild = bevt_15_ta_ph.bem_add_1(bevt_17_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevp_midName);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_8));
bevp_libnameInit = bevt_18_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevp_midName);
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_9));
bevp_libnameInitDone = bevt_21_ta_ph.bem_add_1(bevt_23_ta_ph);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_24_ta_ph = bevt_25_ta_ph.bem_add_1(bevp_midName);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_10));
bevp_libnameData = bevt_24_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(bevp_midName);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_11));
bevp_libnameDataDone = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevp_midName);
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildClassInfo_bels_12));
bevp_libnameDataClear = bevt_30_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_7));
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevp_midName);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildClassInfo_bels_13));
bevp_libNotNullInit = bevt_33_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_3));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_midName);
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildClassInfo_bels_14));
bevp_libNotNullInitDone = bevt_36_ta_ph.bem_add_1(bevt_38_ta_ph);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_copy_0();
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_15));
bevp_xbase = bevt_39_ta_ph.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_16));
bevp_kbase = bevt_40_ta_ph.bem_add_1(bevp_clBase);
bevt_41_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_42_ta_ph = bevp_nbase.bem_add_1(bevt_43_ta_ph);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_ta_ph.bem_addStep_1(bevt_42_ta_ph);
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_ta_ph);
bevt_45_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_46_ta_ph = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_ta_ph.bem_addStep_1(bevt_46_ta_ph);
bevt_47_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_48_ta_ph = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_ta_ph.bem_addStep_1(bevt_48_ta_ph);
bevt_49_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_51_ta_ph = bevp_cpro.bem_libExtGet_0();
bevt_50_ta_ph = bevp_lbase.bem_add_1(bevt_51_ta_ph);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_ta_ph.bem_addStep_1(bevt_50_ta_ph);
bevt_52_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_54_ta_ph = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_ta_ph = bevp_lbase.bem_add_1(bevt_54_ta_ph);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_ta_ph.bem_addStep_1(bevt_53_ta_ph);
bevt_55_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_57_ta_ph = bevp_cpro.bem_exeExtGet_0();
bevt_56_ta_ph = beva__exeName.bem_add_1(bevt_57_ta_ph);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_ta_ph.bem_addStep_1(bevt_56_ta_ph);
bevt_58_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_59_ta_ph = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_ta_ph.bem_addStep_1(bevt_59_ta_ph);
bevt_60_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_61_ta_ph = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_ta_ph.bem_addStep_1(bevt_61_ta_ph);
bevt_62_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_64_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildClassInfo_bels_18));
bevt_63_ta_ph = bevp_xbase.bem_add_1(bevt_64_ta_ph);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_ta_ph.bem_addStep_1(bevt_63_ta_ph);
bevt_65_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_66_ta_ph = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_ta_ph.bem_addStep_1(bevt_66_ta_ph);
bevt_67_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_68_ta_ph = bevp_kbase.bem_add_1(bevt_69_ta_ph);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_ta_ph.bem_addStep_1(bevt_68_ta_ph);
bevt_70_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_nsDir.bem_copy_0();
bevt_72_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildClassInfo_bels_17));
bevt_71_ta_ph = bevp_kbase.bem_add_1(bevt_72_ta_ph);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_ta_ph.bem_addStep_1(bevt_71_ta_ph);
bevt_73_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_74_ta_ph = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_ta_ph.bem_addStep_1(bevt_74_ta_ph);
bevt_75_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_77_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildClassInfo_bels_19));
bevt_76_ta_ph = bevp_kbase.bem_add_1(bevt_77_ta_ph);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_ta_ph.bem_addStep_1(bevt_76_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(-178385347);
while (true)
/* Line: 110*/ {
bevt_0_ta_ph = bevl_i.bemd_0(36836391);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 110*/ {
bevt_1_ta_ph = bevl_i.bemd_0(528131764);
bevp_nsDir.bem_addStep_1(bevt_1_ta_ph);
} /* Line: 111*/
 else /* Line: 110*/ {
break;
} /* Line: 110*/
} /* Line: 110*/
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGetDirect_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() {
return bevp_cpro;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGetDirect_0() {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() {
return bevp_npar;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGetDirect_0() {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() {
return bevp_nparSteps;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGetDirect_0() {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nparSteps = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nparSteps = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() {
return bevp_clName;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGetDirect_0() {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() {
return bevp_clBase;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGetDirect_0() {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() {
return bevp_midName;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGetDirect_0() {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() {
return bevp_incBlock;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGetDirect_0() {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() {
return bevp_mtdName;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGetDirect_0() {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() {
return bevp_cldefName;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGetDirect_0() {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() {
return bevp_shClassName;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGetDirect_0() {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() {
return bevp_shFileName;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGetDirect_0() {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGetDirect_0() {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() {
return bevp_libnameInit;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGetDirect_0() {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGetDirect_0() {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() {
return bevp_libnameData;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGetDirect_0() {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGetDirect_0() {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGetDirect_0() {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGetDirect_0() {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGetDirect_0() {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGetDirect_0() {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() {
return bevp_cuBase;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGetDirect_0() {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() {
return bevp_nsDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGetDirect_0() {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() {
return bevp_xbase;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGetDirect_0() {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() {
return bevp_lbase;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGetDirect_0() {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() {
return bevp_nbase;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGetDirect_0() {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() {
return bevp_kbase;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGetDirect_0() {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() {
return bevp_cuinitH;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGetDirect_0() {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() {
return bevp_namesIncH;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGetDirect_0() {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() {
return bevp_cuinit;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGetDirect_0() {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() {
return bevp_namesO;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGetDirect_0() {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() {
return bevp_unitShlib;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGetDirect_0() {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() {
return bevp_unitExeLink;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGetDirect_0() {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() {
return bevp_unitExe;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGetDirect_0() {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() {
return bevp_classExeSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGetDirect_0() {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() {
return bevp_classExeO;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGetDirect_0() {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() {
return bevp_makeSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGetDirect_0() {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() {
return bevp_classSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGetDirect_0() {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() {
return bevp_classSrcH;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGetDirect_0() {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() {
return bevp_classIncH;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGetDirect_0() {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() {
return bevp_classO;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGetDirect_0() {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() {
return bevp_synSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGetDirect_0() {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 27, 28, 29, 29, 30, 31, 32, 34, 34, 36, 38, 39, 40, 43, 43, 45, 45, 45, 45, 47, 47, 47, 47, 49, 49, 49, 49, 51, 51, 51, 51, 53, 53, 53, 53, 55, 55, 55, 55, 57, 57, 57, 57, 59, 59, 59, 59, 61, 61, 61, 61, 63, 63, 63, 63, 65, 65, 65, 65, 66, 66, 66, 66, 68, 70, 71, 74, 74, 75, 76, 77, 77, 79, 79, 79, 79, 80, 80, 81, 81, 81, 82, 82, 82, 86, 86, 86, 86, 87, 87, 87, 87, 88, 88, 88, 88, 90, 90, 90, 91, 91, 91, 92, 92, 92, 92, 94, 94, 94, 95, 95, 95, 95, 96, 96, 96, 96, 97, 97, 97, 98, 98, 98, 98, 108, 109, 110, 110, 111, 111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {77, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 291, 292, 293, 296, 298, 299, 308, 311, 314, 318, 322, 325, 328, 332, 336, 339, 342, 346, 350, 353, 356, 360, 364, 367, 370, 374, 378, 381, 384, 388, 392, 395, 398, 402, 406, 409, 412, 416, 420, 423, 426, 430, 434, 437, 440, 444, 448, 451, 454, 458, 462, 465, 468, 472, 476, 479, 482, 486, 490, 493, 496, 500, 504, 507, 510, 514, 518, 521, 524, 528, 532, 535, 538, 542, 546, 549, 552, 556, 560, 563, 566, 570, 574, 577, 580, 584, 588, 591, 594, 598, 602, 605, 608, 612, 616, 619, 622, 626, 630, 633, 636, 640, 644, 647, 650, 654, 658, 661, 664, 668, 672, 675, 678, 682, 686, 689, 692, 696, 700, 703, 706, 710, 714, 717, 720, 724, 728, 731, 734, 738, 742, 745, 748, 752, 756, 759, 762, 766, 770, 773, 776, 780, 784, 787, 790, 794, 798, 801, 804, 808, 812, 815, 818, 822, 826, 829, 832, 836, 840, 843, 846, 850, 854, 857, 860, 864, 868, 871, 874, 878, 882, 885, 888, 892, 896, 899, 902, 906, 910, 913, 916, 920};
/* BEGIN LINEINFO 
new 5 20 77
assign 1 27 161
assign 1 28 162
assign 1 29 163
buildGet 0 29 163
assign 1 29 164
compilerProfileGet 0 29 164
assign 1 30 165
parentGet 0 30 165
assign 1 31 166
stepsGet 0 31 166
assign 1 32 167
toString 0 32 167
assign 1 34 168
stepsGet 0 34 168
assign 1 34 169
lastGet 0 34 169
assign 1 36 170
midNameDo 2 36 170
nsDirDo 1 38 171
assign 1 39 172
cextGet 0 39 172
assign 1 40 173
oextGet 0 40 173
assign 1 43 174
new 0 43 174
assign 1 43 175
add 1 43 175
assign 1 45 176
new 0 45 176
assign 1 45 177
add 1 45 177
assign 1 45 178
new 0 45 178
assign 1 45 179
add 1 45 179
assign 1 47 180
new 0 47 180
assign 1 47 181
add 1 47 181
assign 1 47 182
new 0 47 182
assign 1 47 183
add 1 47 183
assign 1 49 184
new 0 49 184
assign 1 49 185
add 1 49 185
assign 1 49 186
new 0 49 186
assign 1 49 187
add 1 49 187
assign 1 51 188
new 0 51 188
assign 1 51 189
add 1 51 189
assign 1 51 190
new 0 51 190
assign 1 51 191
add 1 51 191
assign 1 53 192
new 0 53 192
assign 1 53 193
add 1 53 193
assign 1 53 194
new 0 53 194
assign 1 53 195
add 1 53 195
assign 1 55 196
new 0 55 196
assign 1 55 197
add 1 55 197
assign 1 55 198
new 0 55 198
assign 1 55 199
add 1 55 199
assign 1 57 200
new 0 57 200
assign 1 57 201
add 1 57 201
assign 1 57 202
new 0 57 202
assign 1 57 203
add 1 57 203
assign 1 59 204
new 0 59 204
assign 1 59 205
add 1 59 205
assign 1 59 206
new 0 59 206
assign 1 59 207
add 1 59 207
assign 1 61 208
new 0 61 208
assign 1 61 209
add 1 61 209
assign 1 61 210
new 0 61 210
assign 1 61 211
add 1 61 211
assign 1 63 212
new 0 63 212
assign 1 63 213
add 1 63 213
assign 1 63 214
new 0 63 214
assign 1 63 215
add 1 63 215
assign 1 65 216
new 0 65 216
assign 1 65 217
add 1 65 217
assign 1 65 218
new 0 65 218
assign 1 65 219
add 1 65 219
assign 1 66 220
new 0 66 220
assign 1 66 221
add 1 66 221
assign 1 66 222
new 0 66 222
assign 1 66 223
add 1 66 223
assign 1 68 224
assign 1 70 225
add 1 70 225
assign 1 71 226
copy 0 71 226
assign 1 74 227
new 0 74 227
assign 1 74 228
add 1 74 228
assign 1 75 229
assign 1 76 230
assign 1 77 231
new 0 77 231
assign 1 77 232
add 1 77 232
assign 1 79 233
copy 0 79 233
assign 1 79 234
new 0 79 234
assign 1 79 235
add 1 79 235
assign 1 79 236
addStep 1 79 236
assign 1 80 237
new 0 80 237
assign 1 80 238
add 1 80 238
assign 1 81 239
copy 0 81 239
assign 1 81 240
add 1 81 240
assign 1 81 241
addStep 1 81 241
assign 1 82 242
copy 0 82 242
assign 1 82 243
add 1 82 243
assign 1 82 244
addStep 1 82 244
assign 1 86 245
copy 0 86 245
assign 1 86 246
libExtGet 0 86 246
assign 1 86 247
add 1 86 247
assign 1 86 248
addStep 1 86 248
assign 1 87 249
copy 0 87 249
assign 1 87 250
exeLibExtGet 0 87 250
assign 1 87 251
add 1 87 251
assign 1 87 252
addStep 1 87 252
assign 1 88 253
copy 0 88 253
assign 1 88 254
exeExtGet 0 88 254
assign 1 88 255
add 1 88 255
assign 1 88 256
addStep 1 88 256
assign 1 90 257
copy 0 90 257
assign 1 90 258
add 1 90 258
assign 1 90 259
addStep 1 90 259
assign 1 91 260
copy 0 91 260
assign 1 91 261
add 1 91 261
assign 1 91 262
addStep 1 91 262
assign 1 92 263
copy 0 92 263
assign 1 92 264
new 0 92 264
assign 1 92 265
add 1 92 265
assign 1 92 266
addStep 1 92 266
assign 1 94 267
copy 0 94 267
assign 1 94 268
add 1 94 268
assign 1 94 269
addStep 1 94 269
assign 1 95 270
copy 0 95 270
assign 1 95 271
new 0 95 271
assign 1 95 272
add 1 95 272
assign 1 95 273
addStep 1 95 273
assign 1 96 274
copy 0 96 274
assign 1 96 275
new 0 96 275
assign 1 96 276
add 1 96 276
assign 1 96 277
addStep 1 96 277
assign 1 97 278
copy 0 97 278
assign 1 97 279
add 1 97 279
assign 1 97 280
addStep 1 97 280
assign 1 98 281
copy 0 98 281
assign 1 98 282
new 0 98 282
assign 1 98 283
add 1 98 283
assign 1 98 284
addStep 1 98 284
assign 1 108 291
new 0 108 291
addStep 1 109 292
assign 1 110 293
iteratorGet 0 110 293
assign 1 110 296
hasNextGet 0 110 296
assign 1 111 298
nextGet 0 111 298
addStep 1 111 299
return 1 0 308
return 1 0 311
assign 1 0 314
assign 1 0 318
return 1 0 322
return 1 0 325
assign 1 0 328
assign 1 0 332
return 1 0 336
return 1 0 339
assign 1 0 342
assign 1 0 346
return 1 0 350
return 1 0 353
assign 1 0 356
assign 1 0 360
return 1 0 364
return 1 0 367
assign 1 0 370
assign 1 0 374
return 1 0 378
return 1 0 381
assign 1 0 384
assign 1 0 388
return 1 0 392
return 1 0 395
assign 1 0 398
assign 1 0 402
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
return 1 0 434
return 1 0 437
assign 1 0 440
assign 1 0 444
return 1 0 448
return 1 0 451
assign 1 0 454
assign 1 0 458
return 1 0 462
return 1 0 465
assign 1 0 468
assign 1 0 472
return 1 0 476
return 1 0 479
assign 1 0 482
assign 1 0 486
return 1 0 490
return 1 0 493
assign 1 0 496
assign 1 0 500
return 1 0 504
return 1 0 507
assign 1 0 510
assign 1 0 514
return 1 0 518
return 1 0 521
assign 1 0 524
assign 1 0 528
return 1 0 532
return 1 0 535
assign 1 0 538
assign 1 0 542
return 1 0 546
return 1 0 549
assign 1 0 552
assign 1 0 556
return 1 0 560
return 1 0 563
assign 1 0 566
assign 1 0 570
return 1 0 574
return 1 0 577
assign 1 0 580
assign 1 0 584
return 1 0 588
return 1 0 591
assign 1 0 594
assign 1 0 598
return 1 0 602
return 1 0 605
assign 1 0 608
assign 1 0 612
return 1 0 616
return 1 0 619
assign 1 0 622
assign 1 0 626
return 1 0 630
return 1 0 633
assign 1 0 636
assign 1 0 640
return 1 0 644
return 1 0 647
assign 1 0 650
assign 1 0 654
return 1 0 658
return 1 0 661
assign 1 0 664
assign 1 0 668
return 1 0 672
return 1 0 675
assign 1 0 678
assign 1 0 682
return 1 0 686
return 1 0 689
assign 1 0 692
assign 1 0 696
return 1 0 700
return 1 0 703
assign 1 0 706
assign 1 0 710
return 1 0 714
return 1 0 717
assign 1 0 720
assign 1 0 724
return 1 0 728
return 1 0 731
assign 1 0 734
assign 1 0 738
return 1 0 742
return 1 0 745
assign 1 0 748
assign 1 0 752
return 1 0 756
return 1 0 759
assign 1 0 762
assign 1 0 766
return 1 0 770
return 1 0 773
assign 1 0 776
assign 1 0 780
return 1 0 784
return 1 0 787
assign 1 0 790
assign 1 0 794
return 1 0 798
return 1 0 801
assign 1 0 804
assign 1 0 808
return 1 0 812
return 1 0 815
assign 1 0 818
assign 1 0 822
return 1 0 826
return 1 0 829
assign 1 0 832
assign 1 0 836
return 1 0 840
return 1 0 843
assign 1 0 846
assign 1 0 850
return 1 0 854
return 1 0 857
assign 1 0 860
assign 1 0 864
return 1 0 868
return 1 0 871
assign 1 0 874
assign 1 0 878
return 1 0 882
return 1 0 885
assign 1 0 888
assign 1 0 892
return 1 0 896
return 1 0 899
assign 1 0 902
assign 1 0 906
return 1 0 910
return 1 0 913
assign 1 0 916
assign 1 0 920
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1082587922: return bem_kbaseGet_0();
case -71820859: return bem_cuinitHGet_0();
case 1943064326: return bem_shFileNameGet_0();
case 536714568: return bem_xbaseGet_0();
case 1525095896: return bem_cuinitGetDirect_0();
case 524154839: return bem_unitExeLinkGetDirect_0();
case 1219793485: return bem_emitterGetDirect_0();
case 1562650783: return bem_fieldIteratorGet_0();
case -1448387833: return bem_lbaseGet_0();
case 595470354: return bem_libnameDataClearGetDirect_0();
case -758776587: return bem_libnameDataDoneGet_0();
case -1692317746: return bem_nparGetDirect_0();
case -178385347: return bem_iteratorGet_0();
case 1724128434: return bem_clBaseGet_0();
case -1304982862: return bem_cproGet_0();
case 1301734470: return bem_nparStepsGet_0();
case -1279292712: return bem_classIncHGet_0();
case -1534510204: return bem_libnameDataDoneGetDirect_0();
case 1615418415: return bem_emitPathGet_0();
case -586650636: return bem_clNameGetDirect_0();
case 344398742: return bem_makeSrcGet_0();
case -1760879347: return bem_mtdNameGetDirect_0();
case -1073443404: return bem_unitExeGetDirect_0();
case -102521625: return bem_unitExeGet_0();
case 1916405809: return bem_shClassNameGetDirect_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 73189710: return bem_libnameInitGet_0();
case 515074061: return bem_namesOGetDirect_0();
case 1891631606: return bem_libNotNullInitGet_0();
case 210819671: return bem_cldefNameGetDirect_0();
case -860100592: return bem_namesOGet_0();
case -1670635016: return bem_emitterGet_0();
case -839941577: return bem_npGetDirect_0();
case 1258729534: return bem_echo_0();
case 1688074387: return bem_cldefBuildGet_0();
case 2037996040: return bem_create_0();
case -468349499: return bem_namesIncHGet_0();
case -1221104789: return bem_sourceFileNameGet_0();
case 2031953323: return bem_libnameDataGetDirect_0();
case 782288461: return bem_nparStepsGetDirect_0();
case 1998764969: return bem_emitPathGetDirect_0();
case 1460710096: return bem_tagGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case 1425780147: return bem_basePathGetDirect_0();
case -1047807883: return bem_libNotNullInitGetDirect_0();
case 24355092: return bem_mtdNameGet_0();
case 939713627: return bem_print_0();
case 1064919129: return bem_shClassNameGet_0();
case 188549135: return bem_lbaseGetDirect_0();
case -398572135: return bem_libnameInitDoneGet_0();
case 1361317742: return bem_xbaseGetDirect_0();
case -1139204672: return bem_kbaseGetDirect_0();
case -20103875: return bem_nsDirGet_0();
case -1551240890: return bem_clBaseGetDirect_0();
case 81120566: return bem_clNameGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case 253773790: return bem_classExeOGet_0();
case 1228242560: return bem_unitShlibGet_0();
case 1346616940: return bem_basePathGet_0();
case 550823925: return bem_cuinitGet_0();
case 1763988289: return bem_cproGetDirect_0();
case -1906768398: return bem_classNameGet_0();
case -1253293660: return bem_serializeToString_0();
case -2115985903: return bem_classExeSrcGet_0();
case -1536712644: return bem_nbaseGetDirect_0();
case 346431687: return bem_nparGet_0();
case -1500793713: return bem_classIncHGetDirect_0();
case 1174651128: return bem_unitShlibGetDirect_0();
case 221392594: return bem_classOGetDirect_0();
case 663084125: return bem_cuBaseGet_0();
case -1395986726: return bem_cuBaseGetDirect_0();
case 1438481785: return bem_nbaseGet_0();
case 873076018: return bem_new_0();
case 832307031: return bem_makeSrcGetDirect_0();
case -181791464: return bem_synSrcGet_0();
case -1199828244: return bem_classExeOGetDirect_0();
case -1751679089: return bem_classExeSrcGetDirect_0();
case -1652709585: return bem_synSrcGetDirect_0();
case 1640157629: return bem_toString_0();
case 977755641: return bem_unitExeLinkGet_0();
case 739918425: return bem_cldefBuildGetDirect_0();
case -1488083356: return bem_shFileNameGetDirect_0();
case -933728979: return bem_classSrcGet_0();
case 1039117552: return bem_libnameInitGetDirect_0();
case 506777306: return bem_nsDirGetDirect_0();
case 694224808: return bem_incBlockGet_0();
case -2070846101: return bem_hashGet_0();
case -544137775: return bem_libNotNullInitDoneGetDirect_0();
case -1427862939: return bem_cldefNameGet_0();
case -700395068: return bem_libnameDataClearGet_0();
case -281818644: return bem_namesIncHGetDirect_0();
case 311172389: return bem_classSrcHGetDirect_0();
case 1063495394: return bem_incBlockGetDirect_0();
case -342312841: return bem_libNotNullInitDoneGet_0();
case -2129869346: return bem_midNameGet_0();
case 1168795387: return bem_libnameInitDoneGetDirect_0();
case 1142421051: return bem_cuinitHGetDirect_0();
case -1605324346: return bem_midNameGetDirect_0();
case 1918352077: return bem_classOGet_0();
case -1036391864: return bem_copy_0();
case -278862759: return bem_npGet_0();
case 307193318: return bem_serializeContents_0();
case 1261311777: return bem_classSrcGetDirect_0();
case -689018920: return bem_classSrcHGet_0();
case -893703593: return bem_libnameDataGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1420800859: return bem_otherType_1(bevd_0);
case -791238166: return bem_cldefNameSetDirect_1(bevd_0);
case -12178918: return bem_namesOSet_1(bevd_0);
case 1840776753: return bem_namesOSetDirect_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case 706090438: return bem_libNotNullInitDoneSetDirect_1(bevd_0);
case 2124102170: return bem_nparStepsSetDirect_1(bevd_0);
case 1412761341: return bem_kbaseSet_1(bevd_0);
case -561650435: return bem_libNotNullInitDoneSet_1(bevd_0);
case -11249361: return bem_classIncHSet_1(bevd_0);
case -1183187918: return bem_clBaseSetDirect_1(bevd_0);
case -1722584650: return bem_xbaseSet_1(bevd_0);
case 364429835: return bem_emitPathSet_1(bevd_0);
case -1827734500: return bem_classExeSrcSet_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case 1939864657: return bem_shClassNameSet_1(bevd_0);
case -886300894: return bem_unitExeLinkSetDirect_1(bevd_0);
case 477507381: return bem_shClassNameSetDirect_1(bevd_0);
case -825078663: return bem_shFileNameSetDirect_1(bevd_0);
case 660163655: return bem_mtdNameSet_1(bevd_0);
case 1766200368: return bem_cproSet_1(bevd_0);
case -1379422508: return bem_cuBaseSet_1(bevd_0);
case 1891517938: return bem_shFileNameSet_1(bevd_0);
case 109461499: return bem_classOSetDirect_1(bevd_0);
case -748899280: return bem_libnameDataSetDirect_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 195379385: return bem_incBlockSetDirect_1(bevd_0);
case -1400817823: return bem_namesIncHSetDirect_1(bevd_0);
case -377491913: return bem_emitterSet_1(bevd_0);
case -1081932545: return bem_cuinitHSetDirect_1(bevd_0);
case 2022574360: return bem_nbaseSet_1(bevd_0);
case -1746954511: return bem_emitterSetDirect_1(bevd_0);
case -2069788764: return bem_cldefBuildSetDirect_1(bevd_0);
case 844746070: return bem_libnameDataClearSetDirect_1(bevd_0);
case 1317792812: return bem_nsDirSet_1(bevd_0);
case 840957352: return bem_libnameInitSet_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 295551291: return bem_nparStepsSet_1(bevd_0);
case 1565914404: return bem_basePathSet_1(bevd_0);
case 1715699662: return bem_cldefBuildSet_1(bevd_0);
case -1247620066: return bem_classExeOSetDirect_1(bevd_0);
case 1920063144: return bem_clNameSet_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case -1289241929: return bem_classExeSrcSetDirect_1(bevd_0);
case 832206541: return bem_classIncHSetDirect_1(bevd_0);
case -710725308: return bem_libnameInitDoneSetDirect_1(bevd_0);
case 2125250170: return bem_synSrcSet_1(bevd_0);
case 735061035: return bem_incBlockSet_1(bevd_0);
case 1727668435: return bem_clBaseSet_1(bevd_0);
case 1983780392: return bem_cuinitHSet_1(bevd_0);
case 464244242: return bem_synSrcSetDirect_1(bevd_0);
case 531524970: return bem_libNotNullInitSetDirect_1(bevd_0);
case 816421987: return bem_classSrcHSetDirect_1(bevd_0);
case 360925310: return bem_nbaseSetDirect_1(bevd_0);
case 2074718436: return bem_kbaseSetDirect_1(bevd_0);
case -1723438160: return bem_lbaseSetDirect_1(bevd_0);
case -1762142033: return bem_cproSetDirect_1(bevd_0);
case 686153561: return bem_nparSetDirect_1(bevd_0);
case 271608842: return bem_libnameInitDoneSet_1(bevd_0);
case -407558460: return bem_midNameSetDirect_1(bevd_0);
case -688378820: return bem_xbaseSetDirect_1(bevd_0);
case 168851833: return bem_emitPathSetDirect_1(bevd_0);
case 1801466675: return bem_namesIncHSet_1(bevd_0);
case 1577700568: return bem_cldefNameSet_1(bevd_0);
case 1225021664: return bem_unitExeSet_1(bevd_0);
case 29953283: return bem_libnameInitSetDirect_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1433898734: return bem_npSetDirect_1(bevd_0);
case -2006349910: return bem_midNameSet_1(bevd_0);
case -286001397: return bem_libnameDataDoneSetDirect_1(bevd_0);
case -1183153313: return bem_makeSrcSet_1(bevd_0);
case 2028347384: return bem_clNameSetDirect_1(bevd_0);
case -1664140532: return bem_classSrcSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case -406788757: return bem_makeSrcSetDirect_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -1101868643: return bem_cuinitSetDirect_1(bevd_0);
case -2079340087: return bem_classExeOSet_1(bevd_0);
case -423911598: return bem_libnameDataDoneSet_1(bevd_0);
case 1866681268: return bem_unitShlibSetDirect_1(bevd_0);
case -1312832798: return bem_basePathSetDirect_1(bevd_0);
case 56108739: return bem_nparSet_1(bevd_0);
case 752195193: return bem_libNotNullInitSet_1(bevd_0);
case -554198641: return bem_classSrcSet_1(bevd_0);
case -1025313871: return bem_classSrcHSet_1(bevd_0);
case -63882034: return bem_libnameDataClearSet_1(bevd_0);
case 717387272: return bem_libnameDataSet_1(bevd_0);
case -741661852: return bem_unitExeLinkSet_1(bevd_0);
case 1506093669: return bem_mtdNameSetDirect_1(bevd_0);
case -2025118719: return bem_classOSet_1(bevd_0);
case -218614718: return bem_cuBaseSetDirect_1(bevd_0);
case 518751020: return bem_nsDirSetDirect_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case 1550678411: return bem_npSet_1(bevd_0);
case 1789727150: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case -373723949: return bem_lbaseSet_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -971438108: return bem_unitShlibSet_1(bevd_0);
case 2098707963: return bem_cuinitSet_1(bevd_0);
case 1583888829: return bem_unitExeSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -915834492: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -1077456389: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildClassInfo();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_type;
}
}
}
