namespace be {
public class BET_2_9_4_ContainerList : BETS_Object {
public BET_2_9_4_ContainerList() {
string[] bevs_mtnames = new string[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "new_1", "new_2", "sizeGet_0", "sizeSet_1", "isEmptyGet_0", "anyrayGet_0", "anyraySet_0", "firstGet_0", "lastGet_0", "put_2", "get_1", "delete_1", "arrayIteratorGet_0", "clear_0", "create_1", "add_1", "sort_0", "sortValue_0", "sortValue_2", "mergeIn_2", "mergeSort_0", "mergeSort_2", "capacitySet_1", "lengthSet_1", "iterateAdd_1", "addAll_1", "addValueWhole_1", "addValue_1", "find_1", "has_1", "sortedFind_1", "sortedFind_2", "lengthGet_0", "lengthGetDirect_0", "lengthSetDirect_1", "capacityGet_0", "capacityGetDirect_0", "capacitySetDirect_1", "multiplierGet_0", "multiplierGetDirect_0", "multiplierSet_1", "multiplierSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "length", "capacity", "multiplier" };
}
static BET_2_9_4_ContainerList() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_9_4_ContainerList();
}
}
}
