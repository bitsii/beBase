namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_6_BuildVisitRewind : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
static BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_1, 11));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_2, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_3, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_6, 27));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_8, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_9, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_10 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_10, 17));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_11 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_11, 10));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_12 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_83_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_86_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 248 */ {
bevt_12_tmpany_phold = beva_node.bem_heldGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(323667655);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 248 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 248 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 248 */
 else  /* Line: 248 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 248 */ {
bevt_15_tmpany_phold = beva_node.bem_containerGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 250 */ {
bevt_20_tmpany_phold = beva_node.bem_containerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1935085261);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(-1363115649, bevt_21_tmpany_phold);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 250 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 250 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 250 */
 else  /* Line: 250 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 250 */ {
bevt_22_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 250 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 250 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 250 */
 else  /* Line: 250 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 250 */ {
bevt_26_tmpany_phold = beva_node.bem_containedGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_firstGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(-1622744050);
bevt_27_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-1363115649, bevt_27_tmpany_phold);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 252 */ {
bevt_31_tmpany_phold = beva_node.bem_containedGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_firstGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-1093167831);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-2084582003);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 252 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 252 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 252 */
 else  /* Line: 252 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 252 */ {
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-1093167831);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_tmpany_phold.bemd_0(1736428289);
bevt_35_tmpany_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_lastGet_0();
bevt_39_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0;
bevt_40_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1;
bevt_38_tmpany_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpany_phold, bevt_40_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevt_38_tmpany_phold.bem_lowerValue_0();
bevt_42_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_41_tmpany_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2;
bevl_fgin = bevt_36_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpany_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3;
bevt_45_tmpany_phold = bevl_fgin.bem_add_1(bevt_46_tmpany_phold);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_tmpany_phold.bem_get_1(bevt_45_tmpany_phold);
if (bevl_fgms == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_48_tmpany_phold.bemd_1(-188494555, bevl_fgin);
bevt_49_tmpany_phold = beva_node.bem_heldGet_0();
bevt_51_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4;
bevt_50_tmpany_phold = bevl_fgin.bem_add_1(bevt_51_tmpany_phold);
bevt_49_tmpany_phold.bemd_1(-1849236093, bevt_50_tmpany_phold);
} /* Line: 262 */
} /* Line: 259 */
} /* Line: 252 */
} /* Line: 250 */
bevt_53_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_tmpany_phold.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevp_inClass = beva_node;
bevt_55_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpany_phold.bemd_0(1736428289);
bevt_56_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpany_phold.bemd_0(930306570);
} /* Line: 270 */
bevt_58_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_59_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 274 */
 else  /* Line: 272 */ {
bevt_61_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpany_phold.bevi_int == bevt_62_tmpany_phold.bevi_int) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_64_tmpany_phold = beva_node.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1989675316);
if (bevt_63_tmpany_phold != null && bevt_63_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 275 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 275 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 275 */
 else  /* Line: 275 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 275 */ {
bevt_66_tmpany_phold = beva_node.bem_heldGet_0();
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(-2071511275);
bevt_67_tmpany_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(-1953458593, bevt_65_tmpany_phold, bevt_67_tmpany_phold);
bevt_69_tmpany_phold = beva_node.bem_heldGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(-2071511275);
bevl_ll = bevp_rmap.bemd_1(1422589702, bevt_68_tmpany_phold);
if (bevl_ll == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 278 */ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = beva_node.bem_heldGet_0();
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(-2071511275);
bevp_rmap.bemd_2(-1953458593, bevt_71_tmpany_phold, bevl_ll);
} /* Line: 280 */
bevl_ll.bemd_1(-663384923, beva_node);
} /* Line: 282 */
 else  /* Line: 272 */ {
bevt_74_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_tmpany_phold.bevi_int == bevt_75_tmpany_phold.bevi_int) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 283 */ {
bevt_77_tmpany_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 283 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
 else  /* Line: 283 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 283 */ {
bevt_80_tmpany_phold = beva_node.bem_containerGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_containerGet_0();
if (bevt_79_tmpany_phold == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 283 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
 else  /* Line: 283 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 283 */ {
bevt_84_tmpany_phold = beva_node.bem_containerGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bem_containerGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_typenameGet_0();
bevt_85_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_tmpany_phold.bevi_int == bevt_85_tmpany_phold.bevi_int) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 283 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
 else  /* Line: 283 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 283 */ {
bem_processTmps_0();
} /* Line: 285 */
} /* Line: 272 */
} /* Line: 272 */
bevt_86_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpany_phold;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 299 */ {
if (bevl_foundone != null && bevl_foundone is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool) /* Line: 299 */ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(1684441017);
while (true)
 /* Line: 301 */ {
bevt_9_tmpany_phold = bevl_i.bemd_0(278473655);
if (bevt_9_tmpany_phold != null && bevt_9_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 301 */ {
bevl_nv = bevl_i.bemd_0(1252274177);
bevt_11_tmpany_phold = bevl_nv.bemd_0(-2084582003);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-880677035);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 304 */ {
bevl_nvname = bevl_nv.bemd_0(-2071511275);
bevl_ll = bevp_rmap.bemd_1(1422589702, bevl_nvname);
bevt_0_tmpany_loop = bevl_ll.bemd_0(-1626502172);
while (true)
 /* Line: 309 */ {
bevt_12_tmpany_phold = bevt_0_tmpany_loop.bemd_0(278473655);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 309 */ {
bevl_k = bevt_0_tmpany_loop.bemd_0(1252274177);
bevt_13_tmpany_phold = bevl_k.bemd_0(467186779);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevt_16_tmpany_phold = bevl_k.bemd_0(108209925);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1622744050);
bevt_17_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_1(-1363115649, bevt_17_tmpany_phold);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 310 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 310 */
 else  /* Line: 310 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 310 */ {
bevt_21_tmpany_phold = bevl_k.bemd_0(108209925);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-1093167831);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(1935085261);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_4));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-1363115649, bevt_22_tmpany_phold);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 310 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 310 */
 else  /* Line: 310 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 310 */ {
bevt_26_tmpany_phold = bevl_k.bemd_0(108209925);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1403025229);
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(-1622744050);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-1363115649, bevt_27_tmpany_phold);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 310 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 310 */
 else  /* Line: 310 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 310 */ {
bevt_28_tmpany_phold = bevl_k.bemd_0(108209925);
bevl_tcall = bevt_28_tmpany_phold.bemd_0(1403025229);
bevl_targNp = null;
bevt_31_tmpany_phold = bevl_tcall.bemd_0(-1093167831);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(-147819877);
if (bevt_30_tmpany_phold == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_32_tmpany_phold = bevl_tcall.bemd_0(-1093167831);
bevl_targNp = bevt_32_tmpany_phold.bemd_0(-147819877);
} /* Line: 315 */
 else  /* Line: 316 */ {
bevt_33_tmpany_phold = bevl_tcall.bemd_0(-582812323);
bevl_targ = bevt_33_tmpany_phold.bemd_0(127272844);
bevt_35_tmpany_phold = bevl_targ.bemd_0(-1093167831);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1734104319);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 321 */ {
bevl_tany = bevl_targ.bemd_0(-1093167831);
} /* Line: 322 */
 else  /* Line: 323 */ {
bevt_37_tmpany_phold = bevp_inClassSyn.bemd_0(-2067861273);
bevt_39_tmpany_phold = bevl_targ.bemd_0(-1093167831);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(-2071511275);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(1422589702, bevt_38_tmpany_phold);
bevl_tany = bevt_36_tmpany_phold.bemd_0(-663819152);
} /* Line: 324 */
bevt_40_tmpany_phold = bevl_tany.bemd_0(-2084582003);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 327 */ {
bevl_targNp = bevl_tany.bemd_0(1736428289);
} /* Line: 328 */
} /* Line: 327 */
if (bevl_targNp == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_44_tmpany_phold = bevl_tcall.bemd_0(-1093167831);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(-2071511275);
bevl_mtdc = bevt_42_tmpany_phold.bem_get_1(bevt_43_tmpany_phold);
if (bevl_mtdc == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevl_oany = bevl_mtdc.bemd_0(651090563);
if (bevl_oany == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 338 */ {
bevt_47_tmpany_phold = bevl_oany.bemd_0(-2084582003);
if (bevt_47_tmpany_phold != null && bevt_47_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 338 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 338 */
 else  /* Line: 338 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 338 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_tmpany_phold = bevl_oany.bemd_0(614595662);
if (bevt_48_tmpany_phold != null && bevt_48_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_48_tmpany_phold).bevi_bool) /* Line: 341 */ {
bevl_nv.bemd_1(-503081019, bevl_targNp);
} /* Line: 342 */
 else  /* Line: 343 */ {
bevt_49_tmpany_phold = bevl_oany.bemd_0(1736428289);
bevl_nv.bemd_1(-503081019, bevt_49_tmpany_phold);
} /* Line: 344 */
bevt_50_tmpany_phold = bevl_oany.bemd_0(-2084582003);
bevl_nv.bemd_1(-264609329, bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bevp_inClass.bemd_0(-1093167831);
bevt_52_tmpany_phold = bevl_nv.bemd_0(1736428289);
bevt_51_tmpany_phold.bemd_1(-447285794, bevt_52_tmpany_phold);
bevt_55_tmpany_phold = bevl_nv.bemd_0(1736428289);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-327890059);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_1(-1363115649, bevt_56_tmpany_phold);
if (bevt_53_tmpany_phold != null && bevt_53_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_53_tmpany_phold).bevi_bool) /* Line: 348 */ {
bevt_58_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5;
bevt_59_tmpany_phold = bevl_oany.bemd_0(614595662);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold.bem_print_0();
} /* Line: 348 */
} /* Line: 348 */
} /* Line: 338 */
 else  /* Line: 335 */ {
bevt_62_tmpany_phold = bevl_tcall.bemd_0(-1093167831);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(1935085261);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_7));
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_1(1971930884, bevt_63_tmpany_phold);
if (bevt_60_tmpany_phold != null && bevt_60_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 350 */ {
bevt_64_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_65_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_tmpany_phold.bem_get_1(bevt_65_tmpany_phold);
if (bevl_fcms == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 352 */ {
bevt_69_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_toString_0();
bevt_70_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7;
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_notEquals_1(bevt_70_tmpany_phold);
if (bevt_67_tmpany_phold.bevi_bool) /* Line: 352 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 352 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 352 */
 else  /* Line: 352 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 352 */ {
bevt_71_tmpany_phold = bevl_tcall.bemd_0(-1093167831);
bevt_72_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_71_tmpany_phold.bemd_1(-1262844736, bevt_72_tmpany_phold);
} /* Line: 353 */
 else  /* Line: 354 */ {
bevt_77_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8;
bevt_79_tmpany_phold = bevl_tcall.bemd_0(-1093167831);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-2071511275);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_add_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9;
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_add_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = bevl_targNp.bemd_0(-327890059);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 355 */
} /* Line: 352 */
} /* Line: 335 */
} /* Line: 335 */
} /* Line: 331 */
 else  /* Line: 310 */ {
bevt_82_tmpany_phold = bevl_k.bemd_0(467186779);
if (bevt_82_tmpany_phold != null && bevt_82_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 361 */ {
bevt_85_tmpany_phold = bevl_k.bemd_0(108209925);
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bemd_0(-1622744050);
bevt_86_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_1(-1363115649, bevt_86_tmpany_phold);
if (bevt_83_tmpany_phold != null && bevt_83_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_83_tmpany_phold).bevi_bool) /* Line: 361 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 361 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 361 */
 else  /* Line: 361 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 361 */ {
bevt_90_tmpany_phold = bevl_k.bemd_0(108209925);
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(-1093167831);
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bemd_0(1935085261);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_12));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bemd_1(-1363115649, bevt_91_tmpany_phold);
if (bevt_87_tmpany_phold != null && bevt_87_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 361 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 361 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 361 */
 else  /* Line: 361 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 361 */ {
bevt_95_tmpany_phold = bevl_k.bemd_0(108209925);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_0(1403025229);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(-1622744050);
bevt_96_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(-1363115649, bevt_96_tmpany_phold);
if (bevt_92_tmpany_phold != null && bevt_92_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 361 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 361 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 361 */
 else  /* Line: 361 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 361 */ {
bevt_98_tmpany_phold = bevl_k.bemd_0(108209925);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_0(1403025229);
bevl_targ = bevt_97_tmpany_phold.bemd_0(-1093167831);
bevt_99_tmpany_phold = bevl_targ.bemd_0(-2084582003);
if (bevt_99_tmpany_phold != null && bevt_99_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_99_tmpany_phold).bevi_bool) /* Line: 364 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_tmpany_phold = bevl_targ.bemd_0(-2084582003);
bevl_nv.bemd_1(-264609329, bevt_100_tmpany_phold);
bevt_101_tmpany_phold = bevl_targ.bemd_0(1736428289);
bevl_nv.bemd_1(-503081019, bevt_101_tmpany_phold);
} /* Line: 369 */
} /* Line: 364 */
} /* Line: 310 */
} /* Line: 310 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
} /* Line: 309 */
} /* Line: 304 */
 else  /* Line: 301 */ {
break;
} /* Line: 301 */
} /* Line: 301 */
} /* Line: 301 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {248, 248, 248, 248, 248, 248, 0, 0, 0, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 0, 0, 0, 250, 0, 0, 0, 252, 252, 252, 252, 252, 252, 252, 252, 252, 0, 0, 0, 253, 253, 253, 253, 254, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 257, 258, 258, 258, 258, 259, 259, 261, 261, 262, 262, 262, 262, 267, 267, 267, 267, 268, 269, 269, 270, 270, 272, 272, 272, 272, 273, 274, 275, 275, 275, 275, 275, 275, 0, 0, 0, 276, 276, 276, 276, 277, 277, 277, 278, 278, 279, 280, 280, 280, 282, 283, 283, 283, 283, 283, 283, 283, 0, 0, 0, 283, 283, 283, 283, 0, 0, 0, 283, 283, 283, 283, 283, 283, 0, 0, 0, 285, 287, 287, 291, 300, 301, 301, 302, 304, 304, 307, 308, 309, 0, 309, 309, 310, 310, 310, 310, 310, 0, 0, 0, 310, 310, 310, 310, 310, 0, 0, 0, 310, 310, 310, 310, 310, 0, 0, 0, 312, 312, 313, 314, 314, 314, 314, 315, 315, 317, 317, 321, 321, 322, 324, 324, 324, 324, 324, 327, 328, 331, 331, 333, 334, 334, 334, 334, 335, 335, 337, 338, 338, 338, 0, 0, 0, 339, 341, 342, 344, 344, 346, 346, 347, 347, 347, 348, 348, 348, 348, 348, 348, 348, 348, 350, 350, 350, 350, 351, 351, 351, 352, 352, 352, 352, 352, 352, 0, 0, 0, 353, 353, 353, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 361, 361, 361, 361, 361, 0, 0, 0, 361, 361, 361, 361, 361, 0, 0, 0, 361, 361, 361, 361, 361, 0, 0, 0, 362, 362, 362, 364, 366, 368, 368, 369, 369, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {136, 137, 138, 143, 144, 145, 147, 150, 154, 157, 158, 159, 160, 165, 166, 167, 168, 169, 170, 172, 175, 179, 182, 184, 187, 191, 194, 195, 196, 197, 198, 200, 201, 202, 203, 205, 208, 212, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 240, 241, 242, 243, 244, 245, 246, 251, 252, 253, 258, 259, 260, 261, 262, 263, 265, 266, 267, 272, 273, 274, 277, 278, 279, 284, 285, 286, 288, 291, 295, 298, 299, 300, 301, 302, 303, 304, 305, 310, 311, 312, 313, 314, 316, 319, 320, 321, 326, 327, 328, 333, 334, 337, 341, 344, 345, 346, 351, 352, 355, 359, 362, 363, 364, 365, 366, 371, 372, 375, 379, 382, 386, 387, 506, 510, 511, 514, 516, 517, 518, 520, 521, 522, 522, 525, 527, 528, 530, 531, 532, 533, 535, 538, 542, 545, 546, 547, 548, 549, 551, 554, 558, 561, 562, 563, 564, 565, 567, 570, 574, 577, 578, 579, 580, 581, 582, 587, 588, 589, 592, 593, 594, 595, 597, 600, 601, 602, 603, 604, 606, 608, 611, 616, 617, 618, 619, 620, 621, 622, 627, 628, 629, 634, 635, 637, 640, 644, 647, 648, 650, 653, 654, 656, 657, 658, 659, 660, 661, 662, 663, 664, 666, 667, 668, 669, 674, 675, 676, 677, 679, 680, 681, 682, 687, 688, 689, 690, 691, 693, 696, 700, 703, 704, 705, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 724, 726, 727, 728, 729, 731, 734, 738, 741, 742, 743, 744, 745, 747, 750, 754, 757, 758, 759, 760, 761, 763, 766, 770, 773, 774, 775, 776, 778, 779, 780, 781, 782, 805, 808, 812, 815, 819, 822, 826, 829, 833, 836, 840, 843, 847, 850};
/* BEGIN LINEINFO 
assign 1 248 136
typenameGet 0 248 136
assign 1 248 137
CALLGet 0 248 137
assign 1 248 138
equals 1 248 143
assign 1 248 144
heldGet 0 248 144
assign 1 248 145
wasForeachGennedGet 0 248 145
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 250 157
containerGet 0 250 157
assign 1 250 158
typenameGet 0 250 158
assign 1 250 159
CALLGet 0 250 159
assign 1 250 160
equals 1 250 165
assign 1 250 166
containerGet 0 250 166
assign 1 250 167
heldGet 0 250 167
assign 1 250 168
orgNameGet 0 250 168
assign 1 250 169
new 0 250 169
assign 1 250 170
equals 1 250 170
assign 1 0 172
assign 1 0 175
assign 1 0 179
assign 1 250 182
isSecondGet 0 250 182
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 252 194
containedGet 0 252 194
assign 1 252 195
firstGet 0 252 195
assign 1 252 196
typenameGet 0 252 196
assign 1 252 197
VARGet 0 252 197
assign 1 252 198
equals 1 252 198
assign 1 252 200
containedGet 0 252 200
assign 1 252 201
firstGet 0 252 201
assign 1 252 202
heldGet 0 252 202
assign 1 252 203
isTypedGet 0 252 203
assign 1 0 205
assign 1 0 208
assign 1 0 212
assign 1 253 215
containedGet 0 253 215
assign 1 253 216
firstGet 0 253 216
assign 1 253 217
heldGet 0 253 217
assign 1 253 218
namepathGet 0 253 218
assign 1 254 219
stepsGet 0 254 219
assign 1 254 220
lastGet 0 254 220
assign 1 255 221
new 0 255 221
assign 1 255 222
new 0 255 222
assign 1 255 223
substring 2 255 223
assign 1 255 224
lowerValue 0 255 224
assign 1 255 225
new 0 255 225
assign 1 255 226
substring 1 255 226
assign 1 255 227
add 1 255 227
assign 1 255 228
new 0 255 228
assign 1 255 229
add 1 255 229
assign 1 257 230
getSynNp 1 257 230
assign 1 258 231
mtdMapGet 0 258 231
assign 1 258 232
new 0 258 232
assign 1 258 233
add 1 258 233
assign 1 258 234
get 1 258 234
assign 1 259 235
def 1 259 240
assign 1 261 241
heldGet 0 261 241
orgNameSet 1 261 242
assign 1 262 243
heldGet 0 262 243
assign 1 262 244
new 0 262 244
assign 1 262 245
add 1 262 245
nameSet 1 262 246
assign 1 267 251
typenameGet 0 267 251
assign 1 267 252
CLASSGet 0 267 252
assign 1 267 253
equals 1 267 258
assign 1 268 259
assign 1 269 260
heldGet 0 269 260
assign 1 269 261
namepathGet 0 269 261
assign 1 270 262
heldGet 0 270 262
assign 1 270 263
synGet 0 270 263
assign 1 272 265
typenameGet 0 272 265
assign 1 272 266
METHODGet 0 272 266
assign 1 272 267
equals 1 272 272
assign 1 273 273
new 0 273 273
assign 1 274 274
new 0 274 274
assign 1 275 277
typenameGet 0 275 277
assign 1 275 278
VARGet 0 275 278
assign 1 275 279
equals 1 275 284
assign 1 275 285
heldGet 0 275 285
assign 1 275 286
autoTypeGet 0 275 286
assign 1 0 288
assign 1 0 291
assign 1 0 295
assign 1 276 298
heldGet 0 276 298
assign 1 276 299
nameGet 0 276 299
assign 1 276 300
heldGet 0 276 300
put 2 276 301
assign 1 277 302
heldGet 0 277 302
assign 1 277 303
nameGet 0 277 303
assign 1 277 304
get 1 277 304
assign 1 278 305
undef 1 278 310
assign 1 279 311
new 0 279 311
assign 1 280 312
heldGet 0 280 312
assign 1 280 313
nameGet 0 280 313
put 2 280 314
addValue 1 282 316
assign 1 283 319
typenameGet 0 283 319
assign 1 283 320
RBRACESGet 0 283 320
assign 1 283 321
equals 1 283 326
assign 1 283 327
containerGet 0 283 327
assign 1 283 328
def 1 283 333
assign 1 0 334
assign 1 0 337
assign 1 0 341
assign 1 283 344
containerGet 0 283 344
assign 1 283 345
containerGet 0 283 345
assign 1 283 346
def 1 283 351
assign 1 0 352
assign 1 0 355
assign 1 0 359
assign 1 283 362
containerGet 0 283 362
assign 1 283 363
containerGet 0 283 363
assign 1 283 364
typenameGet 0 283 364
assign 1 283 365
METHODGet 0 283 365
assign 1 283 366
equals 1 283 371
assign 1 0 372
assign 1 0 375
assign 1 0 379
processTmps 0 285 382
assign 1 287 386
nextDescendGet 0 287 386
return 1 287 387
assign 1 291 506
new 0 291 506
assign 1 300 510
new 0 300 510
assign 1 301 511
valueIteratorGet 0 301 511
assign 1 301 514
hasNextGet 0 301 514
assign 1 302 516
nextGet 0 302 516
assign 1 304 517
isTypedGet 0 304 517
assign 1 304 518
not 0 304 518
assign 1 307 520
nameGet 0 307 520
assign 1 308 521
get 1 308 521
assign 1 309 522
iteratorGet 0 0 522
assign 1 309 525
hasNextGet 0 309 525
assign 1 309 527
nextGet 0 309 527
assign 1 310 528
isFirstGet 0 310 528
assign 1 310 530
containerGet 0 310 530
assign 1 310 531
typenameGet 0 310 531
assign 1 310 532
CALLGet 0 310 532
assign 1 310 533
equals 1 310 533
assign 1 0 535
assign 1 0 538
assign 1 0 542
assign 1 310 545
containerGet 0 310 545
assign 1 310 546
heldGet 0 310 546
assign 1 310 547
orgNameGet 0 310 547
assign 1 310 548
new 0 310 548
assign 1 310 549
equals 1 310 549
assign 1 0 551
assign 1 0 554
assign 1 0 558
assign 1 310 561
containerGet 0 310 561
assign 1 310 562
secondGet 0 310 562
assign 1 310 563
typenameGet 0 310 563
assign 1 310 564
CALLGet 0 310 564
assign 1 310 565
equals 1 310 565
assign 1 0 567
assign 1 0 570
assign 1 0 574
assign 1 312 577
containerGet 0 312 577
assign 1 312 578
secondGet 0 312 578
assign 1 313 579
assign 1 314 580
heldGet 0 314 580
assign 1 314 581
newNpGet 0 314 581
assign 1 314 582
def 1 314 587
assign 1 315 588
heldGet 0 315 588
assign 1 315 589
newNpGet 0 315 589
assign 1 317 592
containedGet 0 317 592
assign 1 317 593
firstGet 0 317 593
assign 1 321 594
heldGet 0 321 594
assign 1 321 595
isDeclaredGet 0 321 595
assign 1 322 597
heldGet 0 322 597
assign 1 324 600
ptyMapGet 0 324 600
assign 1 324 601
heldGet 0 324 601
assign 1 324 602
nameGet 0 324 602
assign 1 324 603
get 1 324 603
assign 1 324 604
memSynGet 0 324 604
assign 1 327 606
isTypedGet 0 327 606
assign 1 328 608
namepathGet 0 328 608
assign 1 331 611
def 1 331 616
assign 1 333 617
getSynNp 1 333 617
assign 1 334 618
mtdMapGet 0 334 618
assign 1 334 619
heldGet 0 334 619
assign 1 334 620
nameGet 0 334 620
assign 1 334 621
get 1 334 621
assign 1 335 622
def 1 335 627
assign 1 337 628
rsynGet 0 337 628
assign 1 338 629
def 1 338 634
assign 1 338 635
isTypedGet 0 338 635
assign 1 0 637
assign 1 0 640
assign 1 0 644
assign 1 339 647
new 0 339 647
assign 1 341 648
isSelfGet 0 341 648
namepathSet 1 342 650
assign 1 344 653
namepathGet 0 344 653
namepathSet 1 344 654
assign 1 346 656
isTypedGet 0 346 656
isTypedSet 1 346 657
assign 1 347 658
heldGet 0 347 658
assign 1 347 659
namepathGet 0 347 659
addUsed 1 347 660
assign 1 348 661
namepathGet 0 348 661
assign 1 348 662
toString 0 348 662
assign 1 348 663
new 0 348 663
assign 1 348 664
equals 1 348 664
assign 1 348 666
new 0 348 666
assign 1 348 667
isSelfGet 0 348 667
assign 1 348 668
add 1 348 668
print 0 348 669
assign 1 350 674
heldGet 0 350 674
assign 1 350 675
orgNameGet 0 350 675
assign 1 350 676
new 0 350 676
assign 1 350 677
notEquals 1 350 677
assign 1 351 679
mtdMapGet 0 351 679
assign 1 351 680
new 0 351 680
assign 1 351 681
get 1 351 681
assign 1 352 682
def 1 352 687
assign 1 352 688
originGet 0 352 688
assign 1 352 689
toString 0 352 689
assign 1 352 690
new 0 352 690
assign 1 352 691
notEquals 1 352 691
assign 1 0 693
assign 1 0 696
assign 1 0 700
assign 1 353 703
heldGet 0 353 703
assign 1 353 704
new 0 353 704
isForwardSet 1 353 705
assign 1 355 708
new 0 355 708
assign 1 355 709
heldGet 0 355 709
assign 1 355 710
nameGet 0 355 710
assign 1 355 711
add 1 355 711
assign 1 355 712
new 0 355 712
assign 1 355 713
add 1 355 713
assign 1 355 714
toString 0 355 714
assign 1 355 715
add 1 355 715
assign 1 355 716
new 2 355 716
throw 1 355 717
assign 1 361 724
isFirstGet 0 361 724
assign 1 361 726
containerGet 0 361 726
assign 1 361 727
typenameGet 0 361 727
assign 1 361 728
CALLGet 0 361 728
assign 1 361 729
equals 1 361 729
assign 1 0 731
assign 1 0 734
assign 1 0 738
assign 1 361 741
containerGet 0 361 741
assign 1 361 742
heldGet 0 361 742
assign 1 361 743
orgNameGet 0 361 743
assign 1 361 744
new 0 361 744
assign 1 361 745
equals 1 361 745
assign 1 0 747
assign 1 0 750
assign 1 0 754
assign 1 361 757
containerGet 0 361 757
assign 1 361 758
secondGet 0 361 758
assign 1 361 759
typenameGet 0 361 759
assign 1 361 760
VARGet 0 361 760
assign 1 361 761
equals 1 361 761
assign 1 0 763
assign 1 0 766
assign 1 0 770
assign 1 362 773
containerGet 0 362 773
assign 1 362 774
secondGet 0 362 774
assign 1 362 775
heldGet 0 362 775
assign 1 364 776
isTypedGet 0 364 776
assign 1 366 778
new 0 366 778
assign 1 368 779
isTypedGet 0 368 779
isTypedSet 1 368 780
assign 1 369 781
namepathGet 0 369 781
namepathSet 1 369 782
return 1 0 805
assign 1 0 808
return 1 0 812
assign 1 0 815
return 1 0 819
assign 1 0 822
return 1 0 826
assign 1 0 829
return 1 0 833
assign 1 0 836
return 1 0 840
assign 1 0 843
return 1 0 847
assign 1 0 850
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 492712940: return bem_processTmps_0();
case -1170883362: return bem_deserializeClassNameGet_0();
case -869030838: return bem_hashGet_0();
case -694642189: return bem_serializationIteratorGet_0();
case 716581775: return bem_fieldIteratorGet_0();
case -1759446842: return bem_emitterGet_0();
case -222699673: return bem_ntypesGet_0();
case 1276785109: return bem_once_0();
case -838633237: return bem_serializeToString_0();
case -912670062: return bem_buildGet_0();
case -327890059: return bem_toString_0();
case 1885938794: return bem_toAny_0();
case 1778404598: return bem_tagGet_0();
case 1207509984: return bem_print_0();
case -683546224: return bem_inClassNpGet_0();
case -864977132: return bem_echo_0();
case 201753632: return bem_constGet_0();
case -1626502172: return bem_iteratorGet_0();
case -231534902: return bem_new_0();
case -2131755969: return bem_transGet_0();
case 1964495741: return bem_serializeContents_0();
case -151516979: return bem_tvmapGet_0();
case 753595156: return bem_nlGet_0();
case -108593702: return bem_sourceFileNameGet_0();
case -271301923: return bem_rmapGet_0();
case -296700272: return bem_create_0();
case -640694898: return bem_many_0();
case 1332787293: return bem_inClassSynGet_0();
case -1470416551: return bem_copy_0();
case 498230251: return bem_classNameGet_0();
case 1514150846: return bem_inClassGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1697977276: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1285310872: return bem_buildSet_1(bevd_0);
case 919867593: return bem_tvmapSet_1(bevd_0);
case -1805705632: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1654000102: return bem_ntypesSet_1(bevd_0);
case 869562099: return bem_nlSet_1(bevd_0);
case -1130213523: return bem_inClassNpSet_1(bevd_0);
case 41506532: return bem_otherClass_1(bevd_0);
case -1118008475: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -341054699: return bem_undefined_1(bevd_0);
case -254805022: return bem_transSet_1(bevd_0);
case -996916931: return bem_copyTo_1(bevd_0);
case -1242523352: return bem_inClassSynSet_1(bevd_0);
case 1640060912: return bem_rmapSet_1(bevd_0);
case 1992587527: return bem_end_1(bevd_0);
case 398724989: return bem_constSet_1(bevd_0);
case 1609046381: return bem_emitterSet_1(bevd_0);
case 1971930884: return bem_notEquals_1(bevd_0);
case 1349020478: return bem_sameObject_1(bevd_0);
case 1129766768: return bem_begin_1(bevd_0);
case -1363115649: return bem_equals_1(bevd_0);
case -898771829: return bem_otherType_1(bevd_0);
case 872576564: return bem_inClassSet_1(bevd_0);
case -1237205225: return bem_sameClass_1(bevd_0);
case -2022931262: return bem_defined_1(bevd_0);
case 871367475: return bem_def_1(bevd_0);
case 1029744872: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 873867702: return bem_undef_1(bevd_0);
case -1073870688: return bem_sameType_1(bevd_0);
case 2041683748: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 508127182: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1597816100: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -282965627: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1721714391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -48765507: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1009765426: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1302207765: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
}
}
