namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileReader : BEC_2_2_6_IOReader {
public BEC_3_2_4_6_IOFileReader() { }
static BEC_3_2_4_6_IOFileReader() { }
private static byte[] becc_BEC_3_2_4_6_IOFileReader_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileReader_bels_0 = {0x46,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileReader_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileReader_bels_0, 5));
private static byte[] bece_BEC_3_2_4_6_IOFileReader_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileReader_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileReader_bels_1, 30));
public static new BEC_3_2_4_6_IOFileReader bece_BEC_3_2_4_6_IOFileReader_bevs_inst;

public static new BET_3_2_4_6_IOFileReader bece_BEC_3_2_4_6_IOFileReader_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public virtual BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bem_new_0();
bevp_blockSize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1024));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_fhpatha = bevp_path.bem_toString_0();

      if (this.bevi_is == null) {
        string bevls_spath = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        this.bevi_is = new FileStream(bevls_spath, FileMode.Open);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      if (bevp_isClosed == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
if (bevp_isClosed.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevt_5_tmpany_phold = bece_BEC_3_2_4_6_IOFileReader_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_fhpatha);
bevt_6_tmpany_phold = bece_BEC_3_2_4_6_IOFileReader_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 138 */
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileReader bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {64, 65, 69, 69, 84, 137, 137, 0, 0, 0, 138, 138, 138, 138, 138, 138, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 38, 45, 50, 51, 55, 58, 62, 63, 64, 65, 66, 67, 72, 75, 78, 82};
/* BEGIN LINEINFO 
new 0 64 22
assign 1 65 23
new 0 65 23
assign 1 69 24
new 1 69 24
pathSet 1 69 25
assign 1 84 38
toString 0 84 38
assign 1 137 45
undef 1 137 50
assign 1 0 51
assign 1 0 55
assign 1 0 58
assign 1 138 62
new 0 138 62
assign 1 138 63
add 1 138 63
assign 1 138 64
new 0 138 64
assign 1 138 65
add 1 138 65
assign 1 138 66
new 1 138 66
throw 1 138 67
return 1 0 72
return 1 0 75
assign 1 0 78
assign 1 0 82
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1612095707: return bem_pathGetDirect_0();
case -139353918: return bem_toAny_0();
case -2058654018: return bem_toString_0();
case -1943120126: return bem_serializeToString_0();
case 1990625095: return bem_tagGet_0();
case 1270116221: return bem_open_0();
case 1310168666: return bem_copy_0();
case -320545548: return bem_sourceFileNameGet_0();
case -1456235115: return bem_echo_0();
case 668930393: return bem_pathGet_0();
case 1147856721: return bem_fieldIteratorGet_0();
case -166586667: return bem_readBufferLine_0();
case 341148236: return bem_once_0();
case -919690617: return bem_readBuffer_0();
case -256176855: return bem_iteratorGet_0();
case 148319359: return bem_new_0();
case 2121617532: return bem_hashGet_0();
case -140400327: return bem_readString_0();
case -740937572: return bem_print_0();
case -1797964019: return bem_classNameGet_0();
case -1359748897: return bem_vfileGet_0();
case -484934042: return bem_blockSizeGetDirect_0();
case 332613786: return bem_serializeContents_0();
case 1464830293: return bem_isClosedGet_0();
case 1132446437: return bem_readStringClose_0();
case 331003873: return bem_vfileGetDirect_0();
case 190695838: return bem_extOpen_0();
case 734060929: return bem_serializationIteratorGet_0();
case -41276197: return bem_create_0();
case 754120077: return bem_isClosedGetDirect_0();
case -865211167: return bem_many_0();
case 903178719: return bem_fieldNamesGet_0();
case 1548888304: return bem_close_0();
case -2027679173: return bem_deserializeClassNameGet_0();
case -1662663316: return bem_blockSizeGet_0();
case 172676702: return bem_byteReaderGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1350346500: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1407546366: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -116587458: return bem_sameType_1(bevd_0);
case -1829045189: return bem_otherClass_1(bevd_0);
case -2023862139: return bem_equals_1(bevd_0);
case 55946271: return bem_notEquals_1(bevd_0);
case 1775649439: return bem_blockSizeSetDirect_1(bevd_0);
case -1352807597: return bem_pathSet_1(bevd_0);
case 1985783592: return bem_otherType_1(bevd_0);
case 159840292: return bem_pathSetDirect_1(bevd_0);
case 976863422: return bem_vfileSetDirect_1(bevd_0);
case -1103247882: return bem_blockSizeSet_1(bevd_0);
case 1129819292: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -245605778: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -927085439: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 550510840: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 825055568: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 649776492: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2133166360: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -247019574: return bem_vfileSet_1(bevd_0);
case 1062283119: return bem_isClosedSet_1(bevd_0);
case 306277101: return bem_undefined_1(bevd_0);
case -264091635: return bem_copyTo_1(bevd_0);
case -296742223: return bem_isClosedSetDirect_1(bevd_0);
case 261224447: return bem_new_1(bevd_0);
case 906711890: return bem_sameObject_1(bevd_0);
case 346911699: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1679251333: return bem_undef_1(bevd_0);
case 1865504944: return bem_sameClass_1(bevd_0);
case 2070971991: return bem_def_1(bevd_0);
case 635105057: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1372536257: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 710095661: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1798728092: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1286703705: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -275173380: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 704289821: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -434987531: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1105189015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1174970450: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 582619463: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_6_IOFileReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_inst = (BEC_3_2_4_6_IOFileReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_type;
}
}
}
