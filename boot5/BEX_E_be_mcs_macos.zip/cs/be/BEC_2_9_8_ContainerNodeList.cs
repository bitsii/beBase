namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList : BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
static BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static new BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public override BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_10_9_ContainerLinkedListAwareNode) (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {112, 112};
public static new int[] bevs_smnlec
 = new int[] {14, 15};
/* BEGIN LINEINFO 
assign 1 112 14
new 2 112 14
return 1 112 15
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -639622757: return bem_hashGet_0();
case -2015039528: return bem_iteratorGet_0();
case 1502992604: return bem_lastGet_0();
case 1981673449: return bem_lastNodeGetDirect_0();
case -756158517: return bem_linkedListIteratorGet_0();
case -990059379: return bem_toNodeList_0();
case 965815191: return bem_echo_0();
case 105645045: return bem_many_0();
case 940651019: return bem_once_0();
case -296688753: return bem_print_0();
case 2070190337: return bem_thirdGet_0();
case 1132167746: return bem_firstNodeGetDirect_0();
case -1578327045: return bem_serializeContents_0();
case 993863115: return bem_fieldIteratorGet_0();
case 617667581: return bem_toAny_0();
case 770044727: return bem_deserializeClassNameGet_0();
case -1400364749: return bem_serializationIteratorGet_0();
case -1596775328: return bem_serializeToString_0();
case -800987538: return bem_reverse_0();
case 1552820506: return bem_classNameGet_0();
case -1639524545: return bem_secondGet_0();
case -305948609: return bem_sizeGet_0();
case 1167480829: return bem_copy_0();
case -479359240: return bem_tagGet_0();
case -1870744239: return bem_firstGet_0();
case 1413459969: return bem_isEmptyGet_0();
case 1470127612: return bem_sourceFileNameGet_0();
case 923761516: return bem_toList_0();
case 2061232622: return bem_lengthGet_0();
case -1039531132: return bem_create_0();
case 1559029392: return bem_lastNodeGet_0();
case 2066844567: return bem_fieldNamesGet_0();
case -688862469: return bem_toString_0();
case -1453318633: return bem_new_0();
case -1079111227: return bem_firstNodeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1447883638: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 323831111: return bem_undef_1(bevd_0);
case -1416339029: return bem_sameObject_1(bevd_0);
case 775000177: return bem_lastNodeSetDirect_1(bevd_0);
case -1204908879: return bem_addValue_1(bevd_0);
case -1365097484: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1979045723: return bem_appendNode_1(bevd_0);
case -829661193: return bem_addAll_1(bevd_0);
case 1503413748: return bem_undefined_1(bevd_0);
case 1545593538: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1357382359: return bem_iterateAdd_1(bevd_0);
case 1879722769: return bem_sameClass_1(bevd_0);
case -238977579: return bem_getNode_1(bevd_0);
case 1279513896: return bem_addValueWhole_1(bevd_0);
case -2048076942: return bem_firstNodeSet_1(bevd_0);
case 1269999424: return bem_deleteNode_1(bevd_0);
case 745858586: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 1788125681: return bem_newNode_1(bevd_0);
case 1489408670: return bem_sameType_1(bevd_0);
case -1371991213: return bem_prependNode_1(bevd_0);
case -1300492421: return bem_otherType_1(bevd_0);
case -1197332143: return bem_otherClass_1(bevd_0);
case -1645761574: return bem_lastNodeSet_1(bevd_0);
case -1073960196: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 189658019: return bem_defined_1(bevd_0);
case -1202688048: return bem_def_1(bevd_0);
case -1596168486: return bem_equals_1(bevd_0);
case 1669585004: return bem_prepend_1(bevd_0);
case 419445436: return bem_copyTo_1(bevd_0);
case -1076480041: return bem_notEquals_1(bevd_0);
case 1307926562: return bem_firstNodeSetDirect_1(bevd_0);
case -884635357: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 576408039: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1323585037: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 282981748: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -437555976: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -624371870: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2145191247: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1711810653: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 948941179: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case 1285045766: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 787023569: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_8_ContainerNodeList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
}
