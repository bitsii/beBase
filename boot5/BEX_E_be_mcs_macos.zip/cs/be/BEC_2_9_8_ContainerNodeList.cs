namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_8_ContainerNodeList : BEC_2_9_10_ContainerLinkedList {
public BEC_2_9_8_ContainerNodeList() { }
static BEC_2_9_8_ContainerNodeList() { }
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4E,0x6F,0x64,0x65,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_8_ContainerNodeList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_inst;

public static new BET_2_9_8_ContainerNodeList bece_BEC_2_9_8_ContainerNodeList_bevs_type;

public override BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) {
BEC_3_9_10_9_ContainerLinkedListAwareNode bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_9_10_9_ContainerLinkedListAwareNode) (new BEC_3_9_10_9_ContainerLinkedListAwareNode()).bem_new_2(beva_toHold, this);
return bevt_0_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {111, 111};
public static new int[] bevs_smnlec
 = new int[] {14, 15};
/* BEGIN LINEINFO 
assign 1 111 14
new 2 111 14
return 1 111 15
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1482984555: return bem_sizeGet_0();
case 485413890: return bem_toList_0();
case -2129983068: return bem_toAny_0();
case 529284437: return bem_reverse_0();
case 879975179: return bem_classNameGet_0();
case 2125361805: return bem_isEmptyGet_0();
case -1084228149: return bem_print_0();
case -1006617970: return bem_secondGet_0();
case 1843544518: return bem_serializeContents_0();
case -153156208: return bem_serializationIteratorGet_0();
case -1588532100: return bem_echo_0();
case 162533386: return bem_fieldNamesGet_0();
case 233362262: return bem_many_0();
case 887739950: return bem_serializeToString_0();
case 2146386956: return bem_firstGet_0();
case 339902866: return bem_firstNodeGet_0();
case 110382217: return bem_sourceFileNameGet_0();
case 2071597061: return bem_create_0();
case 1989693945: return bem_toString_0();
case 1132897690: return bem_lastGet_0();
case 888041456: return bem_tagGet_0();
case -1411032825: return bem_toNodeList_0();
case -187762145: return bem_firstNodeGetDirect_0();
case 714460463: return bem_once_0();
case 1992233456: return bem_lastNodeGetDirect_0();
case 1105152133: return bem_new_0();
case -2057723625: return bem_thirdGet_0();
case 89485470: return bem_linkedListIteratorGet_0();
case 1986590366: return bem_hashGet_0();
case 2047518896: return bem_lengthGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 1488113430: return bem_lastNodeGet_0();
case 1732513565: return bem_copy_0();
case 1383646476: return bem_iteratorGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 388340258: return bem_addValue_1(bevd_0);
case -69486772: return bem_iterateAdd_1(bevd_0);
case -1395972424: return bem_addValueWhole_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case -695320255: return bem_lastNodeSet_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -183598233: return bem_firstNodeSet_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case -1604611880: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case -889856693: return bem_getNode_1(bevd_0);
case -1996970624: return bem_prependNode_1(bevd_0);
case -665114254: return bem_addAll_1(bevd_0);
case -549963417: return bem_deleteNode_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -831012863: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1143494633: return bem_newNode_1(bevd_0);
case 958824950: return bem_lastNodeSetDirect_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case 1859727647: return bem_appendNode_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -372145160: return bem_prepend_1(bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1444110696: return bem_firstNodeSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 674259766: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -368888707: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -113038329: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_8_ContainerNodeList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_8_ContainerNodeList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_8_ContainerNodeList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst = (BEC_2_9_8_ContainerNodeList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_8_ContainerNodeList.bece_BEC_2_9_8_ContainerNodeList_bevs_type;
}
}
}
