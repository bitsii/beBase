namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_10_SystemTestExtendable : BEC_2_6_6_SystemObject {
public BEC_3_6_4_10_SystemTestExtendable() { }
static BEC_3_6_4_10_SystemTestExtendable() { }
private static byte[] becc_BEC_3_6_4_10_SystemTestExtendable_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x45,0x78,0x74,0x65,0x6E,0x64,0x61,0x62,0x6C,0x65};
private static byte[] becc_BEC_3_6_4_10_SystemTestExtendable_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_3_6_4_10_SystemTestExtendable bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst;

public static new BET_3_6_4_10_SystemTestExtendable bece_BEC_3_6_4_10_SystemTestExtendable_bevs_type;

public BEC_2_6_6_SystemObject bevp_propa;
public BEC_2_6_6_SystemObject bevp_propb;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_acall_0() {
return this;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_bcall_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_propaGet_0() {
return bevp_propa;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propaGetDirect_0() {
return bevp_propa;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_propaSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propa = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_4_10_SystemTestExtendable bem_propaSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propa = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_propbGet_0() {
return bevp_propb;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propbGetDirect_0() {
return bevp_propb;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_propbSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propb = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_4_10_SystemTestExtendable bem_propbSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propb = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 27, 30, 34, 38, 41, 44, 48};
/* BEGIN LINEINFO 
return 1 0 24
return 1 0 27
assign 1 0 30
assign 1 0 34
return 1 0 38
return 1 0 41
assign 1 0 44
assign 1 0 48
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 64930083: return bem_new_0();
case 1916631538: return bem_propaGetDirect_0();
case -1160093527: return bem_fieldIteratorGet_0();
case 265775004: return bem_tagGet_0();
case 1259379161: return bem_sourceFileNameGet_0();
case 338892103: return bem_serializeContents_0();
case 1685630819: return bem_toAny_0();
case 324558137: return bem_serializationIteratorGet_0();
case -1924670591: return bem_print_0();
case 1616298039: return bem_toString_0();
case -477793454: return bem_deserializeClassNameGet_0();
case -952762516: return bem_bcall_0();
case -2145124906: return bem_fieldNamesGet_0();
case -383409287: return bem_hashGet_0();
case 1698440478: return bem_classNameGet_0();
case 1409367716: return bem_iteratorGet_0();
case -698592158: return bem_once_0();
case 857744439: return bem_serializeToString_0();
case 447398905: return bem_copy_0();
case -1182212964: return bem_propbGetDirect_0();
case -1707071611: return bem_propbGet_0();
case 24523401: return bem_create_0();
case -1736129046: return bem_propaGet_0();
case 1574541715: return bem_echo_0();
case 621904783: return bem_many_0();
case -1190940961: return bem_acall_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2121299936: return bem_propbSet_1(bevd_0);
case -52657747: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1270041233: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1582703619: return bem_undef_1(bevd_0);
case 854851905: return bem_sameType_1(bevd_0);
case -685667652: return bem_undefined_1(bevd_0);
case -346349789: return bem_equals_1(bevd_0);
case 1464921499: return bem_def_1(bevd_0);
case 604959651: return bem_otherClass_1(bevd_0);
case -1932510652: return bem_sameClass_1(bevd_0);
case -1921243842: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -745010937: return bem_propaSetDirect_1(bevd_0);
case 1882195140: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -907096239: return bem_otherType_1(bevd_0);
case -1768544084: return bem_notEquals_1(bevd_0);
case 2143817101: return bem_copyTo_1(bevd_0);
case -968521563: return bem_sameObject_1(bevd_0);
case -454090959: return bem_defined_1(bevd_0);
case -695333769: return bem_propbSetDirect_1(bevd_0);
case -364275978: return bem_propaSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1030898412: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1425194636: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1465437715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -918533412: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1025227425: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2024613175: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1438061795: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_6_4_10_SystemTestExtendable_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_10_SystemTestExtendable_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_4_10_SystemTestExtendable();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst = (BEC_3_6_4_10_SystemTestExtendable) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_type;
}
}
}
