namespace be {

using System;
using System.Threading;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeSleep : BEC_2_6_6_SystemObject {
public BEC_2_4_5_TimeSleep() { }
static BEC_2_4_5_TimeSleep() { }
private static byte[] becc_BEC_2_4_5_TimeSleep_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x6C,0x65,0x65,0x70};
private static byte[] becc_BEC_2_4_5_TimeSleep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_0 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_TimeSleep_bevo_1 = (new BEC_2_4_3_MathInt(1000));
public static new BEC_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_inst;

public static new BET_2_4_5_TimeSleep bece_BEC_2_4_5_TimeSleep_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_sleep_1(BEC_2_4_8_TimeInterval beva_interval) {
BEC_2_4_3_MathInt bevl_secs = null;
BEC_2_4_3_MathInt bevl_millis = null;
BEC_2_4_3_MathInt bevl_sleepMillis = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
if (beva_interval == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevl_secs = beva_interval.bem_secsGet_0();
bevl_millis = beva_interval.bem_millisGet_0();
if (bevl_secs == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 37 */ {
if (bevl_millis == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 37 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 37 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_0;
bevt_4_tmpany_phold = bevl_secs.bem_multiply_1(bevt_5_tmpany_phold);
bevl_sleepMillis = bevt_4_tmpany_phold.bem_add_1(bevl_millis);
bem_sleepMilliseconds_1(bevl_sleepMillis);
} /* Line: 39 */
} /* Line: 37 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sleepSeconds_1(BEC_2_4_3_MathInt beva_secs) {
BEC_2_4_5_TimeSleep bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_5_TimeSleep_bevo_1;
bevt_1_tmpany_phold = beva_secs.bem_multiply_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_5_TimeSleep) bem_sleepMilliseconds_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_5_TimeSleep bem_sleepMilliseconds_1(BEC_2_4_3_MathInt beva_msecs) {
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;

      Thread.Sleep(beva_msecs.bevi_int);
       /* Line: 86 */ {
} /* Line: 87 */
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {34, 34, 35, 36, 37, 37, 37, 37, 0, 0, 0, 38, 38, 38, 39, 45, 45, 45, 45};
public static new int[] bevs_smnlec
 = new int[] {33, 38, 39, 40, 41, 46, 47, 52, 53, 56, 60, 63, 64, 65, 66, 75, 76, 77, 78};
/* BEGIN LINEINFO 
assign 1 34 33
def 1 34 38
assign 1 35 39
secsGet 0 35 39
assign 1 36 40
millisGet 0 36 40
assign 1 37 41
def 1 37 46
assign 1 37 47
def 1 37 52
assign 1 0 53
assign 1 0 56
assign 1 0 60
assign 1 38 63
new 0 38 63
assign 1 38 64
multiply 1 38 64
assign 1 38 65
add 1 38 65
sleepMilliseconds 1 39 66
assign 1 45 75
new 0 45 75
assign 1 45 76
multiply 1 45 76
assign 1 45 77
sleepMilliseconds 1 45 77
return 1 45 78
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1045627857: return bem_create_0();
case -1723287273: return bem_fieldIteratorGet_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case 1690848108: return bem_echo_0();
case 1426474238: return bem_once_0();
case -2091217929: return bem_toAny_0();
case 237106258: return bem_default_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 805348767: return bem_serializationIteratorGet_0();
case 1776712568: return bem_iteratorGet_0();
case 1340694490: return bem_new_0();
case -856707590: return bem_tagGet_0();
case 1365471067: return bem_print_0();
case 756642383: return bem_fieldNamesGet_0();
case -1287943088: return bem_copy_0();
case -348782970: return bem_serializeToString_0();
case 1963695386: return bem_toString_0();
case -1303115743: return bem_hashGet_0();
case 353377191: return bem_classNameGet_0();
case -835303456: return bem_many_0();
case -723282878: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2129603513: return bem_defined_1(bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case -550139783: return bem_otherType_1(bevd_0);
case 1275555896: return bem_sleepSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case -1412377002: return bem_undef_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -480348635: return bem_def_1(bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case -228940652: return bem_sleep_1((BEC_2_4_8_TimeInterval) bevd_0);
case 838174241: return bem_sleepMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -793887534: return bem_otherClass_1(bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeSleep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeSleep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_TimeSleep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst = (BEC_2_4_5_TimeSleep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_5_TimeSleep.bece_BEC_2_4_5_TimeSleep_bevs_type;
}
}
}
