namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_6_SystemRandom : BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }
static BEC_2_6_6_SystemRandom() { }

   
   public RandomNumberGenerator srand = RNGCryptoServiceProvider.Create();
   
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_1 = (new BEC_2_4_3_MathInt(65));
public static new BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static new BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() {

      srand = RNGCryptoServiceProvider.Create();
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getInt_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) {

      byte[] rb = new byte[4];
      srand.GetBytes(rb);
      beva_value.bevi_int = BitConverter.ToInt32(rb, 0);
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_2_tmpany_phold = bem_getInt_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_getInt_1(beva_value);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpany_phold = bem_getString_2(bevt_1_tmpany_phold, beva_size);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_str.bem_capacityGet_0();
if (bevt_1_tmpany_phold.bevi_int < beva_size.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 277 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 278 */
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpany_phold);
bevl_value = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 286 */ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_0;
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) bevt_9_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bem_getIntMax_2(bevl_value, bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_1;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevt_7_tmpany_phold;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 286 */
 else  /* Line: 286 */ {
break;
} /* Line: 286 */
} /* Line: 286 */
return beva_str;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {202, 230, 230, 230, 261, 265, 265, 265, 265, 265, 269, 269, 269, 269, 273, 273, 273, 277, 277, 277, 278, 280, 280, 285, 286, 286, 286, 288, 288, 288, 288, 288, 288, 288, 286, 290};
public static new int[] bevs_smnlec
 = new int[] {27, 38, 39, 40, 47, 54, 55, 56, 57, 58, 64, 65, 66, 67, 72, 73, 74, 91, 92, 97, 98, 100, 101, 102, 103, 106, 111, 112, 113, 114, 115, 116, 117, 119, 120, 126};
/* BEGIN LINEINFO 
seedNow 0 202 27
assign 1 230 38
new 0 230 38
assign 1 230 39
getInt 1 230 39
return 1 230 40
return 1 261 47
assign 1 265 54
new 0 265 54
assign 1 265 55
getInt 1 265 55
assign 1 265 56
absValue 0 265 56
assign 1 265 57
modulusValue 1 265 57
return 1 265 58
assign 1 269 64
getInt 1 269 64
assign 1 269 65
absValue 0 269 65
assign 1 269 66
modulusValue 1 269 66
return 1 269 67
assign 1 273 72
new 1 273 72
assign 1 273 73
getString 2 273 73
return 1 273 74
assign 1 277 91
capacityGet 0 277 91
assign 1 277 92
lesser 1 277 97
capacitySet 1 278 98
assign 1 280 100
copy 0 280 100
sizeSet 1 280 101
assign 1 285 102
new 0 285 102
assign 1 286 103
new 0 286 103
assign 1 286 106
lesser 1 286 111
assign 1 288 112
new 0 288 112
assign 1 288 113
once 0 288 113
assign 1 288 114
getIntMax 2 288 114
assign 1 288 115
new 0 288 115
assign 1 288 116
once 0 288 116
assign 1 288 117
addValue 1 288 117
setIntUnchecked 2 288 119
incrementValue 0 286 120
return 1 290 126
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1852877275: return bem_new_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -236887613: return bem_classNameGet_0();
case 1076647192: return bem_create_0();
case -2092760709: return bem_once_0();
case 1359360249: return bem_echo_0();
case 1064677251: return bem_many_0();
case 560376136: return bem_seedNow_0();
case 605836827: return bem_sourceFileNameGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 928457034: return bem_serializeContents_0();
case -1430066973: return bem_print_0();
case -323661464: return bem_serializeToString_0();
case 849387251: return bem_toAny_0();
case 9393320: return bem_getInt_0();
case 1910979786: return bem_default_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
case 996718380: return bem_toString_0();
case -1369483363: return bem_fieldNamesGet_0();
case 864393987: return bem_tagGet_0();
case 2070502838: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -960159496: return bem_otherClass_1(bevd_0);
case 1982127606: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -1416994177: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1949727967: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1356613099: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1162022915: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemRandom();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
}
