namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_6_BuildPtySyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildPtySyn() { }
static BEC_2_5_6_BuildPtySyn() { }
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x74,0x79,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_0 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_0, 8));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_1, 4));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_2 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_3 = {0x6D,0x65,0x6D,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_4 = {0x61,0x6E,0x79};
public static new BEC_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_inst;

public static new BET_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_type;

public BEC_2_4_3_MathInt bevp_mpos;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_6_BuildVarSyn bevp_memSyn;
public BEC_2_5_6_BuildPtySyn bem_new_2(BEC_2_6_6_SystemObject beva_vnode, BEC_2_6_6_SystemObject beva__origin) {
BEC_2_5_3_BuildVar bevl_v = null;
bevl_v = (BEC_2_5_3_BuildVar) beva_vnode.bemd_0(-108099280);
bevp_name = bevl_v.bem_nameGet_0();
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1(bevl_v);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_5_tmpany_phold = bece_BEC_2_5_6_BuildPtySyn_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_nl);
bevt_6_tmpany_phold = bece_BEC_2_5_6_BuildPtySyn_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevl_nl);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevl_toRet = bevt_1_tmpany_phold.bem_add_1(bevl_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildPtySyn_bels_2));
bevt_9_tmpany_phold = bevl_toRet.bemd_1(2072584689, bevt_10_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(2072584689, bevl_nl);
bevt_11_tmpany_phold = bevp_origin.bem_toString_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(2072584689, bevt_11_tmpany_phold);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(2072584689, bevl_nl);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildPtySyn_bels_3));
bevt_12_tmpany_phold = bevl_toRet.bemd_1(2072584689, bevt_13_tmpany_phold);
bevl_toRet = bevt_12_tmpany_phold.bemd_1(2072584689, bevl_nl);
bevt_14_tmpany_phold = bevp_memSyn.bem_isTypedGet_0();
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_17_tmpany_phold = bevp_memSyn.bem_namepathGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_toString_0();
bevt_15_tmpany_phold = bevl_toRet.bemd_1(2072584689, bevt_16_tmpany_phold);
bevl_toRet = bevt_15_tmpany_phold.bemd_1(2072584689, bevl_nl);
} /* Line: 523 */
 else  /* Line: 524 */ {
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildPtySyn_bels_4));
bevt_18_tmpany_phold = bevl_toRet.bemd_1(2072584689, bevt_19_tmpany_phold);
bevl_toRet = bevt_18_tmpany_phold.bemd_1(2072584689, bevl_nl);
} /* Line: 525 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_mposGet_0() {
return bevp_mpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_mposGetDirect_0() {
return bevp_mpos;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_mposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_mposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGetDirect_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_originSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_memSynGet_0() {
return bevp_memSyn;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_memSynGetDirect_0() {
return bevp_memSyn;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_memSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_memSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {507, 511, 512, 513, 518, 518, 519, 519, 519, 519, 519, 519, 519, 520, 520, 520, 520, 520, 520, 521, 521, 521, 522, 523, 523, 523, 523, 525, 525, 525, 527, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 28, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 74, 75, 76, 77, 80, 81, 82, 84, 87, 90, 93, 97, 101, 104, 107, 111, 115, 118, 121, 125, 129, 132, 135, 139};
/* BEGIN LINEINFO 
assign 1 507 25
heldGet 0 507 25
assign 1 511 26
nameGet 0 511 26
assign 1 512 27
assign 1 513 28
anyNew 1 513 28
assign 1 518 54
new 0 518 54
assign 1 518 55
newlineGet 0 518 55
assign 1 519 56
new 0 519 56
assign 1 519 57
add 1 519 57
assign 1 519 58
new 0 519 58
assign 1 519 59
add 1 519 59
assign 1 519 60
add 1 519 60
assign 1 519 61
add 1 519 61
assign 1 519 62
add 1 519 62
assign 1 520 63
new 0 520 63
assign 1 520 64
add 1 520 64
assign 1 520 65
add 1 520 65
assign 1 520 66
toString 0 520 66
assign 1 520 67
add 1 520 67
assign 1 520 68
add 1 520 68
assign 1 521 69
new 0 521 69
assign 1 521 70
add 1 521 70
assign 1 521 71
add 1 521 71
assign 1 522 72
isTypedGet 0 522 72
assign 1 523 74
namepathGet 0 523 74
assign 1 523 75
toString 0 523 75
assign 1 523 76
add 1 523 76
assign 1 523 77
add 1 523 77
assign 1 525 80
new 0 525 80
assign 1 525 81
add 1 525 81
assign 1 525 82
add 1 525 82
return 1 527 84
return 1 0 87
return 1 0 90
assign 1 0 93
assign 1 0 97
return 1 0 101
return 1 0 104
assign 1 0 107
assign 1 0 111
return 1 0 115
return 1 0 118
assign 1 0 121
assign 1 0 125
return 1 0 129
return 1 0 132
assign 1 0 135
assign 1 0 139
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1858345160: return bem_many_0();
case 1802337732: return bem_memSynGetDirect_0();
case -436164110: return bem_hashGet_0();
case -1474180855: return bem_copy_0();
case 1992383723: return bem_once_0();
case -592497163: return bem_nameGetDirect_0();
case -183071211: return bem_new_0();
case -941995054: return bem_print_0();
case 163561636: return bem_echo_0();
case 1659508682: return bem_iteratorGet_0();
case 922739318: return bem_fieldIteratorGet_0();
case -391566484: return bem_mposGet_0();
case -606275227: return bem_tagGet_0();
case 1979675315: return bem_toString_0();
case -1472038924: return bem_toAny_0();
case -1713867889: return bem_serializationIteratorGet_0();
case -1684408485: return bem_serializeContents_0();
case 1208183465: return bem_mposGetDirect_0();
case 1903027527: return bem_originGet_0();
case 2091325035: return bem_memSynGet_0();
case 2119526452: return bem_deserializeClassNameGet_0();
case -1265013519: return bem_fieldNamesGet_0();
case 1738596312: return bem_originGetDirect_0();
case -23361149: return bem_sourceFileNameGet_0();
case 1937136245: return bem_create_0();
case 439322172: return bem_classNameGet_0();
case -1302207362: return bem_serializeToString_0();
case 1717559145: return bem_nameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1473811380: return bem_defined_1(bevd_0);
case 579439581: return bem_mposSet_1(bevd_0);
case 987555878: return bem_sameType_1(bevd_0);
case 1770693036: return bem_mposSetDirect_1(bevd_0);
case 233690225: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -264806622: return bem_undefined_1(bevd_0);
case 1960686692: return bem_notEquals_1(bevd_0);
case -1581273032: return bem_otherType_1(bevd_0);
case 1617129647: return bem_sameObject_1(bevd_0);
case -822082723: return bem_memSynSet_1(bevd_0);
case 938978423: return bem_otherClass_1(bevd_0);
case -1031049575: return bem_copyTo_1(bevd_0);
case -1112596058: return bem_nameSet_1(bevd_0);
case 1614099349: return bem_originSetDirect_1(bevd_0);
case -1106603847: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -49958560: return bem_nameSetDirect_1(bevd_0);
case -339333895: return bem_equals_1(bevd_0);
case 2017705831: return bem_def_1(bevd_0);
case 766930230: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 612692222: return bem_originSet_1(bevd_0);
case 1070735389: return bem_undef_1(bevd_0);
case -1692946157: return bem_memSynSetDirect_1(bevd_0);
case 1524591721: return bem_sameClass_1(bevd_0);
case -805702504: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1628937971: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -779217973: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -727572211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -881140199: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 923430668: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 391353131: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1719602560: return bem_new_2(bevd_0, bevd_1);
case 838418125: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildPtySyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildPtySyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildPtySyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst = (BEC_2_5_6_BuildPtySyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_type;
}
}
}
