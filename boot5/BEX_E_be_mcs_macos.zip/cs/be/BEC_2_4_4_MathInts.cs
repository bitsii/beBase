namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_4_MathInts : BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
static BEC_2_4_4_MathInts() { }
private static byte[] becc_BEC_2_4_4_MathInts_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_4_4_MathInts_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_inst;
public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_default_0() {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl__min = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = int.MaxValue;
      bevl__min.bevi_int = int.MinValue;
      //Stream stdout = Console.OpenStandardOutput();
      //Console.WriteLine(bevl__max.bevi_int.ToString());
      //Console.WriteLine(bevl__min.bevi_int.ToString());
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_one = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 815 */ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 815 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 815 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 815 */ {
return beva_a;
} /* Line: 816 */
return beva_b;
} /*method end*/
public BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 822 */ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 822 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 822 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 822 */ {
return beva_a;
} /* Line: 823 */
return beva_b;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGet_0() {
return bevp_min;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() {
return bevp_one;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {767, 768, 807, 808, 809, 810, 815, 815, 0, 815, 815, 0, 0, 816, 818, 822, 822, 0, 822, 822, 0, 0, 823, 825, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 30, 31, 32, 33, 40, 45, 46, 49, 54, 55, 58, 62, 64, 70, 75, 76, 79, 84, 85, 88, 92, 94, 97, 100, 104, 107, 111, 114, 118, 121};
/* BEGIN LINEINFO 
assign 1 767 22
new 0 767 22
assign 1 768 23
new 0 768 23
assign 1 807 30
assign 1 808 31
assign 1 809 32
new 0 809 32
assign 1 810 33
new 0 810 33
assign 1 815 40
undef 1 815 45
assign 1 0 46
assign 1 815 49
lesser 1 815 54
assign 1 0 55
assign 1 0 58
return 1 816 62
return 1 818 64
assign 1 822 70
undef 1 822 75
assign 1 0 76
assign 1 822 79
greater 1 822 84
assign 1 0 85
assign 1 0 88
return 1 823 92
return 1 825 94
return 1 0 97
assign 1 0 100
return 1 0 104
assign 1 0 107
return 1 0 111
assign 1 0 114
return 1 0 118
assign 1 0 121
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 509465600: return bem_iteratorGet_0();
case 913636711: return bem_toAny_0();
case -967868612: return bem_oneGet_0();
case -2046432818: return bem_minGet_0();
case 876844323: return bem_serializationIteratorGet_0();
case 101959527: return bem_maxGet_0();
case -85596330: return bem_tagGet_0();
case 47547638: return bem_zeroGet_0();
case 1796230342: return bem_toString_0();
case -1427622449: return bem_create_0();
case -853067962: return bem_serializeContents_0();
case -904557663: return bem_print_0();
case -945812364: return bem_once_0();
case 905853766: return bem_default_0();
case 1398390067: return bem_classNameGet_0();
case -2066691170: return bem_hashGet_0();
case -1059501870: return bem_fieldIteratorGet_0();
case -1254976075: return bem_deserializeClassNameGet_0();
case -551829583: return bem_echo_0();
case -1414488789: return bem_copy_0();
case 1965225689: return bem_sourceFileNameGet_0();
case 1395453592: return bem_serializeToString_0();
case 332749494: return bem_many_0();
case 627584199: return bem_new_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 1789153529: return bem_equals_1(bevd_0);
case 1081898105: return bem_def_1(bevd_0);
case -406443070: return bem_maxSet_1(bevd_0);
case 1991875652: return bem_minSet_1(bevd_0);
case -1531639990: return bem_oneSet_1(bevd_0);
case 632969730: return bem_otherType_1(bevd_0);
case -1410322621: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1650785007: return bem_undefined_1(bevd_0);
case -1825570190: return bem_sameObject_1(bevd_0);
case -375396806: return bem_sameType_1(bevd_0);
case -2064416533: return bem_copyTo_1(bevd_0);
case 251217946: return bem_defined_1(bevd_0);
case 414867900: return bem_otherClass_1(bevd_0);
case -1398432640: return bem_sameClass_1(bevd_0);
case -2038649804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1121775076: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -533549049: return bem_zeroSet_1(bevd_0);
case 1213922529: return bem_notEquals_1(bevd_0);
case 2142029115: return bem_undef_1(bevd_0);
case -282488764: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -2045097182: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1418573133: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -113794903: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 75445916: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1467397408: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1606481035: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1823385565: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1716376212: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518297580: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_MathInts_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_4_MathInts_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_MathInts();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst = (BEC_2_4_4_MathInts) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
}
}
}
