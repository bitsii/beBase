namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_4_MathInts : BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
static BEC_2_4_4_MathInts() { }
private static byte[] becc_BEC_2_4_4_MathInts_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_4_4_MathInts_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_inst;

public static new BET_2_4_4_MathInts bece_BEC_2_4_4_MathInts_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_default_0() {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl__min = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = int.MaxValue;
      bevl__min.bevi_int = int.MinValue;
      //Stream stdout = Console.OpenStandardOutput();
      //Console.WriteLine(bevl__max.bevi_int.ToString());
      //Console.WriteLine(bevl__min.bevi_int.ToString());
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_one = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 964 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 964 */ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 964 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 964 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 964 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 964 */ {
return beva_a;
} /* Line: 965 */
return beva_b;
} /*method end*/
public BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 971 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 971 */ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 971 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 971 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 971 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 971 */ {
return beva_a;
} /* Line: 972 */
return beva_b;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGetDirect_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGet_0() {
return bevp_min;
} /*method end*/
public BEC_2_4_3_MathInt bem_minGetDirect_0() {
return bevp_min;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_minSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGetDirect_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGet_0() {
return bevp_one;
} /*method end*/
public BEC_2_4_3_MathInt bem_oneGetDirect_0() {
return bevp_one;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_4_MathInts bem_oneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {910, 911, 956, 957, 958, 959, 964, 964, 0, 964, 964, 0, 0, 965, 967, 971, 971, 0, 971, 971, 0, 0, 972, 974, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 33, 34, 35, 36, 43, 48, 49, 52, 57, 58, 61, 65, 67, 73, 78, 79, 82, 87, 88, 91, 95, 97, 100, 103, 106, 110, 114, 117, 120, 124, 128, 131, 134, 138, 142, 145, 148, 152};
/* BEGIN LINEINFO 
assign 1 910 25
new 0 910 25
assign 1 911 26
new 0 911 26
assign 1 956 33
assign 1 957 34
assign 1 958 35
new 0 958 35
assign 1 959 36
new 0 959 36
assign 1 964 43
undef 1 964 48
assign 1 0 49
assign 1 964 52
lesser 1 964 57
assign 1 0 58
assign 1 0 61
return 1 965 65
return 1 967 67
assign 1 971 73
undef 1 971 78
assign 1 0 79
assign 1 971 82
greater 1 971 87
assign 1 0 88
assign 1 0 91
return 1 972 95
return 1 974 97
return 1 0 100
return 1 0 103
assign 1 0 106
assign 1 0 110
return 1 0 114
return 1 0 117
assign 1 0 120
assign 1 0 124
return 1 0 128
return 1 0 131
assign 1 0 134
assign 1 0 138
return 1 0 142
return 1 0 145
assign 1 0 148
assign 1 0 152
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 222096027: return bem_classNameGet_0();
case 1115258825: return bem_create_0();
case -1141049131: return bem_iteratorGet_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case -672993382: return bem_minGet_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 434654272: return bem_hashGet_0();
case -1490452813: return bem_oneGet_0();
case -256194891: return bem_default_0();
case -14767827: return bem_serializeToString_0();
case -31410563: return bem_once_0();
case -1121300979: return bem_fieldNamesGet_0();
case -211098098: return bem_zeroGet_0();
case 1428178010: return bem_maxGet_0();
case 2146613587: return bem_zeroGetDirect_0();
case -2016997496: return bem_print_0();
case -1194274080: return bem_toAny_0();
case 306116222: return bem_echo_0();
case -417211766: return bem_oneGetDirect_0();
case 2035044181: return bem_minGetDirect_0();
case 516080386: return bem_maxGetDirect_0();
case 1747475389: return bem_many_0();
case 1999868679: return bem_fieldIteratorGet_0();
case 216845033: return bem_new_0();
case 1801694719: return bem_copy_0();
case 1366617398: return bem_tagGet_0();
case 2119098947: return bem_serializeContents_0();
case -1365182072: return bem_sourceFileNameGet_0();
case -1219673974: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -811515089: return bem_zeroSetDirect_1(bevd_0);
case 462099105: return bem_zeroSet_1(bevd_0);
case -1246021533: return bem_equals_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case 1531231200: return bem_maxSet_1(bevd_0);
case -1443085457: return bem_oneSet_1(bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case 1118927527: return bem_minSet_1(bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 838939835: return bem_minSetDirect_1(bevd_0);
case -1480014846: return bem_oneSetDirect_1(bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -240164168: return bem_undefined_1(bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case -1546754176: return bem_maxSetDirect_1(bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 422736202: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 995710410: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_MathInts_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_4_MathInts_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_MathInts();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst = (BEC_2_4_4_MathInts) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_type;
}
}
}
