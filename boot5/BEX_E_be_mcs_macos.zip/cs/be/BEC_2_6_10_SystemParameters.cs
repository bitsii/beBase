namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
static BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_1, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_3, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 1));
public static new BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static new BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevp_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) {
bem_new_0();
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 124 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(2061232622);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(1545593538, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(964225604, bevt_9_tmpany_phold);
beva__args.bemd_2(576408039, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 124 */
 else  /* Line: 124 */ {
break;
} /* Line: 124 */
} /* Line: 124 */
} /* Line: 124 */
bevp_args = (BEC_2_9_4_ContainerList) bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(-2015039528);
while (true)
 /* Line: 131 */ {
bevt_10_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1252731319);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-30891401);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_13_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
if (bevt_12_tmpany_phold.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevl_fa = bevl_i.bem_substring_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_18_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_17_tmpany_phold.bevi_int > bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fb = bevl_i.bem_substring_2(bevt_19_tmpany_phold, bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_23_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_22_tmpany_phold.bevi_int > bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 139 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fc = bevl_i.bem_substring_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
} /* Line: 140 */
} /* Line: 139 */
} /* Line: 137 */
if (bevl_pname == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 144 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 145 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 146 */
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 149 */
 else  /* Line: 144 */ {
if (bevl_fb == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
bevt_29_tmpany_phold = bevl_fb.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 150 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 150 */
 else  /* Line: 150 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 150 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_32_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
} /* Line: 151 */
 else  /* Line: 144 */ {
if (bevl_fa == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevt_34_tmpany_phold = bevl_fa.bem_equals_1(bevt_35_tmpany_phold);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 152 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 152 */
 else  /* Line: 152 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 152 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_37_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevl_pos = bevl_par.bem_find_1(bevt_38_tmpany_phold);
if (bevl_pos == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_40_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevl_key = bevl_par.bem_substring_2(bevt_40_tmpany_phold, bevl_pos);
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_41_tmpany_phold = bevl_pos.bem_add_1(bevt_42_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_41_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 158 */
} /* Line: 155 */
 else  /* Line: 144 */ {
if (bevl_fc == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 160 */ {
bevt_45_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevt_44_tmpany_phold = bevl_fc.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 160 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 160 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 160 */
 else  /* Line: 160 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 160 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevt_47_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 162 */
 else  /* Line: 144 */ {
if (bevl_fa == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_49_tmpany_phold = bevl_fa.bem_equals_1(bevt_50_tmpany_phold);
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 163 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 163 */
 else  /* Line: 163 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 163 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 164 */
} /* Line: 144 */
} /* Line: 144 */
} /* Line: 144 */
} /* Line: 144 */
} /* Line: 144 */
 else  /* Line: 131 */ {
break;
} /* Line: 131 */
} /* Line: 131 */
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 172 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(964225604, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 172 */
 else  /* Line: 172 */ {
break;
} /* Line: 172 */
} /* Line: 172 */
} /* Line: 172 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 177 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 177 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(964225604, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 177 */
 else  /* Line: 177 */ {
break;
} /* Line: 177 */
} /* Line: 177 */
} /* Line: 177 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 181 */ {
bevl__params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 183 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(-1252731319);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 183 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(-30891401);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 187 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 187 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(964225604, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 188 */
 else  /* Line: 187 */ {
break;
} /* Line: 187 */
} /* Line: 187 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(964225604, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 191 */
 else  /* Line: 183 */ {
break;
} /* Line: 183 */
} /* Line: 183 */
bevp_params = bevl__params;
} /* Line: 193 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 199 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 201 */
return beva_isit;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevl_pl = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 223 */
return bevl_pl;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 234 */ {
return beva_default;
} /* Line: 235 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevl_vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 249 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1173722063);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(-751466123);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(1341030253);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(923761516);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_orderedGet_0() {
return bevp_ordered;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGetDirect_0() {
return bevp_ordered;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_fileTokGet_0() {
return bevp_fileTok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() {
return bevp_fileTok;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_preProcessorGet_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_preProcessor = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {108, 109, 110, 111, 111, 118, 119, 123, 123, 124, 124, 124, 125, 125, 125, 124, 128, 129, 130, 131, 0, 131, 131, 132, 133, 134, 135, 135, 135, 135, 136, 136, 136, 137, 137, 137, 137, 138, 138, 138, 139, 139, 139, 139, 140, 140, 140, 144, 144, 145, 145, 146, 148, 149, 150, 150, 150, 150, 0, 0, 0, 151, 151, 151, 152, 152, 152, 152, 0, 0, 0, 153, 153, 153, 154, 154, 155, 155, 156, 156, 157, 157, 157, 158, 160, 160, 160, 160, 0, 0, 0, 161, 161, 161, 162, 163, 163, 163, 163, 0, 0, 0, 163, 163, 164, 170, 171, 171, 172, 172, 172, 172, 173, 173, 173, 172, 176, 176, 177, 177, 177, 177, 178, 178, 178, 177, 181, 181, 182, 183, 183, 184, 185, 186, 187, 0, 187, 187, 188, 188, 190, 191, 193, 198, 199, 199, 201, 204, 208, 208, 208, 212, 212, 216, 216, 220, 221, 221, 222, 223, 225, 229, 229, 233, 234, 234, 235, 237, 237, 241, 246, 247, 247, 248, 249, 251, 256, 256, 256, 257, 257, 258, 258, 259, 263, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {44, 45, 46, 47, 48, 52, 53, 120, 125, 126, 129, 130, 132, 133, 134, 135, 142, 143, 144, 145, 145, 148, 150, 151, 152, 153, 154, 155, 156, 161, 162, 163, 164, 165, 166, 167, 172, 173, 174, 175, 176, 177, 178, 183, 184, 185, 186, 190, 195, 196, 201, 202, 204, 205, 208, 213, 214, 215, 217, 220, 224, 227, 228, 229, 232, 237, 238, 239, 241, 244, 248, 251, 252, 253, 254, 255, 256, 261, 262, 263, 264, 265, 266, 267, 271, 276, 277, 278, 280, 283, 287, 290, 291, 292, 293, 296, 301, 302, 303, 305, 308, 312, 314, 319, 320, 356, 357, 362, 363, 366, 367, 372, 373, 374, 375, 376, 383, 388, 389, 392, 393, 398, 399, 400, 401, 402, 409, 414, 415, 416, 419, 421, 422, 423, 424, 424, 427, 429, 430, 431, 437, 438, 444, 451, 452, 457, 458, 460, 465, 466, 467, 471, 472, 476, 477, 482, 483, 488, 489, 490, 492, 496, 497, 503, 504, 509, 510, 512, 513, 516, 522, 523, 528, 529, 530, 532, 542, 543, 544, 545, 546, 547, 548, 549, 554, 555, 558, 561, 564, 568, 572, 575, 578, 582, 586, 589, 592, 596, 600, 603, 606, 610, 614, 617, 620};
/* BEGIN LINEINFO 
assign 1 108 44
new 0 108 44
assign 1 109 45
new 0 109 45
assign 1 110 46
new 0 110 46
assign 1 111 47
new 0 111 47
assign 1 111 48
new 1 111 48
new 0 118 52
addArgs 1 119 53
assign 1 123 120
def 1 123 125
assign 1 124 126
new 0 124 126
assign 1 124 129
lengthGet 0 124 129
assign 1 124 130
lesser 1 124 130
assign 1 125 132
get 1 125 132
assign 1 125 133
process 1 125 133
put 2 125 134
assign 1 124 135
increment 0 124 135
assign 1 128 142
add 1 128 142
assign 1 129 143
assign 1 130 144
new 0 130 144
assign 1 131 145
iteratorGet 0 0 145
assign 1 131 148
hasNextGet 0 131 148
assign 1 131 150
nextGet 0 131 150
assign 1 132 151
assign 1 133 152
assign 1 134 153
assign 1 135 154
sizeGet 0 135 154
assign 1 135 155
new 0 135 155
assign 1 135 156
greater 1 135 161
assign 1 136 162
new 0 136 162
assign 1 136 163
new 0 136 163
assign 1 136 164
substring 2 136 164
assign 1 137 165
sizeGet 0 137 165
assign 1 137 166
new 0 137 166
assign 1 137 167
greater 1 137 172
assign 1 138 173
new 0 138 173
assign 1 138 174
new 0 138 174
assign 1 138 175
substring 2 138 175
assign 1 139 176
sizeGet 0 139 176
assign 1 139 177
new 0 139 177
assign 1 139 178
greater 1 139 183
assign 1 140 184
new 0 140 184
assign 1 140 185
new 0 140 185
assign 1 140 186
substring 2 140 186
assign 1 144 190
def 1 144 195
assign 1 145 196
not 0 145 201
addParameter 2 146 202
assign 1 148 204
assign 1 149 205
new 0 149 205
assign 1 150 208
def 1 150 213
assign 1 150 214
new 0 150 214
assign 1 150 215
equals 1 150 215
assign 1 0 217
assign 1 0 220
assign 1 0 224
assign 1 151 227
new 0 151 227
assign 1 151 228
sizeGet 0 151 228
assign 1 151 229
substring 2 151 229
assign 1 152 232
def 1 152 237
assign 1 152 238
new 0 152 238
assign 1 152 239
equals 1 152 239
assign 1 0 241
assign 1 0 244
assign 1 0 248
assign 1 153 251
new 0 153 251
assign 1 153 252
sizeGet 0 153 252
assign 1 153 253
substring 2 153 253
assign 1 154 254
new 0 154 254
assign 1 154 255
find 1 154 255
assign 1 155 256
def 1 155 261
assign 1 156 262
new 0 156 262
assign 1 156 263
substring 2 156 263
assign 1 157 264
new 0 157 264
assign 1 157 265
add 1 157 265
assign 1 157 266
substring 1 157 266
addParameter 2 158 267
assign 1 160 271
def 1 160 276
assign 1 160 277
new 0 160 277
assign 1 160 278
equals 1 160 278
assign 1 0 280
assign 1 0 283
assign 1 0 287
assign 1 161 290
new 0 161 290
assign 1 161 291
sizeGet 0 161 291
assign 1 161 292
substring 2 161 292
assign 1 162 293
new 0 162 293
assign 1 163 296
def 1 163 301
assign 1 163 302
new 0 163 302
assign 1 163 303
equals 1 163 303
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 163 314
not 0 163 319
addValue 1 164 320
assign 1 170 356
assign 1 171 357
def 1 171 362
assign 1 172 363
new 0 172 363
assign 1 172 366
lengthGet 0 172 366
assign 1 172 367
lesser 1 172 372
assign 1 173 373
get 1 173 373
assign 1 173 374
process 1 173 374
put 2 173 375
assign 1 172 376
increment 0 172 376
assign 1 176 383
def 1 176 388
assign 1 177 389
new 0 177 389
assign 1 177 392
lengthGet 0 177 392
assign 1 177 393
lesser 1 177 398
assign 1 178 399
get 1 178 399
assign 1 178 400
process 1 178 400
put 2 178 401
assign 1 177 402
increment 0 177 402
assign 1 181 409
def 1 181 414
assign 1 182 415
new 0 182 415
assign 1 183 416
keyIteratorGet 0 183 416
assign 1 183 419
hasNextGet 0 183 419
assign 1 184 421
nextGet 0 184 421
assign 1 185 422
get 1 185 422
assign 1 186 423
new 0 186 423
assign 1 187 424
linkedListIteratorGet 0 0 424
assign 1 187 427
hasNextGet 0 187 427
assign 1 187 429
nextGet 0 187 429
assign 1 188 430
process 1 188 430
addValue 1 188 431
assign 1 190 437
process 1 190 437
put 2 191 438
assign 1 193 444
assign 1 198 451
getFirst 1 198 451
assign 1 199 452
def 1 199 457
assign 1 201 458
new 1 201 458
return 1 204 460
assign 1 208 465
new 0 208 465
assign 1 208 466
isTrue 2 208 466
return 1 208 467
assign 1 212 471
has 1 212 471
return 1 212 472
assign 1 216 476
get 1 216 476
return 1 216 477
assign 1 220 482
get 1 220 482
assign 1 221 483
undef 1 221 488
assign 1 222 489
new 0 222 489
addValue 1 223 490
return 1 225 492
assign 1 229 496
getFirst 2 229 496
return 1 229 497
assign 1 233 503
get 1 233 503
assign 1 234 504
undef 1 234 509
return 1 235 510
assign 1 237 512
firstGet 0 237 512
return 1 237 513
addParam 2 241 516
assign 1 246 522
get 1 246 522
assign 1 247 523
undef 1 247 528
assign 1 248 529
new 0 248 529
put 2 249 530
addValue 1 251 532
assign 1 256 542
readerGet 0 256 542
assign 1 256 543
open 0 256 543
assign 1 256 544
readString 0 256 544
assign 1 257 545
readerGet 0 257 545
close 0 257 546
assign 1 258 547
tokenize 1 258 547
assign 1 258 548
toList 0 258 548
addArgs 1 259 549
assign 1 263 554
iteratorGet 0 263 554
return 1 263 555
return 1 0 558
return 1 0 561
assign 1 0 564
assign 1 0 568
return 1 0 572
return 1 0 575
assign 1 0 578
assign 1 0 582
return 1 0 586
return 1 0 589
assign 1 0 592
assign 1 0 596
return 1 0 600
return 1 0 603
assign 1 0 606
assign 1 0 610
return 1 0 614
return 1 0 617
assign 1 0 620
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1578327045: return bem_serializeContents_0();
case 965815191: return bem_echo_0();
case 1264409041: return bem_preProcessorGetDirect_0();
case 495872272: return bem_fileTokGet_0();
case 1470127612: return bem_sourceFileNameGet_0();
case 1552820506: return bem_classNameGet_0();
case -1400364749: return bem_serializationIteratorGet_0();
case 770044727: return bem_deserializeClassNameGet_0();
case -296688753: return bem_print_0();
case -479051665: return bem_paramsGet_0();
case -288104744: return bem_argsGetDirect_0();
case 993863115: return bem_fieldIteratorGet_0();
case 617667581: return bem_toAny_0();
case -351099743: return bem_orderedGet_0();
case -533132789: return bem_orderedGetDirect_0();
case -1039531132: return bem_create_0();
case -1508997486: return bem_preProcessorGet_0();
case 1386203302: return bem_fileTokGetDirect_0();
case 105645045: return bem_many_0();
case 2066844567: return bem_fieldNamesGet_0();
case 1167480829: return bem_copy_0();
case -2116731666: return bem_paramsGetDirect_0();
case 940651019: return bem_once_0();
case -1596775328: return bem_serializeToString_0();
case -479359240: return bem_tagGet_0();
case -639622757: return bem_hashGet_0();
case -2015039528: return bem_iteratorGet_0();
case -688862469: return bem_toString_0();
case -806071649: return bem_argsGet_0();
case -1453318633: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -414279577: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case 2063031309: return bem_argsSet_1(bevd_0);
case -1202688048: return bem_def_1(bevd_0);
case -1596168486: return bem_equals_1(bevd_0);
case 1489408670: return bem_sameType_1(bevd_0);
case -1076480041: return bem_notEquals_1(bevd_0);
case 1503413748: return bem_undefined_1(bevd_0);
case -2060822992: return bem_preProcessorSetDirect_1(bevd_0);
case -1365097484: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1073960196: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -639605000: return bem_addArgs_1(bevd_0);
case 1291613488: return bem_paramsSet_1(bevd_0);
case 976784755: return bem_orderedSetDirect_1(bevd_0);
case 506597384: return bem_preProcessorSet_1(bevd_0);
case 434917768: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 419445436: return bem_copyTo_1(bevd_0);
case -1044485296: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -814180749: return bem_fileTokSetDirect_1(bevd_0);
case 1879722769: return bem_sameClass_1(bevd_0);
case -1018419171: return bem_orderedSet_1(bevd_0);
case 65645087: return bem_argsSetDirect_1(bevd_0);
case -1416339029: return bem_sameObject_1(bevd_0);
case -1447883638: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1197332143: return bem_otherClass_1(bevd_0);
case 336248374: return bem_fileTokSet_1(bevd_0);
case -884635357: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1262649378: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case 1545593538: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 323831111: return bem_undef_1(bevd_0);
case -1300492421: return bem_otherType_1(bevd_0);
case 1204551596: return bem_paramsSetDirect_1(bevd_0);
case 189658019: return bem_defined_1(bevd_0);
case -109918388: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1458852885: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 893521893: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 282981748: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1285045766: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -443209355: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 787023569: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 824971801: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -437555976: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1323585037: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -624371870: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2145191247: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1751386896: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemParameters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
}
