namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
static BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x61,0x72,0x67,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 4));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 6));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_6 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_6, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_7 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_7, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_8 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_8, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_9 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_9, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_10 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_10, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_20 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_11 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_11, 1));
public static new BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static new BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_initialArgs;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevp_initialArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toJson_0() {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_9_4_ContainerMaps bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_10_JsonMarshaller bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[7];
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerMaps) BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevd_x[0] = bevt_1_tmpany_phold;
bevd_x[1] = bevp_args;
bevd_x[2] = bevt_2_tmpany_phold;
bevd_x[3] = bevp_params;
bevd_x[4] = bevt_3_tmpany_phold;
bevd_x[5] = bevp_ordered;
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bems_forwardCallCp(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes("from")), new BEC_2_9_4_ContainerList(bevd_x, 6));
bevt_5_tmpany_phold = (BEC_2_4_10_JsonMarshaller) (new BEC_2_4_10_JsonMarshaller()).bem_new_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_marshall_1(bevl_jsm);
return bevt_4_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fromJson_1(BEC_2_4_6_TextString beva_jsms) {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_4_12_JsonUnmarshaller bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_JsonUnmarshaller) (new BEC_2_4_12_JsonUnmarshaller()).bem_new_0();
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bem_unmarshall_1(beva_jsms);
bevt_1_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
bevp_args = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevp_params = (BEC_2_9_3_ContainerMap) bevl_jsm.bem_get_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevp_ordered = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fromJsonFile_1(BEC_2_2_4_IOFile beva_jsf) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = beva_jsf.bem_readerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1491075741);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(351676234);
bem_fromJson_1((BEC_2_4_6_TextString) bevt_0_tmpany_phold );
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_toJsonFile_1(BEC_2_2_4_IOFile beva_jsf) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = beva_jsf.bem_writerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1491075741);
bevt_2_tmpany_phold = bem_toJson_0();
bevt_0_tmpany_phold.bemd_1(-1015119205, bevt_2_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addValue_1(BEC_2_6_10_SystemParameters beva_p) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_9_10_ContainerLinkedList bevl_cp = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_9_4_ContainerList bevt_1_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_p.bem_argsGet_0();
bevp_args.bem_addValue_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = beva_p.bem_orderedGet_0();
bevp_ordered.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = beva_p.bem_paramsGet_0();
bevt_0_tmpany_loop = bevt_3_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 141 */ {
bevt_4_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1246776508);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevl_kv = bevt_0_tmpany_loop.bemd_0(-730791271);
bevt_5_tmpany_phold = bevl_kv.bemd_0(1049317738);
bevl_cp = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevt_5_tmpany_phold);
if (bevl_cp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_7_tmpany_phold = bevl_kv.bemd_0(312620823);
bevl_cp.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 144 */
 else  /* Line: 145 */ {
bevt_8_tmpany_phold = bevl_kv.bemd_0(1049317738);
bevt_9_tmpany_phold = bevl_kv.bemd_0(312620823);
bevp_params.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
} /* Line: 146 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) {
bem_new_0();
bevp_initialArgs = beva__args;
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 159 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(-1199332066);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 159 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(-901256688, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(-821507292, bevt_9_tmpany_phold);
beva__args.bemd_2(-38787755, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 159 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
} /* Line: 159 */
bevp_args = (BEC_2_9_4_ContainerList) bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(-1141049131);
while (true)
 /* Line: 166 */ {
bevt_10_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1246776508);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 166 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-730791271);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_13_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_12_tmpany_phold.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fa = bevl_i.bem_substring_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_18_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_17_tmpany_phold.bevi_int > bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fb = bevl_i.bem_substring_2(bevt_19_tmpany_phold, bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_23_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
if (bevt_22_tmpany_phold.bevi_int > bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevl_fc = bevl_i.bem_substring_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
} /* Line: 175 */
} /* Line: 174 */
} /* Line: 172 */
if (bevl_pname == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 179 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 180 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 181 */
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 184 */
 else  /* Line: 179 */ {
if (bevl_fb == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_29_tmpany_phold = bevl_fb.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 185 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 185 */
 else  /* Line: 185 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 185 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevt_32_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
} /* Line: 186 */
 else  /* Line: 179 */ {
if (bevl_fa == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevt_34_tmpany_phold = bevl_fa.bem_equals_1(bevt_35_tmpany_phold);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 187 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 187 */
 else  /* Line: 187 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 187 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_37_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevl_pos = bevl_par.bem_find_1(bevt_38_tmpany_phold);
if (bevl_pos == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevt_40_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevl_key = bevl_par.bem_substring_2(bevt_40_tmpany_phold, bevl_pos);
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_41_tmpany_phold = bevl_pos.bem_add_1(bevt_42_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_41_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 193 */
} /* Line: 190 */
 else  /* Line: 179 */ {
if (bevl_fc == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_45_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_19;
bevt_44_tmpany_phold = bevl_fc.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_20;
bevt_47_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 197 */
 else  /* Line: 179 */ {
if (bevl_fa == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_21;
bevt_49_tmpany_phold = bevl_fa.bem_equals_1(bevt_50_tmpany_phold);
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 199 */
} /* Line: 179 */
} /* Line: 179 */
} /* Line: 179 */
} /* Line: 179 */
} /* Line: 179 */
 else  /* Line: 166 */ {
break;
} /* Line: 166 */
} /* Line: 166 */
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 207 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(-821507292, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 207 */
 else  /* Line: 207 */ {
break;
} /* Line: 207 */
} /* Line: 207 */
} /* Line: 207 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 212 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(-821507292, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 212 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
} /* Line: 212 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevl__params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 218 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(1246776508);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 218 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(-730791271);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 222 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 222 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(-821507292, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 223 */
 else  /* Line: 222 */ {
break;
} /* Line: 222 */
} /* Line: 222 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(-821507292, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 226 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevp_params = bevl__params;
} /* Line: 228 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 234 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 236 */
return beva_isit;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 256 */ {
bevl_pl = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 258 */
return bevl_pl;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 269 */ {
return beva_default;
} /* Line: 270 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevl_vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 284 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1491075741);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(1308379424);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(-647640823);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(1341307528);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_initialArgsGet_0() {
return bevp_initialArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_initialArgsGetDirect_0() {
return bevp_initialArgs;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_initialArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_initialArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_orderedGet_0() {
return bevp_ordered;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGetDirect_0() {
return bevp_ordered;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_fileTokGet_0() {
return bevp_fileTok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() {
return bevp_fileTok;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_preProcessorGet_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_preProcessor = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {108, 109, 110, 111, 112, 112, 119, 119, 119, 119, 119, 120, 120, 120, 124, 124, 125, 125, 126, 126, 127, 127, 131, 131, 131, 131, 135, 135, 135, 135, 139, 139, 140, 140, 141, 141, 0, 141, 141, 142, 142, 143, 143, 144, 144, 146, 146, 146, 152, 153, 154, 158, 158, 159, 159, 159, 160, 160, 160, 159, 163, 164, 165, 166, 0, 166, 166, 167, 168, 169, 170, 170, 170, 170, 171, 171, 171, 172, 172, 172, 172, 173, 173, 173, 174, 174, 174, 174, 175, 175, 175, 179, 179, 180, 180, 181, 183, 184, 185, 185, 185, 185, 0, 0, 0, 186, 186, 186, 187, 187, 187, 187, 0, 0, 0, 188, 188, 188, 189, 189, 190, 190, 191, 191, 192, 192, 192, 193, 195, 195, 195, 195, 0, 0, 0, 196, 196, 196, 197, 198, 198, 198, 198, 0, 0, 0, 198, 198, 199, 205, 206, 206, 207, 207, 207, 207, 208, 208, 208, 207, 211, 211, 212, 212, 212, 212, 213, 213, 213, 212, 216, 216, 217, 218, 218, 219, 220, 221, 222, 0, 222, 222, 223, 223, 225, 226, 228, 233, 234, 234, 236, 239, 243, 243, 243, 247, 247, 251, 251, 255, 256, 256, 257, 258, 260, 264, 264, 268, 269, 269, 270, 272, 272, 276, 281, 282, 282, 283, 284, 286, 291, 291, 291, 292, 292, 293, 293, 294, 298, 298, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {54, 55, 56, 57, 58, 59, 71, 72, 73, 74, 75, 82, 83, 84, 92, 93, 94, 95, 96, 97, 98, 99, 106, 107, 108, 109, 116, 117, 118, 119, 135, 136, 137, 138, 139, 140, 140, 143, 145, 146, 147, 148, 153, 154, 155, 158, 159, 160, 170, 171, 172, 239, 244, 245, 248, 249, 251, 252, 253, 254, 261, 262, 263, 264, 264, 267, 269, 270, 271, 272, 273, 274, 275, 280, 281, 282, 283, 284, 285, 286, 291, 292, 293, 294, 295, 296, 297, 302, 303, 304, 305, 309, 314, 315, 320, 321, 323, 324, 327, 332, 333, 334, 336, 339, 343, 346, 347, 348, 351, 356, 357, 358, 360, 363, 367, 370, 371, 372, 373, 374, 375, 380, 381, 382, 383, 384, 385, 386, 390, 395, 396, 397, 399, 402, 406, 409, 410, 411, 412, 415, 420, 421, 422, 424, 427, 431, 433, 438, 439, 475, 476, 481, 482, 485, 486, 491, 492, 493, 494, 495, 502, 507, 508, 511, 512, 517, 518, 519, 520, 521, 528, 533, 534, 535, 538, 540, 541, 542, 543, 543, 546, 548, 549, 550, 556, 557, 563, 570, 571, 576, 577, 579, 584, 585, 586, 590, 591, 595, 596, 601, 602, 607, 608, 609, 611, 615, 616, 622, 623, 628, 629, 631, 632, 635, 641, 642, 647, 648, 649, 651, 661, 662, 663, 664, 665, 666, 667, 668, 673, 674, 677, 680, 683, 687, 691, 694, 697, 701, 705, 708, 711, 715, 719, 722, 725, 729, 733, 736, 739, 743, 747, 750, 753};
/* BEGIN LINEINFO 
assign 1 108 54
new 0 108 54
assign 1 109 55
new 0 109 55
assign 1 110 56
new 0 110 56
assign 1 111 57
new 0 111 57
assign 1 112 58
new 0 112 58
assign 1 112 59
new 1 112 59
assign 1 119 71
new 0 119 71
assign 1 119 72
new 0 119 72
assign 1 119 73
new 0 119 73
assign 1 119 74
new 0 119 74
assign 1 119 75
from 6 119 75
assign 1 120 82
new 0 120 82
assign 1 120 83
marshall 1 120 83
return 1 120 84
assign 1 124 92
new 0 124 92
assign 1 124 93
unmarshall 1 124 93
assign 1 125 94
new 0 125 94
assign 1 125 95
get 1 125 95
assign 1 126 96
new 0 126 96
assign 1 126 97
get 1 126 97
assign 1 127 98
new 0 127 98
assign 1 127 99
get 1 127 99
assign 1 131 106
readerGet 0 131 106
assign 1 131 107
open 0 131 107
assign 1 131 108
readStringClose 0 131 108
fromJson 1 131 109
assign 1 135 116
writerGet 0 135 116
assign 1 135 117
open 0 135 117
assign 1 135 118
toJson 0 135 118
writeStringClose 1 135 119
assign 1 139 135
argsGet 0 139 135
addValue 1 139 136
assign 1 140 137
orderedGet 0 140 137
addValue 1 140 138
assign 1 141 139
paramsGet 0 141 139
assign 1 141 140
iteratorGet 0 0 140
assign 1 141 143
hasNextGet 0 141 143
assign 1 141 145
nextGet 0 141 145
assign 1 142 146
keyGet 0 142 146
assign 1 142 147
get 1 142 147
assign 1 143 148
def 1 143 153
assign 1 144 154
valueGet 0 144 154
addValue 1 144 155
assign 1 146 158
keyGet 0 146 158
assign 1 146 159
valueGet 0 146 159
put 2 146 160
new 0 152 170
assign 1 153 171
addArgs 1 154 172
assign 1 158 239
def 1 158 244
assign 1 159 245
new 0 159 245
assign 1 159 248
lengthGet 0 159 248
assign 1 159 249
lesser 1 159 249
assign 1 160 251
get 1 160 251
assign 1 160 252
process 1 160 252
put 2 160 253
assign 1 159 254
increment 0 159 254
assign 1 163 261
add 1 163 261
assign 1 164 262
assign 1 165 263
new 0 165 263
assign 1 166 264
iteratorGet 0 0 264
assign 1 166 267
hasNextGet 0 166 267
assign 1 166 269
nextGet 0 166 269
assign 1 167 270
assign 1 168 271
assign 1 169 272
assign 1 170 273
sizeGet 0 170 273
assign 1 170 274
new 0 170 274
assign 1 170 275
greater 1 170 280
assign 1 171 281
new 0 171 281
assign 1 171 282
new 0 171 282
assign 1 171 283
substring 2 171 283
assign 1 172 284
sizeGet 0 172 284
assign 1 172 285
new 0 172 285
assign 1 172 286
greater 1 172 291
assign 1 173 292
new 0 173 292
assign 1 173 293
new 0 173 293
assign 1 173 294
substring 2 173 294
assign 1 174 295
sizeGet 0 174 295
assign 1 174 296
new 0 174 296
assign 1 174 297
greater 1 174 302
assign 1 175 303
new 0 175 303
assign 1 175 304
new 0 175 304
assign 1 175 305
substring 2 175 305
assign 1 179 309
def 1 179 314
assign 1 180 315
not 0 180 320
addParameter 2 181 321
assign 1 183 323
assign 1 184 324
new 0 184 324
assign 1 185 327
def 1 185 332
assign 1 185 333
new 0 185 333
assign 1 185 334
equals 1 185 334
assign 1 0 336
assign 1 0 339
assign 1 0 343
assign 1 186 346
new 0 186 346
assign 1 186 347
sizeGet 0 186 347
assign 1 186 348
substring 2 186 348
assign 1 187 351
def 1 187 356
assign 1 187 357
new 0 187 357
assign 1 187 358
equals 1 187 358
assign 1 0 360
assign 1 0 363
assign 1 0 367
assign 1 188 370
new 0 188 370
assign 1 188 371
sizeGet 0 188 371
assign 1 188 372
substring 2 188 372
assign 1 189 373
new 0 189 373
assign 1 189 374
find 1 189 374
assign 1 190 375
def 1 190 380
assign 1 191 381
new 0 191 381
assign 1 191 382
substring 2 191 382
assign 1 192 383
new 0 192 383
assign 1 192 384
add 1 192 384
assign 1 192 385
substring 1 192 385
addParameter 2 193 386
assign 1 195 390
def 1 195 395
assign 1 195 396
new 0 195 396
assign 1 195 397
equals 1 195 397
assign 1 0 399
assign 1 0 402
assign 1 0 406
assign 1 196 409
new 0 196 409
assign 1 196 410
sizeGet 0 196 410
assign 1 196 411
substring 2 196 411
assign 1 197 412
new 0 197 412
assign 1 198 415
def 1 198 420
assign 1 198 421
new 0 198 421
assign 1 198 422
equals 1 198 422
assign 1 0 424
assign 1 0 427
assign 1 0 431
assign 1 198 433
not 0 198 438
addValue 1 199 439
assign 1 205 475
assign 1 206 476
def 1 206 481
assign 1 207 482
new 0 207 482
assign 1 207 485
lengthGet 0 207 485
assign 1 207 486
lesser 1 207 491
assign 1 208 492
get 1 208 492
assign 1 208 493
process 1 208 493
put 2 208 494
assign 1 207 495
increment 0 207 495
assign 1 211 502
def 1 211 507
assign 1 212 508
new 0 212 508
assign 1 212 511
lengthGet 0 212 511
assign 1 212 512
lesser 1 212 517
assign 1 213 518
get 1 213 518
assign 1 213 519
process 1 213 519
put 2 213 520
assign 1 212 521
increment 0 212 521
assign 1 216 528
def 1 216 533
assign 1 217 534
new 0 217 534
assign 1 218 535
keyIteratorGet 0 218 535
assign 1 218 538
hasNextGet 0 218 538
assign 1 219 540
nextGet 0 219 540
assign 1 220 541
get 1 220 541
assign 1 221 542
new 0 221 542
assign 1 222 543
linkedListIteratorGet 0 0 543
assign 1 222 546
hasNextGet 0 222 546
assign 1 222 548
nextGet 0 222 548
assign 1 223 549
process 1 223 549
addValue 1 223 550
assign 1 225 556
process 1 225 556
put 2 226 557
assign 1 228 563
assign 1 233 570
getFirst 1 233 570
assign 1 234 571
def 1 234 576
assign 1 236 577
new 1 236 577
return 1 239 579
assign 1 243 584
new 0 243 584
assign 1 243 585
isTrue 2 243 585
return 1 243 586
assign 1 247 590
has 1 247 590
return 1 247 591
assign 1 251 595
get 1 251 595
return 1 251 596
assign 1 255 601
get 1 255 601
assign 1 256 602
undef 1 256 607
assign 1 257 608
new 0 257 608
addValue 1 258 609
return 1 260 611
assign 1 264 615
getFirst 2 264 615
return 1 264 616
assign 1 268 622
get 1 268 622
assign 1 269 623
undef 1 269 628
return 1 270 629
assign 1 272 631
firstGet 0 272 631
return 1 272 632
addParam 2 276 635
assign 1 281 641
get 1 281 641
assign 1 282 642
undef 1 282 647
assign 1 283 648
new 0 283 648
put 2 284 649
addValue 1 286 651
assign 1 291 661
readerGet 0 291 661
assign 1 291 662
open 0 291 662
assign 1 291 663
readString 0 291 663
assign 1 292 664
readerGet 0 292 664
close 0 292 665
assign 1 293 666
tokenize 1 293 666
assign 1 293 667
toList 0 293 667
addArgs 1 294 668
assign 1 298 673
iteratorGet 0 298 673
return 1 298 674
return 1 0 677
return 1 0 680
assign 1 0 683
assign 1 0 687
return 1 0 691
return 1 0 694
assign 1 0 697
assign 1 0 701
return 1 0 705
return 1 0 708
assign 1 0 711
assign 1 0 715
return 1 0 719
return 1 0 722
assign 1 0 725
assign 1 0 729
return 1 0 733
return 1 0 736
assign 1 0 739
assign 1 0 743
return 1 0 747
return 1 0 750
assign 1 0 753
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1390208462: return bem_toJson_0();
case -1141049131: return bem_iteratorGet_0();
case 1366617398: return bem_tagGet_0();
case -2028470517: return bem_argsGetDirect_0();
case 1747475389: return bem_many_0();
case -31410563: return bem_once_0();
case 306116222: return bem_echo_0();
case 1801694719: return bem_copy_0();
case -675004702: return bem_preProcessorGet_0();
case -72505501: return bem_argsGet_0();
case -1219673974: return bem_toString_0();
case 32650831: return bem_paramsGet_0();
case -1120811970: return bem_orderedGetDirect_0();
case -2016997496: return bem_print_0();
case -14767827: return bem_serializeToString_0();
case 1180639151: return bem_paramsGetDirect_0();
case 1115258825: return bem_create_0();
case 270211904: return bem_initialArgsGet_0();
case 222096027: return bem_classNameGet_0();
case 216845033: return bem_new_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 434654272: return bem_hashGet_0();
case 1999868679: return bem_fieldIteratorGet_0();
case 2119098947: return bem_serializeContents_0();
case -1121300979: return bem_fieldNamesGet_0();
case -1194274080: return bem_toAny_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case 1251955617: return bem_initialArgsGetDirect_0();
case -1437019881: return bem_fileTokGet_0();
case -946626294: return bem_orderedGet_0();
case 2140018653: return bem_fileTokGetDirect_0();
case -1365182072: return bem_sourceFileNameGet_0();
case 637593609: return bem_preProcessorGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2098161987: return bem_addValue_1((BEC_2_6_10_SystemParameters) bevd_0);
case -1921147204: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case -2128632774: return bem_orderedSetDirect_1(bevd_0);
case -240164168: return bem_undefined_1(bevd_0);
case -1179756876: return bem_preProcessorSet_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case 689867155: return bem_orderedSet_1(bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1730569175: return bem_fromJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case 1599336408: return bem_argsSetDirect_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case -541526062: return bem_initialArgsSetDirect_1(bevd_0);
case -901256688: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 315768632: return bem_fileTokSetDirect_1(bevd_0);
case 1206237372: return bem_fileTokSet_1(bevd_0);
case 1684084096: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -1246021533: return bem_equals_1(bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1556259176: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
case -2031564793: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1614676730: return bem_toJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case -1048125626: return bem_paramsSet_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 673301700: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case -1032442331: return bem_paramsSetDirect_1(bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case 518977888: return bem_argsSet_1(bevd_0);
case -1655972130: return bem_preProcessorSetDirect_1(bevd_0);
case -983590052: return bem_fromJson_1((BEC_2_4_6_TextString) bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case -958862967: return bem_initialArgsSet_1(bevd_0);
case -1950366333: return bem_addArgs_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1695471985: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 43325304: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 436581735: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1475163447: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1769115882: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemParameters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
}
