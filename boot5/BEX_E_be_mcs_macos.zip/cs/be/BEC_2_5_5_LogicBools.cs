namespace be {
/* IO:File: source/base/Logic.be */
public sealed class BEC_2_5_5_LogicBools : BEC_2_6_6_SystemObject {
public BEC_2_5_5_LogicBools() { }
static BEC_2_5_5_LogicBools() { }
private static byte[] becc_BEC_2_5_5_LogicBools_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] becc_BEC_2_5_5_LogicBools_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_1 = {0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_LogicBools_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_LogicBools_bels_1, 1));
public static new BEC_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_inst;

public static new BET_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_5_5_LogicBools bem_default_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_forString_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(1949406125, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 122 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 123 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_fromString_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_2_tmpany_phold = beva_str.bemd_1(1949406125, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 129 */
 else  /* Line: 129 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 129 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 130 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_5_LogicBools_bevo_0;
bevt_0_tmpany_phold = beva_str.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 137 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isTrue_1(BEC_2_5_4_LogicBool beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 143 */ {
if (beva_val.bevi_bool) /* Line: 143 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 143 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 143 */
 else  /* Line: 143 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 143 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 144 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {122, 122, 123, 123, 125, 125, 129, 129, 129, 129, 0, 0, 0, 130, 130, 132, 132, 136, 136, 137, 137, 139, 139, 143, 143, 0, 0, 0, 144, 144, 146, 146};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 29, 30, 32, 33, 42, 47, 48, 49, 51, 54, 58, 61, 62, 64, 65, 72, 73, 75, 76, 78, 79, 86, 91, 93, 96, 100, 103, 104, 106, 107};
/* BEGIN LINEINFO 
assign 1 122 26
new 0 122 26
assign 1 122 27
equals 1 122 27
assign 1 123 29
new 0 123 29
return 1 123 30
assign 1 125 32
new 0 125 32
return 1 125 33
assign 1 129 42
def 1 129 47
assign 1 129 48
new 0 129 48
assign 1 129 49
equals 1 129 49
assign 1 0 51
assign 1 0 54
assign 1 0 58
assign 1 130 61
new 0 130 61
return 1 130 62
assign 1 132 64
new 0 132 64
return 1 132 65
assign 1 136 72
new 0 136 72
assign 1 136 73
equals 1 136 73
assign 1 137 75
new 0 137 75
return 1 137 76
assign 1 139 78
new 0 139 78
return 1 139 79
assign 1 143 86
def 1 143 91
assign 1 0 93
assign 1 0 96
assign 1 0 100
assign 1 144 103
new 0 144 103
return 1 144 104
assign 1 146 106
new 0 146 106
return 1 146 107
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1045627857: return bem_create_0();
case -1723287273: return bem_fieldIteratorGet_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case 1690848108: return bem_echo_0();
case 1426474238: return bem_once_0();
case -2091217929: return bem_toAny_0();
case 237106258: return bem_default_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 805348767: return bem_serializationIteratorGet_0();
case 1776712568: return bem_iteratorGet_0();
case 1340694490: return bem_new_0();
case -856707590: return bem_tagGet_0();
case 1365471067: return bem_print_0();
case 756642383: return bem_fieldNamesGet_0();
case -1287943088: return bem_copy_0();
case -348782970: return bem_serializeToString_0();
case 1963695386: return bem_toString_0();
case -1303115743: return bem_hashGet_0();
case 353377191: return bem_classNameGet_0();
case -835303456: return bem_many_0();
case -723282878: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -550139783: return bem_otherType_1(bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -662872016: return bem_fromString_1(bevd_0);
case -793887534: return bem_otherClass_1(bevd_0);
case 1957754251: return bem_isTrue_1((BEC_2_5_4_LogicBool) bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case -900992323: return bem_forString_1(bevd_0);
case -480348635: return bem_def_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case 2129603513: return bem_defined_1(bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case -1412377002: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_LogicBools_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_5_LogicBools_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_LogicBools();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst = (BEC_2_5_5_LogicBools) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_type;
}
}
}
