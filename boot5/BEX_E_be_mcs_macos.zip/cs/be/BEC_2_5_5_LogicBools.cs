namespace be {
/* IO:File: source/base/Logic.be */
public sealed class BEC_2_5_5_LogicBools : BEC_2_6_6_SystemObject {
public BEC_2_5_5_LogicBools() { }
static BEC_2_5_5_LogicBools() { }
private static byte[] becc_BEC_2_5_5_LogicBools_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] becc_BEC_2_5_5_LogicBools_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_2 = {0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_LogicBools_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_LogicBools_bels_2, 1));
public static new BEC_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_inst;

public static new BET_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_5_5_LogicBools bem_default_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_forString_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(-1897607279, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 123 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 124 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_fromString_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(-1897607279, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 130 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 130 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 130 */
 else  /* Line: 130 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 130 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 131 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_5_LogicBools_bevo_0;
bevt_0_tmpany_phold = beva_str.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 138 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {123, 123, 124, 124, 126, 126, 130, 130, 130, 130, 0, 0, 0, 131, 131, 133, 133, 137, 137, 138, 138, 140, 140};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 30, 31, 33, 34, 43, 48, 49, 50, 52, 55, 59, 62, 63, 65, 66, 73, 74, 76, 77, 79, 80};
/* BEGIN LINEINFO 
assign 1 123 27
new 0 123 27
assign 1 123 28
equals 1 123 28
assign 1 124 30
new 0 124 30
return 1 124 31
assign 1 126 33
new 0 126 33
return 1 126 34
assign 1 130 43
def 1 130 48
assign 1 130 49
new 0 130 49
assign 1 130 50
equals 1 130 50
assign 1 0 52
assign 1 0 55
assign 1 0 59
assign 1 131 62
new 0 131 62
return 1 131 63
assign 1 133 65
new 0 133 65
return 1 133 66
assign 1 137 73
new 0 137 73
assign 1 137 74
equals 1 137 74
assign 1 138 76
new 0 138 76
return 1 138 77
assign 1 140 79
new 0 140 79
return 1 140 80
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -457703447: return bem_deserializeClassNameGet_0();
case 705946713: return bem_serializationIteratorGet_0();
case 1878894995: return bem_classNameGet_0();
case 2087771877: return bem_echo_0();
case -1922780248: return bem_iteratorGet_0();
case 1855506680: return bem_toString_0();
case 1835544527: return bem_print_0();
case 945522219: return bem_hashGet_0();
case 615981380: return bem_fieldNamesGet_0();
case -798507920: return bem_default_0();
case -711514807: return bem_sourceFileNameGet_0();
case 1284640786: return bem_copy_0();
case -84103940: return bem_many_0();
case -1354126741: return bem_tagGet_0();
case -292945961: return bem_create_0();
case 87072509: return bem_toAny_0();
case 624386533: return bem_serializeToString_0();
case 457529483: return bem_serializeContents_0();
case 1095611429: return bem_once_0();
case -1725699695: return bem_fieldIteratorGet_0();
case 658678414: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -656840793: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1383533410: return bem_undef_1(bevd_0);
case 58606191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 907709181: return bem_forString_1(bevd_0);
case -2109400999: return bem_copyTo_1(bevd_0);
case -754260669: return bem_def_1(bevd_0);
case 126395237: return bem_sameObject_1(bevd_0);
case -597509561: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1526623563: return bem_fromString_1(bevd_0);
case -586455400: return bem_defined_1(bevd_0);
case -1551748546: return bem_undefined_1(bevd_0);
case -341234740: return bem_notEquals_1(bevd_0);
case -1368724020: return bem_sameType_1(bevd_0);
case 1894284601: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -701846850: return bem_otherType_1(bevd_0);
case -1971460437: return bem_otherClass_1(bevd_0);
case 465199415: return bem_sameClass_1(bevd_0);
case -1897607279: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1810583739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -687329733: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 703022748: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -871246707: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1013064550: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1390383369: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1845172722: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_LogicBools_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_5_LogicBools_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_LogicBools();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst = (BEC_2_5_5_LogicBools) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_type;
}
}
}
