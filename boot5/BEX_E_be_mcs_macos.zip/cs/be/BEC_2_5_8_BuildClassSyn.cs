namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_8_BuildClassSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
static BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_0, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_2, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_3, 44));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_4, 78));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_5, 12));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_6, 38));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_7, 68));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_8, 75));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_9, 13));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_10, 65));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_11, 11));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_12, 33));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_13 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_13, 1));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_14, 95));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x62,0x75,0x74,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_15, 90));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_16, 84));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_17 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_17, 80));
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_2, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_18, 26));
public static new BEC_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_inst;

public static new BET_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_4_ContainerList bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_4_ContainerList bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_maxMtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 95 */ {
bevt_0_tmpany_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 98 */
} /* Line: 97 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpany_phold);
if (bevl_dmtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 108 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = beva_psyn.bemd_0(265714607);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bemd_0(-1287943088);
bevt_3_tmpany_phold = beva_psyn.bemd_0(565636739);
bevp_superList.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = beva_psyn.bemd_0(-1571719846);
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_4_tmpany_phold.bemd_0(-1287943088);
bevt_5_tmpany_phold = beva_psyn.bemd_0(-334596089);
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_5_tmpany_phold.bemd_0(-1287943088);
bevt_7_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(723807726);
bevl_iv = bevt_6_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 131 */ {
bevt_8_tmpany_phold = bevl_iv.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevl_ov = bevl_iv.bemd_0(1949384208);
bevt_9_tmpany_phold = beva_psyn.bemd_0(1449940664);
bevt_11_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(300088773);
bevl_pv = bevt_9_tmpany_phold.bemd_1(556895144, bevt_10_tmpany_phold);
bevt_14_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(300088773);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_8_BuildClassSyn_bels_1));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(674421585, bevt_15_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 134 */ {
if (bevl_pv == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 134 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
 else  /* Line: 134 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_19_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1964101134);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(1877521898);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 134 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 134 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 134 */
 else  /* Line: 134 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 134 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_1;
bevt_26_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(300088773);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_2;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(565636739);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1963695386);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 135 */
} /* Line: 134 */
 else  /* Line: 131 */ {
break;
} /* Line: 131 */
} /* Line: 131 */
bevt_31_tmpany_phold = beva_psyn.bemd_0(-334596089);
bevl_iv = bevt_31_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 140 */ {
bevt_32_tmpany_phold = bevl_iv.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_ov = bevl_iv.bemd_0(1949384208);
bevt_34_tmpany_phold = bevl_ov.bemd_0(-386753334);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(1646621915);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevt_35_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_37_tmpany_phold = bevl_ov.bemd_0(-386753334);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(565636739);
bevt_35_tmpany_phold.bemd_1(-85229346, bevt_36_tmpany_phold);
} /* Line: 143 */
} /* Line: 142 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
bevt_39_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(1195253250);
bevl_im = bevt_38_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 147 */ {
bevt_40_tmpany_phold = bevl_im.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 147 */ {
bevl_om = bevl_im.bemd_0(1949384208);
bevt_41_tmpany_phold = beva_psyn.bemd_0(704460341);
bevt_43_tmpany_phold = bevl_om.bemd_0(2102127943);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(300088773);
bevl_pm = bevt_41_tmpany_phold.bemd_1(556895144, bevt_42_tmpany_phold);
if (bevl_pm == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 150 */ {
bevt_46_tmpany_phold = bevl_pm.bemd_0(362812799);
if (bevt_46_tmpany_phold == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_49_tmpany_phold = bevl_om.bemd_0(2102127943);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(-16871615);
if (bevt_48_tmpany_phold == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_54_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_3;
bevt_56_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_0(300088773);
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_add_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_4;
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_add_1(bevt_57_tmpany_phold);
bevt_59_tmpany_phold = bevl_om.bemd_0(2102127943);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(300088773);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_50_tmpany_phold);
} /* Line: 153 */
} /* Line: 152 */
} /* Line: 151 */
} /* Line: 150 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
bem_loadClass_1(beva_klass);
bevt_60_tmpany_phold = beva_psyn.bemd_0(1688023222);
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpany_phold.bemd_1(-1136298158, bevt_61_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpany_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 167 */ {
return this;
} /* Line: 167 */
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpany_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 177 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 177 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1949384208);
bevt_9_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_methodIndexesGet_0();
bevt_10_tmpany_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpany_phold.bem_put_1(bevt_10_tmpany_phold);
} /* Line: 178 */
 else  /* Line: 177 */ {
break;
} /* Line: 177 */
} /* Line: 177 */
return this;
} /* Line: 180 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_11_tmpany_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpany_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpany_phold.bem_subtract_1(bevt_12_tmpany_phold);
bevt_15_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 187 */
bevt_16_tmpany_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_5;
bevt_20_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_17_tmpany_phold);
} /* Line: 189 */
bevt_21_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevt_23_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 191 */ {
bevt_26_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_6;
bevt_27_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 192 */
bevt_28_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 194 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
 else  /* Line: 194 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 194 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
 else  /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 194 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_7;
bevt_34_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_31_tmpany_phold);
} /* Line: 195 */
bevt_1_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 197 */ {
bevt_35_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 197 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_has_1(bevt_39_tmpany_phold);
if (bevt_37_tmpany_phold.bevi_bool) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_41_tmpany_phold = bevl_pn.bem_toString_0();
bevt_42_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_8;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_notEquals_1(bevt_42_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 199 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 199 */
 else  /* Line: 199 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 199 */ {
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 202 */
bevt_45_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 205 */
} /* Line: 204 */
 else  /* Line: 197 */ {
break;
} /* Line: 197 */
} /* Line: 197 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 209 */ {
bevt_47_tmpany_phold = bevl_im.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 209 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1949384208);
bevt_48_tmpany_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpany_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
if (bevl_pm == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevt_51_tmpany_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_52_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpany_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 216 */
} /* Line: 213 */
 else  /* Line: 218 */ {
bevt_54_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpany_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_methodIndexesGet_0();
bevt_57_tmpany_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpany_phold.bem_put_1(bevt_57_tmpany_phold);
} /* Line: 222 */
} /* Line: 212 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 229 */ {
return this;
} /* Line: 229 */
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 231 */ {
return this;
} /* Line: 231 */
bevl_psyn = beva_build.bemd_1(-979600985, bevp_superNp);
bevt_5_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(723807726);
bevl_iv = bevt_4_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 233 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 233 */ {
bevl_ov = bevl_iv.bemd_0(1949384208);
bevt_7_tmpany_phold = bevl_psyn.bemd_0(1449940664);
bevt_9_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(300088773);
bevl_pv = bevt_7_tmpany_phold.bemd_1(556895144, bevt_8_tmpany_phold);
if (bevl_pv == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 236 */ {
bevt_12_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1964101134);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 237 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_9;
bevt_19_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(300088773);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_10;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(565636739);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1963695386);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_14_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_13_tmpany_phold);
} /* Line: 238 */
 else  /* Line: 239 */ {
bevt_24_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_26_tmpany_phold = bevl_pv.bemd_0(-386753334);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1646621915);
bevt_24_tmpany_phold.bemd_1(320650603, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_29_tmpany_phold = bevl_pv.bemd_0(-386753334);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(565636739);
bevt_27_tmpany_phold.bemd_1(-2059713689, bevt_28_tmpany_phold);
} /* Line: 241 */
} /* Line: 237 */
} /* Line: 236 */
 else  /* Line: 233 */ {
break;
} /* Line: 233 */
} /* Line: 233 */
bevt_31_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(1195253250);
bevl_im = bevt_30_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 245 */ {
bevt_32_tmpany_phold = bevl_im.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 245 */ {
bevl_om = bevl_im.bemd_0(1949384208);
bevt_33_tmpany_phold = bevl_psyn.bemd_0(704460341);
bevt_35_tmpany_phold = bevl_om.bemd_0(2102127943);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(300088773);
bevl_pm = bevt_33_tmpany_phold.bemd_1(556895144, bevt_34_tmpany_phold);
if (bevl_pm == null) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 248 */ {
bevt_37_tmpany_phold = bevl_pm.bemd_0(-1758172921);
if (((BEC_2_5_4_LogicBool) bevt_37_tmpany_phold).bevi_bool) /* Line: 249 */ {
bevt_42_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_11;
bevt_44_tmpany_phold = bevl_om.bemd_0(2102127943);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(300088773);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_45_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_12;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(565636739);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1963695386);
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_39_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_38_tmpany_phold);
} /* Line: 250 */
bevt_50_tmpany_phold = bevl_om.bemd_0(2088390349);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(-356420282);
bevl_oa = bevt_49_tmpany_phold.bemd_0(2088390349);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 253 */ {
bevt_53_tmpany_phold = bevl_pm.bemd_0(-727337812);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(514375372);
bevt_51_tmpany_phold = bevl_i.bemd_1(-559304786, bevt_52_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 253 */ {
bevt_54_tmpany_phold = bevl_pm.bemd_0(-727337812);
bevl_pmr = bevt_54_tmpany_phold.bemd_1(556895144, bevl_i);
bevt_55_tmpany_phold = bevl_oa.bemd_1(556895144, bevl_i);
bevl_omr = bevt_55_tmpany_phold.bemd_0(2102127943);
bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(521375152);
} /* Line: 253 */
 else  /* Line: 253 */ {
break;
} /* Line: 253 */
} /* Line: 253 */
bevl_pmr = bevl_pm.bemd_0(362812799);
bevt_56_tmpany_phold = bevl_om.bemd_0(2102127943);
bevl_omr = bevt_56_tmpany_phold.bemd_0(-16871615);
if (bevl_pmr == null) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 261 */ {
if (bevl_omr == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 261 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 261 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 261 */ {
if (bevl_pmr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
if (bevl_omr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 262 */ {
bevt_65_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_13;
bevt_68_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(565636739);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_0(1963695386);
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_add_1(bevt_66_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_63_tmpany_phold);
} /* Line: 267 */
} /* Line: 262 */
 else  /* Line: 269 */ {
bevt_69_tmpany_phold = bevl_pmr.bemd_0(-1868060594);
if (((BEC_2_5_4_LogicBool) bevt_69_tmpany_phold).bevi_bool) /* Line: 271 */ {
bevt_71_tmpany_phold = bevl_pmr.bemd_0(-1868060594);
bevt_72_tmpany_phold = bevl_omr.bemd_0(-1868060594);
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(674421585, bevt_72_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_70_tmpany_phold).bevi_bool) /* Line: 271 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 271 */ {
bevt_75_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_14;
bevt_78_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(565636739);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bemd_0(1963695386);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_76_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 272 */
bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 274 */
} /* Line: 261 */
} /* Line: 248 */
 else  /* Line: 245 */ {
break;
} /* Line: 245 */
} /* Line: 245 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
bevt_2_tmpany_phold = beva_pmr.bemd_0(1646621915);
bevt_3_tmpany_phold = beva_omr.bemd_0(1646621915);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(674421585, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 281 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_15;
bevt_9_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(565636739);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1963695386);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
bevt_10_tmpany_phold = beva_pmr.bemd_0(1646621915);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 283 */ {
bevt_11_tmpany_phold = beva_pmr.bemd_0(600926307);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_12_tmpany_phold = beva_omr.bemd_0(600926307);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 286 */ {
return this;
} /* Line: 287 */
bevt_13_tmpany_phold = beva_omr.bemd_0(565636739);
bevl_osyn = beva_build.bemd_1(-979600985, bevt_13_tmpany_phold);
bevt_16_tmpany_phold = bevl_osyn.bemd_0(1286465292);
bevt_17_tmpany_phold = beva_pmr.bemd_0(565636739);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-31812836, bevt_17_tmpany_phold);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(1877521898);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 290 */ {
bevt_20_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_16;
bevt_23_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(565636739);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1963695386);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_18_tmpany_phold);
} /* Line: 291 */
} /* Line: 290 */
} /* Line: 281 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bem_new_0();
bevt_1_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(723807726);
bevl_iv = bevt_0_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 298 */ {
bevt_2_tmpany_phold = bevl_iv.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 298 */ {
bevl_ov = bevl_iv.bemd_0(1949384208);
bevt_5_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1964101134);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1877521898);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 300 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_17;
bevt_12_tmpany_phold = bevl_ov.bemd_0(2102127943);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(300088773);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_18;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_16_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(565636739);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(1963695386);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 301 */
} /* Line: 300 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
bem_loadClass_1(beva_klass);
bevp_depth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = beva_klass.bemd_0(2102127943);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bemd_0(1142074911);
bevt_1_tmpany_phold = beva_klass.bemd_0(2102127943);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_phold.bemd_0(565636739);
bevt_2_tmpany_phold = beva_klass.bemd_0(2102127943);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(-2119901542);
bevt_3_tmpany_phold = beva_klass.bemd_0(2102127943);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpany_phold.bemd_0(-1758172921);
bevt_4_tmpany_phold = beva_klass.bemd_0(2102127943);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpany_phold.bemd_0(-1714605543);
bevt_5_tmpany_phold = beva_klass.bemd_0(2102127943);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpany_phold.bemd_0(2098104332);
bevt_7_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1811409151);
bevl_iu = bevt_6_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 316 */ {
bevt_8_tmpany_phold = bevl_iu.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 316 */ {
bevl_ou = bevl_iu.bemd_0(1949384208);
bevt_9_tmpany_phold = bevl_ou.bemd_0(1963695386);
bevp_uses.bem_put_1(bevt_9_tmpany_phold);
} /* Line: 318 */
 else  /* Line: 316 */ {
break;
} /* Line: 316 */
} /* Line: 316 */
bevt_11_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(723807726);
bevl_iv = bevt_10_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 320 */ {
bevt_12_tmpany_phold = bevl_iv.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 320 */ {
bevl_ov = bevl_iv.bemd_0(1949384208);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 323 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
bevt_14_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1195253250);
bevl_im = bevt_13_tmpany_phold.bemd_0(1776712568);
while (true)
 /* Line: 325 */ {
bevt_15_tmpany_phold = bevl_im.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 325 */ {
bevl_om = bevl_im.bemd_0(1949384208);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 328 */
 else  /* Line: 325 */ {
break;
} /* Line: 325 */
} /* Line: 325 */
bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_postLoad_0() {
BEC_2_9_4_ContainerList bevl_nptyList = null;
BEC_2_9_4_ContainerList bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
bevl_nptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_mtdnList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 338 */ {
bevt_1_tmpany_phold = bevl_iv.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 338 */ {
bevl_ov = bevl_iv.bemd_0(1949384208);
bevt_4_tmpany_phold = bevl_ov.bemd_0(300088773);
bevt_3_tmpany_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 340 */ {
bevt_5_tmpany_phold = bevl_ov.bemd_0(300088773);
bevp_ptyMap.bem_put_2(bevt_5_tmpany_phold, bevl_ov);
} /* Line: 342 */
} /* Line: 340 */
 else  /* Line: 338 */ {
break;
} /* Line: 338 */
} /* Line: 338 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 348 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 348 */ {
bevl_ov = bevl_iv.bemd_0(1949384208);
bevt_9_tmpany_phold = bevl_ov.bemd_0(300088773);
bevt_8_tmpany_phold = bevl_unq.bem_has_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevt_10_tmpany_phold = bevl_ov.bemd_0(300088773);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpany_phold);
bevl_nom.bemd_1(621898839, bevl_mpos);
bevt_11_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(-1136298158, bevt_11_tmpany_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpany_phold = bevl_ov.bemd_0(300088773);
bevt_13_tmpany_phold = bevl_ov.bemd_0(300088773);
bevl_unq.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
} /* Line: 355 */
} /* Line: 350 */
 else  /* Line: 348 */ {
break;
} /* Line: 348 */
} /* Line: 348 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 362 */ {
bevt_14_tmpany_phold = bevl_im.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 362 */ {
bevl_om = bevl_im.bemd_0(1949384208);
bevt_15_tmpany_phold = bevl_om.bemd_0(300088773);
bevp_mtdMap.bem_put_2(bevt_15_tmpany_phold, bevl_om);
bevt_18_tmpany_phold = bevl_om.bemd_0(300088773);
bevt_17_tmpany_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 367 */ {
bevt_19_tmpany_phold = bevl_om.bemd_0(300088773);
bevl_mtdOmap.bem_put_2(bevt_19_tmpany_phold, bevl_om);
} /* Line: 368 */
} /* Line: 367 */
 else  /* Line: 362 */ {
break;
} /* Line: 362 */
} /* Line: 362 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 374 */ {
bevt_20_tmpany_phold = bevl_im.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 374 */ {
bevl_om = bevl_im.bemd_0(1949384208);
bevt_23_tmpany_phold = bevl_om.bemd_0(300088773);
bevt_22_tmpany_phold = bevl_unq.bem_has_1(bevt_23_tmpany_phold);
if (bevt_22_tmpany_phold.bevi_bool) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 376 */ {
bevt_24_tmpany_phold = bevl_om.bemd_0(300088773);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = bevl_om.bemd_0(300088773);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 387 */ {
bevt_28_tmpany_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpany_phold);
} /* Line: 388 */
bevt_29_tmpany_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(-1025446413, bevt_29_tmpany_phold);
bevl_oma.bemd_1(1527808785, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpany_phold = bevl_om.bemd_0(300088773);
bevt_31_tmpany_phold = bevl_om.bemd_0(300088773);
bevl_unq.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
} /* Line: 394 */
} /* Line: 376 */
 else  /* Line: 374 */ {
break;
} /* Line: 374 */
} /* Line: 374 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 399 */ {
bevt_32_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 399 */ {
bevl_s = bevt_0_tmpany_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 401 */
 else  /* Line: 399 */ {
break;
} /* Line: 399 */
} /* Line: 399 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGetDirect_0() {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() {
return bevp_depth;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGetDirect_0() {
return bevp_depth;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() {
return bevp_newMbrs;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGetDirect_0() {
return bevp_newMbrs;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() {
return bevp_newMtds;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGetDirect_0() {
return bevp_newMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() {
return bevp_defMtds;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGetDirect_0() {
return bevp_defMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGetDirect_0() {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGetDirect_0() {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() {
return bevp_allTypes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGetDirect_0() {
return bevp_allTypes;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() {
return bevp_superList;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGetDirect_0() {
return bevp_superList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() {
return bevp_mtdMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGetDirect_0() {
return bevp_mtdMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGet_0() {
return bevp_mtdList;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGetDirect_0() {
return bevp_mtdList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() {
return bevp_ptyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGetDirect_0() {
return bevp_ptyMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGet_0() {
return bevp_ptyList;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGetDirect_0() {
return bevp_ptyList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGetDirect_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGetDirect_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGetDirect_0() {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() {
return bevp_integrated;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGetDirect_0() {
return bevp_integrated;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGetDirect_0() {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() {
return bevp_uses;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGetDirect_0() {
return bevp_uses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGetDirect_0() {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGetDirect_0() {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {71, 73, 75, 77, 78, 79, 80, 81, 82, 83, 84, 86, 87, 88, 89, 94, 95, 95, 96, 97, 97, 97, 98, 101, 105, 105, 106, 106, 108, 108, 110, 110, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 125, 126, 126, 127, 127, 128, 128, 131, 131, 131, 131, 132, 133, 133, 133, 133, 134, 134, 134, 134, 134, 134, 0, 0, 0, 134, 134, 134, 0, 0, 0, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 140, 140, 140, 141, 142, 142, 143, 143, 143, 143, 147, 147, 147, 147, 148, 149, 149, 149, 149, 150, 150, 151, 151, 151, 152, 152, 152, 152, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 158, 159, 159, 159, 163, 163, 167, 168, 169, 170, 171, 172, 172, 173, 174, 175, 176, 177, 0, 177, 177, 178, 178, 178, 178, 180, 182, 183, 184, 186, 186, 186, 186, 187, 187, 187, 188, 189, 189, 189, 189, 189, 191, 191, 191, 0, 0, 0, 192, 192, 192, 192, 192, 194, 194, 194, 0, 0, 0, 194, 194, 0, 0, 0, 195, 195, 195, 195, 195, 197, 0, 197, 197, 198, 199, 199, 199, 199, 199, 199, 199, 199, 0, 0, 0, 201, 202, 204, 204, 204, 204, 204, 205, 209, 209, 210, 211, 211, 211, 212, 212, 213, 214, 214, 215, 215, 216, 219, 219, 220, 221, 222, 222, 222, 222, 229, 230, 231, 231, 231, 232, 233, 233, 233, 233, 234, 235, 235, 235, 235, 236, 236, 237, 237, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 240, 240, 240, 240, 241, 241, 241, 241, 245, 245, 245, 245, 246, 247, 247, 247, 247, 248, 248, 249, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 252, 252, 252, 253, 253, 253, 253, 254, 254, 255, 255, 257, 253, 259, 260, 260, 261, 261, 0, 261, 261, 0, 0, 262, 262, 262, 0, 262, 262, 262, 0, 0, 267, 267, 267, 267, 267, 267, 267, 271, 271, 271, 271, 0, 0, 0, 272, 272, 272, 272, 272, 272, 272, 274, 281, 281, 281, 282, 282, 282, 282, 282, 282, 282, 283, 286, 286, 0, 0, 0, 287, 289, 289, 290, 290, 290, 290, 291, 291, 291, 291, 291, 291, 291, 297, 298, 298, 298, 298, 299, 300, 300, 300, 301, 301, 301, 301, 301, 301, 301, 301, 301, 301, 301, 301, 304, 305, 310, 310, 311, 311, 312, 312, 313, 313, 314, 314, 315, 315, 316, 316, 316, 316, 317, 318, 318, 320, 320, 320, 320, 321, 322, 323, 325, 325, 325, 325, 326, 327, 328, 330, 334, 335, 338, 338, 339, 340, 340, 340, 340, 342, 342, 346, 347, 348, 348, 349, 350, 350, 350, 350, 351, 351, 352, 353, 353, 354, 355, 355, 355, 358, 360, 362, 362, 363, 365, 365, 367, 367, 367, 367, 368, 368, 372, 373, 374, 374, 375, 376, 376, 376, 376, 377, 377, 386, 386, 387, 387, 387, 388, 388, 390, 390, 391, 392, 393, 394, 394, 394, 397, 399, 0, 399, 399, 400, 401, 404, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 102, 103, 106, 108, 109, 110, 115, 116, 123, 131, 132, 133, 138, 139, 140, 142, 143, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 240, 242, 243, 244, 245, 246, 247, 248, 249, 250, 252, 257, 258, 261, 265, 268, 269, 270, 272, 275, 279, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 300, 301, 304, 306, 307, 308, 310, 311, 312, 313, 320, 321, 322, 325, 327, 328, 329, 330, 331, 332, 337, 338, 339, 344, 345, 346, 347, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 372, 373, 374, 375, 380, 381, 449, 451, 452, 453, 454, 455, 460, 461, 462, 463, 464, 465, 465, 468, 470, 471, 472, 473, 474, 480, 482, 483, 484, 485, 486, 487, 488, 489, 490, 492, 494, 496, 497, 498, 499, 500, 502, 504, 505, 507, 510, 514, 517, 518, 519, 520, 521, 523, 525, 530, 531, 534, 538, 541, 546, 547, 550, 554, 557, 558, 559, 560, 561, 563, 563, 566, 568, 569, 570, 571, 572, 573, 578, 579, 580, 581, 583, 586, 590, 593, 594, 596, 597, 598, 599, 604, 605, 612, 615, 617, 618, 619, 620, 621, 626, 627, 629, 630, 631, 632, 633, 637, 638, 639, 640, 641, 642, 643, 644, 745, 747, 748, 753, 754, 756, 757, 758, 759, 762, 764, 765, 766, 767, 768, 769, 774, 775, 776, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 792, 793, 794, 795, 796, 797, 798, 799, 807, 808, 809, 812, 814, 815, 816, 817, 818, 819, 824, 825, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 840, 841, 842, 843, 846, 847, 848, 850, 851, 852, 853, 854, 855, 861, 862, 863, 864, 869, 870, 873, 878, 879, 882, 886, 891, 896, 897, 900, 905, 910, 911, 914, 918, 919, 920, 921, 922, 923, 924, 928, 930, 931, 932, 934, 937, 941, 944, 945, 946, 947, 948, 949, 950, 952, 988, 989, 990, 992, 993, 994, 995, 996, 997, 998, 1001, 1003, 1005, 1007, 1010, 1014, 1017, 1019, 1020, 1021, 1022, 1023, 1024, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1058, 1059, 1060, 1061, 1064, 1066, 1067, 1068, 1069, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1089, 1090, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1135, 1137, 1138, 1139, 1145, 1146, 1147, 1150, 1152, 1153, 1154, 1160, 1161, 1162, 1165, 1167, 1168, 1169, 1175, 1226, 1227, 1228, 1231, 1233, 1234, 1235, 1236, 1241, 1242, 1243, 1250, 1251, 1252, 1255, 1257, 1258, 1259, 1260, 1265, 1266, 1267, 1268, 1269, 1270, 1271, 1272, 1273, 1274, 1281, 1282, 1283, 1286, 1288, 1289, 1290, 1291, 1292, 1293, 1298, 1299, 1300, 1307, 1308, 1309, 1312, 1314, 1315, 1316, 1317, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1333, 1334, 1335, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1351, 1352, 1352, 1355, 1357, 1358, 1359, 1365, 1369, 1372, 1375, 1379, 1383, 1386, 1389, 1393, 1397, 1400, 1403, 1407, 1411, 1414, 1417, 1421, 1425, 1428, 1431, 1435, 1439, 1442, 1445, 1449, 1453, 1456, 1459, 1463, 1467, 1470, 1473, 1477, 1481, 1484, 1487, 1491, 1495, 1498, 1501, 1505, 1509, 1512, 1515, 1519, 1523, 1526, 1529, 1533, 1537, 1540, 1543, 1547, 1551, 1554, 1557, 1561, 1565, 1568, 1571, 1575, 1579, 1582, 1585, 1589, 1593, 1596, 1599, 1603, 1607, 1610, 1613, 1617, 1621, 1624, 1627, 1631, 1635, 1638, 1641, 1645, 1649, 1652, 1655, 1659, 1663, 1666, 1669, 1673, 1677, 1680, 1683, 1687, 1691, 1694, 1697, 1701, 1705, 1708, 1711, 1715, 1719, 1722, 1725, 1729, 1733, 1736, 1739, 1743};
/* BEGIN LINEINFO 
assign 1 71 78
new 0 71 78
assign 1 73 79
new 0 73 79
assign 1 75 80
new 0 75 80
assign 1 77 81
new 0 77 81
assign 1 78 82
new 0 78 82
assign 1 79 83
new 0 79 83
assign 1 80 84
new 0 80 84
assign 1 81 85
new 0 81 85
assign 1 82 86
new 0 82 86
assign 1 83 87
new 0 83 87
assign 1 84 88
new 0 84 88
assign 1 86 89
new 0 86 89
assign 1 87 90
new 0 87 90
assign 1 88 91
new 0 88 91
assign 1 89 92
new 0 89 92
assign 1 94 102
new 0 94 102
assign 1 95 103
valueIteratorGet 0 95 103
assign 1 95 106
hasNextGet 0 95 106
assign 1 96 108
nextGet 0 96 108
assign 1 97 109
mtdxGet 0 97 109
assign 1 97 110
greater 1 97 115
assign 1 98 116
mtdxGet 0 98 116
return 1 101 123
assign 1 105 131
new 0 105 131
assign 1 105 132
get 1 105 132
assign 1 106 133
def 1 106 138
assign 1 108 139
new 0 108 139
return 1 108 140
assign 1 110 142
new 0 110 142
return 1 110 143
assign 1 114 216
new 0 114 216
assign 1 115 217
new 0 115 217
assign 1 116 218
new 0 116 218
assign 1 117 219
new 0 117 219
assign 1 118 220
new 0 118 220
assign 1 119 221
new 0 119 221
assign 1 120 222
new 0 120 222
assign 1 121 223
new 0 121 223
assign 1 122 224
new 0 122 224
assign 1 123 225
new 0 123 225
assign 1 124 226
new 0 124 226
assign 1 125 227
superListGet 0 125 227
assign 1 125 228
copy 0 125 228
assign 1 126 229
namepathGet 0 126 229
addValue 1 126 230
assign 1 127 231
mtdListGet 0 127 231
assign 1 127 232
copy 0 127 232
assign 1 128 233
ptyListGet 0 128 233
assign 1 128 234
copy 0 128 234
assign 1 131 235
heldGet 0 131 235
assign 1 131 236
orderedVarsGet 0 131 236
assign 1 131 237
iteratorGet 0 131 237
assign 1 131 240
hasNextGet 0 131 240
assign 1 132 242
nextGet 0 132 242
assign 1 133 243
ptyMapGet 0 133 243
assign 1 133 244
heldGet 0 133 244
assign 1 133 245
nameGet 0 133 245
assign 1 133 246
get 1 133 246
assign 1 134 247
heldGet 0 134 247
assign 1 134 248
nameGet 0 134 248
assign 1 134 249
new 0 134 249
assign 1 134 250
notEquals 1 134 250
assign 1 134 252
undef 1 134 257
assign 1 0 258
assign 1 0 261
assign 1 0 265
assign 1 134 268
heldGet 0 134 268
assign 1 134 269
isDeclaredGet 0 134 269
assign 1 134 270
not 0 134 270
assign 1 0 272
assign 1 0 275
assign 1 0 279
assign 1 135 282
new 0 135 282
assign 1 135 283
heldGet 0 135 283
assign 1 135 284
nameGet 0 135 284
assign 1 135 285
add 1 135 285
assign 1 135 286
new 0 135 286
assign 1 135 287
add 1 135 287
assign 1 135 288
heldGet 0 135 288
assign 1 135 289
namepathGet 0 135 289
assign 1 135 290
toString 0 135 290
assign 1 135 291
add 1 135 291
assign 1 135 292
new 2 135 292
throw 1 135 293
assign 1 140 300
ptyListGet 0 140 300
assign 1 140 301
iteratorGet 0 140 301
assign 1 140 304
hasNextGet 0 140 304
assign 1 141 306
nextGet 0 141 306
assign 1 142 307
memSynGet 0 142 307
assign 1 142 308
isTypedGet 0 142 308
assign 1 143 310
heldGet 0 143 310
assign 1 143 311
memSynGet 0 143 311
assign 1 143 312
namepathGet 0 143 312
addUsed 1 143 313
assign 1 147 320
heldGet 0 147 320
assign 1 147 321
orderedMethodsGet 0 147 321
assign 1 147 322
iteratorGet 0 147 322
assign 1 147 325
hasNextGet 0 147 325
assign 1 148 327
nextGet 0 148 327
assign 1 149 328
mtdMapGet 0 149 328
assign 1 149 329
heldGet 0 149 329
assign 1 149 330
nameGet 0 149 330
assign 1 149 331
get 1 149 331
assign 1 150 332
def 1 150 337
assign 1 151 338
rsynGet 0 151 338
assign 1 151 339
def 1 151 344
assign 1 152 345
heldGet 0 152 345
assign 1 152 346
rtypeGet 0 152 346
assign 1 152 347
undef 1 152 352
assign 1 153 353
new 0 153 353
assign 1 153 354
heldGet 0 153 354
assign 1 153 355
nameGet 0 153 355
assign 1 153 356
add 1 153 356
assign 1 153 357
new 0 153 357
assign 1 153 358
add 1 153 358
assign 1 153 359
heldGet 0 153 359
assign 1 153 360
nameGet 0 153 360
assign 1 153 361
add 1 153 361
assign 1 153 362
new 2 153 362
throw 1 153 363
loadClass 1 158 372
assign 1 159 373
depthGet 0 159 373
assign 1 159 374
new 0 159 374
assign 1 159 375
add 1 159 375
assign 1 163 380
has 1 163 380
return 1 163 381
return 1 167 449
assign 1 168 451
new 0 168 451
assign 1 169 452
new 0 169 452
assign 1 170 453
new 0 170 453
assign 1 171 454
new 0 171 454
assign 1 172 455
undef 1 172 460
assign 1 173 461
new 0 173 461
assign 1 174 462
sizeGet 0 174 462
assign 1 175 463
sizeGet 0 175 463
assign 1 176 464
assign 1 177 465
iteratorGet 0 0 465
assign 1 177 468
hasNextGet 0 177 468
assign 1 177 470
nextGet 0 177 470
assign 1 178 471
emitDataGet 0 178 471
assign 1 178 472
methodIndexesGet 0 178 472
assign 1 178 473
new 2 178 473
put 1 178 474
return 1 180 480
assign 1 182 482
getSynNp 1 182 482
assign 1 183 483
new 0 183 483
assign 1 184 484
new 0 184 484
assign 1 186 485
sizeGet 0 186 485
assign 1 186 486
ptyListGet 0 186 486
assign 1 186 487
sizeGet 0 186 487
assign 1 186 488
subtract 1 186 488
assign 1 187 489
libNameGet 0 187 489
assign 1 187 490
equals 1 187 490
integrate 1 187 492
assign 1 188 494
isFinalGet 0 188 494
assign 1 189 496
new 0 189 496
assign 1 189 497
toString 0 189 497
assign 1 189 498
add 1 189 498
assign 1 189 499
new 1 189 499
throw 1 189 500
assign 1 191 502
isLocalGet 0 191 502
assign 1 191 504
libNameGet 0 191 504
assign 1 191 505
notEquals 1 191 505
assign 1 0 507
assign 1 0 510
assign 1 0 514
assign 1 192 517
new 0 192 517
assign 1 192 518
toString 0 192 518
assign 1 192 519
add 1 192 519
assign 1 192 520
new 1 192 520
throw 1 192 521
assign 1 194 523
isLocalGet 0 194 523
assign 1 194 525
not 0 194 530
assign 1 0 531
assign 1 0 534
assign 1 0 538
assign 1 194 541
not 0 194 546
assign 1 0 547
assign 1 0 550
assign 1 0 554
assign 1 195 557
new 0 195 557
assign 1 195 558
toString 0 195 558
assign 1 195 559
add 1 195 559
assign 1 195 560
new 1 195 560
throw 1 195 561
assign 1 197 563
linkedListIteratorGet 0 0 563
assign 1 197 566
hasNextGet 0 197 566
assign 1 197 568
nextGet 0 197 568
assign 1 198 569
getSynNp 1 198 569
assign 1 199 570
closeLibrariesGet 0 199 570
assign 1 199 571
libNameGet 0 199 571
assign 1 199 572
has 1 199 572
assign 1 199 573
not 0 199 578
assign 1 199 579
toString 0 199 579
assign 1 199 580
new 0 199 580
assign 1 199 581
notEquals 1 199 581
assign 1 0 583
assign 1 0 586
assign 1 0 590
assign 1 201 593
new 0 201 593
assign 1 202 594
new 0 202 594
assign 1 204 596
closeLibrariesGet 0 204 596
assign 1 204 597
libNameGet 0 204 597
assign 1 204 598
has 1 204 598
assign 1 204 599
not 0 204 604
assign 1 205 605
new 0 205 605
assign 1 209 612
valueIteratorGet 0 209 612
assign 1 209 615
hasNextGet 0 209 615
assign 1 210 617
nextGet 0 210 617
assign 1 211 618
mtdMapGet 0 211 618
assign 1 211 619
nameGet 0 211 619
assign 1 211 620
get 1 211 620
assign 1 212 621
def 1 212 626
assign 1 213 627
notEquals 1 213 627
assign 1 214 629
new 0 214 629
lastDefSet 1 214 630
assign 1 215 631
new 0 215 631
isOverrideSet 1 215 632
assign 1 216 633
increment 0 216 633
assign 1 219 637
new 0 219 637
isOverrideSet 1 219 638
assign 1 220 639
increment 0 220 639
assign 1 221 640
increment 0 221 640
assign 1 222 641
emitDataGet 0 222 641
assign 1 222 642
methodIndexesGet 0 222 642
assign 1 222 643
new 2 222 643
put 1 222 644
return 1 229 745
assign 1 230 747
new 0 230 747
assign 1 231 748
undef 1 231 753
return 1 231 754
assign 1 232 756
getSynNp 1 232 756
assign 1 233 757
heldGet 0 233 757
assign 1 233 758
orderedVarsGet 0 233 758
assign 1 233 759
iteratorGet 0 233 759
assign 1 233 762
hasNextGet 0 233 762
assign 1 234 764
nextGet 0 234 764
assign 1 235 765
ptyMapGet 0 235 765
assign 1 235 766
heldGet 0 235 766
assign 1 235 767
nameGet 0 235 767
assign 1 235 768
get 1 235 768
assign 1 236 769
def 1 236 774
assign 1 237 775
heldGet 0 237 775
assign 1 237 776
isDeclaredGet 0 237 776
assign 1 238 778
new 0 238 778
assign 1 238 779
heldGet 0 238 779
assign 1 238 780
nameGet 0 238 780
assign 1 238 781
add 1 238 781
assign 1 238 782
new 0 238 782
assign 1 238 783
add 1 238 783
assign 1 238 784
heldGet 0 238 784
assign 1 238 785
namepathGet 0 238 785
assign 1 238 786
toString 0 238 786
assign 1 238 787
add 1 238 787
assign 1 238 788
new 1 238 788
throw 1 238 789
assign 1 240 792
heldGet 0 240 792
assign 1 240 793
memSynGet 0 240 793
assign 1 240 794
isTypedGet 0 240 794
isTypedSet 1 240 795
assign 1 241 796
heldGet 0 241 796
assign 1 241 797
memSynGet 0 241 797
assign 1 241 798
namepathGet 0 241 798
namepathSet 1 241 799
assign 1 245 807
heldGet 0 245 807
assign 1 245 808
orderedMethodsGet 0 245 808
assign 1 245 809
iteratorGet 0 245 809
assign 1 245 812
hasNextGet 0 245 812
assign 1 246 814
nextGet 0 246 814
assign 1 247 815
mtdMapGet 0 247 815
assign 1 247 816
heldGet 0 247 816
assign 1 247 817
nameGet 0 247 817
assign 1 247 818
get 1 247 818
assign 1 248 819
def 1 248 824
assign 1 249 825
isFinalGet 0 249 825
assign 1 250 827
new 0 250 827
assign 1 250 828
heldGet 0 250 828
assign 1 250 829
nameGet 0 250 829
assign 1 250 830
add 1 250 830
assign 1 250 831
new 0 250 831
assign 1 250 832
add 1 250 832
assign 1 250 833
heldGet 0 250 833
assign 1 250 834
namepathGet 0 250 834
assign 1 250 835
toString 0 250 835
assign 1 250 836
add 1 250 836
assign 1 250 837
new 2 250 837
throw 1 250 838
assign 1 252 840
containedGet 0 252 840
assign 1 252 841
firstGet 0 252 841
assign 1 252 842
containedGet 0 252 842
assign 1 253 843
new 0 253 843
assign 1 253 846
argSynsGet 0 253 846
assign 1 253 847
lengthGet 0 253 847
assign 1 253 848
lesser 1 253 848
assign 1 254 850
argSynsGet 0 254 850
assign 1 254 851
get 1 254 851
assign 1 255 852
get 1 255 852
assign 1 255 853
heldGet 0 255 853
checkTypes 5 257 854
assign 1 253 855
increment 0 253 855
assign 1 259 861
rsynGet 0 259 861
assign 1 260 862
heldGet 0 260 862
assign 1 260 863
rtypeGet 0 260 863
assign 1 261 864
undef 1 261 869
assign 1 0 870
assign 1 261 873
undef 1 261 878
assign 1 0 879
assign 1 0 882
assign 1 262 886
undef 1 262 891
assign 1 262 891
not 0 262 896
assign 1 0 897
assign 1 262 900
undef 1 262 905
assign 1 262 905
not 0 262 910
assign 1 0 911
assign 1 0 914
assign 1 267 918
new 0 267 918
assign 1 267 919
heldGet 0 267 919
assign 1 267 920
namepathGet 0 267 920
assign 1 267 921
toString 0 267 921
assign 1 267 922
add 1 267 922
assign 1 267 923
new 2 267 923
throw 1 267 924
assign 1 271 928
isThisGet 0 271 928
assign 1 271 930
isThisGet 0 271 930
assign 1 271 931
isThisGet 0 271 931
assign 1 271 932
notEquals 1 271 932
assign 1 0 934
assign 1 0 937
assign 1 0 941
assign 1 272 944
new 0 272 944
assign 1 272 945
heldGet 0 272 945
assign 1 272 946
namepathGet 0 272 946
assign 1 272 947
toString 0 272 947
assign 1 272 948
add 1 272 948
assign 1 272 949
new 2 272 949
throw 1 272 950
checkTypes 5 274 952
assign 1 281 988
isTypedGet 0 281 988
assign 1 281 989
isTypedGet 0 281 989
assign 1 281 990
notEquals 1 281 990
assign 1 282 992
new 0 282 992
assign 1 282 993
heldGet 0 282 993
assign 1 282 994
namepathGet 0 282 994
assign 1 282 995
toString 0 282 995
assign 1 282 996
add 1 282 996
assign 1 282 997
new 2 282 997
throw 1 282 998
assign 1 283 1001
isTypedGet 0 283 1001
assign 1 286 1003
isSelfGet 0 286 1003
assign 1 286 1005
isSelfGet 0 286 1005
assign 1 0 1007
assign 1 0 1010
assign 1 0 1014
return 1 287 1017
assign 1 289 1019
namepathGet 0 289 1019
assign 1 289 1020
getSynNp 1 289 1020
assign 1 290 1021
allTypesGet 0 290 1021
assign 1 290 1022
namepathGet 0 290 1022
assign 1 290 1023
has 1 290 1023
assign 1 290 1024
not 0 290 1024
assign 1 291 1026
new 0 291 1026
assign 1 291 1027
heldGet 0 291 1027
assign 1 291 1028
namepathGet 0 291 1028
assign 1 291 1029
toString 0 291 1029
assign 1 291 1030
add 1 291 1030
assign 1 291 1031
new 2 291 1031
throw 1 291 1032
new 0 297 1058
assign 1 298 1059
heldGet 0 298 1059
assign 1 298 1060
orderedVarsGet 0 298 1060
assign 1 298 1061
iteratorGet 0 298 1061
assign 1 298 1064
hasNextGet 0 298 1064
assign 1 299 1066
nextGet 0 299 1066
assign 1 300 1067
heldGet 0 300 1067
assign 1 300 1068
isDeclaredGet 0 300 1068
assign 1 300 1069
not 0 300 1069
assign 1 301 1071
new 0 301 1071
assign 1 301 1072
heldGet 0 301 1072
assign 1 301 1073
nameGet 0 301 1073
assign 1 301 1074
add 1 301 1074
assign 1 301 1075
new 0 301 1075
assign 1 301 1076
add 1 301 1076
assign 1 301 1077
heldGet 0 301 1077
assign 1 301 1078
namepathGet 0 301 1078
assign 1 301 1079
toString 0 301 1079
assign 1 301 1080
add 1 301 1080
assign 1 301 1081
new 2 301 1081
throw 1 301 1082
loadClass 1 304 1089
assign 1 305 1090
new 0 305 1090
assign 1 310 1118
heldGet 0 310 1118
assign 1 310 1119
fromFileGet 0 310 1119
assign 1 311 1120
heldGet 0 311 1120
assign 1 311 1121
namepathGet 0 311 1121
assign 1 312 1122
heldGet 0 312 1122
assign 1 312 1123
libNameGet 0 312 1123
assign 1 313 1124
heldGet 0 313 1124
assign 1 313 1125
isFinalGet 0 313 1125
assign 1 314 1126
heldGet 0 314 1126
assign 1 314 1127
isLocalGet 0 314 1127
assign 1 315 1128
heldGet 0 315 1128
assign 1 315 1129
isNotNullGet 0 315 1129
assign 1 316 1130
heldGet 0 316 1130
assign 1 316 1131
usedGet 0 316 1131
assign 1 316 1132
iteratorGet 0 316 1132
assign 1 316 1135
hasNextGet 0 316 1135
assign 1 317 1137
nextGet 0 317 1137
assign 1 318 1138
toString 0 318 1138
put 1 318 1139
assign 1 320 1145
heldGet 0 320 1145
assign 1 320 1146
orderedVarsGet 0 320 1146
assign 1 320 1147
iteratorGet 0 320 1147
assign 1 320 1150
hasNextGet 0 320 1150
assign 1 321 1152
nextGet 0 321 1152
assign 1 322 1153
new 2 322 1153
addValue 1 323 1154
assign 1 325 1160
heldGet 0 325 1160
assign 1 325 1161
orderedMethodsGet 0 325 1161
assign 1 325 1162
iteratorGet 0 325 1162
assign 1 325 1165
hasNextGet 0 325 1165
assign 1 326 1167
nextGet 0 326 1167
assign 1 327 1168
new 2 327 1168
addValue 1 328 1169
postLoad 0 330 1175
assign 1 334 1226
new 0 334 1226
assign 1 335 1227
new 0 335 1227
assign 1 338 1228
iteratorGet 0 338 1228
assign 1 338 1231
hasNextGet 0 338 1231
assign 1 339 1233
nextGet 0 339 1233
assign 1 340 1234
nameGet 0 340 1234
assign 1 340 1235
has 1 340 1235
assign 1 340 1236
not 0 340 1241
assign 1 342 1242
nameGet 0 342 1242
put 2 342 1243
assign 1 346 1250
new 0 346 1250
assign 1 347 1251
new 0 347 1251
assign 1 348 1252
iteratorGet 0 348 1252
assign 1 348 1255
hasNextGet 0 348 1255
assign 1 349 1257
nextGet 0 349 1257
assign 1 350 1258
nameGet 0 350 1258
assign 1 350 1259
has 1 350 1259
assign 1 350 1260
not 0 350 1265
assign 1 351 1266
nameGet 0 351 1266
assign 1 351 1267
get 1 351 1267
mposSet 1 352 1268
assign 1 353 1269
new 0 353 1269
assign 1 353 1270
add 1 353 1270
addValue 1 354 1271
assign 1 355 1272
nameGet 0 355 1272
assign 1 355 1273
nameGet 0 355 1273
put 2 355 1274
assign 1 358 1281
assign 1 360 1282
new 0 360 1282
assign 1 362 1283
iteratorGet 0 362 1283
assign 1 362 1286
hasNextGet 0 362 1286
assign 1 363 1288
nextGet 0 363 1288
assign 1 365 1289
nameGet 0 365 1289
put 2 365 1290
assign 1 367 1291
nameGet 0 367 1291
assign 1 367 1292
has 1 367 1292
assign 1 367 1293
not 0 367 1298
assign 1 368 1299
nameGet 0 368 1299
put 2 368 1300
assign 1 372 1307
new 0 372 1307
assign 1 373 1308
new 0 373 1308
assign 1 374 1309
iteratorGet 0 374 1309
assign 1 374 1312
hasNextGet 0 374 1312
assign 1 375 1314
nextGet 0 375 1314
assign 1 376 1315
nameGet 0 376 1315
assign 1 376 1316
has 1 376 1316
assign 1 376 1317
not 0 376 1322
assign 1 377 1323
nameGet 0 377 1323
assign 1 377 1324
get 1 377 1324
assign 1 386 1325
nameGet 0 386 1325
assign 1 386 1326
get 1 386 1326
assign 1 387 1327
declarationGet 0 387 1327
assign 1 387 1328
undef 1 387 1333
assign 1 388 1334
originGet 0 388 1334
declarationSet 1 388 1335
assign 1 390 1337
declarationGet 0 390 1337
declarationSet 1 390 1338
mtdxSet 1 391 1339
assign 1 392 1340
increment 0 392 1340
addValue 1 393 1341
assign 1 394 1342
nameGet 0 394 1342
assign 1 394 1343
nameGet 0 394 1343
put 2 394 1344
assign 1 397 1351
assign 1 399 1352
linkedListIteratorGet 0 0 1352
assign 1 399 1355
hasNextGet 0 399 1355
assign 1 399 1357
nextGet 0 399 1357
put 2 400 1358
assign 1 401 1359
put 2 404 1365
return 1 0 1369
return 1 0 1372
assign 1 0 1375
assign 1 0 1379
return 1 0 1383
return 1 0 1386
assign 1 0 1389
assign 1 0 1393
return 1 0 1397
return 1 0 1400
assign 1 0 1403
assign 1 0 1407
return 1 0 1411
return 1 0 1414
assign 1 0 1417
assign 1 0 1421
return 1 0 1425
return 1 0 1428
assign 1 0 1431
assign 1 0 1435
return 1 0 1439
return 1 0 1442
assign 1 0 1445
assign 1 0 1449
return 1 0 1453
return 1 0 1456
assign 1 0 1459
assign 1 0 1463
return 1 0 1467
return 1 0 1470
assign 1 0 1473
assign 1 0 1477
return 1 0 1481
return 1 0 1484
assign 1 0 1487
assign 1 0 1491
return 1 0 1495
return 1 0 1498
assign 1 0 1501
assign 1 0 1505
return 1 0 1509
return 1 0 1512
assign 1 0 1515
assign 1 0 1519
return 1 0 1523
return 1 0 1526
assign 1 0 1529
assign 1 0 1533
return 1 0 1537
return 1 0 1540
assign 1 0 1543
assign 1 0 1547
return 1 0 1551
return 1 0 1554
assign 1 0 1557
assign 1 0 1561
return 1 0 1565
return 1 0 1568
assign 1 0 1571
assign 1 0 1575
return 1 0 1579
return 1 0 1582
assign 1 0 1585
assign 1 0 1589
return 1 0 1593
return 1 0 1596
assign 1 0 1599
assign 1 0 1603
return 1 0 1607
return 1 0 1610
assign 1 0 1613
assign 1 0 1617
return 1 0 1621
return 1 0 1624
assign 1 0 1627
assign 1 0 1631
return 1 0 1635
return 1 0 1638
assign 1 0 1641
assign 1 0 1645
return 1 0 1649
return 1 0 1652
assign 1 0 1655
assign 1 0 1659
return 1 0 1663
return 1 0 1666
assign 1 0 1669
assign 1 0 1673
return 1 0 1677
return 1 0 1680
assign 1 0 1683
assign 1 0 1687
return 1 0 1691
return 1 0 1694
assign 1 0 1697
assign 1 0 1701
return 1 0 1705
return 1 0 1708
assign 1 0 1711
assign 1 0 1715
return 1 0 1719
return 1 0 1722
assign 1 0 1725
assign 1 0 1729
return 1 0 1733
return 1 0 1736
assign 1 0 1739
assign 1 0 1743
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 580786361: return bem_hasDefaultGet_0();
case -1406800786: return bem_foreignClassesGetDirect_0();
case 1365471067: return bem_print_0();
case -879333110: return bem_ptyMapGetDirect_0();
case 704460341: return bem_mtdMapGet_0();
case 909645719: return bem_newMbrsGet_0();
case -887167109: return bem_fromFileGetDirect_0();
case 1483353089: return bem_mtdMapGetDirect_0();
case 1540741582: return bem_mtdListGetDirect_0();
case -1571719846: return bem_mtdListGet_0();
case 61013342: return bem_superNpGetDirect_0();
case -1303115743: return bem_hashGet_0();
case -1775874186: return bem_usesGet_0();
case 1690848108: return bem_echo_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case 1286465292: return bem_allTypesGet_0();
case 934150254: return bem_newMtdsGet_0();
case 1003473740: return bem_directPropertiesGet_0();
case 565636739: return bem_namepathGet_0();
case 915846215: return bem_directMethodsGetDirect_0();
case 1142074911: return bem_fromFileGet_0();
case 1282857093: return bem_ptyListGetDirect_0();
case 1340694490: return bem_new_0();
case -835303456: return bem_many_0();
case 117162964: return bem_newMtdsGetDirect_0();
case -2059930718: return bem_maxMtdxGet_0();
case -1013807563: return bem_isFinalGetDirect_0();
case 597544801: return bem_newMbrsGetDirect_0();
case -1275133637: return bem_superNpGet_0();
case -40822487: return bem_directMethodsGet_0();
case -1702446305: return bem_depthGetDirect_0();
case 913289094: return bem_allTypesGetDirect_0();
case 1264998916: return bem_allAncestorsCloseGet_0();
case 1963695386: return bem_toString_0();
case -317041533: return bem_foreignClassesGet_0();
case 590843911: return bem_usesGetDirect_0();
case -1045627857: return bem_create_0();
case -677744188: return bem_signatureCheckedGetDirect_0();
case -856707590: return bem_tagGet_0();
case -866115065: return bem_allNamesGet_0();
case -351894064: return bem_postLoad_0();
case 88424709: return bem_iCheckedGetDirect_0();
case -750762161: return bem_defMtdsGetDirect_0();
case 2098104332: return bem_isNotNullGet_0();
case 1449940664: return bem_ptyMapGet_0();
case -1731732560: return bem_iCheckedGet_0();
case -1350181023: return bem_libNameGetDirect_0();
case 1026230476: return bem_isLocalGetDirect_0();
case -1287943088: return bem_copy_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 719879827: return bem_signatureChangedGet_0();
case 1127021181: return bem_isNotNullGetDirect_0();
case -334596089: return bem_ptyListGet_0();
case -2119901542: return bem_libNameGet_0();
case -992648109: return bem_namepathGetDirect_0();
case -843777464: return bem_integratedGet_0();
case -348782970: return bem_serializeToString_0();
case 265714607: return bem_superListGet_0();
case 1642971647: return bem_signatureCheckedGet_0();
case -723282878: return bem_serializeContents_0();
case 353377191: return bem_classNameGet_0();
case 1377925332: return bem_integratedGetDirect_0();
case 1776712568: return bem_iteratorGet_0();
case -1723287273: return bem_fieldIteratorGet_0();
case -2091217929: return bem_toAny_0();
case 1287286342: return bem_defMtdsGet_0();
case -1714605543: return bem_isLocalGet_0();
case 756642383: return bem_fieldNamesGet_0();
case 1426474238: return bem_once_0();
case 1688023222: return bem_depthGet_0();
case -1758172921: return bem_isFinalGet_0();
case 1728952582: return bem_signatureChangedGetDirect_0();
case -1851666723: return bem_allAncestorsCloseGetDirect_0();
case 300497104: return bem_directPropertiesGetDirect_0();
case 805348767: return bem_serializationIteratorGet_0();
case 583333898: return bem_superListGetDirect_0();
case -180850668: return bem_allNamesGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1203082377: return bem_directMethodsSet_1(bevd_0);
case -2059713689: return bem_namepathSet_1(bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case 159782826: return bem_superNpSet_1(bevd_0);
case -1658817798: return bem_depthSet_1(bevd_0);
case -742775900: return bem_new_1(bevd_0);
case 365611062: return bem_foreignClassesSet_1(bevd_0);
case -1362880618: return bem_fromFileSetDirect_1(bevd_0);
case 1426503336: return bem_mtdMapSetDirect_1(bevd_0);
case 628952658: return bem_allAncestorsCloseSet_1(bevd_0);
case 110968457: return bem_mtdListSetDirect_1(bevd_0);
case -184465830: return bem_isFinalSet_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1127178501: return bem_isNotNullSetDirect_1(bevd_0);
case -1566163953: return bem_usesSetDirect_1(bevd_0);
case -550139783: return bem_otherType_1(bevd_0);
case -771483716: return bem_superListSetDirect_1(bevd_0);
case 1178094503: return bem_allTypesSetDirect_1(bevd_0);
case 844414713: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1412377002: return bem_undef_1(bevd_0);
case -1524432014: return bem_isLocalSetDirect_1(bevd_0);
case 91584758: return bem_fromFileSet_1(bevd_0);
case 41511525: return bem_iCheckedSetDirect_1(bevd_0);
case -661339921: return bem_libNameSet_1(bevd_0);
case 92894119: return bem_allTypesSet_1(bevd_0);
case -1192107624: return bem_directPropertiesSetDirect_1(bevd_0);
case 1484423832: return bem_allNamesSetDirect_1(bevd_0);
case 1574839946: return bem_directPropertiesSet_1(bevd_0);
case 2067195802: return bem_newMtdsSetDirect_1(bevd_0);
case 2001273702: return bem_libNameSetDirect_1(bevd_0);
case -433099289: return bem_isNotNullSet_1(bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
case 160362096: return bem_loadClass_1(bevd_0);
case 1883513262: return bem_signatureChangedSet_1(bevd_0);
case 1319856672: return bem_foreignClassesSetDirect_1(bevd_0);
case -696910703: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1663455700: return bem_usesSet_1(bevd_0);
case 1243102113: return bem_signatureCheckedSet_1(bevd_0);
case 530174437: return bem_newMbrsSetDirect_1(bevd_0);
case 1708451250: return bem_isLocalSet_1(bevd_0);
case 1547930161: return bem_defMtdsSetDirect_1(bevd_0);
case -650952923: return bem_superNpSetDirect_1(bevd_0);
case -772613955: return bem_ptyMapSet_1(bevd_0);
case -793887534: return bem_otherClass_1(bevd_0);
case -536530975: return bem_isFinalSetDirect_1(bevd_0);
case -228252329: return bem_allAncestorsCloseSetDirect_1(bevd_0);
case 10363691: return bem_directMethodsSetDirect_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case 1027215240: return bem_defMtdsSet_1(bevd_0);
case 1227572669: return bem_superListSet_1(bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1601208687: return bem_mtdMapSet_1(bevd_0);
case 23930185: return bem_signatureCheckedSetDirect_1(bevd_0);
case -480348635: return bem_def_1(bevd_0);
case -1150764493: return bem_ptyMapSetDirect_1(bevd_0);
case -748926066: return bem_iCheckedSet_1(bevd_0);
case 2085616414: return bem_integratedSetDirect_1(bevd_0);
case 1037969743: return bem_integratedSet_1(bevd_0);
case 173133942: return bem_newMbrsSet_1(bevd_0);
case -543337573: return bem_depthSetDirect_1(bevd_0);
case 2129603513: return bem_defined_1(bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case -2074529295: return bem_signatureChangedSetDirect_1(bevd_0);
case -1518039639: return bem_namepathSetDirect_1(bevd_0);
case -451622951: return bem_ptyListSetDirect_1(bevd_0);
case -1302656122: return bem_newMtdsSet_1(bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case 1851900668: return bem_mtdListSet_1(bevd_0);
case 2004123549: return bem_ptyListSet_1(bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case -1270864803: return bem_allNamesSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -468614659: return bem_checkInheritance_2(bevd_0, bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1062329286: return bem_new_2(bevd_0, bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 684506348: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildClassSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_8_BuildClassSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildClassSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst = (BEC_2_5_8_BuildClassSyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_type;
}
}
}
