namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_8_BuildClassSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
static BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_0, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_2, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_3, 44));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_4, 78));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_5, 12));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_6, 38));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_7, 68));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_8, 75));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_9, 13));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_10, 65));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_11, 11));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_12, 33));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_13 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_13, 1));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_14, 95));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x62,0x75,0x74,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_15, 90));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_16, 84));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_17 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_17, 80));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_18 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_18, 9));
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_19 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildClassSyn_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildClassSyn_bels_19, 26));
public static new BEC_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_inst;

public static new BET_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_4_ContainerList bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_4_ContainerList bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_maxMtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 96 */ {
bevt_0_tmpany_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 99 */
} /* Line: 98 */
 else  /* Line: 96 */ {
break;
} /* Line: 96 */
} /* Line: 96 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpany_phold);
if (bevl_dmtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 107 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 109 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = beva_psyn.bemd_0(-1384043882);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bemd_0(-296810667);
bevt_3_tmpany_phold = beva_psyn.bemd_0(-1468375282);
bevp_superList.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = beva_psyn.bemd_0(955242221);
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_4_tmpany_phold.bemd_0(-296810667);
bevt_5_tmpany_phold = beva_psyn.bemd_0(227163298);
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_5_tmpany_phold.bemd_0(-296810667);
bevt_7_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-856021326);
bevl_iv = bevt_6_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 132 */ {
bevt_8_tmpany_phold = bevl_iv.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevl_ov = bevl_iv.bemd_0(1471239590);
bevt_9_tmpany_phold = beva_psyn.bemd_0(-765757544);
bevt_11_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1126230749);
bevl_pv = bevt_9_tmpany_phold.bemd_1(-2130446874, bevt_10_tmpany_phold);
bevt_14_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-1126230749);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_8_BuildClassSyn_bels_1));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(-1424462703, bevt_15_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 135 */ {
if (bevl_pv == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_19_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-364507972);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(-1066130750);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_1;
bevt_26_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-1126230749);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_2;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-1468375282);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-1737970926);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 136 */
} /* Line: 135 */
 else  /* Line: 132 */ {
break;
} /* Line: 132 */
} /* Line: 132 */
bevt_31_tmpany_phold = beva_psyn.bemd_0(227163298);
bevl_iv = bevt_31_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 141 */ {
bevt_32_tmpany_phold = bevl_iv.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevl_ov = bevl_iv.bemd_0(1471239590);
bevt_34_tmpany_phold = bevl_ov.bemd_0(-211514934);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(-1252591542);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevt_35_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_37_tmpany_phold = bevl_ov.bemd_0(-211514934);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-1468375282);
bevt_35_tmpany_phold.bemd_1(-1308774944, bevt_36_tmpany_phold);
} /* Line: 144 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
bevt_39_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(1933602642);
bevl_im = bevt_38_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 148 */ {
bevt_40_tmpany_phold = bevl_im.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 148 */ {
bevl_om = bevl_im.bemd_0(1471239590);
bevt_41_tmpany_phold = beva_psyn.bemd_0(-119984388);
bevt_43_tmpany_phold = bevl_om.bemd_0(-2030765001);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(-1126230749);
bevl_pm = bevt_41_tmpany_phold.bemd_1(-2130446874, bevt_42_tmpany_phold);
if (bevl_pm == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_46_tmpany_phold = bevl_pm.bemd_0(-338232564);
if (bevt_46_tmpany_phold == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_49_tmpany_phold = bevl_om.bemd_0(-2030765001);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(1215099666);
if (bevt_48_tmpany_phold == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_54_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_3;
bevt_56_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_0(-1126230749);
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_add_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_4;
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_add_1(bevt_57_tmpany_phold);
bevt_59_tmpany_phold = bevl_om.bemd_0(-2030765001);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(-1126230749);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_50_tmpany_phold);
} /* Line: 154 */
} /* Line: 153 */
} /* Line: 152 */
} /* Line: 151 */
 else  /* Line: 148 */ {
break;
} /* Line: 148 */
} /* Line: 148 */
bem_loadClass_1(beva_klass);
bevt_60_tmpany_phold = beva_psyn.bemd_0(-1284976174);
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpany_phold.bemd_1(-668339329, bevt_61_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpany_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 168 */ {
return this;
} /* Line: 168 */
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpany_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 178 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 178 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1471239590);
bevt_9_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_methodIndexesGet_0();
bevt_10_tmpany_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpany_phold.bem_put_1(bevt_10_tmpany_phold);
} /* Line: 179 */
 else  /* Line: 178 */ {
break;
} /* Line: 178 */
} /* Line: 178 */
return this;
} /* Line: 181 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_11_tmpany_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpany_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpany_phold.bem_subtract_1(bevt_12_tmpany_phold);
bevt_15_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 188 */
bevt_16_tmpany_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_5;
bevt_20_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_17_tmpany_phold);
} /* Line: 190 */
bevt_21_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_23_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_26_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_6;
bevt_27_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 193 */
bevt_28_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 195 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 195 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_7;
bevt_34_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_31_tmpany_phold);
} /* Line: 196 */
bevt_1_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 198 */ {
bevt_35_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 198 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_has_1(bevt_39_tmpany_phold);
if (bevt_37_tmpany_phold.bevi_bool) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_41_tmpany_phold = bevl_pn.bem_toString_0();
bevt_42_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_8;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_notEquals_1(bevt_42_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 200 */ {
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 203 */
bevt_45_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 206 */
} /* Line: 205 */
 else  /* Line: 198 */ {
break;
} /* Line: 198 */
} /* Line: 198 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 210 */ {
bevt_47_tmpany_phold = bevl_im.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 210 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1471239590);
bevt_48_tmpany_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpany_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
if (bevl_pm == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_51_tmpany_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevt_52_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpany_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 217 */
} /* Line: 214 */
 else  /* Line: 219 */ {
bevt_54_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpany_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_methodIndexesGet_0();
bevt_57_tmpany_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpany_phold.bem_put_1(bevt_57_tmpany_phold);
} /* Line: 223 */
} /* Line: 213 */
 else  /* Line: 210 */ {
break;
} /* Line: 210 */
} /* Line: 210 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 230 */ {
return this;
} /* Line: 230 */
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 232 */ {
return this;
} /* Line: 232 */
bevl_psyn = beva_build.bemd_1(-268893067, bevp_superNp);
bevt_5_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-856021326);
bevl_iv = bevt_4_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 234 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 234 */ {
bevl_ov = bevl_iv.bemd_0(1471239590);
bevt_7_tmpany_phold = bevl_psyn.bemd_0(-765757544);
bevt_9_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1126230749);
bevl_pv = bevt_7_tmpany_phold.bemd_1(-2130446874, bevt_8_tmpany_phold);
if (bevl_pv == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_12_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-364507972);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_9;
bevt_19_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1126230749);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_10;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(-1468375282);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-1737970926);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_14_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_13_tmpany_phold);
} /* Line: 239 */
 else  /* Line: 240 */ {
bevt_24_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_26_tmpany_phold = bevl_pv.bemd_0(-211514934);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-1252591542);
bevt_24_tmpany_phold.bemd_1(274592371, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_29_tmpany_phold = bevl_pv.bemd_0(-211514934);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-1468375282);
bevt_27_tmpany_phold.bemd_1(-1586463740, bevt_28_tmpany_phold);
} /* Line: 242 */
} /* Line: 238 */
} /* Line: 237 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
bevt_31_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(1933602642);
bevl_im = bevt_30_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 246 */ {
bevt_32_tmpany_phold = bevl_im.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 246 */ {
bevl_om = bevl_im.bemd_0(1471239590);
bevt_33_tmpany_phold = bevl_psyn.bemd_0(-119984388);
bevt_35_tmpany_phold = bevl_om.bemd_0(-2030765001);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(-1126230749);
bevl_pm = bevt_33_tmpany_phold.bemd_1(-2130446874, bevt_34_tmpany_phold);
if (bevl_pm == null) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevt_37_tmpany_phold = bevl_pm.bemd_0(-1263963508);
if (((BEC_2_5_4_LogicBool) bevt_37_tmpany_phold).bevi_bool) /* Line: 250 */ {
bevt_42_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_11;
bevt_44_tmpany_phold = bevl_om.bemd_0(-2030765001);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(-1126230749);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_45_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_12;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(-1468375282);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(-1737970926);
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_39_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_38_tmpany_phold);
} /* Line: 251 */
bevt_50_tmpany_phold = bevl_om.bemd_0(1053870398);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(-1467982926);
bevl_oa = bevt_49_tmpany_phold.bemd_0(1053870398);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 254 */ {
bevt_53_tmpany_phold = bevl_pm.bemd_0(1296341237);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(-191277371);
bevt_51_tmpany_phold = bevl_i.bemd_1(-1864654129, bevt_52_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 254 */ {
bevt_54_tmpany_phold = bevl_pm.bemd_0(1296341237);
bevl_pmr = bevt_54_tmpany_phold.bemd_1(-2130446874, bevl_i);
bevt_55_tmpany_phold = bevl_oa.bemd_1(-2130446874, bevl_i);
bevl_omr = bevt_55_tmpany_phold.bemd_0(-2030765001);
bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(-1306358749);
} /* Line: 254 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
bevl_pmr = bevl_pm.bemd_0(-338232564);
bevt_56_tmpany_phold = bevl_om.bemd_0(-2030765001);
bevl_omr = bevt_56_tmpany_phold.bemd_0(1215099666);
if (bevl_pmr == null) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
if (bevl_omr == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 262 */ {
if (bevl_pmr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
if (bevl_omr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_65_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_13;
bevt_68_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(-1468375282);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_0(-1737970926);
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_add_1(bevt_66_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_63_tmpany_phold);
} /* Line: 268 */
} /* Line: 263 */
 else  /* Line: 270 */ {
bevt_69_tmpany_phold = bevl_pmr.bemd_0(1142928490);
if (((BEC_2_5_4_LogicBool) bevt_69_tmpany_phold).bevi_bool) /* Line: 272 */ {
bevt_71_tmpany_phold = bevl_pmr.bemd_0(1142928490);
bevt_72_tmpany_phold = bevl_omr.bemd_0(1142928490);
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(-1424462703, bevt_72_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_70_tmpany_phold).bevi_bool) /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 272 */ {
bevt_75_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_14;
bevt_78_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-1468375282);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bemd_0(-1737970926);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_76_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 273 */
bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 275 */
} /* Line: 262 */
} /* Line: 249 */
 else  /* Line: 246 */ {
break;
} /* Line: 246 */
} /* Line: 246 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
bevt_2_tmpany_phold = beva_pmr.bemd_0(-1252591542);
bevt_3_tmpany_phold = beva_omr.bemd_0(-1252591542);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(-1424462703, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_15;
bevt_9_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1468375282);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-1737970926);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 283 */
 else  /* Line: 282 */ {
bevt_10_tmpany_phold = beva_pmr.bemd_0(-1252591542);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_11_tmpany_phold = beva_pmr.bemd_0(-91849841);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_12_tmpany_phold = beva_omr.bemd_0(-91849841);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 287 */ {
return this;
} /* Line: 288 */
bevt_13_tmpany_phold = beva_omr.bemd_0(-1468375282);
bevl_osyn = beva_build.bemd_1(-268893067, bevt_13_tmpany_phold);
bevt_16_tmpany_phold = bevl_osyn.bemd_0(-753304415);
bevt_17_tmpany_phold = beva_pmr.bemd_0(-1468375282);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(1721175775, bevt_17_tmpany_phold);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(-1066130750);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 291 */ {
bevt_20_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_16;
bevt_23_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(-1468375282);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-1737970926);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_18_tmpany_phold);
} /* Line: 292 */
} /* Line: 291 */
} /* Line: 282 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
bem_new_0();
bevt_1_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-856021326);
bevl_iv = bevt_0_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 299 */ {
bevt_2_tmpany_phold = bevl_iv.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 299 */ {
bevl_ov = bevl_iv.bemd_0(1471239590);
bevt_5_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-364507972);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-1066130750);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 301 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_17;
bevt_12_tmpany_phold = bevl_ov.bemd_0(-2030765001);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-1126230749);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_8_BuildClassSyn_bevo_18;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_16_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1468375282);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(-1737970926);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 302 */
} /* Line: 301 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
bem_loadClass_1(beva_klass);
bevp_depth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bemd_0(1754266436);
bevt_1_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_phold.bemd_0(-1468375282);
bevt_2_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(582153509);
bevt_3_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpany_phold.bemd_0(-1263963508);
bevt_4_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpany_phold.bemd_0(-572013032);
bevt_5_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpany_phold.bemd_0(1012036029);
bevt_7_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-82810998);
bevl_iu = bevt_6_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 317 */ {
bevt_8_tmpany_phold = bevl_iu.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_ou = bevl_iu.bemd_0(1471239590);
bevt_9_tmpany_phold = bevl_ou.bemd_0(-1737970926);
bevp_uses.bem_put_1(bevt_9_tmpany_phold);
} /* Line: 319 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
bevt_11_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-856021326);
bevl_iv = bevt_10_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 321 */ {
bevt_12_tmpany_phold = bevl_iv.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 321 */ {
bevl_ov = bevl_iv.bemd_0(1471239590);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
bevt_14_tmpany_phold = beva_klass.bemd_0(-2030765001);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1933602642);
bevl_im = bevt_13_tmpany_phold.bemd_0(-2050938340);
while (true)
 /* Line: 326 */ {
bevt_15_tmpany_phold = bevl_im.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 326 */ {
bevl_om = bevl_im.bemd_0(1471239590);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 329 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_postLoad_0() {
BEC_2_9_4_ContainerList bevl_nptyList = null;
BEC_2_9_4_ContainerList bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
bevl_nptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_mtdnList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 339 */ {
bevt_1_tmpany_phold = bevl_iv.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 339 */ {
bevl_ov = bevl_iv.bemd_0(1471239590);
bevt_4_tmpany_phold = bevl_ov.bemd_0(-1126230749);
bevt_3_tmpany_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_5_tmpany_phold = bevl_ov.bemd_0(-1126230749);
bevp_ptyMap.bem_put_2(bevt_5_tmpany_phold, bevl_ov);
} /* Line: 343 */
} /* Line: 341 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 349 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 349 */ {
bevl_ov = bevl_iv.bemd_0(1471239590);
bevt_9_tmpany_phold = bevl_ov.bemd_0(-1126230749);
bevt_8_tmpany_phold = bevl_unq.bem_has_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevt_10_tmpany_phold = bevl_ov.bemd_0(-1126230749);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpany_phold);
bevl_nom.bemd_1(282413186, bevl_mpos);
bevt_11_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(-668339329, bevt_11_tmpany_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpany_phold = bevl_ov.bemd_0(-1126230749);
bevt_13_tmpany_phold = bevl_ov.bemd_0(-1126230749);
bevl_unq.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
} /* Line: 356 */
} /* Line: 351 */
 else  /* Line: 349 */ {
break;
} /* Line: 349 */
} /* Line: 349 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 363 */ {
bevt_14_tmpany_phold = bevl_im.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 363 */ {
bevl_om = bevl_im.bemd_0(1471239590);
bevt_15_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevp_mtdMap.bem_put_2(bevt_15_tmpany_phold, bevl_om);
bevt_18_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevt_17_tmpany_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 368 */ {
bevt_19_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevl_mtdOmap.bem_put_2(bevt_19_tmpany_phold, bevl_om);
} /* Line: 369 */
} /* Line: 368 */
 else  /* Line: 363 */ {
break;
} /* Line: 363 */
} /* Line: 363 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 375 */ {
bevt_20_tmpany_phold = bevl_im.bemd_0(1967108884);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 375 */ {
bevl_om = bevl_im.bemd_0(1471239590);
bevt_23_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevt_22_tmpany_phold = bevl_unq.bem_has_1(bevt_23_tmpany_phold);
if (bevt_22_tmpany_phold.bevi_bool) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 377 */ {
bevt_24_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevt_28_tmpany_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpany_phold);
} /* Line: 389 */
bevt_29_tmpany_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(1671127121, bevt_29_tmpany_phold);
bevl_oma.bemd_1(-107797978, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevt_31_tmpany_phold = bevl_om.bemd_0(-1126230749);
bevl_unq.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
} /* Line: 395 */
} /* Line: 377 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_32_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 400 */ {
bevl_s = bevt_0_tmpany_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGetDirect_0() {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() {
return bevp_depth;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGetDirect_0() {
return bevp_depth;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() {
return bevp_newMbrs;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGetDirect_0() {
return bevp_newMbrs;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() {
return bevp_newMtds;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGetDirect_0() {
return bevp_newMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() {
return bevp_defMtds;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGetDirect_0() {
return bevp_defMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGetDirect_0() {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGetDirect_0() {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() {
return bevp_allTypes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGetDirect_0() {
return bevp_allTypes;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() {
return bevp_superList;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGetDirect_0() {
return bevp_superList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() {
return bevp_mtdMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGetDirect_0() {
return bevp_mtdMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGet_0() {
return bevp_mtdList;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGetDirect_0() {
return bevp_mtdList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() {
return bevp_ptyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGetDirect_0() {
return bevp_ptyMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGet_0() {
return bevp_ptyList;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGetDirect_0() {
return bevp_ptyList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGetDirect_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGetDirect_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGetDirect_0() {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() {
return bevp_integrated;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGetDirect_0() {
return bevp_integrated;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGetDirect_0() {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() {
return bevp_uses;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGetDirect_0() {
return bevp_uses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGetDirect_0() {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGetDirect_0() {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {72, 74, 76, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88, 89, 90, 95, 96, 96, 97, 98, 98, 98, 99, 102, 106, 106, 107, 107, 109, 109, 111, 111, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 126, 127, 127, 128, 128, 129, 129, 132, 132, 132, 132, 133, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 135, 135, 135, 0, 0, 0, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 141, 141, 141, 142, 143, 143, 144, 144, 144, 144, 148, 148, 148, 148, 149, 150, 150, 150, 150, 151, 151, 152, 152, 152, 153, 153, 153, 153, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 159, 160, 160, 160, 164, 164, 168, 169, 170, 171, 172, 173, 173, 174, 175, 176, 177, 178, 0, 178, 178, 179, 179, 179, 179, 181, 183, 184, 185, 187, 187, 187, 187, 188, 188, 188, 189, 190, 190, 190, 190, 190, 192, 192, 192, 0, 0, 0, 193, 193, 193, 193, 193, 195, 195, 195, 0, 0, 0, 195, 195, 0, 0, 0, 196, 196, 196, 196, 196, 198, 0, 198, 198, 199, 200, 200, 200, 200, 200, 200, 200, 200, 0, 0, 0, 202, 203, 205, 205, 205, 205, 205, 206, 210, 210, 211, 212, 212, 212, 213, 213, 214, 215, 215, 216, 216, 217, 220, 220, 221, 222, 223, 223, 223, 223, 230, 231, 232, 232, 232, 233, 234, 234, 234, 234, 235, 236, 236, 236, 236, 237, 237, 238, 238, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 241, 241, 241, 241, 242, 242, 242, 242, 246, 246, 246, 246, 247, 248, 248, 248, 248, 249, 249, 250, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 253, 253, 253, 254, 254, 254, 254, 255, 255, 256, 256, 258, 254, 260, 261, 261, 262, 262, 0, 262, 262, 0, 0, 263, 263, 263, 0, 263, 263, 263, 0, 0, 268, 268, 268, 268, 268, 268, 268, 272, 272, 272, 272, 0, 0, 0, 273, 273, 273, 273, 273, 273, 273, 275, 282, 282, 282, 283, 283, 283, 283, 283, 283, 283, 284, 287, 287, 0, 0, 0, 288, 290, 290, 291, 291, 291, 291, 292, 292, 292, 292, 292, 292, 292, 298, 299, 299, 299, 299, 300, 301, 301, 301, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 305, 306, 311, 311, 312, 312, 313, 313, 314, 314, 315, 315, 316, 316, 317, 317, 317, 317, 318, 319, 319, 321, 321, 321, 321, 322, 323, 324, 326, 326, 326, 326, 327, 328, 329, 331, 335, 336, 339, 339, 340, 341, 341, 341, 341, 343, 343, 347, 348, 349, 349, 350, 351, 351, 351, 351, 352, 352, 353, 354, 354, 355, 356, 356, 356, 359, 361, 363, 363, 364, 366, 366, 368, 368, 368, 368, 369, 369, 373, 374, 375, 375, 376, 377, 377, 377, 377, 378, 378, 387, 387, 388, 388, 388, 389, 389, 391, 391, 392, 393, 394, 395, 395, 395, 398, 400, 0, 400, 400, 401, 402, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 103, 104, 107, 109, 110, 111, 116, 117, 124, 132, 133, 134, 139, 140, 141, 143, 144, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 241, 243, 244, 245, 246, 247, 248, 249, 250, 251, 253, 258, 259, 262, 266, 269, 270, 271, 273, 276, 280, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 301, 302, 305, 307, 308, 309, 311, 312, 313, 314, 321, 322, 323, 326, 328, 329, 330, 331, 332, 333, 338, 339, 340, 345, 346, 347, 348, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 373, 374, 375, 376, 381, 382, 450, 452, 453, 454, 455, 456, 461, 462, 463, 464, 465, 466, 466, 469, 471, 472, 473, 474, 475, 481, 483, 484, 485, 486, 487, 488, 489, 490, 491, 493, 495, 497, 498, 499, 500, 501, 503, 505, 506, 508, 511, 515, 518, 519, 520, 521, 522, 524, 526, 531, 532, 535, 539, 542, 547, 548, 551, 555, 558, 559, 560, 561, 562, 564, 564, 567, 569, 570, 571, 572, 573, 574, 579, 580, 581, 582, 584, 587, 591, 594, 595, 597, 598, 599, 600, 605, 606, 613, 616, 618, 619, 620, 621, 622, 627, 628, 630, 631, 632, 633, 634, 638, 639, 640, 641, 642, 643, 644, 645, 746, 748, 749, 754, 755, 757, 758, 759, 760, 763, 765, 766, 767, 768, 769, 770, 775, 776, 777, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 793, 794, 795, 796, 797, 798, 799, 800, 808, 809, 810, 813, 815, 816, 817, 818, 819, 820, 825, 826, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 841, 842, 843, 844, 847, 848, 849, 851, 852, 853, 854, 855, 856, 862, 863, 864, 865, 870, 871, 874, 879, 880, 883, 887, 892, 897, 898, 901, 906, 911, 912, 915, 919, 920, 921, 922, 923, 924, 925, 929, 931, 932, 933, 935, 938, 942, 945, 946, 947, 948, 949, 950, 951, 953, 989, 990, 991, 993, 994, 995, 996, 997, 998, 999, 1002, 1004, 1006, 1008, 1011, 1015, 1018, 1020, 1021, 1022, 1023, 1024, 1025, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1059, 1060, 1061, 1062, 1065, 1067, 1068, 1069, 1070, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1090, 1091, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1136, 1138, 1139, 1140, 1146, 1147, 1148, 1151, 1153, 1154, 1155, 1161, 1162, 1163, 1166, 1168, 1169, 1170, 1176, 1227, 1228, 1229, 1232, 1234, 1235, 1236, 1237, 1242, 1243, 1244, 1251, 1252, 1253, 1256, 1258, 1259, 1260, 1261, 1266, 1267, 1268, 1269, 1270, 1271, 1272, 1273, 1274, 1275, 1282, 1283, 1284, 1287, 1289, 1290, 1291, 1292, 1293, 1294, 1299, 1300, 1301, 1308, 1309, 1310, 1313, 1315, 1316, 1317, 1318, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1334, 1335, 1336, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1352, 1353, 1353, 1356, 1358, 1359, 1360, 1366, 1370, 1373, 1376, 1380, 1384, 1387, 1390, 1394, 1398, 1401, 1404, 1408, 1412, 1415, 1418, 1422, 1426, 1429, 1432, 1436, 1440, 1443, 1446, 1450, 1454, 1457, 1460, 1464, 1468, 1471, 1474, 1478, 1482, 1485, 1488, 1492, 1496, 1499, 1502, 1506, 1510, 1513, 1516, 1520, 1524, 1527, 1530, 1534, 1538, 1541, 1544, 1548, 1552, 1555, 1558, 1562, 1566, 1569, 1572, 1576, 1580, 1583, 1586, 1590, 1594, 1597, 1600, 1604, 1608, 1611, 1614, 1618, 1622, 1625, 1628, 1632, 1636, 1639, 1642, 1646, 1650, 1653, 1656, 1660, 1664, 1667, 1670, 1674, 1678, 1681, 1684, 1688, 1692, 1695, 1698, 1702, 1706, 1709, 1712, 1716, 1720, 1723, 1726, 1730, 1734, 1737, 1740, 1744};
/* BEGIN LINEINFO 
assign 1 72 79
new 0 72 79
assign 1 74 80
new 0 74 80
assign 1 76 81
new 0 76 81
assign 1 78 82
new 0 78 82
assign 1 79 83
new 0 79 83
assign 1 80 84
new 0 80 84
assign 1 81 85
new 0 81 85
assign 1 82 86
new 0 82 86
assign 1 83 87
new 0 83 87
assign 1 84 88
new 0 84 88
assign 1 85 89
new 0 85 89
assign 1 87 90
new 0 87 90
assign 1 88 91
new 0 88 91
assign 1 89 92
new 0 89 92
assign 1 90 93
new 0 90 93
assign 1 95 103
new 0 95 103
assign 1 96 104
valueIteratorGet 0 96 104
assign 1 96 107
hasNextGet 0 96 107
assign 1 97 109
nextGet 0 97 109
assign 1 98 110
mtdxGet 0 98 110
assign 1 98 111
greater 1 98 116
assign 1 99 117
mtdxGet 0 99 117
return 1 102 124
assign 1 106 132
new 0 106 132
assign 1 106 133
get 1 106 133
assign 1 107 134
def 1 107 139
assign 1 109 140
new 0 109 140
return 1 109 141
assign 1 111 143
new 0 111 143
return 1 111 144
assign 1 115 217
new 0 115 217
assign 1 116 218
new 0 116 218
assign 1 117 219
new 0 117 219
assign 1 118 220
new 0 118 220
assign 1 119 221
new 0 119 221
assign 1 120 222
new 0 120 222
assign 1 121 223
new 0 121 223
assign 1 122 224
new 0 122 224
assign 1 123 225
new 0 123 225
assign 1 124 226
new 0 124 226
assign 1 125 227
new 0 125 227
assign 1 126 228
superListGet 0 126 228
assign 1 126 229
copy 0 126 229
assign 1 127 230
namepathGet 0 127 230
addValue 1 127 231
assign 1 128 232
mtdListGet 0 128 232
assign 1 128 233
copy 0 128 233
assign 1 129 234
ptyListGet 0 129 234
assign 1 129 235
copy 0 129 235
assign 1 132 236
heldGet 0 132 236
assign 1 132 237
orderedVarsGet 0 132 237
assign 1 132 238
iteratorGet 0 132 238
assign 1 132 241
hasNextGet 0 132 241
assign 1 133 243
nextGet 0 133 243
assign 1 134 244
ptyMapGet 0 134 244
assign 1 134 245
heldGet 0 134 245
assign 1 134 246
nameGet 0 134 246
assign 1 134 247
get 1 134 247
assign 1 135 248
heldGet 0 135 248
assign 1 135 249
nameGet 0 135 249
assign 1 135 250
new 0 135 250
assign 1 135 251
notEquals 1 135 251
assign 1 135 253
undef 1 135 258
assign 1 0 259
assign 1 0 262
assign 1 0 266
assign 1 135 269
heldGet 0 135 269
assign 1 135 270
isDeclaredGet 0 135 270
assign 1 135 271
not 0 135 271
assign 1 0 273
assign 1 0 276
assign 1 0 280
assign 1 136 283
new 0 136 283
assign 1 136 284
heldGet 0 136 284
assign 1 136 285
nameGet 0 136 285
assign 1 136 286
add 1 136 286
assign 1 136 287
new 0 136 287
assign 1 136 288
add 1 136 288
assign 1 136 289
heldGet 0 136 289
assign 1 136 290
namepathGet 0 136 290
assign 1 136 291
toString 0 136 291
assign 1 136 292
add 1 136 292
assign 1 136 293
new 2 136 293
throw 1 136 294
assign 1 141 301
ptyListGet 0 141 301
assign 1 141 302
iteratorGet 0 141 302
assign 1 141 305
hasNextGet 0 141 305
assign 1 142 307
nextGet 0 142 307
assign 1 143 308
memSynGet 0 143 308
assign 1 143 309
isTypedGet 0 143 309
assign 1 144 311
heldGet 0 144 311
assign 1 144 312
memSynGet 0 144 312
assign 1 144 313
namepathGet 0 144 313
addUsed 1 144 314
assign 1 148 321
heldGet 0 148 321
assign 1 148 322
orderedMethodsGet 0 148 322
assign 1 148 323
iteratorGet 0 148 323
assign 1 148 326
hasNextGet 0 148 326
assign 1 149 328
nextGet 0 149 328
assign 1 150 329
mtdMapGet 0 150 329
assign 1 150 330
heldGet 0 150 330
assign 1 150 331
nameGet 0 150 331
assign 1 150 332
get 1 150 332
assign 1 151 333
def 1 151 338
assign 1 152 339
rsynGet 0 152 339
assign 1 152 340
def 1 152 345
assign 1 153 346
heldGet 0 153 346
assign 1 153 347
rtypeGet 0 153 347
assign 1 153 348
undef 1 153 353
assign 1 154 354
new 0 154 354
assign 1 154 355
heldGet 0 154 355
assign 1 154 356
nameGet 0 154 356
assign 1 154 357
add 1 154 357
assign 1 154 358
new 0 154 358
assign 1 154 359
add 1 154 359
assign 1 154 360
heldGet 0 154 360
assign 1 154 361
nameGet 0 154 361
assign 1 154 362
add 1 154 362
assign 1 154 363
new 2 154 363
throw 1 154 364
loadClass 1 159 373
assign 1 160 374
depthGet 0 160 374
assign 1 160 375
new 0 160 375
assign 1 160 376
add 1 160 376
assign 1 164 381
has 1 164 381
return 1 164 382
return 1 168 450
assign 1 169 452
new 0 169 452
assign 1 170 453
new 0 170 453
assign 1 171 454
new 0 171 454
assign 1 172 455
new 0 172 455
assign 1 173 456
undef 1 173 461
assign 1 174 462
new 0 174 462
assign 1 175 463
sizeGet 0 175 463
assign 1 176 464
sizeGet 0 176 464
assign 1 177 465
assign 1 178 466
iteratorGet 0 0 466
assign 1 178 469
hasNextGet 0 178 469
assign 1 178 471
nextGet 0 178 471
assign 1 179 472
emitDataGet 0 179 472
assign 1 179 473
methodIndexesGet 0 179 473
assign 1 179 474
new 2 179 474
put 1 179 475
return 1 181 481
assign 1 183 483
getSynNp 1 183 483
assign 1 184 484
new 0 184 484
assign 1 185 485
new 0 185 485
assign 1 187 486
sizeGet 0 187 486
assign 1 187 487
ptyListGet 0 187 487
assign 1 187 488
sizeGet 0 187 488
assign 1 187 489
subtract 1 187 489
assign 1 188 490
libNameGet 0 188 490
assign 1 188 491
equals 1 188 491
integrate 1 188 493
assign 1 189 495
isFinalGet 0 189 495
assign 1 190 497
new 0 190 497
assign 1 190 498
toString 0 190 498
assign 1 190 499
add 1 190 499
assign 1 190 500
new 1 190 500
throw 1 190 501
assign 1 192 503
isLocalGet 0 192 503
assign 1 192 505
libNameGet 0 192 505
assign 1 192 506
notEquals 1 192 506
assign 1 0 508
assign 1 0 511
assign 1 0 515
assign 1 193 518
new 0 193 518
assign 1 193 519
toString 0 193 519
assign 1 193 520
add 1 193 520
assign 1 193 521
new 1 193 521
throw 1 193 522
assign 1 195 524
isLocalGet 0 195 524
assign 1 195 526
not 0 195 531
assign 1 0 532
assign 1 0 535
assign 1 0 539
assign 1 195 542
not 0 195 547
assign 1 0 548
assign 1 0 551
assign 1 0 555
assign 1 196 558
new 0 196 558
assign 1 196 559
toString 0 196 559
assign 1 196 560
add 1 196 560
assign 1 196 561
new 1 196 561
throw 1 196 562
assign 1 198 564
linkedListIteratorGet 0 0 564
assign 1 198 567
hasNextGet 0 198 567
assign 1 198 569
nextGet 0 198 569
assign 1 199 570
getSynNp 1 199 570
assign 1 200 571
closeLibrariesGet 0 200 571
assign 1 200 572
libNameGet 0 200 572
assign 1 200 573
has 1 200 573
assign 1 200 574
not 0 200 579
assign 1 200 580
toString 0 200 580
assign 1 200 581
new 0 200 581
assign 1 200 582
notEquals 1 200 582
assign 1 0 584
assign 1 0 587
assign 1 0 591
assign 1 202 594
new 0 202 594
assign 1 203 595
new 0 203 595
assign 1 205 597
closeLibrariesGet 0 205 597
assign 1 205 598
libNameGet 0 205 598
assign 1 205 599
has 1 205 599
assign 1 205 600
not 0 205 605
assign 1 206 606
new 0 206 606
assign 1 210 613
valueIteratorGet 0 210 613
assign 1 210 616
hasNextGet 0 210 616
assign 1 211 618
nextGet 0 211 618
assign 1 212 619
mtdMapGet 0 212 619
assign 1 212 620
nameGet 0 212 620
assign 1 212 621
get 1 212 621
assign 1 213 622
def 1 213 627
assign 1 214 628
notEquals 1 214 628
assign 1 215 630
new 0 215 630
lastDefSet 1 215 631
assign 1 216 632
new 0 216 632
isOverrideSet 1 216 633
assign 1 217 634
increment 0 217 634
assign 1 220 638
new 0 220 638
isOverrideSet 1 220 639
assign 1 221 640
increment 0 221 640
assign 1 222 641
increment 0 222 641
assign 1 223 642
emitDataGet 0 223 642
assign 1 223 643
methodIndexesGet 0 223 643
assign 1 223 644
new 2 223 644
put 1 223 645
return 1 230 746
assign 1 231 748
new 0 231 748
assign 1 232 749
undef 1 232 754
return 1 232 755
assign 1 233 757
getSynNp 1 233 757
assign 1 234 758
heldGet 0 234 758
assign 1 234 759
orderedVarsGet 0 234 759
assign 1 234 760
iteratorGet 0 234 760
assign 1 234 763
hasNextGet 0 234 763
assign 1 235 765
nextGet 0 235 765
assign 1 236 766
ptyMapGet 0 236 766
assign 1 236 767
heldGet 0 236 767
assign 1 236 768
nameGet 0 236 768
assign 1 236 769
get 1 236 769
assign 1 237 770
def 1 237 775
assign 1 238 776
heldGet 0 238 776
assign 1 238 777
isDeclaredGet 0 238 777
assign 1 239 779
new 0 239 779
assign 1 239 780
heldGet 0 239 780
assign 1 239 781
nameGet 0 239 781
assign 1 239 782
add 1 239 782
assign 1 239 783
new 0 239 783
assign 1 239 784
add 1 239 784
assign 1 239 785
heldGet 0 239 785
assign 1 239 786
namepathGet 0 239 786
assign 1 239 787
toString 0 239 787
assign 1 239 788
add 1 239 788
assign 1 239 789
new 1 239 789
throw 1 239 790
assign 1 241 793
heldGet 0 241 793
assign 1 241 794
memSynGet 0 241 794
assign 1 241 795
isTypedGet 0 241 795
isTypedSet 1 241 796
assign 1 242 797
heldGet 0 242 797
assign 1 242 798
memSynGet 0 242 798
assign 1 242 799
namepathGet 0 242 799
namepathSet 1 242 800
assign 1 246 808
heldGet 0 246 808
assign 1 246 809
orderedMethodsGet 0 246 809
assign 1 246 810
iteratorGet 0 246 810
assign 1 246 813
hasNextGet 0 246 813
assign 1 247 815
nextGet 0 247 815
assign 1 248 816
mtdMapGet 0 248 816
assign 1 248 817
heldGet 0 248 817
assign 1 248 818
nameGet 0 248 818
assign 1 248 819
get 1 248 819
assign 1 249 820
def 1 249 825
assign 1 250 826
isFinalGet 0 250 826
assign 1 251 828
new 0 251 828
assign 1 251 829
heldGet 0 251 829
assign 1 251 830
nameGet 0 251 830
assign 1 251 831
add 1 251 831
assign 1 251 832
new 0 251 832
assign 1 251 833
add 1 251 833
assign 1 251 834
heldGet 0 251 834
assign 1 251 835
namepathGet 0 251 835
assign 1 251 836
toString 0 251 836
assign 1 251 837
add 1 251 837
assign 1 251 838
new 2 251 838
throw 1 251 839
assign 1 253 841
containedGet 0 253 841
assign 1 253 842
firstGet 0 253 842
assign 1 253 843
containedGet 0 253 843
assign 1 254 844
new 0 254 844
assign 1 254 847
argSynsGet 0 254 847
assign 1 254 848
lengthGet 0 254 848
assign 1 254 849
lesser 1 254 849
assign 1 255 851
argSynsGet 0 255 851
assign 1 255 852
get 1 255 852
assign 1 256 853
get 1 256 853
assign 1 256 854
heldGet 0 256 854
checkTypes 5 258 855
assign 1 254 856
increment 0 254 856
assign 1 260 862
rsynGet 0 260 862
assign 1 261 863
heldGet 0 261 863
assign 1 261 864
rtypeGet 0 261 864
assign 1 262 865
undef 1 262 870
assign 1 0 871
assign 1 262 874
undef 1 262 879
assign 1 0 880
assign 1 0 883
assign 1 263 887
undef 1 263 892
assign 1 263 892
not 0 263 897
assign 1 0 898
assign 1 263 901
undef 1 263 906
assign 1 263 906
not 0 263 911
assign 1 0 912
assign 1 0 915
assign 1 268 919
new 0 268 919
assign 1 268 920
heldGet 0 268 920
assign 1 268 921
namepathGet 0 268 921
assign 1 268 922
toString 0 268 922
assign 1 268 923
add 1 268 923
assign 1 268 924
new 2 268 924
throw 1 268 925
assign 1 272 929
isThisGet 0 272 929
assign 1 272 931
isThisGet 0 272 931
assign 1 272 932
isThisGet 0 272 932
assign 1 272 933
notEquals 1 272 933
assign 1 0 935
assign 1 0 938
assign 1 0 942
assign 1 273 945
new 0 273 945
assign 1 273 946
heldGet 0 273 946
assign 1 273 947
namepathGet 0 273 947
assign 1 273 948
toString 0 273 948
assign 1 273 949
add 1 273 949
assign 1 273 950
new 2 273 950
throw 1 273 951
checkTypes 5 275 953
assign 1 282 989
isTypedGet 0 282 989
assign 1 282 990
isTypedGet 0 282 990
assign 1 282 991
notEquals 1 282 991
assign 1 283 993
new 0 283 993
assign 1 283 994
heldGet 0 283 994
assign 1 283 995
namepathGet 0 283 995
assign 1 283 996
toString 0 283 996
assign 1 283 997
add 1 283 997
assign 1 283 998
new 2 283 998
throw 1 283 999
assign 1 284 1002
isTypedGet 0 284 1002
assign 1 287 1004
isSelfGet 0 287 1004
assign 1 287 1006
isSelfGet 0 287 1006
assign 1 0 1008
assign 1 0 1011
assign 1 0 1015
return 1 288 1018
assign 1 290 1020
namepathGet 0 290 1020
assign 1 290 1021
getSynNp 1 290 1021
assign 1 291 1022
allTypesGet 0 291 1022
assign 1 291 1023
namepathGet 0 291 1023
assign 1 291 1024
has 1 291 1024
assign 1 291 1025
not 0 291 1025
assign 1 292 1027
new 0 292 1027
assign 1 292 1028
heldGet 0 292 1028
assign 1 292 1029
namepathGet 0 292 1029
assign 1 292 1030
toString 0 292 1030
assign 1 292 1031
add 1 292 1031
assign 1 292 1032
new 2 292 1032
throw 1 292 1033
new 0 298 1059
assign 1 299 1060
heldGet 0 299 1060
assign 1 299 1061
orderedVarsGet 0 299 1061
assign 1 299 1062
iteratorGet 0 299 1062
assign 1 299 1065
hasNextGet 0 299 1065
assign 1 300 1067
nextGet 0 300 1067
assign 1 301 1068
heldGet 0 301 1068
assign 1 301 1069
isDeclaredGet 0 301 1069
assign 1 301 1070
not 0 301 1070
assign 1 302 1072
new 0 302 1072
assign 1 302 1073
heldGet 0 302 1073
assign 1 302 1074
nameGet 0 302 1074
assign 1 302 1075
add 1 302 1075
assign 1 302 1076
new 0 302 1076
assign 1 302 1077
add 1 302 1077
assign 1 302 1078
heldGet 0 302 1078
assign 1 302 1079
namepathGet 0 302 1079
assign 1 302 1080
toString 0 302 1080
assign 1 302 1081
add 1 302 1081
assign 1 302 1082
new 2 302 1082
throw 1 302 1083
loadClass 1 305 1090
assign 1 306 1091
new 0 306 1091
assign 1 311 1119
heldGet 0 311 1119
assign 1 311 1120
fromFileGet 0 311 1120
assign 1 312 1121
heldGet 0 312 1121
assign 1 312 1122
namepathGet 0 312 1122
assign 1 313 1123
heldGet 0 313 1123
assign 1 313 1124
libNameGet 0 313 1124
assign 1 314 1125
heldGet 0 314 1125
assign 1 314 1126
isFinalGet 0 314 1126
assign 1 315 1127
heldGet 0 315 1127
assign 1 315 1128
isLocalGet 0 315 1128
assign 1 316 1129
heldGet 0 316 1129
assign 1 316 1130
isNotNullGet 0 316 1130
assign 1 317 1131
heldGet 0 317 1131
assign 1 317 1132
usedGet 0 317 1132
assign 1 317 1133
iteratorGet 0 317 1133
assign 1 317 1136
hasNextGet 0 317 1136
assign 1 318 1138
nextGet 0 318 1138
assign 1 319 1139
toString 0 319 1139
put 1 319 1140
assign 1 321 1146
heldGet 0 321 1146
assign 1 321 1147
orderedVarsGet 0 321 1147
assign 1 321 1148
iteratorGet 0 321 1148
assign 1 321 1151
hasNextGet 0 321 1151
assign 1 322 1153
nextGet 0 322 1153
assign 1 323 1154
new 2 323 1154
addValue 1 324 1155
assign 1 326 1161
heldGet 0 326 1161
assign 1 326 1162
orderedMethodsGet 0 326 1162
assign 1 326 1163
iteratorGet 0 326 1163
assign 1 326 1166
hasNextGet 0 326 1166
assign 1 327 1168
nextGet 0 327 1168
assign 1 328 1169
new 2 328 1169
addValue 1 329 1170
postLoad 0 331 1176
assign 1 335 1227
new 0 335 1227
assign 1 336 1228
new 0 336 1228
assign 1 339 1229
iteratorGet 0 339 1229
assign 1 339 1232
hasNextGet 0 339 1232
assign 1 340 1234
nextGet 0 340 1234
assign 1 341 1235
nameGet 0 341 1235
assign 1 341 1236
has 1 341 1236
assign 1 341 1237
not 0 341 1242
assign 1 343 1243
nameGet 0 343 1243
put 2 343 1244
assign 1 347 1251
new 0 347 1251
assign 1 348 1252
new 0 348 1252
assign 1 349 1253
iteratorGet 0 349 1253
assign 1 349 1256
hasNextGet 0 349 1256
assign 1 350 1258
nextGet 0 350 1258
assign 1 351 1259
nameGet 0 351 1259
assign 1 351 1260
has 1 351 1260
assign 1 351 1261
not 0 351 1266
assign 1 352 1267
nameGet 0 352 1267
assign 1 352 1268
get 1 352 1268
mposSet 1 353 1269
assign 1 354 1270
new 0 354 1270
assign 1 354 1271
add 1 354 1271
addValue 1 355 1272
assign 1 356 1273
nameGet 0 356 1273
assign 1 356 1274
nameGet 0 356 1274
put 2 356 1275
assign 1 359 1282
assign 1 361 1283
new 0 361 1283
assign 1 363 1284
iteratorGet 0 363 1284
assign 1 363 1287
hasNextGet 0 363 1287
assign 1 364 1289
nextGet 0 364 1289
assign 1 366 1290
nameGet 0 366 1290
put 2 366 1291
assign 1 368 1292
nameGet 0 368 1292
assign 1 368 1293
has 1 368 1293
assign 1 368 1294
not 0 368 1299
assign 1 369 1300
nameGet 0 369 1300
put 2 369 1301
assign 1 373 1308
new 0 373 1308
assign 1 374 1309
new 0 374 1309
assign 1 375 1310
iteratorGet 0 375 1310
assign 1 375 1313
hasNextGet 0 375 1313
assign 1 376 1315
nextGet 0 376 1315
assign 1 377 1316
nameGet 0 377 1316
assign 1 377 1317
has 1 377 1317
assign 1 377 1318
not 0 377 1323
assign 1 378 1324
nameGet 0 378 1324
assign 1 378 1325
get 1 378 1325
assign 1 387 1326
nameGet 0 387 1326
assign 1 387 1327
get 1 387 1327
assign 1 388 1328
declarationGet 0 388 1328
assign 1 388 1329
undef 1 388 1334
assign 1 389 1335
originGet 0 389 1335
declarationSet 1 389 1336
assign 1 391 1338
declarationGet 0 391 1338
declarationSet 1 391 1339
mtdxSet 1 392 1340
assign 1 393 1341
increment 0 393 1341
addValue 1 394 1342
assign 1 395 1343
nameGet 0 395 1343
assign 1 395 1344
nameGet 0 395 1344
put 2 395 1345
assign 1 398 1352
assign 1 400 1353
linkedListIteratorGet 0 0 1353
assign 1 400 1356
hasNextGet 0 400 1356
assign 1 400 1358
nextGet 0 400 1358
put 2 401 1359
assign 1 402 1360
put 2 405 1366
return 1 0 1370
return 1 0 1373
assign 1 0 1376
assign 1 0 1380
return 1 0 1384
return 1 0 1387
assign 1 0 1390
assign 1 0 1394
return 1 0 1398
return 1 0 1401
assign 1 0 1404
assign 1 0 1408
return 1 0 1412
return 1 0 1415
assign 1 0 1418
assign 1 0 1422
return 1 0 1426
return 1 0 1429
assign 1 0 1432
assign 1 0 1436
return 1 0 1440
return 1 0 1443
assign 1 0 1446
assign 1 0 1450
return 1 0 1454
return 1 0 1457
assign 1 0 1460
assign 1 0 1464
return 1 0 1468
return 1 0 1471
assign 1 0 1474
assign 1 0 1478
return 1 0 1482
return 1 0 1485
assign 1 0 1488
assign 1 0 1492
return 1 0 1496
return 1 0 1499
assign 1 0 1502
assign 1 0 1506
return 1 0 1510
return 1 0 1513
assign 1 0 1516
assign 1 0 1520
return 1 0 1524
return 1 0 1527
assign 1 0 1530
assign 1 0 1534
return 1 0 1538
return 1 0 1541
assign 1 0 1544
assign 1 0 1548
return 1 0 1552
return 1 0 1555
assign 1 0 1558
assign 1 0 1562
return 1 0 1566
return 1 0 1569
assign 1 0 1572
assign 1 0 1576
return 1 0 1580
return 1 0 1583
assign 1 0 1586
assign 1 0 1590
return 1 0 1594
return 1 0 1597
assign 1 0 1600
assign 1 0 1604
return 1 0 1608
return 1 0 1611
assign 1 0 1614
assign 1 0 1618
return 1 0 1622
return 1 0 1625
assign 1 0 1628
assign 1 0 1632
return 1 0 1636
return 1 0 1639
assign 1 0 1642
assign 1 0 1646
return 1 0 1650
return 1 0 1653
assign 1 0 1656
assign 1 0 1660
return 1 0 1664
return 1 0 1667
assign 1 0 1670
assign 1 0 1674
return 1 0 1678
return 1 0 1681
assign 1 0 1684
assign 1 0 1688
return 1 0 1692
return 1 0 1695
assign 1 0 1698
assign 1 0 1702
return 1 0 1706
return 1 0 1709
assign 1 0 1712
assign 1 0 1716
return 1 0 1720
return 1 0 1723
assign 1 0 1726
assign 1 0 1730
return 1 0 1734
return 1 0 1737
assign 1 0 1740
assign 1 0 1744
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 833786164: return bem_create_0();
case -713590185: return bem_mtdListGetDirect_0();
case 1958822494: return bem_defMtdsGetDirect_0();
case -1762451596: return bem_print_0();
case -1065524441: return bem_iCheckedGet_0();
case -2127487000: return bem_signatureCheckedGet_0();
case 582153509: return bem_libNameGet_0();
case 805258403: return bem_allAncestorsCloseGet_0();
case -331581779: return bem_allAncestorsCloseGetDirect_0();
case 144921627: return bem_isNotNullGetDirect_0();
case 918246902: return bem_fieldIteratorGet_0();
case 1500504504: return bem_new_0();
case 227163298: return bem_ptyListGet_0();
case -1751483425: return bem_usesGet_0();
case 212273782: return bem_hashGet_0();
case -1883066593: return bem_defMtdsGet_0();
case -1100214586: return bem_ptyMapGetDirect_0();
case -916882185: return bem_namepathGetDirect_0();
case -677806483: return bem_toAny_0();
case 1212853878: return bem_foreignClassesGet_0();
case -572013032: return bem_isLocalGet_0();
case -794157194: return bem_isFinalGetDirect_0();
case 955242221: return bem_mtdListGet_0();
case -1446374280: return bem_superNpGet_0();
case -677670296: return bem_allNamesGet_0();
case 1311565177: return bem_newMbrsGetDirect_0();
case -478536194: return bem_signatureChangedGet_0();
case -1263963508: return bem_isFinalGet_0();
case 942168519: return bem_serializationIteratorGet_0();
case -2097568812: return bem_foreignClassesGetDirect_0();
case 1905029126: return bem_signatureCheckedGetDirect_0();
case 1007076121: return bem_depthGetDirect_0();
case 664995964: return bem_many_0();
case 1754266436: return bem_fromFileGet_0();
case -1975530495: return bem_newMtdsGet_0();
case -1284976174: return bem_depthGet_0();
case 1543973012: return bem_superNpGetDirect_0();
case -2132129762: return bem_usesGetDirect_0();
case -1012843800: return bem_directPropertiesGet_0();
case -296810667: return bem_copy_0();
case 912896996: return bem_sourceFileNameGet_0();
case -844998411: return bem_fieldNamesGet_0();
case -753304415: return bem_allTypesGet_0();
case 1958971730: return bem_postLoad_0();
case 1829193407: return bem_allTypesGetDirect_0();
case -1468375282: return bem_namepathGet_0();
case -1379435095: return bem_directMethodsGetDirect_0();
case 2045377383: return bem_classNameGet_0();
case 65167261: return bem_hasDefaultGet_0();
case -172593300: return bem_ptyListGetDirect_0();
case -362800444: return bem_allNamesGetDirect_0();
case -1599008676: return bem_serializeToString_0();
case -2973582: return bem_superListGetDirect_0();
case 536183275: return bem_tagGet_0();
case -1384043882: return bem_superListGet_0();
case -1065178102: return bem_deserializeClassNameGet_0();
case 1540192904: return bem_once_0();
case 1545182183: return bem_directMethodsGet_0();
case 745321063: return bem_isLocalGetDirect_0();
case 1173886720: return bem_signatureChangedGetDirect_0();
case -119984388: return bem_mtdMapGet_0();
case -2050938340: return bem_iteratorGet_0();
case -163001642: return bem_serializeContents_0();
case -698197029: return bem_fromFileGetDirect_0();
case -1737970926: return bem_toString_0();
case 1922546743: return bem_newMtdsGetDirect_0();
case 1030934483: return bem_iCheckedGetDirect_0();
case -1429529270: return bem_integratedGetDirect_0();
case 1012036029: return bem_isNotNullGet_0();
case -138609735: return bem_libNameGetDirect_0();
case 1443041557: return bem_echo_0();
case -524180885: return bem_integratedGet_0();
case 209300568: return bem_newMbrsGet_0();
case 304908009: return bem_directPropertiesGetDirect_0();
case 684784381: return bem_maxMtdxGet_0();
case -765757544: return bem_ptyMapGet_0();
case 1832551206: return bem_mtdMapGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -119025421: return bem_allNamesSet_1(bevd_0);
case 452658451: return bem_isFinalSet_1(bevd_0);
case -273450264: return bem_allAncestorsCloseSet_1(bevd_0);
case -1393770274: return bem_libNameSetDirect_1(bevd_0);
case 891495205: return bem_fromFileSetDirect_1(bevd_0);
case 663445287: return bem_depthSetDirect_1(bevd_0);
case -653746224: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -236948784: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -620116274: return bem_directPropertiesSet_1(bevd_0);
case -1925373753: return bem_mtdListSetDirect_1(bevd_0);
case -957845823: return bem_ptyMapSetDirect_1(bevd_0);
case -584766015: return bem_signatureCheckedSetDirect_1(bevd_0);
case 686373188: return bem_isNotNullSetDirect_1(bevd_0);
case -785982807: return bem_new_1(bevd_0);
case -1424462703: return bem_notEquals_1(bevd_0);
case -1783313008: return bem_directPropertiesSetDirect_1(bevd_0);
case -1663771515: return bem_namepathSetDirect_1(bevd_0);
case 444898705: return bem_superListSet_1(bevd_0);
case -113679506: return bem_superListSetDirect_1(bevd_0);
case -1142778017: return bem_defined_1(bevd_0);
case -335945636: return bem_ptyMapSet_1(bevd_0);
case -476342963: return bem_signatureCheckedSet_1(bevd_0);
case 595968186: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 169168317: return bem_signatureChangedSetDirect_1(bevd_0);
case 282110399: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1091261379: return bem_foreignClassesSetDirect_1(bevd_0);
case -742539479: return bem_newMtdsSet_1(bevd_0);
case -34903537: return bem_newMtdsSetDirect_1(bevd_0);
case -268123649: return bem_iCheckedSet_1(bevd_0);
case 1999927566: return bem_undef_1(bevd_0);
case 1103051023: return bem_usesSet_1(bevd_0);
case 554252823: return bem_directMethodsSet_1(bevd_0);
case 658098740: return bem_undefined_1(bevd_0);
case -850057288: return bem_copyTo_1(bevd_0);
case -1540202831: return bem_isLocalSetDirect_1(bevd_0);
case 56582738: return bem_signatureChangedSet_1(bevd_0);
case -896840024: return bem_def_1(bevd_0);
case 1244942171: return bem_iCheckedSetDirect_1(bevd_0);
case -1460783217: return bem_integratedSet_1(bevd_0);
case 1787986549: return bem_allNamesSetDirect_1(bevd_0);
case -1645248382: return bem_isFinalSetDirect_1(bevd_0);
case -1642334600: return bem_newMbrsSetDirect_1(bevd_0);
case 874995097: return bem_mtdMapSetDirect_1(bevd_0);
case 391100574: return bem_allTypesSetDirect_1(bevd_0);
case 847539874: return bem_mtdMapSet_1(bevd_0);
case 860343971: return bem_otherClass_1(bevd_0);
case -112979367: return bem_superNpSet_1(bevd_0);
case -1702116519: return bem_depthSet_1(bevd_0);
case 1093687723: return bem_superNpSetDirect_1(bevd_0);
case -1801189299: return bem_defMtdsSetDirect_1(bevd_0);
case 1236401364: return bem_mtdListSet_1(bevd_0);
case -1528654552: return bem_fromFileSet_1(bevd_0);
case -995436768: return bem_defMtdsSet_1(bevd_0);
case -405819372: return bem_usesSetDirect_1(bevd_0);
case 13395974: return bem_allAncestorsCloseSetDirect_1(bevd_0);
case 598878525: return bem_sameClass_1(bevd_0);
case 1329377857: return bem_sameObject_1(bevd_0);
case 64329032: return bem_newMbrsSet_1(bevd_0);
case 157742408: return bem_foreignClassesSet_1(bevd_0);
case -670225751: return bem_loadClass_1(bevd_0);
case 657678955: return bem_integratedSetDirect_1(bevd_0);
case -640645514: return bem_ptyListSetDirect_1(bevd_0);
case -321109132: return bem_libNameSet_1(bevd_0);
case 873957775: return bem_sameType_1(bevd_0);
case 1871977633: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 2138290092: return bem_allTypesSet_1(bevd_0);
case 1686430384: return bem_otherType_1(bevd_0);
case 723799991: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1661713084: return bem_directMethodsSetDirect_1(bevd_0);
case -650068928: return bem_equals_1(bevd_0);
case 1730806218: return bem_isLocalSet_1(bevd_0);
case 1902342102: return bem_isNotNullSet_1(bevd_0);
case -1090388709: return bem_ptyListSet_1(bevd_0);
case -1586463740: return bem_namepathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2038560265: return bem_new_2(bevd_0, bevd_1);
case 348982157: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 422466535: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1266547135: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450087500: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1218154238: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1431615808: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1692908225: return bem_checkInheritance_2(bevd_0, bevd_1);
case 1528949086: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -2051016232: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildClassSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_8_BuildClassSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildClassSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst = (BEC_2_5_8_BuildClassSyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_type;
}
}
}
