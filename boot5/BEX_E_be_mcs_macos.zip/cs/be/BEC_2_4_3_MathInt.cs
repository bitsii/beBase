namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_3_MathInt : BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }
static BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_0, 39));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_20 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_21 = (new BEC_2_4_3_MathInt(43));
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_1, 21));
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_25 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_26 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_27 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_29 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_30 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_31 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_32 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_33 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_34 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_35 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_36 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_38 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static new BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 83 */
bevt_9_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevl_max0 = (BEC_2_4_3_MathInt) beva_radix.bem_copy_0();
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_max0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
} /* Line: 88 */
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_12;
bevt_13_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_14;
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 102 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 102 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 106 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 106 */ {
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 109 */
 else  /* Line: 106 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 110 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 113 */
 else  /* Line: 106 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 114 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 114 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 114 */ {
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 117 */
 else  /* Line: 106 */ {
bevt_20_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 120 */
 else  /* Line: 106 */ {
bevt_23_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_21;
if (bevl_ic.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 121 */ {
} /* Line: 121 */
 else  /* Line: 123 */ {
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_22;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(beva_str);
bevt_29_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_23;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevl_ic);
bevt_24_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 124 */
} /* Line: 106 */
} /* Line: 106 */
} /* Line: 106 */
} /* Line: 106 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 127 */
 else  /* Line: 102 */ {
break;
} /* Line: 102 */
} /* Line: 102 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_24;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_25;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_26;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_27;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_28;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_29;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 200 */ {
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_30;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_31;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 204 */
 else  /* Line: 205 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 206 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 210 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_33;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 217 */
 else  /* Line: 200 */ {
break;
} /* Line: 200 */
} /* Line: 200 */
while (true)
 /* Line: 220 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_34;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 222 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_35;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_36;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 226 */
 else  /* Line: 220 */ {
break;
} /* Line: 220 */
} /* Line: 220 */
bevt_36_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_37;
if (bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 231 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_38;
if (bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 248 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 268 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /* Line: 275 */
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 283 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /* Line: 290 */
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 326 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /* Line: 333 */
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 355 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /* Line: 362 */
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 384 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /* Line: 391 */
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 413 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /* Line: 425 */
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 452 */ {
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /* Line: 459 */
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 600 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 600 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 600 */
 else  /* Line: 600 */ {
break;
} /* Line: 600 */
} /* Line: 600 */
return bevl_result;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int == bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int != bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {63, 63, 66, 70, 74, 74, 74, 74, 74, 74, 74, 74, 74, 78, 78, 78, 78, 78, 78, 78, 78, 78, 82, 82, 82, 0, 82, 82, 82, 0, 0, 83, 83, 83, 83, 85, 85, 85, 86, 88, 90, 90, 91, 91, 91, 91, 92, 92, 92, 92, 93, 97, 97, 98, 98, 99, 100, 101, 102, 102, 102, 104, 106, 106, 106, 106, 106, 0, 0, 0, 107, 107, 108, 109, 110, 110, 110, 110, 110, 0, 0, 0, 111, 111, 112, 113, 114, 114, 114, 114, 114, 0, 0, 0, 115, 115, 116, 117, 118, 118, 118, 120, 120, 121, 121, 121, 124, 124, 124, 124, 124, 124, 124, 126, 127, 132, 132, 136, 140, 140, 144, 155, 173, 177, 177, 177, 177, 177, 177, 177, 177, 181, 181, 181, 181, 185, 185, 185, 185, 185, 185, 189, 189, 189, 189, 189, 193, 193, 193, 193, 197, 198, 199, 200, 200, 200, 201, 202, 203, 203, 203, 204, 204, 206, 209, 209, 209, 209, 210, 210, 210, 210, 212, 212, 213, 213, 213, 213, 217, 220, 220, 220, 221, 221, 221, 221, 222, 222, 222, 222, 224, 224, 224, 224, 225, 225, 225, 225, 230, 230, 230, 231, 231, 233, 233, 237, 238, 239, 243, 243, 243, 247, 247, 247, 248, 248, 264, 269, 275, 284, 290, 308, 322, 327, 333, 351, 356, 362, 380, 385, 391, 409, 414, 425, 448, 453, 459, 477, 481, 492, 506, 510, 521, 535, 539, 550, 564, 568, 579, 593, 598, 600, 600, 600, 601, 600, 603, 635, 635, 664, 664, 685, 685, 706, 706, 727, 727, 748, 748};
public static new int[] bevs_smnlec
 = new int[] {74, 75, 78, 82, 94, 95, 96, 97, 98, 99, 100, 101, 102, 114, 115, 116, 117, 118, 119, 120, 121, 122, 146, 147, 152, 153, 156, 157, 162, 163, 166, 170, 171, 172, 173, 175, 176, 181, 182, 185, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 234, 235, 236, 237, 238, 239, 240, 243, 244, 249, 250, 251, 252, 257, 258, 263, 264, 267, 271, 274, 275, 276, 277, 280, 281, 286, 287, 292, 293, 296, 300, 303, 304, 305, 306, 309, 310, 315, 316, 321, 322, 325, 329, 332, 333, 334, 335, 338, 339, 344, 345, 346, 349, 350, 355, 358, 359, 360, 361, 362, 363, 364, 370, 371, 381, 382, 385, 390, 391, 394, 398, 401, 411, 412, 413, 414, 415, 416, 417, 418, 424, 425, 426, 427, 435, 436, 437, 438, 439, 440, 447, 448, 449, 450, 451, 457, 458, 459, 460, 504, 505, 506, 509, 510, 515, 516, 517, 518, 519, 524, 525, 526, 529, 531, 532, 533, 538, 539, 540, 541, 542, 544, 545, 546, 547, 548, 549, 550, 558, 559, 564, 565, 566, 567, 572, 573, 574, 575, 576, 578, 579, 580, 581, 582, 583, 584, 585, 591, 592, 597, 598, 599, 601, 602, 606, 607, 608, 613, 614, 615, 621, 622, 627, 628, 629, 636, 642, 645, 652, 655, 661, 666, 672, 675, 681, 687, 690, 696, 702, 705, 711, 717, 720, 726, 732, 735, 741, 745, 748, 753, 757, 760, 765, 769, 772, 777, 781, 784, 789, 795, 796, 799, 804, 805, 806, 812, 822, 823, 833, 834, 843, 844, 853, 854, 863, 864, 873, 874};
/* BEGIN LINEINFO 
assign 1 63 74
new 0 63 74
return 1 63 75
setStringValueDec 1 66 78
setStringValueHex 1 70 82
assign 1 74 94
new 0 74 94
assign 1 74 95
once 0 74 95
assign 1 74 96
new 0 74 96
assign 1 74 97
once 0 74 97
assign 1 74 98
new 0 74 98
assign 1 74 99
once 0 74 99
assign 1 74 100
new 0 74 100
assign 1 74 101
once 0 74 101
setStringValue 5 74 102
assign 1 78 114
new 0 78 114
assign 1 78 115
once 0 78 115
assign 1 78 116
new 0 78 116
assign 1 78 117
once 0 78 117
assign 1 78 118
new 0 78 118
assign 1 78 119
once 0 78 119
assign 1 78 120
new 0 78 120
assign 1 78 121
once 0 78 121
setStringValue 5 78 122
assign 1 82 146
new 0 82 146
assign 1 82 147
lesser 1 82 152
assign 1 0 153
assign 1 82 156
new 0 82 156
assign 1 82 157
greater 1 82 162
assign 1 0 163
assign 1 0 166
assign 1 83 170
new 0 83 170
assign 1 83 171
add 1 83 171
assign 1 83 172
new 1 83 172
throw 1 83 173
assign 1 85 175
new 0 85 175
assign 1 85 176
lesser 1 85 181
assign 1 86 182
copy 0 86 182
assign 1 88 185
new 0 88 185
assign 1 90 187
new 0 90 187
addValue 1 90 188
assign 1 91 189
new 0 91 189
assign 1 91 190
new 0 91 190
assign 1 91 191
subtract 1 91 191
assign 1 91 192
add 1 91 192
assign 1 92 193
new 0 92 193
assign 1 92 194
new 0 92 194
assign 1 92 195
subtract 1 92 195
assign 1 92 196
add 1 92 196
setStringValue 5 93 197
assign 1 97 234
new 0 97 234
setValue 1 97 235
assign 1 98 236
sizeGet 0 98 236
assign 1 98 237
copy 0 98 237
decrementValue 0 99 238
assign 1 100 239
new 0 100 239
assign 1 101 240
new 0 101 240
assign 1 102 243
new 0 102 243
assign 1 102 244
greaterEquals 1 102 249
getInt 2 104 250
assign 1 106 251
new 0 106 251
assign 1 106 252
greater 1 106 257
assign 1 106 258
lesser 1 106 263
assign 1 0 264
assign 1 0 267
assign 1 0 271
assign 1 107 274
new 0 107 274
subtractValue 1 107 275
multiplyValue 1 108 276
addValue 1 109 277
assign 1 110 280
new 0 110 280
assign 1 110 281
greater 1 110 286
assign 1 110 287
lesser 1 110 292
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 111 303
new 0 111 303
subtractValue 1 111 304
multiplyValue 1 112 305
addValue 1 113 306
assign 1 114 309
new 0 114 309
assign 1 114 310
greater 1 114 315
assign 1 114 316
lesser 1 114 321
assign 1 0 322
assign 1 0 325
assign 1 0 329
assign 1 115 332
new 0 115 332
subtractValue 1 115 333
multiplyValue 1 116 334
addValue 1 117 335
assign 1 118 338
new 0 118 338
assign 1 118 339
equals 1 118 344
assign 1 120 345
new 0 120 345
multiplyValue 1 120 346
assign 1 121 349
new 0 121 349
assign 1 121 350
equals 1 121 355
assign 1 124 358
new 0 124 358
assign 1 124 359
add 1 124 359
assign 1 124 360
new 0 124 360
assign 1 124 361
add 1 124 361
assign 1 124 362
add 1 124 362
assign 1 124 363
new 1 124 363
throw 1 124 364
decrementValue 0 126 370
multiplyValue 1 127 371
assign 1 132 381
toString 0 132 381
return 1 132 382
new 1 136 385
assign 1 140 390
new 0 140 390
return 1 140 391
return 1 144 394
assign 1 155 398
new 0 155 398
return 1 173 401
assign 1 177 411
new 0 177 411
assign 1 177 412
new 1 177 412
assign 1 177 413
new 0 177 413
assign 1 177 414
once 0 177 414
assign 1 177 415
new 0 177 415
assign 1 177 416
once 0 177 416
assign 1 177 417
toString 4 177 417
return 1 177 418
assign 1 181 424
new 0 181 424
assign 1 181 425
new 1 181 425
assign 1 181 426
toHexString 1 181 426
return 1 181 427
assign 1 185 435
new 0 185 435
assign 1 185 436
once 0 185 436
assign 1 185 437
new 0 185 437
assign 1 185 438
once 0 185 438
assign 1 185 439
toString 3 185 439
return 1 185 440
assign 1 189 447
new 1 189 447
assign 1 189 448
new 0 189 448
assign 1 189 449
once 0 189 449
assign 1 189 450
toString 4 189 450
return 1 189 451
assign 1 193 457
new 0 193 457
assign 1 193 458
once 0 193 458
assign 1 193 459
toString 4 193 459
return 1 193 460
clear 0 197 504
assign 1 198 505
abs 0 198 505
assign 1 199 506
new 0 199 506
assign 1 200 509
new 0 200 509
assign 1 200 510
greater 1 200 515
setValue 1 201 516
modulusValue 1 202 517
assign 1 203 518
new 0 203 518
assign 1 203 519
lesser 1 203 524
assign 1 204 525
new 0 204 525
addValue 1 204 526
addValue 1 206 529
assign 1 209 531
capacityGet 0 209 531
assign 1 209 532
sizeGet 0 209 532
assign 1 209 533
lesserEquals 1 209 538
assign 1 210 539
capacityGet 0 210 539
assign 1 210 540
new 0 210 540
assign 1 210 541
add 1 210 541
capacitySet 1 210 542
assign 1 212 544
sizeGet 0 212 544
setIntUnchecked 2 212 545
assign 1 213 546
sizeGet 0 213 546
assign 1 213 547
new 0 213 547
assign 1 213 548
add 1 213 548
sizeSet 1 213 549
divideValue 1 217 550
assign 1 220 558
sizeGet 0 220 558
assign 1 220 559
lesser 1 220 564
assign 1 221 565
capacityGet 0 221 565
assign 1 221 566
sizeGet 0 221 566
assign 1 221 567
lesserEquals 1 221 572
assign 1 222 573
capacityGet 0 222 573
assign 1 222 574
new 0 222 574
assign 1 222 575
add 1 222 575
capacitySet 1 222 576
assign 1 224 578
sizeGet 0 224 578
assign 1 224 579
new 0 224 579
assign 1 224 580
once 0 224 580
setIntUnchecked 2 224 581
assign 1 225 582
sizeGet 0 225 582
assign 1 225 583
new 0 225 583
assign 1 225 584
add 1 225 584
sizeSet 1 225 585
assign 1 230 591
new 0 230 591
assign 1 230 592
lesser 1 230 597
assign 1 231 598
new 0 231 598
addValue 1 231 599
assign 1 233 601
reverseBytes 0 233 601
return 1 233 602
assign 1 237 606
new 0 237 606
setValue 1 238 607
return 1 239 608
assign 1 243 613
copy 0 243 613
assign 1 243 614
absValue 0 243 614
return 1 243 615
assign 1 247 621
new 0 247 621
assign 1 247 622
lesser 1 247 627
assign 1 248 628
new 0 248 628
multiplyValue 1 248 629
return 1 264 636
assign 1 269 642
new 0 269 642
return 1 275 645
assign 1 284 652
new 0 284 652
return 1 290 655
return 1 308 661
return 1 322 666
assign 1 327 672
new 0 327 672
return 1 333 675
return 1 351 681
assign 1 356 687
new 0 356 687
return 1 362 690
return 1 380 696
assign 1 385 702
new 0 385 702
return 1 391 705
return 1 409 711
assign 1 414 717
new 0 414 717
return 1 425 720
return 1 448 726
assign 1 453 732
new 0 453 732
return 1 459 735
return 1 477 741
assign 1 481 745
new 0 481 745
return 1 492 748
return 1 506 753
assign 1 510 757
new 0 510 757
return 1 521 760
return 1 535 765
assign 1 539 769
new 0 539 769
return 1 550 772
return 1 564 777
assign 1 568 781
new 0 568 781
return 1 579 784
return 1 593 789
assign 1 598 795
new 0 598 795
assign 1 600 796
new 0 600 796
assign 1 600 799
lesser 1 600 804
multiplyValue 1 601 805
incrementValue 0 600 806
return 1 603 812
assign 1 635 822
new 0 635 822
return 1 635 823
assign 1 664 833
new 0 664 833
return 1 664 834
assign 1 685 843
new 0 685 843
return 1 685 844
assign 1 706 853
new 0 706 853
return 1 706 854
assign 1 727 863
new 0 727 863
return 1 727 864
assign 1 748 873
new 0 748 873
return 1 748 874
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 104628568: return bem_vintGet_0();
case -1737970926: return bem_toString_0();
case -1545147924: return bem_absValue_0();
case -1762451596: return bem_print_0();
case 1443041557: return bem_echo_0();
case -834268109: return bem_toFloat_0();
case -2050938340: return bem_iteratorGet_0();
case 912896996: return bem_sourceFileNameGet_0();
case -351595247: return bem_decrement_0();
case -163001642: return bem_serializeContents_0();
case 559072918: return bem_abs_0();
case 1540192904: return bem_once_0();
case 664995964: return bem_many_0();
case 212273782: return bem_hashGet_0();
case 942168519: return bem_serializationIteratorGet_0();
case -1599008676: return bem_serializeToString_0();
case -1065178102: return bem_deserializeClassNameGet_0();
case 1500504504: return bem_new_0();
case 536183275: return bem_tagGet_0();
case 833786164: return bem_create_0();
case 1754715319: return bem_vintSet_0();
case -677806483: return bem_toAny_0();
case -1464198292: return bem_incrementValue_0();
case 2045377383: return bem_classNameGet_0();
case -296810667: return bem_copy_0();
case -844998411: return bem_fieldNamesGet_0();
case 10283827: return bem_decrementValue_0();
case -241752018: return bem_toHexString_0();
case 918246902: return bem_fieldIteratorGet_0();
case -1306358749: return bem_increment_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1790779313: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1148684045: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 873957775: return bem_sameType_1(bevd_0);
case -850975864: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2128079792: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case -964208689: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -186797970: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -726363777: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case -653746224: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 723799991: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -710616753: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -236948784: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -54730417: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case -668339329: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1126343006: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case -482721857: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case 1731897047: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 1701293054: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -785982807: return bem_new_1(bevd_0);
case 569595088: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1329377857: return bem_sameObject_1(bevd_0);
case 658098740: return bem_undefined_1(bevd_0);
case 1686430384: return bem_otherType_1(bevd_0);
case 598878525: return bem_sameClass_1(bevd_0);
case -353631769: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case -238423855: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1521910480: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -2072399827: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1142778017: return bem_defined_1(bevd_0);
case -1864654129: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 595968186: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -850057288: return bem_copyTo_1(bevd_0);
case -185566475: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -1424462703: return bem_notEquals_1(bevd_0);
case -258351044: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 1846714864: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case -896840024: return bem_def_1(bevd_0);
case 402413081: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -650068928: return bem_equals_1(bevd_0);
case 860343971: return bem_otherClass_1(bevd_0);
case -2000430043: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 16604950: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case 1015174810: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1999927566: return bem_undef_1(bevd_0);
case -968123651: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 348982157: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 422466535: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1266547135: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450087500: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 690928716: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1218154238: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1431615808: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 154756576: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1528949086: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -2013311017: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1962035659: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 2021336952: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_3_MathInt();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
}
