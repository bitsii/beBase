namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static new BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {91, 91, 95, 96, 97, 98, 99, 100};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 91 14
new 0 91 14
new 1 91 15
assign 1 95 19
new 1 95 19
assign 1 96 20
assign 1 97 21
new 0 97 21
assign 1 98 22
new 0 98 22
assign 1 99 23
new 0 99 23
assign 1 100 24
new 0 100 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 103178011: return bem_keyValueIteratorGet_0();
case 232505134: return bem_slotsGetDirect_0();
case -410316669: return bem_baseNodeGet_0();
case 912896996: return bem_sourceFileNameGet_0();
case 1443041557: return bem_echo_0();
case 764533210: return bem_setIteratorGet_0();
case 1540192904: return bem_once_0();
case 473692470: return bem_notEmptyGet_0();
case -844998411: return bem_fieldNamesGet_0();
case 655696313: return bem_valueIteratorGet_0();
case -1935239124: return bem_nodesGet_0();
case 921776943: return bem_innerPutAddedGet_0();
case -306162920: return bem_innerPutAddedGetDirect_0();
case 400634381: return bem_mapIteratorGet_0();
case 668842843: return bem_relGetDirect_0();
case -1762451596: return bem_print_0();
case -280896789: return bem_multiGetDirect_0();
case -484638650: return bem_multiGet_0();
case -1737970926: return bem_toString_0();
case -1945273283: return bem_sizeGet_0();
case 942168519: return bem_serializationIteratorGet_0();
case 918246902: return bem_fieldIteratorGet_0();
case 1407472849: return bem_keysGet_0();
case 833786164: return bem_create_0();
case -1599008676: return bem_serializeToString_0();
case 212273782: return bem_hashGet_0();
case -1957625964: return bem_moduGetDirect_0();
case -2050938340: return bem_iteratorGet_0();
case 902551562: return bem_keyIteratorGet_0();
case -22328594: return bem_moduGet_0();
case 1831004684: return bem_nodeIteratorGet_0();
case -677806483: return bem_toAny_0();
case 1637585760: return bem_isEmptyGet_0();
case 664995964: return bem_many_0();
case -584610727: return bem_clear_0();
case -1928026181: return bem_valuesGet_0();
case 2045377383: return bem_classNameGet_0();
case -1065178102: return bem_deserializeClassNameGet_0();
case 536183275: return bem_tagGet_0();
case -213958843: return bem_baseNodeGetDirect_0();
case -163001642: return bem_serializeContents_0();
case 695099706: return bem_sizeGetDirect_0();
case 1500504504: return bem_new_0();
case 572388945: return bem_slotsGet_0();
case -956957225: return bem_relGet_0();
case -296810667: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2101493160: return bem_multiSet_1(bevd_0);
case -785982807: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1142778017: return bem_defined_1(bevd_0);
case 595968186: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -850057288: return bem_copyTo_1(bevd_0);
case -668339329: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1090676569: return bem_innerPutAddedSet_1(bevd_0);
case 1966233789: return bem_moduSetDirect_1(bevd_0);
case -106724922: return bem_multiSetDirect_1(bevd_0);
case 658098740: return bem_undefined_1(bevd_0);
case 1329377857: return bem_sameObject_1(bevd_0);
case 860343971: return bem_otherClass_1(bevd_0);
case 1049087982: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1832490927: return bem_baseNodeSet_1(bevd_0);
case -1461198840: return bem_relSet_1(bevd_0);
case -2072399827: return bem_addValue_1(bevd_0);
case -1330995982: return bem_sizeSet_1(bevd_0);
case 1721175775: return bem_has_1(bevd_0);
case -2119465430: return bem_innerPutAddedSetDirect_1(bevd_0);
case 55828418: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2130446874: return bem_get_1(bevd_0);
case 581724896: return bem_moduSet_1(bevd_0);
case 1316871973: return bem_slotsSetDirect_1(bevd_0);
case -896840024: return bem_def_1(bevd_0);
case 1223594119: return bem_relSetDirect_1(bevd_0);
case 1172544492: return bem_sizeSetDirect_1(bevd_0);
case 751013191: return bem_slotsSet_1(bevd_0);
case -653746224: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 873957775: return bem_sameType_1(bevd_0);
case 1999927566: return bem_undef_1(bevd_0);
case -650068928: return bem_equals_1(bevd_0);
case 723799991: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 691959028: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1657131030: return bem_delete_1(bevd_0);
case -2130359573: return bem_put_1(bevd_0);
case 1049744847: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 598878525: return bem_sameClass_1(bevd_0);
case -1445599141: return bem_baseNodeSetDirect_1(bevd_0);
case -1424462703: return bem_notEquals_1(bevd_0);
case 1686430384: return bem_otherType_1(bevd_0);
case -843047196: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -236948784: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1390124400: return bem_put_2(bevd_0, bevd_1);
case 348982157: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 422466535: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1266547135: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450087500: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1218154238: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -612294687: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1431615808: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1528949086: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1548594610: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
}
