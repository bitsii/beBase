namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static new BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {90, 90, 94, 95, 96, 97, 98, 99};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 90 14
new 0 90 14
new 1 90 15
assign 1 94 19
new 1 94 19
assign 1 95 20
assign 1 96 21
new 0 96 21
assign 1 97 22
new 0 97 22
assign 1 98 23
new 0 98 23
assign 1 99 24
new 0 99 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 416676438: return bem_innerPutAddedGetDirect_0();
case -1584105641: return bem_moduGet_0();
case -323904680: return bem_moduGetDirect_0();
case -1719721754: return bem_multiGet_0();
case 64930083: return bem_new_0();
case 1259379161: return bem_sourceFileNameGet_0();
case 870539947: return bem_keyValueIteratorGet_0();
case -1088345537: return bem_sizeGet_0();
case 1409367716: return bem_iteratorGet_0();
case 324558137: return bem_serializationIteratorGet_0();
case 621904783: return bem_many_0();
case 1616298039: return bem_toString_0();
case -2145124906: return bem_fieldNamesGet_0();
case 447398905: return bem_copy_0();
case 138291867: return bem_relGet_0();
case -698592158: return bem_once_0();
case 1444282442: return bem_nodesGet_0();
case 1698440478: return bem_classNameGet_0();
case -1678575421: return bem_sizeGetDirect_0();
case -477793454: return bem_deserializeClassNameGet_0();
case 733429103: return bem_setIteratorGet_0();
case -784827327: return bem_clear_0();
case 265775004: return bem_tagGet_0();
case -1890110568: return bem_keyIteratorGet_0();
case 1580795174: return bem_keysGet_0();
case 964021551: return bem_valueIteratorGet_0();
case -1924670591: return bem_print_0();
case -5068474: return bem_relGetDirect_0();
case 857744439: return bem_serializeToString_0();
case -383409287: return bem_hashGet_0();
case -1195330991: return bem_mapIteratorGet_0();
case 1535490926: return bem_isEmptyGet_0();
case -160890143: return bem_slotsGet_0();
case 1633693281: return bem_multiGetDirect_0();
case 1966612970: return bem_baseNodeGet_0();
case 1621394777: return bem_slotsGetDirect_0();
case -1101876346: return bem_notEmptyGet_0();
case -170352172: return bem_innerPutAddedGet_0();
case 24523401: return bem_create_0();
case 338892103: return bem_serializeContents_0();
case -1160093527: return bem_fieldIteratorGet_0();
case 1685630819: return bem_toAny_0();
case 78842048: return bem_nodeIteratorGet_0();
case 1574541715: return bem_echo_0();
case 253040047: return bem_valuesGet_0();
case -1777317622: return bem_baseNodeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 898565877: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -260729170: return bem_relSetDirect_1(bevd_0);
case -817334654: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -454090959: return bem_defined_1(bevd_0);
case 2048544091: return bem_slotsSet_1(bevd_0);
case 604959651: return bem_otherClass_1(bevd_0);
case -590190796: return bem_baseNodeSet_1(bevd_0);
case -1358770303: return bem_innerPutAddedSet_1(bevd_0);
case -1237963680: return bem_addValue_1(bevd_0);
case 762006166: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -949419177: return bem_relSet_1(bevd_0);
case -1974306504: return bem_get_1(bevd_0);
case 1930701189: return bem_innerPutAddedSetDirect_1(bevd_0);
case 854851905: return bem_sameType_1(bevd_0);
case 1464921499: return bem_def_1(bevd_0);
case -911377735: return bem_put_1(bevd_0);
case -1859292781: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1600268764: return bem_multiSetDirect_1(bevd_0);
case 1582703619: return bem_undef_1(bevd_0);
case -1921243842: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 705502266: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1254208752: return bem_moduSetDirect_1(bevd_0);
case -907096239: return bem_otherType_1(bevd_0);
case -1800477454: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -346349789: return bem_equals_1(bevd_0);
case -1270041233: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1768544084: return bem_notEquals_1(bevd_0);
case -52657747: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1701074814: return bem_multiSet_1(bevd_0);
case 1882195140: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2143817101: return bem_copyTo_1(bevd_0);
case -1877522955: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1932510652: return bem_sameClass_1(bevd_0);
case 1365862161: return bem_sizeSetDirect_1(bevd_0);
case -643594269: return bem_moduSet_1(bevd_0);
case 217915821: return bem_slotsSetDirect_1(bevd_0);
case -1378981491: return bem_sizeSet_1(bevd_0);
case 1821362578: return bem_delete_1(bevd_0);
case -1503448081: return bem_baseNodeSetDirect_1(bevd_0);
case 2116880036: return bem_has_1(bevd_0);
case -968521563: return bem_sameObject_1(bevd_0);
case -685667652: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1030898412: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1425194636: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1465437715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -918533412: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1025227425: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -25244724: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2024613175: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1438061795: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 946142028: return bem_put_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 975302647: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
}
