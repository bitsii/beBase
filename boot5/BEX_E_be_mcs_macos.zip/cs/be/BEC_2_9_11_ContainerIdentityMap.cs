namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {91, 91, 95, 96, 97, 98, 99, 100};
public static new int[] bevs_smnlec
 = new int[] {11, 12, 16, 17, 18, 19, 20, 21};
/* BEGIN LINEINFO 
assign 1 91 11
new 0 91 11
new 1 91 12
assign 1 95 16
new 1 95 16
assign 1 96 17
assign 1 97 18
new 0 97 18
assign 1 98 19
new 0 98 19
assign 1 99 20
new 0 99 20
assign 1 100 21
new 0 100 21
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -349248390: return bem_deserializeClassNameGet_0();
case -633813896: return bem_moduGet_0();
case 1611504589: return bem_new_0();
case -993607120: return bem_fieldIteratorGet_0();
case 1626658769: return bem_innerPutAddedGet_0();
case -2070800854: return bem_nodeIteratorGet_0();
case -386274073: return bem_tagGet_0();
case -68587803: return bem_print_0();
case -1683940834: return bem_create_0();
case -1779073385: return bem_toString_0();
case -762427456: return bem_mapIteratorGet_0();
case 1007010882: return bem_hashGet_0();
case -182529291: return bem_slotsGet_0();
case 1799957068: return bem_relGet_0();
case 1184979340: return bem_keyIteratorGet_0();
case 462697424: return bem_many_0();
case 1936129041: return bem_valuesGet_0();
case -17157588: return bem_sizeGet_0();
case -195593751: return bem_isEmptyGet_0();
case 1113679576: return bem_echo_0();
case 2085421345: return bem_keysGet_0();
case 984657505: return bem_serializationIteratorGet_0();
case 2129397987: return bem_keyValueIteratorGet_0();
case 1467676516: return bem_iteratorGet_0();
case -272786033: return bem_multiGet_0();
case -591406965: return bem_valueIteratorGet_0();
case 1104062927: return bem_setIteratorGet_0();
case 1574115416: return bem_clear_0();
case -2122550555: return bem_baseNodeGet_0();
case -829112796: return bem_sourceFileNameGet_0();
case 967087648: return bem_classNameGet_0();
case 1197173348: return bem_nodesGet_0();
case 1248886449: return bem_notEmptyGet_0();
case -817841652: return bem_toAny_0();
case -1620217339: return bem_serializeContents_0();
case 570560636: return bem_serializeToString_0();
case 32699518: return bem_copy_0();
case -604042750: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -135465033: return bem_relSet_1(bevd_0);
case 186027133: return bem_sameObject_1(bevd_0);
case -439947503: return bem_get_1(bevd_0);
case -1003116355: return bem_undefined_1(bevd_0);
case -1394703037: return bem_notEquals_1(bevd_0);
case -1307418906: return bem_slotsSet_1(bevd_0);
case -1507004932: return bem_addValue_1(bevd_0);
case -1163022531: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1371929547: return bem_baseNodeSet_1(bevd_0);
case -138829346: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 249329745: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1371950595: return bem_sameType_1(bevd_0);
case -1239955085: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 885897434: return bem_sizeSet_1(bevd_0);
case 871077747: return bem_copyTo_1(bevd_0);
case 807492905: return bem_put_1(bevd_0);
case -757590718: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -690797068: return bem_otherClass_1(bevd_0);
case 1017703126: return bem_def_1(bevd_0);
case 442788356: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1974642550: return bem_innerPutAddedSet_1(bevd_0);
case 1412822362: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1270221954: return bem_has_1(bevd_0);
case -1320126626: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -337289143: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1219927083: return bem_equals_1(bevd_0);
case 370802014: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1915157348: return bem_defined_1(bevd_0);
case 768529536: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -261242901: return bem_multiSet_1(bevd_0);
case -1857123920: return bem_otherType_1(bevd_0);
case -497225509: return bem_undef_1(bevd_0);
case -1851250107: return bem_delete_1(bevd_0);
case -1475435649: return bem_moduSet_1(bevd_0);
case 400917403: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 963667386: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 5892141: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -150615069: return bem_put_2(bevd_0, bevd_1);
case -423405168: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1893386943: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -74821886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 194196311: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 980645593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1825045674: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 988107420: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
}
}
