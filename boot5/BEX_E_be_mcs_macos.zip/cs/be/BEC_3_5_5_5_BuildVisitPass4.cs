namespace be {
/* IO:File: source/build/Pass4.be */
public sealed class BEC_3_5_5_5_BuildVisitPass4 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass4() { }
static BEC_3_5_5_5_BuildVisitPass4() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass4_bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static new BEC_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;

public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_6_TextString bevl_nps = null;
BEC_2_5_4_BuildNode bevl_nxn = null;
BEC_2_5_4_BuildNode bevl_nxnn = null;
BEC_2_5_4_BuildNode bevl_first = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_BuildNode bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
/* Line: 20*/ {
bevt_5_ta_ph = beva_node.bem_typenameGet_0();
bevt_6_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_5_ta_ph.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 20*/ {
if (bevl_nnode == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 20*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 20*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 20*/
 else /* Line: 20*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 20*/ {
bevt_9_ta_ph = bevl_nnode.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_COLONGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 20*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 20*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 20*/
 else /* Line: 20*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 20*/ {
if (bevl_nps == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 21*/ {
bevl_nps = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 22*/
bevt_13_ta_ph = beva_node.bem_heldGet_0();
bevt_12_ta_ph = bevl_nps.bem_add_1(bevt_13_ta_ph);
bevt_14_ta_ph = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_ta_ph.bem_add_1(bevt_14_ta_ph);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 26*/ {
bevt_17_ta_ph = bevl_nxn.bem_typenameGet_0();
bevt_18_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_17_ta_ph.bevi_int != bevt_18_ta_ph.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 26*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 26*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 26*/ {
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_3_5_5_5_BuildVisitPass4_bels_0));
bevt_19_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_20_ta_ph, beva_node);
throw new be.BECS_ThrowBack(bevt_19_ta_ph);
} /* Line: 27*/
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 30*/ {
beva_node.bem_delete_0();
} /* Line: 31*/
 else /* Line: 32*/ {
bevl_first = beva_node;
} /* Line: 33*/
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 37*/
 else /* Line: 20*/ {
break;
} /* Line: 20*/
} /* Line: 20*/
if (bevl_first == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_23_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_ta_ph);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_26_ta_ph = beva_node.bem_typenameGet_0();
bevt_27_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_26_ta_ph.bevi_int == bevt_27_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 42*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 42*/
 else /* Line: 42*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 42*/ {
bevt_28_ta_ph = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_ta_ph);
beva_node.bem_delete_0();
} /* Line: 44*/
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_ta_ph = bevl_first.bem_nextDescendGet_0();
return bevt_29_ta_ph;
} /* Line: 48*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 19, 20, 20, 20, 20, 20, 20, 0, 0, 0, 20, 20, 20, 20, 0, 0, 0, 21, 21, 22, 24, 24, 24, 24, 25, 26, 26, 0, 26, 26, 26, 26, 0, 0, 27, 27, 27, 29, 30, 30, 31, 33, 35, 36, 37, 39, 39, 40, 40, 41, 42, 42, 42, 42, 42, 42, 0, 0, 0, 43, 43, 44, 46, 47, 48, 48, 50, 50};
public static new int[] bevs_smnlec
 = new int[] {14, 55, 58, 59, 60, 65, 66, 71, 72, 75, 79, 82, 83, 84, 89, 90, 93, 97, 100, 105, 106, 108, 109, 110, 111, 112, 113, 118, 119, 122, 123, 124, 129, 130, 133, 137, 138, 139, 141, 142, 147, 148, 151, 153, 154, 155, 161, 166, 167, 168, 169, 170, 175, 176, 177, 178, 183, 184, 187, 191, 194, 195, 196, 198, 199, 200, 201, 203, 204};
/* BEGIN LINEINFO 
begin 1 15 14
assign 1 19 55
nextPeerGet 0 19 55
assign 1 20 58
typenameGet 0 20 58
assign 1 20 59
IDGet 0 20 59
assign 1 20 60
equals 1 20 65
assign 1 20 66
def 1 20 71
assign 1 0 72
assign 1 0 75
assign 1 0 79
assign 1 20 82
typenameGet 0 20 82
assign 1 20 83
COLONGet 0 20 83
assign 1 20 84
equals 1 20 89
assign 1 0 90
assign 1 0 93
assign 1 0 97
assign 1 21 100
undef 1 21 105
assign 1 22 106
new 0 22 106
assign 1 24 108
heldGet 0 24 108
assign 1 24 109
add 1 24 109
assign 1 24 110
heldGet 0 24 110
assign 1 24 111
add 1 24 111
assign 1 25 112
nextPeerGet 0 25 112
assign 1 26 113
undef 1 26 118
assign 1 0 119
assign 1 26 122
typenameGet 0 26 122
assign 1 26 123
IDGet 0 26 123
assign 1 26 124
notEquals 1 26 129
assign 1 0 130
assign 1 0 133
assign 1 27 137
new 0 27 137
assign 1 27 138
new 2 27 138
throw 1 27 139
assign 1 29 141
nextPeerGet 0 29 141
assign 1 30 142
def 1 30 147
delete 0 31 148
assign 1 33 151
delete 0 35 153
assign 1 36 154
assign 1 37 155
assign 1 39 161
def 1 39 166
assign 1 40 167
NAMEPATHGet 0 40 167
typenameSet 1 40 168
assign 1 41 169
new 0 41 169
assign 1 42 170
def 1 42 175
assign 1 42 176
typenameGet 0 42 176
assign 1 42 177
IDGet 0 42 177
assign 1 42 178
equals 1 42 183
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 43 194
heldGet 0 43 194
assign 1 43 195
add 1 43 195
delete 0 44 196
fromString 1 46 198
heldSet 1 47 199
assign 1 48 200
nextDescendGet 0 48 200
return 1 48 201
assign 1 50 203
nextDescendGet 0 50 203
return 1 50 204
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1777316122: return bem_serializationIteratorGet_0();
case 1878268220: return bem_buildGet_0();
case -2070846101: return bem_hashGet_0();
case -249375382: return bem_transGetDirect_0();
case 2037996040: return bem_create_0();
case -1036391864: return bem_copy_0();
case 1941247303: return bem_ntypesGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case 1004829909: return bem_transGet_0();
case -1906768398: return bem_classNameGet_0();
case 873076018: return bem_new_0();
case 939713627: return bem_print_0();
case 309126939: return bem_constGetDirect_0();
case -178385347: return bem_iteratorGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 1562650783: return bem_fieldIteratorGet_0();
case 1640157629: return bem_toString_0();
case -1564846521: return bem_constGet_0();
case -1772344344: return bem_ntypesGetDirect_0();
case -1221104789: return bem_sourceFileNameGet_0();
case 942507611: return bem_buildGetDirect_0();
case 1460710096: return bem_tagGet_0();
case -1253293660: return bem_serializeToString_0();
case 307193318: return bem_serializeContents_0();
case 1258729534: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -645913487: return bem_ntypesSet_1(bevd_0);
case -1822218971: return bem_transSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case -1159997008: return bem_constSet_1(bevd_0);
case -1349694791: return bem_begin_1(bevd_0);
case -1307348296: return bem_buildSetDirect_1(bevd_0);
case -1793426904: return bem_end_1(bevd_0);
case 4039371: return bem_ntypesSetDirect_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case 47684234: return bem_buildSet_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2027154208: return bem_constSetDirect_1(bevd_0);
case 1276390583: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -364587754: return bem_transSet_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass4_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass4_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass4();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst = (BEC_3_5_5_5_BuildVisitPass4) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;
}
}
}
