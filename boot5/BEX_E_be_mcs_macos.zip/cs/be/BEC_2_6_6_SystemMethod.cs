namespace be {
/* IO:File: source/base/Functions.be */
public class BEC_2_6_6_SystemMethod : BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemMethod() { }
static BEC_2_6_6_SystemMethod() { }
private static byte[] becc_BEC_2_6_6_SystemMethod_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_6_6_SystemMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemMethod_bels_0 = {0x5F};
public static new BEC_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_inst;

public static new BET_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_4_3_MathInt bevp_ac;
public virtual BEC_2_6_6_SystemMethod bem_new_2(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva_nameac) {
BEC_2_4_3_MathInt bevl_cd = null;
BEC_2_4_6_TextString bevl_name = null;
BEC_2_4_3_MathInt bevl__ac = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_6_SystemMethod bevt_5_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemMethod_bels_0));
bevl_cd = beva_nameac.bem_rfind_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_name = beva_nameac.bem_substring_2(bevt_1_ta_ph, bevl_cd);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_3_ta_ph = bevl_cd.bem_add_1(bevt_4_ta_ph);
bevt_2_ta_ph = beva_nameac.bem_substring_1(bevt_3_ta_ph);
bevl__ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_2_ta_ph);
bevt_5_ta_ph = (BEC_2_6_6_SystemMethod) bem_new_3(beva__target, bevl_name, bevl__ac);
return (BEC_2_6_6_SystemMethod) bevt_5_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_4_3_MathInt beva__ac) {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_ac = beva__ac;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-4013609, bevp_callName, beva_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGetDirect_0() {
return bevp_target;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acGet_0() {
return bevp_ac;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acGetDirect_0() {
return bevp_ac;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_acSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_acSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {35, 35, 36, 36, 37, 37, 37, 37, 38, 38, 43, 44, 45, 54, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 38, 39, 40, 45, 46, 49, 52, 55, 59, 63, 66, 69, 73, 77, 80, 83, 87};
/* BEGIN LINEINFO 
assign 1 35 26
new 0 35 26
assign 1 35 27
rfind 1 35 27
assign 1 36 28
new 0 36 28
assign 1 36 29
substring 2 36 29
assign 1 37 30
new 0 37 30
assign 1 37 31
add 1 37 31
assign 1 37 32
substring 1 37 32
assign 1 37 33
new 1 37 33
assign 1 38 34
new 3 38 34
return 1 38 35
assign 1 43 38
assign 1 44 39
assign 1 45 40
assign 1 54 45
invoke 2 54 45
return 1 55 46
return 1 0 49
return 1 0 52
assign 1 0 55
assign 1 0 59
return 1 0 63
return 1 0 66
assign 1 0 69
assign 1 0 73
return 1 0 77
return 1 0 80
assign 1 0 83
assign 1 0 87
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1562650783: return bem_fieldIteratorGet_0();
case 307193318: return bem_serializeContents_0();
case -905770045: return bem_callNameGetDirect_0();
case 1460710096: return bem_tagGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case 806255357: return bem_targetGetDirect_0();
case -2070846101: return bem_hashGet_0();
case -1906768398: return bem_classNameGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 1258729534: return bem_echo_0();
case 793487297: return bem_callNameGet_0();
case 873076018: return bem_new_0();
case -1253293660: return bem_serializeToString_0();
case -1777316122: return bem_serializationIteratorGet_0();
case -636989668: return bem_acGetDirect_0();
case -2016979558: return bem_acGet_0();
case -681620400: return bem_targetGet_0();
case -1036391864: return bem_copy_0();
case 1640157629: return bem_toString_0();
case 2037996040: return bem_create_0();
case -178385347: return bem_iteratorGet_0();
case 939713627: return bem_print_0();
case -1221104789: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1563945410: return bem_callNameSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case -411886476: return bem_acSet_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -636852985: return bem_acSetDirect_1(bevd_0);
case -681310879: return bem_callNameSet_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1165541730: return bem_targetSet_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -514994970: return bem_targetSetDirect_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1988117707: return bem_new_2(bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 655449428: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_6_SystemMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst = (BEC_2_6_6_SystemMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_type;
}
}
}
