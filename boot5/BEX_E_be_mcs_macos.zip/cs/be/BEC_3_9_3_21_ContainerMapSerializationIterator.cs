namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerMapSerializationIterator : BEC_3_9_3_16_ContainerMapKeyValueIterator {
public BEC_3_9_3_21_ContainerMapSerializationIterator() { }
static BEC_3_9_3_21_ContainerMapSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;

public static new BET_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public override BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
bevp_contents = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
base.bem_new_1(beva__set);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 579*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 579*/ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 579*/
 else /* Line: 579*/ {
break;
} /* Line: 579*/
} /* Line: 579*/
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_postDeserialize_0() {
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_key = null;
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevl_map = (BEC_2_9_3_ContainerMap) bevp_set;
bevl_iter = bevp_contents.bem_iteratorGet_0();
while (true)
/* Line: 587*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(36836391);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 587*/ {
bevl_key = bevl_iter.bemd_0(528131764);
bevl_value = bevl_iter.bemd_0(528131764);
bevl_map.bem_put_2(bevl_key, bevl_value);
} /* Line: 590*/
 else /* Line: 587*/ {
break;
} /* Line: 587*/
} /* Line: 587*/
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_contentsGet_0() {
return bevp_contents;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGetDirect_0() {
return bevp_contents;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {569, 571, 575, 579, 579, 579, 580, 579, 585, 586, 587, 588, 589, 590, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 25, 28, 33, 34, 35, 49, 50, 53, 55, 56, 57, 66, 69, 72, 76};
/* BEGIN LINEINFO 
assign 1 569 14
new 0 569 14
new 1 571 15
addValue 1 575 19
assign 1 579 25
new 0 579 25
assign 1 579 28
lesser 1 579 33
nextSet 1 580 34
assign 1 579 35
increment 0 579 35
assign 1 585 49
assign 1 586 50
iteratorGet 0 586 50
assign 1 587 53
hasNextGet 0 587 53
assign 1 588 55
nextGet 0 588 55
assign 1 589 56
nextGet 0 589 56
put 2 590 57
return 1 0 66
return 1 0 69
assign 1 0 72
assign 1 0 76
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1460710096: return bem_tagGet_0();
case 1804439609: return bem_postDeserialize_0();
case 1562650783: return bem_fieldIteratorGet_0();
case -1036391864: return bem_copy_0();
case 1454597754: return bem_currentGetDirect_0();
case -1117796647: return bem_delete_0();
case -1243909418: return bem_moduGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case 1412837116: return bem_slotsGetDirect_0();
case 1640157629: return bem_toString_0();
case -1906768398: return bem_classNameGet_0();
case 1454299074: return bem_contentsGet_0();
case 36836391: return bem_hasNextGet_0();
case -916466850: return bem_nodeIteratorIteratorGet_0();
case 939713627: return bem_print_0();
case 1123968229: return bem_onNodeGet_0();
case -1281332224: return bem_setGet_0();
case 528131764: return bem_nextGet_0();
case -178385347: return bem_iteratorGet_0();
case -162400470: return bem_slotsGet_0();
case -2070846101: return bem_hashGet_0();
case 307193318: return bem_serializeContents_0();
case -499056153: return bem_contentsGetDirect_0();
case -290296852: return bem_currentGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case -1253293660: return bem_serializeToString_0();
case 62239394: return bem_deserializeClassNameGet_0();
case -1017143848: return bem_moduGetDirect_0();
case 739369906: return bem_setGetDirect_0();
case -1913523785: return bem_onNodeGetDirect_0();
case 1258729534: return bem_echo_0();
case -1221104789: return bem_sourceFileNameGet_0();
case 873076018: return bem_new_0();
case 2037996040: return bem_create_0();
case 73704721: return bem_containerGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -493310448: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -996536337: return bem_moduSet_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case 2020093430: return bem_moduSetDirect_1(bevd_0);
case -841125018: return bem_setSet_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -66126921: return bem_currentSetDirect_1(bevd_0);
case -499742234: return bem_setSetDirect_1(bevd_0);
case -911127035: return bem_contentsSet_1(bevd_0);
case -2087776778: return bem_slotsSet_1(bevd_0);
case 307236542: return bem_onNodeSetDirect_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -1007104350: return bem_slotsSetDirect_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -222876410: return bem_onNodeSet_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1769853070: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1251840955: return bem_currentSet_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1979984129: return bem_nextSet_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case 1285355259: return bem_contentsSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_21_ContainerMapSerializationIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerMapSerializationIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;
}
}
}
