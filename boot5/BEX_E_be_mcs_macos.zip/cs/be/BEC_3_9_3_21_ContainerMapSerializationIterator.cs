namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_21_ContainerMapSerializationIterator : BEC_3_9_3_16_ContainerMapKeyValueIterator {
public BEC_3_9_3_21_ContainerMapSerializationIterator() { }
static BEC_3_9_3_21_ContainerMapSerializationIterator() { }
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x61,0x74,0x69,0x6F,0x6E,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;

public static new BET_3_9_3_21_ContainerMapSerializationIterator bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_contents;
public override BEC_3_9_3_12_ContainerSetNodeIterator bem_new_1(BEC_2_9_3_ContainerSet beva__set) {
bevp_contents = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
base.bem_new_1(beva__set);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
bevp_contents.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 579 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 579 */ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 579 */
 else  /* Line: 579 */ {
break;
} /* Line: 579 */
} /* Line: 579 */
return this;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_postDeserialize_0() {
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_key = null;
BEC_2_6_6_SystemObject bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_map = (BEC_2_9_3_ContainerMap) bevp_set;
bevl_iter = bevp_contents.bem_iteratorGet_0();
while (true)
 /* Line: 587 */ {
bevt_0_tmpany_phold = bevl_iter.bemd_0(-1252731319);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 587 */ {
bevl_key = bevl_iter.bemd_0(-30891401);
bevl_value = bevl_iter.bemd_0(-30891401);
bevl_map.bem_put_2(bevl_key, bevl_value);
} /* Line: 590 */
 else  /* Line: 587 */ {
break;
} /* Line: 587 */
} /* Line: 587 */
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_contentsGet_0() {
return bevp_contents;
} /*method end*/
public BEC_2_9_4_ContainerList bem_contentsGetDirect_0() {
return bevp_contents;
} /*method end*/
public virtual BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_21_ContainerMapSerializationIterator bem_contentsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_contents = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {569, 571, 575, 579, 579, 579, 580, 579, 585, 586, 587, 588, 589, 590, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 25, 28, 33, 34, 35, 49, 50, 53, 55, 56, 57, 66, 69, 72, 76};
/* BEGIN LINEINFO 
assign 1 569 14
new 0 569 14
new 1 571 15
addValue 1 575 19
assign 1 579 25
new 0 579 25
assign 1 579 28
lesser 1 579 33
nextSet 1 580 34
assign 1 579 35
increment 0 579 35
assign 1 585 49
assign 1 586 50
iteratorGet 0 586 50
assign 1 587 53
hasNextGet 0 587 53
assign 1 588 55
nextGet 0 588 55
assign 1 589 56
nextGet 0 589 56
put 2 590 57
return 1 0 66
return 1 0 69
assign 1 0 72
assign 1 0 76
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -639622757: return bem_hashGet_0();
case -2015039528: return bem_iteratorGet_0();
case 1764215204: return bem_moduGet_0();
case -758136205: return bem_slotsGet_0();
case -710241368: return bem_slotsGetDirect_0();
case -30891401: return bem_nextGet_0();
case 2079240474: return bem_nodeIteratorIteratorGet_0();
case 965815191: return bem_echo_0();
case -1252731319: return bem_hasNextGet_0();
case 105645045: return bem_many_0();
case 940651019: return bem_once_0();
case -296688753: return bem_print_0();
case -44366825: return bem_onNodeGetDirect_0();
case 2057346724: return bem_postDeserialize_0();
case -1578327045: return bem_serializeContents_0();
case 993863115: return bem_fieldIteratorGet_0();
case 617667581: return bem_toAny_0();
case 770044727: return bem_deserializeClassNameGet_0();
case -1400364749: return bem_serializationIteratorGet_0();
case -1596775328: return bem_serializeToString_0();
case -1374021326: return bem_currentGetDirect_0();
case 1552820506: return bem_classNameGet_0();
case 1167480829: return bem_copy_0();
case 476647139: return bem_contentsGetDirect_0();
case -625342347: return bem_delete_0();
case -479359240: return bem_tagGet_0();
case 1470127612: return bem_sourceFileNameGet_0();
case 1746473699: return bem_currentGet_0();
case -1491206424: return bem_setGetDirect_0();
case -1405045915: return bem_setGet_0();
case -1039531132: return bem_create_0();
case 2066844567: return bem_fieldNamesGet_0();
case -688862469: return bem_toString_0();
case -944664027: return bem_moduGetDirect_0();
case -1318782989: return bem_contentsGet_0();
case 1149265872: return bem_containerGet_0();
case -1988553054: return bem_onNodeGet_0();
case -1453318633: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1574125927: return bem_setSetDirect_1(bevd_0);
case -414279577: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case -486219542: return bem_currentSetDirect_1(bevd_0);
case 1251355993: return bem_nextSet_1(bevd_0);
case -1202688048: return bem_def_1(bevd_0);
case -1596168486: return bem_equals_1(bevd_0);
case 1431319258: return bem_moduSetDirect_1(bevd_0);
case 1489408670: return bem_sameType_1(bevd_0);
case -1076480041: return bem_notEquals_1(bevd_0);
case 1503413748: return bem_undefined_1(bevd_0);
case -16852549: return bem_onNodeSetDirect_1(bevd_0);
case -1365097484: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1073960196: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 548059277: return bem_contentsSetDirect_1(bevd_0);
case 419445436: return bem_copyTo_1(bevd_0);
case 1879722769: return bem_sameClass_1(bevd_0);
case -2130634504: return bem_slotsSetDirect_1(bevd_0);
case 1563855947: return bem_currentSet_1(bevd_0);
case -1416339029: return bem_sameObject_1(bevd_0);
case -1472392756: return bem_onNodeSet_1(bevd_0);
case -1447883638: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1415671500: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -1197332143: return bem_otherClass_1(bevd_0);
case 1704379462: return bem_slotsSet_1(bevd_0);
case -884635357: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1538855056: return bem_setSet_1(bevd_0);
case 323831111: return bem_undef_1(bevd_0);
case -1300492421: return bem_otherType_1(bevd_0);
case -1605445135: return bem_moduSet_1(bevd_0);
case 189658019: return bem_defined_1(bevd_0);
case -1842622256: return bem_contentsSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 787023569: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1285045766: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -624371870: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 282981748: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1323585037: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2145191247: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -437555976: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(35, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_21_ContainerMapSerializationIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_21_ContainerMapSerializationIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst = (BEC_3_9_3_21_ContainerMapSerializationIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_21_ContainerMapSerializationIterator.bece_BEC_3_9_3_21_ContainerMapSerializationIterator_bevs_type;
}
}
}
