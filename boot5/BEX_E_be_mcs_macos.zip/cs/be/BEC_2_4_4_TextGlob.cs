namespace be {
/* IO:File: source/base/Tokenize.be */
public class BEC_2_4_4_TextGlob : BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
static BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_1, 1));
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_2, 1));
public static new BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;

public static new BET_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_type;

public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public virtual BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public virtual BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_phold.bemd_0(-590153748);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = bem_caseMatch_4(bevl_node, beva_input, bevt_2_tmpany_phold, null);
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
if (beva_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_2_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 126 */
 else  /* Line: 127 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 128 */
} /* Line: 125 */
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_0;
bevt_5_tmpany_phold = bevl_val.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_7_tmpany_phold = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_tmpany_phold;
} /* Line: 133 */
bevt_9_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_1;
bevt_8_tmpany_phold = bevl_val.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 135 */ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_13_tmpany_phold = beva_node.bem_nextGet_0();
bevt_12_tmpany_phold = bem_caseMatch_4(bevt_13_tmpany_phold, beva_input, beva_pos, null);
return bevt_12_tmpany_phold;
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_14_tmpany_phold;
} /* Line: 137 */
} /* Line: 137 */
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 140 */ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_18_tmpany_phold = beva_node.bem_nextGet_0();
bevt_20_tmpany_phold = bevl_val.bem_sizeGet_0();
bevt_19_tmpany_phold = beva_pos.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bem_caseMatch_4(bevt_18_tmpany_phold, beva_input, bevt_19_tmpany_phold, null);
return bevt_17_tmpany_phold;
} /* Line: 142 */
 else  /* Line: 143 */ {
if (beva_lpos == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 144 */ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 145 */
} /* Line: 144 */
} /* Line: 141 */
bevt_22_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_22_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (BEC_2_9_6_ContainerSingle) (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
 /* Line: 156 */ {
bevt_1_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool) /* Line: 158 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 158 */
bevt_4_tmpany_phold = bevl_lpos.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 159 */ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 161 */
 else  /* Line: 162 */ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 163 */
} /* Line: 159 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_globGet_0() {
return bevp_glob;
} /*method end*/
public BEC_2_4_6_TextString bem_globGetDirect_0() {
return bevp_glob;
} /*method end*/
public BEC_2_4_4_TextGlob bem_globSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_glob = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() {
return bevp_splits;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitsGetDirect_0() {
return bevp_splits;
} /*method end*/
public virtual BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_4_TextGlob bem_splitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {101, 105, 105, 105, 106, 108, 109, 119, 119, 120, 120, 120, 124, 124, 125, 125, 125, 126, 126, 128, 128, 131, 132, 132, 133, 133, 135, 135, 136, 137, 137, 137, 137, 137, 137, 137, 137, 139, 140, 140, 141, 141, 142, 142, 142, 142, 142, 144, 144, 145, 149, 149, 153, 154, 156, 156, 156, 157, 158, 158, 159, 159, 159, 160, 161, 163, 166, 166, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 28, 29, 30, 31, 32, 33, 41, 42, 43, 44, 45, 73, 78, 79, 80, 85, 86, 87, 90, 91, 94, 95, 96, 98, 99, 101, 102, 104, 105, 106, 111, 112, 113, 114, 117, 118, 121, 122, 127, 128, 133, 134, 135, 136, 137, 138, 141, 146, 147, 151, 152, 164, 165, 168, 169, 174, 175, 177, 178, 180, 181, 186, 187, 188, 191, 198, 199, 202, 205, 208, 212, 215, 218, 222};
/* BEGIN LINEINFO 
globSet 1 101 20
assign 1 105 28
new 0 105 28
assign 1 105 29
new 0 105 29
assign 1 105 30
new 2 105 30
assign 1 106 31
tokenize 1 106 31
assign 1 108 32
assign 1 109 33
assign 1 119 41
iteratorGet 0 119 41
assign 1 119 42
nextNodeGet 0 119 42
assign 1 120 43
new 0 120 43
assign 1 120 44
caseMatch 4 120 44
return 1 120 45
assign 1 124 73
undef 1 124 78
assign 1 125 79
sizeGet 0 125 79
assign 1 125 80
equals 1 125 85
assign 1 126 86
new 0 126 86
return 1 126 87
assign 1 128 90
new 0 128 90
return 1 128 91
assign 1 131 94
heldGet 0 131 94
assign 1 132 95
new 0 132 95
assign 1 132 96
equals 1 132 96
assign 1 133 98
starMatch 3 133 98
return 1 133 99
assign 1 135 101
new 0 135 101
assign 1 135 102
equals 1 135 102
assign 1 136 104
increment 0 136 104
assign 1 137 105
sizeGet 0 137 105
assign 1 137 106
lesserEquals 1 137 111
assign 1 137 112
nextGet 0 137 112
assign 1 137 113
caseMatch 4 137 113
return 1 137 114
assign 1 137 117
new 0 137 117
return 1 137 118
assign 1 139 121
find 2 139 121
assign 1 140 122
def 1 140 127
assign 1 141 128
equals 1 141 133
assign 1 142 134
nextGet 0 142 134
assign 1 142 135
sizeGet 0 142 135
assign 1 142 136
add 1 142 136
assign 1 142 137
caseMatch 4 142 137
return 1 142 138
assign 1 144 141
def 1 144 146
firstSet 1 145 147
assign 1 149 151
new 0 149 151
return 1 149 152
assign 1 153 164
nextGet 0 153 164
assign 1 154 165
new 0 154 165
assign 1 156 168
sizeGet 0 156 168
assign 1 156 169
lesserEquals 1 156 174
assign 1 157 175
caseMatch 4 157 175
assign 1 158 177
new 0 158 177
return 1 158 178
assign 1 159 180
firstGet 0 159 180
assign 1 159 181
def 1 159 186
assign 1 160 187
firstGet 0 160 187
firstSet 1 161 188
assign 1 163 191
increment 0 163 191
assign 1 166 198
new 0 166 198
return 1 166 199
return 1 0 202
return 1 0 205
assign 1 0 208
return 1 0 212
return 1 0 215
assign 1 0 218
assign 1 0 222
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1776469940: return bem_globGet_0();
case -1141049131: return bem_iteratorGet_0();
case 1366617398: return bem_tagGet_0();
case 1747475389: return bem_many_0();
case -1651752879: return bem_splitsGet_0();
case -31410563: return bem_once_0();
case 306116222: return bem_echo_0();
case 1801694719: return bem_copy_0();
case -1219673974: return bem_toString_0();
case 95623142: return bem_globGetDirect_0();
case -2016997496: return bem_print_0();
case -14767827: return bem_serializeToString_0();
case 1115258825: return bem_create_0();
case 493645004: return bem_splitsGetDirect_0();
case 222096027: return bem_classNameGet_0();
case 216845033: return bem_new_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 434654272: return bem_hashGet_0();
case 1999868679: return bem_fieldIteratorGet_0();
case 2119098947: return bem_serializeContents_0();
case -1121300979: return bem_fieldNamesGet_0();
case -1194274080: return bem_toAny_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case -1365182072: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1684084096: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1732884175: return bem_globSetDirect_1(bevd_0);
case -1246021533: return bem_equals_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case -589849337: return bem_splitsSet_1(bevd_0);
case -736227815: return bem_splitsSetDirect_1(bevd_0);
case -379790668: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case 53506905: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -240164168: return bem_undefined_1(bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 2057114038: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 492479748: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_4_TextGlob_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_TextGlob();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_type;
}
}
}
