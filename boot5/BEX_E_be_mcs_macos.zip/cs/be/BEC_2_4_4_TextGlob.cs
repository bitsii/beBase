namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public class BEC_2_4_4_TextGlob : BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
static BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_1, 1));
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_2, 1));
public static new BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;

public static new BET_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_type;

public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public virtual BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public virtual BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_ph.bemd_0(1775967388);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bem_caseMatch_4(bevl_node, beva_input, bevt_2_ta_ph, null);
return bevt_1_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
if (beva_node == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1051*/ {
bevt_2_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1052*/ {
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1053*/
 else /* Line: 1054*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 1055*/
} /* Line: 1052*/
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_ta_ph = bece_BEC_2_4_4_TextGlob_bevo_0;
bevt_5_ta_ph = bevl_val.bem_equals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1059*/ {
bevt_7_ta_ph = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_ta_ph;
} /* Line: 1060*/
bevt_9_ta_ph = bece_BEC_2_4_4_TextGlob_bevo_1;
bevt_8_ta_ph = bevl_val.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 1062*/ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1064*/ {
bevt_13_ta_ph = beva_node.bem_nextGet_0();
bevt_12_ta_ph = bem_caseMatch_4(bevt_13_ta_ph, beva_input, beva_pos, null);
return bevt_12_ta_ph;
} /* Line: 1064*/
 else /* Line: 1064*/ {
bevt_14_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_14_ta_ph;
} /* Line: 1064*/
} /* Line: 1064*/
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1067*/ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 1068*/ {
bevt_18_ta_ph = beva_node.bem_nextGet_0();
bevt_20_ta_ph = bevl_val.bem_sizeGet_0();
bevt_19_ta_ph = beva_pos.bem_add_1(bevt_20_ta_ph);
bevt_17_ta_ph = bem_caseMatch_4(bevt_18_ta_ph, beva_input, bevt_19_ta_ph, null);
return bevt_17_ta_ph;
} /* Line: 1069*/
 else /* Line: 1070*/ {
if (beva_lpos == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1071*/ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 1072*/
} /* Line: 1071*/
} /* Line: 1068*/
bevt_22_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_22_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (BEC_2_9_6_ContainerSingle) (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
/* Line: 1083*/ {
bevt_1_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1083*/ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool)/* Line: 1085*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1085*/
bevt_4_ta_ph = bevl_lpos.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1086*/ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 1088*/
 else /* Line: 1089*/ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 1090*/
} /* Line: 1086*/
 else /* Line: 1083*/ {
break;
} /* Line: 1083*/
} /* Line: 1083*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_globGet_0() {
return bevp_glob;
} /*method end*/
public BEC_2_4_6_TextString bem_globGetDirect_0() {
return bevp_glob;
} /*method end*/
public BEC_2_4_4_TextGlob bem_globSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_glob = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() {
return bevp_splits;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitsGetDirect_0() {
return bevp_splits;
} /*method end*/
public virtual BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_4_TextGlob bem_splitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1028, 1032, 1032, 1032, 1033, 1035, 1036, 1046, 1046, 1047, 1047, 1047, 1051, 1051, 1052, 1052, 1052, 1053, 1053, 1055, 1055, 1058, 1059, 1059, 1060, 1060, 1062, 1062, 1063, 1064, 1064, 1064, 1064, 1064, 1064, 1064, 1064, 1066, 1067, 1067, 1068, 1068, 1069, 1069, 1069, 1069, 1069, 1071, 1071, 1072, 1076, 1076, 1080, 1081, 1083, 1083, 1083, 1084, 1085, 1085, 1086, 1086, 1086, 1087, 1088, 1090, 1093, 1093, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 32, 33, 34, 35, 36, 37, 45, 46, 47, 48, 49, 77, 82, 83, 84, 89, 90, 91, 94, 95, 98, 99, 100, 102, 103, 105, 106, 108, 109, 110, 115, 116, 117, 118, 121, 122, 125, 126, 131, 132, 137, 138, 139, 140, 141, 142, 145, 150, 151, 155, 156, 168, 169, 172, 173, 178, 179, 181, 182, 184, 185, 190, 191, 192, 195, 202, 203, 206, 209, 212, 216, 219, 222, 226};
/* BEGIN LINEINFO 
globSet 1 1028 24
assign 1 1032 32
new 0 1032 32
assign 1 1032 33
new 0 1032 33
assign 1 1032 34
new 2 1032 34
assign 1 1033 35
tokenize 1 1033 35
assign 1 1035 36
assign 1 1036 37
assign 1 1046 45
iteratorGet 0 1046 45
assign 1 1046 46
nextNodeGet 0 1046 46
assign 1 1047 47
new 0 1047 47
assign 1 1047 48
caseMatch 4 1047 48
return 1 1047 49
assign 1 1051 77
undef 1 1051 82
assign 1 1052 83
sizeGet 0 1052 83
assign 1 1052 84
equals 1 1052 89
assign 1 1053 90
new 0 1053 90
return 1 1053 91
assign 1 1055 94
new 0 1055 94
return 1 1055 95
assign 1 1058 98
heldGet 0 1058 98
assign 1 1059 99
new 0 1059 99
assign 1 1059 100
equals 1 1059 100
assign 1 1060 102
starMatch 3 1060 102
return 1 1060 103
assign 1 1062 105
new 0 1062 105
assign 1 1062 106
equals 1 1062 106
assign 1 1063 108
increment 0 1063 108
assign 1 1064 109
sizeGet 0 1064 109
assign 1 1064 110
lesserEquals 1 1064 115
assign 1 1064 116
nextGet 0 1064 116
assign 1 1064 117
caseMatch 4 1064 117
return 1 1064 118
assign 1 1064 121
new 0 1064 121
return 1 1064 122
assign 1 1066 125
find 2 1066 125
assign 1 1067 126
def 1 1067 131
assign 1 1068 132
equals 1 1068 137
assign 1 1069 138
nextGet 0 1069 138
assign 1 1069 139
sizeGet 0 1069 139
assign 1 1069 140
add 1 1069 140
assign 1 1069 141
caseMatch 4 1069 141
return 1 1069 142
assign 1 1071 145
def 1 1071 150
firstSet 1 1072 151
assign 1 1076 155
new 0 1076 155
return 1 1076 156
assign 1 1080 168
nextGet 0 1080 168
assign 1 1081 169
new 0 1081 169
assign 1 1083 172
sizeGet 0 1083 172
assign 1 1083 173
lesserEquals 1 1083 178
assign 1 1084 179
caseMatch 4 1084 179
assign 1 1085 181
new 0 1085 181
return 1 1085 182
assign 1 1086 184
firstGet 0 1086 184
assign 1 1086 185
def 1 1086 190
assign 1 1087 191
firstGet 0 1087 191
firstSet 1 1088 192
assign 1 1090 195
increment 0 1090 195
assign 1 1093 202
new 0 1093 202
return 1 1093 203
return 1 0 206
return 1 0 209
assign 1 0 212
return 1 0 216
return 1 0 219
assign 1 0 222
assign 1 0 226
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 110382217: return bem_sourceFileNameGet_0();
case 1986590366: return bem_hashGet_0();
case 879975179: return bem_classNameGet_0();
case -857218109: return bem_splitsGet_0();
case -1584439045: return bem_splitsGetDirect_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 887739950: return bem_serializeToString_0();
case -2129983068: return bem_toAny_0();
case 233362262: return bem_many_0();
case 888041456: return bem_tagGet_0();
case 1843544518: return bem_serializeContents_0();
case 1732513565: return bem_copy_0();
case -1588532100: return bem_echo_0();
case 1383646476: return bem_iteratorGet_0();
case 1989693945: return bem_toString_0();
case 2071597061: return bem_create_0();
case -1084228149: return bem_print_0();
case 714460463: return bem_once_0();
case -553399733: return bem_globGet_0();
case 162533386: return bem_fieldNamesGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 1105152133: return bem_new_0();
case -153156208: return bem_serializationIteratorGet_0();
case -1577465699: return bem_globGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1096638030: return bem_undefined_1(bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -189286728: return bem_globSetDirect_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 495765458: return bem_splitsSet_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1660359147: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case -1221777904: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case 1526801060: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 11588364: return bem_splitsSetDirect_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1758639079: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1868422907: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_4_4_TextGlob_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_TextGlob();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_type;
}
}
}
