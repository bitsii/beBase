namespace be {
public class BET_2_5_6_BuildMtdSyn : BETS_Object {
public BET_2_5_6_BuildMtdSyn() {
string[] bevs_mtnames = new string[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "new_2", "getEmitReturnType_2", "hposGet_0", "hposGetDirect_0", "hposSet_1", "hposSetDirect_1", "mtdxGet_0", "mtdxGetDirect_0", "mtdxSet_1", "mtdxSetDirect_1", "numargsGet_0", "numargsGetDirect_0", "numargsSet_1", "numargsSetDirect_1", "nameGet_0", "nameGetDirect_0", "nameSet_1", "nameSetDirect_1", "orgNameGet_0", "orgNameGetDirect_0", "orgNameSet_1", "orgNameSetDirect_1", "isGenAccessorGet_0", "isGenAccessorGetDirect_0", "isGenAccessorSet_1", "isGenAccessorSetDirect_1", "argSynsGet_0", "argSynsGetDirect_0", "argSynsSet_1", "argSynsSetDirect_1", "originGet_0", "originGetDirect_0", "originSet_1", "originSetDirect_1", "declarationGet_0", "declarationGetDirect_0", "declarationSet_1", "declarationSetDirect_1", "lastDefGet_0", "lastDefGetDirect_0", "lastDefSet_1", "lastDefSetDirect_1", "isOverrideGet_0", "isOverrideGetDirect_0", "isOverrideSet_1", "isOverrideSetDirect_1", "isFinalGet_0", "isFinalGetDirect_0", "isFinalSet_1", "isFinalSetDirect_1", "propertyNameGet_0", "propertyNameGetDirect_0", "propertyNameSet_1", "propertyNameSetDirect_1", "rsynGet_0", "rsynGetDirect_0", "rsynSet_1", "rsynSetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "hpos", "mtdx", "numargs", "name", "orgName", "isGenAccessor", "argSyns", "origin", "declaration", "lastDef", "isOverride", "isFinal", "propertyName", "rsyn" };
}
static BET_2_5_6_BuildMtdSyn() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_6_BuildMtdSyn();
}
}
}
