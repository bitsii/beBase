namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_8_SystemVariadic : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemVariadic() { }
static BEC_2_6_8_SystemVariadic() { }
private static byte[] becc_BEC_2_6_8_SystemVariadic_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x56,0x61,0x72,0x69,0x61,0x64,0x69,0x63};
private static byte[] becc_BEC_2_6_8_SystemVariadic_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
public static new BEC_2_6_8_SystemVariadic bece_BEC_2_6_8_SystemVariadic_bevs_inst;

public static new BET_2_6_8_SystemVariadic bece_BEC_2_6_8_SystemVariadic_bevs_type;

public sealed override BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bem_can_2(beva_name, bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 918*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_varargs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_3_ta_ph, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 921*/
return bevl_result;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {918, 918, 919, 919, 920, 920, 921, 923};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 26, 27, 28, 30};
/* BEGIN LINEINFO 
assign 1 918 21
new 0 918 21
assign 1 918 22
can 2 918 22
assign 1 919 24
new 0 919 24
assign 1 919 25
new 1 919 25
assign 1 920 26
new 0 920 26
put 2 920 27
assign 1 921 28
invoke 2 921 28
return 1 923 30
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1562608535: return bem_print_0();
case 1688687204: return bem_serializeToString_0();
case 1029695809: return bem_echo_0();
case -1844917728: return bem_many_0();
case -1026733174: return bem_new_0();
case -1902089216: return bem_toString_0();
case 102554564: return bem_fieldIteratorGet_0();
case -479166709: return bem_tagGet_0();
case 185174991: return bem_copy_0();
case -1848718184: return bem_hashGet_0();
case 126670515: return bem_toAny_0();
case -31114048: return bem_iteratorGet_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -8643043: return bem_serializeContents_0();
case 1137009070: return bem_once_0();
case -785258946: return bem_create_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 217968364: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemVariadic_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemVariadic_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemVariadic();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst = (BEC_2_6_8_SystemVariadic) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_type;
}
}
}
