namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_8_7_TemplateReplace : BEC_2_6_6_SystemObject {
public BEC_2_8_7_TemplateReplace() { }
static BEC_2_8_7_TemplateReplace() { }
private static byte[] becc_BEC_2_8_7_TemplateReplace_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_BEC_2_8_7_TemplateReplace_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_1 = {0x3F,0x3E};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_2 = {0x20};
public static new BEC_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_inst;

public static new BET_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_steps;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_append;
public BEC_2_8_6_TemplateRunner bevp_runner;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_load_1(BEC_2_4_6_TextString beva_template) {
bem_load_2(beva_template, null);
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_load_2(BEC_2_4_6_TextString beva_template, BEC_2_8_6_TemplateRunner beva__runner) {
BEC_2_4_6_TextString bevl_blStart = null;
BEC_2_4_6_TextString bevl_blEnd = null;
BEC_2_5_4_LogicBool bevl_onStart = null;
BEC_2_5_4_LogicBool bevl_nextIsCall = null;
BEC_2_4_6_TextString bevl_delim = null;
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_4_6_TextString bevl_payload = null;
BEC_2_9_10_ContainerLinkedList bevl_payloads = null;
BEC_2_7_8_ReplaceCallStep bevl_rcs = null;
BEC_2_4_6_TextString bevl_paypart = null;
BEC_2_7_7_ReplaceRunStep bevl_rs = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_7_10_ReplaceStringStep bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_8_7_TemplateReplace_bels_0));
bevl_blEnd = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_8_7_TemplateReplace_bels_1));
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
/* Line: 82*/ {
if (bevl_i == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 82*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 83*/ {
if (bevl_nextIsCall.bevi_bool)/* Line: 84*/ {
bevt_3_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_strip_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_8_7_TemplateReplace_bels_2));
bevl_payloads = bevl_payload.bem_split_1(bevt_4_ta_ph);
if (bevp_runner == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 87*/ {
bevl_rcs = (BEC_2_7_8_ReplaceCallStep) (new BEC_2_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 91*/
 else /* Line: 92*/ {
bevt_0_ta_loop = bevl_payloads.bem_linkedListIteratorGet_0();
while (true)
/* Line: 94*/ {
bevt_6_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 94*/ {
bevl_paypart = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_rs = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 96*/
 else /* Line: 94*/ {
break;
} /* Line: 94*/
} /* Line: 94*/
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 98*/
} /* Line: 87*/
 else /* Line: 100*/ {
bevt_8_ta_ph = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_7_ta_ph = (BEC_2_7_10_ReplaceStringStep) (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_8_ta_ph);
bevl_splits.bem_addValue_1(bevt_7_ta_ph);
} /* Line: 101*/
} /* Line: 84*/
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool)/* Line: 105*/ {
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 109*/
 else /* Line: 110*/ {
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 113*/
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 115*/
 else /* Line: 82*/ {
break;
} /* Line: 82*/
} /* Line: 82*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 117*/ {
bevt_11_ta_ph = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_10_ta_ph = (BEC_2_7_10_ReplaceStringStep) (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_11_ta_ph);
bevl_splits.bem_addValue_1(bevt_10_ta_ph);
} /* Line: 118*/
bevp_steps = bevl_splits;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_accept_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_out) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
/* Line: 125*/ {
bevt_0_ta_ph = bevl_iter.bemd_0(1091237859);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 125*/ {
bevl_s = bevl_iter.bemd_0(1799618430);
if (bevp_append.bevi_bool)/* Line: 127*/ {
bevt_1_ta_ph = bevl_s.bemd_1(873458453, beva_inst);
beva_out.bemd_1(568704480, bevt_1_ta_ph);
} /* Line: 128*/
} /* Line: 127*/
 else /* Line: 125*/ {
break;
} /* Line: 125*/
} /* Line: 125*/
return beva_out;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
return bevp_steps;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGetDirect_0() {
return bevp_steps;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_stepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_stepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_appendGet_0() {
return bevp_append;
} /*method end*/
public BEC_2_5_4_LogicBool bem_appendGetDirect_0() {
return bevp_append;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_appendSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_appendSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_runnerGet_0() {
return bevp_runner;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runnerGetDirect_0() {
return bevp_runner;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_runnerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_runnerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {58, 65, 69, 70, 72, 73, 74, 75, 77, 78, 79, 80, 81, 82, 82, 83, 83, 85, 85, 86, 86, 87, 87, 89, 90, 91, 94, 0, 94, 94, 95, 96, 98, 101, 101, 101, 104, 106, 107, 108, 109, 111, 112, 113, 115, 117, 117, 118, 118, 118, 120, 124, 125, 126, 128, 128, 131, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 24, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 67, 72, 73, 78, 80, 81, 82, 83, 84, 89, 90, 91, 92, 95, 95, 98, 100, 101, 102, 108, 112, 113, 114, 117, 119, 120, 121, 122, 125, 126, 127, 129, 135, 140, 141, 142, 143, 145, 153, 156, 158, 160, 161, 168, 171, 174, 177, 181, 185, 188, 191, 195, 199, 202, 205, 209, 213, 216, 219, 223};
/* BEGIN LINEINFO 
assign 1 58 20
new 0 58 20
load 2 65 24
assign 1 69 54
assign 1 70 55
sizeGet 0 70 55
assign 1 72 56
new 0 72 56
assign 1 73 57
new 0 73 57
assign 1 74 58
new 0 74 58
assign 1 75 59
new 0 75 59
assign 1 77 60
assign 1 78 61
new 0 78 61
assign 1 79 62
new 0 79 62
assign 1 80 63
find 2 80 63
assign 1 81 64
sizeGet 0 81 64
assign 1 82 67
def 1 82 72
assign 1 83 73
greater 1 83 78
assign 1 85 80
substring 2 85 80
assign 1 85 81
strip 0 85 81
assign 1 86 82
new 0 86 82
assign 1 86 83
split 1 86 83
assign 1 87 84
undef 1 87 89
assign 1 89 90
new 1 89 90
addValue 1 90 91
assign 1 91 92
new 0 91 92
assign 1 94 95
linkedListIteratorGet 0 0 95
assign 1 94 98
hasNextGet 0 94 98
assign 1 94 100
nextGet 0 94 100
assign 1 95 101
new 2 95 101
addValue 1 96 102
assign 1 98 108
new 0 98 108
assign 1 101 112
substring 2 101 112
assign 1 101 113
new 1 101 113
addValue 1 101 114
assign 1 104 117
add 1 104 117
assign 1 106 119
new 0 106 119
assign 1 107 120
assign 1 108 121
sizeGet 0 108 121
assign 1 109 122
new 0 109 122
assign 1 111 125
new 0 111 125
assign 1 112 126
assign 1 113 127
sizeGet 0 113 127
assign 1 115 129
find 2 115 129
assign 1 117 135
lesser 1 117 140
assign 1 118 141
substring 2 118 141
assign 1 118 142
new 1 118 142
addValue 1 118 143
assign 1 120 145
assign 1 124 153
iteratorGet 0 124 153
assign 1 125 156
hasNextGet 0 125 156
assign 1 126 158
nextGet 0 126 158
assign 1 128 160
handle 1 128 160
write 1 128 161
return 1 131 168
return 1 0 171
return 1 0 174
assign 1 0 177
assign 1 0 181
return 1 0 185
return 1 0 188
assign 1 0 191
assign 1 0 195
return 1 0 199
return 1 0 202
assign 1 0 205
assign 1 0 209
return 1 0 213
return 1 0 216
assign 1 0 219
assign 1 0 223
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 110382217: return bem_sourceFileNameGet_0();
case 1986590366: return bem_hashGet_0();
case 879975179: return bem_classNameGet_0();
case -2064614940: return bem_sizeGetDirect_0();
case -817851538: return bem_stepsGetDirect_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 887739950: return bem_serializeToString_0();
case -2129983068: return bem_toAny_0();
case 1743900761: return bem_runnerGetDirect_0();
case 292596471: return bem_appendGet_0();
case 233362262: return bem_many_0();
case 549012775: return bem_stepsGet_0();
case 888041456: return bem_tagGet_0();
case -1482984555: return bem_sizeGet_0();
case 1843544518: return bem_serializeContents_0();
case 1732513565: return bem_copy_0();
case -1588532100: return bem_echo_0();
case 1383646476: return bem_iteratorGet_0();
case 1989693945: return bem_toString_0();
case 2071597061: return bem_create_0();
case -565633749: return bem_appendGetDirect_0();
case -1084228149: return bem_print_0();
case 714460463: return bem_once_0();
case 162533386: return bem_fieldNamesGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 426310145: return bem_runnerGet_0();
case 1105152133: return bem_new_0();
case -153156208: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2085177945: return bem_appendSet_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case 755520805: return bem_stepsSetDirect_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case -1596095239: return bem_appendSetDirect_1(bevd_0);
case 2122294516: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 223415888: return bem_runnerSet_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1238965384: return bem_runnerSetDirect_1(bevd_0);
case -816341029: return bem_sizeSet_1(bevd_0);
case -1502620842: return bem_sizeSetDirect_1(bevd_0);
case -306371044: return bem_stepsSet_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -811521255: return bem_load_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_8_6_TemplateRunner) bevd_1);
case -969573303: return bem_accept_2(bevd_0, bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_8_7_TemplateReplace_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_7_TemplateReplace_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_8_7_TemplateReplace();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst = (BEC_2_8_7_TemplateReplace) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_type;
}
}
}
