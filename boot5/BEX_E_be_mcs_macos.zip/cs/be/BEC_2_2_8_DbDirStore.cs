namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore : BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
static BEC_2_2_8_DbDirStore() { }
private static byte[] becc_BEC_2_2_8_DbDirStore_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_BEC_2_2_8_DbDirStore_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_0 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
public static new BEC_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_inst;

public static new BET_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_type;

public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public virtual BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) {
bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
bem_pathNew_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) {
bevp_ser = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_keyEncoder == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(-1421556472, beva_id);
} /* Line: 373 */
 else  /* Line: 374 */ {
bevl_storeId = beva_id;
} /* Line: 375 */
return bevl_storeId;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_0;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 382 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 382 */
 else  /* Line: 382 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 382 */ {
bevt_6_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_7_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 384 */
bevl_storeId = (BEC_2_4_6_TextString) bem_getStoreId_1(beva_id);
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevl_storeId);
} /* Line: 387 */
return bevl_p;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_1;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 393 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 393 */
 else  /* Line: 393 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 393 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 395 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_writerGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-1176006467);
bevp_ser.bem_serialize_2(beva_object, bevt_5_tmpany_phold);
bevt_9_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevt_8_tmpany_phold.bemd_0(-913233948);
} /* Line: 397 */
} /* Line: 395 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_12_tmpany_phold = null;
if (beva_id == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 403 */ {
bevt_4_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_2;
bevt_3_tmpany_phold = beva_id.bem_notEquals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 403 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 403 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 403 */
 else  /* Line: 403 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 403 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_existsGet_0();
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 405 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 405 */
 else  /* Line: 405 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 405 */ {
bevt_10_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_readerGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1176006467);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_tmpany_phold);
bevt_12_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_readerGet_0();
bevt_11_tmpany_phold.bemd_0(-913233948);
return bevl_object;
} /* Line: 408 */
} /* Line: 405 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 415 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_3;
bevt_2_tmpany_phold = beva_id.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 415 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 415 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 415 */
bevl_p = bem_getPath_1(beva_id);
bevt_6_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 418 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_delete_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevl_p = bem_getPath_1(beva_id);
bevt_0_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_0_tmpany_phold.bem_delete_0();
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemSerializer bem_serGet_0() {
return bevp_ser;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serGetDirect_0() {
return bevp_ser;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_serSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() {
return bevp_storageDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_storageDirGetDirect_0() {
return bevp_storageDir;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_storageDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_keyEncoderGet_0() {
return bevp_keyEncoder;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderGetDirect_0() {
return bevp_keyEncoder;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_keyEncoder = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_keyEncoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_keyEncoder = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {354, 355, 359, 359, 364, 365, 366, 372, 372, 373, 375, 377, 382, 382, 382, 382, 0, 0, 0, 383, 383, 383, 383, 384, 384, 386, 387, 387, 389, 393, 393, 393, 393, 0, 0, 0, 394, 395, 395, 396, 396, 396, 396, 397, 397, 397, 403, 403, 403, 403, 0, 0, 0, 404, 405, 405, 405, 405, 0, 0, 0, 406, 406, 406, 406, 407, 407, 407, 408, 411, 415, 415, 0, 415, 415, 0, 0, 415, 415, 416, 417, 417, 418, 418, 420, 420, 424, 425, 425, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 27, 28, 32, 33, 34, 40, 45, 46, 49, 51, 65, 70, 71, 72, 74, 77, 81, 84, 85, 86, 91, 92, 93, 95, 96, 97, 99, 113, 118, 119, 120, 122, 125, 129, 132, 133, 138, 139, 140, 141, 142, 143, 144, 145, 166, 171, 172, 173, 175, 178, 182, 185, 186, 191, 192, 193, 195, 198, 202, 205, 206, 207, 208, 209, 210, 211, 212, 215, 228, 233, 234, 237, 238, 240, 243, 247, 248, 250, 251, 252, 254, 255, 257, 258, 263, 264, 265, 269, 272, 275, 279, 283, 286, 289, 293, 297, 300, 303, 307};
/* BEGIN LINEINFO 
new 1 354 21
assign 1 355 22
assign 1 359 27
apNew 1 359 27
pathNew 1 359 28
assign 1 364 32
new 0 364 32
assign 1 365 33
assign 1 366 34
assign 1 372 40
def 1 372 45
assign 1 373 46
encode 1 373 46
assign 1 375 49
return 1 377 51
assign 1 382 65
def 1 382 70
assign 1 382 71
new 0 382 71
assign 1 382 72
notEquals 1 382 72
assign 1 0 74
assign 1 0 77
assign 1 0 81
assign 1 383 84
fileGet 0 383 84
assign 1 383 85
existsGet 0 383 85
assign 1 383 86
not 0 383 91
assign 1 384 92
fileGet 0 384 92
makeDirs 0 384 93
assign 1 386 95
getStoreId 1 386 95
assign 1 387 96
copy 0 387 96
assign 1 387 97
addStep 1 387 97
return 1 389 99
assign 1 393 113
def 1 393 118
assign 1 393 119
new 0 393 119
assign 1 393 120
notEquals 1 393 120
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 394 132
getPath 1 394 132
assign 1 395 133
def 1 395 138
assign 1 396 139
fileGet 0 396 139
assign 1 396 140
writerGet 0 396 140
assign 1 396 141
open 0 396 141
serialize 2 396 142
assign 1 397 143
fileGet 0 397 143
assign 1 397 144
writerGet 0 397 144
close 0 397 145
assign 1 403 166
def 1 403 171
assign 1 403 172
new 0 403 172
assign 1 403 173
notEquals 1 403 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 404 185
getPath 1 404 185
assign 1 405 186
def 1 405 191
assign 1 405 192
fileGet 0 405 192
assign 1 405 193
existsGet 0 405 193
assign 1 0 195
assign 1 0 198
assign 1 0 202
assign 1 406 205
fileGet 0 406 205
assign 1 406 206
readerGet 0 406 206
assign 1 406 207
open 0 406 207
assign 1 406 208
deserialize 1 406 208
assign 1 407 209
fileGet 0 407 209
assign 1 407 210
readerGet 0 407 210
close 0 407 211
return 1 408 212
return 1 411 215
assign 1 415 228
undef 1 415 233
assign 1 0 234
assign 1 415 237
new 0 415 237
assign 1 415 238
equals 1 415 238
assign 1 0 240
assign 1 0 243
assign 1 415 247
new 0 415 247
return 1 415 248
assign 1 416 250
getPath 1 416 250
assign 1 417 251
fileGet 0 417 251
assign 1 417 252
existsGet 0 417 252
assign 1 418 254
new 0 418 254
return 1 418 255
assign 1 420 257
new 0 420 257
return 1 420 258
assign 1 424 263
getPath 1 424 263
assign 1 425 264
fileGet 0 425 264
delete 0 425 265
return 1 0 269
return 1 0 272
assign 1 0 275
assign 1 0 279
return 1 0 283
return 1 0 286
assign 1 0 289
assign 1 0 293
return 1 0 297
return 1 0 300
assign 1 0 303
assign 1 0 307
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 64930083: return bem_new_0();
case -1160093527: return bem_fieldIteratorGet_0();
case 1685980709: return bem_serGetDirect_0();
case 265775004: return bem_tagGet_0();
case 1259379161: return bem_sourceFileNameGet_0();
case 338892103: return bem_serializeContents_0();
case 1685630819: return bem_toAny_0();
case 324558137: return bem_serializationIteratorGet_0();
case -1924670591: return bem_print_0();
case 1616298039: return bem_toString_0();
case -477793454: return bem_deserializeClassNameGet_0();
case -2145124906: return bem_fieldNamesGet_0();
case -383409287: return bem_hashGet_0();
case 1698440478: return bem_classNameGet_0();
case 1409367716: return bem_iteratorGet_0();
case -698592158: return bem_once_0();
case 857744439: return bem_serializeToString_0();
case 783138120: return bem_keyEncoderGet_0();
case 447398905: return bem_copy_0();
case 24523401: return bem_create_0();
case -1935071382: return bem_keyEncoderGetDirect_0();
case 1536526581: return bem_serGet_0();
case 1574541715: return bem_echo_0();
case -1547942674: return bem_storageDirGetDirect_0();
case 1658911196: return bem_storageDirGet_0();
case 621904783: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -52657747: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1270041233: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1582703619: return bem_undef_1(bevd_0);
case 854851905: return bem_sameType_1(bevd_0);
case -284744275: return bem_storageDirSetDirect_1(bevd_0);
case 1377540300: return bem_keyEncoderSetDirect_1(bevd_0);
case -685667652: return bem_undefined_1(bevd_0);
case -1166446788: return bem_serSetDirect_1(bevd_0);
case -346349789: return bem_equals_1(bevd_0);
case -263744154: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 1464921499: return bem_def_1(bevd_0);
case 604959651: return bem_otherClass_1(bevd_0);
case 1991124225: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -1932510652: return bem_sameClass_1(bevd_0);
case -1921243842: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1928814677: return bem_storageDirSet_1(bevd_0);
case 1882195140: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -907096239: return bem_otherType_1(bevd_0);
case -1768544084: return bem_notEquals_1(bevd_0);
case -2122679297: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case -2000466836: return bem_keyEncoderSet_1(bevd_0);
case 1821362578: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case -1974306504: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 2116880036: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 2143817101: return bem_copyTo_1(bevd_0);
case -968521563: return bem_sameObject_1(bevd_0);
case -454090959: return bem_defined_1(bevd_0);
case 2130746153: return bem_serSet_1(bevd_0);
case -1859292781: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1030898412: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1425194636: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1465437715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -918533412: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1478053356: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1025227425: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2024613175: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1438061795: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 946142028: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_2_8_DbDirStore_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_8_DbDirStore_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_8_DbDirStore();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst = (BEC_2_2_8_DbDirStore) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_type;
}
}
}
