namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError : BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
static BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static new BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -553110251: return bem_nodeGet_0();
case 658678414: return bem_new_0();
case 380130546: return bem_framesTextGet_0();
case 1906010681: return bem_fileNameGet_0();
case 2087771877: return bem_echo_0();
case -457703447: return bem_deserializeClassNameGet_0();
case -475526252: return bem_lineNumberGetDirect_0();
case 1835544527: return bem_print_0();
case 1642251056: return bem_lineNumberGet_0();
case -1234233845: return bem_framesGetDirect_0();
case 624386533: return bem_serializeToString_0();
case 1625883206: return bem_klassNameGetDirect_0();
case 1972074436: return bem_msgGetDirect_0();
case 457529483: return bem_serializeContents_0();
case -2138893400: return bem_getFrameText_0();
case -2100313708: return bem_klassNameGet_0();
case -1713171190: return bem_descriptionGet_0();
case 795355831: return bem_translatedGetDirect_0();
case 1284640786: return bem_copy_0();
case -1354126741: return bem_tagGet_0();
case 1882696328: return bem_nodeGetDirect_0();
case 87072509: return bem_toAny_0();
case -97354710: return bem_translateEmittedExceptionInner_0();
case -711514807: return bem_sourceFileNameGet_0();
case -1922780248: return bem_iteratorGet_0();
case -696452086: return bem_descriptionGetDirect_0();
case 1292826719: return bem_translateEmittedException_0();
case 1219667479: return bem_framesGet_0();
case 635643285: return bem_framesTextGetDirect_0();
case 1467887775: return bem_fileNameGetDirect_0();
case -1510786404: return bem_vvGetDirect_0();
case -292945961: return bem_create_0();
case 615981380: return bem_fieldNamesGet_0();
case -1245187281: return bem_methodNameGetDirect_0();
case -1507484332: return bem_langGetDirect_0();
case 1581657281: return bem_langGet_0();
case 1878894995: return bem_classNameGet_0();
case -84103940: return bem_many_0();
case 1567557457: return bem_msgGet_0();
case 705946713: return bem_serializationIteratorGet_0();
case 937931160: return bem_emitLangGetDirect_0();
case 945522219: return bem_hashGet_0();
case -1725699695: return bem_fieldIteratorGet_0();
case 1855506680: return bem_toString_0();
case 1145763040: return bem_methodNameGet_0();
case -913601113: return bem_translatedGet_0();
case 1894283135: return bem_emitLangGet_0();
case 1039354445: return bem_vvGet_0();
case 1095611429: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -341234740: return bem_notEquals_1(bevd_0);
case 1250395697: return bem_lineNumberSetDirect_1(bevd_0);
case -1377332124: return bem_nodeSet_1(bevd_0);
case -533298553: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -925769480: return bem_klassNameSet_1(bevd_0);
case -1897607279: return bem_equals_1(bevd_0);
case -1582378530: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -935033767: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -531891039: return bem_vvSet_1(bevd_0);
case 465199415: return bem_sameClass_1(bevd_0);
case -1383533410: return bem_undef_1(bevd_0);
case 469297782: return bem_framesSet_1(bevd_0);
case 126395237: return bem_sameObject_1(bevd_0);
case 2011956224: return bem_descriptionSet_1(bevd_0);
case -1368724020: return bem_sameType_1(bevd_0);
case -569173731: return bem_methodNameSet_1(bevd_0);
case -1800729453: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -736525172: return bem_framesSetDirect_1(bevd_0);
case -423403148: return bem_framesTextSetDirect_1(bevd_0);
case 999215309: return bem_emitLangSet_1(bevd_0);
case -2103605908: return bem_langSetDirect_1(bevd_0);
case -1021438286: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1971460437: return bem_otherClass_1(bevd_0);
case -904319385: return bem_translatedSetDirect_1(bevd_0);
case -2091993192: return bem_translatedSet_1(bevd_0);
case 1666356834: return bem_methodNameSetDirect_1(bevd_0);
case 1185804072: return bem_vvSetDirect_1(bevd_0);
case 852549626: return bem_lineNumberSet_1(bevd_0);
case -754260669: return bem_def_1(bevd_0);
case -2109400999: return bem_copyTo_1(bevd_0);
case 40407923: return bem_msgSetDirect_1(bevd_0);
case -1551748546: return bem_undefined_1(bevd_0);
case 941882754: return bem_nodeSetDirect_1(bevd_0);
case -1742434048: return bem_fileNameSet_1(bevd_0);
case 1894284601: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1517775787: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -22414614: return bem_klassNameSetDirect_1(bevd_0);
case -586455400: return bem_defined_1(bevd_0);
case -783095700: return bem_langSet_1(bevd_0);
case 863868704: return bem_framesTextSet_1(bevd_0);
case 2059212473: return bem_fileNameSetDirect_1(bevd_0);
case -701846850: return bem_otherType_1(bevd_0);
case -881360802: return bem_msgSet_1(bevd_0);
case 243930935: return bem_descriptionSetDirect_1(bevd_0);
case 58606191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1990119237: return bem_emitLangSetDirect_1(bevd_0);
case -597509561: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1609990267: return bem_new_1(bevd_0);
case -656840793: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1810583739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1864186690: return bem_new_2(bevd_0, bevd_1);
case -687329733: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 703022748: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -871246707: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1013064550: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1390383369: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1845172722: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1180557769: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildEmitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
}
