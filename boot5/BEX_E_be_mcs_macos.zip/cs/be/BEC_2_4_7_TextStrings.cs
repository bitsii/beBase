namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_7_TextStrings : BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
static BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static new BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static new BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_space = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevp_quote = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_tab = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_cr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(-31114048);
bevt_1_ta_ph = bevl_i.bemd_0(-262847282);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1277736910);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1289*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1290*/
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(-894202533);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1294*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1294*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(-894202533);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1296*/
 else /* Line: 1294*/ {
break;
} /* Line: 1294*/
} /* Line: 1294*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_beg = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1306*/ {
bevt_0_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 1306*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_ta_ph = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_ta_ph.bevi_bool)/* Line: 1308*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1309*/ {
bevl_end.bevi_int++;
} /* Line: 1310*/
 else /* Line: 1311*/ {
bevl_beg.bevi_int++;
} /* Line: 1312*/
} /* Line: 1309*/
 else /* Line: 1314*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_ta_ph.bevi_int;
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1316*/
} /* Line: 1308*/
 else /* Line: 1306*/ {
break;
} /* Line: 1306*/
} /* Line: 1306*/
if (bevl_foundChar.bevi_bool)/* Line: 1319*/ {
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_ta_ph);
} /* Line: 1320*/
 else /* Line: 1321*/ {
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1322*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1328*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1328*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1328*/ {
return null;
} /* Line: 1328*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1334*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1334*/ {
bevl_ai.bemd_1(-1903992967, bevl_av);
bevl_bi.bemd_1(-1903992967, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1337*/ {
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1338*/
bevl_i.bevi_int++;
} /* Line: 1334*/
 else /* Line: 1334*/ {
break;
} /* Line: 1334*/
} /* Line: 1334*/
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(-31114048);
while (true)
/* Line: 1345*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-262847282);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1345*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-894202533);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1346*/ {
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1347*/
} /* Line: 1346*/
 else /* Line: 1345*/ {
break;
} /* Line: 1345*/
} /* Line: 1345*/
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1354*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1354*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1354*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1355*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
bevt_2_ta_ph = beva_value.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1361*/
 else /* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1361*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1362*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGetDirect_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGetDirect_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGetDirect_0() {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1263, 1264, 1265, 1265, 1266, 1266, 1267, 1268, 1270, 1270, 1271, 1272, 1273, 1274, 1277, 1278, 1279, 1280, 1284, 1284, 1288, 1289, 1289, 1290, 1290, 1292, 1293, 1293, 1294, 1295, 1296, 1296, 1298, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1310, 1312, 1315, 1315, 1316, 1320, 1320, 1320, 1322, 1324, 1328, 1328, 0, 1328, 1328, 0, 0, 1328, 1329, 1329, 1329, 1329, 1330, 1331, 1332, 1333, 1334, 1334, 1334, 1335, 1336, 1337, 1338, 1338, 1338, 1334, 1341, 1341, 1341, 1345, 0, 1345, 1345, 1346, 1347, 1347, 1350, 1350, 1354, 1354, 0, 1354, 1354, 1354, 1354, 0, 0, 1355, 1355, 1357, 1357, 1361, 1361, 1361, 1361, 0, 0, 0, 1362, 1362, 1364, 1364, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 61, 62, 73, 74, 75, 77, 78, 80, 81, 82, 85, 87, 88, 89, 95, 109, 110, 111, 112, 115, 117, 118, 121, 124, 128, 129, 130, 138, 139, 140, 143, 145, 166, 171, 172, 175, 180, 181, 184, 188, 190, 191, 192, 193, 194, 195, 196, 197, 198, 201, 206, 207, 208, 209, 211, 212, 213, 215, 221, 222, 223, 232, 232, 235, 237, 238, 240, 241, 248, 249, 259, 264, 265, 268, 269, 270, 275, 276, 279, 283, 284, 286, 287, 296, 301, 302, 303, 305, 308, 312, 315, 316, 318, 319, 322, 325, 328, 332, 336, 339, 342, 346, 350, 353, 356, 360, 364, 367, 370, 374, 378, 381, 384, 388, 392, 395, 398, 402, 406, 409, 412, 416, 420, 423, 426, 430, 434, 437, 440, 444, 448, 451, 454, 458, 462, 465, 468, 472, 476, 479, 482, 486};
/* BEGIN LINEINFO 
assign 1 1263 39
new 0 1263 39
assign 1 1264 40
new 0 1264 40
assign 1 1265 41
new 0 1265 41
assign 1 1265 42
codeNew 1 1265 42
assign 1 1266 43
new 0 1266 43
assign 1 1266 44
codeNew 1 1266 44
assign 1 1267 45
new 0 1267 45
assign 1 1268 46
new 0 1268 46
assign 1 1270 47
new 0 1270 47
assign 1 1270 48
codeNew 1 1270 48
assign 1 1271 49
new 0 1271 49
assign 1 1272 50
new 0 1272 50
assign 1 1273 51
new 1 1273 51
assign 1 1274 52
new 0 1274 52
put 1 1277 53
put 1 1278 54
put 1 1279 55
put 1 1280 56
assign 1 1284 61
joinBuffer 2 1284 61
return 1 1284 62
assign 1 1288 73
iteratorGet 0 1288 73
assign 1 1289 74
hasNextGet 0 1289 74
assign 1 1289 75
not 0 1289 75
assign 1 1290 77
new 0 1290 77
return 1 1290 78
assign 1 1292 80
new 0 1292 80
assign 1 1293 81
nextGet 0 1293 81
addValue 1 1293 82
assign 1 1294 85
hasNextGet 0 1294 85
addValue 1 1295 87
assign 1 1296 88
nextGet 0 1296 88
addValue 1 1296 89
return 1 1298 95
assign 1 1302 109
new 0 1302 109
assign 1 1303 110
new 0 1303 110
assign 1 1304 111
new 0 1304 111
assign 1 1305 112
mbiterGet 0 1305 112
assign 1 1306 115
hasNextGet 0 1306 115
assign 1 1307 117
nextGet 0 1307 117
assign 1 1308 118
has 1 1308 118
incrementValue 0 1310 121
incrementValue 0 1312 124
assign 1 1315 128
new 0 1315 128
setValue 1 1315 129
assign 1 1316 130
new 0 1316 130
assign 1 1320 138
sizeGet 0 1320 138
assign 1 1320 139
subtract 1 1320 139
assign 1 1320 140
substring 2 1320 140
assign 1 1322 143
new 0 1322 143
return 1 1324 145
assign 1 1328 166
undef 1 1328 171
assign 1 0 172
assign 1 1328 175
undef 1 1328 180
assign 1 0 181
assign 1 0 184
return 1 1328 188
assign 1 1329 190
new 0 1329 190
assign 1 1329 191
sizeGet 0 1329 191
assign 1 1329 192
sizeGet 0 1329 192
assign 1 1329 193
min 2 1329 193
assign 1 1330 194
biterGet 0 1330 194
assign 1 1331 195
biterGet 0 1331 195
assign 1 1332 196
new 0 1332 196
assign 1 1333 197
new 0 1333 197
assign 1 1334 198
new 0 1334 198
assign 1 1334 201
lesser 1 1334 206
next 1 1335 207
next 1 1336 208
assign 1 1337 209
notEquals 1 1337 209
assign 1 1338 211
new 0 1338 211
assign 1 1338 212
substring 2 1338 212
return 1 1338 213
incrementValue 0 1334 215
assign 1 1341 221
new 0 1341 221
assign 1 1341 222
substring 2 1341 222
return 1 1341 223
assign 1 1345 232
iteratorGet 0 0 232
assign 1 1345 235
hasNextGet 0 1345 235
assign 1 1345 237
nextGet 0 1345 237
assign 1 1346 238
isEmpty 1 1346 238
assign 1 1347 240
new 0 1347 240
return 1 1347 241
assign 1 1350 248
new 0 1350 248
return 1 1350 249
assign 1 1354 259
undef 1 1354 264
assign 1 0 265
assign 1 1354 268
sizeGet 0 1354 268
assign 1 1354 269
new 0 1354 269
assign 1 1354 270
lesser 1 1354 275
assign 1 0 276
assign 1 0 279
assign 1 1355 283
new 0 1355 283
return 1 1355 284
assign 1 1357 286
new 0 1357 286
return 1 1357 287
assign 1 1361 296
def 1 1361 301
assign 1 1361 302
new 0 1361 302
assign 1 1361 303
notEquals 1 1361 303
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 1362 315
new 0 1362 315
return 1 1362 316
assign 1 1364 318
new 0 1364 318
return 1 1364 319
return 1 0 322
return 1 0 325
assign 1 0 328
assign 1 0 332
return 1 0 336
return 1 0 339
assign 1 0 342
assign 1 0 346
return 1 0 350
return 1 0 353
assign 1 0 356
assign 1 0 360
return 1 0 364
return 1 0 367
assign 1 0 370
assign 1 0 374
return 1 0 378
return 1 0 381
assign 1 0 384
assign 1 0 388
return 1 0 392
return 1 0 395
assign 1 0 398
assign 1 0 402
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
return 1 0 434
return 1 0 437
assign 1 0 440
assign 1 0 444
return 1 0 448
return 1 0 451
assign 1 0 454
assign 1 0 458
return 1 0 462
return 1 0 465
assign 1 0 468
assign 1 0 472
return 1 0 476
return 1 0 479
assign 1 0 482
assign 1 0 486
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1029695809: return bem_echo_0();
case 1085102591: return bem_unixNewlineGetDirect_0();
case 728530586: return bem_quoteGetDirect_0();
case -1844917728: return bem_many_0();
case -2147096602: return bem_dosNewlineGetDirect_0();
case -348116924: return bem_newlineGetDirect_0();
case 1627438273: return bem_default_0();
case 12120440: return bem_spaceGetDirect_0();
case -1848718184: return bem_hashGet_0();
case -1902089216: return bem_toString_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -869995266: return bem_tabGet_0();
case 1166294930: return bem_lineSplitterGetDirect_0();
case 217968364: return bem_classNameGet_0();
case -8643043: return bem_serializeContents_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1248148986: return bem_emptyGet_0();
case -169391625: return bem_quoteGet_0();
case 854033662: return bem_wsGet_0();
case -479166709: return bem_tagGet_0();
case 1299809283: return bem_emptyGetDirect_0();
case -390956950: return bem_spaceGet_0();
case 1749799442: return bem_tabGetDirect_0();
case -1026733174: return bem_new_0();
case -785258946: return bem_create_0();
case 497350979: return bem_colonGetDirect_0();
case 1320284045: return bem_colonGet_0();
case 1688687204: return bem_serializeToString_0();
case -1440209026: return bem_lineSplitterGet_0();
case 1636589790: return bem_dosNewlineGet_0();
case 1452074508: return bem_crGetDirect_0();
case 1899821863: return bem_newlineGet_0();
case 126670515: return bem_toAny_0();
case 1137009070: return bem_once_0();
case 602901478: return bem_lfGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 1562608535: return bem_print_0();
case -2042317329: return bem_lfGetDirect_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 177667859: return bem_crGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 185174991: return bem_copy_0();
case 1041778627: return bem_unixNewlineGet_0();
case -31114048: return bem_iteratorGet_0();
case -1291945125: return bem_wsGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1811318132: return bem_defined_1(bevd_0);
case 1609351676: return bem_lineSplitterSetDirect_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 1868338350: return bem_wsSet_1(bevd_0);
case -2073164657: return bem_newlineSet_1(bevd_0);
case 1222542910: return bem_crSetDirect_1(bevd_0);
case 537568018: return bem_wsSetDirect_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case -856244850: return bem_lfSet_1(bevd_0);
case -953017493: return bem_quoteSetDirect_1(bevd_0);
case -460082402: return bem_colonSet_1(bevd_0);
case -196774779: return bem_spaceSetDirect_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 26348158: return bem_crSet_1(bevd_0);
case -444528337: return bem_unixNewlineSet_1(bevd_0);
case 1026422642: return bem_colonSetDirect_1(bevd_0);
case -939803381: return bem_newlineSetDirect_1(bevd_0);
case 1851550859: return bem_lineSplitterSet_1(bevd_0);
case 735517232: return bem_quoteSet_1(bevd_0);
case -1304637260: return bem_tabSetDirect_1(bevd_0);
case -327681238: return bem_emptySet_1(bevd_0);
case 1979520487: return bem_lfSetDirect_1(bevd_0);
case 1381620013: return bem_spaceSet_1(bevd_0);
case 523060319: return bem_emptySetDirect_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 210828038: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case -31692389: return bem_tabSet_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case 1178073448: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -386259652: return bem_dosNewlineSetDirect_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1893602822: return bem_unixNewlineSetDirect_1(bevd_0);
case -645527269: return bem_dosNewlineSet_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -951795390: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case -521197933: return bem_anyEmpty_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1262069438: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1616435040: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 316879312: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
}
