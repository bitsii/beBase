namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_6_DigestSHA256 : BEC_2_6_6_SystemObject {
public BEC_2_6_6_DigestSHA256() { }
static BEC_2_6_6_DigestSHA256() { }

    public SHA256Managed bevi_md; 
   private static byte[] becc_BEC_2_6_6_DigestSHA256_clname = {0x44,0x69,0x67,0x65,0x73,0x74,0x3A,0x53,0x48,0x41,0x32,0x35,0x36};
private static byte[] becc_BEC_2_6_6_DigestSHA256_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
public static new BEC_2_6_6_DigestSHA256 bece_BEC_2_6_6_DigestSHA256_bevs_inst;

public static new BET_2_6_6_DigestSHA256 bece_BEC_2_6_6_DigestSHA256_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {

        bevi_md = new SHA256Managed();
        return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_digest_1(BEC_2_4_6_TextString beva_with) {
BEC_2_4_6_TextString bevl_res = null;
bem_new_0();

        bevl_res = new BEC_2_4_6_TextString(
          bevi_md.ComputeHash(beva_with.bevi_bytes, 0, beva_with.bevp_size.bevi_int)
        );
        return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_digestToHex_1(BEC_2_4_6_TextString beva_input) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_3_EncodeHex bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevt_2_tmpany_phold = bem_digest_1(beva_input);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_encode_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {95, 110, 114, 114, 114, 114};
public static new int[] bevs_smnlec
 = new int[] {23, 28, 34, 35, 36, 37};
/* BEGIN LINEINFO 
new 0 95 23
return 1 110 28
assign 1 114 34
new 0 114 34
assign 1 114 35
digest 1 114 35
assign 1 114 36
encode 1 114 36
return 1 114 37
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 372560497: return bem_sourceFileNameGet_0();
case 1941027794: return bem_serializationIteratorGet_0();
case 526296627: return bem_create_0();
case 891560596: return bem_toAny_0();
case -1435074057: return bem_tagGet_0();
case 463617467: return bem_once_0();
case 58718604: return bem_echo_0();
case -1664007235: return bem_fieldIteratorGet_0();
case 966788565: return bem_serializeContents_0();
case 1820222231: return bem_print_0();
case -2038208379: return bem_hashGet_0();
case 2109118158: return bem_toString_0();
case -375288944: return bem_deserializeClassNameGet_0();
case -1621033763: return bem_classNameGet_0();
case -378593941: return bem_serializeToString_0();
case 1410581559: return bem_new_0();
case -1388693079: return bem_iteratorGet_0();
case 39762284: return bem_copy_0();
case -1695576573: return bem_fieldNamesGet_0();
case -50050173: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1854916705: return bem_sameClass_1(bevd_0);
case 422542432: return bem_defined_1(bevd_0);
case -413408753: return bem_otherClass_1(bevd_0);
case -1455520849: return bem_undef_1(bevd_0);
case -1511698342: return bem_notEquals_1(bevd_0);
case 1150415934: return bem_sameType_1(bevd_0);
case -490319654: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2051460262: return bem_def_1(bevd_0);
case -1888157551: return bem_digest_1((BEC_2_4_6_TextString) bevd_0);
case -287873339: return bem_sameObject_1(bevd_0);
case -2033353560: return bem_digestToHex_1((BEC_2_4_6_TextString) bevd_0);
case -1562713873: return bem_equals_1(bevd_0);
case -1812079184: return bem_otherType_1(bevd_0);
case 2087226838: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 463884319: return bem_copyTo_1(bevd_0);
case -583057928: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 328764114: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1251230934: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1460908619: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1199360949: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -122254137: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1589994776: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1766146489: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1661600038: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90070391: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_DigestSHA256_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_DigestSHA256_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_DigestSHA256();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_inst = (BEC_2_6_6_DigestSHA256) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_DigestSHA256.bece_BEC_2_6_6_DigestSHA256_bevs_type;
}
}
}
