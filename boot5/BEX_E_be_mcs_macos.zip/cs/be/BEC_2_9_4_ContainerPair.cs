namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_4_ContainerPair : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerPair() { }
static BEC_2_9_4_ContainerPair() { }
private static byte[] becc_BEC_2_9_4_ContainerPair_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x50,0x61,0x69,0x72};
private static byte[] becc_BEC_2_9_4_ContainerPair_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_inst;

public static new BET_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_type;

public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_6_6_SystemObject bevp_second;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_new_2(BEC_2_6_6_SystemObject beva__first, BEC_2_6_6_SystemObject beva__second) {
bevp_first = beva__first;
bevp_second = beva__second;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
return bevp_first;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGetDirect_0() {
return bevp_first;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_secondGet_0() {
return bevp_second;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGetDirect_0() {
return bevp_second;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_secondSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_second = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_secondSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_second = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {32, 33, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 23, 26, 29, 33, 37, 40, 43, 47};
/* BEGIN LINEINFO 
assign 1 32 18
assign 1 33 19
return 1 0 23
return 1 0 26
assign 1 0 29
assign 1 0 33
return 1 0 37
return 1 0 40
assign 1 0 43
assign 1 0 47
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -963755335: return bem_fieldIteratorGet_0();
case -1004079418: return bem_once_0();
case -1108167878: return bem_serializeToString_0();
case 1603326601: return bem_many_0();
case -1753588576: return bem_firstGetDirect_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -469171007: return bem_serializeContents_0();
case -545958368: return bem_toAny_0();
case -632169362: return bem_print_0();
case -2048609488: return bem_tagGet_0();
case -212376625: return bem_iteratorGet_0();
case 1909096874: return bem_create_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case 1419414154: return bem_new_0();
case 2077040828: return bem_copy_0();
case -1767320597: return bem_firstGet_0();
case 429419643: return bem_echo_0();
case 784183653: return bem_secondGetDirect_0();
case 1730620110: return bem_serializationIteratorGet_0();
case 1741010261: return bem_classNameGet_0();
case -1918539521: return bem_toString_0();
case -811598956: return bem_fieldNamesGet_0();
case -716635724: return bem_secondGet_0();
case 1687921048: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1434304379: return bem_otherType_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case -1957308438: return bem_firstSet_1(bevd_0);
case -363168387: return bem_sameType_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case -44910487: return bem_secondSet_1(bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case 795883547: return bem_firstSetDirect_1(bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case 1369032206: return bem_secondSetDirect_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1339848514: return bem_new_2(bevd_0, bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerPair_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_4_ContainerPair_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerPair();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst = (BEC_2_9_4_ContainerPair) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_type;
}
}
}
