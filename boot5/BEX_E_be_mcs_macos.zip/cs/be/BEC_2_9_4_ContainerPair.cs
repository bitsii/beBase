namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_4_ContainerPair : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerPair() { }
static BEC_2_9_4_ContainerPair() { }
private static byte[] becc_BEC_2_9_4_ContainerPair_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x50,0x61,0x69,0x72};
private static byte[] becc_BEC_2_9_4_ContainerPair_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_inst;

public static new BET_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_type;

public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_6_6_SystemObject bevp_second;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_new_2(BEC_2_6_6_SystemObject beva__first, BEC_2_6_6_SystemObject beva__second) {
bevp_first = beva__first;
bevp_second = beva__second;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
return bevp_first;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGetDirect_0() {
return bevp_first;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_firstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_first = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_secondGet_0() {
return bevp_second;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secondGetDirect_0() {
return bevp_second;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_secondSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_second = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_secondSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_second = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {31, 32, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 23, 26, 29, 33, 37, 40, 43, 47};
/* BEGIN LINEINFO 
assign 1 31 18
assign 1 32 19
return 1 0 23
return 1 0 26
assign 1 0 29
assign 1 0 33
return 1 0 37
return 1 0 40
assign 1 0 43
assign 1 0 47
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1499227601: return bem_secondGet_0();
case 1688687204: return bem_serializeToString_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1029695809: return bem_echo_0();
case -479166709: return bem_tagGet_0();
case -1830055514: return bem_firstGetDirect_0();
case 126670515: return bem_toAny_0();
case -1902089216: return bem_toString_0();
case -1844917728: return bem_many_0();
case -1779062531: return bem_serializationIteratorGet_0();
case 1562608535: return bem_print_0();
case -1148520836: return bem_firstGet_0();
case -8643043: return bem_serializeContents_0();
case -785258946: return bem_create_0();
case -31114048: return bem_iteratorGet_0();
case 819336751: return bem_secondGetDirect_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 217968364: return bem_classNameGet_0();
case 1137009070: return bem_once_0();
case -1026733174: return bem_new_0();
case -1725405782: return bem_sourceFileNameGet_0();
case -1848718184: return bem_hashGet_0();
case 185174991: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 1802073945: return bem_secondSet_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1355907126: return bem_secondSetDirect_1(bevd_0);
case 1795758742: return bem_firstSet_1(bevd_0);
case 639904291: return bem_firstSetDirect_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 497465062: return bem_new_2(bevd_0, bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerPair_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_4_ContainerPair_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerPair();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst = (BEC_2_9_4_ContainerPair) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_type;
}
}
}
