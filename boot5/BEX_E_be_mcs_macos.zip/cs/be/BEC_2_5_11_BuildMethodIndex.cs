namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_11_BuildMethodIndex : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildMethodIndex() { }
static BEC_2_5_11_BuildMethodIndex() { }
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;

public static new BET_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_type;

public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildMtdSyn bevp_msyn;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_11_BuildMethodIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildMtdSyn beva__msyn) {
bevp_syn = beva__syn;
bevp_msyn = beva__msyn;
bevp_declaration = bevp_msyn.bem_declarationGet_0();
bevp_name = bevp_msyn.bem_nameGet_0();
return this;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_declaration.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_4_tmpany_phold = bem_sameClass_1(beva_x);
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 111 */
bevt_7_tmpany_phold = beva_x.bemd_0(377609954);
bevt_6_tmpany_phold = bevp_declaration.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_9_tmpany_phold = beva_x.bemd_0(-1547082045);
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 112 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 112 */
 else  /* Line: 112 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 112 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 113 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_msynGet_0() {
return bevp_msyn;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_msynGetDirect_0() {
return bevp_msyn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_msynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_msynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() {
return bevp_declaration;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGetDirect_0() {
return bevp_declaration;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_declarationSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {99, 100, 101, 102, 107, 107, 107, 107, 111, 111, 0, 111, 111, 111, 0, 0, 111, 111, 112, 112, 112, 112, 0, 0, 0, 113, 113, 115, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 27, 28, 29, 30, 45, 50, 51, 54, 55, 60, 61, 64, 68, 69, 71, 72, 74, 75, 77, 80, 84, 87, 88, 90, 91, 94, 97, 100, 104, 108, 111, 114, 118, 122, 125, 128, 132, 136, 139, 142, 146};
/* BEGIN LINEINFO 
assign 1 99 17
assign 1 100 18
assign 1 101 19
declarationGet 0 101 19
assign 1 102 20
nameGet 0 102 20
assign 1 107 27
toString 0 107 27
assign 1 107 28
add 1 107 28
assign 1 107 29
hashGet 0 107 29
return 1 107 30
assign 1 111 45
undef 1 111 50
assign 1 0 51
assign 1 111 54
sameClass 1 111 54
assign 1 111 55
not 0 111 60
assign 1 0 61
assign 1 0 64
assign 1 111 68
new 0 111 68
return 1 111 69
assign 1 112 71
declarationGet 0 112 71
assign 1 112 72
equals 1 112 72
assign 1 112 74
nameGet 0 112 74
assign 1 112 75
equals 1 112 75
assign 1 0 77
assign 1 0 80
assign 1 0 84
assign 1 113 87
new 0 113 87
return 1 113 88
assign 1 115 90
new 0 115 90
return 1 115 91
return 1 0 94
return 1 0 97
assign 1 0 100
assign 1 0 104
return 1 0 108
return 1 0 111
assign 1 0 114
assign 1 0 118
return 1 0 122
return 1 0 125
assign 1 0 128
assign 1 0 132
return 1 0 136
return 1 0 139
assign 1 0 142
assign 1 0 146
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2055997260: return bem_fieldIteratorGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -323661464: return bem_serializeToString_0();
case -898522649: return bem_msynGet_0();
case 1064677251: return bem_many_0();
case -2092760709: return bem_once_0();
case 1076647192: return bem_create_0();
case 849387251: return bem_toAny_0();
case -1430066973: return bem_print_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -1654552861: return bem_msynGetDirect_0();
case 864393987: return bem_tagGet_0();
case 605836827: return bem_sourceFileNameGet_0();
case 1359360249: return bem_echo_0();
case -165350472: return bem_nameGetDirect_0();
case -236887613: return bem_classNameGet_0();
case -1369483363: return bem_fieldNamesGet_0();
case 1889367965: return bem_synGet_0();
case 2070502838: return bem_copy_0();
case -1852877275: return bem_new_0();
case -1547082045: return bem_nameGet_0();
case 377609954: return bem_declarationGet_0();
case 928457034: return bem_serializeContents_0();
case 996718380: return bem_toString_0();
case 1372644764: return bem_hashGet_0();
case -1927128434: return bem_declarationGetDirect_0();
case -842207018: return bem_iteratorGet_0();
case -458457494: return bem_synGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -960159496: return bem_otherClass_1(bevd_0);
case 653158270: return bem_msynSet_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 1770414039: return bem_nameSetDirect_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case 438113542: return bem_nameSet_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 177979611: return bem_msynSetDirect_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -483693322: return bem_synSetDirect_1(bevd_0);
case -897522927: return bem_declarationSetDirect_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 727113733: return bem_synSet_1(bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
case 438783048: return bem_declarationSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 67877554: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildMtdSyn) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildMethodIndex_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_11_BuildMethodIndex_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildMethodIndex();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst = (BEC_2_5_11_BuildMethodIndex) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_type;
}
}
}
