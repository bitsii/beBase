namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_10, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_55, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_58, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_59, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_62, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_65, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 41));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 41));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
 else  /* Line: 99 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 99 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 100 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 118 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 118 */
 else  /* Line: 118 */ {
break;
} /* Line: 118 */
} /* Line: 118 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 127 */ {
bem_config_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 131 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1963695386);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 136 */
if (bevp_printSteps.bevi_bool) /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 138 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 139 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(300088773);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1949406125, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 145 */ {
} /* Line: 145 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_4_6_TextString bevt_114_tmpany_phold = null;
BEC_2_4_6_TextString bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_123_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_124_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_126_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_130_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_131_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_7_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_7_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 156 */ {
bevt_8_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 156 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1949384208);
bevt_10_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_tmpany_phold);
} /* Line: 159 */
} /* Line: 157 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
} /* Line: 156 */
bevt_14_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_nameGet_0();
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_equals_1(bevt_15_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 164 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 165 */
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_12));
bevt_16_tmpany_phold = bevp_params.bem_get_1(bevt_17_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_firstGet_0();
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_18_tmpany_phold = bevp_params.bem_has_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_20_tmpany_phold = bevp_params.bem_get_1(bevt_21_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_firstGet_0();
} /* Line: 169 */
 else  /* Line: 170 */ {
bevp_exeName = bevp_libName;
} /* Line: 171 */
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_24_tmpany_phold = bevp_params.bem_get_2(bevt_25_tmpany_phold, bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_firstGet_0();
bevt_22_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_tmpany_phold);
bevp_buildPath = bevt_22_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevp_buildPath.bem_addStep_1(bevt_27_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_30_tmpany_phold = bevp_params.bem_get_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_firstGet_0();
bevt_28_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_tmpany_phold);
bevp_includePath = bevt_28_tmpany_phold.bem_pathGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_18));
bevt_37_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_nameGet_0();
bevt_34_tmpany_phold = bevp_params.bem_get_2(bevt_35_tmpany_phold, bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_tmpany_phold );
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_41_tmpany_phold = bevp_platform.bemd_0(300088773);
bevt_39_tmpany_phold = bevp_params.bem_get_2(bevt_40_tmpany_phold, (BEC_2_4_6_TextString) bevt_41_tmpany_phold );
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_tmpany_phold );
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_43_tmpany_phold = bevp_params.bem_get_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_47_tmpany_phold = bevp_params.bem_get_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_51_tmpany_phold = bevp_params.bem_get_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevp_loadSyns = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_26));
bevp_initLibs = bevp_params.bem_get_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_56_tmpany_phold = bevp_params.bem_get_1(bevt_57_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_56_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_58_tmpany_phold = bevp_params.bem_get_1(bevt_59_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_58_tmpany_phold.bem_firstGet_0();
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_60_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_62_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_64_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_66_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_67_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_67_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_67_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_extIncludes = bevp_params.bem_get_1(bevt_68_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_70_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_71_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_71_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 208 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extLibs = bevp_params.bem_get_1(bevt_72_tmpany_phold);
if (bevp_extLibs == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_74_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_75_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_76_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_77_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_77_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_78_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_79_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-356420282);
} /* Line: 225 */
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_runArgs = bevp_params.bem_get_1(bevt_80_tmpany_phold);
if (bevp_runArgs == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-356420282);
} /* Line: 229 */
 else  /* Line: 230 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 231 */
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_40));
bevt_83_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_82_tmpany_phold, bevt_83_tmpany_phold);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_41));
bevt_85_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_84_tmpany_phold, bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_87_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_44));
bevl_pacm = bevp_params.bem_get_1(bevt_88_tmpany_phold);
if (bevl_pacm == null) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_91_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_91_tmpany_phold.bevi_bool) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_92_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 240 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 241 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_run = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_96_tmpany_phold);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_49));
bevt_98_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_97_tmpany_phold, bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_emitLangs = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_emitFlags = bevp_params.bem_get_1(bevt_100_tmpany_phold);
bevp_emitChecks = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevt_2_tmpany_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 253 */ {
bevt_102_tmpany_phold = bevt_2_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_102_tmpany_phold).bevi_bool) /* Line: 253 */ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 255 */
 else  /* Line: 253 */ {
break;
} /* Line: 253 */
} /* Line: 253 */
} /* Line: 253 */
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_108_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_108_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevt_111_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_110_tmpany_phold = bevt_111_tmpany_phold.bem_add_1(bevp_makeName);
bevt_112_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_109_tmpany_phold = bevp_params.bem_get_2(bevt_110_tmpany_phold, bevt_112_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_109_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 269 */
 else  /* Line: 270 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_57));
} /* Line: 271 */
bevt_116_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_115_tmpany_phold = bevl_outLang.bem_add_1(bevt_116_tmpany_phold);
bevt_117_tmpany_phold = bevp_platform.bemd_0(300088773);
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bem_add_1(bevt_117_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_114_tmpany_phold);
if (bevl_platformSources == null) {
bevt_118_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_118_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevt_119_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_119_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 280 */
bevt_121_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_120_tmpany_phold = bevl_outLang.bem_add_1(bevt_121_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_120_tmpany_phold);
if (bevl_langSources == null) {
bevt_122_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_123_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_123_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 285 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_124_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_3_tmpany_loop = bevt_124_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 289 */ {
bevt_125_tmpany_phold = bevt_3_tmpany_loop.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_125_tmpany_phold).bevi_bool) /* Line: 289 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_tmpany_loop.bemd_0(1949384208);
bevt_126_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_126_tmpany_phold);
} /* Line: 290 */
 else  /* Line: 289 */ {
break;
} /* Line: 289 */
} /* Line: 289 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-1384571420);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_129_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_128_tmpany_phold = bevt_129_tmpany_phold.bem_existsGet_0();
if (bevt_128_tmpany_phold.bevi_bool) {
bevt_127_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_127_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_130_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_130_tmpany_phold.bem_makeDirs_0();
} /* Line: 298 */
if (bevp_emitFileHeader == null) {
bevt_131_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_131_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_131_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_132_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_132_tmpany_phold.bem_readerGet_0();
bevt_133_tmpany_phold = bevl_emr.bemd_0(-1441323027);
bevp_emitFileHeader = bevt_133_tmpany_phold.bemd_0(-1560679003);
bevl_emr.bemd_0(-358309902);
} /* Line: 303 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(-1136298158, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_60));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1136298158, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(-1136298158, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(-1136298158, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(-1136298158, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(-1136298158, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_clnode = bevl_ci.bemd_0(1949384208);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(2102127943);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1142074911);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(2102127943);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(565636739);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1963695386);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(2102127943);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(565636739);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1963695386);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 323 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 324 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
} /* Line: 323 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(2102127943);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(565636739);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1963695386);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 330 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 328 */
} /* Line: 319 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 335 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 335 */ {
bevl_clnode = bevl_ci.bemd_0(1949384208);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(2102127943);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(2102127943);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(565636739);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(1963695386);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(-482201625, bevt_26_tmpany_phold);
} /* Line: 337 */
 else  /* Line: 335 */ {
break;
} /* Line: 335 */
} /* Line: 335 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 348 */ {
return bevp_emitCommon;
} /* Line: 349 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 354 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 356 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 357 */
 else  /* Line: 356 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 358 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 359 */
 else  /* Line: 356 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 360 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 361 */
 else  /* Line: 356 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 362 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 363 */
 else  /* Line: 366 */ {
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_10_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 367 */
} /* Line: 356 */
} /* Line: 356 */
} /* Line: 356 */
return bevp_emitCommon;
} /* Line: 369 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(-1441323027);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 392 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 393 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 394 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
} /* Line: 393 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 401 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 402 */
} /* Line: 401 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(1776712568);
while (true)
 /* Line: 407 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 407 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(1949384208);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 408 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 411 */
} /* Line: 408 */
 else  /* Line: 407 */ {
break;
} /* Line: 407 */
} /* Line: 407 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(1776712568);
while (true)
 /* Line: 414 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 414 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(1949384208);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-2119901542);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 419 */
} /* Line: 415 */
 else  /* Line: 414 */ {
break;
} /* Line: 414 */
} /* Line: 414 */
if (bevp_parse.bevi_bool) /* Line: 422 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 425 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 425 */ {
bevl_tb = bevl_i.bemd_0(1949384208);
bevt_20_tmpany_phold = bevl_tb.bemd_0(1963695386);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 428 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(1963695386);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 430 */
} /* Line: 428 */
 else  /* Line: 425 */ {
break;
} /* Line: 425 */
} /* Line: 425 */
bem_buildSyns_1(bevl_em);
} /* Line: 433 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 448 */
if (bevp_doEmit.bevi_bool) /* Line: 450 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(629014894);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 454 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 454 */ {
bevl_clnode = bevl_ci.bemd_0(1949384208);
bevl_em.bemd_1(-11238298, bevl_clnode);
} /* Line: 456 */
 else  /* Line: 454 */ {
break;
} /* Line: 454 */
} /* Line: 454 */
bevl_em.bemd_0(-1798772512);
bevl_em.bemd_0(-255909822);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 460 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 460 */ {
bevl_clnode = bevl_ci.bemd_0(1949384208);
bevl_em.bemd_1(47488842, bevl_clnode);
} /* Line: 462 */
 else  /* Line: 460 */ {
break;
} /* Line: 460 */
} /* Line: 460 */
} /* Line: 460 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 468 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 471 */ {
bevl_em.bemd_1(-1581107972, bevp_deployLibrary);
} /* Line: 473 */
if (bevp_make.bevi_bool) /* Line: 476 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 477 */ {
bevl_em.bemd_1(2100611889, bevp_deployLibrary);
bevl_em.bemd_1(677874685, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 480 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 481 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 481 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(629014894);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(-1720878725);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(637007010);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1556755195);
bevl_cpTo.bemd_1(-123480177, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-483272572);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 485 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevt_58_tmpany_phold.bemd_0(1127067698);
} /* Line: 486 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-483272572);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(1877521898);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 488 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-186862484);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevl_em.bemd_2(-1496201494, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 489 */
} /* Line: 488 */
 else  /* Line: 481 */ {
break;
} /* Line: 481 */
} /* Line: 481 */
} /* Line: 481 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 496 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 496 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 496 */
 else  /* Line: 496 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 496 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(1949384208);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(1949384208);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-483272572);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 500 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevt_76_tmpany_phold.bemd_0(1127067698);
} /* Line: 501 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(-483272572);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(1877521898);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 503 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-186862484);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-186862484);
bevl_em.bemd_2(-1496201494, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 504 */
} /* Line: 503 */
 else  /* Line: 496 */ {
break;
} /* Line: 496 */
} /* Line: 496 */
} /* Line: 496 */
} /* Line: 477 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 512 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 514 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 515 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 517 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 518 */
if (bevp_run.bevi_bool) /* Line: 521 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-1399283928, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 525 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 531 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 531 */ {
bevl_kls = bevl_ci.bemd_0(1949384208);
bevt_2_tmpany_phold = bevl_kls.bemd_0(2102127943);
bevt_2_tmpany_phold.bemd_1(-661339921, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-661339921, bevp_libName);
} /* Line: 535 */
 else  /* Line: 531 */ {
break;
} /* Line: 531 */
} /* Line: 531 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 537 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 537 */ {
bevl_kls = bevl_ci.bemd_0(1949384208);
bevt_5_tmpany_phold = bevl_kls.bemd_0(2102127943);
bevl_syn = bevt_5_tmpany_phold.bemd_0(-2141562882);
bevl_syn.bemd_2(-468614659, this, bevl_kls);
bevl_syn.bemd_1(-696910703, this);
} /* Line: 541 */
 else  /* Line: 537 */ {
break;
} /* Line: 537 */
} /* Line: 537 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(-2141562882);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-2141562882);
return bevt_3_tmpany_phold;
} /* Line: 548 */
bevt_5_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_5_tmpany_phold.bemd_1(-661339921, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(-32553880);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 551 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 552 */
 else  /* Line: 553 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-32553880);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1963695386);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 556 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(2102127943);
bevt_14_tmpany_phold.bemd_1(-661339921, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 558 */
 else  /* Line: 559 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-32553880);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 562 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 564 */
bevt_17_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_17_tmpany_phold.bemd_1(803033560, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(2102127943);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(565636739);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1963695386);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(1963695386);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 574 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 575 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(594111758, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 590 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 591 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 604 */ {
if (bevp_printSteps.bevi_bool) /* Line: 605 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 605 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 605 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 605 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 605 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 605 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_tmpany_phold = beva_toParse.bemd_0(1963695386);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 606 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-186862484);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(2067953645);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1441323027);
bevl_src = bevt_6_tmpany_phold.bemd_1(-150356515, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-186862484);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(2067953645);
bevt_9_tmpany_phold.bemd_0(-358309902);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 617 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 618 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(-199343094);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 621 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_14_tmpany_phold);
} /* Line: 623 */
if (bevp_printSteps.bevi_bool) /* Line: 626 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 627 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(1009609587, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 630 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_18_tmpany_phold);
} /* Line: 632 */
if (bevp_printSteps.bevi_bool) /* Line: 634 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 635 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(1009609587, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-1306720325);
if (bevp_printAllAst.bevi_bool) /* Line: 640 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_22_tmpany_phold);
} /* Line: 642 */
if (bevp_printSteps.bevi_bool) /* Line: 645 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 646 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(1009609587, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 649 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_26_tmpany_phold);
} /* Line: 651 */
if (bevp_printSteps.bevi_bool) /* Line: 654 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 655 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(1009609587, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 658 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_30_tmpany_phold);
} /* Line: 660 */
if (bevp_printSteps.bevi_bool) /* Line: 663 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 664 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(1009609587, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 667 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_34_tmpany_phold);
} /* Line: 669 */
if (bevp_printSteps.bevi_bool) /* Line: 672 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 673 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(1009609587, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 676 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_38_tmpany_phold);
} /* Line: 678 */
if (bevp_printSteps.bevi_bool) /* Line: 681 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 682 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(1009609587, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 685 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_42_tmpany_phold);
} /* Line: 687 */
if (bevp_printSteps.bevi_bool) /* Line: 690 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 691 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(1009609587, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 694 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_46_tmpany_phold);
} /* Line: 696 */
if (bevp_printSteps.bevi_bool) /* Line: 699 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 700 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(1009609587, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 703 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_50_tmpany_phold);
} /* Line: 705 */
if (bevp_printSteps.bevi_bool) /* Line: 707 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 708 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(1009609587, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 711 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_54_tmpany_phold);
} /* Line: 713 */
if (bevp_printSteps.bevi_bool) /* Line: 716 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 718 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(1009609587, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 721 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 721 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 721 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 721 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 721 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 721 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(1009609587, bevt_59_tmpany_phold);
} /* Line: 723 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 725 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(1931751520);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 725 */ {
bevl_clnode = bevl_ci.bemd_0(1949384208);
bevl_tunode = bevl_clnode.bemd_0(1271391834);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-901005709, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(2102127943);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1055679097);
bevl_ntt.bemd_1(-60418841, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(-957086007, bevl_ntt);
bevl_clnode.bemd_0(1127067698);
bevl_ntunode.bemd_1(1537835, bevl_clnode);
bevl_ntunode.bemd_1(-1868549971, bevl_clnode);
} /* Line: 736 */
 else  /* Line: 725 */ {
break;
} /* Line: 725 */
} /* Line: 725 */
} /* Line: 725 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(1247246480);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(2088390349);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 746 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 746 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(-957086007, bevt_2_tmpany_phold);
bevl_node.bemd_1(958903691, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(2102127943);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1949406125, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 750 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 751 */
bevt_6_tmpany_phold = bevl_node.bemd_0(2102127943);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(674421585, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 753 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-2073744340, beva_parnode);
} /* Line: 755 */
} /* Line: 753 */
 else  /* Line: 746 */ {
break;
} /* Line: 746 */
} /* Line: 746 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-662872016, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-901005709, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(-957086007, bevl_nlnp);
bevl_nlnpn.bemd_1(-1868549971, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevl_nlc.bemd_1(331561059, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(896206598, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-559981011, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(147022717, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(157185108, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(2102127943);
bevl_nlc.bemd_1(-111122837, bevt_11_tmpany_phold);
beva_node.bemd_1(1537835, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-901005709, bevt_12_tmpany_phold);
beva_node.bemd_1(-957086007, bevl_nlc);
bevl_nlnpn.bemd_0(-29610592);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_103));
bevt_13_tmpany_phold = beva_tName.bemd_1(1949406125, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 785 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 785 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_104));
bevt_15_tmpany_phold = beva_tName.bemd_1(1949406125, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 785 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 785 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 785 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 785 */ {
bevl_pn = beva_node.bemd_0(-2084600888);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 787 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(671769530);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1949406125, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 787 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 787 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(671769530);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1949406125, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 787 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 787 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 787 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 787 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 787 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 787 */
 else  /* Line: 787 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 787 */ {
bevl_pn2 = bevl_pn.bemd_0(-2084600888);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 789 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 789 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(671769530);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(674421585, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 789 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(671769530);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(674421585, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 789 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 789 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 789 */
 else  /* Line: 789 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 789 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(671769530);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(674421585, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 789 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 789 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 789 */
 else  /* Line: 789 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 789 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(671769530);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(674421585, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 789 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 789 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 789 */
 else  /* Line: 789 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 789 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 789 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 789 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 789 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(2102127943);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(1233176815);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(-1136298158, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(-111122837, bevt_37_tmpany_phold);
bevl_pn.bemd_0(1127067698);
} /* Line: 796 */
} /* Line: 789 */
} /* Line: 787 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGetDirect_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 88, 89, 90, 91, 92, 92, 99, 99, 99, 99, 0, 99, 99, 0, 0, 0, 0, 0, 100, 100, 102, 102, 106, 106, 106, 106, 110, 110, 111, 111, 111, 115, 116, 117, 117, 117, 117, 117, 118, 118, 118, 119, 118, 121, 125, 126, 128, 129, 130, 131, 133, 134, 135, 135, 136, 0, 0, 0, 139, 141, 145, 145, 145, 147, 152, 154, 155, 155, 155, 156, 156, 0, 156, 156, 157, 157, 157, 158, 159, 159, 164, 164, 164, 164, 165, 167, 167, 167, 168, 168, 169, 169, 169, 171, 173, 173, 173, 173, 173, 173, 174, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 183, 183, 185, 185, 185, 186, 186, 186, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 233, 233, 233, 234, 234, 234, 235, 235, 236, 236, 237, 238, 238, 239, 239, 239, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 244, 244, 245, 245, 246, 246, 247, 247, 248, 248, 248, 249, 249, 250, 250, 251, 252, 252, 253, 0, 253, 253, 255, 258, 258, 258, 258, 259, 259, 259, 259, 260, 260, 260, 260, 260, 261, 262, 263, 264, 265, 268, 268, 269, 271, 278, 278, 278, 278, 278, 279, 279, 280, 280, 283, 283, 283, 284, 284, 285, 285, 288, 289, 289, 0, 289, 289, 290, 290, 292, 293, 294, 296, 297, 297, 297, 297, 298, 298, 300, 300, 301, 301, 302, 302, 303, 309, 310, 310, 310, 310, 310, 311, 311, 311, 311, 311, 312, 316, 317, 317, 317, 318, 319, 319, 319, 319, 320, 320, 320, 320, 321, 321, 321, 321, 321, 322, 322, 323, 0, 323, 323, 324, 327, 327, 327, 327, 327, 328, 328, 329, 0, 329, 329, 330, 335, 335, 335, 336, 337, 337, 337, 337, 337, 337, 344, 344, 348, 348, 349, 354, 354, 355, 356, 356, 357, 358, 358, 359, 360, 360, 361, 362, 362, 363, 367, 367, 367, 369, 371, 375, 377, 377, 377, 378, 378, 379, 379, 379, 380, 380, 381, 382, 382, 383, 383, 383, 384, 384, 384, 390, 390, 391, 392, 392, 393, 0, 393, 393, 394, 397, 398, 398, 399, 400, 402, 402, 402, 405, 407, 0, 407, 407, 408, 408, 408, 409, 410, 411, 414, 0, 414, 414, 415, 415, 415, 416, 417, 418, 419, 419, 424, 425, 425, 426, 428, 428, 429, 429, 430, 433, 436, 436, 436, 439, 439, 439, 441, 441, 442, 442, 443, 443, 443, 444, 444, 444, 445, 445, 445, 446, 446, 446, 447, 447, 447, 448, 448, 451, 452, 454, 454, 454, 455, 456, 458, 459, 460, 460, 460, 461, 462, 466, 466, 466, 467, 467, 468, 468, 468, 470, 470, 470, 473, 477, 477, 478, 479, 481, 0, 481, 481, 482, 482, 483, 483, 484, 484, 484, 485, 485, 486, 486, 488, 488, 488, 489, 489, 489, 493, 494, 496, 496, 0, 0, 0, 497, 497, 498, 498, 498, 498, 498, 498, 498, 498, 500, 500, 501, 501, 503, 503, 503, 504, 504, 504, 509, 509, 509, 511, 511, 512, 512, 512, 514, 514, 515, 515, 515, 517, 517, 518, 518, 518, 522, 522, 523, 524, 524, 524, 524, 524, 525, 527, 527, 531, 531, 531, 532, 533, 533, 534, 535, 537, 537, 537, 538, 539, 539, 540, 541, 543, 543, 547, 547, 547, 547, 548, 548, 548, 550, 550, 551, 551, 551, 551, 552, 554, 554, 554, 554, 554, 556, 556, 557, 557, 558, 562, 562, 562, 564, 566, 566, 567, 567, 567, 567, 568, 572, 573, 573, 574, 574, 575, 581, 581, 582, 583, 590, 590, 591, 593, 598, 599, 600, 601, 602, 603, 603, 0, 0, 0, 606, 606, 606, 606, 608, 610, 610, 610, 610, 611, 611, 611, 614, 618, 618, 620, 620, 622, 622, 623, 623, 627, 627, 629, 629, 631, 631, 632, 632, 635, 635, 638, 638, 639, 641, 641, 642, 642, 646, 646, 648, 648, 650, 650, 651, 651, 655, 655, 657, 657, 659, 659, 660, 660, 664, 664, 666, 666, 668, 668, 669, 669, 673, 673, 675, 675, 677, 677, 678, 678, 682, 682, 684, 684, 686, 686, 687, 687, 691, 691, 693, 693, 695, 695, 696, 696, 700, 700, 702, 702, 704, 704, 705, 705, 708, 708, 710, 710, 712, 712, 713, 713, 717, 717, 718, 718, 720, 720, 0, 0, 0, 722, 722, 723, 723, 725, 725, 725, 726, 728, 729, 730, 730, 731, 732, 732, 732, 733, 734, 735, 736, 742, 743, 744, 745, 745, 746, 746, 747, 748, 748, 749, 750, 750, 751, 753, 753, 754, 755, 762, 763, 765, 766, 766, 767, 768, 770, 771, 771, 772, 772, 773, 773, 774, 774, 775, 775, 776, 776, 778, 780, 780, 781, 783, 785, 785, 0, 785, 785, 0, 0, 786, 787, 787, 787, 787, 787, 0, 787, 787, 787, 0, 0, 0, 0, 0, 788, 789, 789, 0, 789, 789, 789, 789, 789, 789, 0, 0, 0, 789, 789, 789, 0, 0, 0, 789, 789, 789, 0, 0, 0, 0, 0, 795, 795, 795, 795, 796, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 285, 290, 291, 292, 294, 297, 298, 300, 303, 307, 310, 314, 317, 318, 320, 321, 327, 328, 329, 330, 337, 338, 339, 340, 341, 353, 354, 355, 356, 357, 358, 359, 360, 363, 368, 369, 370, 376, 384, 385, 387, 388, 389, 390, 394, 395, 396, 397, 398, 401, 405, 408, 412, 414, 420, 421, 422, 425, 572, 573, 574, 575, 580, 581, 582, 582, 585, 587, 588, 589, 594, 595, 596, 597, 605, 606, 607, 608, 610, 612, 613, 614, 615, 616, 618, 619, 620, 623, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 683, 684, 686, 687, 688, 693, 694, 696, 697, 698, 703, 704, 706, 707, 708, 713, 714, 716, 717, 718, 723, 724, 726, 727, 728, 733, 734, 736, 737, 738, 743, 744, 746, 747, 748, 753, 754, 756, 757, 758, 763, 764, 766, 767, 768, 773, 774, 776, 777, 778, 783, 784, 787, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 807, 808, 809, 814, 815, 818, 822, 825, 825, 828, 830, 831, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 859, 860, 860, 863, 865, 866, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 896, 897, 900, 902, 903, 904, 905, 906, 907, 912, 913, 914, 916, 917, 918, 919, 924, 925, 926, 928, 929, 930, 930, 933, 935, 936, 937, 943, 944, 945, 946, 947, 948, 949, 954, 955, 956, 958, 963, 964, 965, 966, 967, 968, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 1033, 1034, 1035, 1038, 1040, 1041, 1042, 1043, 1044, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1060, 1061, 1061, 1064, 1066, 1067, 1074, 1075, 1076, 1077, 1078, 1079, 1084, 1085, 1085, 1088, 1090, 1091, 1104, 1105, 1108, 1110, 1111, 1112, 1113, 1114, 1115, 1116, 1126, 1127, 1143, 1148, 1149, 1151, 1156, 1157, 1158, 1159, 1161, 1164, 1165, 1167, 1170, 1171, 1173, 1176, 1177, 1179, 1182, 1183, 1184, 1189, 1191, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1350, 1351, 1352, 1353, 1358, 1359, 1359, 1362, 1364, 1365, 1372, 1373, 1378, 1379, 1380, 1382, 1383, 1384, 1387, 1388, 1388, 1391, 1393, 1394, 1395, 1400, 1401, 1402, 1403, 1410, 1410, 1413, 1415, 1416, 1417, 1422, 1423, 1424, 1425, 1426, 1427, 1435, 1436, 1439, 1441, 1442, 1443, 1445, 1446, 1447, 1454, 1456, 1457, 1458, 1459, 1460, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1476, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1489, 1490, 1491, 1492, 1495, 1497, 1498, 1504, 1505, 1506, 1507, 1510, 1512, 1513, 1520, 1521, 1522, 1523, 1528, 1529, 1530, 1531, 1533, 1534, 1535, 1537, 1540, 1545, 1546, 1547, 1549, 1549, 1552, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1565, 1566, 1568, 1569, 1570, 1572, 1573, 1574, 1582, 1583, 1586, 1588, 1590, 1593, 1597, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 1609, 1610, 1611, 1613, 1614, 1616, 1617, 1618, 1620, 1621, 1622, 1631, 1632, 1633, 1634, 1639, 1640, 1641, 1642, 1644, 1649, 1650, 1651, 1652, 1654, 1659, 1660, 1661, 1662, 1665, 1666, 1667, 1668, 1669, 1670, 1671, 1672, 1673, 1675, 1676, 1689, 1690, 1693, 1695, 1696, 1697, 1698, 1699, 1705, 1706, 1709, 1711, 1712, 1713, 1714, 1715, 1721, 1722, 1750, 1751, 1752, 1757, 1758, 1759, 1760, 1762, 1763, 1764, 1765, 1766, 1771, 1772, 1775, 1776, 1777, 1778, 1779, 1780, 1785, 1786, 1787, 1788, 1791, 1792, 1793, 1795, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1811, 1812, 1813, 1814, 1819, 1820, 1822, 1823, 1824, 1825, 1829, 1834, 1835, 1837, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1925, 1929, 1932, 1936, 1937, 1938, 1939, 1941, 1942, 1943, 1944, 1945, 1946, 1947, 1948, 1949, 1951, 1952, 1954, 1955, 1957, 1958, 1959, 1960, 1963, 1964, 1966, 1967, 1969, 1970, 1971, 1972, 1975, 1976, 1978, 1979, 1980, 1982, 1983, 1984, 1985, 1988, 1989, 1991, 1992, 1994, 1995, 1996, 1997, 2000, 2001, 2003, 2004, 2006, 2007, 2008, 2009, 2012, 2013, 2015, 2016, 2018, 2019, 2020, 2021, 2024, 2025, 2027, 2028, 2030, 2031, 2032, 2033, 2036, 2037, 2039, 2040, 2042, 2043, 2044, 2045, 2048, 2049, 2051, 2052, 2054, 2055, 2056, 2057, 2060, 2061, 2063, 2064, 2066, 2067, 2068, 2069, 2072, 2073, 2075, 2076, 2078, 2079, 2080, 2081, 2084, 2085, 2086, 2087, 2089, 2090, 2092, 2096, 2099, 2103, 2104, 2105, 2106, 2108, 2109, 2112, 2114, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2125, 2126, 2148, 2149, 2150, 2151, 2152, 2153, 2156, 2158, 2159, 2160, 2161, 2162, 2163, 2165, 2167, 2168, 2170, 2171, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2254, 2257, 2258, 2260, 2263, 2267, 2268, 2273, 2274, 2275, 2276, 2278, 2281, 2282, 2283, 2285, 2288, 2292, 2295, 2299, 2302, 2303, 2308, 2309, 2312, 2313, 2314, 2316, 2317, 2318, 2320, 2323, 2327, 2330, 2331, 2332, 2334, 2337, 2341, 2344, 2345, 2346, 2348, 2351, 2355, 2358, 2361, 2365, 2366, 2367, 2368, 2369, 2376, 2379, 2382, 2386, 2390, 2393, 2396, 2400, 2404, 2407, 2410, 2414, 2418, 2421, 2424, 2428, 2432, 2435, 2438, 2442, 2446, 2449, 2452, 2456, 2460, 2463, 2466, 2470, 2474, 2477, 2480, 2484, 2488, 2491, 2494, 2498, 2502, 2505, 2508, 2512, 2516, 2519, 2522, 2526, 2530, 2533, 2536, 2540, 2544, 2547, 2550, 2554, 2558, 2561, 2564, 2568, 2572, 2575, 2578, 2582, 2586, 2589, 2592, 2596, 2600, 2603, 2606, 2610, 2614, 2617, 2620, 2624, 2628, 2631, 2634, 2638, 2642, 2645, 2648, 2652, 2656, 2659, 2662, 2666, 2670, 2673, 2676, 2680, 2684, 2687, 2690, 2694, 2698, 2701, 2704, 2708, 2712, 2715, 2718, 2722, 2726, 2729, 2732, 2736, 2740, 2743, 2746, 2750, 2754, 2757, 2760, 2764, 2768, 2771, 2774, 2778, 2782, 2785, 2788, 2792, 2796, 2799, 2802, 2806, 2810, 2813, 2816, 2820, 2824, 2827, 2830, 2834, 2838, 2841, 2844, 2848, 2852, 2855, 2858, 2862, 2866, 2869, 2872, 2876, 2880, 2883, 2886, 2890, 2894, 2897, 2900, 2904, 2908, 2911, 2914, 2918, 2922, 2925, 2928, 2932, 2936, 2939, 2942, 2946, 2950, 2953, 2956, 2960, 2964, 2967, 2970, 2974, 2978, 2981, 2984, 2988, 2992, 2995, 2998, 3002, 3006, 3009, 3012, 3016, 3020, 3023, 3026, 3030, 3034, 3037, 3040, 3044, 3048, 3051, 3054, 3058, 3062, 3065, 3068, 3072, 3076, 3079, 3082, 3086, 3090, 3093, 3096, 3100, 3104, 3107, 3110, 3114, 3118, 3121, 3124, 3128, 3132, 3135, 3138, 3142, 3146, 3149, 3152, 3156, 3160, 3163, 3166, 3170, 3174, 3177, 3180, 3184, 3188, 3191, 3194, 3198, 3202, 3205, 3208, 3212, 3216, 3219, 3222, 3226, 3230, 3233, 3236, 3240, 3244, 3247, 3250, 3254, 3258, 3261, 3264, 3268, 3272, 3275, 3278, 3282, 3286, 3289, 3292, 3296, 3300, 3303, 3306, 3310, 3314, 3317, 3320, 3324, 3328, 3331, 3334, 3338, 3342, 3345, 3348, 3352, 3356, 3359, 3362, 3366, 3370, 3373, 3376, 3380, 3384, 3387, 3390, 3394, 3398, 3401, 3405};
/* BEGIN LINEINFO 
assign 1 51 246
new 0 51 246
assign 1 53 247
new 0 53 247
assign 1 54 248
new 0 54 248
assign 1 55 249
new 0 55 249
assign 1 56 250
new 0 56 250
assign 1 58 251
new 0 58 251
assign 1 59 252
new 0 59 252
assign 1 60 253
new 0 60 253
assign 1 61 254
new 0 61 254
assign 1 62 255
new 0 62 255
assign 1 63 256
new 0 63 256
assign 1 64 257
new 0 64 257
assign 1 68 258
new 0 68 258
assign 1 70 259
new 1 70 259
assign 1 71 260
ntypesGet 0 71 260
assign 1 72 261
twtokGet 0 72 261
assign 1 73 262
new 0 73 262
assign 1 73 263
new 1 73 263
assign 1 76 264
new 0 76 264
assign 1 79 265
new 0 79 265
assign 1 80 266
new 0 80 266
assign 1 81 267
new 0 81 267
assign 1 88 268
new 0 88 268
assign 1 89 269
new 0 89 269
assign 1 90 270
new 0 90 270
assign 1 91 271
new 0 91 271
assign 1 92 272
new 0 92 272
assign 1 92 273
new 1 92 273
assign 1 99 285
def 1 99 290
assign 1 99 291
new 0 99 291
assign 1 99 292
equals 1 99 292
assign 1 0 294
assign 1 99 297
new 0 99 297
assign 1 99 298
ends 1 99 298
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 100 317
new 0 100 317
return 1 100 318
assign 1 102 320
new 0 102 320
return 1 102 321
assign 1 106 327
new 0 106 327
assign 1 106 328
new 0 106 328
assign 1 106 329
swap 2 106 329
return 1 106 330
assign 1 110 337
new 0 110 337
assign 1 110 338
argsGet 0 110 338
assign 1 111 339
new 0 111 339
assign 1 111 340
main 1 111 340
exit 1 111 341
assign 1 115 353
assign 1 116 354
new 1 116 354
assign 1 117 355
new 0 117 355
assign 1 117 356
new 0 117 356
assign 1 117 357
get 2 117 357
assign 1 117 358
firstGet 0 117 358
assign 1 117 359
new 1 117 359
assign 1 118 360
new 0 118 360
assign 1 118 363
lesser 1 118 368
assign 1 119 369
go 0 119 369
incrementValue 0 118 370
return 1 121 376
assign 1 125 384
new 0 125 384
assign 1 126 385
new 0 126 385
config 0 128 387
assign 1 129 388
new 0 129 388
assign 1 130 389
doWhat 0 130 389
assign 1 131 390
new 0 131 390
assign 1 133 394
toString 0 133 394
assign 1 134 395
new 0 134 395
assign 1 135 396
new 0 135 396
assign 1 135 397
add 1 135 397
assign 1 136 398
new 0 136 398
assign 1 0 401
assign 1 0 405
assign 1 0 408
print 0 139 412
return 1 141 414
assign 1 145 420
nameGet 0 145 420
assign 1 145 421
new 0 145 421
assign 1 145 422
equals 1 145 422
return 1 147 425
assign 1 152 572
new 0 152 572
assign 1 154 573
new 0 154 573
assign 1 155 574
get 1 155 574
assign 1 155 575
def 1 155 580
assign 1 156 581
get 1 156 581
assign 1 156 582
iteratorGet 0 0 582
assign 1 156 585
hasNextGet 0 156 585
assign 1 156 587
nextGet 0 156 587
assign 1 157 588
has 1 157 588
assign 1 157 589
not 0 157 594
put 1 158 595
assign 1 159 596
new 1 159 596
addFile 1 159 597
assign 1 164 605
new 0 164 605
assign 1 164 606
nameGet 0 164 606
assign 1 164 607
new 0 164 607
assign 1 164 608
equals 1 164 608
preProcessorSet 1 165 610
assign 1 167 612
new 0 167 612
assign 1 167 613
get 1 167 613
assign 1 167 614
firstGet 0 167 614
assign 1 168 615
new 0 168 615
assign 1 168 616
has 1 168 616
assign 1 169 618
new 0 169 618
assign 1 169 619
get 1 169 619
assign 1 169 620
firstGet 0 169 620
assign 1 171 623
assign 1 173 625
new 0 173 625
assign 1 173 626
new 0 173 626
assign 1 173 627
get 2 173 627
assign 1 173 628
firstGet 0 173 628
assign 1 173 629
new 1 173 629
assign 1 173 630
pathGet 0 173 630
addStep 1 174 631
assign 1 175 632
new 0 175 632
addStep 1 175 633
assign 1 176 634
new 0 176 634
assign 1 176 635
new 0 176 635
assign 1 176 636
get 2 176 636
assign 1 176 637
firstGet 0 176 637
assign 1 176 638
new 1 176 638
assign 1 176 639
pathGet 0 176 639
assign 1 177 640
new 0 177 640
assign 1 177 641
new 0 177 641
assign 1 177 642
nameGet 0 177 642
assign 1 177 643
get 2 177 643
assign 1 177 644
firstGet 0 177 644
assign 1 177 645
new 1 177 645
assign 1 178 646
new 0 178 646
assign 1 178 647
nameGet 0 178 647
assign 1 178 648
get 2 178 648
assign 1 178 649
firstGet 0 178 649
assign 1 178 650
new 1 178 650
assign 1 179 651
new 0 179 651
assign 1 179 652
new 0 179 652
assign 1 179 653
get 2 179 653
assign 1 179 654
firstGet 0 179 654
assign 1 179 655
new 1 179 655
assign 1 180 656
new 0 180 656
assign 1 180 657
new 0 180 657
assign 1 180 658
get 2 180 658
assign 1 180 659
firstGet 0 180 659
assign 1 180 660
new 1 180 660
assign 1 181 661
new 0 181 661
assign 1 181 662
new 0 181 662
assign 1 181 663
get 2 181 663
assign 1 181 664
firstGet 0 181 664
assign 1 181 665
new 1 181 665
assign 1 182 666
new 0 182 666
assign 1 182 667
get 1 182 667
assign 1 183 668
new 0 183 668
assign 1 183 669
get 1 183 669
assign 1 185 670
new 0 185 670
assign 1 185 671
get 1 185 671
assign 1 185 672
firstGet 0 185 672
assign 1 186 673
new 0 186 673
assign 1 186 674
get 1 186 674
assign 1 186 675
firstGet 0 186 675
assign 1 187 676
new 0 187 676
assign 1 187 677
get 1 187 677
assign 1 188 678
undef 1 188 683
assign 1 189 684
new 0 189 684
assign 1 191 686
new 0 191 686
assign 1 191 687
get 1 191 687
assign 1 192 688
undef 1 192 693
assign 1 193 694
new 0 193 694
assign 1 195 696
new 0 195 696
assign 1 195 697
get 1 195 697
assign 1 196 698
undef 1 196 703
assign 1 197 704
new 0 197 704
assign 1 199 706
new 0 199 706
assign 1 199 707
get 1 199 707
assign 1 200 708
undef 1 200 713
assign 1 201 714
new 0 201 714
assign 1 203 716
new 0 203 716
assign 1 203 717
get 1 203 717
assign 1 204 718
undef 1 204 723
assign 1 205 724
new 0 205 724
assign 1 207 726
new 0 207 726
assign 1 207 727
get 1 207 727
assign 1 208 728
undef 1 208 733
assign 1 209 734
new 0 209 734
assign 1 211 736
new 0 211 736
assign 1 211 737
get 1 211 737
assign 1 212 738
undef 1 212 743
assign 1 213 744
new 0 213 744
assign 1 215 746
new 0 215 746
assign 1 215 747
get 1 215 747
assign 1 216 748
undef 1 216 753
assign 1 217 754
new 0 217 754
assign 1 219 756
new 0 219 756
assign 1 219 757
get 1 219 757
assign 1 220 758
undef 1 220 763
assign 1 221 764
new 0 221 764
assign 1 223 766
new 0 223 766
assign 1 223 767
get 1 223 767
assign 1 224 768
def 1 224 773
assign 1 225 774
firstGet 0 225 774
assign 1 227 776
new 0 227 776
assign 1 227 777
get 1 227 777
assign 1 228 778
def 1 228 783
assign 1 229 784
firstGet 0 229 784
assign 1 231 787
new 0 231 787
assign 1 233 789
new 0 233 789
assign 1 233 790
new 0 233 790
assign 1 233 791
isTrue 2 233 791
assign 1 234 792
new 0 234 792
assign 1 234 793
new 0 234 793
assign 1 234 794
isTrue 2 234 794
assign 1 235 795
new 0 235 795
assign 1 235 796
isTrue 1 235 796
assign 1 236 797
new 0 236 797
assign 1 236 798
isTrue 1 236 798
assign 1 237 799
new 0 237 799
assign 1 238 800
new 0 238 800
assign 1 238 801
get 1 238 801
assign 1 239 802
def 1 239 807
assign 1 239 808
isEmptyGet 0 239 808
assign 1 239 809
not 0 239 814
assign 1 0 815
assign 1 0 818
assign 1 0 822
assign 1 240 825
linkedListIteratorGet 0 0 825
assign 1 240 828
hasNextGet 0 240 828
assign 1 240 830
nextGet 0 240 830
put 1 241 831
assign 1 244 838
new 0 244 838
assign 1 244 839
isTrue 1 244 839
assign 1 245 840
new 0 245 840
assign 1 245 841
isTrue 1 245 841
assign 1 246 842
new 0 246 842
assign 1 246 843
isTrue 1 246 843
assign 1 247 844
new 0 247 844
assign 1 247 845
isTrue 1 247 845
assign 1 248 846
new 0 248 846
assign 1 248 847
new 0 248 847
assign 1 248 848
isTrue 2 248 848
assign 1 249 849
new 0 249 849
assign 1 249 850
get 1 249 850
assign 1 250 851
new 0 250 851
assign 1 250 852
get 1 250 852
assign 1 251 853
new 0 251 853
assign 1 252 854
def 1 252 859
assign 1 253 860
linkedListIteratorGet 0 0 860
assign 1 253 863
hasNextGet 0 253 863
assign 1 253 865
nextGet 0 253 865
addValue 1 255 866
assign 1 258 873
new 0 258 873
assign 1 258 874
new 0 258 874
assign 1 258 875
get 2 258 875
assign 1 258 876
firstGet 0 258 876
assign 1 259 877
new 0 259 877
assign 1 259 878
new 0 259 878
assign 1 259 879
get 2 259 879
assign 1 259 880
firstGet 0 259 880
assign 1 260 881
new 0 260 881
assign 1 260 882
add 1 260 882
assign 1 260 883
new 0 260 883
assign 1 260 884
get 2 260 884
assign 1 260 885
firstGet 0 260 885
assign 1 261 886
new 0 261 886
assign 1 262 887
new 0 262 887
assign 1 263 888
new 0 263 888
assign 1 264 889
new 0 264 889
assign 1 265 890
new 0 265 890
assign 1 268 891
def 1 268 896
assign 1 269 897
firstGet 0 269 897
assign 1 271 900
new 0 271 900
assign 1 278 902
new 0 278 902
assign 1 278 903
add 1 278 903
assign 1 278 904
nameGet 0 278 904
assign 1 278 905
add 1 278 905
assign 1 278 906
get 1 278 906
assign 1 279 907
def 1 279 912
assign 1 280 913
orderedGet 0 280 913
addAll 1 280 914
assign 1 283 916
new 0 283 916
assign 1 283 917
add 1 283 917
assign 1 283 918
get 1 283 918
assign 1 284 919
def 1 284 924
assign 1 285 925
orderedGet 0 285 925
addAll 1 285 926
assign 1 288 928
new 0 288 928
assign 1 289 929
orderedGet 0 289 929
assign 1 289 930
iteratorGet 0 0 930
assign 1 289 933
hasNextGet 0 289 933
assign 1 289 935
nextGet 0 289 935
assign 1 290 936
new 1 290 936
addValue 1 290 937
assign 1 292 943
newlineGet 0 292 943
assign 1 293 944
assign 1 294 945
new 1 294 945
assign 1 296 946
copy 0 296 946
assign 1 297 947
fileGet 0 297 947
assign 1 297 948
existsGet 0 297 948
assign 1 297 949
not 0 297 954
assign 1 298 955
fileGet 0 298 955
makeDirs 0 298 956
assign 1 300 958
def 1 300 963
assign 1 301 964
new 1 301 964
assign 1 301 965
readerGet 0 301 965
assign 1 302 966
open 0 302 966
assign 1 302 967
readString 0 302 967
close 0 303 968
assign 1 309 982
classNameGet 0 309 982
assign 1 310 983
add 1 310 983
assign 1 310 984
new 0 310 984
assign 1 310 985
add 1 310 985
assign 1 310 986
toString 0 310 986
assign 1 310 987
add 1 310 987
assign 1 311 988
add 1 311 988
assign 1 311 989
new 0 311 989
assign 1 311 990
add 1 311 990
assign 1 311 991
toString 0 311 991
assign 1 311 992
add 1 311 992
return 1 312 993
assign 1 316 1033
new 0 316 1033
assign 1 317 1034
classesGet 0 317 1034
assign 1 317 1035
valueIteratorGet 0 317 1035
assign 1 317 1038
hasNextGet 0 317 1038
assign 1 318 1040
nextGet 0 318 1040
assign 1 319 1041
shouldEmitGet 0 319 1041
assign 1 319 1042
heldGet 0 319 1042
assign 1 319 1043
fromFileGet 0 319 1043
assign 1 319 1044
has 1 319 1044
assign 1 320 1046
heldGet 0 320 1046
assign 1 320 1047
namepathGet 0 320 1047
assign 1 320 1048
toString 0 320 1048
put 1 320 1049
assign 1 321 1050
usedByGet 0 321 1050
assign 1 321 1051
heldGet 0 321 1051
assign 1 321 1052
namepathGet 0 321 1052
assign 1 321 1053
toString 0 321 1053
assign 1 321 1054
get 1 321 1054
assign 1 322 1055
def 1 322 1060
assign 1 323 1061
setIteratorGet 0 0 1061
assign 1 323 1064
hasNextGet 0 323 1064
assign 1 323 1066
nextGet 0 323 1066
put 1 324 1067
assign 1 327 1074
subClassesGet 0 327 1074
assign 1 327 1075
heldGet 0 327 1075
assign 1 327 1076
namepathGet 0 327 1076
assign 1 327 1077
toString 0 327 1077
assign 1 327 1078
get 1 327 1078
assign 1 328 1079
def 1 328 1084
assign 1 329 1085
setIteratorGet 0 0 1085
assign 1 329 1088
hasNextGet 0 329 1088
assign 1 329 1090
nextGet 0 329 1090
put 1 330 1091
assign 1 335 1104
classesGet 0 335 1104
assign 1 335 1105
valueIteratorGet 0 335 1105
assign 1 335 1108
hasNextGet 0 335 1108
assign 1 336 1110
nextGet 0 336 1110
assign 1 337 1111
heldGet 0 337 1111
assign 1 337 1112
heldGet 0 337 1112
assign 1 337 1113
namepathGet 0 337 1113
assign 1 337 1114
toString 0 337 1114
assign 1 337 1115
has 1 337 1115
shouldWriteSet 1 337 1116
assign 1 344 1126
new 0 344 1126
return 1 344 1127
assign 1 348 1143
def 1 348 1148
return 1 349 1149
assign 1 354 1151
def 1 354 1156
assign 1 355 1157
firstGet 0 355 1157
assign 1 356 1158
new 0 356 1158
assign 1 356 1159
equals 1 356 1159
assign 1 357 1161
new 1 357 1161
assign 1 358 1164
new 0 358 1164
assign 1 358 1165
equals 1 358 1165
assign 1 359 1167
new 1 359 1167
assign 1 360 1170
new 0 360 1170
assign 1 360 1171
equals 1 360 1171
assign 1 361 1173
new 1 361 1173
assign 1 362 1176
new 0 362 1176
assign 1 362 1177
equals 1 362 1177
assign 1 363 1179
new 1 363 1179
assign 1 367 1182
new 0 367 1182
assign 1 367 1183
new 1 367 1183
throw 1 367 1184
return 1 369 1189
return 1 371 1191
assign 1 375 1210
apNew 1 375 1210
assign 1 377 1211
new 0 377 1211
assign 1 377 1212
add 1 377 1212
print 0 377 1213
assign 1 378 1214
new 0 378 1214
assign 1 378 1215
now 0 378 1215
assign 1 379 1216
fileGet 0 379 1216
assign 1 379 1217
readerGet 0 379 1217
assign 1 379 1218
open 0 379 1218
assign 1 380 1219
new 0 380 1219
assign 1 380 1220
deserialize 1 380 1220
close 0 381 1221
assign 1 382 1222
synClassesGet 0 382 1222
addValue 1 382 1223
assign 1 383 1224
new 0 383 1224
assign 1 383 1225
now 0 383 1225
assign 1 383 1226
subtract 1 383 1226
assign 1 384 1227
new 0 384 1227
assign 1 384 1228
add 1 384 1228
print 0 384 1229
assign 1 390 1350
new 0 390 1350
assign 1 390 1351
now 0 390 1351
assign 1 391 1352
new 0 391 1352
assign 1 392 1353
def 1 392 1358
assign 1 393 1359
linkedListIteratorGet 0 0 1359
assign 1 393 1362
hasNextGet 0 393 1362
assign 1 393 1364
nextGet 0 393 1364
loadSyns 1 394 1365
assign 1 397 1372
emitterGet 0 397 1372
assign 1 398 1373
def 1 398 1378
assign 1 399 1379
new 4 399 1379
put 1 400 1380
assign 1 402 1382
new 0 402 1382
assign 1 402 1383
add 1 402 1383
print 0 402 1384
assign 1 405 1387
new 0 405 1387
assign 1 407 1388
iteratorGet 0 0 1388
assign 1 407 1391
hasNextGet 0 407 1391
assign 1 407 1393
nextGet 0 407 1393
assign 1 408 1394
has 1 408 1394
assign 1 408 1395
not 0 408 1400
put 1 409 1401
assign 1 410 1402
new 2 410 1402
addValue 1 411 1403
assign 1 414 1410
iteratorGet 0 0 1410
assign 1 414 1413
hasNextGet 0 414 1413
assign 1 414 1415
nextGet 0 414 1415
assign 1 415 1416
has 1 415 1416
assign 1 415 1417
not 0 415 1422
put 1 416 1423
assign 1 417 1424
new 2 417 1424
addValue 1 418 1425
assign 1 419 1426
libNameGet 0 419 1426
put 1 419 1427
assign 1 424 1435
new 0 424 1435
assign 1 425 1436
iteratorGet 0 425 1436
assign 1 425 1439
hasNextGet 0 425 1439
assign 1 426 1441
nextGet 0 426 1441
assign 1 428 1442
toString 0 428 1442
assign 1 428 1443
has 1 428 1443
assign 1 429 1445
toString 0 429 1445
put 1 429 1446
doParse 1 430 1447
buildSyns 1 433 1454
assign 1 436 1456
new 0 436 1456
assign 1 436 1457
now 0 436 1457
assign 1 436 1458
subtract 1 436 1458
assign 1 439 1459
emitCommonGet 0 439 1459
assign 1 439 1460
def 1 439 1465
assign 1 441 1466
new 0 441 1466
assign 1 441 1467
now 0 441 1467
assign 1 442 1468
emitCommonGet 0 442 1468
doEmit 0 442 1469
assign 1 443 1470
new 0 443 1470
assign 1 443 1471
now 0 443 1471
assign 1 443 1472
subtract 1 443 1472
assign 1 444 1473
new 0 444 1473
assign 1 444 1474
now 0 444 1474
assign 1 444 1475
subtract 1 444 1475
assign 1 445 1476
new 0 445 1476
assign 1 445 1477
add 1 445 1477
print 0 445 1478
assign 1 446 1479
new 0 446 1479
assign 1 446 1480
add 1 446 1480
print 0 446 1481
assign 1 447 1482
new 0 447 1482
assign 1 447 1483
add 1 447 1483
print 0 447 1484
assign 1 448 1485
new 0 448 1485
return 1 448 1486
setClassesToWrite 0 451 1489
libnameInfoGet 0 452 1490
assign 1 454 1491
classesGet 0 454 1491
assign 1 454 1492
valueIteratorGet 0 454 1492
assign 1 454 1495
hasNextGet 0 454 1495
assign 1 455 1497
nextGet 0 455 1497
doEmit 1 456 1498
emitMain 0 458 1504
emitCUInit 0 459 1505
assign 1 460 1506
classesGet 0 460 1506
assign 1 460 1507
valueIteratorGet 0 460 1507
assign 1 460 1510
hasNextGet 0 460 1510
assign 1 461 1512
nextGet 0 461 1512
emitSyn 1 462 1513
assign 1 466 1520
new 0 466 1520
assign 1 466 1521
now 0 466 1521
assign 1 466 1522
subtract 1 466 1522
assign 1 467 1523
def 1 467 1528
assign 1 468 1529
new 0 468 1529
assign 1 468 1530
add 1 468 1530
print 0 468 1531
assign 1 470 1533
new 0 470 1533
assign 1 470 1534
add 1 470 1534
print 0 470 1535
prepMake 1 473 1537
assign 1 477 1540
not 0 477 1545
make 1 478 1546
deployLibrary 1 479 1547
assign 1 481 1549
linkedListIteratorGet 0 0 1549
assign 1 481 1552
hasNextGet 0 481 1552
assign 1 481 1554
nextGet 0 481 1554
assign 1 482 1555
libnameInfoGet 0 482 1555
assign 1 482 1556
unitShlibGet 0 482 1556
assign 1 483 1557
emitPathGet 0 483 1557
assign 1 483 1558
copy 0 483 1558
assign 1 484 1559
stepsGet 0 484 1559
assign 1 484 1560
lastGet 0 484 1560
addStep 1 484 1561
assign 1 485 1562
fileGet 0 485 1562
assign 1 485 1563
existsGet 0 485 1563
assign 1 486 1565
fileGet 0 486 1565
delete 0 486 1566
assign 1 488 1568
fileGet 0 488 1568
assign 1 488 1569
existsGet 0 488 1569
assign 1 488 1570
not 0 488 1570
assign 1 489 1572
fileGet 0 489 1572
assign 1 489 1573
fileGet 0 489 1573
deployFile 2 489 1574
assign 1 493 1582
iteratorGet 0 493 1582
assign 1 494 1583
iteratorGet 0 494 1583
assign 1 496 1586
hasNextGet 0 496 1586
assign 1 496 1588
hasNextGet 0 496 1588
assign 1 0 1590
assign 1 0 1593
assign 1 0 1597
assign 1 497 1600
nextGet 0 497 1600
assign 1 497 1601
apNew 1 497 1601
assign 1 498 1602
emitPathGet 0 498 1602
assign 1 498 1603
copy 0 498 1603
assign 1 498 1604
toString 0 498 1604
assign 1 498 1605
new 0 498 1605
assign 1 498 1606
add 1 498 1606
assign 1 498 1607
nextGet 0 498 1607
assign 1 498 1608
add 1 498 1608
assign 1 498 1609
apNew 1 498 1609
assign 1 500 1610
fileGet 0 500 1610
assign 1 500 1611
existsGet 0 500 1611
assign 1 501 1613
fileGet 0 501 1613
delete 0 501 1614
assign 1 503 1616
fileGet 0 503 1616
assign 1 503 1617
existsGet 0 503 1617
assign 1 503 1618
not 0 503 1618
assign 1 504 1620
fileGet 0 504 1620
assign 1 504 1621
fileGet 0 504 1621
deployFile 2 504 1622
assign 1 509 1631
new 0 509 1631
assign 1 509 1632
now 0 509 1632
assign 1 509 1633
subtract 1 509 1633
assign 1 511 1634
def 1 511 1639
assign 1 512 1640
new 0 512 1640
assign 1 512 1641
add 1 512 1641
print 0 512 1642
assign 1 514 1644
def 1 514 1649
assign 1 515 1650
new 0 515 1650
assign 1 515 1651
add 1 515 1651
print 0 515 1652
assign 1 517 1654
def 1 517 1659
assign 1 518 1660
new 0 518 1660
assign 1 518 1661
add 1 518 1661
print 0 518 1662
assign 1 522 1665
new 0 522 1665
print 0 522 1666
assign 1 523 1667
run 2 523 1667
assign 1 524 1668
new 0 524 1668
assign 1 524 1669
add 1 524 1669
assign 1 524 1670
new 0 524 1670
assign 1 524 1671
add 1 524 1671
print 0 524 1672
return 1 525 1673
assign 1 527 1675
new 0 527 1675
return 1 527 1676
assign 1 531 1689
justParsedGet 0 531 1689
assign 1 531 1690
valueIteratorGet 0 531 1690
assign 1 531 1693
hasNextGet 0 531 1693
assign 1 532 1695
nextGet 0 532 1695
assign 1 533 1696
heldGet 0 533 1696
libNameSet 1 533 1697
assign 1 534 1698
getSyn 2 534 1698
libNameSet 1 535 1699
assign 1 537 1705
justParsedGet 0 537 1705
assign 1 537 1706
valueIteratorGet 0 537 1706
assign 1 537 1709
hasNextGet 0 537 1709
assign 1 538 1711
nextGet 0 538 1711
assign 1 539 1712
heldGet 0 539 1712
assign 1 539 1713
synGet 0 539 1713
checkInheritance 2 540 1714
integrate 1 541 1715
assign 1 543 1721
new 0 543 1721
justParsedSet 1 543 1722
assign 1 547 1750
heldGet 0 547 1750
assign 1 547 1751
synGet 0 547 1751
assign 1 547 1752
def 1 547 1757
assign 1 548 1758
heldGet 0 548 1758
assign 1 548 1759
synGet 0 548 1759
return 1 548 1760
assign 1 550 1762
heldGet 0 550 1762
libNameSet 1 550 1763
assign 1 551 1764
heldGet 0 551 1764
assign 1 551 1765
extendsGet 0 551 1765
assign 1 551 1766
undef 1 551 1771
assign 1 552 1772
new 1 552 1772
assign 1 554 1775
classesGet 0 554 1775
assign 1 554 1776
heldGet 0 554 1776
assign 1 554 1777
extendsGet 0 554 1777
assign 1 554 1778
toString 0 554 1778
assign 1 554 1779
get 1 554 1779
assign 1 556 1780
def 1 556 1785
assign 1 557 1786
heldGet 0 557 1786
libNameSet 1 557 1787
assign 1 558 1788
getSyn 2 558 1788
assign 1 562 1791
heldGet 0 562 1791
assign 1 562 1792
extendsGet 0 562 1792
assign 1 562 1793
getSynNp 1 562 1793
assign 1 564 1795
new 2 564 1795
assign 1 566 1797
heldGet 0 566 1797
synSet 1 566 1798
assign 1 567 1799
heldGet 0 567 1799
assign 1 567 1800
namepathGet 0 567 1800
assign 1 567 1801
toString 0 567 1801
addSynClass 2 567 1802
return 1 568 1803
assign 1 572 1811
toString 0 572 1811
assign 1 573 1812
synClassesGet 0 573 1812
assign 1 573 1813
get 1 573 1813
assign 1 574 1814
def 1 574 1819
return 1 575 1820
assign 1 581 1822
emitterGet 0 581 1822
assign 1 581 1823
loadSyn 1 581 1823
addSynClass 2 582 1824
return 1 583 1825
assign 1 590 1829
undef 1 590 1834
assign 1 591 1835
new 1 591 1835
return 1 593 1837
assign 1 598 1916
new 1 598 1916
assign 1 599 1917
new 0 599 1917
assign 1 600 1918
emitterGet 0 600 1918
assign 1 601 1919
assign 1 602 1920
new 0 602 1920
assign 1 603 1921
shouldEmitGet 0 603 1921
put 1 603 1922
assign 1 0 1925
assign 1 0 1929
assign 1 0 1932
assign 1 606 1936
new 0 606 1936
assign 1 606 1937
toString 0 606 1937
assign 1 606 1938
add 1 606 1938
print 0 606 1939
assign 1 608 1941
assign 1 610 1942
fileGet 0 610 1942
assign 1 610 1943
readerGet 0 610 1943
assign 1 610 1944
open 0 610 1944
assign 1 610 1945
readBuffer 1 610 1945
assign 1 611 1946
fileGet 0 611 1946
assign 1 611 1947
readerGet 0 611 1947
close 0 611 1948
assign 1 614 1949
tokenize 1 614 1949
assign 1 618 1951
new 0 618 1951
echo 0 618 1952
assign 1 620 1954
outermostGet 0 620 1954
nodify 2 620 1955
assign 1 622 1957
new 0 622 1957
print 0 622 1958
assign 1 623 1959
new 2 623 1959
traverse 1 623 1960
assign 1 627 1963
new 0 627 1963
echo 0 627 1964
assign 1 629 1966
new 0 629 1966
traverse 1 629 1967
assign 1 631 1969
new 0 631 1969
print 0 631 1970
assign 1 632 1971
new 2 632 1971
traverse 1 632 1972
assign 1 635 1975
new 0 635 1975
echo 0 635 1976
assign 1 638 1978
new 0 638 1978
traverse 1 638 1979
contain 0 639 1980
assign 1 641 1982
new 0 641 1982
print 0 641 1983
assign 1 642 1984
new 2 642 1984
traverse 1 642 1985
assign 1 646 1988
new 0 646 1988
echo 0 646 1989
assign 1 648 1991
new 0 648 1991
traverse 1 648 1992
assign 1 650 1994
new 0 650 1994
print 0 650 1995
assign 1 651 1996
new 2 651 1996
traverse 1 651 1997
assign 1 655 2000
new 0 655 2000
echo 0 655 2001
assign 1 657 2003
new 0 657 2003
traverse 1 657 2004
assign 1 659 2006
new 0 659 2006
print 0 659 2007
assign 1 660 2008
new 2 660 2008
traverse 1 660 2009
assign 1 664 2012
new 0 664 2012
echo 0 664 2013
assign 1 666 2015
new 0 666 2015
traverse 1 666 2016
assign 1 668 2018
new 0 668 2018
print 0 668 2019
assign 1 669 2020
new 2 669 2020
traverse 1 669 2021
assign 1 673 2024
new 0 673 2024
echo 0 673 2025
assign 1 675 2027
new 0 675 2027
traverse 1 675 2028
assign 1 677 2030
new 0 677 2030
print 0 677 2031
assign 1 678 2032
new 2 678 2032
traverse 1 678 2033
assign 1 682 2036
new 0 682 2036
echo 0 682 2037
assign 1 684 2039
new 0 684 2039
traverse 1 684 2040
assign 1 686 2042
new 0 686 2042
print 0 686 2043
assign 1 687 2044
new 2 687 2044
traverse 1 687 2045
assign 1 691 2048
new 0 691 2048
echo 0 691 2049
assign 1 693 2051
new 0 693 2051
traverse 1 693 2052
assign 1 695 2054
new 0 695 2054
print 0 695 2055
assign 1 696 2056
new 2 696 2056
traverse 1 696 2057
assign 1 700 2060
new 0 700 2060
echo 0 700 2061
assign 1 702 2063
new 0 702 2063
traverse 1 702 2064
assign 1 704 2066
new 0 704 2066
print 0 704 2067
assign 1 705 2068
new 2 705 2068
traverse 1 705 2069
assign 1 708 2072
new 0 708 2072
echo 0 708 2073
assign 1 710 2075
new 0 710 2075
traverse 1 710 2076
assign 1 712 2078
new 0 712 2078
print 0 712 2079
assign 1 713 2080
new 2 713 2080
traverse 1 713 2081
assign 1 717 2084
new 0 717 2084
echo 0 717 2085
assign 1 718 2086
new 0 718 2086
print 0 718 2087
assign 1 720 2089
new 0 720 2089
traverse 1 720 2090
assign 1 0 2092
assign 1 0 2096
assign 1 0 2099
assign 1 722 2103
new 0 722 2103
print 0 722 2104
assign 1 723 2105
new 2 723 2105
traverse 1 723 2106
assign 1 725 2108
classesGet 0 725 2108
assign 1 725 2109
valueIteratorGet 0 725 2109
assign 1 725 2112
hasNextGet 0 725 2112
assign 1 726 2114
nextGet 0 726 2114
assign 1 728 2115
transUnitGet 0 728 2115
assign 1 729 2116
new 1 729 2116
assign 1 730 2117
TRANSUNITGet 0 730 2117
typenameSet 1 730 2118
assign 1 731 2119
new 0 731 2119
assign 1 732 2120
heldGet 0 732 2120
assign 1 732 2121
emitsGet 0 732 2121
emitsSet 1 732 2122
heldSet 1 733 2123
delete 0 734 2124
addValue 1 735 2125
copyLoc 1 736 2126
reInitContained 0 742 2148
assign 1 743 2149
containedGet 0 743 2149
assign 1 744 2150
new 0 744 2150
assign 1 745 2151
new 0 745 2151
assign 1 745 2152
crGet 0 745 2152
assign 1 746 2153
linkedListIteratorGet 0 746 2153
assign 1 746 2156
hasNextGet 0 746 2156
assign 1 747 2158
new 1 747 2158
assign 1 748 2159
nextGet 0 748 2159
heldSet 1 748 2160
nlcSet 1 749 2161
assign 1 750 2162
heldGet 0 750 2162
assign 1 750 2163
equals 1 750 2163
assign 1 751 2165
increment 0 751 2165
assign 1 753 2167
heldGet 0 753 2167
assign 1 753 2168
notEquals 1 753 2168
addValue 1 754 2170
containerSet 1 755 2171
assign 1 762 2226
new 0 762 2226
fromString 1 763 2227
assign 1 765 2228
new 1 765 2228
assign 1 766 2229
NAMEPATHGet 0 766 2229
typenameSet 1 766 2230
heldSet 1 767 2231
copyLoc 1 768 2232
assign 1 770 2233
new 0 770 2233
assign 1 771 2234
new 0 771 2234
nameSet 1 771 2235
assign 1 772 2236
new 0 772 2236
wasBoundSet 1 772 2237
assign 1 773 2238
new 0 773 2238
boundSet 1 773 2239
assign 1 774 2240
new 0 774 2240
isConstructSet 1 774 2241
assign 1 775 2242
new 0 775 2242
isLiteralSet 1 775 2243
assign 1 776 2244
heldGet 0 776 2244
literalValueSet 1 776 2245
addValue 1 778 2246
assign 1 780 2247
CALLGet 0 780 2247
typenameSet 1 780 2248
heldSet 1 781 2249
resolveNp 0 783 2250
assign 1 785 2251
new 0 785 2251
assign 1 785 2252
equals 1 785 2252
assign 1 0 2254
assign 1 785 2257
new 0 785 2257
assign 1 785 2258
equals 1 785 2258
assign 1 0 2260
assign 1 0 2263
assign 1 786 2267
priorPeerGet 0 786 2267
assign 1 787 2268
def 1 787 2273
assign 1 787 2274
typenameGet 0 787 2274
assign 1 787 2275
SUBTRACTGet 0 787 2275
assign 1 787 2276
equals 1 787 2276
assign 1 0 2278
assign 1 787 2281
typenameGet 0 787 2281
assign 1 787 2282
ADDGet 0 787 2282
assign 1 787 2283
equals 1 787 2283
assign 1 0 2285
assign 1 0 2288
assign 1 0 2292
assign 1 0 2295
assign 1 0 2299
assign 1 788 2302
priorPeerGet 0 788 2302
assign 1 789 2303
undef 1 789 2308
assign 1 0 2309
assign 1 789 2312
typenameGet 0 789 2312
assign 1 789 2313
CALLGet 0 789 2313
assign 1 789 2314
notEquals 1 789 2314
assign 1 789 2316
typenameGet 0 789 2316
assign 1 789 2317
IDGet 0 789 2317
assign 1 789 2318
notEquals 1 789 2318
assign 1 0 2320
assign 1 0 2323
assign 1 0 2327
assign 1 789 2330
typenameGet 0 789 2330
assign 1 789 2331
VARGet 0 789 2331
assign 1 789 2332
notEquals 1 789 2332
assign 1 0 2334
assign 1 0 2337
assign 1 0 2341
assign 1 789 2344
typenameGet 0 789 2344
assign 1 789 2345
ACCESSORGet 0 789 2345
assign 1 789 2346
notEquals 1 789 2346
assign 1 0 2348
assign 1 0 2351
assign 1 0 2355
assign 1 0 2358
assign 1 0 2361
assign 1 795 2365
heldGet 0 795 2365
assign 1 795 2366
literalValueGet 0 795 2366
assign 1 795 2367
add 1 795 2367
literalValueSet 1 795 2368
delete 0 796 2369
return 1 0 2376
return 1 0 2379
assign 1 0 2382
assign 1 0 2386
return 1 0 2390
return 1 0 2393
assign 1 0 2396
assign 1 0 2400
return 1 0 2404
return 1 0 2407
assign 1 0 2410
assign 1 0 2414
return 1 0 2418
return 1 0 2421
assign 1 0 2424
assign 1 0 2428
return 1 0 2432
return 1 0 2435
assign 1 0 2438
assign 1 0 2442
return 1 0 2446
return 1 0 2449
assign 1 0 2452
assign 1 0 2456
return 1 0 2460
return 1 0 2463
assign 1 0 2466
assign 1 0 2470
return 1 0 2474
return 1 0 2477
assign 1 0 2480
assign 1 0 2484
return 1 0 2488
return 1 0 2491
assign 1 0 2494
assign 1 0 2498
return 1 0 2502
return 1 0 2505
assign 1 0 2508
assign 1 0 2512
return 1 0 2516
return 1 0 2519
assign 1 0 2522
assign 1 0 2526
return 1 0 2530
return 1 0 2533
assign 1 0 2536
assign 1 0 2540
return 1 0 2544
return 1 0 2547
assign 1 0 2550
assign 1 0 2554
return 1 0 2558
return 1 0 2561
assign 1 0 2564
assign 1 0 2568
return 1 0 2572
return 1 0 2575
assign 1 0 2578
assign 1 0 2582
return 1 0 2586
return 1 0 2589
assign 1 0 2592
assign 1 0 2596
return 1 0 2600
return 1 0 2603
assign 1 0 2606
assign 1 0 2610
return 1 0 2614
return 1 0 2617
assign 1 0 2620
assign 1 0 2624
return 1 0 2628
return 1 0 2631
assign 1 0 2634
assign 1 0 2638
return 1 0 2642
return 1 0 2645
assign 1 0 2648
assign 1 0 2652
return 1 0 2656
return 1 0 2659
assign 1 0 2662
assign 1 0 2666
return 1 0 2670
return 1 0 2673
assign 1 0 2676
assign 1 0 2680
return 1 0 2684
return 1 0 2687
assign 1 0 2690
assign 1 0 2694
return 1 0 2698
return 1 0 2701
assign 1 0 2704
assign 1 0 2708
return 1 0 2712
return 1 0 2715
assign 1 0 2718
assign 1 0 2722
return 1 0 2726
return 1 0 2729
assign 1 0 2732
assign 1 0 2736
return 1 0 2740
return 1 0 2743
assign 1 0 2746
assign 1 0 2750
return 1 0 2754
return 1 0 2757
assign 1 0 2760
assign 1 0 2764
return 1 0 2768
return 1 0 2771
assign 1 0 2774
assign 1 0 2778
return 1 0 2782
return 1 0 2785
assign 1 0 2788
assign 1 0 2792
return 1 0 2796
return 1 0 2799
assign 1 0 2802
assign 1 0 2806
return 1 0 2810
return 1 0 2813
assign 1 0 2816
assign 1 0 2820
return 1 0 2824
return 1 0 2827
assign 1 0 2830
assign 1 0 2834
return 1 0 2838
return 1 0 2841
assign 1 0 2844
assign 1 0 2848
return 1 0 2852
return 1 0 2855
assign 1 0 2858
assign 1 0 2862
return 1 0 2866
return 1 0 2869
assign 1 0 2872
assign 1 0 2876
return 1 0 2880
return 1 0 2883
assign 1 0 2886
assign 1 0 2890
return 1 0 2894
return 1 0 2897
assign 1 0 2900
assign 1 0 2904
return 1 0 2908
return 1 0 2911
assign 1 0 2914
assign 1 0 2918
return 1 0 2922
return 1 0 2925
assign 1 0 2928
assign 1 0 2932
return 1 0 2936
return 1 0 2939
assign 1 0 2942
assign 1 0 2946
return 1 0 2950
return 1 0 2953
assign 1 0 2956
assign 1 0 2960
return 1 0 2964
return 1 0 2967
assign 1 0 2970
assign 1 0 2974
return 1 0 2978
return 1 0 2981
assign 1 0 2984
assign 1 0 2988
return 1 0 2992
return 1 0 2995
assign 1 0 2998
assign 1 0 3002
return 1 0 3006
return 1 0 3009
assign 1 0 3012
assign 1 0 3016
return 1 0 3020
return 1 0 3023
assign 1 0 3026
assign 1 0 3030
return 1 0 3034
return 1 0 3037
assign 1 0 3040
assign 1 0 3044
return 1 0 3048
return 1 0 3051
assign 1 0 3054
assign 1 0 3058
return 1 0 3062
return 1 0 3065
assign 1 0 3068
assign 1 0 3072
return 1 0 3076
return 1 0 3079
assign 1 0 3082
assign 1 0 3086
return 1 0 3090
return 1 0 3093
assign 1 0 3096
assign 1 0 3100
return 1 0 3104
return 1 0 3107
assign 1 0 3110
assign 1 0 3114
return 1 0 3118
return 1 0 3121
assign 1 0 3124
assign 1 0 3128
return 1 0 3132
return 1 0 3135
assign 1 0 3138
assign 1 0 3142
return 1 0 3146
return 1 0 3149
assign 1 0 3152
assign 1 0 3156
return 1 0 3160
return 1 0 3163
assign 1 0 3166
assign 1 0 3170
return 1 0 3174
return 1 0 3177
assign 1 0 3180
assign 1 0 3184
return 1 0 3188
return 1 0 3191
assign 1 0 3194
assign 1 0 3198
return 1 0 3202
return 1 0 3205
assign 1 0 3208
assign 1 0 3212
return 1 0 3216
return 1 0 3219
assign 1 0 3222
assign 1 0 3226
return 1 0 3230
return 1 0 3233
assign 1 0 3236
assign 1 0 3240
return 1 0 3244
return 1 0 3247
assign 1 0 3250
assign 1 0 3254
return 1 0 3258
return 1 0 3261
assign 1 0 3264
assign 1 0 3268
return 1 0 3272
return 1 0 3275
assign 1 0 3278
assign 1 0 3282
return 1 0 3286
return 1 0 3289
assign 1 0 3292
assign 1 0 3296
return 1 0 3300
return 1 0 3303
assign 1 0 3306
assign 1 0 3310
return 1 0 3314
return 1 0 3317
assign 1 0 3320
assign 1 0 3324
return 1 0 3328
return 1 0 3331
assign 1 0 3334
assign 1 0 3338
return 1 0 3342
return 1 0 3345
assign 1 0 3348
assign 1 0 3352
return 1 0 3356
return 1 0 3359
assign 1 0 3362
assign 1 0 3366
return 1 0 3370
return 1 0 3373
assign 1 0 3376
assign 1 0 3380
return 1 0 3384
return 1 0 3387
assign 1 0 3390
assign 1 0 3394
return 1 0 3398
assign 1 0 3401
assign 1 0 3405
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1170478139: return bem_initLibsGetDirect_0();
case 1669509041: return bem_extLibsGetDirect_0();
case -1045627857: return bem_create_0();
case -856707590: return bem_tagGet_0();
case -1085986593: return bem_emitDataGet_0();
case -364769879: return bem_buildSucceededGetDirect_0();
case 2128938873: return bem_parseEmitCompileTimeGetDirect_0();
case 1426474238: return bem_once_0();
case -1933266420: return bem_usedLibrarysStrGetDirect_0();
case -1723287273: return bem_fieldIteratorGet_0();
case -2119901542: return bem_libNameGet_0();
case -723282878: return bem_serializeContents_0();
case -621674786: return bem_extIncludesGetDirect_0();
case 1358224300: return bem_loadSynsGet_0();
case 1198242976: return bem_parseEmitTimeGetDirect_0();
case 314338513: return bem_readBufferGetDirect_0();
case -831328384: return bem_initLibsGet_0();
case 2117463639: return bem_makeNameGetDirect_0();
case 683976526: return bem_buildMessageGetDirect_0();
case -590452234: return bem_emitterGet_0();
case 1519571232: return bem_singleCCGetDirect_0();
case 1072311080: return bem_saveIdsGetDirect_0();
case 1432143315: return bem_deployUsedLibrariesGetDirect_0();
case -348782970: return bem_serializeToString_0();
case -681547894: return bem_buildPathGet_0();
case -646782562: return bem_includePathGetDirect_0();
case -1255556255: return bem_setClassesToWrite_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 223060900: return bem_putLineNumbersInTraceGetDirect_0();
case -1868269224: return bem_builtGetDirect_0();
case 1740133881: return bem_emitFlagsGetDirect_0();
case -1894799610: return bem_usedLibrarysStrGet_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case -892061027: return bem_loadSynsGetDirect_0();
case 2094596544: return bem_emitFileHeaderGet_0();
case 1316981654: return bem_printAstElementsGet_0();
case 1340694490: return bem_new_0();
case 1142074911: return bem_fromFileGet_0();
case -662535211: return bem_makeGetDirect_0();
case 1198348151: return bem_emitCommonGet_0();
case -1534870281: return bem_ntypesGet_0();
case -1965810124: return bem_emitFlagsGet_0();
case 354206806: return bem_makeNameGet_0();
case -157083963: return bem_closeLibrariesGet_0();
case 827431059: return bem_emitPathGet_0();
case 1069321007: return bem_parseEmitCompileTimeGet_0();
case -835303456: return bem_many_0();
case 1191639251: return bem_deployLibraryGet_0();
case 1516238623: return bem_saveSynsGetDirect_0();
case -1296663567: return bem_estrGet_0();
case 344757576: return bem_sharedEmitterGetDirect_0();
case 1918504948: return bem_extLibsGet_0();
case -1350181023: return bem_libNameGetDirect_0();
case 983757099: return bem_buildPathGetDirect_0();
case 1504058251: return bem_makeGet_0();
case -1384571420: return bem_newlineGet_0();
case -231078638: return bem_closeLibrariesGetDirect_0();
case -1874461592: return bem_startTimeGet_0();
case 988955504: return bem_parseEmitTimeGet_0();
case 1937125918: return bem_emitCs_0();
case 365358239: return bem_emitDebugGetDirect_0();
case 1776712568: return bem_iteratorGet_0();
case 507482431: return bem_exeNameGetDirect_0();
case 785821127: return bem_deployFilesFromGet_0();
case -120325228: return bem_linkLibArgsGetDirect_0();
case 1767781701: return bem_prepMakeGet_0();
case -838392685: return bem_ownProcessGetDirect_0();
case -919529811: return bem_printStepsGet_0();
case 1493582929: return bem_compilerGetDirect_0();
case 792440645: return bem_doEmitGetDirect_0();
case -770276999: return bem_deployFilesToGetDirect_0();
case 16444359: return bem_genOnlyGetDirect_0();
case -653623125: return bem_platformGet_0();
case 1957215882: return bem_runGet_0();
case -1384036136: return bem_extLinkObjectsGetDirect_0();
case -435641994: return bem_startTimeGetDirect_0();
case 732471999: return bem_genOnlyGet_0();
case -466304522: return bem_doEmitGet_0();
case -108664911: return bem_constantsGetDirect_0();
case 368722137: return bem_emitChecksGetDirect_0();
case 1175117090: return bem_estrGetDirect_0();
case -570065140: return bem_emitChecksGet_0();
case -1725374063: return bem_parseGetDirect_0();
case 1750668466: return bem_readBufferGet_0();
case -1230263951: return bem_go_0();
case -227614836: return bem_printAstElementsGetDirect_0();
case -651368928: return bem_exeNameGet_0();
case 2041349618: return bem_lctokGetDirect_0();
case 2134657919: return bem_doWhat_0();
case -887167109: return bem_fromFileGetDirect_0();
case -1321438288: return bem_codeGetDirect_0();
case 633636805: return bem_closeLibrariesStrGet_0();
case 966380131: return bem_printPlacesGetDirect_0();
case -953988327: return bem_outputPlatformGet_0();
case -1577230717: return bem_singleCCGet_0();
case 1353872218: return bem_extIncludesGet_0();
case 2024213147: return bem_emitFileHeaderGetDirect_0();
case -2091217929: return bem_toAny_0();
case -1231995304: return bem_emitDebugGet_0();
case 194113337: return bem_usedLibrarysGetDirect_0();
case -407306574: return bem_printStepsGetDirect_0();
case 1112452953: return bem_deployLibraryGetDirect_0();
case 353377191: return bem_classNameGet_0();
case 1323214414: return bem_lctokGet_0();
case 1541835912: return bem_putLineNumbersInTraceGet_0();
case 629575742: return bem_saveSynsGet_0();
case -68579519: return bem_printAllAstGet_0();
case -185187127: return bem_deployPathGetDirect_0();
case 1365471067: return bem_print_0();
case 1690848108: return bem_echo_0();
case 1851347889: return bem_deployFilesFromGetDirect_0();
case 1644755620: return bem_emitDataGetDirect_0();
case -2022346249: return bem_deployPathGet_0();
case -255288764: return bem_paramsGet_0();
case 1713519438: return bem_mainNameGet_0();
case 1957580392: return bem_runArgsGetDirect_0();
case -1586294475: return bem_codeGet_0();
case -1403580132: return bem_emitLibraryGetDirect_0();
case -1287943088: return bem_copy_0();
case 140554408: return bem_deployFilesToGet_0();
case -1159894170: return bem_argsGet_0();
case -303260697: return bem_printPlacesGet_0();
case 1392185121: return bem_toBuildGet_0();
case 212805446: return bem_includePathGet_0();
case 1963695386: return bem_toString_0();
case -66927170: return bem_saveIdsGet_0();
case -946844537: return bem_builtGet_0();
case 996941134: return bem_config_0();
case -1314899429: return bem_emitPathGetDirect_0();
case 1594275013: return bem_constantsGet_0();
case 555723375: return bem_twtokGet_0();
case 39521997: return bem_platformGetDirect_0();
case 341544195: return bem_emitLangsGetDirect_0();
case -961308661: return bem_emitCommonGetDirect_0();
case 517177722: return bem_compilerGet_0();
case 967003885: return bem_linkLibArgsGet_0();
case 50961827: return bem_paramsGetDirect_0();
case 408923972: return bem_mainNameGetDirect_0();
case -176464850: return bem_printAllAstGetDirect_0();
case -64996989: return bem_toBuildGetDirect_0();
case -1785712022: return bem_parseGet_0();
case -1186600628: return bem_main_0();
case 525999126: return bem_ccObjArgsGetDirect_0();
case 413597748: return bem_printAstGet_0();
case 1171767778: return bem_prepMakeGetDirect_0();
case -503420440: return bem_nlGet_0();
case -382946106: return bem_buildSucceededGet_0();
case 605014677: return bem_emitLibraryGet_0();
case 830869762: return bem_runGetDirect_0();
case -446928164: return bem_closeLibrariesStrGetDirect_0();
case 711082063: return bem_newlineGetDirect_0();
case -1737712485: return bem_sharedEmitterGet_0();
case -1303115743: return bem_hashGet_0();
case -19810359: return bem_ownProcessGet_0();
case 1898000883: return bem_buildMessageGet_0();
case -1688617338: return bem_makeArgsGet_0();
case -1949858061: return bem_emitLangsGet_0();
case 1432922201: return bem_makeArgsGetDirect_0();
case -440347352: return bem_compilerProfileGet_0();
case -2099382498: return bem_deployUsedLibrariesGet_0();
case 1761135305: return bem_ntypesGetDirect_0();
case 492381958: return bem_extLinkObjectsGet_0();
case -1728795578: return bem_outputPlatformGetDirect_0();
case 61040956: return bem_runArgsGet_0();
case 1312250402: return bem_parseTimeGet_0();
case -184584349: return bem_printAstGetDirect_0();
case -1307701649: return bem_usedLibrarysGet_0();
case 1764435826: return bem_nlGetDirect_0();
case 1927956798: return bem_argsGetDirect_0();
case 756642383: return bem_fieldNamesGet_0();
case -741735469: return bem_twtokGetDirect_0();
case -310081220: return bem_compilerProfileGetDirect_0();
case 7751983: return bem_parseTimeGetDirect_0();
case 805348767: return bem_serializationIteratorGet_0();
case -2081814050: return bem_ccObjArgsGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1603210807: return bem_ownProcessSetDirect_1(bevd_0);
case 1824531343: return bem_doParse_1(bevd_0);
case 563567213: return bem_printStepsSetDirect_1(bevd_0);
case 1658019503: return bem_estrSetDirect_1(bevd_0);
case 1565092233: return bem_emitDebugSet_1(bevd_0);
case 511749244: return bem_ccObjArgsSet_1(bevd_0);
case -1270637176: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 797504046: return bem_singleCCSetDirect_1(bevd_0);
case -734473535: return bem_emitFlagsSet_1(bevd_0);
case 357480976: return bem_nlSet_1(bevd_0);
case -1658894358: return bem_loadSynsSet_1(bevd_0);
case -1765363176: return bem_emitChecksSet_1(bevd_0);
case -1391860222: return bem_extLibsSet_1(bevd_0);
case 2001273702: return bem_libNameSetDirect_1(bevd_0);
case 1127526161: return bem_emitCommonSetDirect_1(bevd_0);
case -88702062: return bem_deployLibrarySetDirect_1(bevd_0);
case 357593141: return bem_includePathSetDirect_1(bevd_0);
case 1576132709: return bem_doEmitSet_1(bevd_0);
case 984659840: return bem_emitPathSetDirect_1(bevd_0);
case 69409864: return bem_compilerSetDirect_1(bevd_0);
case 1017667285: return bem_parseSetDirect_1(bevd_0);
case 1261591207: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1746500551: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case 352763098: return bem_emitCommonSet_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1657656600: return bem_parseSet_1(bevd_0);
case -1009600263: return bem_buildSucceededSet_1(bevd_0);
case 919133043: return bem_parseEmitTimeSetDirect_1(bevd_0);
case -1318130558: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -315729275: return bem_initLibsSet_1(bevd_0);
case 550188670: return bem_emitLibrarySetDirect_1(bevd_0);
case 1707421985: return bem_saveSynsSetDirect_1(bevd_0);
case -1753494050: return bem_makeSetDirect_1(bevd_0);
case -1221570017: return bem_extIncludesSetDirect_1(bevd_0);
case 568310901: return bem_sharedEmitterSet_1(bevd_0);
case -1581463624: return bem_exeNameSetDirect_1(bevd_0);
case -351384733: return bem_outputPlatformSet_1(bevd_0);
case -550139783: return bem_otherType_1(bevd_0);
case -1674095678: return bem_paramsSetDirect_1(bevd_0);
case 1800605179: return bem_makeNameSetDirect_1(bevd_0);
case -458868888: return bem_argsSet_1(bevd_0);
case -979600985: return bem_getSynNp_1(bevd_0);
case -346594103: return bem_saveSynsSet_1(bevd_0);
case 1606416640: return bem_printStepsSet_1(bevd_0);
case 1334462315: return bem_makeArgsSet_1(bevd_0);
case -85738597: return bem_platformSetDirect_1(bevd_0);
case -1485356336: return bem_runArgsSetDirect_1(bevd_0);
case -126363176: return bem_sharedEmitterSetDirect_1(bevd_0);
case 506627437: return bem_ccObjArgsSetDirect_1(bevd_0);
case 1037119341: return bem_parseTimeSet_1(bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 139517862: return bem_deployUsedLibrariesSet_1(bevd_0);
case -1162964084: return bem_saveIdsSetDirect_1(bevd_0);
case 1105731651: return bem_startTimeSetDirect_1(bevd_0);
case -1897999644: return bem_parseTimeSetDirect_1(bevd_0);
case -1197269446: return bem_runSet_1(bevd_0);
case -1225088268: return bem_runSetDirect_1(bevd_0);
case -2023009099: return bem_mainNameSetDirect_1(bevd_0);
case 475132769: return bem_argsSetDirect_1(bevd_0);
case 1531583249: return bem_closeLibrariesStrSet_1(bevd_0);
case -1941758512: return bem_buildSyns_1(bevd_0);
case 1882201819: return bem_doEmitSetDirect_1(bevd_0);
case -278781007: return bem_ownProcessSet_1(bevd_0);
case -1485253858: return bem_constantsSetDirect_1(bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case -1243542148: return bem_deployFilesFromSet_1(bevd_0);
case -2076883091: return bem_printAllAstSetDirect_1(bevd_0);
case 1504909291: return bem_emitDebugSetDirect_1(bevd_0);
case 1323221657: return bem_printAstElementsSet_1(bevd_0);
case 1104228579: return bem_initLibsSetDirect_1(bevd_0);
case -94454922: return bem_deployFilesFromSetDirect_1(bevd_0);
case -449695192: return bem_closeLibrariesSetDirect_1(bevd_0);
case -1611872352: return bem_buildMessageSet_1(bevd_0);
case -38967314: return bem_emitFileHeaderSet_1(bevd_0);
case -244538924: return bem_usedLibrarysSet_1(bevd_0);
case 1518986146: return bem_readBufferSet_1(bevd_0);
case 1765616485: return bem_emitLangsSetDirect_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2135262010: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case -1671238131: return bem_closeLibrariesSet_1(bevd_0);
case -1507759525: return bem_makeNameSet_1(bevd_0);
case 1474715793: return bem_singleCCSet_1(bevd_0);
case 35198338: return bem_estrSet_1(bevd_0);
case 2137933692: return bem_genOnlySetDirect_1(bevd_0);
case 1446816460: return bem_newlineSetDirect_1(bevd_0);
case 1591953408: return bem_loadSynsSetDirect_1(bevd_0);
case 296210229: return bem_startTimeSet_1(bevd_0);
case -1339812408: return bem_lctokSetDirect_1(bevd_0);
case -342934459: return bem_ntypesSetDirect_1(bevd_0);
case 835566700: return bem_emitLibrarySet_1(bevd_0);
case 1468868867: return bem_linkLibArgsSet_1(bevd_0);
case -1412377002: return bem_undef_1(bevd_0);
case 234600908: return bem_deployFilesToSetDirect_1(bevd_0);
case 1916660659: return bem_runArgsSet_1(bevd_0);
case 2041725367: return bem_printPlacesSetDirect_1(bevd_0);
case -240972194: return bem_compilerProfileSet_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case 1299830654: return bem_newlineSet_1(bevd_0);
case -1992785866: return bem_toBuildSetDirect_1(bevd_0);
case -1412130726: return bem_toBuildSet_1(bevd_0);
case -661339921: return bem_libNameSet_1(bevd_0);
case 1528534623: return bem_emitFlagsSetDirect_1(bevd_0);
case -480348635: return bem_def_1(bevd_0);
case 1138426887: return bem_deployFilesToSet_1(bevd_0);
case 1934786081: return bem_mainNameSet_1(bevd_0);
case -1630942269: return bem_emitFileHeaderSetDirect_1(bevd_0);
case -895494600: return bem_makeSet_1(bevd_0);
case -793887534: return bem_otherClass_1(bevd_0);
case -1206898698: return bem_exeNameSet_1(bevd_0);
case -1847462687: return bem_ntypesSet_1(bevd_0);
case 258139199: return bem_emitDataSetDirect_1(bevd_0);
case -2058930287: return bem_paramsSet_1(bevd_0);
case 483367780: return bem_parseEmitTimeSet_1(bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
case 442141677: return bem_extLibsSetDirect_1(bevd_0);
case 727549085: return bem_codeSetDirect_1(bevd_0);
case 1718862657: return bem_prepMakeSetDirect_1(bevd_0);
case -1764443671: return bem_buildPathSetDirect_1(bevd_0);
case 1792917781: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 1253791917: return bem_extLinkObjectsSetDirect_1(bevd_0);
case 91584758: return bem_fromFileSet_1(bevd_0);
case -781527231: return bem_buildPathSet_1(bevd_0);
case 144034433: return bem_printAstSet_1(bevd_0);
case 613125343: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case -1641562783: return bem_codeSet_1(bevd_0);
case 846259962: return bem_deployPathSetDirect_1(bevd_0);
case 1378555078: return bem_usedLibrarysStrSet_1(bevd_0);
case -1385084245: return bem_outputPlatformSetDirect_1(bevd_0);
case -1188141894: return bem_includePathSet_1(bevd_0);
case -1669951654: return bem_buildMessageSetDirect_1(bevd_0);
case -115800389: return bem_makeArgsSetDirect_1(bevd_0);
case -908111025: return bem_printAstElementsSetDirect_1(bevd_0);
case -56704779: return bem_printAllAstSet_1(bevd_0);
case 2011224145: return bem_constantsSet_1(bevd_0);
case 1708484055: return bem_deployLibrarySet_1(bevd_0);
case -1088339710: return bem_printAstSetDirect_1(bevd_0);
case -1622245404: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 10005900: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 167132191: return bem_printPlacesSet_1(bevd_0);
case -1034180046: return bem_builtSet_1(bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case 1035705370: return bem_genOnlySet_1(bevd_0);
case 30248699: return bem_linkLibArgsSetDirect_1(bevd_0);
case -654288468: return bem_deployPathSet_1(bevd_0);
case 478523662: return bem_usedLibrarysSetDirect_1(bevd_0);
case -532384934: return bem_platformSet_1(bevd_0);
case 738509174: return bem_emitDataSet_1(bevd_0);
case -1816310899: return bem_emitPathSet_1(bevd_0);
case 1443857959: return bem_compilerProfileSetDirect_1(bevd_0);
case 243609532: return bem_emitChecksSetDirect_1(bevd_0);
case -1585593739: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case 1951286996: return bem_builtSetDirect_1(bevd_0);
case -230165944: return bem_buildSucceededSetDirect_1(bevd_0);
case 1904305439: return bem_nlSetDirect_1(bevd_0);
case -1003970700: return bem_prepMakeSet_1(bevd_0);
case 74650273: return bem_saveIdsSet_1(bevd_0);
case 2129603513: return bem_defined_1(bevd_0);
case 1762282323: return bem_twtokSetDirect_1(bevd_0);
case -1906479769: return bem_extLinkObjectsSet_1(bevd_0);
case -2068038326: return bem_twtokSet_1(bevd_0);
case 2055347907: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case -1362880618: return bem_fromFileSetDirect_1(bevd_0);
case -139435103: return bem_emitLangsSet_1(bevd_0);
case -1833905819: return bem_lctokSet_1(bevd_0);
case 553958958: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -79068398: return bem_extIncludesSet_1(bevd_0);
case 1470536886: return bem_compilerSet_1(bevd_0);
case 1522947077: return bem_readBufferSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1293014739: return bem_buildLiteral_2(bevd_0, bevd_1);
case 425706107: return bem_getSyn_2(bevd_0, bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1981278438: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
