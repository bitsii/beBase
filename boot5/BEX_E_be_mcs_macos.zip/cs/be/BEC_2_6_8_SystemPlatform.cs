namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemPlatform : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemPlatform() { }
static BEC_2_6_8_SystemPlatform() { }
private static byte[] becc_BEC_2_6_8_SystemPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_8_SystemPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_0 = {0x6D,0x61,0x63,0x6F,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_1 = {0x6C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_2 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_3 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_4 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_5 = {0x2F,0x64,0x65,0x76,0x2F,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_6 = {0x2E,0x73,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_7 = {0x4D,0x61,0x63,0x4F,0x53};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_8 = {0x4C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_9 = {0x46,0x72,0x65,0x65,0x42,0x53,0x44};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_11 = {0x6E,0x75,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_12 = {0x2E,0x62,0x61,0x74};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_13 = {0x4D,0x53,0x57,0x69,0x6E};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_14 = {0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_14, 9));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_15 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x2C,0x20,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x69,0x6E,0x20,0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_15, 60));
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 5));
public static new BEC_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_inst;

public static new BET_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_properName;
public BEC_2_5_4_LogicBool bevp_isNix;
public BEC_2_5_4_LogicBool bevp_isWin;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_otherSeparator;
public BEC_2_4_6_TextString bevp_nullFile;
public BEC_2_4_6_TextString bevp_scriptExt;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_new_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_0;
bevt_2_tmpany_phold = bevp_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_1;
bevt_4_tmpany_phold = bevp_name.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 637 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 637 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_7_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_2;
bevt_6_tmpany_phold = bevp_name.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 637 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 637 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 637 */ {
bevp_isNix = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isWin = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_otherSeparator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_nullFile = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_5));
bevp_scriptExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_6));
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_3;
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevp_properName = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_7));
} /* Line: 645 */
 else  /* Line: 644 */ {
bevt_11_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_4;
bevt_10_tmpany_phold = bevp_name.bem_equals_1(bevt_11_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 646 */ {
bevp_properName = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_8));
} /* Line: 647 */
 else  /* Line: 644 */ {
bevt_13_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_5;
bevt_12_tmpany_phold = bevp_name.bem_equals_1(bevt_13_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevp_properName = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_8_SystemPlatform_bels_9));
} /* Line: 649 */
} /* Line: 644 */
} /* Line: 644 */
} /* Line: 644 */
 else  /* Line: 637 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_6;
bevt_14_tmpany_phold = bevp_name.bem_equals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 651 */ {
bevp_isNix = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isWin = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_otherSeparator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_nullFile = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_11));
bevp_scriptExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_6_8_SystemPlatform_bels_12));
bevp_properName = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_6_8_SystemPlatform_bels_13));
} /* Line: 658 */
 else  /* Line: 659 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_7;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevp_name);
bevt_20_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_8;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_17_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_16_tmpany_phold);
} /* Line: 660 */
} /* Line: 637 */
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_22_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_9;
bevt_21_tmpany_phold = bevp_name.bem_equals_1(bevt_22_tmpany_phold);
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 663 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(1146834424);
} /* Line: 665 */
 else  /* Line: 666 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(1146834424);
} /* Line: 667 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_properNameGet_0() {
return bevp_properName;
} /*method end*/
public BEC_2_4_6_TextString bem_properNameGetDirect_0() {
return bevp_properName;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_properNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_properName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_properNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_properName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isNixGet_0() {
return bevp_isNix;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNixGetDirect_0() {
return bevp_isNix;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_isNixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isNixSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isWinGet_0() {
return bevp_isWin;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isWinGetDirect_0() {
return bevp_isWin;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_isWinSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isWinSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGetDirect_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_otherSeparatorGet_0() {
return bevp_otherSeparator;
} /*method end*/
public BEC_2_4_6_TextString bem_otherSeparatorGetDirect_0() {
return bevp_otherSeparator;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_otherSeparatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_otherSeparatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nullFileGet_0() {
return bevp_nullFile;
} /*method end*/
public BEC_2_4_6_TextString bem_nullFileGetDirect_0() {
return bevp_nullFile;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_nullFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nullFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_scriptExtGet_0() {
return bevp_scriptExt;
} /*method end*/
public BEC_2_4_6_TextString bem_scriptExtGetDirect_0() {
return bevp_scriptExt;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_scriptExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_scriptExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_scriptExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_scriptExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {631, 632, 637, 637, 0, 637, 637, 0, 0, 0, 637, 637, 0, 0, 638, 639, 640, 641, 642, 643, 644, 644, 645, 646, 646, 647, 648, 648, 649, 651, 651, 652, 653, 654, 655, 656, 657, 658, 660, 660, 660, 660, 660, 660, 662, 663, 663, 665, 667, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {56, 57, 85, 86, 88, 91, 92, 94, 97, 101, 104, 105, 107, 110, 114, 115, 116, 117, 118, 119, 120, 121, 123, 126, 127, 129, 132, 133, 135, 141, 142, 144, 145, 146, 147, 148, 149, 150, 153, 154, 155, 156, 157, 158, 161, 162, 163, 165, 168, 173, 176, 179, 183, 187, 190, 193, 197, 201, 204, 207, 211, 215, 218, 221, 225, 229, 232, 235, 239, 243, 246, 249, 253, 257, 260, 263, 267, 271, 274, 277, 281, 285, 288, 291, 295};
/* BEGIN LINEINFO 
assign 1 631 56
buildProfile 0 632 57
assign 1 637 85
new 0 637 85
assign 1 637 86
equals 1 637 86
assign 1 0 88
assign 1 637 91
new 0 637 91
assign 1 637 92
equals 1 637 92
assign 1 0 94
assign 1 0 97
assign 1 0 101
assign 1 637 104
new 0 637 104
assign 1 637 105
equals 1 637 105
assign 1 0 107
assign 1 0 110
assign 1 638 114
new 0 638 114
assign 1 639 115
new 0 639 115
assign 1 640 116
new 0 640 116
assign 1 641 117
new 0 641 117
assign 1 642 118
new 0 642 118
assign 1 643 119
new 0 643 119
assign 1 644 120
new 0 644 120
assign 1 644 121
equals 1 644 121
assign 1 645 123
new 0 645 123
assign 1 646 126
new 0 646 126
assign 1 646 127
equals 1 646 127
assign 1 647 129
new 0 647 129
assign 1 648 132
new 0 648 132
assign 1 648 133
equals 1 648 133
assign 1 649 135
new 0 649 135
assign 1 651 141
new 0 651 141
assign 1 651 142
equals 1 651 142
assign 1 652 144
new 0 652 144
assign 1 653 145
new 0 653 145
assign 1 654 146
new 0 654 146
assign 1 655 147
new 0 655 147
assign 1 656 148
new 0 656 148
assign 1 657 149
new 0 657 149
assign 1 658 150
new 0 658 150
assign 1 660 153
new 0 660 153
assign 1 660 154
add 1 660 154
assign 1 660 155
new 0 660 155
assign 1 660 156
add 1 660 156
assign 1 660 157
new 1 660 157
throw 1 660 158
assign 1 662 161
new 0 662 161
assign 1 663 162
new 0 663 162
assign 1 663 163
equals 1 663 163
assign 1 665 165
unixNewlineGet 0 665 165
assign 1 667 168
unixNewlineGet 0 667 168
return 1 0 173
return 1 0 176
assign 1 0 179
assign 1 0 183
return 1 0 187
return 1 0 190
assign 1 0 193
assign 1 0 197
return 1 0 201
return 1 0 204
assign 1 0 207
assign 1 0 211
return 1 0 215
return 1 0 218
assign 1 0 221
assign 1 0 225
return 1 0 229
return 1 0 232
assign 1 0 235
assign 1 0 239
return 1 0 243
return 1 0 246
assign 1 0 249
assign 1 0 253
return 1 0 257
return 1 0 260
assign 1 0 263
assign 1 0 267
return 1 0 271
return 1 0 274
assign 1 0 277
assign 1 0 281
return 1 0 285
return 1 0 288
assign 1 0 291
assign 1 0 295
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 401182894: return bem_isNixGetDirect_0();
case -1892820705: return bem_properNameGet_0();
case -766985723: return bem_nameGetDirect_0();
case 64930083: return bem_new_0();
case -1160093527: return bem_fieldIteratorGet_0();
case -426042336: return bem_separatorGetDirect_0();
case 265775004: return bem_tagGet_0();
case 1259379161: return bem_sourceFileNameGet_0();
case -379805637: return bem_nullFileGet_0();
case 1075457053: return bem_nullFileGetDirect_0();
case 338892103: return bem_serializeContents_0();
case 1685630819: return bem_toAny_0();
case 1035440652: return bem_newlineGet_0();
case 324558137: return bem_serializationIteratorGet_0();
case 1719514234: return bem_properNameGetDirect_0();
case -1468115075: return bem_scriptExtGetDirect_0();
case -224812992: return bem_scriptExtGet_0();
case -1924670591: return bem_print_0();
case -139101935: return bem_isWinGetDirect_0();
case 1616298039: return bem_toString_0();
case 680668687: return bem_isNixGet_0();
case -477793454: return bem_deserializeClassNameGet_0();
case 331416977: return bem_otherSeparatorGet_0();
case -2145124906: return bem_fieldNamesGet_0();
case -383409287: return bem_hashGet_0();
case 712946172: return bem_separatorGet_0();
case 1698440478: return bem_classNameGet_0();
case 1409367716: return bem_iteratorGet_0();
case -698592158: return bem_once_0();
case 857744439: return bem_serializeToString_0();
case 447398905: return bem_copy_0();
case 24523401: return bem_create_0();
case 81663168: return bem_isWinGet_0();
case 835103543: return bem_newlineGetDirect_0();
case 1574541715: return bem_echo_0();
case 384092963: return bem_buildProfile_0();
case 841151954: return bem_nameGet_0();
case 1136504236: return bem_otherSeparatorGetDirect_0();
case 621904783: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -52657747: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 604959651: return bem_otherClass_1(bevd_0);
case 1464921499: return bem_def_1(bevd_0);
case -1768544084: return bem_notEquals_1(bevd_0);
case 129529538: return bem_newlineSet_1(bevd_0);
case 932713001: return bem_nullFileSetDirect_1(bevd_0);
case 1561395236: return bem_scriptExtSet_1(bevd_0);
case -1859292781: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1729689734: return bem_separatorSetDirect_1(bevd_0);
case 1015788846: return bem_isWinSet_1(bevd_0);
case -2122248222: return bem_separatorSet_1(bevd_0);
case -12851290: return bem_otherSeparatorSet_1(bevd_0);
case -738844966: return bem_isWinSetDirect_1(bevd_0);
case -1921243842: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2143817101: return bem_copyTo_1(bevd_0);
case 1582703619: return bem_undef_1(bevd_0);
case -1011975947: return bem_isNixSetDirect_1(bevd_0);
case 854851905: return bem_sameType_1(bevd_0);
case -2081973429: return bem_otherSeparatorSetDirect_1(bevd_0);
case 933039677: return bem_isNixSet_1(bevd_0);
case -968521563: return bem_sameObject_1(bevd_0);
case 764191291: return bem_properNameSet_1(bevd_0);
case -1270041233: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1408995072: return bem_scriptExtSetDirect_1(bevd_0);
case -454090959: return bem_defined_1(bevd_0);
case 1662953083: return bem_nameSetDirect_1(bevd_0);
case -346349789: return bem_equals_1(bevd_0);
case -350262427: return bem_properNameSetDirect_1(bevd_0);
case -1932510652: return bem_sameClass_1(bevd_0);
case 1882195140: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2025213657: return bem_newlineSetDirect_1(bevd_0);
case 1635542344: return bem_nameSet_1(bevd_0);
case -2054707322: return bem_nullFileSet_1(bevd_0);
case -907096239: return bem_otherType_1(bevd_0);
case -685667652: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1030898412: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1425194636: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1465437715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -918533412: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1025227425: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2024613175: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1438061795: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst = (BEC_2_6_8_SystemPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_type;
}
}
}
