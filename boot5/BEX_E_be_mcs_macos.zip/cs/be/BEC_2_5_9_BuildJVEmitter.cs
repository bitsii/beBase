namespace be {
/* IO:File: source/build/JVEmitter.be */
public sealed class BEC_2_5_9_BuildJVEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
static BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_20, 31));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_22, 15));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_25, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_26, 14));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_23, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_29, 38));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_36, 8));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_37, 1));
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_39 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJVEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJVEmitter_bels_39, 9));
public static new BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static new BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 27 */
bevt_10_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_8_tmpany_phold.bemd_0(642173546);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_23_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_23_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 37 */ {
bevt_24_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 37 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1532131234);
if (bevl_firstmnsyn.bevi_bool) /* Line: 38 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 39 */
 else  /* Line: 40 */ {
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
} /* Line: 41 */
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_28_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 43 */
 else  /* Line: 37 */ {
break;
} /* Line: 37 */
} /* Line: 37 */
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_32_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_32_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 50 */ {
bevt_33_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1532131234);
if (bevl_firstptsyn.bevi_bool) /* Line: 51 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 52 */
 else  /* Line: 53 */ {
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
} /* Line: 54 */
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_37_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 56 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevt_42_tmpany_phold.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_tmpany_phold.bem_addValue_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_tmpany_phold);
bevl_tout.bemd_1(-423262360, bevl_bet);
bevl_tout.bemd_0(77620147);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-902248231);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(512136633);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_5;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 90 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 103 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 104 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_3_tmpany_phold;
} /* Line: 111 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_9;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-1547082045);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_11;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJVEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 81, 81, 81, 81, 86, 87, 88, 88, 89, 89, 90, 90, 92, 92, 92, 93, 99, 99, 99, 99, 99, 99, 103, 103, 103, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 0, 0, 0, 111, 111, 113, 113, 117, 117, 121, 121, 121, 121, 121, 122, 122, 122, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 125, 129, 129, 129, 133, 133, 133, 133, 133, 133, 133, 137, 137, 141, 141, 145, 145, 145, 145};
public static new int[] bevs_smnlec
 = new int[] {67, 68, 69, 70, 128, 129, 130, 131, 136, 137, 138, 139, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 164, 167, 169, 171, 174, 175, 177, 178, 179, 180, 186, 187, 188, 189, 190, 191, 192, 193, 194, 194, 197, 199, 201, 204, 205, 207, 208, 209, 210, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 281, 282, 283, 284, 285, 295, 296, 297, 298, 300, 301, 302, 303, 305, 306, 307, 308, 317, 318, 319, 320, 321, 322, 330, 335, 336, 338, 341, 345, 348, 349, 351, 352, 360, 365, 366, 368, 371, 375, 378, 379, 381, 382, 386, 387, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 436, 437, 438, 447, 448, 449, 450, 451, 452, 453, 457, 458, 462, 463, 469, 470, 471, 472};
/* BEGIN LINEINFO 
assign 1 16 67
new 0 16 67
assign 1 17 68
new 0 17 68
assign 1 18 69
new 0 18 69
new 1 22 70
assign 1 26 128
classDirGet 0 26 128
assign 1 26 129
fileGet 0 26 129
assign 1 26 130
existsGet 0 26 130
assign 1 26 131
not 0 26 136
assign 1 27 137
classDirGet 0 27 137
assign 1 27 138
fileGet 0 27 138
makeDirs 0 27 139
assign 1 29 141
typePathGet 0 29 141
assign 1 29 142
fileGet 0 29 142
assign 1 29 143
writerGet 0 29 143
assign 1 29 144
open 0 29 144
assign 1 30 145
new 0 30 145
assign 1 31 146
new 0 31 146
addValue 1 31 147
assign 1 32 148
new 0 32 148
assign 1 32 149
addValue 1 32 149
assign 1 32 150
typeEmitNameGet 0 32 150
assign 1 32 151
addValue 1 32 151
assign 1 32 152
new 0 32 152
addValue 1 32 153
assign 1 33 154
new 0 33 154
assign 1 33 155
addValue 1 33 155
assign 1 33 156
typeEmitNameGet 0 33 156
assign 1 33 157
addValue 1 33 157
assign 1 33 158
new 0 33 158
addValue 1 33 159
assign 1 35 160
new 0 35 160
addValue 1 35 161
assign 1 36 162
new 0 36 162
assign 1 37 163
mtdListGet 0 37 163
assign 1 37 164
iteratorGet 0 0 164
assign 1 37 167
hasNextGet 0 37 167
assign 1 37 169
nextGet 0 37 169
assign 1 39 171
new 0 39 171
assign 1 41 174
new 0 41 174
addValue 1 41 175
assign 1 43 177
addValue 1 43 177
assign 1 43 178
nameGet 0 43 178
assign 1 43 179
addValue 1 43 179
addValue 1 43 180
assign 1 45 186
new 0 45 186
addValue 1 45 187
assign 1 46 188
new 0 46 188
addValue 1 46 189
assign 1 48 190
new 0 48 190
addValue 1 48 191
assign 1 49 192
new 0 49 192
assign 1 50 193
ptyListGet 0 50 193
assign 1 50 194
iteratorGet 0 0 194
assign 1 50 197
hasNextGet 0 50 197
assign 1 50 199
nextGet 0 50 199
assign 1 52 201
new 0 52 201
assign 1 54 204
new 0 54 204
addValue 1 54 205
assign 1 56 207
addValue 1 56 207
assign 1 56 208
nameGet 0 56 208
assign 1 56 209
addValue 1 56 209
addValue 1 56 210
assign 1 58 216
new 0 58 216
addValue 1 58 217
assign 1 60 218
new 0 60 218
addValue 1 60 219
assign 1 62 220
new 0 62 220
addValue 1 62 221
assign 1 63 222
new 0 63 222
assign 1 63 223
addValue 1 63 223
assign 1 63 224
emitNameGet 0 63 224
assign 1 63 225
addValue 1 63 225
assign 1 63 226
new 0 63 226
addValue 1 63 227
assign 1 64 228
new 0 64 228
addValue 1 64 229
assign 1 65 230
new 0 65 230
addValue 1 65 231
write 1 66 232
close 0 67 233
assign 1 71 254
new 0 71 254
assign 1 71 255
toString 0 71 255
assign 1 71 256
add 1 71 256
incrementValue 0 72 257
assign 1 73 258
new 0 73 258
assign 1 73 259
addValue 1 73 259
assign 1 73 260
addValue 1 73 260
assign 1 73 261
new 0 73 261
assign 1 73 262
addValue 1 73 262
addValue 1 73 263
assign 1 75 264
containedGet 0 75 264
assign 1 75 265
firstGet 0 75 265
assign 1 75 266
containedGet 0 75 266
assign 1 75 267
firstGet 0 75 267
assign 1 75 268
new 0 75 268
assign 1 75 269
add 1 75 269
assign 1 75 270
new 0 75 270
assign 1 75 271
add 1 75 271
assign 1 75 272
finalAssign 4 75 272
addValue 1 75 273
assign 1 81 281
new 0 81 281
assign 1 81 282
add 1 81 282
assign 1 81 283
new 0 81 283
assign 1 81 284
add 1 81 284
return 1 81 285
getInt 2 86 295
assign 1 87 296
toHexString 1 87 296
assign 1 88 297
new 0 88 297
assign 1 88 298
begins 1 88 298
assign 1 89 300
new 0 89 300
assign 1 89 301
substring 1 89 301
assign 1 90 302
new 0 90 302
addValue 1 90 303
assign 1 92 305
new 0 92 305
assign 1 92 306
once 0 92 306
addValue 1 92 307
addValue 1 93 308
assign 1 99 317
new 0 99 317
assign 1 99 318
add 1 99 318
assign 1 99 319
new 0 99 319
assign 1 99 320
add 1 99 320
assign 1 99 321
add 1 99 321
return 1 99 322
assign 1 103 330
def 1 103 335
assign 1 103 336
isFinalGet 0 103 336
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 104 348
new 0 104 348
return 1 104 349
assign 1 106 351
new 0 106 351
return 1 106 352
assign 1 110 360
def 1 110 365
assign 1 110 366
isFinalGet 0 110 366
assign 1 0 368
assign 1 0 371
assign 1 0 375
assign 1 111 378
new 0 111 378
return 1 111 379
assign 1 113 381
new 0 113 381
return 1 113 382
assign 1 117 386
new 0 117 386
return 1 117 387
assign 1 121 409
new 0 121 409
assign 1 121 410
add 1 121 410
assign 1 121 411
new 0 121 411
assign 1 121 412
add 1 121 412
assign 1 121 413
add 1 121 413
assign 1 122 414
new 0 122 414
assign 1 122 415
addValue 1 122 415
assign 1 122 416
addValue 1 122 416
assign 1 122 417
new 0 122 417
assign 1 122 418
addValue 1 122 418
addValue 1 122 419
assign 1 123 420
new 0 123 420
assign 1 123 421
addValue 1 123 421
addValue 1 123 422
assign 1 124 423
new 0 124 423
assign 1 124 424
addValue 1 124 424
assign 1 124 425
outputPlatformGet 0 124 425
assign 1 124 426
nameGet 0 124 426
assign 1 124 427
addValue 1 124 427
assign 1 124 428
new 0 124 428
assign 1 124 429
addValue 1 124 429
addValue 1 124 430
return 1 125 431
assign 1 129 436
libNameGet 0 129 436
assign 1 129 437
beginNs 1 129 437
return 1 129 438
assign 1 133 447
new 0 133 447
assign 1 133 448
libNs 1 133 448
assign 1 133 449
add 1 133 449
assign 1 133 450
new 0 133 450
assign 1 133 451
add 1 133 451
assign 1 133 452
add 1 133 452
return 1 133 453
assign 1 137 457
getNameSpace 1 137 457
return 1 137 458
assign 1 141 462
new 0 141 462
return 1 141 463
assign 1 145 469
new 0 145 469
assign 1 145 470
once 0 145 470
assign 1 145 471
add 1 145 471
return 1 145 472
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 928457034: return bem_serializeContents_0();
case -125524636: return bem_trueValueGetDirect_0();
case 347302975: return bem_methodsGetDirect_0();
case 8896887: return bem_emitLib_0();
case -2124948120: return bem_idToNamePathGetDirect_0();
case -154534625: return bem_propertyDecsGet_0();
case -2092760709: return bem_once_0();
case -2019897330: return bem_maxDynArgsGetDirect_0();
case 328737182: return bem_ccMethodsGet_0();
case -1376265700: return bem_ccCacheGet_0();
case 594637567: return bem_nameToIdPathGetDirect_0();
case 105255020: return bem_endNs_0();
case -1303987182: return bem_methodBodyGet_0();
case 1632896250: return bem_libEmitNameGetDirect_0();
case -1237796461: return bem_floatNpGet_0();
case -842207018: return bem_iteratorGet_0();
case -612656985: return bem_ccMethodsGetDirect_0();
case 1904373316: return bem_propertyDecsGetDirect_0();
case -1257851297: return bem_classEmitsGetDirect_0();
case -792061706: return bem_callNamesGetDirect_0();
case -1127978038: return bem_baseMtdDecGet_0();
case 1372644764: return bem_hashGet_0();
case 108102557: return bem_buildGetDirect_0();
case 864393987: return bem_tagGet_0();
case -1406862989: return bem_objectNpGetDirect_0();
case -121392599: return bem_libEmitNameGet_0();
case 719416320: return bem_dynMethodsGetDirect_0();
case 1101301306: return bem_classCallsGetDirect_0();
case 542757790: return bem_boolTypeGet_0();
case -115989431: return bem_inClassGetDirect_0();
case 1959303394: return bem_mnodeGet_0();
case 1772750247: return bem_onceCountGetDirect_0();
case 720605991: return bem_instanceNotEqualGet_0();
case -1523845400: return bem_dynMethodsGet_0();
case -697367643: return bem_getLibOutput_0();
case -1852877275: return bem_new_0();
case -1587280835: return bem_boolCcGetDirect_0();
case -2146062281: return bem_inFilePathedGet_0();
case -358025207: return bem_loadIds_0();
case -236887613: return bem_classNameGet_0();
case -330630087: return bem_propDecGet_0();
case 1762117364: return bem_lastMethodBodyLinesGetDirect_0();
case 729042411: return bem_ccCacheGetDirect_0();
case -149693501: return bem_idToNamePathGet_0();
case 1083526105: return bem_falseValueGetDirect_0();
case 568312566: return bem_methodCallsGetDirect_0();
case 746102407: return bem_instOfGet_0();
case -935142269: return bem_inClassGet_0();
case -413504769: return bem_lastMethodsSizeGetDirect_0();
case 206517704: return bem_instanceNotEqualGetDirect_0();
case -1719324678: return bem_buildInitial_0();
case -1013325988: return bem_smnlecsGetDirect_0();
case -473973046: return bem_methodBodyGetDirect_0();
case -1318034253: return bem_returnTypeGet_0();
case -1360044135: return bem_writeBET_0();
case 237248432: return bem_onceDecsGet_0();
case -1503172150: return bem_classEmitsGet_0();
case 513195392: return bem_synEmitPathGet_0();
case 493050059: return bem_nameToIdGet_0();
case -459694510: return bem_maxSpillArgsLenGet_0();
case 251809488: return bem_nameToIdPathGet_0();
case 1241985807: return bem_lastMethodsLinesGet_0();
case 1217147975: return bem_nativeCSlotsGet_0();
case -194064343: return bem_mainEndGet_0();
case -23390772: return bem_floatNpGetDirect_0();
case -766421348: return bem_cnodeGet_0();
case -418366255: return bem_maxSpillArgsLenGetDirect_0();
case -1082955259: return bem_preClassOutput_0();
case -1153104759: return bem_methodCatchGetDirect_0();
case -2144558196: return bem_csynGet_0();
case 889222919: return bem_onceCountGet_0();
case 2003290617: return bem_runtimeInitGet_0();
case -309697524: return bem_libEmitPathGetDirect_0();
case 756781626: return bem_newDecGet_0();
case -464061736: return bem_ntypesGetDirect_0();
case 406173825: return bem_transGet_0();
case -323661464: return bem_serializeToString_0();
case -2131693464: return bem_belslitsGet_0();
case -958451534: return bem_nlGet_0();
case 1332706034: return bem_smnlecsGet_0();
case -1234395424: return bem_preClassGet_0();
case 19237238: return bem_fullLibEmitNameGetDirect_0();
case 197246584: return bem_idToNameGetDirect_0();
case 1587224391: return bem_transGetDirect_0();
case -242748600: return bem_doEmit_0();
case 1956892328: return bem_classesInDepthOrderGetDirect_0();
case 110735570: return bem_returnTypeGetDirect_0();
case -358783907: return bem_typeDecGet_0();
case -400027824: return bem_fileExtGetDirect_0();
case -718262525: return bem_stringNpGetDirect_0();
case -2141866060: return bem_gcMarksGetDirect_0();
case 1602807836: return bem_superCallsGetDirect_0();
case -2043449555: return bem_belslitsGetDirect_0();
case -615551128: return bem_methodsGet_0();
case -878568774: return bem_intNpGetDirect_0();
case -1642983427: return bem_falseValueGet_0();
case 866152174: return bem_stringNpGet_0();
case 1998217747: return bem_constGet_0();
case -1179760370: return bem_covariantReturnsGet_0();
case 1997175524: return bem_mainInClassGet_0();
case -483843588: return bem_gcMarksGet_0();
case 78334972: return bem_preClassGetDirect_0();
case -659151350: return bem_afterCast_0();
case -1369483363: return bem_fieldNamesGet_0();
case -1980635940: return bem_exceptDecGetDirect_0();
case -483998687: return bem_invpGetDirect_0();
case -1163840990: return bem_lastMethodBodySizeGet_0();
case -1654552861: return bem_msynGetDirect_0();
case 2048527497: return bem_buildClassInfo_0();
case -1324555499: return bem_classConfGet_0();
case -604212258: return bem_inFilePathedGetDirect_0();
case 1469097267: return bem_onceDecsGetDirect_0();
case -170941628: return bem_nativeCSlotsGetDirect_0();
case -112726755: return bem_callNamesGet_0();
case 447174096: return bem_saveSyns_0();
case -805378630: return bem_classEndGet_0();
case -457387997: return bem_lineCountGetDirect_0();
case -1495186160: return bem_maxDynArgsGet_0();
case 1390552893: return bem_invpGet_0();
case 747166857: return bem_fileExtGet_0();
case 438154477: return bem_lastMethodsLinesGetDirect_0();
case 274871933: return bem_objectNpGet_0();
case -1469438108: return bem_parentConfGet_0();
case -1166217280: return bem_getClassOutput_0();
case -1129392639: return bem_qGetDirect_0();
case -1556646105: return bem_objectCcGet_0();
case 1359360249: return bem_echo_0();
case -945243357: return bem_libEmitPathGet_0();
case -1430066973: return bem_print_0();
case -2093692014: return bem_nlGetDirect_0();
case 105074959: return bem_nullValueGetDirect_0();
case 849387251: return bem_toAny_0();
case 1211773133: return bem_spropDecGet_0();
case -11008638: return bem_buildGet_0();
case -1013237770: return bem_synEmitPathGetDirect_0();
case 1703080589: return bem_methodCallsGet_0();
case 1095008762: return bem_smnlcsGetDirect_0();
case 1523041979: return bem_lastMethodBodyLinesGet_0();
case 767554897: return bem_idToNameGet_0();
case -1321677625: return bem_instOfGetDirect_0();
case -1831288423: return bem_lastCallGet_0();
case -898522649: return bem_msynGet_0();
case 2070502838: return bem_copy_0();
case 1688433670: return bem_objectCcGetDirect_0();
case -355490341: return bem_csynGetDirect_0();
case -1733665536: return bem_nullValueGet_0();
case -1466971571: return bem_smnlcsGet_0();
case -599048812: return bem_emitLangGet_0();
case 1064677251: return bem_many_0();
case 1076647192: return bem_create_0();
case -1523626920: return bem_buildCreate_0();
case 2116313447: return bem_fullLibEmitNameGet_0();
case -477961898: return bem_superCallsGet_0();
case -197125980: return bem_intNpGet_0();
case -917153037: return bem_mnodeGetDirect_0();
case 528681379: return bem_initialDecGet_0();
case 1283855332: return bem_saveIds_0();
case 122012304: return bem_exceptDecGet_0();
case -625690319: return bem_boolNpGet_0();
case 1057952466: return bem_mainOutsideNsGet_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -751021546: return bem_emitLangGetDirect_0();
case -344994104: return bem_nameToIdGetDirect_0();
case 1230859494: return bem_baseSmtdDecGet_0();
case -1045979493: return bem_lastCallGetDirect_0();
case -440973066: return bem_classCallsGet_0();
case 1530844557: return bem_randGetDirect_0();
case -1137979748: return bem_boolCcGet_0();
case -2033658389: return bem_cnodeGetDirect_0();
case 1193129232: return bem_lastMethodsSizeGet_0();
case 1037110303: return bem_boolNpGetDirect_0();
case -761459611: return bem_methodCatchGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 624288951: return bem_beginNs_0();
case -1611952469: return bem_superNameGet_0();
case -105260941: return bem_scvpGetDirect_0();
case 1466941053: return bem_scvpGet_0();
case 1549038999: return bem_mainStartGet_0();
case -1012327793: return bem_instanceEqualGetDirect_0();
case 996718380: return bem_toString_0();
case -752215908: return bem_parentConfGetDirect_0();
case -918936873: return bem_useDynMethodsGet_0();
case -308422861: return bem_ntypesGet_0();
case -837718502: return bem_overrideMtdDecGet_0();
case -1482576615: return bem_lineCountGet_0();
case 874226959: return bem_constGetDirect_0();
case 404513897: return bem_lastMethodBodySizeGetDirect_0();
case 1423913538: return bem_randGet_0();
case 605836827: return bem_sourceFileNameGet_0();
case 1078156339: return bem_trueValueGet_0();
case 611032821: return bem_classConfGetDirect_0();
case -1096178781: return bem_classesInDepthOrderGet_0();
case -1367565265: return bem_instanceEqualGet_0();
case 1418382979: return bem_qGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -387595023: return bem_scvpSet_1(bevd_0);
case -1587075092: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -1084102046: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1462003221: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 860535262: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1500326399: return bem_gcMarksSet_1(bevd_0);
case 280482386: return bem_callNamesSet_1(bevd_0);
case -2007098411: return bem_lastCallSetDirect_1(bevd_0);
case -1291078940: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 202151827: return bem_instanceEqualSetDirect_1(bevd_0);
case -545965444: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1320996402: return bem_preClassSet_1(bevd_0);
case -2003929528: return bem_randSet_1(bevd_0);
case 177979611: return bem_msynSetDirect_1(bevd_0);
case 928136567: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1725777167: return bem_classEmitsSet_1(bevd_0);
case -1846267283: return bem_lastMethodsLinesSet_1(bevd_0);
case -474768129: return bem_lastMethodsSizeSet_1(bevd_0);
case 1223948856: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1928356294: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
case 485531858: return bem_ccCacheSet_1(bevd_0);
case -960159496: return bem_otherClass_1(bevd_0);
case 2055324647: return bem_callNamesSetDirect_1(bevd_0);
case 2003564846: return bem_idToNameSetDirect_1(bevd_0);
case 2005673292: return bem_invpSet_1(bevd_0);
case -144269694: return bem_nullValueSetDirect_1(bevd_0);
case 1950647904: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1989797599: return bem_methodCallsSet_1(bevd_0);
case -1587905121: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1858565734: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1426708999: return bem_belslitsSet_1(bevd_0);
case 1632478803: return bem_ccCacheSetDirect_1(bevd_0);
case -62966840: return bem_mnodeSet_1(bevd_0);
case -246579278: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 201238382: return bem_nlSetDirect_1(bevd_0);
case 1262206781: return bem_inClassSet_1(bevd_0);
case 1531473182: return bem_parentConfSetDirect_1(bevd_0);
case -1818686320: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 791078773: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1761009834: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case -1339916782: return bem_returnTypeSet_1(bevd_0);
case -107534388: return bem_nlSet_1(bevd_0);
case -442474446: return bem_maxDynArgsSet_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 1839140886: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1672483365: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -738801361: return bem_inFilePathedSetDirect_1(bevd_0);
case 1095034835: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1984324119: return bem_boolNpSetDirect_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 631941336: return bem_stringNpSetDirect_1(bevd_0);
case -608739103: return bem_trueValueSet_1(bevd_0);
case -292631601: return bem_emitLangSetDirect_1(bevd_0);
case 1293621630: return bem_methodBodySetDirect_1(bevd_0);
case -663200006: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1328551341: return bem_objectCcSet_1(bevd_0);
case -446663451: return bem_inFilePathedSet_1(bevd_0);
case 478028121: return bem_libEmitPathSet_1(bevd_0);
case 1151345369: return bem_cnodeSet_1(bevd_0);
case -625263640: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -2082083044: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -160208307: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1991744387: return bem_objectCcSetDirect_1(bevd_0);
case -1833873139: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -143970869: return bem_propertyDecsSet_1(bevd_0);
case -1943477938: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -964557971: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 778191497: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 1783950494: return bem_nullValueSet_1(bevd_0);
case 1851258596: return bem_idToNamePathSetDirect_1(bevd_0);
case -794825249: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 538412265: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -932463615: return bem_end_1(bevd_0);
case 1318149803: return bem_nameToIdSetDirect_1(bevd_0);
case 1961814740: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1715575939: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1234722829: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1283217046: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 790386981: return bem_ntypesSet_1(bevd_0);
case 1329852354: return bem_smnlecsSet_1(bevd_0);
case 1701400110: return bem_gcMarksSetDirect_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 704062473: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -486905268: return bem_mnodeSetDirect_1(bevd_0);
case -1434027048: return bem_falseValueSet_1(bevd_0);
case -518744023: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1798179660: return bem_cnodeSetDirect_1(bevd_0);
case -1759404254: return bem_classConfSet_1(bevd_0);
case -1715607270: return bem_idToNamePathSet_1(bevd_0);
case 1612967236: return bem_ccMethodsSet_1(bevd_0);
case -1789802068: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -2056825925: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -375669347: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1721262103: return bem_begin_1(bevd_0);
case 716282878: return bem_constSet_1(bevd_0);
case -372834197: return bem_libEmitNameSet_1(bevd_0);
case -1051715753: return bem_qSetDirect_1(bevd_0);
case 1511397097: return bem_boolCcSet_1(bevd_0);
case -893956741: return bem_boolNpSet_1(bevd_0);
case -1003514744: return bem_belslitsSetDirect_1(bevd_0);
case -882719021: return bem_qSet_1(bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 444493310: return bem_libEmitPathSetDirect_1(bevd_0);
case 932813340: return bem_falseValueSetDirect_1(bevd_0);
case 886262275: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -492578982: return bem_methodsSetDirect_1(bevd_0);
case 594217907: return bem_onceDecsSet_1(bevd_0);
case -1024256293: return bem_instOfSetDirect_1(bevd_0);
case 741715452: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -2105697821: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 1066958558: return bem_smnlcsSetDirect_1(bevd_0);
case -463588041: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -523725486: return bem_onceCountSetDirect_1(bevd_0);
case -745810773: return bem_methodBodySet_1(bevd_0);
case 163013157: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -2093159546: return bem_lineCountSetDirect_1(bevd_0);
case 467714536: return bem_boolCcSetDirect_1(bevd_0);
case 1289075138: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 2028646193: return bem_fileExtSet_1(bevd_0);
case 1251968409: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 397175289: return bem_classesInDepthOrderSet_1(bevd_0);
case -2027776037: return bem_classConfSetDirect_1(bevd_0);
case -1585582932: return bem_exceptDecSet_1(bevd_0);
case 442428894: return bem_buildSetDirect_1(bevd_0);
case 842175531: return bem_nativeCSlotsSet_1(bevd_0);
case 405281625: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -822921971: return bem_inClassSetDirect_1(bevd_0);
case -1903692910: return bem_nameToIdSet_1(bevd_0);
case -1855679040: return bem_superCallsSetDirect_1(bevd_0);
case -1983523746: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1102315799: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1365381661: return bem_emitLangSet_1(bevd_0);
case 1359973316: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -1204406980: return bem_propertyDecsSetDirect_1(bevd_0);
case -373605190: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 651411427: return bem_csynSetDirect_1(bevd_0);
case 1395501902: return bem_parentConfSet_1(bevd_0);
case -812242675: return bem_methodCallsSetDirect_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -363908270: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 129091253: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1572907584: return bem_intNpSetDirect_1(bevd_0);
case 919966779: return bem_nameToIdPathSet_1(bevd_0);
case -2099500845: return bem_methodCatchSetDirect_1(bevd_0);
case -244151254: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 454452952: return bem_superCallsSet_1(bevd_0);
case -883954848: return bem_libEmitNameSetDirect_1(bevd_0);
case -775666342: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 653158270: return bem_msynSet_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case -1396790309: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 116509435: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -861744627: return bem_classCallsSetDirect_1(bevd_0);
case -567479502: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case 709026002: return bem_randSetDirect_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case 661373943: return bem_fullLibEmitNameSet_1(bevd_0);
case 63555219: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 274995382: return bem_smnlcsSet_1(bevd_0);
case 2024249127: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1873289547: return bem_exceptDecSetDirect_1(bevd_0);
case -1981562519: return bem_trueValueSetDirect_1(bevd_0);
case -1436645165: return bem_instanceEqualSet_1(bevd_0);
case -2042978766: return bem_synEmitPathSetDirect_1(bevd_0);
case -716159304: return bem_intNpSet_1(bevd_0);
case -969568702: return bem_dynMethodsSet_1(bevd_0);
case -721327501: return bem_classEmitsSetDirect_1(bevd_0);
case 1462258451: return bem_methodsSet_1(bevd_0);
case 956456469: return bem_transSetDirect_1(bevd_0);
case 1051071357: return bem_nameToIdPathSetDirect_1(bevd_0);
case -1875763038: return bem_lineCountSet_1(bevd_0);
case 716468183: return bem_objectNpSetDirect_1(bevd_0);
case -541620175: return bem_instanceNotEqualSet_1(bevd_0);
case -673248215: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 327956204: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1318519422: return bem_returnTypeSetDirect_1(bevd_0);
case 1441539029: return bem_fileExtSetDirect_1(bevd_0);
case 1916949496: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1579648363: return bem_buildSet_1(bevd_0);
case -226099053: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 830966729: return bem_objectNpSet_1(bevd_0);
case 789811530: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1163807713: return bem_idToNameSet_1(bevd_0);
case 1451891079: return bem_maxDynArgsSetDirect_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case 1784248642: return bem_onceDecsSetDirect_1(bevd_0);
case -1061847705: return bem_scvpSetDirect_1(bevd_0);
case 81399418: return bem_classCallsSet_1(bevd_0);
case 513449544: return bem_dynMethodsSetDirect_1(bevd_0);
case 1955884120: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -237692528: return bem_invpSetDirect_1(bevd_0);
case -130988432: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -602178882: return bem_stringNpSet_1(bevd_0);
case -1433139758: return bem_constSetDirect_1(bevd_0);
case 850005288: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 168338507: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -644360289: return bem_ccMethodsSetDirect_1(bevd_0);
case 214898958: return bem_floatNpSetDirect_1(bevd_0);
case 1481902274: return bem_ntypesSetDirect_1(bevd_0);
case -272173180: return bem_synEmitPathSet_1(bevd_0);
case 1588026259: return bem_transSet_1(bevd_0);
case -165372393: return bem_methodCatchSet_1(bevd_0);
case 441506828: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 600603910: return bem_smnlecsSetDirect_1(bevd_0);
case 1200621550: return bem_onceCountSet_1(bevd_0);
case -1917317859: return bem_csynSet_1(bevd_0);
case 831416193: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1255375634: return bem_instOfSet_1(bevd_0);
case -1140106751: return bem_lastCallSet_1(bevd_0);
case 1522857961: return bem_floatNpSet_1(bevd_0);
case -261197521: return bem_preClassSetDirect_1(bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1795024150: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -298165990: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1806622672: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -856996376: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1650562428: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2038093316: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -835651430: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 165354965: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2010601293: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -747880859: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1466676333: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1944839781: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1947957571: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 471618185: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 815586935: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1137281105: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -808244447: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1792824748: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -61116913: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 656033829: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -736594313: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJVEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
}
