namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException : BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
static BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static new BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;

public static new BET_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -639622757: return bem_hashGet_0();
case -2015039528: return bem_iteratorGet_0();
case 2057902396: return bem_translatedGet_0();
case -1237127915: return bem_klassNameGet_0();
case -1428945834: return bem_methodNameGetDirect_0();
case 965815191: return bem_echo_0();
case -895761206: return bem_framesTextGetDirect_0();
case 714215467: return bem_fileNameGetDirect_0();
case 1470501423: return bem_descriptionGetDirect_0();
case -1794640101: return bem_fileNameGet_0();
case 105645045: return bem_many_0();
case 940651019: return bem_once_0();
case -296688753: return bem_print_0();
case 1378440385: return bem_translateEmittedException_0();
case -1578327045: return bem_serializeContents_0();
case 651444015: return bem_langGet_0();
case 123389654: return bem_lineNumberGet_0();
case 993863115: return bem_fieldIteratorGet_0();
case 617667581: return bem_toAny_0();
case 2020421059: return bem_descriptionGet_0();
case 1313176483: return bem_lineNumberGetDirect_0();
case -1137906174: return bem_vvGetDirect_0();
case 770044727: return bem_deserializeClassNameGet_0();
case 1995325233: return bem_framesTextGet_0();
case -1400364749: return bem_serializationIteratorGet_0();
case 861994087: return bem_translatedGetDirect_0();
case -1596775328: return bem_serializeToString_0();
case 1057761464: return bem_vvGet_0();
case 1552820506: return bem_classNameGet_0();
case 1167480829: return bem_copy_0();
case -479359240: return bem_tagGet_0();
case 1156458884: return bem_framesGet_0();
case 1470127612: return bem_sourceFileNameGet_0();
case 505798632: return bem_klassNameGetDirect_0();
case -1348961788: return bem_getFrameText_0();
case -850792326: return bem_emitLangGet_0();
case -1039531132: return bem_create_0();
case 2066844567: return bem_fieldNamesGet_0();
case 68270506: return bem_methodNameGet_0();
case -688862469: return bem_toString_0();
case 1028943969: return bem_emitLangGetDirect_0();
case -285828847: return bem_langGetDirect_0();
case -1515623024: return bem_framesGetDirect_0();
case 207157900: return bem_translateEmittedExceptionInner_0();
case -1453318633: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1300492421: return bem_otherType_1(bevd_0);
case -414279577: return bem_new_1(bevd_0);
case 189658019: return bem_defined_1(bevd_0);
case -1202688048: return bem_def_1(bevd_0);
case -240536886: return bem_klassNameSetDirect_1(bevd_0);
case -1617777472: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 323831111: return bem_undef_1(bevd_0);
case -1508033743: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -547021140: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1881353179: return bem_emitLangSet_1(bevd_0);
case 1364662750: return bem_framesTextSet_1(bevd_0);
case 509514338: return bem_langSetDirect_1(bevd_0);
case -1447883638: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1073960196: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1365097484: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1879722769: return bem_sameClass_1(bevd_0);
case 161412253: return bem_methodNameSetDirect_1(bevd_0);
case 1489408670: return bem_sameType_1(bevd_0);
case -1076480041: return bem_notEquals_1(bevd_0);
case -1197332143: return bem_otherClass_1(bevd_0);
case -752964673: return bem_lineNumberSetDirect_1(bevd_0);
case 1770927946: return bem_vvSetDirect_1(bevd_0);
case 1857294181: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1989767656: return bem_translatedSetDirect_1(bevd_0);
case -1893907459: return bem_framesSetDirect_1(bevd_0);
case -1596104350: return bem_descriptionSet_1(bevd_0);
case -1596168486: return bem_equals_1(bevd_0);
case 1472066990: return bem_vvSet_1(bevd_0);
case 205661105: return bem_klassNameSet_1(bevd_0);
case -598299187: return bem_translatedSet_1(bevd_0);
case -1403021879: return bem_langSet_1(bevd_0);
case 419445436: return bem_copyTo_1(bevd_0);
case -173869760: return bem_lineNumberSet_1(bevd_0);
case 416205256: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1245823048: return bem_framesSet_1(bevd_0);
case -248637267: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1416339029: return bem_sameObject_1(bevd_0);
case 829860442: return bem_descriptionSetDirect_1(bevd_0);
case -884635357: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 27599199: return bem_methodNameSet_1(bevd_0);
case 968909920: return bem_emitLangSetDirect_1(bevd_0);
case -1939242982: return bem_fileNameSetDirect_1(bevd_0);
case 1503413748: return bem_undefined_1(bevd_0);
case -15192570: return bem_fileNameSet_1(bevd_0);
case -1215621885: return bem_framesTextSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 787023569: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1285045766: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -624371870: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 282981748: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1323585037: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2145191247: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -437555976: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1081137885: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_20_XmlTagIteratorException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;
}
}
}
