namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_3_2_4_17_IOFileDirectoryIterator : BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }
static BEC_3_2_4_17_IOFileDirectoryIterator() { }

   
    public IEnumerator<string> bevi_dir;
    
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static new BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static new BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 551 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 552 */
 else  /* Line: 554 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 555 */
if (bevp_closed.bevi_bool) /* Line: 558 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 560 */
if (bevp_opened.bevi_bool) /* Line: 562 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 563 */

      bevi_dir = Directory.EnumerateFileSystemEntries(bevl_path.bems_toCsString(), "*", SearchOption.TopDirectoryOnly).GetEnumerator();
      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 584 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 587 */
 else  /* Line: 588 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 591 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 596 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 596 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 597 */ {
bem_open_0();
} /* Line: 597 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 602 */ {
return null;
} /* Line: 602 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 603 */ {
bem_open_0();
} /* Line: 603 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 613 */ {
return this;
} /* Line: 613 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 614 */ {
return this;
} /* Line: 614 */
if (bevp_current == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 615 */ {
return this;
} /* Line: 615 */

      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 633 */
 else  /* Line: 634 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 637 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() {

      bevi_dir.Dispose();
      bevi_dir = null;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() {
return bevp_dir;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGetDirect_0() {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() {
return bevp_opened;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGetDirect_0() {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() {
return bevp_closed;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGetDirect_0() {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGetDirect_0() {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {534, 535, 536, 542, 543, 551, 551, 552, 552, 555, 555, 555, 560, 560, 560, 563, 563, 563, 584, 584, 586, 587, 590, 591, 596, 596, 597, 597, 597, 598, 598, 602, 603, 603, 603, 604, 605, 606, 613, 614, 614, 614, 615, 615, 615, 631, 631, 632, 633, 635, 636, 637, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {32, 33, 34, 38, 39, 54, 59, 60, 61, 64, 65, 66, 69, 70, 71, 74, 75, 76, 83, 88, 89, 90, 93, 94, 103, 104, 106, 111, 112, 114, 119, 125, 127, 132, 133, 135, 136, 137, 145, 147, 152, 153, 155, 160, 161, 167, 172, 173, 174, 177, 178, 179, 190, 193, 196, 200, 204, 207, 210, 214, 218, 221, 224, 228, 232, 235, 238, 242};
/* BEGIN LINEINFO 
assign 1 534 32
new 0 534 32
assign 1 535 33
new 0 535 33
assign 1 536 34
new 0 542 38
assign 1 543 39
assign 1 551 54
def 1 551 59
assign 1 552 60
pathGet 0 552 60
assign 1 552 61
toString 0 552 61
assign 1 555 64
new 0 555 64
assign 1 555 65
new 1 555 65
throw 1 555 66
assign 1 560 69
new 0 560 69
assign 1 560 70
new 1 560 70
throw 1 560 71
assign 1 563 74
new 0 563 74
assign 1 563 75
new 1 563 75
throw 1 563 76
assign 1 584 83
def 1 584 88
assign 1 586 89
new 0 586 89
assign 1 587 90
apNew 1 587 90
assign 1 590 93
new 0 590 93
assign 1 591 94
new 0 591 94
assign 1 596 103
new 0 596 103
return 1 596 104
assign 1 597 106
not 0 597 111
open 0 597 112
assign 1 598 114
def 1 598 119
return 1 598 119
return 1 602 125
assign 1 603 127
not 0 603 132
open 0 603 133
assign 1 604 135
advance 0 605 136
return 1 606 137
return 1 613 145
assign 1 614 147
not 0 614 152
return 1 614 153
assign 1 615 155
undef 1 615 160
return 1 615 161
assign 1 631 167
def 1 631 172
assign 1 632 173
new 0 632 173
assign 1 633 174
apNew 1 633 174
assign 1 635 177
new 0 635 177
assign 1 636 178
new 0 636 178
assign 1 637 179
return 1 0 190
return 1 0 193
assign 1 0 196
assign 1 0 200
return 1 0 204
return 1 0 207
assign 1 0 210
assign 1 0 214
return 1 0 218
return 1 0 221
assign 1 0 224
assign 1 0 228
return 1 0 232
return 1 0 235
assign 1 0 238
assign 1 0 242
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -963755335: return bem_fieldIteratorGet_0();
case -1004079418: return bem_once_0();
case -1108167878: return bem_serializeToString_0();
case 1453058067: return bem_closedGetDirect_0();
case 1603326601: return bem_many_0();
case -690607454: return bem_currentGetDirect_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -469171007: return bem_serializeContents_0();
case -545958368: return bem_toAny_0();
case -1862809801: return bem_open_0();
case -799512235: return bem_openedGetDirect_0();
case -632169362: return bem_print_0();
case 622925673: return bem_hasNextGet_0();
case -2048609488: return bem_tagGet_0();
case 572658803: return bem_dirGet_0();
case -212376625: return bem_iteratorGet_0();
case 1692346103: return bem_currentGet_0();
case 1909096874: return bem_create_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case -1053282251: return bem_dirGetDirect_0();
case 1419414154: return bem_new_0();
case -1273964881: return bem_openedGet_0();
case -1809371867: return bem_nextGet_0();
case 2077040828: return bem_copy_0();
case 429419643: return bem_echo_0();
case 1730620110: return bem_serializationIteratorGet_0();
case 1741010261: return bem_classNameGet_0();
case -1918539521: return bem_toString_0();
case -811598956: return bem_fieldNamesGet_0();
case -1259828052: return bem_advance_0();
case 287394467: return bem_close_0();
case -1564704332: return bem_closedGet_0();
case 1687921048: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1983360411: return bem_dirSetDirect_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -363168387: return bem_sameType_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2095525409: return bem_currentSetDirect_1(bevd_0);
case 1359762856: return bem_dirSet_1(bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case -935383523: return bem_closedSet_1(bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case -1205772150: return bem_currentSet_1(bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case -536126381: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -16867500: return bem_closedSetDirect_1(bevd_0);
case 1477988688: return bem_openedSetDirect_1(bevd_0);
case -1434304379: return bem_otherType_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 683051610: return bem_openedSet_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
}
