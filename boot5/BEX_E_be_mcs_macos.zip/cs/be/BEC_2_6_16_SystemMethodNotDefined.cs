namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemMethodNotDefined : BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
static BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;

public static new BET_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1848718184: return bem_hashGet_0();
case 193255442: return bem_translateEmittedException_0();
case -1177413693: return bem_langGetDirect_0();
case -31114048: return bem_iteratorGet_0();
case -1615143867: return bem_klassNameGet_0();
case -611716188: return bem_translatedGet_0();
case 1920982992: return bem_translateEmittedExceptionInner_0();
case -781363880: return bem_methodNameGetDirect_0();
case -1779062531: return bem_serializationIteratorGet_0();
case 742243485: return bem_emitLangGetDirect_0();
case -479166709: return bem_tagGet_0();
case 185174991: return bem_copy_0();
case 1314058192: return bem_lineNumberGet_0();
case 715716842: return bem_framesGet_0();
case -1902089216: return bem_toString_0();
case -785258946: return bem_create_0();
case 2038193605: return bem_fieldNamesGet_0();
case -1743854913: return bem_getFrameText_0();
case 217968364: return bem_classNameGet_0();
case 1289872604: return bem_fileNameGetDirect_0();
case 1029695809: return bem_echo_0();
case 1137009070: return bem_once_0();
case 428889720: return bem_langGet_0();
case 1562608535: return bem_print_0();
case 1926865324: return bem_framesTextGetDirect_0();
case 1735327099: return bem_framesGetDirect_0();
case -1844917728: return bem_many_0();
case 1338346341: return bem_descriptionGet_0();
case 1753049059: return bem_translatedGetDirect_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -8643043: return bem_serializeContents_0();
case 735324992: return bem_vvGet_0();
case -1695057809: return bem_descriptionGetDirect_0();
case -2073663012: return bem_framesTextGet_0();
case -635864198: return bem_fileNameGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 1688687204: return bem_serializeToString_0();
case 1361837695: return bem_klassNameGetDirect_0();
case -2036231207: return bem_lineNumberGetDirect_0();
case 126670515: return bem_toAny_0();
case 1886322063: return bem_emitLangGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 766575698: return bem_vvGetDirect_0();
case 2084683937: return bem_methodNameGet_0();
case -1026733174: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -515081282: return bem_lineNumberSet_1(bevd_0);
case -792995907: return bem_klassNameSetDirect_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case -37155279: return bem_descriptionSet_1(bevd_0);
case -1125272274: return bem_framesTextSetDirect_1(bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -783336794: return bem_vvSetDirect_1(bevd_0);
case -1474258014: return bem_framesSet_1(bevd_0);
case -1082500833: return bem_translatedSetDirect_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -2076948529: return bem_fileNameSet_1(bevd_0);
case 2036667124: return bem_langSet_1(bevd_0);
case 263519481: return bem_framesSetDirect_1(bevd_0);
case -995591099: return bem_langSetDirect_1(bevd_0);
case 389177729: return bem_new_1(bevd_0);
case -1942322755: return bem_methodNameSetDirect_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 1879758028: return bem_vvSet_1(bevd_0);
case -1741459094: return bem_methodNameSet_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1224986976: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case -390307314: return bem_klassNameSet_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 832592569: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1623635837: return bem_fileNameSetDirect_1(bevd_0);
case -1888580484: return bem_emitLangSet_1(bevd_0);
case -519826501: return bem_framesTextSet_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -263930441: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -754285981: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -742531171: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case -455557418: return bem_descriptionSetDirect_1(bevd_0);
case -1563244779: return bem_emitLangSetDirect_1(bevd_0);
case 636999341: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 2060573744: return bem_lineNumberSetDirect_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case 1707557374: return bem_translatedSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1595316313: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;
}
}
}
