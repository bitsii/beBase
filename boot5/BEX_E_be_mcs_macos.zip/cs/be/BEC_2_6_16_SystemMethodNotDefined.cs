namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemMethodNotDefined : BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
static BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;

public static new BET_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1359433464: return bem_framesTextGetDirect_0();
case 1074643112: return bem_vvGetDirect_0();
case 1460710096: return bem_tagGet_0();
case 1862523130: return bem_framesTextGet_0();
case -1862215610: return bem_methodNameGet_0();
case 1562650783: return bem_fieldIteratorGet_0();
case -551145353: return bem_emitLangGetDirect_0();
case -1036391864: return bem_copy_0();
case -638006285: return bem_framesGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case -1642247669: return bem_langGetDirect_0();
case 1056660728: return bem_framesGetDirect_0();
case 1640157629: return bem_toString_0();
case 1018247965: return bem_klassNameGetDirect_0();
case -1038362857: return bem_translatedGet_0();
case 896695333: return bem_fileNameGet_0();
case -1906768398: return bem_classNameGet_0();
case -690910534: return bem_langGet_0();
case -1998940253: return bem_lineNumberGet_0();
case 350327807: return bem_lineNumberGetDirect_0();
case 939713627: return bem_print_0();
case -2074020116: return bem_emitLangGet_0();
case -178385347: return bem_iteratorGet_0();
case -2070846101: return bem_hashGet_0();
case 307193318: return bem_serializeContents_0();
case -257258104: return bem_descriptionGet_0();
case -348034134: return bem_klassNameGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case 413415824: return bem_methodNameGetDirect_0();
case -1253293660: return bem_serializeToString_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 328978343: return bem_translatedGetDirect_0();
case -1724932192: return bem_descriptionGetDirect_0();
case -910391963: return bem_fileNameGetDirect_0();
case 1258729534: return bem_echo_0();
case -870817408: return bem_vvGet_0();
case -1221104789: return bem_sourceFileNameGet_0();
case 873076018: return bem_new_0();
case 2037996040: return bem_create_0();
case 431270363: return bem_getFrameText_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1528782257: return bem_copyTo_1(bevd_0);
case -1599978521: return bem_langSetDirect_1(bevd_0);
case -563560742: return bem_methodNameSet_1(bevd_0);
case 335347569: return bem_vvSet_1(bevd_0);
case -493310448: return bem_new_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -808021347: return bem_klassNameSet_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case 1121462018: return bem_klassNameSetDirect_1(bevd_0);
case -685270224: return bem_translatedSet_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -1808728434: return bem_vvSetDirect_1(bevd_0);
case -82783240: return bem_emitLangSet_1(bevd_0);
case 512121376: return bem_emitLangSetDirect_1(bevd_0);
case 132846182: return bem_langSet_1(bevd_0);
case 276048138: return bem_descriptionSet_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1653007690: return bem_framesSet_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case 513231751: return bem_framesTextSetDirect_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1620616295: return bem_fileNameSetDirect_1(bevd_0);
case -2133043342: return bem_lineNumberSetDirect_1(bevd_0);
case -1251363713: return bem_descriptionSetDirect_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case 1504602421: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1875460442: return bem_translatedSetDirect_1(bevd_0);
case -1525857813: return bem_methodNameSetDirect_1(bevd_0);
case -1869056258: return bem_lineNumberSet_1(bevd_0);
case -937112844: return bem_fileNameSet_1(bevd_0);
case -596223987: return bem_framesTextSet_1(bevd_0);
case -1304581965: return bem_framesSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1615196666: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;
}
}
}
