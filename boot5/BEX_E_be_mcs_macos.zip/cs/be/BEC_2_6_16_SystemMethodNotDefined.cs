namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemMethodNotDefined : BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
static BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 509465600: return bem_iteratorGet_0();
case 744196600: return bem_vvGet_0();
case 1790287709: return bem_lineNumberGet_0();
case 913636711: return bem_toAny_0();
case 876844323: return bem_serializationIteratorGet_0();
case 1445821224: return bem_fileNameGet_0();
case -85596330: return bem_tagGet_0();
case 1796230342: return bem_toString_0();
case -417792642: return bem_methodNameGet_0();
case -690544544: return bem_translateEmittedException_0();
case -1427622449: return bem_create_0();
case -1829691749: return bem_descriptionGet_0();
case -487082551: return bem_translatedGet_0();
case -853067962: return bem_serializeContents_0();
case -904557663: return bem_print_0();
case -945812364: return bem_once_0();
case 1398390067: return bem_classNameGet_0();
case -2066691170: return bem_hashGet_0();
case -1059501870: return bem_fieldIteratorGet_0();
case -1785061873: return bem_translateEmittedExceptionInner_0();
case 449331673: return bem_framesTextGet_0();
case -1254976075: return bem_deserializeClassNameGet_0();
case 872852978: return bem_langGet_0();
case -1832843281: return bem_klassNameGet_0();
case -986479382: return bem_getFrameText_0();
case -551829583: return bem_echo_0();
case -1414488789: return bem_copy_0();
case 1965225689: return bem_sourceFileNameGet_0();
case -973189991: return bem_emitLangGet_0();
case 1395453592: return bem_serializeToString_0();
case 332749494: return bem_many_0();
case -1681566097: return bem_framesGet_0();
case 627584199: return bem_new_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 1438783901: return bem_translatedSet_1(bevd_0);
case -1410322621: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 662157095: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1825570190: return bem_sameObject_1(bevd_0);
case 2142029115: return bem_undef_1(bevd_0);
case -1860692421: return bem_klassNameSet_1(bevd_0);
case 786638494: return bem_emitLangSet_1(bevd_0);
case -998216454: return bem_langSet_1(bevd_0);
case -2038649804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 251217946: return bem_defined_1(bevd_0);
case 206265527: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -850356110: return bem_framesSet_1(bevd_0);
case 414867900: return bem_otherClass_1(bevd_0);
case 2041335091: return bem_fileNameSet_1(bevd_0);
case 1320933327: return bem_new_1(bevd_0);
case -375396806: return bem_sameType_1(bevd_0);
case 2071830925: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1213922529: return bem_notEquals_1(bevd_0);
case -766466078: return bem_vvSet_1(bevd_0);
case 1650785007: return bem_undefined_1(bevd_0);
case -2064416533: return bem_copyTo_1(bevd_0);
case 1871036873: return bem_lineNumberSet_1(bevd_0);
case 632969730: return bem_otherType_1(bevd_0);
case 1388645762: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1207972179: return bem_descriptionSet_1(bevd_0);
case -282488764: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1628483910: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2063629471: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1398432640: return bem_sameClass_1(bevd_0);
case -794604670: return bem_methodNameSet_1(bevd_0);
case -822013560: return bem_framesTextSet_1(bevd_0);
case -1121775076: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1789153529: return bem_equals_1(bevd_0);
case 1081898105: return bem_def_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1716376212: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -113794903: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1467397408: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1606481035: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 75445916: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1518297580: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1418573133: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callCase) {
case -1277546464: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callCase, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
}
}
