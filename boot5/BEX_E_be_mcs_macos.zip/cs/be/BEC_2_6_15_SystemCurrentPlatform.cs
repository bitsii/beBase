namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 551 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 552 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 575 */
} /* Line: 552 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(1537298163, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {552, 552, 575, 581, 582, 586, 587, 588};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 32, 38, 39, 44, 45, 46};
/* BEGIN LINEINFO 
assign 1 552 24
undef 1 552 29
setName 1 575 32
assign 1 581 38
buildProfile 0 582 39
buildProfile 0 586 44
assign 1 587 45
new 0 587 45
newlineSet 1 588 46
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 337782000: return bem_isNixGetDirect_0();
case -457703447: return bem_deserializeClassNameGet_0();
case 705946713: return bem_serializationIteratorGet_0();
case 1987220453: return bem_newlineGet_0();
case 1878894995: return bem_classNameGet_0();
case -1146188970: return bem_nullFileGetDirect_0();
case 2087771877: return bem_echo_0();
case -1922780248: return bem_iteratorGet_0();
case -378647588: return bem_isWinGet_0();
case -461692125: return bem_buildProfile_0();
case -151111191: return bem_separatorGetDirect_0();
case 1405428024: return bem_nullFileGet_0();
case 1855506680: return bem_toString_0();
case -1280718876: return bem_nameGet_0();
case 1835544527: return bem_print_0();
case -1927182002: return bem_otherSeparatorGetDirect_0();
case 945522219: return bem_hashGet_0();
case 615981380: return bem_fieldNamesGet_0();
case -798507920: return bem_default_0();
case -711514807: return bem_sourceFileNameGet_0();
case 1284640786: return bem_copy_0();
case 1323199388: return bem_isNixGet_0();
case -84103940: return bem_many_0();
case -1354126741: return bem_tagGet_0();
case -292945961: return bem_create_0();
case 87072509: return bem_toAny_0();
case -1446404808: return bem_otherSeparatorGet_0();
case 624386533: return bem_serializeToString_0();
case 457529483: return bem_serializeContents_0();
case -69826886: return bem_isWinGetDirect_0();
case 1769236573: return bem_separatorGet_0();
case 1095611429: return bem_once_0();
case 55842129: return bem_nameGetDirect_0();
case -1725699695: return bem_fieldIteratorGet_0();
case 1219704997: return bem_newlineGetDirect_0();
case 658678414: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2109400999: return bem_copyTo_1(bevd_0);
case 1421617056: return bem_isNixSet_1(bevd_0);
case -1516598724: return bem_newlineSetDirect_1(bevd_0);
case 1861221770: return bem_isNixSetDirect_1(bevd_0);
case -1971460437: return bem_otherClass_1(bevd_0);
case 126395237: return bem_sameObject_1(bevd_0);
case -1551748546: return bem_undefined_1(bevd_0);
case -1368724020: return bem_sameType_1(bevd_0);
case 58606191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1831091397: return bem_nameSetDirect_1(bevd_0);
case -1436462159: return bem_otherSeparatorSetDirect_1(bevd_0);
case -597509561: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1496200726: return bem_nullFileSet_1(bevd_0);
case 66141979: return bem_isWinSetDirect_1(bevd_0);
case 698138409: return bem_separatorSet_1(bevd_0);
case 483285466: return bem_isWinSet_1(bevd_0);
case -1897607279: return bem_equals_1(bevd_0);
case 1154788222: return bem_nullFileSetDirect_1(bevd_0);
case -1383533410: return bem_undef_1(bevd_0);
case -701846850: return bem_otherType_1(bevd_0);
case -2105151702: return bem_otherSeparatorSet_1(bevd_0);
case -656840793: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -341234740: return bem_notEquals_1(bevd_0);
case 918510986: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -586455400: return bem_defined_1(bevd_0);
case 1114642203: return bem_separatorSetDirect_1(bevd_0);
case 1894284601: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1537298163: return bem_newlineSet_1(bevd_0);
case -195954973: return bem_nameSet_1(bevd_0);
case 465199415: return bem_sameClass_1(bevd_0);
case -1609990267: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -754260669: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1810583739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -687329733: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 703022748: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -871246707: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1013064550: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1390383369: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1845172722: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
