namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
/* Line: 267*/ {
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 268*/ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                /* Line: 283*/ {
} /* Line: 284*/
/* Line: 291*/ {
} /* Line: 292*/
bem_setName_1(bevl_platformName);
} /* Line: 298*/
} /* Line: 268*/
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-1997671617, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {268, 268, 298, 304, 305, 309, 310, 311};
public static new int[] bevs_smnlec
 = new int[] {23, 28, 35, 41, 42, 47, 48, 49};
/* BEGIN LINEINFO 
assign 1 268 23
undef 1 268 28
setName 1 298 35
assign 1 304 41
buildProfile 0 305 42
buildProfile 0 309 47
assign 1 310 48
new 0 310 48
newlineSet 1 311 49
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1906768398: return bem_classNameGet_0();
case -1036391864: return bem_copy_0();
case 1406422080: return bem_properNameGetDirect_0();
case 1308996841: return bem_separatorGet_0();
case 1640157629: return bem_toString_0();
case 1460710096: return bem_tagGet_0();
case 1562650783: return bem_fieldIteratorGet_0();
case -1401273642: return bem_separatorGetDirect_0();
case 307193318: return bem_serializeContents_0();
case -1432171810: return bem_nameGet_0();
case -1754003758: return bem_scriptExtGet_0();
case -178385347: return bem_iteratorGet_0();
case 1317841721: return bem_isWinGet_0();
case 1469217030: return bem_properNameGet_0();
case 1495522549: return bem_nullFileGet_0();
case 939713627: return bem_print_0();
case -1253293660: return bem_serializeToString_0();
case -2070846101: return bem_hashGet_0();
case -168213116: return bem_isNixGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case -2128098029: return bem_buildProfile_0();
case -1289168525: return bem_newlineGet_0();
case 1258729534: return bem_echo_0();
case 1539294608: return bem_scriptExtGetDirect_0();
case -1377752262: return bem_default_0();
case -1798510599: return bem_otherSeparatorGet_0();
case -1976964005: return bem_otherSeparatorGetDirect_0();
case -1221104789: return bem_sourceFileNameGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 2050745612: return bem_isNixGetDirect_0();
case 873076018: return bem_new_0();
case -652325711: return bem_newlineGetDirect_0();
case 2037996040: return bem_create_0();
case -977620651: return bem_isWinGetDirect_0();
case 1499064773: return bem_nullFileGetDirect_0();
case -527531531: return bem_nameGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1528782257: return bem_copyTo_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case -1157782046: return bem_newlineSetDirect_1(bevd_0);
case 29741396: return bem_separatorSetDirect_1(bevd_0);
case -1426063336: return bem_nullFileSet_1(bevd_0);
case -1977322563: return bem_properNameSet_1(bevd_0);
case -1997671617: return bem_newlineSet_1(bevd_0);
case -1257917085: return bem_isWinSetDirect_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -1232791091: return bem_nameSet_1(bevd_0);
case 1493675498: return bem_isNixSetDirect_1(bevd_0);
case -1236395496: return bem_separatorSet_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1361820281: return bem_isWinSet_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -406747297: return bem_properNameSetDirect_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1346995845: return bem_scriptExtSetDirect_1(bevd_0);
case 67465497: return bem_nameSetDirect_1(bevd_0);
case 709839478: return bem_scriptExtSet_1(bevd_0);
case -737480477: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -493310448: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case -1814539600: return bem_otherSeparatorSetDirect_1(bevd_0);
case -1568949909: return bem_otherSeparatorSet_1(bevd_0);
case -1326269825: return bem_isNixSet_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -1847982113: return bem_nullFileSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
