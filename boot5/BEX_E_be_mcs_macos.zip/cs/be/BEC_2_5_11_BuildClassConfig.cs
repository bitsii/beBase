namespace be {
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
static BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_2 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_11_BuildClassConfig_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_11_BuildClassConfig_bels_2, 4));
public static new BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static new BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public virtual BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_3_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_1_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_2_tmpany_phold.bem_addStep_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_1_tmpany_phold.bem_addStep_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_5_tmpany_phold = bevp_emitName.bem_add_1(bevt_6_tmpany_phold);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bem_addStep_1(bevt_5_tmpany_phold);
bevt_9_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_10_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_9_tmpany_phold.bem_addStep_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_12_tmpany_phold = bevp_typeEmitName.bem_add_1(bevt_13_tmpany_phold);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_addStep_1(bevt_12_tmpany_phold);
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevp_classPath.bem_parentGet_0();
bevt_14_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_classDir.bem_copy_0();
bevt_16_tmpany_phold = bece_BEC_2_5_11_BuildClassConfig_bevo_0;
bevt_15_tmpany_phold = bevp_emitName.bem_add_1(bevt_16_tmpany_phold);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_tmpany_phold.bem_addStep_1(bevt_15_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGetDirect_0() {
return bevp_np;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameSpaceGet_0() {
return bevp_nameSpace;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() {
return bevp_nameSpace;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameGet_0() {
return bevp_emitName;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGetDirect_0() {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_typeEmitNameGet_0() {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() {
return bevp_typeEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fullEmitNameGet_0() {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() {
return bevp_fullEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classPathGet_0() {
return bevp_classPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() {
return bevp_classPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_typePathGet_0() {
return bevp_typePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() {
return bevp_typePath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classDirGet_0() {
return bevp_classDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() {
return bevp_classDir;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_synPathGet_0() {
return bevp_synPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() {
return bevp_synPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {2356, 2357, 2358, 2359, 2361, 2362, 2363, 2364, 2365, 2365, 2365, 2365, 2365, 2365, 2365, 2365, 2366, 2366, 2366, 2366, 2366, 2366, 2366, 2366, 2367, 2368, 2368, 2368, 2368, 2375, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 78, 81, 84, 87, 91, 95, 98, 101, 105, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217, 221, 224, 227, 231, 235, 238, 241, 245};
/* BEGIN LINEINFO 
assign 1 2356 46
assign 1 2357 47
assign 1 2358 48
assign 1 2359 49
assign 1 2361 50
getNameSpace 1 2361 50
assign 1 2362 51
getEmitName 1 2362 51
assign 1 2363 52
getTypeEmitName 1 2363 52
assign 1 2364 53
getFullEmitName 2 2364 53
assign 1 2365 54
copy 0 2365 54
assign 1 2365 55
emitLangGet 0 2365 55
assign 1 2365 56
addStep 1 2365 56
assign 1 2365 57
new 0 2365 57
assign 1 2365 58
addStep 1 2365 58
assign 1 2365 59
fileExtGet 0 2365 59
assign 1 2365 60
add 1 2365 60
assign 1 2365 61
addStep 1 2365 61
assign 1 2366 62
copy 0 2366 62
assign 1 2366 63
emitLangGet 0 2366 63
assign 1 2366 64
addStep 1 2366 64
assign 1 2366 65
new 0 2366 65
assign 1 2366 66
addStep 1 2366 66
assign 1 2366 67
fileExtGet 0 2366 67
assign 1 2366 68
add 1 2366 68
assign 1 2366 69
addStep 1 2366 69
assign 1 2367 70
parentGet 0 2367 70
assign 1 2368 71
copy 0 2368 71
assign 1 2368 72
new 0 2368 72
assign 1 2368 73
add 1 2368 73
assign 1 2368 74
addStep 1 2368 74
return 1 2375 78
return 1 0 81
return 1 0 84
assign 1 0 87
assign 1 0 91
return 1 0 95
return 1 0 98
assign 1 0 101
assign 1 0 105
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 244909240: return bem_emitNameGet_0();
case 407263222: return bem_typePathGetDirect_0();
case -458782277: return bem_synPathGetDirect_0();
case 1655787948: return bem_npGet_0();
case -865211167: return bem_many_0();
case 734060929: return bem_serializationIteratorGet_0();
case -414543406: return bem_classPathGetDirect_0();
case 1147856721: return bem_fieldIteratorGet_0();
case 2121617532: return bem_hashGet_0();
case 148319359: return bem_new_0();
case 586906526: return bem_typePathGet_0();
case 332613786: return bem_serializeContents_0();
case -320545548: return bem_sourceFileNameGet_0();
case -360670150: return bem_typeEmitNameGet_0();
case 117035787: return bem_emitPathGetDirect_0();
case -1386875085: return bem_libNameGetDirect_0();
case 1521417260: return bem_classPathGet_0();
case -1488294599: return bem_classDirGet_0();
case -1626968232: return bem_emitNameGetDirect_0();
case -206408982: return bem_emitterGetDirect_0();
case -1797964019: return bem_classNameGet_0();
case 1854607749: return bem_classDirGetDirect_0();
case -256176855: return bem_iteratorGet_0();
case 1990625095: return bem_tagGet_0();
case -871082397: return bem_typeEmitNameGetDirect_0();
case -810722765: return bem_fullEmitNameGet_0();
case 1434381851: return bem_libNameGet_0();
case -1214799986: return bem_emitterGet_0();
case 1310168666: return bem_copy_0();
case -1943120126: return bem_serializeToString_0();
case -2027679173: return bem_deserializeClassNameGet_0();
case 1596530776: return bem_npGetDirect_0();
case 341148236: return bem_once_0();
case 1234728219: return bem_fullEmitNameGetDirect_0();
case -740937572: return bem_print_0();
case -2058654018: return bem_toString_0();
case -41276197: return bem_create_0();
case -1456235115: return bem_echo_0();
case -1292778564: return bem_nameSpaceGetDirect_0();
case -544386795: return bem_synPathGet_0();
case 1567084794: return bem_nameSpaceGet_0();
case 903178719: return bem_fieldNamesGet_0();
case -1566162334: return bem_emitPathGet_0();
case -139353918: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1985783592: return bem_otherType_1(bevd_0);
case -852598589: return bem_emitterSetDirect_1(bevd_0);
case -595737351: return bem_typeEmitNameSet_1(bevd_0);
case 55946271: return bem_notEquals_1(bevd_0);
case -280854092: return bem_libNameSet_1(bevd_0);
case -1721937470: return bem_npSetDirect_1(bevd_0);
case -357813968: return bem_emitterSet_1(bevd_0);
case 520993970: return bem_typeEmitNameSetDirect_1(bevd_0);
case 906711890: return bem_sameObject_1(bevd_0);
case 1306222906: return bem_typePathSetDirect_1(bevd_0);
case -1010781743: return bem_synPathSetDirect_1(bevd_0);
case 353971716: return bem_emitNameSet_1(bevd_0);
case 2142128210: return bem_emitPathSet_1(bevd_0);
case -804903337: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -940814966: return bem_fullEmitNameSet_1(bevd_0);
case -1375609275: return bem_classDirSet_1(bevd_0);
case 2070971991: return bem_def_1(bevd_0);
case -924062367: return bem_nameSpaceSet_1(bevd_0);
case 649776492: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2023862139: return bem_equals_1(bevd_0);
case 1199011336: return bem_npSet_1(bevd_0);
case -116587458: return bem_sameType_1(bevd_0);
case -431213424: return bem_fullEmitNameSetDirect_1(bevd_0);
case -264091635: return bem_copyTo_1(bevd_0);
case 635105057: return bem_defined_1(bevd_0);
case 1865504944: return bem_sameClass_1(bevd_0);
case 188764781: return bem_classDirSetDirect_1(bevd_0);
case 1350346500: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -296790153: return bem_nameSpaceSetDirect_1(bevd_0);
case -70758992: return bem_emitNameSetDirect_1(bevd_0);
case -154281286: return bem_synPathSet_1(bevd_0);
case -1829045189: return bem_otherClass_1(bevd_0);
case 825055568: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -245605778: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1286485230: return bem_typePathSet_1(bevd_0);
case 306277101: return bem_undefined_1(bevd_0);
case -1679251333: return bem_undef_1(bevd_0);
case 1343418547: return bem_libNameSetDirect_1(bevd_0);
case 437751041: return bem_classPathSetDirect_1(bevd_0);
case -662688306: return bem_emitPathSetDirect_1(bevd_0);
case -1020201160: return bem_classPathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 710095661: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1286703705: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 704289821: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1372536257: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1105189015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1798728092: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -275173380: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1997458005: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildClassConfig();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
}
