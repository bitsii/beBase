namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_11_SystemTestInExtending : BEC_3_6_4_10_SystemTestExtendable {
public BEC_3_6_4_11_SystemTestInExtending() { }
static BEC_3_6_4_11_SystemTestInExtending() { }
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x49,0x6E,0x45,0x78,0x74,0x65,0x6E,0x64,0x69,0x6E,0x67};
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;

public static new BET_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;

public BEC_2_6_6_SystemObject bevp_prop2a;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_3_6_4_10_SystemTestExtendable bem_bcall_0() {
bevp_propa.bemd_0(-1762451596);
return this;
} /*method end*/
public virtual BEC_3_6_4_11_SystemTestInExtending bem_ccall_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_prop2aGet_0() {
return bevp_prop2a;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prop2aGetDirect_0() {
return bevp_prop2a;
} /*method end*/
public virtual BEC_3_6_4_11_SystemTestInExtending bem_prop2aSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_prop2aSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {222, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 24, 27, 30, 34};
/* BEGIN LINEINFO 
print 0 222 17
return 1 0 24
return 1 0 27
assign 1 0 30
assign 1 0 34
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1259279320: return bem_propbGetDirect_0();
case -1737970926: return bem_toString_0();
case -1762451596: return bem_print_0();
case 1443041557: return bem_echo_0();
case -1679574124: return bem_prop2aGet_0();
case 1423970494: return bem_bcall_0();
case -2050938340: return bem_iteratorGet_0();
case 912896996: return bem_sourceFileNameGet_0();
case 2114426394: return bem_ccall_0();
case -163001642: return bem_serializeContents_0();
case 1540192904: return bem_once_0();
case -1649925616: return bem_propbGet_0();
case 664995964: return bem_many_0();
case 212273782: return bem_hashGet_0();
case 942168519: return bem_serializationIteratorGet_0();
case -1599008676: return bem_serializeToString_0();
case -1065178102: return bem_deserializeClassNameGet_0();
case 1500504504: return bem_new_0();
case 305284571: return bem_prop2aGetDirect_0();
case 536183275: return bem_tagGet_0();
case 833786164: return bem_create_0();
case -677806483: return bem_toAny_0();
case 1905099761: return bem_propaGet_0();
case 2045377383: return bem_classNameGet_0();
case -296810667: return bem_copy_0();
case -1714758025: return bem_propaGetDirect_0();
case -844998411: return bem_fieldNamesGet_0();
case 918246902: return bem_fieldIteratorGet_0();
case -478413698: return bem_acall_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1424462703: return bem_notEquals_1(bevd_0);
case -653746224: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 595968186: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 618985734: return bem_propaSetDirect_1(bevd_0);
case 1329377857: return bem_sameObject_1(bevd_0);
case 873957775: return bem_sameType_1(bevd_0);
case -850057288: return bem_copyTo_1(bevd_0);
case 598878525: return bem_sameClass_1(bevd_0);
case 1999927566: return bem_undef_1(bevd_0);
case -107002521: return bem_propaSet_1(bevd_0);
case 913924184: return bem_prop2aSet_1(bevd_0);
case -236948784: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1686430384: return bem_otherType_1(bevd_0);
case -1466239758: return bem_propbSet_1(bevd_0);
case -896840024: return bem_def_1(bevd_0);
case -1158261503: return bem_prop2aSetDirect_1(bevd_0);
case -650068928: return bem_equals_1(bevd_0);
case 723799991: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 658098740: return bem_undefined_1(bevd_0);
case 860343971: return bem_otherClass_1(bevd_0);
case -1142778017: return bem_defined_1(bevd_0);
case 1852483425: return bem_propbSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 348982157: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 422466535: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1266547135: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1450087500: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1218154238: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1431615808: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1528949086: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_6_4_11_SystemTestInExtending_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_11_SystemTestInExtending_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_4_11_SystemTestInExtending();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst = (BEC_3_6_4_11_SystemTestInExtending) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;
}
}
}
