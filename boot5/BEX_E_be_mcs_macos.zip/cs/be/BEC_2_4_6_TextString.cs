namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
      //do copy, isOnce
      this.bevi_bytes = new byte[bevi_length];
      Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
      bevp_size = new BEC_2_4_3_MathInt(bevi_length);
      bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_18 = (new BEC_2_4_3_MathInt(43));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_19 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_20 = (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_21 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_22 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_23 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_24 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_25 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_26 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_27 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_28 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_29 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_30 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_31 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_32 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_33 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_34 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_35 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_36 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_37 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_38 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_39 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_40 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_41 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_42 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_43 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_44 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_45 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_46 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_47 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_48 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_49 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_50 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_51 = (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_52 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_53 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_54 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_55 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static new BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_4_6_TextString_bevo_0;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) bevt_1_ta_ph.bem_once_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_capacity == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 277*/ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 278*/
 else /* Line: 277*/ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 279*/ {
return this;
} /* Line: 280*/
} /* Line: 277*/

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 316*/ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 317*/
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_4_6_TextString_bevo_1;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) bevt_1_ta_ph.bem_once_0();
bem_new_1(bevt_0_ta_ph);
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_2;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_once_0();
bevp_size.bevi_int = bevt_2_ta_ph.bevi_int;
bevt_5_ta_ph = bece_BEC_2_4_6_TextString_bevo_3;
bevt_4_ta_ph = (BEC_2_4_3_MathInt) bevt_5_ta_ph.bem_once_0();
bem_setHex_2(bevt_4_ta_ph, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_ta_ph = bem_getCode_2(beva_pos, bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_toString_3(bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1989693945);
if (bevp_leni == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 339*/ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 341*/
bevt_1_ta_ph = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_ta_ph.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 346*/ {
bevt_5_ta_ph = bece_BEC_2_4_6_TextString_bevo_4;
bevt_4_ta_ph = bevp_sizi.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = bece_BEC_2_4_6_TextString_bevo_5;
bevt_3_ta_ph = bevt_4_ta_ph.bem_multiply_1(bevt_6_ta_ph);
bevt_7_ta_ph = bece_BEC_2_4_6_TextString_bevo_6;
bevl_nsize = bevt_3_ta_ph.bem_divide_1(bevt_7_ta_ph);
bem_capacitySet_1(bevl_nsize);
} /* Line: 348*/
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_8_ta_ph, bevt_9_ta_ph, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(568704480, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_4_6_TextString_bevo_7;
if (bevp_size.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_8;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_once_0();
bevt_5_ta_ph = bece_BEC_2_4_6_TextString_bevo_9;
bevt_4_ta_ph = (BEC_2_4_3_MathInt) bevt_5_ta_ph.bem_once_0();
bem_setIntUnchecked_2(bevt_2_ta_ph, bevt_4_ta_ph);
bevt_7_ta_ph = bece_BEC_2_4_6_TextString_bevo_10;
bevt_6_ta_ph = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bem_once_0();
bevp_size.bevi_int = bevt_6_ta_ph.bevi_int;
} /* Line: 384*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_2_ta_ph = bece_BEC_2_4_6_TextString_bevo_11;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) bevt_2_ta_ph.bem_once_0();
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_4_ta_ph = bece_BEC_2_4_6_TextString_bevo_12;
bevt_3_ta_ph = (BEC_2_4_3_MathInt) bevt_4_ta_ph.bem_once_0();
bem_setCodeUnchecked_2(bevt_3_ta_ph, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_0_ta_ph = bem_ends_1(bevl_nl);
if (bevt_0_ta_ph.bevi_bool)/* Line: 396*/ {
bevt_2_ta_ph = bece_BEC_2_4_6_TextString_bevo_13;
bevt_4_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_3_ta_ph = bevp_size.bem_subtract_1(bevt_4_ta_ph);
bevt_1_ta_ph = bem_substring_2(bevt_2_ta_ph, bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 397*/
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_5_ta_ph = bem_ends_1(bevl_nl);
if (bevt_5_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_7_ta_ph = bece_BEC_2_4_6_TextString_bevo_14;
bevt_9_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_8_ta_ph = bevp_size.bem_subtract_1(bevt_9_ta_ph);
bevt_6_ta_ph = bem_substring_2(bevt_7_ta_ph, bevt_8_ta_ph);
return bevt_6_ta_ph;
} /* Line: 401*/
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_4_6_TextString_bevo_15;
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 414*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 414*/ {
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_16;
if (bevl_found.bevi_int != bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 414*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 414*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 414*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 414*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 415*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 421*/
bevt_3_ta_ph = beva_str.bem_sizeGet_0();
bevt_2_ta_ph = bevp_size.bem_subtract_1(bevt_3_ta_ph);
bevl_found = bem_find_2(beva_str, bevt_2_ta_ph);
if (bevl_found == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 423*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 424*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 430*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 430*/ {
bevt_3_ta_ph = bem_find_1(beva_str);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 430*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 430*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 430*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 430*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 431*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isInteger_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 442*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 442*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_ta_ph = bece_BEC_2_4_6_TextString_bevo_17;
if (bevl_j.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 444*/ {
bevt_6_ta_ph = bece_BEC_2_4_6_TextString_bevo_18;
if (bevl_ic.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 444*/ {
bevt_8_ta_ph = bece_BEC_2_4_6_TextString_bevo_19;
if (bevl_ic.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 444*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 444*/
 else /* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 444*/ {
} /* Line: 444*/
 else /* Line: 444*/ {
bevt_10_ta_ph = bece_BEC_2_4_6_TextString_bevo_20;
if (bevl_ic.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 446*/ {
bevt_12_ta_ph = bece_BEC_2_4_6_TextString_bevo_21;
if (bevl_ic.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 446*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 446*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 446*/ {
bevt_13_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 447*/
} /* Line: 444*/
bevl_j.bevi_int++;
} /* Line: 442*/
 else /* Line: 442*/ {
break;
} /* Line: 442*/
} /* Line: 442*/
bevt_14_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumGet_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 455*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 455*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_5_ta_ph = bece_BEC_2_4_6_TextString_bevo_22;
if (bevl_ic.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_7_ta_ph = bece_BEC_2_4_6_TextString_bevo_23;
if (bevl_ic.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
 else /* Line: 457*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_9_ta_ph = bece_BEC_2_4_6_TextString_bevo_24;
if (bevl_ic.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_11_ta_ph = bece_BEC_2_4_6_TextString_bevo_25;
if (bevl_ic.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
 else /* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_13_ta_ph = bece_BEC_2_4_6_TextString_bevo_26;
if (bevl_ic.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_15_ta_ph = bece_BEC_2_4_6_TextString_bevo_27;
if (bevl_ic.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
 else /* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 457*/ {
bevt_16_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 458*/
bevl_j.bevi_int++;
} /* Line: 455*/
 else /* Line: 455*/ {
break;
} /* Line: 455*/
} /* Line: 455*/
bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumericGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAlphaNumGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 470*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 470*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_28;
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 472*/ {
bevt_5_ta_ph = bece_BEC_2_4_6_TextString_bevo_29;
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 472*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 472*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 472*/
 else /* Line: 472*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 472*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_ta_ph.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 474*/
bevl_j.bevi_int++;
} /* Line: 470*/
 else /* Line: 470*/ {
break;
} /* Line: 470*/
} /* Line: 470*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lowerValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 485*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 485*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_30;
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 487*/ {
bevt_5_ta_ph = bece_BEC_2_4_6_TextString_bevo_31;
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 487*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 487*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 487*/
 else /* Line: 487*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 487*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_ta_ph);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 489*/
bevl_j.bevi_int++;
} /* Line: 485*/
 else /* Line: 485*/ {
break;
} /* Line: 485*/
} /* Line: 485*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_upperValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bem_split_1(beva_from);
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_to, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 509*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_2_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = bem_sizeGet_0();
bevt_3_ta_ph = bem_substring_2(bevl_last, bevt_4_ta_ph);
bevl_res.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 513*/
 else /* Line: 514*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) beva_from.bem_copy_0();
return bevt_5_ta_ph;
} /* Line: 515*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 525*/ {
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 525*/ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 527*/ {
bevt_2_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_3_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_ta_ph);
} /* Line: 530*/
 else /* Line: 532*/ {
bevt_5_ta_ph = bem_sizeGet_0();
bevt_4_ta_ph = bem_substring_2(bevl_last, bevt_5_ta_ph);
bevl_res.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 533*/
} /* Line: 527*/
 else /* Line: 525*/ {
break;
} /* Line: 525*/
} /* Line: 525*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_j = bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 544*/ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 544*/ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 544*/
 else /* Line: 544*/ {
break;
} /* Line: 544*/
} /* Line: 544*/
bevt_2_ta_ph = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_ta_ph.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 554*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 554*/ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_ta_ph);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 554*/
 else /* Line: 554*/ {
break;
} /* Line: 554*/
} /* Line: 554*/
return beva_into;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_hashValue_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getCode_2(beva_pos, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_4_6_TextString_bevo_32;
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 578*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 578*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 578*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 578*/
 else /* Line: 578*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 578*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 606*/
 else /* Line: 614*/ {
return null;
} /* Line: 615*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_4_6_TextString_bevo_33;
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 628*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 628*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 628*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 628*/
 else /* Line: 628*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 628*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 657*/
 else /* Line: 662*/ {
return null;
} /* Line: 663*/
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_4_6_TextString_bevo_34;
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 669*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 669*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 669*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 669*/
 else /* Line: 669*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 669*/ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 670*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_4_6_TextString_bevo_35;
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 675*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 675*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 675*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 675*/
 else /* Line: 675*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 675*/ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 676*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevl_input = this;
bevt_3_ta_ph = bevl_input.bem_sizeGet_0();
bevl_insz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_copy_0();
bevl_output = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_p = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 686*/ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 686*/ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_ta_ph = bece_BEC_2_4_6_TextString_bevo_36;
if (bevl_c.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_8_ta_ph = bece_BEC_2_4_6_TextString_bevo_37;
if (bevl_c.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
 else /* Line: 688*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_10_ta_ph = bece_BEC_2_4_6_TextString_bevo_38;
if (bevl_c.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_12_ta_ph = bece_BEC_2_4_6_TextString_bevo_39;
if (bevl_c.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
 else /* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_14_ta_ph = bece_BEC_2_4_6_TextString_bevo_40;
if (bevl_c.bevi_int > bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_16_ta_ph = bece_BEC_2_4_6_TextString_bevo_41;
if (bevl_c.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
 else /* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 688*/ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 690*/
bevl_i.bevi_int++;
} /* Line: 686*/
 else /* Line: 686*/ {
break;
} /* Line: 686*/
} /* Line: 686*/
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_4_6_TextString_bevo_42;
if (bevp_size.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 698*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 699*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_rfind_1(beva_str);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_reverseBytes_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_reverseBytes_0();
bevl_rpos = bevt_0_ta_ph.bem_find_1(bevt_2_ta_ph);
if (bevl_rpos == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 806*/ {
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_ta_ph.bevi_int;
bevt_6_ta_ph = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_ta_ph;
} /* Line: 808*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_4_6_TextString_bevo_43;
bevt_0_ta_ph = bem_find_2(beva_str, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
if (beva_str == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
if (beva_start == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_9_ta_ph = bece_BEC_2_4_6_TextString_bevo_44;
if (beva_start.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_12_ta_ph = beva_str.bem_sizeGet_0();
if (bevt_12_ta_ph.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_14_ta_ph = bece_BEC_2_4_6_TextString_bevo_45;
if (bevp_size.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_16_ta_ph = beva_str.bem_sizeGet_0();
bevt_17_ta_ph = bece_BEC_2_4_6_TextString_bevo_46;
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 820*/ {
return null;
} /* Line: 821*/
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_ta_ph, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_ta_ph = bece_BEC_2_4_6_TextString_bevo_47;
if (bevl_strsize.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 832*/ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 835*/
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
/* Line: 838*/ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 838*/ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 840*/ {
bevt_24_ta_ph = bece_BEC_2_4_6_TextString_bevo_48;
if (bevl_strsize.bevi_int == bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 841*/ {
return bevl_current;
} /* Line: 842*/
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_ta_ph = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_ta_ph.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 848*/ {
return null;
} /* Line: 849*/
bevt_28_ta_ph = bece_BEC_2_4_6_TextString_bevo_49;
bevt_27_ta_ph = (BEC_2_4_3_MathInt) bevt_28_ta_ph.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_ta_ph.bevi_int;
while (true)
/* Line: 852*/ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 852*/ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 855*/ {
break;
} /* Line: 856*/
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 859*/
 else /* Line: 852*/ {
break;
} /* Line: 852*/
} /* Line: 852*/
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_31_ta_ph.bevi_bool)/* Line: 861*/ {
return bevl_current;
} /* Line: 862*/
} /* Line: 861*/
bevl_current.bevi_int++;
} /* Line: 865*/
 else /* Line: 838*/ {
break;
} /* Line: 838*/
} /* Line: 838*/
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
/* Line: 875*/ {
if (bevl_i == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 875*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_ta_ph);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 878*/
 else /* Line: 875*/ {
break;
} /* Line: 875*/
} /* Line: 875*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 880*/ {
bevt_3_ta_ph = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 881*/
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_9_TextTokenizer bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_lineSplitterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_stri == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 903*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 903*/ {
bevt_2_ta_ph = beva_stri.bemd_1(-1089350026, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 903*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 903*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 903*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 903*/ {
return null;
} /* Line: 904*/
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-1482984555);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 908*/ {
bevl_maxsize = bevl_osize;
} /* Line: 909*/
 else /* Line: 910*/ {
bevl_maxsize = bevl_mysize;
} /* Line: 911*/
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 916*/ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 916*/ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(1551449746, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 919*/ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 920*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_ta_ph;
} /* Line: 921*/
 else /* Line: 922*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_ta_ph;
} /* Line: 923*/
} /* Line: 920*/
bevl_i.bevi_int++;
} /* Line: 916*/
 else /* Line: 916*/ {
break;
} /* Line: 916*/
} /* Line: 916*/
bevt_10_ta_ph = bece_BEC_2_4_6_TextString_bevo_50;
if (bevl_myret.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 927*/ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 928*/ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 929*/
 else /* Line: 928*/ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 930*/ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 931*/
} /* Line: 928*/
} /* Line: 928*/
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 938*/ {
return null;
} /* Line: 938*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_51;
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 939*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 940*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 946*/ {
return null;
} /* Line: 946*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_52;
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 947*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 948*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_str);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1989693945);
bevt_1_ta_ph = bevl_str.bem_sizeGet_0();
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_ta_ph, bevp_size, bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_ta_ph, bevt_5_ta_ph, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_9_SystemException bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_4_6_TextString_bevo_53;
if (beva_starti.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_4_ta_ph = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_6_ta_ph = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1032*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1032*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1032*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_7_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_ta_ph);
throw new be.BECS_ThrowBack(bevt_7_ta_ph);
} /* Line: 1033*/
 else /* Line: 1034*/ {
if (bevp_leni == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 1037*/ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 1039*/
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1048*/ {
bem_capacitySet_1(bevp_sizi);
} /* Line: 1049*/

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 1082*/ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 1086*/
return this;
} /* Line: 1088*/
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sizeGet_0();
bevt_0_ta_ph = bem_substring_2(beva_starti, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_2_ta_ph = beva_endi.bem_subtract_1(beva_starti);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_snw == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1223*/ {
bem_new_0();
} /* Line: 1224*/
 else /* Line: 1225*/ {
bevt_2_ta_ph = beva_snw.bem_sizeGet_0();
bevt_3_ta_ph = bece_BEC_2_4_6_TextString_bevo_54;
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_new_1(bevt_1_ta_ph);
bem_addValue_1(beva_snw);
} /* Line: 1227*/
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_strip_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bece_BEC_2_4_6_TextString_bevo_55;
bevl_e = bevp_size.bem_subtract_1(bevt_0_ta_ph);
while (true)
/* Line: 1244*/ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1244*/ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1250*/
 else /* Line: 1244*/ {
break;
} /* Line: 1244*/
} /* Line: 1244*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGetDirect_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGetDirect_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {259, 260, 273, 273, 273, 277, 277, 278, 279, 279, 280, 316, 316, 317, 319, 323, 323, 323, 324, 324, 324, 325, 325, 325, 329, 329, 329, 329, 329, 329, 329, 333, 334, 338, 339, 339, 340, 341, 343, 343, 344, 346, 346, 347, 347, 347, 347, 347, 347, 348, 350, 350, 350, 354, 358, 362, 366, 376, 377, 378, 382, 382, 382, 383, 383, 383, 383, 383, 384, 384, 384, 389, 389, 390, 390, 390, 391, 391, 391, 395, 396, 397, 397, 397, 397, 397, 399, 400, 401, 401, 401, 401, 401, 403, 407, 407, 407, 408, 409, 413, 414, 414, 0, 414, 414, 414, 0, 0, 415, 415, 417, 417, 421, 421, 421, 421, 422, 422, 422, 423, 423, 424, 424, 426, 426, 430, 430, 0, 430, 430, 430, 0, 0, 431, 431, 433, 433, 437, 437, 441, 442, 442, 442, 443, 444, 444, 444, 444, 444, 444, 0, 444, 444, 444, 0, 0, 0, 0, 0, 446, 446, 446, 0, 446, 446, 446, 0, 0, 447, 447, 442, 450, 450, 454, 455, 455, 455, 456, 457, 457, 457, 457, 457, 457, 0, 0, 0, 0, 457, 457, 457, 457, 457, 457, 0, 0, 0, 0, 0, 0, 457, 457, 457, 457, 457, 457, 0, 0, 0, 0, 0, 458, 458, 455, 461, 461, 465, 465, 469, 470, 470, 470, 471, 472, 472, 472, 472, 472, 472, 0, 0, 0, 473, 473, 474, 470, 480, 480, 480, 484, 485, 485, 485, 486, 487, 487, 487, 487, 487, 487, 0, 0, 0, 488, 488, 489, 485, 495, 495, 495, 499, 499, 499, 499, 505, 506, 507, 508, 509, 509, 510, 510, 511, 512, 512, 513, 513, 513, 515, 515, 517, 522, 523, 524, 525, 525, 526, 527, 527, 528, 528, 529, 530, 530, 533, 533, 533, 537, 542, 542, 543, 544, 544, 544, 545, 544, 547, 547, 548, 552, 553, 553, 554, 554, 554, 555, 556, 556, 557, 554, 560, 564, 564, 564, 568, 568, 568, 578, 578, 578, 578, 578, 0, 0, 0, 615, 617, 628, 628, 628, 628, 628, 0, 0, 0, 663, 665, 669, 669, 669, 669, 669, 0, 0, 0, 670, 675, 675, 675, 675, 675, 0, 0, 0, 676, 681, 682, 682, 683, 684, 685, 686, 686, 686, 687, 688, 688, 688, 688, 688, 688, 0, 0, 0, 0, 688, 688, 688, 688, 688, 688, 0, 0, 0, 0, 0, 0, 688, 688, 688, 688, 688, 688, 0, 0, 0, 0, 0, 689, 690, 686, 693, 694, 698, 698, 698, 699, 699, 701, 701, 798, 798, 804, 804, 804, 804, 804, 806, 806, 807, 807, 808, 808, 810, 814, 814, 814, 820, 820, 0, 820, 820, 0, 0, 0, 820, 820, 820, 0, 0, 0, 820, 820, 0, 0, 0, 820, 820, 820, 0, 0, 0, 820, 820, 820, 0, 0, 0, 820, 820, 820, 820, 0, 0, 821, 824, 825, 826, 827, 828, 828, 830, 832, 832, 832, 833, 834, 835, 837, 838, 838, 839, 840, 840, 841, 841, 841, 842, 844, 845, 846, 847, 847, 848, 848, 849, 851, 851, 851, 852, 852, 853, 854, 855, 855, 858, 859, 861, 861, 862, 865, 867, 871, 872, 873, 874, 875, 875, 876, 876, 877, 878, 880, 880, 881, 881, 883, 887, 887, 887, 891, 891, 891, 891, 895, 903, 903, 0, 903, 0, 0, 904, 906, 907, 908, 908, 909, 911, 913, 914, 915, 916, 916, 916, 917, 918, 919, 919, 920, 920, 921, 921, 923, 923, 916, 927, 927, 927, 928, 928, 929, 930, 930, 931, 934, 938, 938, 938, 939, 939, 939, 939, 940, 940, 942, 942, 946, 946, 946, 947, 947, 947, 947, 948, 948, 950, 950, 1013, 1013, 1017, 1017, 1017, 1021, 1022, 1022, 1022, 1023, 1023, 1023, 1024, 1024, 1024, 1025, 1028, 1028, 1032, 1032, 1032, 0, 1032, 1032, 1032, 0, 1032, 1032, 1032, 0, 0, 0, 0, 1033, 1033, 1033, 1037, 1037, 1038, 1039, 1041, 1042, 1043, 1045, 1046, 1048, 1048, 1049, 1082, 1082, 1086, 1088, 1093, 1093, 1093, 1097, 1097, 1097, 1097, 1097, 1191, 1195, 1195, 1199, 1199, 1203, 1203, 1207, 1207, 1211, 1211, 1215, 1215, 1219, 1223, 1223, 1224, 1226, 1226, 1226, 1226, 1227, 1232, 1232, 1236, 1236, 1236, 1240, 1241, 1242, 1243, 1243, 1244, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {117, 118, 124, 125, 126, 133, 138, 139, 142, 147, 148, 159, 164, 165, 167, 177, 178, 179, 180, 181, 182, 183, 184, 185, 195, 196, 197, 198, 199, 200, 201, 205, 206, 222, 223, 228, 229, 230, 232, 233, 234, 235, 240, 241, 242, 243, 244, 245, 246, 247, 249, 250, 251, 255, 258, 261, 265, 276, 277, 278, 289, 290, 295, 296, 297, 298, 299, 300, 301, 302, 303, 313, 314, 315, 316, 317, 318, 319, 320, 335, 336, 338, 339, 340, 341, 342, 344, 345, 347, 348, 349, 350, 351, 353, 359, 360, 361, 362, 363, 373, 374, 379, 380, 383, 384, 389, 390, 393, 397, 398, 400, 401, 412, 417, 418, 419, 421, 422, 423, 424, 429, 430, 431, 433, 434, 443, 448, 449, 452, 453, 458, 459, 462, 466, 467, 469, 470, 474, 475, 495, 496, 499, 504, 505, 506, 507, 512, 513, 514, 519, 520, 523, 524, 529, 530, 533, 537, 540, 544, 549, 550, 555, 556, 559, 560, 565, 566, 569, 573, 574, 577, 583, 584, 607, 608, 611, 616, 617, 618, 619, 624, 625, 626, 631, 632, 635, 639, 642, 645, 646, 651, 652, 653, 658, 659, 662, 666, 669, 672, 676, 679, 680, 685, 686, 687, 692, 693, 696, 700, 703, 706, 710, 711, 713, 719, 720, 724, 725, 737, 738, 741, 746, 747, 748, 749, 754, 755, 756, 761, 762, 765, 769, 772, 773, 774, 776, 787, 788, 789, 801, 802, 805, 810, 811, 812, 813, 818, 819, 820, 825, 826, 829, 833, 836, 837, 838, 840, 851, 852, 853, 859, 860, 861, 862, 874, 875, 876, 877, 878, 883, 884, 885, 886, 887, 888, 889, 890, 891, 894, 895, 897, 909, 910, 911, 914, 919, 920, 921, 926, 927, 928, 929, 930, 931, 934, 935, 936, 943, 953, 954, 955, 956, 959, 964, 965, 966, 972, 973, 974, 982, 983, 984, 985, 988, 993, 994, 995, 996, 997, 998, 1004, 1009, 1010, 1011, 1016, 1017, 1018, 1025, 1026, 1031, 1032, 1037, 1038, 1041, 1045, 1055, 1057, 1064, 1065, 1070, 1071, 1076, 1077, 1080, 1084, 1091, 1093, 1100, 1101, 1106, 1107, 1112, 1113, 1116, 1120, 1123, 1132, 1133, 1138, 1139, 1144, 1145, 1148, 1152, 1155, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1192, 1197, 1198, 1199, 1200, 1205, 1206, 1207, 1212, 1213, 1216, 1220, 1223, 1226, 1227, 1232, 1233, 1234, 1239, 1240, 1243, 1247, 1250, 1253, 1257, 1260, 1261, 1266, 1267, 1268, 1273, 1274, 1277, 1281, 1284, 1287, 1291, 1292, 1294, 1300, 1301, 1308, 1309, 1314, 1315, 1316, 1318, 1319, 1337, 1338, 1349, 1350, 1351, 1352, 1353, 1354, 1359, 1360, 1361, 1362, 1363, 1365, 1370, 1371, 1372, 1416, 1421, 1422, 1425, 1430, 1431, 1434, 1438, 1441, 1442, 1447, 1448, 1451, 1455, 1458, 1463, 1464, 1467, 1471, 1474, 1475, 1480, 1481, 1484, 1488, 1491, 1492, 1497, 1498, 1501, 1505, 1508, 1509, 1510, 1515, 1516, 1519, 1523, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1538, 1539, 1540, 1541, 1543, 1546, 1551, 1552, 1553, 1558, 1559, 1560, 1565, 1566, 1568, 1569, 1570, 1571, 1572, 1573, 1578, 1579, 1581, 1582, 1583, 1586, 1591, 1592, 1593, 1594, 1599, 1602, 1603, 1609, 1614, 1615, 1618, 1624, 1635, 1636, 1637, 1638, 1641, 1646, 1647, 1648, 1649, 1650, 1656, 1661, 1662, 1663, 1665, 1670, 1671, 1672, 1678, 1679, 1680, 1681, 1684, 1707, 1712, 1713, 1716, 1718, 1721, 1725, 1727, 1728, 1729, 1734, 1735, 1738, 1740, 1741, 1742, 1743, 1746, 1751, 1752, 1753, 1754, 1759, 1760, 1765, 1766, 1767, 1770, 1771, 1774, 1780, 1781, 1786, 1787, 1792, 1793, 1796, 1801, 1802, 1806, 1815, 1820, 1821, 1823, 1824, 1825, 1830, 1831, 1832, 1834, 1835, 1844, 1849, 1850, 1852, 1853, 1854, 1859, 1860, 1861, 1863, 1864, 1878, 1879, 1884, 1885, 1890, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1909, 1910, 1911, 1915, 1916, 1933, 1934, 1939, 1940, 1943, 1944, 1949, 1950, 1953, 1954, 1959, 1960, 1963, 1967, 1970, 1974, 1975, 1976, 1979, 1984, 1985, 1986, 1988, 1989, 1990, 1991, 1992, 1993, 1998, 1999, 2004, 2009, 2010, 2012, 2018, 2019, 2020, 2027, 2028, 2029, 2030, 2031, 2047, 2052, 2053, 2057, 2058, 2062, 2063, 2067, 2068, 2072, 2073, 2077, 2078, 2081, 2088, 2093, 2094, 2097, 2098, 2099, 2100, 2101, 2107, 2108, 2113, 2114, 2115, 2124, 2125, 2126, 2127, 2128, 2131, 2136, 2137, 2138, 2139, 2140, 2141, 2142, 2151, 2154, 2157, 2161, 2165, 2168, 2171, 2175, 2178, 2181, 2185, 2189, 2192, 2195, 2199};
/* BEGIN LINEINFO 
assign 1 259 117
new 0 259 117
capacitySet 1 260 118
assign 1 273 124
new 0 273 124
assign 1 273 125
once 0 273 125
new 1 273 126
assign 1 277 133
undef 1 277 138
assign 1 278 139
new 0 278 139
assign 1 279 142
equals 1 279 147
return 1 280 148
assign 1 316 159
greater 1 316 164
setValue 1 317 165
setValue 1 319 167
assign 1 323 177
new 0 323 177
assign 1 323 178
once 0 323 178
new 1 323 179
assign 1 324 180
new 0 324 180
assign 1 324 181
once 0 324 181
setValue 1 324 182
assign 1 325 183
new 0 325 183
assign 1 325 184
once 0 325 184
setHex 2 325 185
assign 1 329 195
new 0 329 195
assign 1 329 196
getCode 2 329 196
assign 1 329 197
new 0 329 197
assign 1 329 198
new 0 329 198
assign 1 329 199
new 0 329 199
assign 1 329 200
toString 3 329 200
return 1 329 201
assign 1 333 205
hexNew 1 333 205
setCode 2 334 206
assign 1 338 222
toString 0 338 222
assign 1 339 223
undef 1 339 228
assign 1 340 229
new 0 340 229
assign 1 341 230
new 0 341 230
assign 1 343 232
sizeGet 0 343 232
setValue 1 343 233
addValue 1 344 234
assign 1 346 235
lesser 1 346 240
assign 1 347 241
new 0 347 241
assign 1 347 242
add 1 347 242
assign 1 347 243
new 0 347 243
assign 1 347 244
multiply 1 347 244
assign 1 347 245
new 0 347 245
assign 1 347 246
divide 1 347 246
capacitySet 1 348 247
assign 1 350 249
new 0 350 249
assign 1 350 250
sizeGet 0 350 250
copyValue 4 350 251
return 1 354 255
return 1 358 258
addValue 1 362 261
write 1 366 265
assign 1 376 276
copy 0 376 276
clear 0 377 277
return 1 378 278
assign 1 382 289
new 0 382 289
assign 1 382 290
greater 1 382 295
assign 1 383 296
new 0 383 296
assign 1 383 297
once 0 383 297
assign 1 383 298
new 0 383 298
assign 1 383 299
once 0 383 299
setIntUnchecked 2 383 300
assign 1 384 301
new 0 384 301
assign 1 384 302
once 0 384 302
setValue 1 384 303
assign 1 389 313
new 0 389 313
new 1 389 314
assign 1 390 315
new 0 390 315
assign 1 390 316
once 0 390 316
setValue 1 390 317
assign 1 391 318
new 0 391 318
assign 1 391 319
once 0 391 319
setCodeUnchecked 2 391 320
assign 1 395 335
new 0 395 335
assign 1 396 336
ends 1 396 336
assign 1 397 338
new 0 397 338
assign 1 397 339
sizeGet 0 397 339
assign 1 397 340
subtract 1 397 340
assign 1 397 341
substring 2 397 341
return 1 397 342
assign 1 399 344
new 0 399 344
assign 1 400 345
ends 1 400 345
assign 1 401 347
new 0 401 347
assign 1 401 348
sizeGet 0 401 348
assign 1 401 349
subtract 1 401 349
assign 1 401 350
substring 2 401 350
return 1 401 351
return 1 403 353
assign 1 407 359
new 0 407 359
assign 1 407 360
add 1 407 360
assign 1 407 361
new 1 407 361
addValue 1 408 362
return 1 409 363
assign 1 413 373
find 1 413 373
assign 1 414 374
undef 1 414 379
assign 1 0 380
assign 1 414 383
new 0 414 383
assign 1 414 384
notEquals 1 414 389
assign 1 0 390
assign 1 0 393
assign 1 415 397
new 0 415 397
return 1 415 398
assign 1 417 400
new 0 417 400
return 1 417 401
assign 1 421 412
undef 1 421 417
assign 1 421 418
new 0 421 418
return 1 421 419
assign 1 422 421
sizeGet 0 422 421
assign 1 422 422
subtract 1 422 422
assign 1 422 423
find 2 422 423
assign 1 423 424
undef 1 423 429
assign 1 424 430
new 0 424 430
return 1 424 431
assign 1 426 433
new 0 426 433
return 1 426 434
assign 1 430 443
undef 1 430 448
assign 1 0 449
assign 1 430 452
find 1 430 452
assign 1 430 453
undef 1 430 458
assign 1 0 459
assign 1 0 462
assign 1 431 466
new 0 431 466
return 1 431 467
assign 1 433 469
new 0 433 469
return 1 433 470
assign 1 437 474
isInteger 0 437 474
return 1 437 475
assign 1 441 495
new 0 441 495
assign 1 442 496
new 0 442 496
assign 1 442 499
lesser 1 442 504
getInt 2 443 505
assign 1 444 506
new 0 444 506
assign 1 444 507
equals 1 444 512
assign 1 444 513
new 0 444 513
assign 1 444 514
equals 1 444 519
assign 1 0 520
assign 1 444 523
new 0 444 523
assign 1 444 524
equals 1 444 529
assign 1 0 530
assign 1 0 533
assign 1 0 537
assign 1 0 540
assign 1 0 544
assign 1 446 549
new 0 446 549
assign 1 446 550
greater 1 446 555
assign 1 0 556
assign 1 446 559
new 0 446 559
assign 1 446 560
lesser 1 446 565
assign 1 0 566
assign 1 0 569
assign 1 447 573
new 0 447 573
return 1 447 574
incrementValue 0 442 577
assign 1 450 583
new 0 450 583
return 1 450 584
assign 1 454 607
new 0 454 607
assign 1 455 608
new 0 455 608
assign 1 455 611
lesser 1 455 616
getInt 2 456 617
assign 1 457 618
new 0 457 618
assign 1 457 619
greater 1 457 624
assign 1 457 625
new 0 457 625
assign 1 457 626
lesser 1 457 631
assign 1 0 632
assign 1 0 635
assign 1 0 639
assign 1 0 642
assign 1 457 645
new 0 457 645
assign 1 457 646
greater 1 457 651
assign 1 457 652
new 0 457 652
assign 1 457 653
lesser 1 457 658
assign 1 0 659
assign 1 0 662
assign 1 0 666
assign 1 0 669
assign 1 0 672
assign 1 0 676
assign 1 457 679
new 0 457 679
assign 1 457 680
greater 1 457 685
assign 1 457 686
new 0 457 686
assign 1 457 687
lesser 1 457 692
assign 1 0 693
assign 1 0 696
assign 1 0 700
assign 1 0 703
assign 1 0 706
assign 1 458 710
new 0 458 710
return 1 458 711
incrementValue 0 455 713
assign 1 461 719
new 0 461 719
return 1 461 720
assign 1 465 724
isAlphaNumGet 0 465 724
return 1 465 725
assign 1 469 737
new 0 469 737
assign 1 470 738
new 0 470 738
assign 1 470 741
lesser 1 470 746
getInt 2 471 747
assign 1 472 748
new 0 472 748
assign 1 472 749
greater 1 472 754
assign 1 472 755
new 0 472 755
assign 1 472 756
lesser 1 472 761
assign 1 0 762
assign 1 0 765
assign 1 0 769
assign 1 473 772
new 0 473 772
addValue 1 473 773
setIntUnchecked 2 474 774
incrementValue 0 470 776
assign 1 480 787
copy 0 480 787
assign 1 480 788
lowerValue 0 480 788
return 1 480 789
assign 1 484 801
new 0 484 801
assign 1 485 802
new 0 485 802
assign 1 485 805
lesser 1 485 810
getInt 2 486 811
assign 1 487 812
new 0 487 812
assign 1 487 813
greater 1 487 818
assign 1 487 819
new 0 487 819
assign 1 487 820
lesser 1 487 825
assign 1 0 826
assign 1 0 829
assign 1 0 833
assign 1 488 836
new 0 488 836
subtractValue 1 488 837
setIntUnchecked 2 489 838
incrementValue 0 485 840
assign 1 495 851
copy 0 495 851
assign 1 495 852
upperValue 0 495 852
return 1 495 853
assign 1 499 859
new 0 499 859
assign 1 499 860
split 1 499 860
assign 1 499 861
join 2 499 861
return 1 499 862
assign 1 505 874
new 0 505 874
assign 1 506 875
new 0 506 875
assign 1 507 876
new 0 507 876
assign 1 508 877
find 2 508 877
assign 1 509 878
def 1 509 883
assign 1 510 884
substring 2 510 884
addValue 1 510 885
addValue 1 511 886
assign 1 512 887
sizeGet 0 512 887
assign 1 512 888
add 1 512 888
assign 1 513 889
sizeGet 0 513 889
assign 1 513 890
substring 2 513 890
addValue 1 513 891
assign 1 515 894
copy 0 515 894
return 1 515 895
return 1 517 897
assign 1 522 909
new 0 522 909
assign 1 523 910
new 0 523 910
assign 1 524 911
new 0 524 911
assign 1 525 914
def 1 525 919
assign 1 526 920
find 2 526 920
assign 1 527 921
def 1 527 926
assign 1 528 927
substring 2 528 927
addValue 1 528 928
addValue 1 529 929
assign 1 530 930
sizeGet 0 530 930
assign 1 530 931
add 1 530 931
assign 1 533 934
sizeGet 0 533 934
assign 1 533 935
substring 2 533 935
addValue 1 533 936
return 1 537 943
assign 1 542 953
new 0 542 953
assign 1 542 954
new 1 542 954
assign 1 543 955
mbiterGet 0 543 955
assign 1 544 956
new 0 544 956
assign 1 544 959
lesser 1 544 964
next 1 545 965
incrementValue 0 544 966
assign 1 547 972
next 1 547 972
assign 1 547 973
toString 0 547 973
return 1 548 974
assign 1 552 982
new 0 552 982
assign 1 553 983
new 0 553 983
setValue 1 553 984
assign 1 554 985
new 0 554 985
assign 1 554 988
lesser 1 554 993
getInt 2 555 994
assign 1 556 995
new 0 556 995
multiplyValue 1 556 996
addValue 1 557 997
incrementValue 0 554 998
return 1 560 1004
assign 1 564 1009
new 0 564 1009
assign 1 564 1010
hashValue 1 564 1010
return 1 564 1011
assign 1 568 1016
new 0 568 1016
assign 1 568 1017
getCode 2 568 1017
return 1 568 1018
assign 1 578 1025
new 0 578 1025
assign 1 578 1026
greaterEquals 1 578 1031
assign 1 578 1032
greater 1 578 1037
assign 1 0 1038
assign 1 0 1041
assign 1 0 1045
return 1 615 1055
return 1 617 1057
assign 1 628 1064
new 0 628 1064
assign 1 628 1065
greaterEquals 1 628 1070
assign 1 628 1071
greater 1 628 1076
assign 1 0 1077
assign 1 0 1080
assign 1 0 1084
return 1 663 1091
return 1 665 1093
assign 1 669 1100
new 0 669 1100
assign 1 669 1101
greaterEquals 1 669 1106
assign 1 669 1107
greater 1 669 1112
assign 1 0 1113
assign 1 0 1116
assign 1 0 1120
setIntUnchecked 2 670 1123
assign 1 675 1132
new 0 675 1132
assign 1 675 1133
greaterEquals 1 675 1138
assign 1 675 1139
greater 1 675 1144
assign 1 0 1145
assign 1 0 1148
assign 1 0 1152
setCodeUnchecked 2 676 1155
assign 1 681 1183
assign 1 682 1184
sizeGet 0 682 1184
assign 1 682 1185
copy 0 682 1185
assign 1 683 1186
new 1 683 1186
assign 1 684 1187
new 0 684 1187
assign 1 685 1188
new 0 685 1188
assign 1 686 1189
new 0 686 1189
assign 1 686 1192
lesser 1 686 1197
getInt 2 687 1198
assign 1 688 1199
new 0 688 1199
assign 1 688 1200
greater 1 688 1205
assign 1 688 1206
new 0 688 1206
assign 1 688 1207
lesser 1 688 1212
assign 1 0 1213
assign 1 0 1216
assign 1 0 1220
assign 1 0 1223
assign 1 688 1226
new 0 688 1226
assign 1 688 1227
greater 1 688 1232
assign 1 688 1233
new 0 688 1233
assign 1 688 1234
lesser 1 688 1239
assign 1 0 1240
assign 1 0 1243
assign 1 0 1247
assign 1 0 1250
assign 1 0 1253
assign 1 0 1257
assign 1 688 1260
new 0 688 1260
assign 1 688 1261
greater 1 688 1266
assign 1 688 1267
new 0 688 1267
assign 1 688 1268
lesser 1 688 1273
assign 1 0 1274
assign 1 0 1277
assign 1 0 1281
assign 1 0 1284
assign 1 0 1287
setIntUnchecked 2 689 1291
incrementValue 0 690 1292
incrementValue 0 686 1294
sizeSet 1 693 1300
return 1 694 1301
assign 1 698 1308
new 0 698 1308
assign 1 698 1309
lesserEquals 1 698 1314
assign 1 699 1315
new 0 699 1315
return 1 699 1316
assign 1 701 1318
new 0 701 1318
return 1 701 1319
assign 1 798 1337
rfind 1 798 1337
return 1 798 1338
assign 1 804 1349
copy 0 804 1349
assign 1 804 1350
reverseBytes 0 804 1350
assign 1 804 1351
copy 0 804 1351
assign 1 804 1352
reverseBytes 0 804 1352
assign 1 804 1353
find 1 804 1353
assign 1 806 1354
def 1 806 1359
assign 1 807 1360
sizeGet 0 807 1360
addValue 1 807 1361
assign 1 808 1362
subtract 1 808 1362
return 1 808 1363
return 1 810 1365
assign 1 814 1370
new 0 814 1370
assign 1 814 1371
find 2 814 1371
return 1 814 1372
assign 1 820 1416
undef 1 820 1421
assign 1 0 1422
assign 1 820 1425
undef 1 820 1430
assign 1 0 1431
assign 1 0 1434
assign 1 0 1438
assign 1 820 1441
new 0 820 1441
assign 1 820 1442
lesser 1 820 1447
assign 1 0 1448
assign 1 0 1451
assign 1 0 1455
assign 1 820 1458
greaterEquals 1 820 1463
assign 1 0 1464
assign 1 0 1467
assign 1 0 1471
assign 1 820 1474
sizeGet 0 820 1474
assign 1 820 1475
greater 1 820 1480
assign 1 0 1481
assign 1 0 1484
assign 1 0 1488
assign 1 820 1491
new 0 820 1491
assign 1 820 1492
equals 1 820 1497
assign 1 0 1498
assign 1 0 1501
assign 1 0 1505
assign 1 820 1508
sizeGet 0 820 1508
assign 1 820 1509
new 0 820 1509
assign 1 820 1510
equals 1 820 1515
assign 1 0 1516
assign 1 0 1519
return 1 821 1523
assign 1 824 1525
assign 1 825 1526
copy 0 825 1526
assign 1 826 1527
new 0 826 1527
assign 1 827 1528
new 0 827 1528
assign 1 828 1529
new 0 828 1529
getInt 2 828 1530
assign 1 830 1531
sizeGet 0 830 1531
assign 1 832 1532
new 0 832 1532
assign 1 832 1533
greater 1 832 1538
assign 1 833 1539
new 0 833 1539
assign 1 834 1540
new 0 834 1540
assign 1 835 1541
new 0 835 1541
assign 1 837 1543
new 0 837 1543
assign 1 838 1546
lesser 1 838 1551
getInt 2 839 1552
assign 1 840 1553
equals 1 840 1558
assign 1 841 1559
new 0 841 1559
assign 1 841 1560
equals 1 841 1565
return 1 842 1566
setValue 1 844 1568
incrementValue 0 845 1569
setValue 1 846 1570
assign 1 847 1571
sizeGet 0 847 1571
addValue 1 847 1572
assign 1 848 1573
greater 1 848 1578
return 1 849 1579
assign 1 851 1581
new 0 851 1581
assign 1 851 1582
once 0 851 1582
setValue 1 851 1583
assign 1 852 1586
lesser 1 852 1591
getInt 2 853 1592
getInt 2 854 1593
assign 1 855 1594
notEquals 1 855 1599
incrementValue 0 858 1602
incrementValue 0 859 1603
assign 1 861 1609
equals 1 861 1614
return 1 862 1615
incrementValue 0 865 1618
return 1 867 1624
assign 1 871 1635
new 0 871 1635
assign 1 872 1636
new 0 872 1636
assign 1 873 1637
find 2 873 1637
assign 1 874 1638
sizeGet 0 874 1638
assign 1 875 1641
def 1 875 1646
assign 1 876 1647
substring 2 876 1647
addValue 1 876 1648
assign 1 877 1649
add 1 877 1649
assign 1 878 1650
find 2 878 1650
assign 1 880 1656
lesser 1 880 1661
assign 1 881 1662
substring 2 881 1662
addValue 1 881 1663
return 1 883 1665
assign 1 887 1670
new 0 887 1670
assign 1 887 1671
join 2 887 1671
return 1 887 1672
assign 1 891 1678
new 0 891 1678
assign 1 891 1679
lineSplitterGet 0 891 1679
assign 1 891 1680
tokenize 1 891 1680
return 1 891 1681
return 1 895 1684
assign 1 903 1707
undef 1 903 1712
assign 1 0 1713
assign 1 903 1716
otherType 1 903 1716
assign 1 0 1718
assign 1 0 1721
return 1 904 1725
assign 1 906 1727
assign 1 907 1728
sizeGet 0 907 1728
assign 1 908 1729
greater 1 908 1734
assign 1 909 1735
assign 1 911 1738
assign 1 913 1740
new 0 913 1740
assign 1 914 1741
new 0 914 1741
assign 1 915 1742
new 0 915 1742
assign 1 916 1743
new 0 916 1743
assign 1 916 1746
lesser 1 916 1751
getCode 2 917 1752
getCode 2 918 1753
assign 1 919 1754
notEquals 1 919 1759
assign 1 920 1760
greater 1 920 1765
assign 1 921 1766
new 0 921 1766
return 1 921 1767
assign 1 923 1770
new 0 923 1770
return 1 923 1771
incrementValue 0 916 1774
assign 1 927 1780
new 0 927 1780
assign 1 927 1781
equals 1 927 1786
assign 1 928 1787
greater 1 928 1792
assign 1 929 1793
new 0 929 1793
assign 1 930 1796
greater 1 930 1801
assign 1 931 1802
new 0 931 1802
return 1 934 1806
assign 1 938 1815
undef 1 938 1820
return 1 938 1821
assign 1 939 1823
compare 1 939 1823
assign 1 939 1824
new 0 939 1824
assign 1 939 1825
equals 1 939 1830
assign 1 940 1831
new 0 940 1831
return 1 940 1832
assign 1 942 1834
new 0 942 1834
return 1 942 1835
assign 1 946 1844
undef 1 946 1849
return 1 946 1850
assign 1 947 1852
compare 1 947 1852
assign 1 947 1853
new 0 947 1853
assign 1 947 1854
equals 1 947 1859
assign 1 948 1860
new 0 948 1860
return 1 948 1861
assign 1 950 1863
new 0 950 1863
return 1 950 1864
assign 1 1013 1878
new 0 1013 1878
return 1 1013 1879
assign 1 1017 1884
equals 1 1017 1884
assign 1 1017 1885
not 0 1017 1890
return 1 1017 1890
assign 1 1021 1901
toString 0 1021 1901
assign 1 1022 1902
sizeGet 0 1022 1902
assign 1 1022 1903
add 1 1022 1903
assign 1 1022 1904
new 1 1022 1904
assign 1 1023 1905
new 0 1023 1905
assign 1 1023 1906
new 0 1023 1906
copyValue 4 1023 1907
assign 1 1024 1908
new 0 1024 1908
assign 1 1024 1909
sizeGet 0 1024 1909
copyValue 4 1024 1910
return 1 1025 1911
assign 1 1028 1915
new 0 1028 1915
return 1 1028 1916
assign 1 1032 1933
new 0 1032 1933
assign 1 1032 1934
lesser 1 1032 1939
assign 1 0 1940
assign 1 1032 1943
sizeGet 0 1032 1943
assign 1 1032 1944
greater 1 1032 1949
assign 1 0 1950
assign 1 1032 1953
sizeGet 0 1032 1953
assign 1 1032 1954
greater 1 1032 1959
assign 1 0 1960
assign 1 0 1963
assign 1 0 1967
assign 1 0 1970
assign 1 1033 1974
new 0 1033 1974
assign 1 1033 1975
new 1 1033 1975
throw 1 1033 1976
assign 1 1037 1979
undef 1 1037 1984
assign 1 1038 1985
new 0 1038 1985
assign 1 1039 1986
new 0 1039 1986
setValue 1 1041 1988
subtractValue 1 1042 1989
assign 1 1043 1990
setValue 1 1045 1991
addValue 1 1046 1992
assign 1 1048 1993
greater 1 1048 1998
capacitySet 1 1049 1999
assign 1 1082 2004
greater 1 1082 2009
setValue 1 1086 2010
return 1 1088 2012
assign 1 1093 2018
sizeGet 0 1093 2018
assign 1 1093 2019
substring 2 1093 2019
return 1 1093 2020
assign 1 1097 2027
subtract 1 1097 2027
assign 1 1097 2028
new 1 1097 2028
assign 1 1097 2029
new 0 1097 2029
assign 1 1097 2030
copyValue 4 1097 2030
return 1 1097 2031
output 0 1191 2047
assign 1 1195 2052
new 1 1195 2052
return 1 1195 2053
assign 1 1199 2057
new 1 1199 2057
return 1 1199 2058
assign 1 1203 2062
new 1 1203 2062
return 1 1203 2063
assign 1 1207 2067
new 1 1207 2067
return 1 1207 2068
assign 1 1211 2072
new 1 1211 2072
return 1 1211 2073
assign 1 1215 2077
new 1 1215 2077
return 1 1215 2078
return 1 1219 2081
assign 1 1223 2088
undef 1 1223 2093
new 0 1224 2094
assign 1 1226 2097
sizeGet 0 1226 2097
assign 1 1226 2098
new 0 1226 2098
assign 1 1226 2099
add 1 1226 2099
new 1 1226 2100
addValue 1 1227 2101
assign 1 1232 2107
new 0 1232 2107
return 1 1232 2108
assign 1 1236 2113
new 0 1236 2113
assign 1 1236 2114
strip 1 1236 2114
return 1 1236 2115
assign 1 1240 2124
new 0 1240 2124
assign 1 1241 2125
new 0 1241 2125
assign 1 1242 2126
new 0 1242 2126
assign 1 1243 2127
new 0 1243 2127
assign 1 1243 2128
subtract 1 1243 2128
assign 1 1244 2131
greater 1 1244 2136
getInt 2 1245 2137
getInt 2 1246 2138
setInt 2 1247 2139
setInt 2 1248 2140
incrementValue 0 1249 2141
decrementValue 0 1250 2142
return 1 0 2151
return 1 0 2154
assign 1 0 2157
assign 1 0 2161
return 1 0 2165
return 1 0 2168
assign 1 0 2171
return 1 0 2175
return 1 0 2178
assign 1 0 2181
assign 1 0 2185
return 1 0 2189
return 1 0 2192
assign 1 0 2195
assign 1 0 2199
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1084228149: return bem_print_0();
case -2129983068: return bem_toAny_0();
case 1105152133: return bem_new_0();
case -2064614940: return bem_sizeGetDirect_0();
case -57466887: return bem_toAlphaNum_0();
case 209777034: return bem_lower_0();
case 2071597061: return bem_create_0();
case -732833006: return bem_mbiterGet_0();
case 1029210629: return bem_vstringGet_0();
case -184289747: return bem_isIntegerGet_0();
case 677939759: return bem_siziGetDirect_0();
case 86861939: return bem_clear_0();
case 1819567888: return bem_splitLines_0();
case 1989693945: return bem_toString_0();
case 1960672767: return bem_output_0();
case -1482984555: return bem_sizeGet_0();
case 133946975: return bem_capacityGetDirect_0();
case 162533386: return bem_fieldNamesGet_0();
case -3456603: return bem_extractString_0();
case -923976176: return bem_byteIteratorGet_0();
case 233362262: return bem_many_0();
case 2111759108: return bem_isInteger_0();
case 774106668: return bem_multiByteIteratorGet_0();
case 110382217: return bem_sourceFileNameGet_0();
case 2035109441: return bem_reverseBytes_0();
case 1947092214: return bem_upperValue_0();
case 1019007593: return bem_fieldIteratorGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 2126662131: return bem_isAlphaNumGet_0();
case -667442317: return bem_biterGet_0();
case 714460463: return bem_once_0();
case 1843544518: return bem_serializeContents_0();
case 887739950: return bem_serializeToString_0();
case 1981858046: return bem_chomp_0();
case -1428223948: return bem_lowerValue_0();
case -803403219: return bem_leniGet_0();
case -488731522: return bem_readBuffer_0();
case 526967805: return bem_leniGetDirect_0();
case 1352864992: return bem_capacityGet_0();
case 888041456: return bem_tagGet_0();
case 1986590366: return bem_hashGet_0();
case 317673340: return bem_siziGet_0();
case -798565805: return bem_upper_0();
case 1383646476: return bem_iteratorGet_0();
case -71513042: return bem_vstringSet_0();
case -117507549: return bem_readString_0();
case -86663906: return bem_close_0();
case 444486393: return bem_isAlphaNumericGet_0();
case 1308716433: return bem_open_0();
case -153156208: return bem_serializationIteratorGet_0();
case 234010710: return bem_stringIteratorGet_0();
case 119368349: return bem_strip_0();
case 879975179: return bem_classNameGet_0();
case 2125361805: return bem_isEmptyGet_0();
case -1588532100: return bem_echo_0();
case 1732513565: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1526801060: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1933097408: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case -157571516: return bem_writeTo_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case 1666568298: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -882949881: return bem_leniSetDirect_1(bevd_0);
case -412051597: return bem_add_1(bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -607039709: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 339221255: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case -675432458: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1338129629: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 568704480: return bem_write_1(bevd_0);
case -1291787490: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case -816341029: return bem_sizeSet_1(bevd_0);
case -631516910: return bem_compare_1(bevd_0);
case 488148232: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 619583891: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case -118601605: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -1692460458: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 356715138: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 942011737: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 160303160: return bem_siziSetDirect_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case 388340258: return bem_addValue_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 319606675: return bem_capacitySetDirect_1(bevd_0);
case -1404238804: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case -39314865: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 2043284433: return bem_siziSet_1(bevd_0);
case 924141999: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 1205468526: return bem_codeNew_1(bevd_0);
case -1502620842: return bem_sizeSetDirect_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 297753493: return bem_leniSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2100203789: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -344177241: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 733354209: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1551449746: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1976053530: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 993403052: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2052195376: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -222212636: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 458653951: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2071962608: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1569892301: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 744710390: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1694654885: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1839437174: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
}
