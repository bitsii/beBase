namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_18 = (new BEC_2_4_3_MathInt(43));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_19 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_20 = (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_21 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_22 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_23 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_24 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_25 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_27 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_28 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_29 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_30 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_31 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_32 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_33 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_34 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_35 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_36 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_38 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_40 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_41 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_42 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_43 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_44 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_45 = (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_46 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_47 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_48 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_49 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static new BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 277 */
 else  /* Line: 276 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 278 */ {
return this;
} /* Line: 279 */
} /* Line: 276 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 316 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_1;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_2;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_3;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setHex_2(bevt_4_tmpany_phold, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_tmpany_phold = bem_getCode_2(beva_pos, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_toString_3(bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-1219673974);
if (bevp_leni == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 338 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 340 */
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_4;
bevt_4_tmpany_phold = bevp_sizi.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_5;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_6;
bevl_nsize = bevt_3_tmpany_phold.bem_divide_1(bevt_7_tmpany_phold);
bem_capacitySet_1(bevl_nsize);
} /* Line: 347 */
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_tmpany_phold = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_8_tmpany_phold, bevt_9_tmpany_phold, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(-353411092, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 381 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_8;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_9;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setIntUnchecked_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_10;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpany_phold.bevi_int;
} /* Line: 383 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_11;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_12;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bem_setCodeUnchecked_2(bevt_3_tmpany_phold, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_1_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 395 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_13;
bevt_5_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpany_phold = bevp_size.bem_subtract_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold = bem_substring_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 396 */
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_6_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 399 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_14;
bevt_10_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpany_phold = bevp_size.bem_subtract_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return bevt_7_tmpany_phold;
} /* Line: 400 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_15;
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 413 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 413 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 413 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 413 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 413 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 413 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 414 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 420 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 420 */
bevt_3_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevp_size.bem_subtract_1(bevt_3_tmpany_phold);
bevl_found = bem_find_2(beva_str, bevt_2_tmpany_phold);
if (bevl_found == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 422 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 423 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 429 */ {
bevt_3_tmpany_phold = bem_find_1(beva_str);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 429 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 429 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 430 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isInteger_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 441 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 441 */ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_17;
if (bevl_j.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 443 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_18;
if (bevl_ic.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 443 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_19;
if (bevl_ic.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 443 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 443 */
 else  /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 443 */ {
} /* Line: 443 */
 else  /* Line: 443 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_20;
if (bevl_ic.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 445 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 445 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_21;
if (bevl_ic.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 445 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 445 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 445 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 445 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 446 */
} /* Line: 443 */
bevl_j.bevi_int++;
} /* Line: 441 */
 else  /* Line: 441 */ {
break;
} /* Line: 441 */
} /* Line: 441 */
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 454 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 454 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_22;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_23;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 456 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 456 */
 else  /* Line: 456 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 456 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpany_phold.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 458 */
bevl_j.bevi_int++;
} /* Line: 454 */
 else  /* Line: 454 */ {
break;
} /* Line: 454 */
} /* Line: 454 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lowerValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 469 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 469 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_24;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 471 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_25;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 471 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 471 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 471 */
 else  /* Line: 471 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 471 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpany_phold);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 473 */
bevl_j.bevi_int++;
} /* Line: 469 */
 else  /* Line: 469 */ {
break;
} /* Line: 469 */
} /* Line: 469 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_upperValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bem_split_1(beva_from);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_to, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 493 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_2_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bem_sizeGet_0();
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevt_4_tmpany_phold);
bevl_res.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 497 */
 else  /* Line: 498 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) beva_from.bem_copy_0();
return bevt_5_tmpany_phold;
} /* Line: 499 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 509 */ {
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 509 */ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 511 */ {
bevt_2_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_3_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 514 */
 else  /* Line: 516 */ {
bevt_5_tmpany_phold = bem_sizeGet_0();
bevt_4_tmpany_phold = bem_substring_2(bevl_last, bevt_5_tmpany_phold);
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 517 */
} /* Line: 511 */
 else  /* Line: 509 */ {
break;
} /* Line: 509 */
} /* Line: 509 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_j = bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 528 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 528 */ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 528 */
 else  /* Line: 528 */ {
break;
} /* Line: 528 */
} /* Line: 528 */
bevt_2_tmpany_phold = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_tmpany_phold.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpany_phold.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 538 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 538 */ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpany_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 538 */
 else  /* Line: 538 */ {
break;
} /* Line: 538 */
} /* Line: 538 */
return beva_into;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_hashValue_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getCode_2(beva_pos, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 562 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 562 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 562 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 562 */
 else  /* Line: 562 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 562 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 590 */
 else  /* Line: 598 */ {
return null;
} /* Line: 599 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_27;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 612 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 612 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 612 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 612 */
 else  /* Line: 612 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 612 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 641 */
 else  /* Line: 646 */ {
return null;
} /* Line: 647 */
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_28;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 653 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 653 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 653 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 653 */
 else  /* Line: 653 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 653 */ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 654 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_29;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 659 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 659 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 659 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 659 */
 else  /* Line: 659 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 659 */ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 660 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevl_input = this;
bevt_3_tmpany_phold = bevl_input.bem_sizeGet_0();
bevl_insz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_copy_0();
bevl_output = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_p = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 670 */ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 670 */ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_30;
if (bevl_c.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 672 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_31;
if (bevl_c.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 672 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 672 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 672 */
 else  /* Line: 672 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 672 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 672 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_32;
if (bevl_c.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 672 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_33;
if (bevl_c.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 672 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 672 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 672 */
 else  /* Line: 672 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 672 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 672 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 672 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 672 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 672 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_34;
if (bevl_c.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 672 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_35;
if (bevl_c.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 672 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 672 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 672 */
 else  /* Line: 672 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 672 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 672 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 672 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 672 */ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 674 */
bevl_i.bevi_int++;
} /* Line: 670 */
 else  /* Line: 670 */ {
break;
} /* Line: 670 */
} /* Line: 670 */
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_36;
if (bevp_size.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 682 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 683 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_rfind_1(beva_str);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_reverseBytes_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpany_phold.bem_find_1(bevt_2_tmpany_phold);
if (bevl_rpos == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 790 */ {
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpany_phold;
} /* Line: 792 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_37;
bevt_0_tmpany_phold = bem_find_2(beva_str, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
if (beva_str == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 804 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
if (beva_start == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 804 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 804 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 804 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_38;
if (beva_start.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 804 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 804 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 804 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 804 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 804 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 804 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_12_tmpany_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpany_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 804 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 804 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 804 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_39;
if (bevp_size.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 804 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 804 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 804 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_16_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_40;
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 804 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 804 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 804 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 804 */ {
return null;
} /* Line: 805 */
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpany_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_41;
if (bevl_strsize.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 816 */ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 819 */
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 822 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 822 */ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 824 */ {
bevt_24_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_42;
if (bevl_strsize.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 825 */ {
return bevl_current;
} /* Line: 826 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpany_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 832 */ {
return null;
} /* Line: 833 */
bevt_28_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_43;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpany_phold.bevi_int;
while (true)
 /* Line: 836 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 836 */ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 839 */ {
break;
} /* Line: 840 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 843 */
 else  /* Line: 836 */ {
break;
} /* Line: 836 */
} /* Line: 836 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 845 */ {
return bevl_current;
} /* Line: 846 */
} /* Line: 845 */
bevl_current.bevi_int++;
} /* Line: 849 */
 else  /* Line: 822 */ {
break;
} /* Line: 822 */
} /* Line: 822 */
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 859 */ {
if (bevl_i == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 859 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpany_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 862 */
 else  /* Line: 859 */ {
break;
} /* Line: 859 */
} /* Line: 859 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 864 */ {
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 865 */
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lineSplitterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_stri == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 887 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 887 */ {
bevt_2_tmpany_phold = beva_stri.bemd_1(-219683086, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 887 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 887 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 887 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 887 */ {
return null;
} /* Line: 888 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-1227837183);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 892 */ {
bevl_maxsize = bevl_osize;
} /* Line: 893 */
 else  /* Line: 894 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 895 */
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 900 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 900 */ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(443043516, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 903 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 904 */ {
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpany_phold;
} /* Line: 905 */
 else  /* Line: 906 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpany_phold;
} /* Line: 907 */
} /* Line: 904 */
bevl_i.bevi_int++;
} /* Line: 900 */
 else  /* Line: 900 */ {
break;
} /* Line: 900 */
} /* Line: 900 */
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_44;
if (bevl_myret.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 911 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 912 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 913 */
 else  /* Line: 912 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 914 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 915 */
} /* Line: 912 */
} /* Line: 912 */
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 922 */ {
return null;
} /* Line: 922 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_45;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 923 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 924 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 930 */ {
return null;
} /* Line: 930 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_46;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 931 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 932 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_str);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-1219673974);
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpany_phold, bevp_size, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_47;
if (beva_starti.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1011 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1011 */ {
bevt_4_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1011 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1011 */ {
bevt_6_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 1011 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1011 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1011 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1011 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1011 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1011 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1011 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_7_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 1012 */
 else  /* Line: 1013 */ {
if (bevp_leni == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 1016 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 1018 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 1027 */ {
bem_capacitySet_1(bevp_sizi);
} /* Line: 1028 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 1061 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 1065 */
return this;
} /* Line: 1067 */
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sizeGet_0();
bevt_0_tmpany_phold = bem_substring_2(beva_starti, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_snw == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1206 */ {
bem_new_0();
} /* Line: 1207 */
 else  /* Line: 1208 */ {
bevt_2_tmpany_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_48;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_new_1(bevt_1_tmpany_phold);
bem_addValue_1(beva_snw);
} /* Line: 1210 */
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_strip_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_49;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpany_phold);
while (true)
 /* Line: 1227 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1227 */ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1233 */
 else  /* Line: 1227 */ {
break;
} /* Line: 1227 */
} /* Line: 1227 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGetDirect_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGetDirect_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {258, 259, 272, 272, 272, 276, 276, 277, 278, 278, 279, 315, 315, 316, 318, 322, 322, 322, 323, 323, 323, 324, 324, 324, 328, 328, 328, 328, 328, 328, 328, 332, 333, 337, 338, 338, 339, 340, 342, 342, 343, 345, 345, 346, 346, 346, 346, 346, 346, 347, 349, 349, 349, 353, 357, 361, 365, 375, 376, 377, 381, 381, 381, 382, 382, 382, 382, 382, 383, 383, 383, 388, 388, 389, 389, 389, 390, 390, 390, 394, 394, 395, 396, 396, 396, 396, 396, 398, 399, 400, 400, 400, 400, 400, 402, 406, 406, 406, 407, 408, 412, 413, 413, 0, 413, 413, 413, 0, 0, 414, 414, 416, 416, 420, 420, 420, 420, 421, 421, 421, 422, 422, 423, 423, 425, 425, 429, 429, 0, 429, 429, 429, 0, 0, 430, 430, 432, 432, 436, 436, 440, 441, 441, 441, 442, 443, 443, 443, 443, 443, 443, 0, 443, 443, 443, 0, 0, 0, 0, 0, 445, 445, 445, 0, 445, 445, 445, 0, 0, 446, 446, 441, 449, 449, 453, 454, 454, 454, 455, 456, 456, 456, 456, 456, 456, 0, 0, 0, 457, 457, 458, 454, 464, 464, 464, 468, 469, 469, 469, 470, 471, 471, 471, 471, 471, 471, 0, 0, 0, 472, 472, 473, 469, 479, 479, 479, 483, 483, 483, 483, 489, 490, 491, 492, 493, 493, 494, 494, 495, 496, 496, 497, 497, 497, 499, 499, 501, 506, 507, 508, 509, 509, 510, 511, 511, 512, 512, 513, 514, 514, 517, 517, 517, 521, 526, 526, 527, 528, 528, 528, 529, 528, 531, 531, 532, 536, 537, 537, 538, 538, 538, 539, 540, 540, 541, 538, 544, 548, 548, 548, 552, 552, 552, 562, 562, 562, 562, 562, 0, 0, 0, 599, 601, 612, 612, 612, 612, 612, 0, 0, 0, 647, 649, 653, 653, 653, 653, 653, 0, 0, 0, 654, 659, 659, 659, 659, 659, 0, 0, 0, 660, 665, 666, 666, 667, 668, 669, 670, 670, 670, 671, 672, 672, 672, 672, 672, 672, 0, 0, 0, 0, 672, 672, 672, 672, 672, 672, 0, 0, 0, 0, 0, 0, 672, 672, 672, 672, 672, 672, 0, 0, 0, 0, 0, 673, 674, 670, 677, 678, 682, 682, 682, 683, 683, 685, 685, 782, 782, 788, 788, 788, 788, 788, 790, 790, 791, 791, 792, 792, 794, 798, 798, 798, 804, 804, 0, 804, 804, 0, 0, 0, 804, 804, 804, 0, 0, 0, 804, 804, 0, 0, 0, 804, 804, 804, 0, 0, 0, 804, 804, 804, 0, 0, 0, 804, 804, 804, 804, 0, 0, 805, 808, 809, 810, 811, 812, 812, 814, 816, 816, 816, 817, 818, 819, 821, 822, 822, 823, 824, 824, 825, 825, 825, 826, 828, 829, 830, 831, 831, 832, 832, 833, 835, 835, 835, 836, 836, 837, 838, 839, 839, 842, 843, 845, 845, 846, 849, 851, 855, 856, 857, 858, 859, 859, 860, 860, 861, 862, 864, 864, 865, 865, 867, 871, 871, 871, 875, 875, 875, 875, 879, 887, 887, 0, 887, 0, 0, 888, 890, 891, 892, 892, 893, 895, 897, 898, 899, 900, 900, 900, 901, 902, 903, 903, 904, 904, 905, 905, 907, 907, 900, 911, 911, 911, 912, 912, 913, 914, 914, 915, 918, 922, 922, 922, 923, 923, 923, 923, 924, 924, 926, 926, 930, 930, 930, 931, 931, 931, 931, 932, 932, 934, 934, 992, 992, 996, 996, 996, 1000, 1001, 1001, 1001, 1002, 1002, 1002, 1003, 1003, 1003, 1004, 1007, 1007, 1011, 1011, 1011, 0, 1011, 1011, 1011, 0, 1011, 1011, 1011, 0, 0, 0, 0, 1012, 1012, 1012, 1016, 1016, 1017, 1018, 1020, 1021, 1022, 1024, 1025, 1027, 1027, 1028, 1061, 1061, 1065, 1067, 1072, 1072, 1072, 1076, 1076, 1076, 1076, 1076, 1174, 1178, 1178, 1182, 1182, 1186, 1186, 1190, 1190, 1194, 1194, 1198, 1198, 1202, 1206, 1206, 1207, 1209, 1209, 1209, 1209, 1210, 1215, 1215, 1219, 1219, 1219, 1223, 1224, 1225, 1226, 1226, 1227, 1227, 1228, 1229, 1230, 1231, 1232, 1233, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {110, 111, 117, 118, 119, 126, 131, 132, 135, 140, 141, 152, 157, 158, 160, 170, 171, 172, 173, 174, 175, 176, 177, 178, 188, 189, 190, 191, 192, 193, 194, 198, 199, 215, 216, 221, 222, 223, 225, 226, 227, 228, 233, 234, 235, 236, 237, 238, 239, 240, 242, 243, 244, 248, 251, 254, 258, 269, 270, 271, 282, 283, 288, 289, 290, 291, 292, 293, 294, 295, 296, 306, 307, 308, 309, 310, 311, 312, 313, 329, 330, 331, 333, 334, 335, 336, 337, 339, 340, 342, 343, 344, 345, 346, 348, 354, 355, 356, 357, 358, 368, 369, 374, 375, 378, 379, 384, 385, 388, 392, 393, 395, 396, 407, 412, 413, 414, 416, 417, 418, 419, 424, 425, 426, 428, 429, 438, 443, 444, 447, 448, 453, 454, 457, 461, 462, 464, 465, 469, 470, 490, 491, 494, 499, 500, 501, 502, 507, 508, 509, 514, 515, 518, 519, 524, 525, 528, 532, 535, 539, 544, 545, 550, 551, 554, 555, 560, 561, 564, 568, 569, 572, 578, 579, 591, 592, 595, 600, 601, 602, 603, 608, 609, 610, 615, 616, 619, 623, 626, 627, 628, 630, 641, 642, 643, 655, 656, 659, 664, 665, 666, 667, 672, 673, 674, 679, 680, 683, 687, 690, 691, 692, 694, 705, 706, 707, 713, 714, 715, 716, 728, 729, 730, 731, 732, 737, 738, 739, 740, 741, 742, 743, 744, 745, 748, 749, 751, 763, 764, 765, 768, 773, 774, 775, 780, 781, 782, 783, 784, 785, 788, 789, 790, 797, 807, 808, 809, 810, 813, 818, 819, 820, 826, 827, 828, 836, 837, 838, 839, 842, 847, 848, 849, 850, 851, 852, 858, 863, 864, 865, 870, 871, 872, 879, 880, 885, 886, 891, 892, 895, 899, 909, 911, 918, 919, 924, 925, 930, 931, 934, 938, 945, 947, 954, 955, 960, 961, 966, 967, 970, 974, 977, 986, 987, 992, 993, 998, 999, 1002, 1006, 1009, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1046, 1051, 1052, 1053, 1054, 1059, 1060, 1061, 1066, 1067, 1070, 1074, 1077, 1080, 1081, 1086, 1087, 1088, 1093, 1094, 1097, 1101, 1104, 1107, 1111, 1114, 1115, 1120, 1121, 1122, 1127, 1128, 1131, 1135, 1138, 1141, 1145, 1146, 1148, 1154, 1155, 1162, 1163, 1168, 1169, 1170, 1172, 1173, 1191, 1192, 1203, 1204, 1205, 1206, 1207, 1208, 1213, 1214, 1215, 1216, 1217, 1219, 1224, 1225, 1226, 1270, 1275, 1276, 1279, 1284, 1285, 1288, 1292, 1295, 1296, 1301, 1302, 1305, 1309, 1312, 1317, 1318, 1321, 1325, 1328, 1329, 1334, 1335, 1338, 1342, 1345, 1346, 1351, 1352, 1355, 1359, 1362, 1363, 1364, 1369, 1370, 1373, 1377, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1392, 1393, 1394, 1395, 1397, 1400, 1405, 1406, 1407, 1412, 1413, 1414, 1419, 1420, 1422, 1423, 1424, 1425, 1426, 1427, 1432, 1433, 1435, 1436, 1437, 1440, 1445, 1446, 1447, 1448, 1453, 1456, 1457, 1463, 1468, 1469, 1472, 1478, 1489, 1490, 1491, 1492, 1495, 1500, 1501, 1502, 1503, 1504, 1510, 1515, 1516, 1517, 1519, 1524, 1525, 1526, 1532, 1533, 1534, 1535, 1538, 1561, 1566, 1567, 1570, 1572, 1575, 1579, 1581, 1582, 1583, 1588, 1589, 1592, 1594, 1595, 1596, 1597, 1600, 1605, 1606, 1607, 1608, 1613, 1614, 1619, 1620, 1621, 1624, 1625, 1628, 1634, 1635, 1640, 1641, 1646, 1647, 1650, 1655, 1656, 1660, 1669, 1674, 1675, 1677, 1678, 1679, 1684, 1685, 1686, 1688, 1689, 1698, 1703, 1704, 1706, 1707, 1708, 1713, 1714, 1715, 1717, 1718, 1732, 1733, 1738, 1739, 1744, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1765, 1769, 1770, 1787, 1788, 1793, 1794, 1797, 1798, 1803, 1804, 1807, 1808, 1813, 1814, 1817, 1821, 1824, 1828, 1829, 1830, 1833, 1838, 1839, 1840, 1842, 1843, 1844, 1845, 1846, 1847, 1852, 1853, 1858, 1863, 1864, 1866, 1872, 1873, 1874, 1881, 1882, 1883, 1884, 1885, 1901, 1906, 1907, 1911, 1912, 1916, 1917, 1921, 1922, 1926, 1927, 1931, 1932, 1935, 1942, 1947, 1948, 1951, 1952, 1953, 1954, 1955, 1961, 1962, 1967, 1968, 1969, 1978, 1979, 1980, 1981, 1982, 1985, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 2005, 2008, 2011, 2015, 2019, 2022, 2025, 2029, 2032, 2035, 2039, 2043, 2046, 2049, 2053};
/* BEGIN LINEINFO 
assign 1 258 110
new 0 258 110
capacitySet 1 259 111
assign 1 272 117
new 0 272 117
assign 1 272 118
once 0 272 118
new 1 272 119
assign 1 276 126
undef 1 276 131
assign 1 277 132
new 0 277 132
assign 1 278 135
equals 1 278 140
return 1 279 141
assign 1 315 152
greater 1 315 157
setValue 1 316 158
setValue 1 318 160
assign 1 322 170
new 0 322 170
assign 1 322 171
once 0 322 171
new 1 322 172
assign 1 323 173
new 0 323 173
assign 1 323 174
once 0 323 174
setValue 1 323 175
assign 1 324 176
new 0 324 176
assign 1 324 177
once 0 324 177
setHex 2 324 178
assign 1 328 188
new 0 328 188
assign 1 328 189
getCode 2 328 189
assign 1 328 190
new 0 328 190
assign 1 328 191
new 0 328 191
assign 1 328 192
new 0 328 192
assign 1 328 193
toString 3 328 193
return 1 328 194
assign 1 332 198
hexNew 1 332 198
setCode 2 333 199
assign 1 337 215
toString 0 337 215
assign 1 338 216
undef 1 338 221
assign 1 339 222
new 0 339 222
assign 1 340 223
new 0 340 223
assign 1 342 225
sizeGet 0 342 225
setValue 1 342 226
addValue 1 343 227
assign 1 345 228
lesser 1 345 233
assign 1 346 234
new 0 346 234
assign 1 346 235
add 1 346 235
assign 1 346 236
new 0 346 236
assign 1 346 237
multiply 1 346 237
assign 1 346 238
new 0 346 238
assign 1 346 239
divide 1 346 239
capacitySet 1 347 240
assign 1 349 242
new 0 349 242
assign 1 349 243
sizeGet 0 349 243
copyValue 4 349 244
return 1 353 248
return 1 357 251
addValue 1 361 254
write 1 365 258
assign 1 375 269
copy 0 375 269
clear 0 376 270
return 1 377 271
assign 1 381 282
new 0 381 282
assign 1 381 283
greater 1 381 288
assign 1 382 289
new 0 382 289
assign 1 382 290
once 0 382 290
assign 1 382 291
new 0 382 291
assign 1 382 292
once 0 382 292
setIntUnchecked 2 382 293
assign 1 383 294
new 0 383 294
assign 1 383 295
once 0 383 295
setValue 1 383 296
assign 1 388 306
new 0 388 306
new 1 388 307
assign 1 389 308
new 0 389 308
assign 1 389 309
once 0 389 309
setValue 1 389 310
assign 1 390 311
new 0 390 311
assign 1 390 312
once 0 390 312
setCodeUnchecked 2 390 313
assign 1 394 329
new 0 394 329
assign 1 394 330
newlineGet 0 394 330
assign 1 395 331
ends 1 395 331
assign 1 396 333
new 0 396 333
assign 1 396 334
sizeGet 0 396 334
assign 1 396 335
subtract 1 396 335
assign 1 396 336
substring 2 396 336
return 1 396 337
assign 1 398 339
new 0 398 339
assign 1 399 340
ends 1 399 340
assign 1 400 342
new 0 400 342
assign 1 400 343
sizeGet 0 400 343
assign 1 400 344
subtract 1 400 344
assign 1 400 345
substring 2 400 345
return 1 400 346
return 1 402 348
assign 1 406 354
new 0 406 354
assign 1 406 355
add 1 406 355
assign 1 406 356
new 1 406 356
addValue 1 407 357
return 1 408 358
assign 1 412 368
find 1 412 368
assign 1 413 369
undef 1 413 374
assign 1 0 375
assign 1 413 378
new 0 413 378
assign 1 413 379
notEquals 1 413 384
assign 1 0 385
assign 1 0 388
assign 1 414 392
new 0 414 392
return 1 414 393
assign 1 416 395
new 0 416 395
return 1 416 396
assign 1 420 407
undef 1 420 412
assign 1 420 413
new 0 420 413
return 1 420 414
assign 1 421 416
sizeGet 0 421 416
assign 1 421 417
subtract 1 421 417
assign 1 421 418
find 2 421 418
assign 1 422 419
undef 1 422 424
assign 1 423 425
new 0 423 425
return 1 423 426
assign 1 425 428
new 0 425 428
return 1 425 429
assign 1 429 438
undef 1 429 443
assign 1 0 444
assign 1 429 447
find 1 429 447
assign 1 429 448
undef 1 429 453
assign 1 0 454
assign 1 0 457
assign 1 430 461
new 0 430 461
return 1 430 462
assign 1 432 464
new 0 432 464
return 1 432 465
assign 1 436 469
isInteger 0 436 469
return 1 436 470
assign 1 440 490
new 0 440 490
assign 1 441 491
new 0 441 491
assign 1 441 494
lesser 1 441 499
getInt 2 442 500
assign 1 443 501
new 0 443 501
assign 1 443 502
equals 1 443 507
assign 1 443 508
new 0 443 508
assign 1 443 509
equals 1 443 514
assign 1 0 515
assign 1 443 518
new 0 443 518
assign 1 443 519
equals 1 443 524
assign 1 0 525
assign 1 0 528
assign 1 0 532
assign 1 0 535
assign 1 0 539
assign 1 445 544
new 0 445 544
assign 1 445 545
greater 1 445 550
assign 1 0 551
assign 1 445 554
new 0 445 554
assign 1 445 555
lesser 1 445 560
assign 1 0 561
assign 1 0 564
assign 1 446 568
new 0 446 568
return 1 446 569
incrementValue 0 441 572
assign 1 449 578
new 0 449 578
return 1 449 579
assign 1 453 591
new 0 453 591
assign 1 454 592
new 0 454 592
assign 1 454 595
lesser 1 454 600
getInt 2 455 601
assign 1 456 602
new 0 456 602
assign 1 456 603
greater 1 456 608
assign 1 456 609
new 0 456 609
assign 1 456 610
lesser 1 456 615
assign 1 0 616
assign 1 0 619
assign 1 0 623
assign 1 457 626
new 0 457 626
addValue 1 457 627
setIntUnchecked 2 458 628
incrementValue 0 454 630
assign 1 464 641
copy 0 464 641
assign 1 464 642
lowerValue 0 464 642
return 1 464 643
assign 1 468 655
new 0 468 655
assign 1 469 656
new 0 469 656
assign 1 469 659
lesser 1 469 664
getInt 2 470 665
assign 1 471 666
new 0 471 666
assign 1 471 667
greater 1 471 672
assign 1 471 673
new 0 471 673
assign 1 471 674
lesser 1 471 679
assign 1 0 680
assign 1 0 683
assign 1 0 687
assign 1 472 690
new 0 472 690
subtractValue 1 472 691
setIntUnchecked 2 473 692
incrementValue 0 469 694
assign 1 479 705
copy 0 479 705
assign 1 479 706
upperValue 0 479 706
return 1 479 707
assign 1 483 713
new 0 483 713
assign 1 483 714
split 1 483 714
assign 1 483 715
join 2 483 715
return 1 483 716
assign 1 489 728
new 0 489 728
assign 1 490 729
new 0 490 729
assign 1 491 730
new 0 491 730
assign 1 492 731
find 2 492 731
assign 1 493 732
def 1 493 737
assign 1 494 738
substring 2 494 738
addValue 1 494 739
addValue 1 495 740
assign 1 496 741
sizeGet 0 496 741
assign 1 496 742
add 1 496 742
assign 1 497 743
sizeGet 0 497 743
assign 1 497 744
substring 2 497 744
addValue 1 497 745
assign 1 499 748
copy 0 499 748
return 1 499 749
return 1 501 751
assign 1 506 763
new 0 506 763
assign 1 507 764
new 0 507 764
assign 1 508 765
new 0 508 765
assign 1 509 768
def 1 509 773
assign 1 510 774
find 2 510 774
assign 1 511 775
def 1 511 780
assign 1 512 781
substring 2 512 781
addValue 1 512 782
addValue 1 513 783
assign 1 514 784
sizeGet 0 514 784
assign 1 514 785
add 1 514 785
assign 1 517 788
sizeGet 0 517 788
assign 1 517 789
substring 2 517 789
addValue 1 517 790
return 1 521 797
assign 1 526 807
new 0 526 807
assign 1 526 808
new 1 526 808
assign 1 527 809
mbiterGet 0 527 809
assign 1 528 810
new 0 528 810
assign 1 528 813
lesser 1 528 818
next 1 529 819
incrementValue 0 528 820
assign 1 531 826
next 1 531 826
assign 1 531 827
toString 0 531 827
return 1 532 828
assign 1 536 836
new 0 536 836
assign 1 537 837
new 0 537 837
setValue 1 537 838
assign 1 538 839
new 0 538 839
assign 1 538 842
lesser 1 538 847
getInt 2 539 848
assign 1 540 849
new 0 540 849
multiplyValue 1 540 850
addValue 1 541 851
incrementValue 0 538 852
return 1 544 858
assign 1 548 863
new 0 548 863
assign 1 548 864
hashValue 1 548 864
return 1 548 865
assign 1 552 870
new 0 552 870
assign 1 552 871
getCode 2 552 871
return 1 552 872
assign 1 562 879
new 0 562 879
assign 1 562 880
greaterEquals 1 562 885
assign 1 562 886
greater 1 562 891
assign 1 0 892
assign 1 0 895
assign 1 0 899
return 1 599 909
return 1 601 911
assign 1 612 918
new 0 612 918
assign 1 612 919
greaterEquals 1 612 924
assign 1 612 925
greater 1 612 930
assign 1 0 931
assign 1 0 934
assign 1 0 938
return 1 647 945
return 1 649 947
assign 1 653 954
new 0 653 954
assign 1 653 955
greaterEquals 1 653 960
assign 1 653 961
greater 1 653 966
assign 1 0 967
assign 1 0 970
assign 1 0 974
setIntUnchecked 2 654 977
assign 1 659 986
new 0 659 986
assign 1 659 987
greaterEquals 1 659 992
assign 1 659 993
greater 1 659 998
assign 1 0 999
assign 1 0 1002
assign 1 0 1006
setCodeUnchecked 2 660 1009
assign 1 665 1037
assign 1 666 1038
sizeGet 0 666 1038
assign 1 666 1039
copy 0 666 1039
assign 1 667 1040
new 1 667 1040
assign 1 668 1041
new 0 668 1041
assign 1 669 1042
new 0 669 1042
assign 1 670 1043
new 0 670 1043
assign 1 670 1046
lesser 1 670 1051
getInt 2 671 1052
assign 1 672 1053
new 0 672 1053
assign 1 672 1054
greater 1 672 1059
assign 1 672 1060
new 0 672 1060
assign 1 672 1061
lesser 1 672 1066
assign 1 0 1067
assign 1 0 1070
assign 1 0 1074
assign 1 0 1077
assign 1 672 1080
new 0 672 1080
assign 1 672 1081
greater 1 672 1086
assign 1 672 1087
new 0 672 1087
assign 1 672 1088
lesser 1 672 1093
assign 1 0 1094
assign 1 0 1097
assign 1 0 1101
assign 1 0 1104
assign 1 0 1107
assign 1 0 1111
assign 1 672 1114
new 0 672 1114
assign 1 672 1115
greater 1 672 1120
assign 1 672 1121
new 0 672 1121
assign 1 672 1122
lesser 1 672 1127
assign 1 0 1128
assign 1 0 1131
assign 1 0 1135
assign 1 0 1138
assign 1 0 1141
setIntUnchecked 2 673 1145
incrementValue 0 674 1146
incrementValue 0 670 1148
sizeSet 1 677 1154
return 1 678 1155
assign 1 682 1162
new 0 682 1162
assign 1 682 1163
lesserEquals 1 682 1168
assign 1 683 1169
new 0 683 1169
return 1 683 1170
assign 1 685 1172
new 0 685 1172
return 1 685 1173
assign 1 782 1191
rfind 1 782 1191
return 1 782 1192
assign 1 788 1203
copy 0 788 1203
assign 1 788 1204
reverseBytes 0 788 1204
assign 1 788 1205
copy 0 788 1205
assign 1 788 1206
reverseBytes 0 788 1206
assign 1 788 1207
find 1 788 1207
assign 1 790 1208
def 1 790 1213
assign 1 791 1214
sizeGet 0 791 1214
addValue 1 791 1215
assign 1 792 1216
subtract 1 792 1216
return 1 792 1217
return 1 794 1219
assign 1 798 1224
new 0 798 1224
assign 1 798 1225
find 2 798 1225
return 1 798 1226
assign 1 804 1270
undef 1 804 1275
assign 1 0 1276
assign 1 804 1279
undef 1 804 1284
assign 1 0 1285
assign 1 0 1288
assign 1 0 1292
assign 1 804 1295
new 0 804 1295
assign 1 804 1296
lesser 1 804 1301
assign 1 0 1302
assign 1 0 1305
assign 1 0 1309
assign 1 804 1312
greaterEquals 1 804 1317
assign 1 0 1318
assign 1 0 1321
assign 1 0 1325
assign 1 804 1328
sizeGet 0 804 1328
assign 1 804 1329
greater 1 804 1334
assign 1 0 1335
assign 1 0 1338
assign 1 0 1342
assign 1 804 1345
new 0 804 1345
assign 1 804 1346
equals 1 804 1351
assign 1 0 1352
assign 1 0 1355
assign 1 0 1359
assign 1 804 1362
sizeGet 0 804 1362
assign 1 804 1363
new 0 804 1363
assign 1 804 1364
equals 1 804 1369
assign 1 0 1370
assign 1 0 1373
return 1 805 1377
assign 1 808 1379
assign 1 809 1380
copy 0 809 1380
assign 1 810 1381
new 0 810 1381
assign 1 811 1382
new 0 811 1382
assign 1 812 1383
new 0 812 1383
getInt 2 812 1384
assign 1 814 1385
sizeGet 0 814 1385
assign 1 816 1386
new 0 816 1386
assign 1 816 1387
greater 1 816 1392
assign 1 817 1393
new 0 817 1393
assign 1 818 1394
new 0 818 1394
assign 1 819 1395
new 0 819 1395
assign 1 821 1397
new 0 821 1397
assign 1 822 1400
lesser 1 822 1405
getInt 2 823 1406
assign 1 824 1407
equals 1 824 1412
assign 1 825 1413
new 0 825 1413
assign 1 825 1414
equals 1 825 1419
return 1 826 1420
setValue 1 828 1422
incrementValue 0 829 1423
setValue 1 830 1424
assign 1 831 1425
sizeGet 0 831 1425
addValue 1 831 1426
assign 1 832 1427
greater 1 832 1432
return 1 833 1433
assign 1 835 1435
new 0 835 1435
assign 1 835 1436
once 0 835 1436
setValue 1 835 1437
assign 1 836 1440
lesser 1 836 1445
getInt 2 837 1446
getInt 2 838 1447
assign 1 839 1448
notEquals 1 839 1453
incrementValue 0 842 1456
incrementValue 0 843 1457
assign 1 845 1463
equals 1 845 1468
return 1 846 1469
incrementValue 0 849 1472
return 1 851 1478
assign 1 855 1489
new 0 855 1489
assign 1 856 1490
new 0 856 1490
assign 1 857 1491
find 2 857 1491
assign 1 858 1492
sizeGet 0 858 1492
assign 1 859 1495
def 1 859 1500
assign 1 860 1501
substring 2 860 1501
addValue 1 860 1502
assign 1 861 1503
add 1 861 1503
assign 1 862 1504
find 2 862 1504
assign 1 864 1510
lesser 1 864 1515
assign 1 865 1516
substring 2 865 1516
addValue 1 865 1517
return 1 867 1519
assign 1 871 1524
new 0 871 1524
assign 1 871 1525
join 2 871 1525
return 1 871 1526
assign 1 875 1532
new 0 875 1532
assign 1 875 1533
lineSplitterGet 0 875 1533
assign 1 875 1534
tokenize 1 875 1534
return 1 875 1535
return 1 879 1538
assign 1 887 1561
undef 1 887 1566
assign 1 0 1567
assign 1 887 1570
otherType 1 887 1570
assign 1 0 1572
assign 1 0 1575
return 1 888 1579
assign 1 890 1581
assign 1 891 1582
sizeGet 0 891 1582
assign 1 892 1583
greater 1 892 1588
assign 1 893 1589
assign 1 895 1592
assign 1 897 1594
new 0 897 1594
assign 1 898 1595
new 0 898 1595
assign 1 899 1596
new 0 899 1596
assign 1 900 1597
new 0 900 1597
assign 1 900 1600
lesser 1 900 1605
getCode 2 901 1606
getCode 2 902 1607
assign 1 903 1608
notEquals 1 903 1613
assign 1 904 1614
greater 1 904 1619
assign 1 905 1620
new 0 905 1620
return 1 905 1621
assign 1 907 1624
new 0 907 1624
return 1 907 1625
incrementValue 0 900 1628
assign 1 911 1634
new 0 911 1634
assign 1 911 1635
equals 1 911 1640
assign 1 912 1641
greater 1 912 1646
assign 1 913 1647
new 0 913 1647
assign 1 914 1650
greater 1 914 1655
assign 1 915 1656
new 0 915 1656
return 1 918 1660
assign 1 922 1669
undef 1 922 1674
return 1 922 1675
assign 1 923 1677
compare 1 923 1677
assign 1 923 1678
new 0 923 1678
assign 1 923 1679
equals 1 923 1684
assign 1 924 1685
new 0 924 1685
return 1 924 1686
assign 1 926 1688
new 0 926 1688
return 1 926 1689
assign 1 930 1698
undef 1 930 1703
return 1 930 1704
assign 1 931 1706
compare 1 931 1706
assign 1 931 1707
new 0 931 1707
assign 1 931 1708
equals 1 931 1713
assign 1 932 1714
new 0 932 1714
return 1 932 1715
assign 1 934 1717
new 0 934 1717
return 1 934 1718
assign 1 992 1732
new 0 992 1732
return 1 992 1733
assign 1 996 1738
equals 1 996 1738
assign 1 996 1739
not 0 996 1744
return 1 996 1744
assign 1 1000 1755
toString 0 1000 1755
assign 1 1001 1756
sizeGet 0 1001 1756
assign 1 1001 1757
add 1 1001 1757
assign 1 1001 1758
new 1 1001 1758
assign 1 1002 1759
new 0 1002 1759
assign 1 1002 1760
new 0 1002 1760
copyValue 4 1002 1761
assign 1 1003 1762
new 0 1003 1762
assign 1 1003 1763
sizeGet 0 1003 1763
copyValue 4 1003 1764
return 1 1004 1765
assign 1 1007 1769
new 0 1007 1769
return 1 1007 1770
assign 1 1011 1787
new 0 1011 1787
assign 1 1011 1788
lesser 1 1011 1793
assign 1 0 1794
assign 1 1011 1797
sizeGet 0 1011 1797
assign 1 1011 1798
greater 1 1011 1803
assign 1 0 1804
assign 1 1011 1807
sizeGet 0 1011 1807
assign 1 1011 1808
greater 1 1011 1813
assign 1 0 1814
assign 1 0 1817
assign 1 0 1821
assign 1 0 1824
assign 1 1012 1828
new 0 1012 1828
assign 1 1012 1829
new 1 1012 1829
throw 1 1012 1830
assign 1 1016 1833
undef 1 1016 1838
assign 1 1017 1839
new 0 1017 1839
assign 1 1018 1840
new 0 1018 1840
setValue 1 1020 1842
subtractValue 1 1021 1843
assign 1 1022 1844
setValue 1 1024 1845
addValue 1 1025 1846
assign 1 1027 1847
greater 1 1027 1852
capacitySet 1 1028 1853
assign 1 1061 1858
greater 1 1061 1863
setValue 1 1065 1864
return 1 1067 1866
assign 1 1072 1872
sizeGet 0 1072 1872
assign 1 1072 1873
substring 2 1072 1873
return 1 1072 1874
assign 1 1076 1881
subtract 1 1076 1881
assign 1 1076 1882
new 1 1076 1882
assign 1 1076 1883
new 0 1076 1883
assign 1 1076 1884
copyValue 4 1076 1884
return 1 1076 1885
output 0 1174 1901
assign 1 1178 1906
new 1 1178 1906
return 1 1178 1907
assign 1 1182 1911
new 1 1182 1911
return 1 1182 1912
assign 1 1186 1916
new 1 1186 1916
return 1 1186 1917
assign 1 1190 1921
new 1 1190 1921
return 1 1190 1922
assign 1 1194 1926
new 1 1194 1926
return 1 1194 1927
assign 1 1198 1931
new 1 1198 1931
return 1 1198 1932
return 1 1202 1935
assign 1 1206 1942
undef 1 1206 1947
new 0 1207 1948
assign 1 1209 1951
sizeGet 0 1209 1951
assign 1 1209 1952
new 0 1209 1952
assign 1 1209 1953
add 1 1209 1953
new 1 1209 1954
addValue 1 1210 1955
assign 1 1215 1961
new 0 1215 1961
return 1 1215 1962
assign 1 1219 1967
new 0 1219 1967
assign 1 1219 1968
strip 1 1219 1968
return 1 1219 1969
assign 1 1223 1978
new 0 1223 1978
assign 1 1224 1979
new 0 1224 1979
assign 1 1225 1980
new 0 1225 1980
assign 1 1226 1981
new 0 1226 1981
assign 1 1226 1982
subtract 1 1226 1982
assign 1 1227 1985
greater 1 1227 1990
getInt 2 1228 1991
getInt 2 1229 1992
setInt 2 1230 1993
setInt 2 1231 1994
incrementValue 0 1232 1995
decrementValue 0 1233 1996
return 1 0 2005
return 1 0 2008
assign 1 0 2011
assign 1 0 2015
return 1 0 2019
return 1 0 2022
assign 1 0 2025
return 1 0 2029
return 1 0 2032
assign 1 0 2035
assign 1 0 2039
return 1 0 2043
return 1 0 2046
assign 1 0 2049
assign 1 0 2053
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2119098947: return bem_serializeContents_0();
case -2064366569: return bem_upper_0();
case 1698291945: return bem_leniGetDirect_0();
case 222096027: return bem_classNameGet_0();
case 579066322: return bem_readBuffer_0();
case 728140695: return bem_biterGet_0();
case -14767827: return bem_serializeToString_0();
case -876448623: return bem_siziGetDirect_0();
case -1141049131: return bem_iteratorGet_0();
case -1121300979: return bem_fieldNamesGet_0();
case 1421448903: return bem_siziGet_0();
case 1115258825: return bem_create_0();
case -2016997496: return bem_print_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case -1177532782: return bem_stringIteratorGet_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 2124144075: return bem_vstringGet_0();
case 545921054: return bem_output_0();
case 1975221864: return bem_lowerValue_0();
case -1304621804: return bem_splitLines_0();
case 434654272: return bem_hashGet_0();
case 306116222: return bem_echo_0();
case -1946521975: return bem_chomp_0();
case 447973789: return bem_byteIteratorGet_0();
case 332837428: return bem_lower_0();
case -31410563: return bem_once_0();
case 216845033: return bem_new_0();
case -1104161947: return bem_sizeGetDirect_0();
case 1999868679: return bem_fieldIteratorGet_0();
case -1365182072: return bem_sourceFileNameGet_0();
case -1826124256: return bem_mbiterGet_0();
case -1015350887: return bem_strip_0();
case -1194274080: return bem_toAny_0();
case -1304542945: return bem_toAlphaNum_0();
case 1801694719: return bem_copy_0();
case -354337801: return bem_isIntegerGet_0();
case 2024915074: return bem_capacityGetDirect_0();
case 1995516991: return bem_capacityGet_0();
case -1656139433: return bem_clear_0();
case -1791317618: return bem_extractString_0();
case 1308379424: return bem_readString_0();
case 1263218482: return bem_leniGet_0();
case -432532530: return bem_vstringSet_0();
case 1434692157: return bem_reverseBytes_0();
case 203911372: return bem_upperValue_0();
case 1366617398: return bem_tagGet_0();
case 2071029114: return bem_multiByteIteratorGet_0();
case -647640823: return bem_close_0();
case -1227837183: return bem_sizeGet_0();
case -542459133: return bem_isInteger_0();
case -1219673974: return bem_toString_0();
case 1491075741: return bem_open_0();
case 1747475389: return bem_many_0();
case -580037254: return bem_isEmptyGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -682112594: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -240164168: return bem_undefined_1(bevd_0);
case -382211081: return bem_writeTo_1(bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case 1509348260: return bem_leniSetDirect_1(bevd_0);
case -934459345: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 737405182: return bem_sizeSet_1(bevd_0);
case 1421428528: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case 393689134: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case -1570236445: return bem_add_1(bevd_0);
case 1524034142: return bem_capacitySetDirect_1(bevd_0);
case -390544863: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1061305728: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case 120401933: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
case -914179160: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case 840500959: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1181935518: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case 2098161987: return bem_addValue_1(bevd_0);
case 1684084096: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case 1161962149: return bem_compare_1(bevd_0);
case -1246021533: return bem_equals_1(bevd_0);
case 308676664: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1753559721: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 513731144: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case -1967937373: return bem_siziSet_1(bevd_0);
case -607725059: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case -88480951: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case -2031564793: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 2065145284: return bem_codeNew_1(bevd_0);
case 2090606142: return bem_leniSet_1(bevd_0);
case -693395719: return bem_siziSetDirect_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case 342478241: return bem_sizeSetDirect_1(bevd_0);
case -353411092: return bem_write_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2008477118: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1490357182: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1368146789: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -122053247: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 721753713: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 629136690: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1976321957: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443043516: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1076093727: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -408605848: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1157752558: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 290993055: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1298133010: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1173014263: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
}
