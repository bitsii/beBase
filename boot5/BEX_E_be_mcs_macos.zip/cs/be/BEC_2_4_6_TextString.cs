namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_18 = (new BEC_2_4_3_MathInt(43));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_19 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_20 = (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_21 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_22 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_23 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_24 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_25 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_27 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_28 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_29 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_30 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_31 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_32 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_33 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_34 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_35 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_36 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_38 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_39 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_40 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_41 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_42 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_43 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_44 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_45 = (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_46 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_47 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_48 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_TextString_bevo_49 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static new BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 252 */ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 253 */
 else  /* Line: 252 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 254 */ {
return this;
} /* Line: 255 */
} /* Line: 252 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 292 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_1;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bem_new_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_2;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_3;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setHex_2(bevt_4_tmpany_phold, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_tmpany_phold = bem_getCode_2(beva_pos, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_toString_3(bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-1918539521);
if (bevp_leni == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 316 */
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_4;
bevt_4_tmpany_phold = bevp_sizi.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_5;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_6;
bevl_nsize = bevt_3_tmpany_phold.bem_divide_1(bevt_7_tmpany_phold);
bem_capacitySet_1(bevl_nsize);
} /* Line: 323 */
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_tmpany_phold = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_8_tmpany_phold, bevt_9_tmpany_phold, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(-215826876, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_8;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_9;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bem_setIntUnchecked_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_10;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpany_phold.bevi_int;
} /* Line: 359 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_11;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_12;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bem_setCodeUnchecked_2(bevt_3_tmpany_phold, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_1_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 371 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_13;
bevt_5_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpany_phold = bevp_size.bem_subtract_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold = bem_substring_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 372 */
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_6_tmpany_phold = bem_ends_1(bevl_nl);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 375 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_14;
bevt_10_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpany_phold = bevp_size.bem_subtract_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return bevt_7_tmpany_phold;
} /* Line: 376 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_15;
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 389 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 389 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 390 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 396 */
bevt_3_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevp_size.bem_subtract_1(bevt_3_tmpany_phold);
bevl_found = bem_find_2(beva_str, bevt_2_tmpany_phold);
if (bevl_found == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 399 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 405 */ {
bevt_3_tmpany_phold = bem_find_1(beva_str);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 405 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 405 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 405 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 405 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 406 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 413 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 413 */ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_17;
if (bevl_j.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_18;
if (bevl_ic.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 415 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_19;
if (bevl_ic.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 415 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 415 */
 else  /* Line: 415 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 415 */ {
} /* Line: 415 */
 else  /* Line: 415 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_20;
if (bevl_ic.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_21;
if (bevl_ic.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 417 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 417 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 418 */
} /* Line: 415 */
bevl_j.bevi_int++;
} /* Line: 413 */
 else  /* Line: 413 */ {
break;
} /* Line: 413 */
} /* Line: 413 */
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 426 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 426 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_22;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 428 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_23;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 428 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 428 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 428 */
 else  /* Line: 428 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 428 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpany_phold.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 430 */
bevl_j.bevi_int++;
} /* Line: 426 */
 else  /* Line: 426 */ {
break;
} /* Line: 426 */
} /* Line: 426 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lowerValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 441 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 441 */ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_24;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 443 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_25;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 443 */
 else  /* Line: 443 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 443 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpany_phold);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 445 */
bevl_j.bevi_int++;
} /* Line: 441 */
 else  /* Line: 441 */ {
break;
} /* Line: 441 */
} /* Line: 441 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_upperValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bem_split_1(beva_from);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_to, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 465 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_2_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bem_sizeGet_0();
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevt_4_tmpany_phold);
bevl_res.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 469 */
 else  /* Line: 470 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) beva_from.bem_copy_0();
return bevt_5_tmpany_phold;
} /* Line: 471 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 481 */ {
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 481 */ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevt_2_tmpany_phold = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_3_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 486 */
 else  /* Line: 488 */ {
bevt_5_tmpany_phold = bem_sizeGet_0();
bevt_4_tmpany_phold = bem_substring_2(bevl_last, bevt_5_tmpany_phold);
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 489 */
} /* Line: 483 */
 else  /* Line: 481 */ {
break;
} /* Line: 481 */
} /* Line: 481 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_j = bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 500 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 500 */ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 500 */
 else  /* Line: 500 */ {
break;
} /* Line: 500 */
} /* Line: 500 */
bevt_2_tmpany_phold = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_tmpany_phold.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpany_phold.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 510 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 510 */ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpany_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 510 */
 else  /* Line: 510 */ {
break;
} /* Line: 510 */
} /* Line: 510 */
return beva_into;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_hashValue_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getCode_2(beva_pos, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 534 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 534 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 534 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 534 */
 else  /* Line: 534 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 534 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 562 */
 else  /* Line: 570 */ {
return null;
} /* Line: 571 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_27;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 584 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 584 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 584 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 584 */
 else  /* Line: 584 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 584 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 613 */
 else  /* Line: 618 */ {
return null;
} /* Line: 619 */
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_28;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 625 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 625 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 625 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 625 */
 else  /* Line: 625 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 625 */ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 626 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_29;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 631 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 631 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 631 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 631 */
 else  /* Line: 631 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 631 */ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 632 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevl_input = this;
bevt_3_tmpany_phold = bevl_input.bem_sizeGet_0();
bevl_insz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_copy_0();
bevl_output = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_p = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 642 */ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 642 */ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_30;
if (bevl_c.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevt_8_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_31;
if (bevl_c.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 644 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 644 */
 else  /* Line: 644 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 644 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 644 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_32;
if (bevl_c.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_33;
if (bevl_c.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 644 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 644 */
 else  /* Line: 644 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 644 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 644 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 644 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 644 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 644 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_34;
if (bevl_c.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_35;
if (bevl_c.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 644 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 644 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 644 */
 else  /* Line: 644 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 644 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 644 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 644 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 644 */ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 646 */
bevl_i.bevi_int++;
} /* Line: 642 */
 else  /* Line: 642 */ {
break;
} /* Line: 642 */
} /* Line: 642 */
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_36;
if (bevp_size.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 654 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 655 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_rfind_1(beva_str);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_reverseBytes_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpany_phold.bem_find_1(bevt_2_tmpany_phold);
if (bevl_rpos == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 762 */ {
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpany_phold;
} /* Line: 764 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_37;
bevt_0_tmpany_phold = bem_find_2(beva_str, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
if (beva_str == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
if (beva_start == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_38;
if (beva_start.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_12_tmpany_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpany_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_14_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_39;
if (bevp_size.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_16_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_40;
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 776 */ {
return null;
} /* Line: 777 */
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpany_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_41;
if (bevl_strsize.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 788 */ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 791 */
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 794 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 794 */ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 796 */ {
bevt_24_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_42;
if (bevl_strsize.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 797 */ {
return bevl_current;
} /* Line: 798 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpany_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 804 */ {
return null;
} /* Line: 805 */
bevt_28_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_43;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpany_phold.bevi_int;
while (true)
 /* Line: 808 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 808 */ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 811 */ {
break;
} /* Line: 812 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 815 */
 else  /* Line: 808 */ {
break;
} /* Line: 808 */
} /* Line: 808 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 817 */ {
return bevl_current;
} /* Line: 818 */
} /* Line: 817 */
bevl_current.bevi_int++;
} /* Line: 821 */
 else  /* Line: 794 */ {
break;
} /* Line: 794 */
} /* Line: 794 */
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 831 */ {
if (bevl_i == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 831 */ {
bevt_1_tmpany_phold = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpany_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 834 */
 else  /* Line: 831 */ {
break;
} /* Line: 831 */
} /* Line: 831 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 836 */ {
bevt_3_tmpany_phold = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 837 */
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lineSplitterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_stri == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 859 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 859 */ {
bevt_2_tmpany_phold = beva_stri.bemd_1(-1434304379, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 859 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 859 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 859 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 859 */ {
return null;
} /* Line: 860 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-918033785);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 864 */ {
bevl_maxsize = bevl_osize;
} /* Line: 865 */
 else  /* Line: 866 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 867 */
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 872 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 872 */ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(1891617533, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 875 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 876 */ {
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpany_phold;
} /* Line: 877 */
 else  /* Line: 878 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpany_phold;
} /* Line: 879 */
} /* Line: 876 */
bevl_i.bevi_int++;
} /* Line: 872 */
 else  /* Line: 872 */ {
break;
} /* Line: 872 */
} /* Line: 872 */
bevt_10_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_44;
if (bevl_myret.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 883 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 884 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 885 */
 else  /* Line: 884 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 886 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 887 */
} /* Line: 884 */
} /* Line: 884 */
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 894 */ {
return null;
} /* Line: 894 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_45;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 895 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 896 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 902 */ {
return null;
} /* Line: 902 */
bevt_2_tmpany_phold = bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_46;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 903 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 904 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_str);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-1918539521);
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpany_phold, bevp_size, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_47;
if (beva_starti.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 980 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 980 */ {
bevt_4_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 980 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 980 */ {
bevt_6_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 980 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 980 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 980 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 980 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 980 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 980 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 980 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_7_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 981 */
 else  /* Line: 982 */ {
if (bevp_leni == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 985 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 987 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 996 */ {
bem_capacitySet_1(bevp_sizi);
} /* Line: 997 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 1030 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 1034 */
return this;
} /* Line: 1036 */
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_sizeGet_0();
bevt_0_tmpany_phold = bem_substring_2(beva_starti, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_snw == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1169 */ {
bem_new_0();
} /* Line: 1170 */
 else  /* Line: 1171 */ {
bevt_2_tmpany_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_48;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bem_new_1(bevt_1_tmpany_phold);
bem_addValue_1(beva_snw);
} /* Line: 1173 */
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_strip_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bece_BEC_2_4_6_TextString_bevo_49;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpany_phold);
while (true)
 /* Line: 1190 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1190 */ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1196 */
 else  /* Line: 1190 */ {
break;
} /* Line: 1190 */
} /* Line: 1190 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGetDirect_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGetDirect_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {234, 235, 248, 248, 248, 252, 252, 253, 254, 254, 255, 291, 291, 292, 294, 298, 298, 298, 299, 299, 299, 300, 300, 300, 304, 304, 304, 304, 304, 304, 304, 308, 309, 313, 314, 314, 315, 316, 318, 318, 319, 321, 321, 322, 322, 322, 322, 322, 322, 323, 325, 325, 325, 329, 333, 337, 341, 351, 352, 353, 357, 357, 357, 358, 358, 358, 358, 358, 359, 359, 359, 364, 364, 365, 365, 365, 366, 366, 366, 370, 370, 371, 372, 372, 372, 372, 372, 374, 375, 376, 376, 376, 376, 376, 378, 382, 382, 382, 383, 384, 388, 389, 389, 0, 389, 389, 389, 0, 0, 390, 390, 392, 392, 396, 396, 396, 396, 397, 397, 397, 398, 398, 399, 399, 401, 401, 405, 405, 0, 405, 405, 405, 0, 0, 406, 406, 408, 408, 412, 413, 413, 413, 414, 415, 415, 415, 415, 415, 415, 0, 415, 415, 415, 0, 0, 0, 0, 0, 417, 417, 417, 0, 417, 417, 417, 0, 0, 418, 418, 413, 421, 421, 425, 426, 426, 426, 427, 428, 428, 428, 428, 428, 428, 0, 0, 0, 429, 429, 430, 426, 436, 436, 436, 440, 441, 441, 441, 442, 443, 443, 443, 443, 443, 443, 0, 0, 0, 444, 444, 445, 441, 451, 451, 451, 455, 455, 455, 455, 461, 462, 463, 464, 465, 465, 466, 466, 467, 468, 468, 469, 469, 469, 471, 471, 473, 478, 479, 480, 481, 481, 482, 483, 483, 484, 484, 485, 486, 486, 489, 489, 489, 493, 498, 498, 499, 500, 500, 500, 501, 500, 503, 503, 504, 508, 509, 509, 510, 510, 510, 511, 512, 512, 513, 510, 516, 520, 520, 520, 524, 524, 524, 534, 534, 534, 534, 534, 0, 0, 0, 571, 573, 584, 584, 584, 584, 584, 0, 0, 0, 619, 621, 625, 625, 625, 625, 625, 0, 0, 0, 626, 631, 631, 631, 631, 631, 0, 0, 0, 632, 637, 638, 638, 639, 640, 641, 642, 642, 642, 643, 644, 644, 644, 644, 644, 644, 0, 0, 0, 0, 644, 644, 644, 644, 644, 644, 0, 0, 0, 0, 0, 0, 644, 644, 644, 644, 644, 644, 0, 0, 0, 0, 0, 645, 646, 642, 649, 650, 654, 654, 654, 655, 655, 657, 657, 754, 754, 760, 760, 760, 760, 760, 762, 762, 763, 763, 764, 764, 766, 770, 770, 770, 776, 776, 0, 776, 776, 0, 0, 0, 776, 776, 776, 0, 0, 0, 776, 776, 0, 0, 0, 776, 776, 776, 0, 0, 0, 776, 776, 776, 0, 0, 0, 776, 776, 776, 776, 0, 0, 777, 780, 781, 782, 783, 784, 784, 786, 788, 788, 788, 789, 790, 791, 793, 794, 794, 795, 796, 796, 797, 797, 797, 798, 800, 801, 802, 803, 803, 804, 804, 805, 807, 807, 807, 808, 808, 809, 810, 811, 811, 814, 815, 817, 817, 818, 821, 823, 827, 828, 829, 830, 831, 831, 832, 832, 833, 834, 836, 836, 837, 837, 839, 843, 843, 843, 847, 847, 847, 847, 851, 859, 859, 0, 859, 0, 0, 860, 862, 863, 864, 864, 865, 867, 869, 870, 871, 872, 872, 872, 873, 874, 875, 875, 876, 876, 877, 877, 879, 879, 872, 883, 883, 883, 884, 884, 885, 886, 886, 887, 890, 894, 894, 894, 895, 895, 895, 895, 896, 896, 898, 898, 902, 902, 902, 903, 903, 903, 903, 904, 904, 906, 906, 961, 961, 965, 965, 965, 969, 970, 970, 970, 971, 971, 971, 972, 972, 972, 973, 976, 976, 980, 980, 980, 0, 980, 980, 980, 0, 980, 980, 980, 0, 0, 0, 0, 981, 981, 981, 985, 985, 986, 987, 989, 990, 991, 993, 994, 996, 996, 997, 1030, 1030, 1034, 1036, 1041, 1041, 1041, 1045, 1045, 1045, 1045, 1045, 1137, 1141, 1141, 1145, 1145, 1149, 1149, 1153, 1153, 1157, 1157, 1161, 1161, 1165, 1169, 1169, 1170, 1172, 1172, 1172, 1172, 1173, 1178, 1178, 1182, 1182, 1182, 1186, 1187, 1188, 1189, 1189, 1190, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {110, 111, 117, 118, 119, 126, 131, 132, 135, 140, 141, 152, 157, 158, 160, 170, 171, 172, 173, 174, 175, 176, 177, 178, 188, 189, 190, 191, 192, 193, 194, 198, 199, 215, 216, 221, 222, 223, 225, 226, 227, 228, 233, 234, 235, 236, 237, 238, 239, 240, 242, 243, 244, 248, 251, 254, 258, 269, 270, 271, 282, 283, 288, 289, 290, 291, 292, 293, 294, 295, 296, 306, 307, 308, 309, 310, 311, 312, 313, 329, 330, 331, 333, 334, 335, 336, 337, 339, 340, 342, 343, 344, 345, 346, 348, 354, 355, 356, 357, 358, 368, 369, 374, 375, 378, 379, 384, 385, 388, 392, 393, 395, 396, 407, 412, 413, 414, 416, 417, 418, 419, 424, 425, 426, 428, 429, 438, 443, 444, 447, 448, 453, 454, 457, 461, 462, 464, 465, 485, 486, 489, 494, 495, 496, 497, 502, 503, 504, 509, 510, 513, 514, 519, 520, 523, 527, 530, 534, 539, 540, 545, 546, 549, 550, 555, 556, 559, 563, 564, 567, 573, 574, 586, 587, 590, 595, 596, 597, 598, 603, 604, 605, 610, 611, 614, 618, 621, 622, 623, 625, 636, 637, 638, 650, 651, 654, 659, 660, 661, 662, 667, 668, 669, 674, 675, 678, 682, 685, 686, 687, 689, 700, 701, 702, 708, 709, 710, 711, 723, 724, 725, 726, 727, 732, 733, 734, 735, 736, 737, 738, 739, 740, 743, 744, 746, 758, 759, 760, 763, 768, 769, 770, 775, 776, 777, 778, 779, 780, 783, 784, 785, 792, 802, 803, 804, 805, 808, 813, 814, 815, 821, 822, 823, 831, 832, 833, 834, 837, 842, 843, 844, 845, 846, 847, 853, 858, 859, 860, 865, 866, 867, 874, 875, 880, 881, 886, 887, 890, 894, 904, 906, 913, 914, 919, 920, 925, 926, 929, 933, 940, 942, 949, 950, 955, 956, 961, 962, 965, 969, 972, 981, 982, 987, 988, 993, 994, 997, 1001, 1004, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1041, 1046, 1047, 1048, 1049, 1054, 1055, 1056, 1061, 1062, 1065, 1069, 1072, 1075, 1076, 1081, 1082, 1083, 1088, 1089, 1092, 1096, 1099, 1102, 1106, 1109, 1110, 1115, 1116, 1117, 1122, 1123, 1126, 1130, 1133, 1136, 1140, 1141, 1143, 1149, 1150, 1157, 1158, 1163, 1164, 1165, 1167, 1168, 1186, 1187, 1198, 1199, 1200, 1201, 1202, 1203, 1208, 1209, 1210, 1211, 1212, 1214, 1219, 1220, 1221, 1265, 1270, 1271, 1274, 1279, 1280, 1283, 1287, 1290, 1291, 1296, 1297, 1300, 1304, 1307, 1312, 1313, 1316, 1320, 1323, 1324, 1329, 1330, 1333, 1337, 1340, 1341, 1346, 1347, 1350, 1354, 1357, 1358, 1359, 1364, 1365, 1368, 1372, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1387, 1388, 1389, 1390, 1392, 1395, 1400, 1401, 1402, 1407, 1408, 1409, 1414, 1415, 1417, 1418, 1419, 1420, 1421, 1422, 1427, 1428, 1430, 1431, 1432, 1435, 1440, 1441, 1442, 1443, 1448, 1451, 1452, 1458, 1463, 1464, 1467, 1473, 1484, 1485, 1486, 1487, 1490, 1495, 1496, 1497, 1498, 1499, 1505, 1510, 1511, 1512, 1514, 1519, 1520, 1521, 1527, 1528, 1529, 1530, 1533, 1556, 1561, 1562, 1565, 1567, 1570, 1574, 1576, 1577, 1578, 1583, 1584, 1587, 1589, 1590, 1591, 1592, 1595, 1600, 1601, 1602, 1603, 1608, 1609, 1614, 1615, 1616, 1619, 1620, 1623, 1629, 1630, 1635, 1636, 1641, 1642, 1645, 1650, 1651, 1655, 1664, 1669, 1670, 1672, 1673, 1674, 1679, 1680, 1681, 1683, 1684, 1693, 1698, 1699, 1701, 1702, 1703, 1708, 1709, 1710, 1712, 1713, 1727, 1728, 1733, 1734, 1739, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1764, 1765, 1782, 1783, 1788, 1789, 1792, 1793, 1798, 1799, 1802, 1803, 1808, 1809, 1812, 1816, 1819, 1823, 1824, 1825, 1828, 1833, 1834, 1835, 1837, 1838, 1839, 1840, 1841, 1842, 1847, 1848, 1853, 1858, 1859, 1861, 1867, 1868, 1869, 1876, 1877, 1878, 1879, 1880, 1896, 1901, 1902, 1906, 1907, 1911, 1912, 1916, 1917, 1921, 1922, 1926, 1927, 1930, 1937, 1942, 1943, 1946, 1947, 1948, 1949, 1950, 1956, 1957, 1962, 1963, 1964, 1973, 1974, 1975, 1976, 1977, 1980, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 2000, 2003, 2006, 2010, 2014, 2017, 2020, 2024, 2027, 2030, 2034, 2038, 2041, 2044, 2048};
/* BEGIN LINEINFO 
assign 1 234 110
new 0 234 110
capacitySet 1 235 111
assign 1 248 117
new 0 248 117
assign 1 248 118
once 0 248 118
new 1 248 119
assign 1 252 126
undef 1 252 131
assign 1 253 132
new 0 253 132
assign 1 254 135
equals 1 254 140
return 1 255 141
assign 1 291 152
greater 1 291 157
setValue 1 292 158
setValue 1 294 160
assign 1 298 170
new 0 298 170
assign 1 298 171
once 0 298 171
new 1 298 172
assign 1 299 173
new 0 299 173
assign 1 299 174
once 0 299 174
setValue 1 299 175
assign 1 300 176
new 0 300 176
assign 1 300 177
once 0 300 177
setHex 2 300 178
assign 1 304 188
new 0 304 188
assign 1 304 189
getCode 2 304 189
assign 1 304 190
new 0 304 190
assign 1 304 191
new 0 304 191
assign 1 304 192
new 0 304 192
assign 1 304 193
toString 3 304 193
return 1 304 194
assign 1 308 198
hexNew 1 308 198
setCode 2 309 199
assign 1 313 215
toString 0 313 215
assign 1 314 216
undef 1 314 221
assign 1 315 222
new 0 315 222
assign 1 316 223
new 0 316 223
assign 1 318 225
sizeGet 0 318 225
setValue 1 318 226
addValue 1 319 227
assign 1 321 228
lesser 1 321 233
assign 1 322 234
new 0 322 234
assign 1 322 235
add 1 322 235
assign 1 322 236
new 0 322 236
assign 1 322 237
multiply 1 322 237
assign 1 322 238
new 0 322 238
assign 1 322 239
divide 1 322 239
capacitySet 1 323 240
assign 1 325 242
new 0 325 242
assign 1 325 243
sizeGet 0 325 243
copyValue 4 325 244
return 1 329 248
return 1 333 251
addValue 1 337 254
write 1 341 258
assign 1 351 269
copy 0 351 269
clear 0 352 270
return 1 353 271
assign 1 357 282
new 0 357 282
assign 1 357 283
greater 1 357 288
assign 1 358 289
new 0 358 289
assign 1 358 290
once 0 358 290
assign 1 358 291
new 0 358 291
assign 1 358 292
once 0 358 292
setIntUnchecked 2 358 293
assign 1 359 294
new 0 359 294
assign 1 359 295
once 0 359 295
setValue 1 359 296
assign 1 364 306
new 0 364 306
new 1 364 307
assign 1 365 308
new 0 365 308
assign 1 365 309
once 0 365 309
setValue 1 365 310
assign 1 366 311
new 0 366 311
assign 1 366 312
once 0 366 312
setCodeUnchecked 2 366 313
assign 1 370 329
new 0 370 329
assign 1 370 330
newlineGet 0 370 330
assign 1 371 331
ends 1 371 331
assign 1 372 333
new 0 372 333
assign 1 372 334
sizeGet 0 372 334
assign 1 372 335
subtract 1 372 335
assign 1 372 336
substring 2 372 336
return 1 372 337
assign 1 374 339
new 0 374 339
assign 1 375 340
ends 1 375 340
assign 1 376 342
new 0 376 342
assign 1 376 343
sizeGet 0 376 343
assign 1 376 344
subtract 1 376 344
assign 1 376 345
substring 2 376 345
return 1 376 346
return 1 378 348
assign 1 382 354
new 0 382 354
assign 1 382 355
add 1 382 355
assign 1 382 356
new 1 382 356
addValue 1 383 357
return 1 384 358
assign 1 388 368
find 1 388 368
assign 1 389 369
undef 1 389 374
assign 1 0 375
assign 1 389 378
new 0 389 378
assign 1 389 379
notEquals 1 389 384
assign 1 0 385
assign 1 0 388
assign 1 390 392
new 0 390 392
return 1 390 393
assign 1 392 395
new 0 392 395
return 1 392 396
assign 1 396 407
undef 1 396 412
assign 1 396 413
new 0 396 413
return 1 396 414
assign 1 397 416
sizeGet 0 397 416
assign 1 397 417
subtract 1 397 417
assign 1 397 418
find 2 397 418
assign 1 398 419
undef 1 398 424
assign 1 399 425
new 0 399 425
return 1 399 426
assign 1 401 428
new 0 401 428
return 1 401 429
assign 1 405 438
undef 1 405 443
assign 1 0 444
assign 1 405 447
find 1 405 447
assign 1 405 448
undef 1 405 453
assign 1 0 454
assign 1 0 457
assign 1 406 461
new 0 406 461
return 1 406 462
assign 1 408 464
new 0 408 464
return 1 408 465
assign 1 412 485
new 0 412 485
assign 1 413 486
new 0 413 486
assign 1 413 489
lesser 1 413 494
getInt 2 414 495
assign 1 415 496
new 0 415 496
assign 1 415 497
equals 1 415 502
assign 1 415 503
new 0 415 503
assign 1 415 504
equals 1 415 509
assign 1 0 510
assign 1 415 513
new 0 415 513
assign 1 415 514
equals 1 415 519
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 0 530
assign 1 0 534
assign 1 417 539
new 0 417 539
assign 1 417 540
greater 1 417 545
assign 1 0 546
assign 1 417 549
new 0 417 549
assign 1 417 550
lesser 1 417 555
assign 1 0 556
assign 1 0 559
assign 1 418 563
new 0 418 563
return 1 418 564
incrementValue 0 413 567
assign 1 421 573
new 0 421 573
return 1 421 574
assign 1 425 586
new 0 425 586
assign 1 426 587
new 0 426 587
assign 1 426 590
lesser 1 426 595
getInt 2 427 596
assign 1 428 597
new 0 428 597
assign 1 428 598
greater 1 428 603
assign 1 428 604
new 0 428 604
assign 1 428 605
lesser 1 428 610
assign 1 0 611
assign 1 0 614
assign 1 0 618
assign 1 429 621
new 0 429 621
addValue 1 429 622
setIntUnchecked 2 430 623
incrementValue 0 426 625
assign 1 436 636
copy 0 436 636
assign 1 436 637
lowerValue 0 436 637
return 1 436 638
assign 1 440 650
new 0 440 650
assign 1 441 651
new 0 441 651
assign 1 441 654
lesser 1 441 659
getInt 2 442 660
assign 1 443 661
new 0 443 661
assign 1 443 662
greater 1 443 667
assign 1 443 668
new 0 443 668
assign 1 443 669
lesser 1 443 674
assign 1 0 675
assign 1 0 678
assign 1 0 682
assign 1 444 685
new 0 444 685
subtractValue 1 444 686
setIntUnchecked 2 445 687
incrementValue 0 441 689
assign 1 451 700
copy 0 451 700
assign 1 451 701
upperValue 0 451 701
return 1 451 702
assign 1 455 708
new 0 455 708
assign 1 455 709
split 1 455 709
assign 1 455 710
join 2 455 710
return 1 455 711
assign 1 461 723
new 0 461 723
assign 1 462 724
new 0 462 724
assign 1 463 725
new 0 463 725
assign 1 464 726
find 2 464 726
assign 1 465 727
def 1 465 732
assign 1 466 733
substring 2 466 733
addValue 1 466 734
addValue 1 467 735
assign 1 468 736
sizeGet 0 468 736
assign 1 468 737
add 1 468 737
assign 1 469 738
sizeGet 0 469 738
assign 1 469 739
substring 2 469 739
addValue 1 469 740
assign 1 471 743
copy 0 471 743
return 1 471 744
return 1 473 746
assign 1 478 758
new 0 478 758
assign 1 479 759
new 0 479 759
assign 1 480 760
new 0 480 760
assign 1 481 763
def 1 481 768
assign 1 482 769
find 2 482 769
assign 1 483 770
def 1 483 775
assign 1 484 776
substring 2 484 776
addValue 1 484 777
addValue 1 485 778
assign 1 486 779
sizeGet 0 486 779
assign 1 486 780
add 1 486 780
assign 1 489 783
sizeGet 0 489 783
assign 1 489 784
substring 2 489 784
addValue 1 489 785
return 1 493 792
assign 1 498 802
new 0 498 802
assign 1 498 803
new 1 498 803
assign 1 499 804
mbiterGet 0 499 804
assign 1 500 805
new 0 500 805
assign 1 500 808
lesser 1 500 813
next 1 501 814
incrementValue 0 500 815
assign 1 503 821
next 1 503 821
assign 1 503 822
toString 0 503 822
return 1 504 823
assign 1 508 831
new 0 508 831
assign 1 509 832
new 0 509 832
setValue 1 509 833
assign 1 510 834
new 0 510 834
assign 1 510 837
lesser 1 510 842
getInt 2 511 843
assign 1 512 844
new 0 512 844
multiplyValue 1 512 845
addValue 1 513 846
incrementValue 0 510 847
return 1 516 853
assign 1 520 858
new 0 520 858
assign 1 520 859
hashValue 1 520 859
return 1 520 860
assign 1 524 865
new 0 524 865
assign 1 524 866
getCode 2 524 866
return 1 524 867
assign 1 534 874
new 0 534 874
assign 1 534 875
greaterEquals 1 534 880
assign 1 534 881
greater 1 534 886
assign 1 0 887
assign 1 0 890
assign 1 0 894
return 1 571 904
return 1 573 906
assign 1 584 913
new 0 584 913
assign 1 584 914
greaterEquals 1 584 919
assign 1 584 920
greater 1 584 925
assign 1 0 926
assign 1 0 929
assign 1 0 933
return 1 619 940
return 1 621 942
assign 1 625 949
new 0 625 949
assign 1 625 950
greaterEquals 1 625 955
assign 1 625 956
greater 1 625 961
assign 1 0 962
assign 1 0 965
assign 1 0 969
setIntUnchecked 2 626 972
assign 1 631 981
new 0 631 981
assign 1 631 982
greaterEquals 1 631 987
assign 1 631 988
greater 1 631 993
assign 1 0 994
assign 1 0 997
assign 1 0 1001
setCodeUnchecked 2 632 1004
assign 1 637 1032
assign 1 638 1033
sizeGet 0 638 1033
assign 1 638 1034
copy 0 638 1034
assign 1 639 1035
new 1 639 1035
assign 1 640 1036
new 0 640 1036
assign 1 641 1037
new 0 641 1037
assign 1 642 1038
new 0 642 1038
assign 1 642 1041
lesser 1 642 1046
getInt 2 643 1047
assign 1 644 1048
new 0 644 1048
assign 1 644 1049
greater 1 644 1054
assign 1 644 1055
new 0 644 1055
assign 1 644 1056
lesser 1 644 1061
assign 1 0 1062
assign 1 0 1065
assign 1 0 1069
assign 1 0 1072
assign 1 644 1075
new 0 644 1075
assign 1 644 1076
greater 1 644 1081
assign 1 644 1082
new 0 644 1082
assign 1 644 1083
lesser 1 644 1088
assign 1 0 1089
assign 1 0 1092
assign 1 0 1096
assign 1 0 1099
assign 1 0 1102
assign 1 0 1106
assign 1 644 1109
new 0 644 1109
assign 1 644 1110
greater 1 644 1115
assign 1 644 1116
new 0 644 1116
assign 1 644 1117
lesser 1 644 1122
assign 1 0 1123
assign 1 0 1126
assign 1 0 1130
assign 1 0 1133
assign 1 0 1136
setIntUnchecked 2 645 1140
incrementValue 0 646 1141
incrementValue 0 642 1143
sizeSet 1 649 1149
return 1 650 1150
assign 1 654 1157
new 0 654 1157
assign 1 654 1158
lesserEquals 1 654 1163
assign 1 655 1164
new 0 655 1164
return 1 655 1165
assign 1 657 1167
new 0 657 1167
return 1 657 1168
assign 1 754 1186
rfind 1 754 1186
return 1 754 1187
assign 1 760 1198
copy 0 760 1198
assign 1 760 1199
reverseBytes 0 760 1199
assign 1 760 1200
copy 0 760 1200
assign 1 760 1201
reverseBytes 0 760 1201
assign 1 760 1202
find 1 760 1202
assign 1 762 1203
def 1 762 1208
assign 1 763 1209
sizeGet 0 763 1209
addValue 1 763 1210
assign 1 764 1211
subtract 1 764 1211
return 1 764 1212
return 1 766 1214
assign 1 770 1219
new 0 770 1219
assign 1 770 1220
find 2 770 1220
return 1 770 1221
assign 1 776 1265
undef 1 776 1270
assign 1 0 1271
assign 1 776 1274
undef 1 776 1279
assign 1 0 1280
assign 1 0 1283
assign 1 0 1287
assign 1 776 1290
new 0 776 1290
assign 1 776 1291
lesser 1 776 1296
assign 1 0 1297
assign 1 0 1300
assign 1 0 1304
assign 1 776 1307
greaterEquals 1 776 1312
assign 1 0 1313
assign 1 0 1316
assign 1 0 1320
assign 1 776 1323
sizeGet 0 776 1323
assign 1 776 1324
greater 1 776 1329
assign 1 0 1330
assign 1 0 1333
assign 1 0 1337
assign 1 776 1340
new 0 776 1340
assign 1 776 1341
equals 1 776 1346
assign 1 0 1347
assign 1 0 1350
assign 1 0 1354
assign 1 776 1357
sizeGet 0 776 1357
assign 1 776 1358
new 0 776 1358
assign 1 776 1359
equals 1 776 1364
assign 1 0 1365
assign 1 0 1368
return 1 777 1372
assign 1 780 1374
assign 1 781 1375
copy 0 781 1375
assign 1 782 1376
new 0 782 1376
assign 1 783 1377
new 0 783 1377
assign 1 784 1378
new 0 784 1378
getInt 2 784 1379
assign 1 786 1380
sizeGet 0 786 1380
assign 1 788 1381
new 0 788 1381
assign 1 788 1382
greater 1 788 1387
assign 1 789 1388
new 0 789 1388
assign 1 790 1389
new 0 790 1389
assign 1 791 1390
new 0 791 1390
assign 1 793 1392
new 0 793 1392
assign 1 794 1395
lesser 1 794 1400
getInt 2 795 1401
assign 1 796 1402
equals 1 796 1407
assign 1 797 1408
new 0 797 1408
assign 1 797 1409
equals 1 797 1414
return 1 798 1415
setValue 1 800 1417
incrementValue 0 801 1418
setValue 1 802 1419
assign 1 803 1420
sizeGet 0 803 1420
addValue 1 803 1421
assign 1 804 1422
greater 1 804 1427
return 1 805 1428
assign 1 807 1430
new 0 807 1430
assign 1 807 1431
once 0 807 1431
setValue 1 807 1432
assign 1 808 1435
lesser 1 808 1440
getInt 2 809 1441
getInt 2 810 1442
assign 1 811 1443
notEquals 1 811 1448
incrementValue 0 814 1451
incrementValue 0 815 1452
assign 1 817 1458
equals 1 817 1463
return 1 818 1464
incrementValue 0 821 1467
return 1 823 1473
assign 1 827 1484
new 0 827 1484
assign 1 828 1485
new 0 828 1485
assign 1 829 1486
find 2 829 1486
assign 1 830 1487
sizeGet 0 830 1487
assign 1 831 1490
def 1 831 1495
assign 1 832 1496
substring 2 832 1496
addValue 1 832 1497
assign 1 833 1498
add 1 833 1498
assign 1 834 1499
find 2 834 1499
assign 1 836 1505
lesser 1 836 1510
assign 1 837 1511
substring 2 837 1511
addValue 1 837 1512
return 1 839 1514
assign 1 843 1519
new 0 843 1519
assign 1 843 1520
join 2 843 1520
return 1 843 1521
assign 1 847 1527
new 0 847 1527
assign 1 847 1528
lineSplitterGet 0 847 1528
assign 1 847 1529
tokenize 1 847 1529
return 1 847 1530
return 1 851 1533
assign 1 859 1556
undef 1 859 1561
assign 1 0 1562
assign 1 859 1565
otherType 1 859 1565
assign 1 0 1567
assign 1 0 1570
return 1 860 1574
assign 1 862 1576
assign 1 863 1577
sizeGet 0 863 1577
assign 1 864 1578
greater 1 864 1583
assign 1 865 1584
assign 1 867 1587
assign 1 869 1589
new 0 869 1589
assign 1 870 1590
new 0 870 1590
assign 1 871 1591
new 0 871 1591
assign 1 872 1592
new 0 872 1592
assign 1 872 1595
lesser 1 872 1600
getCode 2 873 1601
getCode 2 874 1602
assign 1 875 1603
notEquals 1 875 1608
assign 1 876 1609
greater 1 876 1614
assign 1 877 1615
new 0 877 1615
return 1 877 1616
assign 1 879 1619
new 0 879 1619
return 1 879 1620
incrementValue 0 872 1623
assign 1 883 1629
new 0 883 1629
assign 1 883 1630
equals 1 883 1635
assign 1 884 1636
greater 1 884 1641
assign 1 885 1642
new 0 885 1642
assign 1 886 1645
greater 1 886 1650
assign 1 887 1651
new 0 887 1651
return 1 890 1655
assign 1 894 1664
undef 1 894 1669
return 1 894 1670
assign 1 895 1672
compare 1 895 1672
assign 1 895 1673
new 0 895 1673
assign 1 895 1674
equals 1 895 1679
assign 1 896 1680
new 0 896 1680
return 1 896 1681
assign 1 898 1683
new 0 898 1683
return 1 898 1684
assign 1 902 1693
undef 1 902 1698
return 1 902 1699
assign 1 903 1701
compare 1 903 1701
assign 1 903 1702
new 0 903 1702
assign 1 903 1703
equals 1 903 1708
assign 1 904 1709
new 0 904 1709
return 1 904 1710
assign 1 906 1712
new 0 906 1712
return 1 906 1713
assign 1 961 1727
new 0 961 1727
return 1 961 1728
assign 1 965 1733
equals 1 965 1733
assign 1 965 1734
not 0 965 1739
return 1 965 1739
assign 1 969 1750
toString 0 969 1750
assign 1 970 1751
sizeGet 0 970 1751
assign 1 970 1752
add 1 970 1752
assign 1 970 1753
new 1 970 1753
assign 1 971 1754
new 0 971 1754
assign 1 971 1755
new 0 971 1755
copyValue 4 971 1756
assign 1 972 1757
new 0 972 1757
assign 1 972 1758
sizeGet 0 972 1758
copyValue 4 972 1759
return 1 973 1760
assign 1 976 1764
new 0 976 1764
return 1 976 1765
assign 1 980 1782
new 0 980 1782
assign 1 980 1783
lesser 1 980 1788
assign 1 0 1789
assign 1 980 1792
sizeGet 0 980 1792
assign 1 980 1793
greater 1 980 1798
assign 1 0 1799
assign 1 980 1802
sizeGet 0 980 1802
assign 1 980 1803
greater 1 980 1808
assign 1 0 1809
assign 1 0 1812
assign 1 0 1816
assign 1 0 1819
assign 1 981 1823
new 0 981 1823
assign 1 981 1824
new 1 981 1824
throw 1 981 1825
assign 1 985 1828
undef 1 985 1833
assign 1 986 1834
new 0 986 1834
assign 1 987 1835
new 0 987 1835
setValue 1 989 1837
subtractValue 1 990 1838
assign 1 991 1839
setValue 1 993 1840
addValue 1 994 1841
assign 1 996 1842
greater 1 996 1847
capacitySet 1 997 1848
assign 1 1030 1853
greater 1 1030 1858
setValue 1 1034 1859
return 1 1036 1861
assign 1 1041 1867
sizeGet 0 1041 1867
assign 1 1041 1868
substring 2 1041 1868
return 1 1041 1869
assign 1 1045 1876
subtract 1 1045 1876
assign 1 1045 1877
new 1 1045 1877
assign 1 1045 1878
new 0 1045 1878
assign 1 1045 1879
copyValue 4 1045 1879
return 1 1045 1880
output 0 1137 1896
assign 1 1141 1901
new 1 1141 1901
return 1 1141 1902
assign 1 1145 1906
new 1 1145 1906
return 1 1145 1907
assign 1 1149 1911
new 1 1149 1911
return 1 1149 1912
assign 1 1153 1916
new 1 1153 1916
return 1 1153 1917
assign 1 1157 1921
new 1 1157 1921
return 1 1157 1922
assign 1 1161 1926
new 1 1161 1926
return 1 1161 1927
return 1 1165 1930
assign 1 1169 1937
undef 1 1169 1942
new 0 1170 1943
assign 1 1172 1946
sizeGet 0 1172 1946
assign 1 1172 1947
new 0 1172 1947
assign 1 1172 1948
add 1 1172 1948
new 1 1172 1949
addValue 1 1173 1950
assign 1 1178 1956
new 0 1178 1956
return 1 1178 1957
assign 1 1182 1962
new 0 1182 1962
assign 1 1182 1963
strip 1 1182 1963
return 1 1182 1964
assign 1 1186 1973
new 0 1186 1973
assign 1 1187 1974
new 0 1187 1974
assign 1 1188 1975
new 0 1188 1975
assign 1 1189 1976
new 0 1189 1976
assign 1 1189 1977
subtract 1 1189 1977
assign 1 1190 1980
greater 1 1190 1985
getInt 2 1191 1986
getInt 2 1192 1987
setInt 2 1193 1988
setInt 2 1194 1989
incrementValue 0 1195 1990
decrementValue 0 1196 1991
return 1 0 2000
return 1 0 2003
assign 1 0 2006
assign 1 0 2010
return 1 0 2014
return 1 0 2017
assign 1 0 2020
return 1 0 2024
return 1 0 2027
assign 1 0 2030
assign 1 0 2034
return 1 0 2038
return 1 0 2041
assign 1 0 2044
assign 1 0 2048
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1812170199: return bem_isInteger_0();
case 1317031065: return bem_leniGetDirect_0();
case 1741010261: return bem_classNameGet_0();
case -2048609488: return bem_tagGet_0();
case 1306564631: return bem_extractString_0();
case -1001663723: return bem_stringIteratorGet_0();
case 561251563: return bem_lowerValue_0();
case -545958368: return bem_toAny_0();
case 1419414154: return bem_new_0();
case 429419643: return bem_echo_0();
case 1909096874: return bem_create_0();
case -39142453: return bem_clear_0();
case -1108167878: return bem_serializeToString_0();
case -469171007: return bem_serializeContents_0();
case 864218203: return bem_splitLines_0();
case 1613601767: return bem_capacityGetDirect_0();
case -811598956: return bem_fieldNamesGet_0();
case 2077040828: return bem_copy_0();
case -1918539521: return bem_toString_0();
case 1687921048: return bem_hashGet_0();
case 1296673609: return bem_readBuffer_0();
case -632169362: return bem_print_0();
case 465306992: return bem_strip_0();
case -597812390: return bem_vstringGet_0();
case -683861355: return bem_isEmptyGet_0();
case -519287702: return bem_capacityGet_0();
case 287394467: return bem_close_0();
case -1786271241: return bem_sourceFileNameGet_0();
case 1686100284: return bem_leniGet_0();
case -855260646: return bem_toAlphaNum_0();
case 1730620110: return bem_serializationIteratorGet_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case -212376625: return bem_iteratorGet_0();
case -1004079418: return bem_once_0();
case -1969132625: return bem_upper_0();
case 792828478: return bem_biterGet_0();
case 1603326601: return bem_many_0();
case 1351091796: return bem_mbiterGet_0();
case 1665337837: return bem_siziGetDirect_0();
case -2781747: return bem_chomp_0();
case -1701564795: return bem_upperValue_0();
case 1160073551: return bem_lower_0();
case -355650890: return bem_vstringSet_0();
case -963755335: return bem_fieldIteratorGet_0();
case 1363799558: return bem_readString_0();
case 1487044957: return bem_byteIteratorGet_0();
case 1645878416: return bem_siziGet_0();
case -177527484: return bem_reverseBytes_0();
case -1862809801: return bem_open_0();
case -918033785: return bem_sizeGet_0();
case 81377922: return bem_output_0();
case -459955320: return bem_multiByteIteratorGet_0();
case -1614626267: return bem_sizeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1434304379: return bem_otherType_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case 1225776887: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -557886178: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 1448748193: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case -1578950220: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 550499265: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case -363168387: return bem_sameType_1(bevd_0);
case -2089092712: return bem_compare_1(bevd_0);
case 152142043: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1846105765: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case -833485673: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 158922378: return bem_leniSet_1(bevd_0);
case -324907880: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case -536126381: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -800861931: return bem_capacitySetDirect_1(bevd_0);
case 633502395: return bem_add_1(bevd_0);
case 2020550891: return bem_siziSetDirect_1(bevd_0);
case -1753080609: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1188023351: return bem_addValue_1(bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case 2033027988: return bem_codeNew_1(bevd_0);
case -978184840: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1991860809: return bem_writeTo_1(bevd_0);
case -215826876: return bem_write_1(bevd_0);
case -1262650329: return bem_sizeSet_1(bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case 1618696688: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -723593334: return bem_siziSet_1(bevd_0);
case -186597225: return bem_leniSetDirect_1(bevd_0);
case 239719294: return bem_sizeSetDirect_1(bevd_0);
case -1879171236: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -795064216: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -974831903: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case 1827357731: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -49364187: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1174473034: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1629080342: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -616985207: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1478112338: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 972573553: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -344580243: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1891617533: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1575229438: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1379691536: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -708985362: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1243626652: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -589860786: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -673766779: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
}
