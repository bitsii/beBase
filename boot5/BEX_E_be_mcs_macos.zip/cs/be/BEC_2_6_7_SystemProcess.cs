namespace be {

using System;
using System.Reflection;
    /* IO:File: source/base/EcProcess.be */
public sealed class BEC_2_6_7_SystemProcess : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemProcess() { }
static BEC_2_6_7_SystemProcess() { }
private static byte[] becc_BEC_2_6_7_SystemProcess_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] becc_BEC_2_6_7_SystemProcess_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x63,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_inst;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_4_3_MathInt bevp_numArgs;
public BEC_2_6_6_SystemObject bevp_execName;
public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_6_6_SystemObject bevp_result;
public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_15_SystemCurrentPlatform bevp_platform;
public BEC_2_6_6_SystemObject bevp_fullExecName;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_default_0() {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bem_prepArgs_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_execNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_1_tmpany_phold = bem_fullExecNameGet_0();
return bevt_1_tmpany_phold;
} /* Line: 39 */
if (bevp_execName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 40 */ {

            bevp_execName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Environment.GetCommandLineArgs()[0]));
            //bevp_execName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Assembly.GetEntryAssembly().Location));
            } /* Line: 41 */
return bevp_execName;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_execPathGet_0() {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_execNameGet_0();
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fullExecNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_fullExecName == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {

            //bevp_execName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Environment.GetCommandLineArgs()[0]));
            bevp_fullExecName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(System.Reflection.Assembly.GetEntryAssembly().Location));
            } /* Line: 60 */
return bevp_fullExecName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_prepArgs_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 72 */ {
if (bevp_args == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevp_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();

            for (int i = 0;i < be.BECS_Runtime.args.Length;i++) {
                bevp_args.bem_addValue_1(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.args[i])));
            }
          bevp_numArgs = bevp_args.bem_sizeGet_0();
} /* Line: 98 */
} /* Line: 73 */
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_exit_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_1(BEC_2_4_3_MathInt beva_code) {

     Environment.Exit(beva_code.bevi_int);
     return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_start_1(BEC_2_6_6_SystemObject beva__target) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevp_target = beva__target;
try  /* Line: 123 */ {
bevp_result = bevp_target.bemd_0(-1520484779);
} /* Line: 124 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_except = bevl_e;
bevl_e.bemd_0(1207509984);
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 128 */
return bevp_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startByName_1(BEC_2_6_6_SystemObject beva__name) {
BEC_2_6_6_SystemObject bevl_t = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) beva__name );
bevl_t = bevt_0_tmpany_phold.bemd_0(-231534902);
bevt_1_tmpany_phold = bem_start_1(bevl_t);
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numArgsGet_0() {
return bevp_numArgs;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_numArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_numArgs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_execNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_execName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resultGet_0() {
return bevp_result;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_resultSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_result = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_fullExecNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullExecName = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {32, 35, 39, 39, 39, 40, 40, 48, 52, 52, 52, 59, 59, 67, 73, 73, 74, 98, 105, 105, 122, 124, 126, 127, 128, 128, 130, 134, 134, 135, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 32, 34, 35, 37, 42, 47, 52, 53, 54, 58, 63, 68, 73, 78, 79, 84, 91, 92, 103, 105, 109, 110, 111, 112, 114, 120, 121, 122, 123, 126, 129, 133, 136, 140, 144, 147, 151, 154, 158, 161, 165, 168, 172};
/* BEGIN LINEINFO 
assign 1 32 24
new 0 32 24
prepArgs 0 35 25
assign 1 39 32
new 0 39 32
assign 1 39 34
fullExecNameGet 0 39 34
return 1 39 35
assign 1 40 37
undef 1 40 42
return 1 48 47
assign 1 52 52
execNameGet 0 52 52
assign 1 52 53
apNew 1 52 53
return 1 52 54
assign 1 59 58
undef 1 59 63
return 1 67 68
assign 1 73 73
undef 1 73 78
assign 1 74 79
new 0 74 79
assign 1 98 84
sizeGet 0 98 84
assign 1 105 91
new 0 105 91
exit 1 105 92
assign 1 122 103
assign 1 124 105
main 0 124 105
assign 1 126 109
print 0 127 110
assign 1 128 111
new 0 128 111
return 1 128 112
return 1 130 114
assign 1 134 120
createInstance 1 134 120
assign 1 134 121
new 0 134 121
assign 1 135 122
start 1 135 122
return 1 135 123
return 1 0 126
assign 1 0 129
return 1 0 133
assign 1 0 136
assign 1 0 140
return 1 0 144
assign 1 0 147
return 1 0 151
assign 1 0 154
return 1 0 158
assign 1 0 161
return 1 0 165
assign 1 0 168
assign 1 0 172
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1964495741: return bem_serializeContents_0();
case 716581775: return bem_fieldIteratorGet_0();
case -546524164: return bem_default_0();
case -864977132: return bem_echo_0();
case -694642189: return bem_serializationIteratorGet_0();
case 1885938794: return bem_toAny_0();
case -1626502172: return bem_iteratorGet_0();
case 257093696: return bem_resultGet_0();
case 498230251: return bem_classNameGet_0();
case -1170883362: return bem_deserializeClassNameGet_0();
case -108593702: return bem_sourceFileNameGet_0();
case -1705431248: return bem_argsGet_0();
case -1929872495: return bem_targetGet_0();
case 26234707: return bem_fullExecNameGet_0();
case -640694898: return bem_many_0();
case -296700272: return bem_create_0();
case 725812145: return bem_numArgsGet_0();
case -231534902: return bem_new_0();
case -980561080: return bem_execNameGet_0();
case -192469868: return bem_exit_0();
case -869030838: return bem_hashGet_0();
case -2128300145: return bem_exceptGet_0();
case 1276785109: return bem_once_0();
case 1207509984: return bem_print_0();
case 1778404598: return bem_tagGet_0();
case -327890059: return bem_toString_0();
case 472009685: return bem_prepArgs_0();
case -838633237: return bem_serializeToString_0();
case -374230686: return bem_platformGet_0();
case -1470416551: return bem_copy_0();
case 717949135: return bem_execPathGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2084638179: return bem_exceptSet_1(bevd_0);
case 1747027739: return bem_fullExecNameSet_1(bevd_0);
case 1227656529: return bem_numArgsSet_1(bevd_0);
case -1595453011: return bem_start_1(bevd_0);
case -1363115649: return bem_equals_1(bevd_0);
case -2022931262: return bem_defined_1(bevd_0);
case -1805705632: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1237205225: return bem_sameClass_1(bevd_0);
case -996916931: return bem_copyTo_1(bevd_0);
case 871367475: return bem_def_1(bevd_0);
case 1697977276: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1029744872: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1349020478: return bem_sameObject_1(bevd_0);
case 1971930884: return bem_notEquals_1(bevd_0);
case -1118008475: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 873867702: return bem_undef_1(bevd_0);
case -1073870688: return bem_sameType_1(bevd_0);
case 854237498: return bem_execNameSet_1(bevd_0);
case -898771829: return bem_otherType_1(bevd_0);
case -1027631125: return bem_targetSet_1(bevd_0);
case 41506532: return bem_otherClass_1(bevd_0);
case -341054699: return bem_undefined_1(bevd_0);
case -793101475: return bem_platformSet_1(bevd_0);
case 106413135: return bem_exit_1((BEC_2_4_3_MathInt) bevd_0);
case -860700977: return bem_startByName_1(bevd_0);
case -1939491526: return bem_argsSet_1(bevd_0);
case -682106453: return bem_resultSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 508127182: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1597816100: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -282965627: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1721714391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -48765507: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1009765426: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1302207765: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemProcess_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_7_SystemProcess_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemProcess();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst = (BEC_2_6_7_SystemProcess) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
}
}
}
