namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_10_IOByteReader : BEC_2_6_6_SystemObject {
public BEC_2_2_10_IOByteReader() { }
static BEC_2_2_10_IOByteReader() { }
private static byte[] becc_BEC_2_2_10_IOByteReader_clname = {0x49,0x4F,0x3A,0x42,0x79,0x74,0x65,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_10_IOByteReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_inst;

public static new BET_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_type;

public BEC_2_2_6_IOReader bevp_reader;
public BEC_2_4_6_TextString bevp_buf;
public BEC_2_4_12_TextByteIterator bevp_iter;
public virtual BEC_2_2_10_IOByteReader bem_readerBufferNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_6_TextString beva__buf) {
bevp_reader = beva__reader;
bevp_buf = beva__buf;
bevp_iter = bevp_buf.bem_biterGet_0();
return this;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerNew_1(BEC_2_2_6_IOReader beva__reader) {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(256));
bevt_0_tmpany_phold = (BEC_2_2_10_IOByteReader) bem_readerBlockNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerBlockNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_3_MathInt beva__blockSize) {
BEC_2_2_10_IOByteReader bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva__blockSize);
bevt_0_tmpany_phold = (BEC_2_2_10_IOByteReader) bem_readerBufferNew_2(beva__reader, bevt_1_tmpany_phold);
return (BEC_2_2_10_IOByteReader) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 42 */
bevt_3_tmpany_phold = bevp_iter.bem_hasNextGet_0();
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_dest) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_iter.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_tmpany_phold);
} /* Line: 54 */
bevt_3_tmpany_phold = bevp_iter.bem_next_1(beva_dest);
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_readerGet_0() {
return bevp_reader;
} /*method end*/
public BEC_2_2_6_IOReader bem_readerGetDirect_0() {
return bevp_reader;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_bufGet_0() {
return bevp_buf;
} /*method end*/
public BEC_2_4_6_TextString bem_bufGetDirect_0() {
return bevp_buf;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_bufSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_bufSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_iterGetDirect_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {25, 26, 27, 32, 32, 32, 36, 36, 36, 40, 40, 40, 41, 42, 42, 44, 44, 48, 48, 48, 48, 52, 52, 52, 53, 54, 54, 56, 56, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 21, 27, 28, 29, 34, 35, 36, 43, 44, 49, 50, 51, 52, 54, 55, 61, 62, 63, 64, 71, 72, 77, 78, 79, 80, 82, 83, 86, 89, 92, 96, 100, 103, 106, 110, 114, 117, 120, 124};
/* BEGIN LINEINFO 
assign 1 25 19
assign 1 26 20
assign 1 27 21
biterGet 0 27 21
assign 1 32 27
new 0 32 27
assign 1 32 28
readerBlockNew 2 32 28
return 1 32 29
assign 1 36 34
new 1 36 34
assign 1 36 35
readerBufferNew 2 36 35
return 1 36 36
assign 1 40 43
hasNextGet 0 40 43
assign 1 40 44
not 0 40 49
readIntoBuffer 1 41 50
assign 1 42 51
new 0 42 51
posSet 1 42 52
assign 1 44 54
hasNextGet 0 44 54
return 1 44 55
assign 1 48 61
new 0 48 61
assign 1 48 62
new 1 48 62
assign 1 48 63
next 1 48 63
return 1 48 64
assign 1 52 71
hasNextGet 0 52 71
assign 1 52 72
not 0 52 77
readIntoBuffer 1 53 78
assign 1 54 79
new 0 54 79
posSet 1 54 80
assign 1 56 82
next 1 56 82
return 1 56 83
return 1 0 86
return 1 0 89
assign 1 0 92
assign 1 0 96
return 1 0 100
return 1 0 103
assign 1 0 106
assign 1 0 110
return 1 0 114
return 1 0 117
assign 1 0 120
assign 1 0 124
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -31410563: return bem_once_0();
case -622447730: return bem_bufGetDirect_0();
case 2052796055: return bem_readerGet_0();
case 1366617398: return bem_tagGet_0();
case -14767827: return bem_serializeToString_0();
case -1141049131: return bem_iteratorGet_0();
case 98023671: return bem_iterGet_0();
case -1121300979: return bem_fieldNamesGet_0();
case -1194274080: return bem_toAny_0();
case 1801694719: return bem_copy_0();
case 434654272: return bem_hashGet_0();
case 1999868679: return bem_fieldIteratorGet_0();
case 1747475389: return bem_many_0();
case -1660671401: return bem_readerGetDirect_0();
case -1365182072: return bem_sourceFileNameGet_0();
case 2119098947: return bem_serializeContents_0();
case 222096027: return bem_classNameGet_0();
case 306116222: return bem_echo_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 216845033: return bem_new_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case 1246776508: return bem_hasNextGet_0();
case 1115258825: return bem_create_0();
case -2016997496: return bem_print_0();
case -1387377819: return bem_iterGetDirect_0();
case -1219673974: return bem_toString_0();
case -730791271: return bem_nextGet_0();
case -767285088: return bem_bufGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1309082333: return bem_iterSet_1(bevd_0);
case -1246021533: return bem_equals_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case 1877294649: return bem_readerSetDirect_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case 1585282713: return bem_readerNew_1((BEC_2_2_6_IOReader) bevd_0);
case 605244765: return bem_iterSetDirect_1(bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2019665305: return bem_readerSet_1(bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case 48283448: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 767738592: return bem_bufSetDirect_1(bevd_0);
case -240164168: return bem_undefined_1(bevd_0);
case -1193250908: return bem_bufSet_1(bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1929940720: return bem_readerBlockNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -226052782: return bem_readerBufferNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_2_10_IOByteReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_10_IOByteReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_10_IOByteReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst = (BEC_2_2_10_IOByteReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_type;
}
}
}
