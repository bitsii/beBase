namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_5_IOFileReaderStdin : BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_5_IOFileReaderStdin() { }
static BEC_4_2_4_6_5_IOFileReaderStdin() { }
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x53,0x74,0x64,0x69,0x6E};
private static byte[] becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;

public static new BET_4_2_4_6_5_IOFileReaderStdin bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_4_2_4_6_5_IOFileReaderStdin bem_default_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_blockSize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1024));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isClosedGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_2_6_IOReader bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_open_0() {
return this;
} /*method end*/
public override BEC_2_2_6_IOReader bem_close_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {724, 725, 730, 730};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 28, 29};
/* BEGIN LINEINFO 
assign 1 724 19
new 0 724 19
assign 1 725 20
new 0 725 20
assign 1 730 28
new 0 730 28
return 1 730 29
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 965815191: return bem_echo_0();
case -1226110647: return bem_readStringClose_0();
case -737249245: return bem_blockSizeGetDirect_0();
case -296688753: return bem_print_0();
case -1664072497: return bem_pathGetDirect_0();
case 1341030253: return bem_close_0();
case 1815140861: return bem_vfileGetDirect_0();
case -1453318633: return bem_new_0();
case 993863115: return bem_fieldIteratorGet_0();
case 43689037: return bem_extOpen_0();
case -1173722063: return bem_open_0();
case -1578327045: return bem_serializeContents_0();
case -1220273943: return bem_isClosedGetDirect_0();
case 940651019: return bem_once_0();
case -1039531132: return bem_create_0();
case -1683754328: return bem_readBufferLine_0();
case 617667581: return bem_toAny_0();
case -1400364749: return bem_serializationIteratorGet_0();
case 409025975: return bem_isClosedGet_0();
case -479359240: return bem_tagGet_0();
case 770044727: return bem_deserializeClassNameGet_0();
case 1552820506: return bem_classNameGet_0();
case -1948804865: return bem_vfileGet_0();
case -2015039528: return bem_iteratorGet_0();
case 1167480829: return bem_copy_0();
case 105645045: return bem_many_0();
case -1596775328: return bem_serializeToString_0();
case -688862469: return bem_toString_0();
case -835881829: return bem_default_0();
case -1522183491: return bem_pathGet_0();
case 2066844567: return bem_fieldNamesGet_0();
case 1470127612: return bem_sourceFileNameGet_0();
case -751466123: return bem_readString_0();
case 1227300615: return bem_byteReaderGet_0();
case -639622757: return bem_hashGet_0();
case 769185248: return bem_readBuffer_0();
case 1411353698: return bem_blockSizeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -414279577: return bem_new_1(bevd_0);
case 1871978213: return bem_vfileSetDirect_1(bevd_0);
case -1202688048: return bem_def_1(bevd_0);
case -1596168486: return bem_equals_1(bevd_0);
case 1489408670: return bem_sameType_1(bevd_0);
case -1076480041: return bem_notEquals_1(bevd_0);
case 1481142193: return bem_vfileSet_1(bevd_0);
case 1503413748: return bem_undefined_1(bevd_0);
case -548175583: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -1365097484: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1073960196: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2049637288: return bem_blockSizeSet_1(bevd_0);
case 419445436: return bem_copyTo_1(bevd_0);
case 1613708854: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1879722769: return bem_sameClass_1(bevd_0);
case 793732683: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -1416339029: return bem_sameObject_1(bevd_0);
case -1447883638: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1197332143: return bem_otherClass_1(bevd_0);
case 674706299: return bem_isClosedSet_1(bevd_0);
case -884635357: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1099515518: return bem_pathSetDirect_1(bevd_0);
case -1462673949: return bem_isClosedSetDirect_1(bevd_0);
case 1647383367: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1330925212: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 323831111: return bem_undef_1(bevd_0);
case -1300492421: return bem_otherType_1(bevd_0);
case 189658019: return bem_defined_1(bevd_0);
case 765469737: return bem_blockSizeSetDirect_1(bevd_0);
case 46076069: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1708927226: return bem_pathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 787023569: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1285045766: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -624371870: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 282981748: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1323585037: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2145191247: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -437555976: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1241554142: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1726696569: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1442476965: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_5_IOFileReaderStdin_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_5_IOFileReaderStdin();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst = (BEC_4_2_4_6_5_IOFileReaderStdin) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_type;
}
}
}
