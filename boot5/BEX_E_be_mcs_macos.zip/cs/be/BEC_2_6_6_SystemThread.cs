namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_6_SystemThread : BEC_2_6_10_SystemThinThread {
public BEC_2_6_6_SystemThread() { }
static BEC_2_6_6_SystemThread() { }
private static byte[] becc_BEC_2_6_6_SystemThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_6_SystemThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_inst;

public static new BET_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_type;

public BEC_3_6_6_12_SystemThreadObjectLocker bevp_started;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_finished;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_threwException;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_returned;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_exception;
public override BEC_2_6_10_SystemThinThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_1_tmpany_phold);
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
base.bem_new_1(beva__toRun);
return this;
} /*method end*/
public override BEC_2_6_10_SystemThinThread bem_main_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
try  /* Line: 799 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_started.bem_oSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_toRun.bemd_0(823327627);
bevp_returned.bem_oSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_threwException.bem_oSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_3_tmpany_phold);
} /* Line: 803 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_threwException.bem_oSet_1(bevt_4_tmpany_phold);
bevp_exception.bem_oSet_1(bevl_e);
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_5_tmpany_phold);
} /* Line: 807 */
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGet_0() {
return bevp_started;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGetDirect_0() {
return bevp_started;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGet_0() {
return bevp_finished;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGetDirect_0() {
return bevp_finished;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGet_0() {
return bevp_threwException;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGetDirect_0() {
return bevp_threwException;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGet_0() {
return bevp_returned;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGetDirect_0() {
return bevp_returned;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGet_0() {
return bevp_exception;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGetDirect_0() {
return bevp_exception;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {788, 788, 789, 789, 790, 791, 792, 794, 800, 800, 801, 801, 802, 802, 803, 803, 805, 805, 806, 807, 807, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 28, 29, 30, 31, 32, 44, 45, 46, 47, 48, 49, 50, 51, 55, 56, 57, 58, 59, 64, 67, 70, 74, 78, 81, 84, 88, 92, 95, 98, 102, 106, 109, 112, 116, 120, 123, 126, 130};
/* BEGIN LINEINFO 
assign 1 788 25
new 0 788 25
assign 1 788 26
new 1 788 26
assign 1 789 27
new 0 789 27
assign 1 789 28
new 1 789 28
assign 1 790 29
new 0 790 29
assign 1 791 30
new 0 791 30
assign 1 792 31
new 0 792 31
new 1 794 32
assign 1 800 44
new 0 800 44
oSet 1 800 45
assign 1 801 46
main 0 801 46
oSet 1 801 47
assign 1 802 48
new 0 802 48
oSet 1 802 49
assign 1 803 50
new 0 803 50
oSet 1 803 51
assign 1 805 55
new 0 805 55
oSet 1 805 56
oSet 1 806 57
assign 1 807 58
new 0 807 58
oSet 1 807 59
return 1 0 64
return 1 0 67
assign 1 0 70
assign 1 0 74
return 1 0 78
return 1 0 81
assign 1 0 84
assign 1 0 88
return 1 0 92
return 1 0 95
assign 1 0 98
assign 1 0 102
return 1 0 106
return 1 0 109
assign 1 0 112
assign 1 0 116
return 1 0 120
return 1 0 123
assign 1 0 126
assign 1 0 130
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2055997260: return bem_fieldIteratorGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -1528268081: return bem_toRunGetDirect_0();
case -323661464: return bem_serializeToString_0();
case 1064677251: return bem_many_0();
case -2092760709: return bem_once_0();
case -506237597: return bem_startedGetDirect_0();
case -1586284199: return bem_threwExceptionGet_0();
case 1858108497: return bem_toRunGet_0();
case 1076647192: return bem_create_0();
case 849387251: return bem_toAny_0();
case -1430066973: return bem_print_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case 864393987: return bem_tagGet_0();
case 2032575393: return bem_finishedGet_0();
case 1658946261: return bem_returnedGet_0();
case 749594343: return bem_threwExceptionGetDirect_0();
case 605836827: return bem_sourceFileNameGet_0();
case 1359360249: return bem_echo_0();
case 823327627: return bem_main_0();
case -236887613: return bem_classNameGet_0();
case -1369483363: return bem_fieldNamesGet_0();
case -945311630: return bem_returnedGetDirect_0();
case -346583060: return bem_exceptionGetDirect_0();
case -265713764: return bem_finishedGetDirect_0();
case 2070502838: return bem_copy_0();
case -1852877275: return bem_new_0();
case 392727319: return bem_wait_0();
case 928457034: return bem_serializeContents_0();
case 996718380: return bem_toString_0();
case 1372644764: return bem_hashGet_0();
case -331857212: return bem_exceptionGet_0();
case -1394848818: return bem_start_0();
case -842207018: return bem_iteratorGet_0();
case 2066629686: return bem_startedGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1570647300: return bem_equals_1(bevd_0);
case 145759994: return bem_returnedSetDirect_1(bevd_0);
case -986091360: return bem_startedSet_1(bevd_0);
case 1365518645: return bem_threwExceptionSetDirect_1(bevd_0);
case -1331143258: return bem_finishedSetDirect_1(bevd_0);
case 1192886969: return bem_toRunSet_1(bevd_0);
case -1421407725: return bem_finishedSet_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case 791078773: return bem_new_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 885243427: return bem_exceptionSet_1(bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case 1373674485: return bem_startedSetDirect_1(bevd_0);
case -960159496: return bem_otherClass_1(bevd_0);
case 2055551333: return bem_toRunSetDirect_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -681456320: return bem_returnedSet_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case -1321315455: return bem_threwExceptionSet_1(bevd_0);
case 1793220675: return bem_exceptionSetDirect_1(bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemThread_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemThread_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemThread();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst = (BEC_2_6_6_SystemThread) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_type;
}
}
}
