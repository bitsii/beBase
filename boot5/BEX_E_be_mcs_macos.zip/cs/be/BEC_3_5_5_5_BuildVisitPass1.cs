namespace be {
/* IO:File: source/build/Pass1.be */
public sealed class BEC_3_5_5_5_BuildVisitPass1 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass1() { }
static BEC_3_5_5_5_BuildVisitPass1() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_0 = {};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass1_bels_1 = {0x2E};
public static new BEC_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass1 bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;

public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_allAstElements;
public BEC_2_6_6_SystemObject bevp_f;
public BEC_2_4_6_TextString bevp_inClass;
public BEC_2_4_6_TextString bevp_inClassMethod;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_new_2(BEC_2_9_3_ContainerSet beva__printAstElements, BEC_2_4_6_TextString beva__fname) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_2_4_IOFile bevt_2_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_3_ta_ph = null;
bevp_printAstElements = beva__printAstElements;
bevp_allAstElements = bevp_printAstElements.bem_isEmptyGet_0();
if (beva__fname == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 25*/ {
bevt_3_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_2_ta_ph = bevt_3_ta_ph.bem_fileGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_writerGet_0();
bevp_f = bevt_1_ta_ph.bemd_0(-1501293113);
} /* Line: 26*/
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_inLine = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_7_TextStrings bevt_46_ta_ph = null;
BEC_2_5_4_BuildNode bevt_47_ta_ph = null;
bevt_5_ta_ph = beva_node.bem_typenameGet_0();
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_5_ta_ph.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 35*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_sameType_1(bevt_9_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 36*/ {
bevp_inClass = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 37*/
 else /* Line: 38*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1540868113);
bevp_inClass = (BEC_2_4_6_TextString) bevt_10_ta_ph.bemd_0(1640157629);
} /* Line: 39*/
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 42*/
bevt_13_ta_ph = beva_node.bem_typenameGet_0();
bevt_14_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_13_ta_ph.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevp_inClass == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_3_5_5_5_BuildVisitPass1_bels_0));
bevt_18_ta_ph = beva_node.bem_heldGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bem_sameType_1(bevt_18_ta_ph);
if (bevt_16_ta_ph.bevi_bool)/* Line: 45*/ {
bevp_inClassMethod = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 46*/
 else /* Line: 45*/ {
bevt_21_ta_ph = beva_node.bem_heldGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(405170711);
if (bevt_20_ta_ph == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_22_ta_ph = bevp_inClass.bem_add_1(bevt_23_ta_ph);
bevt_25_ta_ph = beva_node.bem_heldGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(405170711);
bevp_inClassMethod = bevt_22_ta_ph.bem_add_1(bevt_24_ta_ph);
} /* Line: 48*/
 else /* Line: 45*/ {
bevt_28_ta_ph = beva_node.bem_heldGet_0();
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-1432171810);
if (bevt_27_ta_ph == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_29_ta_ph = bevp_inClass.bem_add_1(bevt_30_ta_ph);
bevt_32_ta_ph = beva_node.bem_heldGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_0(-1432171810);
bevp_inClassMethod = bevt_29_ta_ph.bem_add_1(bevt_31_ta_ph);
} /* Line: 50*/
} /* Line: 45*/
} /* Line: 45*/
} /* Line: 45*/
if (bevp_inClassMethod == null) {
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_35_ta_ph = beva_node.bem_nlcGet_0();
if (bevt_35_ta_ph == null) {
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 54*/
 else /* Line: 54*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 54*/ {
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass1_bels_1));
bevt_36_ta_ph = bevp_inClassMethod.bem_add_1(bevt_37_ta_ph);
bevt_38_ta_ph = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_36_ta_ph.bem_add_1(bevt_38_ta_ph);
} /* Line: 55*/
if (bevp_allAstElements.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
if (bevp_inClassMethod == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_40_ta_ph = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_40_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
if (bevl_inLine == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_42_ta_ph = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_42_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 57*/ {
if (bevp_f == null) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 58*/ {
bevt_44_ta_ph = beva_node.bem_toString_0();
bevp_f.bemd_1(1757357435, bevt_44_ta_ph);
bevt_46_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_45_ta_ph = bevt_46_ta_ph.bem_newlineGet_0();
bevp_f.bemd_1(1757357435, bevt_45_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
beva_node.bem_print_0();
} /* Line: 62*/
} /* Line: 58*/
bevt_47_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_47_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGet_0() {
return bevp_allAstElements;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGetDirect_0() {
return bevp_allAstElements;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_allAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGet_0() {
return bevp_f;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGetDirect_0() {
return bevp_f;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_fSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_f = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_fSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_f = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGetDirect_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGet_0() {
return bevp_inClassMethod;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGetDirect_0() {
return bevp_inClassMethod;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_inClassMethodSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 24, 25, 25, 26, 26, 26, 26, 35, 35, 35, 35, 36, 36, 36, 37, 39, 39, 39, 41, 42, 44, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 45, 46, 47, 47, 47, 47, 48, 48, 48, 48, 48, 49, 49, 49, 49, 50, 50, 50, 50, 50, 54, 54, 54, 54, 54, 0, 0, 0, 55, 55, 55, 55, 0, 57, 57, 57, 0, 0, 0, 0, 0, 0, 57, 57, 57, 0, 0, 0, 0, 0, 58, 58, 59, 59, 60, 60, 60, 62, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 34, 35, 36, 37, 38, 92, 93, 94, 99, 100, 101, 102, 104, 107, 108, 109, 111, 112, 114, 115, 116, 121, 122, 127, 128, 131, 135, 138, 139, 140, 142, 145, 146, 147, 152, 153, 154, 155, 156, 157, 160, 161, 162, 167, 168, 169, 170, 171, 172, 177, 182, 183, 184, 189, 190, 193, 197, 200, 201, 202, 203, 206, 209, 214, 215, 217, 220, 224, 227, 230, 234, 237, 242, 243, 245, 248, 252, 255, 258, 262, 267, 268, 269, 270, 271, 272, 275, 278, 279, 282, 285, 288, 292, 296, 299, 302, 306, 310, 313, 316, 320, 324, 327, 330, 334, 338, 341, 344, 348};
/* BEGIN LINEINFO 
assign 1 23 27
assign 1 24 28
isEmptyGet 0 24 28
assign 1 25 29
def 1 25 34
assign 1 26 35
new 1 26 35
assign 1 26 36
fileGet 0 26 36
assign 1 26 37
writerGet 0 26 37
assign 1 26 38
open 0 26 38
assign 1 35 92
typenameGet 0 35 92
assign 1 35 93
CLASSGet 0 35 93
assign 1 35 94
equals 1 35 99
assign 1 36 100
new 0 36 100
assign 1 36 101
heldGet 0 36 101
assign 1 36 102
sameType 1 36 102
assign 1 37 104
heldGet 0 37 104
assign 1 39 107
heldGet 0 39 107
assign 1 39 108
namepathGet 0 39 108
assign 1 39 109
toString 0 39 109
assign 1 41 111
assign 1 42 112
assign 1 44 114
typenameGet 0 44 114
assign 1 44 115
METHODGet 0 44 115
assign 1 44 116
equals 1 44 121
assign 1 44 122
def 1 44 127
assign 1 0 128
assign 1 0 131
assign 1 0 135
assign 1 45 138
new 0 45 138
assign 1 45 139
heldGet 0 45 139
assign 1 45 140
sameType 1 45 140
assign 1 46 142
heldGet 0 46 142
assign 1 47 145
heldGet 0 47 145
assign 1 47 146
orgNameGet 0 47 146
assign 1 47 147
def 1 47 152
assign 1 48 153
new 0 48 153
assign 1 48 154
add 1 48 154
assign 1 48 155
heldGet 0 48 155
assign 1 48 156
orgNameGet 0 48 156
assign 1 48 157
add 1 48 157
assign 1 49 160
heldGet 0 49 160
assign 1 49 161
nameGet 0 49 161
assign 1 49 162
def 1 49 167
assign 1 50 168
new 0 50 168
assign 1 50 169
add 1 50 169
assign 1 50 170
heldGet 0 50 170
assign 1 50 171
nameGet 0 50 171
assign 1 50 172
add 1 50 172
assign 1 54 177
def 1 54 182
assign 1 54 183
nlcGet 0 54 183
assign 1 54 184
def 1 54 189
assign 1 0 190
assign 1 0 193
assign 1 0 197
assign 1 55 200
new 0 55 200
assign 1 55 201
add 1 55 201
assign 1 55 202
nlcGet 0 55 202
assign 1 55 203
add 1 55 203
assign 1 0 206
assign 1 57 209
def 1 57 214
assign 1 57 215
has 1 57 215
assign 1 0 217
assign 1 0 220
assign 1 0 224
assign 1 0 227
assign 1 0 230
assign 1 0 234
assign 1 57 237
def 1 57 242
assign 1 57 243
has 1 57 243
assign 1 0 245
assign 1 0 248
assign 1 0 252
assign 1 0 255
assign 1 0 258
assign 1 58 262
def 1 58 267
assign 1 59 268
toString 0 59 268
write 1 59 269
assign 1 60 270
new 0 60 270
assign 1 60 271
newlineGet 0 60 271
write 1 60 272
print 0 62 275
assign 1 65 278
nextDescendGet 0 65 278
return 1 65 279
return 1 0 282
return 1 0 285
assign 1 0 288
assign 1 0 292
return 1 0 296
return 1 0 299
assign 1 0 302
assign 1 0 306
return 1 0 310
return 1 0 313
assign 1 0 316
assign 1 0 320
return 1 0 324
return 1 0 327
assign 1 0 330
assign 1 0 334
return 1 0 338
return 1 0 341
assign 1 0 344
assign 1 0 348
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1498999575: return bem_inClassGet_0();
case 1794395999: return bem_fieldNamesGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case -178385347: return bem_iteratorGet_0();
case 1258729534: return bem_echo_0();
case -1564846521: return bem_constGet_0();
case 1562650783: return bem_fieldIteratorGet_0();
case -2087672163: return bem_fGetDirect_0();
case -1221104789: return bem_sourceFileNameGet_0();
case -716245305: return bem_printAstElementsGet_0();
case 776344141: return bem_allAstElementsGetDirect_0();
case -1253293660: return bem_serializeToString_0();
case 307193318: return bem_serializeContents_0();
case 942507611: return bem_buildGetDirect_0();
case 939713627: return bem_print_0();
case 1046741081: return bem_allAstElementsGet_0();
case 437071357: return bem_inClassGetDirect_0();
case 1460710096: return bem_tagGet_0();
case 2037996040: return bem_create_0();
case -1906768398: return bem_classNameGet_0();
case 1878268220: return bem_buildGet_0();
case -124125161: return bem_printAstElementsGetDirect_0();
case -249375382: return bem_transGetDirect_0();
case -731536791: return bem_fGet_0();
case 1774328609: return bem_inClassMethodGet_0();
case 1004829909: return bem_transGet_0();
case 1941247303: return bem_ntypesGet_0();
case 873076018: return bem_new_0();
case -2070846101: return bem_hashGet_0();
case -1422909302: return bem_inClassMethodGetDirect_0();
case 1640157629: return bem_toString_0();
case -1772344344: return bem_ntypesGetDirect_0();
case 309126939: return bem_constGetDirect_0();
case 62239394: return bem_deserializeClassNameGet_0();
case -1036391864: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -645913487: return bem_ntypesSet_1(bevd_0);
case -1822218971: return bem_transSetDirect_1(bevd_0);
case -1203116468: return bem_inClassMethodSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case -118274675: return bem_allAstElementsSet_1(bevd_0);
case -1159997008: return bem_constSet_1(bevd_0);
case -1349694791: return bem_begin_1(bevd_0);
case -1307348296: return bem_buildSetDirect_1(bevd_0);
case -1793426904: return bem_end_1(bevd_0);
case 4039371: return bem_ntypesSetDirect_1(bevd_0);
case -1873582132: return bem_allAstElementsSetDirect_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -290527812: return bem_inClassSet_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case 650575509: return bem_printAstElementsSetDirect_1(bevd_0);
case 47684234: return bem_buildSet_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -1174912515: return bem_printAstElementsSet_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2095579650: return bem_inClassSetDirect_1(bevd_0);
case -2027154208: return bem_constSetDirect_1(bevd_0);
case 1276390583: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 599572972: return bem_fSetDirect_1(bevd_0);
case -364587754: return bem_transSet_1(bevd_0);
case -1548784804: return bem_inClassMethodSet_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -1490666181: return bem_fSet_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1988117707: return bem_new_2((BEC_2_9_3_ContainerSet) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass1_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass1_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass1();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst = (BEC_3_5_5_5_BuildVisitPass1) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass1.bece_BEC_3_5_5_5_BuildVisitPass1_bevs_type;
}
}
}
