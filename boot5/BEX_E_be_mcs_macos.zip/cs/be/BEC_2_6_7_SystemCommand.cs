namespace be {

using System;
using System.Diagnostics;
/* IO:File: source/extended/Command.be */
public sealed class BEC_2_6_7_SystemCommand : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }
static BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_7_SystemCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_7_SystemCommand_bels_1, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_2 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static new BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_2_9_4_ContainerList bevp_commands;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_listNew_1(BEC_2_9_4_ContainerList beva__commands) {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevp_commands = beva__commands;
bevp_command = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
bevt_0_tmpany_loop = bevp_commands.bem_iteratorGet_0();
while (true)
 /* Line: 46 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 46 */ {
bevl_c = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1532131234);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(bevp_command);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_7_SystemCommand_bels_1));
bevp_command.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 48 */
bevp_command.bem_addValue_1(bevl_c);
} /* Line: 50 */
 else  /* Line: 46 */ {
break;
} /* Line: 46 */
} /* Line: 46 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_3_MathInt bevl_cl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_cmdi = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
 /* Line: 62 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_0;
bevl_sp = bevp_command.bem_find_1(bevt_0_tmpany_phold);
if (bevl_sp == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 64 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_1;
bevl_cmdRun = bevp_command.bem_substring_2(bevt_2_tmpany_phold, bevl_sp);
bevt_4_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_2;
bevt_3_tmpany_phold = bevl_sp.bem_add_1(bevt_4_tmpany_phold);
bevl_cmdArgs = bevp_command.bem_substring_1(bevt_3_tmpany_phold);
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_cmdRun = bevp_command;
bevl_cmdArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
} /* Line: 69 */

          bevi_p = new Process();
          bevi_p.StartInfo.FileName = bevl_cmdRun.bems_toCsString();
          bevi_p.StartInfo.Arguments = bevl_cmdArgs.bems_toCsString();
          bevi_p.StartInfo.CreateNoWindow = true;
          bevi_p.StartInfo.UseShellExecute = false;
          bevi_p.StartInfo.RedirectStandardOutput = true;   
          //bevi_p.StartInfo.WorkingDirectory = strWorkingDirectory;
          bevi_p.Start();
          //bevi_p.StandardOutput.ReadToEnd();
          //bevi_p.WaitForExit();
          } /* Line: 73 */
if (bevp_commands == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 89 */ {
bevl_cl = bevp_commands.bem_sizeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 96 */ {
if (bevl_i.bevi_int < bevl_cl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevl_cmdi = (BEC_2_4_6_TextString) bevp_commands.bem_get_1(bevl_i);
bevl_i.bevi_int++;
} /* Line: 96 */
 else  /* Line: 96 */ {
break;
} /* Line: 96 */
} /* Line: 96 */
} /* Line: 105 */
 else  /* Line: 111 */ {
} /* Line: 113 */
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 132 */ {
return bevp_outputReader;
} /* Line: 133 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.StandardOutput.BaseStream;
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 151 */ {
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 154 */
} /* Line: 152 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 156 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_outputContentGet_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_ee = null;
BEC_3_2_4_6_IOFileReader bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemCommand bevt_1_tmpany_phold = null;
try  /* Line: 175 */ {
bevt_1_tmpany_phold = (BEC_2_6_7_SystemCommand) bem_open_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_outputGet_0();
bevl_res = bevt_0_tmpany_phold.bem_readString_0();
bem_close_0();
} /* Line: 177 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
try  /* Line: 179 */ {
bem_close_0();
} /* Line: 180 */
 catch (System.Exception beve_1) {
bevl_ee = (be.BECS_ThrowBack.handleThrow(beve_1));
} /* Line: 181 */
} /* Line: 181 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGet_0() {
return bevp_commands;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGetDirect_0() {
return bevp_commands;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() {
return bevp_outputReader;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGetDirect_0() {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {37, 43, 45, 46, 0, 46, 46, 47, 47, 48, 48, 50, 55, 56, 56, 63, 63, 64, 64, 65, 65, 66, 66, 66, 68, 69, 89, 89, 90, 96, 96, 96, 97, 96, 121, 125, 132, 132, 133, 135, 146, 147, 152, 152, 153, 154, 160, 176, 176, 176, 177, 180, 183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 36, 37, 38, 38, 41, 43, 44, 45, 47, 48, 50, 60, 61, 62, 80, 81, 82, 87, 88, 89, 90, 91, 92, 95, 96, 110, 115, 116, 117, 120, 125, 126, 127, 136, 139, 144, 149, 150, 152, 155, 156, 162, 167, 168, 169, 178, 190, 191, 192, 193, 198, 204, 207, 210, 213, 217, 221, 224, 227, 231, 235, 238, 241, 245};
/* BEGIN LINEINFO 
assign 1 37 26
assign 1 43 36
assign 1 45 37
new 0 45 37
assign 1 46 38
iteratorGet 0 0 38
assign 1 46 41
hasNextGet 0 46 41
assign 1 46 43
nextGet 0 46 43
assign 1 47 44
new 0 47 44
assign 1 47 45
notEmpty 1 47 45
assign 1 48 47
new 0 48 47
addValue 1 48 48
addValue 1 50 50
new 1 55 60
assign 1 56 61
run 0 56 61
return 1 56 62
assign 1 63 80
new 0 63 80
assign 1 63 81
find 1 63 81
assign 1 64 82
def 1 64 87
assign 1 65 88
new 0 65 88
assign 1 65 89
substring 2 65 89
assign 1 66 90
new 0 66 90
assign 1 66 91
add 1 66 91
assign 1 66 92
substring 1 66 92
assign 1 68 95
assign 1 69 96
new 0 69 96
assign 1 89 110
def 1 89 115
assign 1 90 116
sizeGet 0 90 116
assign 1 96 117
new 0 96 117
assign 1 96 120
lesser 1 96 125
assign 1 97 126
get 1 97 126
incrementValue 0 96 127
return 1 121 136
run 0 125 139
assign 1 132 144
def 1 132 149
return 1 133 150
assign 1 135 152
new 0 135 152
extOpen 0 146 155
return 1 147 156
assign 1 152 162
def 1 152 167
close 0 153 168
assign 1 154 169
closeOutput 0 160 178
assign 1 176 190
open 0 176 190
assign 1 176 191
outputGet 0 176 191
assign 1 176 192
readString 0 176 192
close 0 177 193
close 0 180 198
return 1 183 204
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -52637312: return bem_run_0();
case 182116785: return bem_outputReaderGetDirect_0();
case 1516938819: return bem_commandGetDirect_0();
case 932356395: return bem_commandGet_0();
case -1852877275: return bem_new_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case 642173546: return bem_open_0();
case 77620147: return bem_close_0();
case -1638682249: return bem_commandsGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -236887613: return bem_classNameGet_0();
case 1076647192: return bem_create_0();
case -1251020264: return bem_outputContentGet_0();
case -2092760709: return bem_once_0();
case 1359360249: return bem_echo_0();
case 165563847: return bem_commandsGetDirect_0();
case 1064677251: return bem_many_0();
case 605836827: return bem_sourceFileNameGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 928457034: return bem_serializeContents_0();
case -1430066973: return bem_print_0();
case -323661464: return bem_serializeToString_0();
case 849387251: return bem_toAny_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
case 996718380: return bem_toString_0();
case 316368181: return bem_closeOutput_0();
case -1369483363: return bem_fieldNamesGet_0();
case 864393987: return bem_tagGet_0();
case 622093872: return bem_outputGet_0();
case -1008347444: return bem_outputReaderGet_0();
case 2070502838: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -960159496: return bem_otherClass_1(bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1260677055: return bem_listNew_1((BEC_2_9_4_ContainerList) bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -46552515: return bem_commandsSet_1(bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case 848194253: return bem_commandSet_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -256618560: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case 791078773: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1205534451: return bem_outputReaderSet_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 726023812: return bem_outputReaderSetDirect_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case 915548745: return bem_commandSetDirect_1(bevd_0);
case -483957326: return bem_commandsSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
}
