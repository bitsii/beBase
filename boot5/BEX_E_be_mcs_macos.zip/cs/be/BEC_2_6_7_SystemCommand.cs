namespace be {

using System;
using System.Diagnostics;
/* IO:File: source/extended/Command.be */
public sealed class BEC_2_6_7_SystemCommand : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }
static BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_7_SystemCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_7_SystemCommand_bels_0, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_7_SystemCommand_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {};
public static new BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static new BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bem_new_1(beva__command);
bevt_0_tmpany_phold = bem_run_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
 /* Line: 50 */ {
bevt_0_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_0;
bevl_sp = bevp_command.bem_find_1(bevt_0_tmpany_phold);
if (bevl_sp == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_2_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_1;
bevl_cmdRun = bevp_command.bem_substring_2(bevt_2_tmpany_phold, bevl_sp);
bevt_4_tmpany_phold = bece_BEC_2_6_7_SystemCommand_bevo_2;
bevt_3_tmpany_phold = bevl_sp.bem_add_1(bevt_4_tmpany_phold);
bevl_cmdArgs = bevp_command.bem_substring_1(bevt_3_tmpany_phold);
} /* Line: 54 */
 else  /* Line: 55 */ {
bevl_cmdRun = bevp_command;
bevl_cmdArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_1));
} /* Line: 57 */

          bevi_p = new Process();
          bevi_p.StartInfo.FileName = bevl_cmdRun.bems_toCsString();
          bevi_p.StartInfo.Arguments = bevl_cmdArgs.bems_toCsString();
          bevi_p.StartInfo.CreateNoWindow = true;
          bevi_p.StartInfo.UseShellExecute = false;
          bevi_p.StartInfo.RedirectStandardOutput = true;   
          //bevi_p.StartInfo.WorkingDirectory = strWorkingDirectory;
          bevi_p.Start();
          //bevi_p.StandardOutput.ReadToEnd();
          //bevi_p.WaitForExit();
          } /* Line: 61 */
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 93 */ {
return bevp_outputReader;
} /* Line: 94 */
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.StandardOutput.BaseStream;
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 114 */
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {38, 43, 44, 44, 51, 51, 52, 52, 53, 53, 54, 54, 54, 56, 57, 82, 86, 93, 93, 94, 96, 107, 108, 112, 112, 113, 114, 119, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 30, 31, 32, 45, 46, 47, 52, 53, 54, 55, 56, 57, 60, 61, 75, 78, 83, 88, 89, 91, 94, 95, 99, 104, 105, 106, 111, 117, 120, 124, 127};
/* BEGIN LINEINFO 
assign 1 38 25
new 1 43 30
assign 1 44 31
run 0 44 31
return 1 44 32
assign 1 51 45
new 0 51 45
assign 1 51 46
find 1 51 46
assign 1 52 47
def 1 52 52
assign 1 53 53
new 0 53 53
assign 1 53 54
substring 2 53 54
assign 1 54 55
new 0 54 55
assign 1 54 56
add 1 54 56
assign 1 54 57
substring 1 54 57
assign 1 56 60
assign 1 57 61
new 0 57 61
return 1 82 75
run 0 86 78
assign 1 93 83
def 1 93 88
return 1 94 89
assign 1 96 91
new 0 96 91
extOpen 0 107 94
return 1 108 95
assign 1 112 99
def 1 112 104
close 0 113 105
assign 1 114 106
closeOutput 0 119 111
return 1 0 117
assign 1 0 120
return 1 0 124
assign 1 0 127
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1874352577: return bem_many_0();
case -363466581: return bem_iteratorGet_0();
case 191829922: return bem_closeOutput_0();
case -649794280: return bem_echo_0();
case 823263979: return bem_tagGet_0();
case -1000431791: return bem_copy_0();
case -788077321: return bem_classNameGet_0();
case -1768554896: return bem_hashGet_0();
case -1961384722: return bem_once_0();
case -1869194774: return bem_toAny_0();
case -143898336: return bem_outputReaderGet_0();
case -686751458: return bem_run_0();
case 607172645: return bem_toString_0();
case -519318246: return bem_open_0();
case 31427635: return bem_serializationIteratorGet_0();
case 2094126469: return bem_serializeToString_0();
case -1384853896: return bem_serializeContents_0();
case -1465285966: return bem_close_0();
case -948191759: return bem_commandGet_0();
case -618905808: return bem_print_0();
case 605551831: return bem_create_0();
case 1718503463: return bem_sourceFileNameGet_0();
case 994125870: return bem_fieldIteratorGet_0();
case 277726065: return bem_new_0();
case 1748826999: return bem_outputGet_0();
case 2008488187: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1637365955: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case -1263127801: return bem_sameObject_1(bevd_0);
case 11747238: return bem_defined_1(bevd_0);
case 277308251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -605365957: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1129917483: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1808514742: return bem_commandSet_1(bevd_0);
case 1242105458: return bem_def_1(bevd_0);
case 411925173: return bem_sameType_1(bevd_0);
case 1887876059: return bem_undefined_1(bevd_0);
case 831887130: return bem_equals_1(bevd_0);
case 2111682385: return bem_undef_1(bevd_0);
case 1112246860: return bem_notEquals_1(bevd_0);
case -2027172866: return bem_sameClass_1(bevd_0);
case -552291791: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -547433207: return bem_copyTo_1(bevd_0);
case 1220223304: return bem_otherClass_1(bevd_0);
case 926344794: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 197535869: return bem_otherType_1(bevd_0);
case -1723360893: return bem_outputReaderSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -129206367: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1992907065: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1805532369: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1779420493: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1717448787: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1586496733: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1946581493: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
}
