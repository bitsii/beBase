namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet : BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
static BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static new BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {199, 199, 203, 204, 205, 206, 207, 208};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 199 14
new 0 199 14
new 1 199 15
assign 1 203 19
new 1 203 19
assign 1 204 20
assign 1 205 21
new 0 205 21
assign 1 206 22
new 0 206 22
assign 1 207 23
new 0 207 23
assign 1 208 24
new 0 208 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 39762284: return bem_copy_0();
case -375288944: return bem_deserializeClassNameGet_0();
case 372560497: return bem_sourceFileNameGet_0();
case -1312893708: return bem_sizeGetDirect_0();
case 732717288: return bem_relGet_0();
case 1753023826: return bem_keyIteratorGet_0();
case 463617467: return bem_once_0();
case 804193235: return bem_baseNodeGetDirect_0();
case 966788565: return bem_serializeContents_0();
case -1292012324: return bem_relGetDirect_0();
case -1664007235: return bem_fieldIteratorGet_0();
case -1365591442: return bem_nodesGet_0();
case 1423489944: return bem_multiGetDirect_0();
case 891560596: return bem_toAny_0();
case -711020340: return bem_slotsGet_0();
case -1999254763: return bem_innerPutAddedGet_0();
case -365463436: return bem_nodeIteratorGet_0();
case -1347779508: return bem_innerPutAddedGetDirect_0();
case 1105191947: return bem_isEmptyGet_0();
case -2038208379: return bem_hashGet_0();
case -1388693079: return bem_iteratorGet_0();
case 1410581559: return bem_new_0();
case 526296627: return bem_create_0();
case 2109118158: return bem_toString_0();
case -1506213847: return bem_clear_0();
case -1562425827: return bem_setIteratorGet_0();
case -378593941: return bem_serializeToString_0();
case -1695576573: return bem_fieldNamesGet_0();
case 1639592725: return bem_sizeGet_0();
case 1820222231: return bem_print_0();
case 864392811: return bem_slotsGetDirect_0();
case -1621033763: return bem_classNameGet_0();
case 1483974757: return bem_moduGet_0();
case -50050173: return bem_many_0();
case -643333614: return bem_moduGetDirect_0();
case -1435074057: return bem_tagGet_0();
case -1947638512: return bem_baseNodeGet_0();
case 2040818337: return bem_keysGet_0();
case 1159725397: return bem_multiGet_0();
case 1941027794: return bem_serializationIteratorGet_0();
case 1498523833: return bem_notEmptyGet_0();
case 58718604: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1455520849: return bem_undef_1(bevd_0);
case -1511698342: return bem_notEquals_1(bevd_0);
case 1157301853: return bem_addValue_1(bevd_0);
case -1562713873: return bem_equals_1(bevd_0);
case 422542432: return bem_defined_1(bevd_0);
case 1150415934: return bem_sameType_1(bevd_0);
case 328764114: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 61327064: return bem_slotsSetDirect_1(bevd_0);
case 102576771: return bem_baseNodeSet_1(bevd_0);
case -1207857481: return bem_innerPutAddedSet_1(bevd_0);
case 2087226838: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1600511282: return bem_sizeSet_1(bevd_0);
case -287873339: return bem_sameObject_1(bevd_0);
case 998273204: return bem_sizeSetDirect_1(bevd_0);
case 482205531: return bem_moduSet_1(bevd_0);
case 1251230934: return bem_undefined_1(bevd_0);
case -583057928: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 134291205: return bem_has_1(bevd_0);
case -749107983: return bem_multiSetDirect_1(bevd_0);
case -1703683032: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -488613425: return bem_slotsSet_1(bevd_0);
case 537810448: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1812079184: return bem_otherType_1(bevd_0);
case 1750704964: return bem_baseNodeSetDirect_1(bevd_0);
case -490319654: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2051460262: return bem_def_1(bevd_0);
case 772105407: return bem_put_1(bevd_0);
case 1013364383: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1066928423: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1161328836: return bem_innerPutAddedSetDirect_1(bevd_0);
case 463884319: return bem_copyTo_1(bevd_0);
case -413408753: return bem_otherClass_1(bevd_0);
case 507180394: return bem_multiSet_1(bevd_0);
case 2136465215: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1854916705: return bem_sameClass_1(bevd_0);
case 1267960718: return bem_delete_1(bevd_0);
case -2144659703: return bem_relSetDirect_1(bevd_0);
case -207284822: return bem_get_1(bevd_0);
case 467538942: return bem_relSet_1(bevd_0);
case 855851887: return bem_moduSetDirect_1(bevd_0);
case -1399104214: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1460908619: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -450284664: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1199360949: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -122254137: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1589994776: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1766146489: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1661600038: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90070391: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -250730141: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentitySet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
}
