namespace be {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_34, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_38, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_64, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_65, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 17));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 38));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_70, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_71, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_72, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_73, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 23));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_76, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_77, 27));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_78, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_79, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_80, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_81, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_82 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_82, 32));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_83 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_83, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_84 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_84, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_85 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_85, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_86 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_87 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_88 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_89 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_90 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_90, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_91 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_92 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_92, 15));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_93 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_93, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_94 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_94, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_95 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_95, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_96 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_96, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_97 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_97, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_98 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_99 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_100 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_101 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_102 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_103 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_104 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_105 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_106 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_107 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_108 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_109 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_110 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_111 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_111, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_112 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_112, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_113 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_114 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_114, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_115 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_115, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_116 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_116, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_117 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_118 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_119 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_120 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_121 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_121, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_122 = {0x62,0x65};
public static new BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static new BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formTarg_1(beva_node);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_invp);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-1954979652);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1781836431);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1218089560);
bevt_9_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold );
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1603259157);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 82 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-810629506);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 82 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(262775325);
if (bevl_first.bevi_bool) /* Line: 83 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 84 */
 else  /* Line: 85 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 86 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 88 */
 else  /* Line: 82 */ {
break;
} /* Line: 82 */
} /* Line: 82 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1218089560);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 133 */
bevt_4_tmpany_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 149 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-810629506);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 149 */ {
bevl_clnode = bevl_ci.bemd_0(262775325);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(1204278482);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1218089560);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(2109118158);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(1204278482);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(1218089560);
bevt_15_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold );
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(1204278482);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1603259157);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-434333342);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(1204278482);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(1218089560);
bevt_26_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold );
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(1204278482);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(1603259157);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-434333342);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 164 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 165 */
} /* Line: 164 */
} /* Line: 155 */
 else  /* Line: 149 */ {
break;
} /* Line: 149 */
} /* Line: 149 */
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 173 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-810629506);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(262775325);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 176 */
 else  /* Line: 173 */ {
break;
} /* Line: 173 */
} /* Line: 173 */
bevl_libe.bem_write_1(bevl_smap);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 186 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 200 */
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(-429780155);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 209 */
bevl_libe.bem_write_1(bevl_main);
bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 215 */ {
bem_saveSyns_0();
} /* Line: 216 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
 else  /* Line: 224 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 226 */
bevt_4_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 228 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1398887079);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1398887079);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 259 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 260 */
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 266 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 267 */
 else  /* Line: 268 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_86));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 269 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_87));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_88));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_89));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1416406110);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(beva_callArgs);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
beva_callArgs = bevt_4_tmpany_phold.bem_add_1(beva_callArgs);
} /* Line: 287 */
 else  /* Line: 288 */ {
beva_callArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_91));
} /* Line: 289 */
bevt_10_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-429780155);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_callArgs);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_5_tmpany_phold;
} /* Line: 291 */
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_20_tmpany_phold = beva_callTarget.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = beva_node.bem_heldGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(-429780155);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_callArgs);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_98));
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 305 */ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 306 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 325 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(1479973442);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_99));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_100));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 330 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-810629506);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(262775325);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1479973442);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(165854807);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(-2042647586);
bevt_21_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 335 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 329 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_101));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_102));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_103));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_104));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_105));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_106));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_107));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_108));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_109));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_110));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_113));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_117));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_118));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_119));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_120));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_122));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 25, 26, 28, 29, 33, 33, 33, 37, 37, 37, 37, 41, 41, 41, 41, 45, 45, 45, 45, 45, 45, 45, 45, 49, 49, 49, 50, 51, 51, 51, 51, 51, 51, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 64, 64, 64, 64, 64, 64, 64, 68, 68, 68, 68, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 71, 71, 71, 76, 76, 77, 79, 79, 79, 79, 81, 82, 0, 82, 82, 84, 86, 86, 88, 88, 88, 88, 88, 88, 92, 92, 92, 97, 97, 97, 98, 100, 100, 100, 100, 100, 103, 103, 103, 103, 105, 105, 105, 107, 107, 107, 107, 107, 110, 110, 110, 110, 110, 110, 112, 112, 112, 114, 119, 120, 121, 127, 127, 127, 132, 133, 133, 133, 133, 135, 135, 144, 146, 147, 148, 149, 149, 151, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 155, 155, 155, 157, 157, 157, 157, 157, 157, 157, 157, 157, 163, 163, 163, 163, 163, 163, 164, 164, 164, 165, 165, 165, 165, 165, 165, 171, 173, 173, 0, 173, 173, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 180, 183, 183, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 189, 190, 193, 194, 194, 195, 197, 198, 198, 198, 198, 198, 198, 198, 199, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 202, 203, 204, 205, 206, 207, 208, 208, 208, 209, 209, 209, 211, 213, 215, 216, 222, 225, 225, 225, 226, 226, 228, 228, 233, 233, 237, 237, 237, 237, 237, 237, 241, 241, 245, 245, 245, 245, 245, 245, 245, 246, 246, 246, 246, 246, 247, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 266, 266, 267, 267, 267, 269, 269, 271, 271, 271, 271, 271, 279, 279, 279, 280, 281, 285, 285, 286, 286, 287, 287, 289, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 291, 293, 293, 293, 293, 293, 293, 293, 293, 293, 293, 293, 297, 298, 305, 305, 306, 308, 309, 309, 314, 314, 322, 322, 323, 324, 324, 324, 324, 324, 325, 325, 325, 327, 327, 327, 329, 329, 329, 330, 330, 330, 330, 0, 330, 330, 331, 331, 332, 332, 332, 333, 333, 334, 334, 335, 341, 345, 346, 351, 351, 355, 355, 359, 359, 363, 363, 367, 367, 371, 371, 375, 375, 380, 380, 386, 386, 391, 391, 395, 395, 395, 395, 395, 395, 399, 399, 403, 403, 403, 403, 403, 408, 408, 408, 408, 408, 408, 408, 413, 413, 413, 413, 413, 413, 413, 415, 417, 417, 417, 422, 422, 426, 426, 430, 430, 430, 430, 435, 435, 439, 440, 440, 441, 445, 446, 446, 447, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {181, 182, 183, 184, 185, 186, 187, 188, 194, 195, 196, 202, 203, 204, 205, 211, 212, 213, 214, 224, 225, 226, 227, 228, 229, 230, 231, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 284, 285, 286, 287, 288, 289, 290, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 350, 351, 352, 353, 354, 355, 356, 357, 358, 358, 361, 363, 365, 368, 369, 371, 372, 373, 374, 375, 376, 382, 383, 384, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 447, 448, 449, 455, 456, 457, 466, 468, 469, 470, 471, 473, 474, 601, 602, 603, 604, 605, 608, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 653, 654, 655, 656, 657, 658, 666, 667, 668, 668, 671, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 711, 712, 713, 714, 715, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 747, 748, 749, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 765, 766, 767, 768, 769, 770, 772, 773, 774, 776, 786, 790, 791, 796, 797, 798, 800, 801, 807, 808, 816, 817, 818, 819, 820, 821, 825, 826, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 987, 992, 993, 994, 995, 998, 999, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1039, 1040, 1042, 1043, 1045, 1046, 1049, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1078, 1079, 1084, 1089, 1090, 1092, 1093, 1094, 1098, 1099, 1130, 1135, 1136, 1137, 1138, 1139, 1140, 1145, 1146, 1147, 1148, 1150, 1151, 1152, 1153, 1154, 1155, 1157, 1158, 1159, 1160, 1160, 1163, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173, 1174, 1175, 1183, 1186, 1187, 1192, 1193, 1197, 1198, 1202, 1203, 1207, 1208, 1212, 1213, 1217, 1218, 1222, 1223, 1227, 1228, 1232, 1233, 1237, 1238, 1246, 1247, 1248, 1249, 1250, 1251, 1255, 1256, 1263, 1264, 1265, 1266, 1267, 1276, 1277, 1278, 1279, 1280, 1281, 1282, 1293, 1294, 1295, 1296, 1297, 1298, 1299, 1300, 1301, 1302, 1303, 1308, 1309, 1313, 1314, 1320, 1321, 1322, 1323, 1327, 1328, 1333, 1334, 1335, 1336, 1341, 1342, 1343, 1344, 1347, 1350, 1353, 1357, 1361, 1364, 1367, 1371};
/* BEGIN LINEINFO 
assign 1 17 181
new 0 17 181
assign 1 18 182
new 0 18 182
assign 1 19 183
new 0 19 183
new 1 23 184
assign 1 25 185
new 0 25 185
assign 1 26 186
new 0 26 186
assign 1 28 187
new 0 28 187
assign 1 29 188
new 0 29 188
assign 1 33 194
formTarg 1 33 194
assign 1 33 195
add 1 33 195
return 1 33 196
assign 1 37 202
formCallTarg 1 37 202
assign 1 37 203
new 0 37 203
assign 1 37 204
add 1 37 204
return 1 37 205
assign 1 41 211
formCallTarg 1 41 211
assign 1 41 212
new 0 41 212
assign 1 41 213
add 1 41 213
return 1 41 214
assign 1 45 224
new 0 45 224
assign 1 45 225
addValue 1 45 225
assign 1 45 226
secondGet 0 45 226
assign 1 45 227
formTarg 1 45 227
assign 1 45 228
addValue 1 45 228
assign 1 45 229
new 0 45 229
assign 1 45 230
addValue 1 45 230
addValue 1 45 231
assign 1 49 252
new 0 49 252
assign 1 49 253
toString 0 49 253
assign 1 49 254
add 1 49 254
incrementValue 0 50 255
assign 1 51 256
new 0 51 256
assign 1 51 257
addValue 1 51 257
assign 1 51 258
addValue 1 51 258
assign 1 51 259
new 0 51 259
assign 1 51 260
addValue 1 51 260
addValue 1 51 261
assign 1 56 262
containedGet 0 56 262
assign 1 56 263
firstGet 0 56 263
assign 1 56 264
containedGet 0 56 264
assign 1 56 265
firstGet 0 56 265
assign 1 56 266
new 0 56 266
assign 1 56 267
add 1 56 267
assign 1 56 268
new 0 56 268
assign 1 56 269
add 1 56 269
assign 1 56 270
finalAssign 4 56 270
addValue 1 56 271
assign 1 64 284
emitNameGet 0 64 284
assign 1 64 285
addValue 1 64 285
assign 1 64 286
new 0 64 286
assign 1 64 287
addValue 1 64 287
assign 1 64 288
addValue 1 64 288
assign 1 64 289
new 0 64 289
addValue 1 64 290
assign 1 68 310
emitNameGet 0 68 310
assign 1 68 311
addValue 1 68 311
assign 1 68 312
new 0 68 312
assign 1 68 313
addValue 1 68 313
addValue 1 68 314
assign 1 69 315
new 0 69 315
assign 1 69 316
addValue 1 69 316
assign 1 69 317
heldGet 0 69 317
assign 1 69 318
namepathGet 0 69 318
assign 1 69 319
getClassConfig 1 69 319
assign 1 69 320
libNameGet 0 69 320
assign 1 69 321
relEmitName 1 69 321
assign 1 69 322
addValue 1 69 322
assign 1 69 323
new 0 69 323
assign 1 69 324
addValue 1 69 324
addValue 1 69 325
assign 1 71 326
new 0 71 326
assign 1 71 327
addValue 1 71 327
addValue 1 71 328
assign 1 76 350
heldGet 0 76 350
assign 1 76 351
synGet 0 76 351
assign 1 77 352
ptyListGet 0 77 352
assign 1 79 353
emitNameGet 0 79 353
assign 1 79 354
addValue 1 79 354
assign 1 79 355
new 0 79 355
addValue 1 79 356
assign 1 81 357
new 0 81 357
assign 1 82 358
iteratorGet 0 0 358
assign 1 82 361
hasNextGet 0 82 361
assign 1 82 363
nextGet 0 82 363
assign 1 84 365
new 0 84 365
assign 1 86 368
new 0 86 368
addValue 1 86 369
assign 1 88 371
addValue 1 88 371
assign 1 88 372
new 0 88 372
assign 1 88 373
addValue 1 88 373
assign 1 88 374
nameGet 0 88 374
assign 1 88 375
addValue 1 88 375
addValue 1 88 376
assign 1 92 382
new 0 92 382
assign 1 92 383
addValue 1 92 383
addValue 1 92 384
assign 1 97 412
heldGet 0 97 412
assign 1 97 413
namepathGet 0 97 413
assign 1 97 414
getClassConfig 1 97 414
assign 1 98 415
getInitialInst 1 98 415
assign 1 100 416
emitNameGet 0 100 416
assign 1 100 417
addValue 1 100 417
assign 1 100 418
new 0 100 418
assign 1 100 419
addValue 1 100 419
addValue 1 100 420
assign 1 103 421
addValue 1 103 421
assign 1 103 422
new 0 103 422
assign 1 103 423
addValue 1 103 423
addValue 1 103 424
assign 1 105 425
new 0 105 425
assign 1 105 426
addValue 1 105 426
addValue 1 105 427
assign 1 107 428
emitNameGet 0 107 428
assign 1 107 429
addValue 1 107 429
assign 1 107 430
new 0 107 430
assign 1 107 431
addValue 1 107 431
addValue 1 107 432
assign 1 110 433
new 0 110 433
assign 1 110 434
addValue 1 110 434
assign 1 110 435
addValue 1 110 435
assign 1 110 436
new 0 110 436
assign 1 110 437
addValue 1 110 437
addValue 1 110 438
assign 1 112 439
new 0 112 439
assign 1 112 440
addValue 1 112 440
addValue 1 112 441
buildPropList 0 114 442
getCode 2 119 447
assign 1 120 448
toString 0 120 448
addValue 1 121 449
assign 1 127 455
new 0 127 455
assign 1 127 456
addValue 1 127 456
addValue 1 127 457
assign 1 132 466
isPropertyGet 0 132 466
assign 1 133 468
new 0 133 468
assign 1 133 469
nameGet 0 133 469
assign 1 133 470
add 1 133 470
return 1 133 471
assign 1 135 473
nameForVar 1 135 473
return 1 135 474
assign 1 144 601
getLibOutput 0 144 601
assign 1 146 602
new 0 146 602
assign 1 147 603
new 0 147 603
assign 1 148 604
new 0 148 604
assign 1 149 605
iteratorGet 0 149 605
assign 1 149 608
hasNextGet 0 149 608
assign 1 151 610
nextGet 0 151 610
assign 1 153 611
new 0 153 611
assign 1 153 612
addValue 1 153 612
assign 1 153 613
addValue 1 153 613
assign 1 153 614
heldGet 0 153 614
assign 1 153 615
namepathGet 0 153 615
assign 1 153 616
toString 0 153 616
assign 1 153 617
addValue 1 153 617
assign 1 153 618
addValue 1 153 618
assign 1 153 619
new 0 153 619
assign 1 153 620
addValue 1 153 620
assign 1 153 621
heldGet 0 153 621
assign 1 153 622
namepathGet 0 153 622
assign 1 153 623
getClassConfig 1 153 623
assign 1 153 624
libNameGet 0 153 624
assign 1 153 625
relEmitName 1 153 625
assign 1 153 626
addValue 1 153 626
assign 1 153 627
new 0 153 627
assign 1 153 628
addValue 1 153 628
addValue 1 153 629
assign 1 155 630
heldGet 0 155 630
assign 1 155 631
synGet 0 155 631
assign 1 155 632
hasDefaultGet 0 155 632
assign 1 157 634
new 0 157 634
assign 1 157 635
heldGet 0 157 635
assign 1 157 636
namepathGet 0 157 636
assign 1 157 637
getClassConfig 1 157 637
assign 1 157 638
libNameGet 0 157 638
assign 1 157 639
relEmitName 1 157 639
assign 1 157 640
add 1 157 640
assign 1 157 641
new 0 157 641
assign 1 157 642
add 1 157 642
assign 1 163 643
new 0 163 643
assign 1 163 644
addValue 1 163 644
assign 1 163 645
addValue 1 163 645
assign 1 163 646
new 0 163 646
assign 1 163 647
addValue 1 163 647
addValue 1 163 648
assign 1 164 649
heldGet 0 164 649
assign 1 164 650
synGet 0 164 650
assign 1 164 651
hasDefaultGet 0 164 651
assign 1 165 653
new 0 165 653
assign 1 165 654
addValue 1 165 654
assign 1 165 655
addValue 1 165 655
assign 1 165 656
new 0 165 656
assign 1 165 657
addValue 1 165 657
addValue 1 165 658
assign 1 171 666
new 0 171 666
assign 1 173 667
keysGet 0 173 667
assign 1 173 668
iteratorGet 0 0 668
assign 1 173 671
hasNextGet 0 173 671
assign 1 173 673
nextGet 0 173 673
assign 1 175 674
new 0 175 674
assign 1 175 675
addValue 1 175 675
assign 1 175 676
new 0 175 676
assign 1 175 677
quoteGet 0 175 677
assign 1 175 678
addValue 1 175 678
assign 1 175 679
addValue 1 175 679
assign 1 175 680
new 0 175 680
assign 1 175 681
quoteGet 0 175 681
assign 1 175 682
addValue 1 175 682
assign 1 175 683
new 0 175 683
assign 1 175 684
addValue 1 175 684
assign 1 175 685
get 1 175 685
assign 1 175 686
addValue 1 175 686
assign 1 175 687
new 0 175 687
assign 1 175 688
addValue 1 175 688
addValue 1 175 689
assign 1 176 690
new 0 176 690
assign 1 176 691
addValue 1 176 691
assign 1 176 692
new 0 176 692
assign 1 176 693
quoteGet 0 176 693
assign 1 176 694
addValue 1 176 694
assign 1 176 695
addValue 1 176 695
assign 1 176 696
new 0 176 696
assign 1 176 697
quoteGet 0 176 697
assign 1 176 698
addValue 1 176 698
assign 1 176 699
new 0 176 699
assign 1 176 700
addValue 1 176 700
assign 1 176 701
get 1 176 701
assign 1 176 702
addValue 1 176 702
assign 1 176 703
new 0 176 703
assign 1 176 704
addValue 1 176 704
addValue 1 176 705
write 1 180 711
assign 1 183 712
usedLibrarysGet 0 183 712
assign 1 183 713
sizeGet 0 183 713
assign 1 183 714
new 0 183 714
assign 1 183 715
equals 1 183 720
assign 1 184 721
new 0 184 721
assign 1 184 722
addValue 1 184 722
addValue 1 184 723
assign 1 185 724
new 0 185 724
assign 1 185 725
addValue 1 185 725
addValue 1 185 726
assign 1 186 727
new 0 186 727
assign 1 186 728
addValue 1 186 728
addValue 1 186 729
write 1 189 731
write 1 190 732
assign 1 193 733
new 0 193 733
assign 1 194 734
mainNameGet 0 194 734
fromString 1 194 735
assign 1 195 736
getClassConfig 1 195 736
assign 1 197 737
new 0 197 737
assign 1 198 738
new 0 198 738
assign 1 198 739
addValue 1 198 739
assign 1 198 740
fullEmitNameGet 0 198 740
assign 1 198 741
addValue 1 198 741
assign 1 198 742
new 0 198 742
assign 1 198 743
addValue 1 198 743
addValue 1 198 744
assign 1 199 745
ownProcessGet 0 199 745
assign 1 200 747
new 0 200 747
assign 1 200 748
addValue 1 200 748
addValue 1 200 749
assign 1 202 751
new 0 202 751
assign 1 202 752
addValue 1 202 752
assign 1 202 753
outputPlatformGet 0 202 753
assign 1 202 754
nameGet 0 202 754
assign 1 202 755
addValue 1 202 755
assign 1 202 756
new 0 202 756
assign 1 202 757
addValue 1 202 757
addValue 1 202 758
write 1 203 759
assign 1 204 760
new 0 204 760
write 1 205 761
write 1 206 762
assign 1 207 763
ownProcessGet 0 207 763
assign 1 208 765
new 0 208 765
assign 1 208 766
addValue 1 208 766
addValue 1 208 767
assign 1 209 768
new 0 209 768
assign 1 209 769
addValue 1 209 769
addValue 1 209 770
write 1 211 772
finishLibOutput 1 213 773
assign 1 215 774
saveSynsGet 0 215 774
saveSyns 0 216 776
assign 1 222 786
isPropertyGet 0 222 786
assign 1 225 790
isArgGet 0 225 790
assign 1 225 791
not 0 225 796
assign 1 226 797
new 0 226 797
addValue 1 226 798
assign 1 228 800
nameForVar 1 228 800
addValue 1 228 801
assign 1 233 807
new 0 233 807
return 1 233 808
assign 1 237 816
new 0 237 816
assign 1 237 817
add 1 237 817
assign 1 237 818
new 0 237 818
assign 1 237 819
add 1 237 819
assign 1 237 820
add 1 237 820
return 1 237 821
assign 1 241 825
new 0 241 825
return 1 241 826
assign 1 245 840
emitNameGet 0 245 840
assign 1 245 841
new 0 245 841
assign 1 245 842
add 1 245 842
assign 1 245 843
add 1 245 843
assign 1 245 844
new 0 245 844
assign 1 245 845
add 1 245 845
assign 1 245 846
addValue 1 245 846
assign 1 246 847
emitNameGet 0 246 847
assign 1 246 848
add 1 246 848
assign 1 246 849
new 0 246 849
assign 1 246 850
add 1 246 850
assign 1 246 851
addValue 1 246 851
return 1 247 852
assign 1 251 866
new 0 251 866
assign 1 251 867
libNameGet 0 251 867
assign 1 251 868
relEmitName 1 251 868
assign 1 251 869
add 1 251 869
assign 1 251 870
new 0 251 870
assign 1 251 871
add 1 251 871
assign 1 251 872
heldGet 0 251 872
assign 1 251 873
literalValueGet 0 251 873
assign 1 251 874
add 1 251 874
assign 1 251 875
new 0 251 875
assign 1 251 876
add 1 251 876
return 1 251 877
assign 1 255 891
new 0 255 891
assign 1 255 892
libNameGet 0 255 892
assign 1 255 893
relEmitName 1 255 893
assign 1 255 894
add 1 255 894
assign 1 255 895
new 0 255 895
assign 1 255 896
add 1 255 896
assign 1 255 897
heldGet 0 255 897
assign 1 255 898
literalValueGet 0 255 898
assign 1 255 899
add 1 255 899
assign 1 255 900
new 0 255 900
assign 1 255 901
add 1 255 901
return 1 255 902
assign 1 260 938
new 0 260 938
assign 1 260 939
libNameGet 0 260 939
assign 1 260 940
relEmitName 1 260 940
assign 1 260 941
add 1 260 941
assign 1 260 942
new 0 260 942
assign 1 260 943
add 1 260 943
assign 1 260 944
emitNameGet 0 260 944
assign 1 260 945
add 1 260 945
assign 1 260 946
new 0 260 946
assign 1 260 947
add 1 260 947
assign 1 260 948
add 1 260 948
assign 1 260 949
new 0 260 949
assign 1 260 950
add 1 260 950
assign 1 260 951
add 1 260 951
assign 1 260 952
new 0 260 952
assign 1 260 953
add 1 260 953
return 1 260 954
assign 1 262 956
new 0 262 956
assign 1 262 957
libNameGet 0 262 957
assign 1 262 958
relEmitName 1 262 958
assign 1 262 959
add 1 262 959
assign 1 262 960
new 0 262 960
assign 1 262 961
add 1 262 961
assign 1 262 962
emitNameGet 0 262 962
assign 1 262 963
add 1 262 963
assign 1 262 964
new 0 262 964
assign 1 262 965
add 1 262 965
assign 1 262 966
add 1 262 966
assign 1 262 967
new 0 262 967
assign 1 262 968
add 1 262 968
assign 1 262 969
add 1 262 969
assign 1 262 970
new 0 262 970
assign 1 262 971
add 1 262 971
return 1 262 972
assign 1 266 987
def 1 266 992
assign 1 267 993
libNameGet 0 267 993
assign 1 267 994
relEmitName 1 267 994
assign 1 267 995
extend 1 267 995
assign 1 269 998
new 0 269 998
assign 1 269 999
extend 1 269 999
assign 1 271 1001
new 0 271 1001
assign 1 271 1002
emitNameGet 0 271 1002
assign 1 271 1003
addValue 1 271 1003
assign 1 271 1004
new 0 271 1004
assign 1 271 1005
addValue 1 271 1005
assign 1 279 1006
new 0 279 1006
assign 1 279 1007
addValue 1 279 1007
addValue 1 279 1008
addValue 1 280 1009
return 1 281 1010
assign 1 285 1039
heldGet 0 285 1039
assign 1 285 1040
superCallGet 0 285 1040
assign 1 286 1042
new 0 286 1042
assign 1 286 1043
notEmpty 1 286 1043
assign 1 287 1045
new 0 287 1045
assign 1 287 1046
add 1 287 1046
assign 1 289 1049
new 0 289 1049
assign 1 291 1051
emitNameGet 0 291 1051
assign 1 291 1052
new 0 291 1052
assign 1 291 1053
add 1 291 1053
assign 1 291 1054
heldGet 0 291 1054
assign 1 291 1055
nameGet 0 291 1055
assign 1 291 1056
add 1 291 1056
assign 1 291 1057
new 0 291 1057
assign 1 291 1058
add 1 291 1058
assign 1 291 1059
add 1 291 1059
assign 1 291 1060
new 0 291 1060
assign 1 291 1061
add 1 291 1061
return 1 291 1062
assign 1 293 1064
new 0 293 1064
assign 1 293 1065
add 1 293 1065
assign 1 293 1066
heldGet 0 293 1066
assign 1 293 1067
nameGet 0 293 1067
assign 1 293 1068
add 1 293 1068
assign 1 293 1069
new 0 293 1069
assign 1 293 1070
add 1 293 1070
assign 1 293 1071
add 1 293 1071
assign 1 293 1072
new 0 293 1072
assign 1 293 1073
add 1 293 1073
return 1 293 1074
assign 1 297 1078
new 0 297 1078
return 1 298 1079
assign 1 305 1084
undef 1 305 1089
assign 1 306 1090
new 0 306 1090
addValue 1 308 1092
assign 1 309 1093
new 0 309 1093
return 1 309 1094
assign 1 314 1098
getLibOutput 0 314 1098
return 1 314 1099
assign 1 322 1130
undef 1 322 1135
assign 1 323 1136
new 0 323 1136
assign 1 324 1137
parentGet 0 324 1137
assign 1 324 1138
fileGet 0 324 1138
assign 1 324 1139
existsGet 0 324 1139
assign 1 324 1140
not 0 324 1145
assign 1 325 1146
parentGet 0 325 1146
assign 1 325 1147
fileGet 0 325 1147
makeDirs 0 325 1148
assign 1 327 1150
fileGet 0 327 1150
assign 1 327 1151
writerGet 0 327 1151
assign 1 327 1152
open 0 327 1152
assign 1 329 1153
paramsGet 0 329 1153
assign 1 329 1154
new 0 329 1154
assign 1 329 1155
has 1 329 1155
assign 1 330 1157
paramsGet 0 330 1157
assign 1 330 1158
new 0 330 1158
assign 1 330 1159
get 1 330 1159
assign 1 330 1160
iteratorGet 0 0 1160
assign 1 330 1163
hasNextGet 0 330 1163
assign 1 330 1165
nextGet 0 330 1165
assign 1 331 1166
apNew 1 331 1166
assign 1 331 1167
fileGet 0 331 1167
assign 1 332 1168
readerGet 0 332 1168
assign 1 332 1169
open 0 332 1169
assign 1 332 1170
readString 0 332 1170
assign 1 333 1171
readerGet 0 333 1171
close 0 333 1172
assign 1 334 1173
countLines 1 334 1173
addValue 1 334 1174
write 1 335 1175
return 1 341 1183
close 0 345 1186
assign 1 346 1187
assign 1 351 1192
new 0 351 1192
return 1 351 1193
assign 1 355 1197
new 0 355 1197
return 1 355 1198
assign 1 359 1202
new 0 359 1202
return 1 359 1203
assign 1 363 1207
new 0 363 1207
return 1 363 1208
assign 1 367 1212
new 0 367 1212
return 1 367 1213
assign 1 371 1217
new 0 371 1217
return 1 371 1218
assign 1 375 1222
new 0 375 1222
return 1 375 1223
assign 1 380 1227
new 0 380 1227
return 1 380 1228
assign 1 386 1232
new 0 386 1232
return 1 386 1233
assign 1 391 1237
new 0 391 1237
return 1 391 1238
assign 1 395 1246
new 0 395 1246
assign 1 395 1247
add 1 395 1247
assign 1 395 1248
new 0 395 1248
assign 1 395 1249
add 1 395 1249
assign 1 395 1250
add 1 395 1250
return 1 395 1251
assign 1 399 1255
new 0 399 1255
return 1 399 1256
assign 1 403 1263
libNameGet 0 403 1263
assign 1 403 1264
relEmitName 1 403 1264
assign 1 403 1265
new 0 403 1265
assign 1 403 1266
add 1 403 1266
return 1 403 1267
assign 1 408 1276
emitNameGet 0 408 1276
assign 1 408 1277
new 0 408 1277
assign 1 408 1278
add 1 408 1278
assign 1 408 1279
new 0 408 1279
assign 1 408 1280
add 1 408 1280
assign 1 408 1281
add 1 408 1281
return 1 408 1282
assign 1 413 1293
emitNameGet 0 413 1293
assign 1 413 1294
addValue 1 413 1294
assign 1 413 1295
new 0 413 1295
assign 1 413 1296
addValue 1 413 1296
assign 1 413 1297
addValue 1 413 1297
assign 1 413 1298
new 0 413 1298
addValue 1 413 1299
addValue 1 415 1300
assign 1 417 1301
new 0 417 1301
assign 1 417 1302
addValue 1 417 1302
addValue 1 417 1303
assign 1 422 1308
new 0 422 1308
return 1 422 1309
assign 1 426 1313
new 0 426 1313
return 1 426 1314
assign 1 430 1320
new 0 430 1320
assign 1 430 1321
add 1 430 1321
assign 1 430 1322
add 1 430 1322
return 1 430 1323
assign 1 435 1327
new 0 435 1327
return 1 435 1328
assign 1 439 1333
getClassConfig 1 439 1333
assign 1 440 1334
fullEmitNameGet 0 440 1334
emitNameSet 1 440 1335
return 1 441 1336
assign 1 445 1341
getLocalClassConfig 1 445 1341
assign 1 446 1342
fullEmitNameGet 0 446 1342
emitNameSet 1 446 1343
return 1 447 1344
return 1 0 1347
return 1 0 1350
assign 1 0 1353
assign 1 0 1357
return 1 0 1361
return 1 0 1364
assign 1 0 1367
assign 1 0 1371
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -234327258: return bem_methodCatchGet_0();
case -874316557: return bem_allOnceDecsGetDirect_0();
case 1558783852: return bem_emitLangGetDirect_0();
case 39762284: return bem_copy_0();
case -1435074057: return bem_tagGet_0();
case -568873211: return bem_loadIds_0();
case -1749695920: return bem_qGetDirect_0();
case 1535682568: return bem_inClassGet_0();
case 1826181669: return bem_buildCreate_0();
case -1163353578: return bem_lastMethodsLinesGetDirect_0();
case 463617467: return bem_once_0();
case 1311383413: return bem_dynMethodsGetDirect_0();
case 1764972742: return bem_falseValueGet_0();
case -1237225319: return bem_afterCast_0();
case 1980410077: return bem_fileExtGet_0();
case 2088820836: return bem_idToNameGet_0();
case -1695576573: return bem_fieldNamesGet_0();
case 1906582964: return bem_instOfGet_0();
case -1572465029: return bem_fullLibEmitNameGet_0();
case -1929079725: return bem_cnodeGet_0();
case -1491397219: return bem_instanceEqualGet_0();
case -849546455: return bem_boolNpGetDirect_0();
case 788504560: return bem_lastMethodsSizeGetDirect_0();
case 526296627: return bem_create_0();
case -1060871050: return bem_buildPropList_0();
case 382185458: return bem_nullValueGet_0();
case 542270287: return bem_synEmitPathGetDirect_0();
case -657985317: return bem_onceDecsGetDirect_0();
case 1412778010: return bem_inClassGetDirect_0();
case 515528789: return bem_buildClassInfo_0();
case 543885184: return bem_libEmitNameGetDirect_0();
case 361949562: return bem_instanceNotEqualGetDirect_0();
case 1250362377: return bem_shlibeGetDirect_0();
case 1525357195: return bem_randGetDirect_0();
case 1344705537: return bem_smnlecsGetDirect_0();
case 1158954705: return bem_constGetDirect_0();
case 2131609381: return bem_buildGet_0();
case 1836372285: return bem_returnTypeGet_0();
case 551460003: return bem_transGetDirect_0();
case 1965216254: return bem_objectCcGet_0();
case 2025863587: return bem_classEndGet_0();
case 2048775587: return bem_floatNpGetDirect_0();
case -1993970420: return bem_classConfGetDirect_0();
case 263427005: return bem_coanyiantReturnsGet_0();
case 1191694375: return bem_stringNpGet_0();
case 1173679485: return bem_classConfGet_0();
case -2141909583: return bem_csynGetDirect_0();
case 1210980485: return bem_inFilePathedGet_0();
case -2120566323: return bem_emitLib_0();
case -833437781: return bem_lastCallGetDirect_0();
case -1516703889: return bem_maxSpillArgsLenGetDirect_0();
case 1238097517: return bem_buildGetDirect_0();
case -1438499890: return bem_methodsGet_0();
case -1633249440: return bem_nullValueGetDirect_0();
case -1621033763: return bem_classNameGet_0();
case -1760090359: return bem_qGet_0();
case 557908485: return bem_superCallsGetDirect_0();
case -1928567716: return bem_baseSmtdDecGet_0();
case -79221149: return bem_mainStartGet_0();
case -1884419071: return bem_smnlcsGet_0();
case -50050173: return bem_many_0();
case 1820222231: return bem_print_0();
case 1914520810: return bem_constGet_0();
case -891156212: return bem_synEmitPathGet_0();
case 1958021954: return bem_classCallsGetDirect_0();
case 1595404417: return bem_ccMethodsGetDirect_0();
case -2038208379: return bem_hashGet_0();
case 1938912481: return bem_mnodeGet_0();
case -299822929: return bem_methodBodyGet_0();
case 557133780: return bem_propDecGet_0();
case 1754272198: return bem_lineCountGetDirect_0();
case -304847336: return bem_msynGetDirect_0();
case 488792398: return bem_returnTypeGetDirect_0();
case -1146989102: return bem_methodCallsGet_0();
case 1796327127: return bem_instanceEqualGetDirect_0();
case 264095515: return bem_mainInClassGet_0();
case -961548554: return bem_exceptDecGet_0();
case 1008600793: return bem_getClassOutput_0();
case -289540403: return bem_ccCacheGet_0();
case -375288944: return bem_deserializeClassNameGet_0();
case -1476857575: return bem_msynGet_0();
case -1463160667: return bem_libEmitNameGet_0();
case 233039268: return bem_preClassGetDirect_0();
case 2065801267: return bem_ntypesGetDirect_0();
case -1525128555: return bem_onceCountGetDirect_0();
case -1494428623: return bem_mnodeGetDirect_0();
case 1562914820: return bem_randGet_0();
case 3368895: return bem_fileExtGetDirect_0();
case 1183295878: return bem_inFilePathedGetDirect_0();
case 2133633591: return bem_ntypesGet_0();
case 906711672: return bem_nlGet_0();
case 261069561: return bem_shlibeGet_0();
case 1088459574: return bem_preClassOutput_0();
case 891560596: return bem_toAny_0();
case 372560497: return bem_sourceFileNameGet_0();
case 809716401: return bem_objectCcGetDirect_0();
case -1125167159: return bem_idToNameGetDirect_0();
case 694760305: return bem_propertyDecsGet_0();
case -623370545: return bem_smnlecsGet_0();
case 779629023: return bem_idToNamePathGet_0();
case -289963775: return bem_preClassGet_0();
case -156235476: return bem_saveIds_0();
case 1821236070: return bem_methodBodyGetDirect_0();
case -809620999: return bem_lastMethodsLinesGet_0();
case 1587608863: return bem_boolNpGet_0();
case -1349643004: return bem_instanceNotEqualGet_0();
case 1921806380: return bem_boolTypeGet_0();
case 723202: return bem_onceDecsGet_0();
case 2098321479: return bem_cnodeGetDirect_0();
case 647456787: return bem_spropDecGet_0();
case 1172789085: return bem_buildInitial_0();
case -1328345947: return bem_floatNpGet_0();
case -290928035: return bem_libEmitPathGet_0();
case 1410581559: return bem_new_0();
case 486916966: return bem_baseMtdDecGet_0();
case 2037750594: return bem_getLibOutput_0();
case 1045661862: return bem_saveSyns_0();
case -1873315975: return bem_mainOutsideNsGet_0();
case 1860646847: return bem_libEmitPathGetDirect_0();
case -2012006644: return bem_superNameGet_0();
case 166898493: return bem_nameToIdGetDirect_0();
case -1664007235: return bem_fieldIteratorGet_0();
case 1758835613: return bem_trueValueGet_0();
case 278758543: return bem_scvpGetDirect_0();
case 181600951: return bem_smnlcsGetDirect_0();
case 1508226077: return bem_classCallsGet_0();
case -1592929330: return bem_lastMethodsSizeGet_0();
case 2109118158: return bem_toString_0();
case 402555874: return bem_lastMethodBodySizeGet_0();
case 1992940158: return bem_classesInDepthOrderGet_0();
case -721740711: return bem_lastMethodBodyLinesGet_0();
case -350767244: return bem_doEmit_0();
case -1809042862: return bem_exceptDecGetDirect_0();
case 1138698887: return bem_trueValueGetDirect_0();
case -1287729450: return bem_callNamesGetDirect_0();
case -1014537274: return bem_lastCallGet_0();
case -1476566858: return bem_classEmitsGet_0();
case -1133237014: return bem_transGet_0();
case 58718604: return bem_echo_0();
case 1933624606: return bem_invpGet_0();
case -2056465720: return bem_beginNs_0();
case -1381102130: return bem_ccMethodsGet_0();
case -378593941: return bem_serializeToString_0();
case -291615565: return bem_callNamesGet_0();
case -928812660: return bem_onceCountGet_0();
case 182996423: return bem_methodCatchGetDirect_0();
case -800482620: return bem_mainEndGet_0();
case 1944080693: return bem_csynGet_0();
case 2015082262: return bem_initialDecGet_0();
case 312938222: return bem_maxDynArgsGetDirect_0();
case -1144921450: return bem_nameToIdGet_0();
case 1135674575: return bem_endNs_0();
case -1894621356: return bem_propertyDecsGetDirect_0();
case 2031644648: return bem_overrideMtdDecGet_0();
case -1669618963: return bem_instOfGetDirect_0();
case 1209559049: return bem_emitLangGet_0();
case -812672973: return bem_objectNpGet_0();
case 501829769: return bem_intNpGetDirect_0();
case 1152610818: return bem_nativeCSlotsGetDirect_0();
case -748550914: return bem_methodsGetDirect_0();
case -1673906750: return bem_classesInDepthOrderGetDirect_0();
case -169127816: return bem_nameToIdPathGet_0();
case 671896545: return bem_runtimeInitGet_0();
case 1405022997: return bem_falseValueGetDirect_0();
case -1316043152: return bem_ccCacheGetDirect_0();
case -1152227429: return bem_maxSpillArgsLenGet_0();
case 1560123246: return bem_scvpGet_0();
case 177591983: return bem_allOnceDecsGet_0();
case 1534086570: return bem_boolCcGet_0();
case -303128284: return bem_objectNpGetDirect_0();
case 1572531501: return bem_useDynMethodsGet_0();
case -1728995219: return bem_nativeCSlotsGet_0();
case 1941027794: return bem_serializationIteratorGet_0();
case -1403751869: return bem_lastMethodBodySizeGetDirect_0();
case -1941344405: return bem_parentConfGet_0();
case 361848931: return bem_lineCountGet_0();
case -1388693079: return bem_iteratorGet_0();
case 1508670394: return bem_classEmitsGetDirect_0();
case -616049392: return bem_methodCallsGetDirect_0();
case -1042217839: return bem_fullLibEmitNameGetDirect_0();
case -1567268527: return bem_superCallsGet_0();
case -44745192: return bem_typeDecGet_0();
case -671201442: return bem_boolCcGetDirect_0();
case -2097970472: return bem_nameToIdPathGetDirect_0();
case 1276467169: return bem_lastMethodBodyLinesGetDirect_0();
case 966788565: return bem_serializeContents_0();
case -685186347: return bem_stringNpGetDirect_0();
case -276579382: return bem_nlGetDirect_0();
case 245696486: return bem_idToNamePathGetDirect_0();
case -838511041: return bem_maxDynArgsGet_0();
case -1673108285: return bem_intNpGet_0();
case -1551713403: return bem_writeBET_0();
case -1552812799: return bem_invpGetDirect_0();
case -1113940222: return bem_parentConfGetDirect_0();
case 1059106422: return bem_dynMethodsGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -652618216: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 2033637734: return bem_boolCcSet_1(bevd_0);
case -844064398: return bem_shlibeSet_1(bevd_0);
case 676535251: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1275942262: return bem_smnlecsSet_1(bevd_0);
case -1644241153: return bem_lineCountSet_1(bevd_0);
case 720146593: return bem_parentConfSet_1(bevd_0);
case 2087226838: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1879575035: return bem_mnodeSetDirect_1(bevd_0);
case -1891017593: return bem_stringNpSet_1(bevd_0);
case 217485357: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1881245681: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -367718700: return bem_idToNamePathSetDirect_1(bevd_0);
case 292792465: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -2059025923: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -517159758: return bem_parentConfSetDirect_1(bevd_0);
case -1797333754: return bem_ccCacheSet_1(bevd_0);
case 2111239091: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1249906509: return bem_cnodeSetDirect_1(bevd_0);
case -383915238: return bem_boolNpSet_1(bevd_0);
case -1889307166: return bem_returnTypeSetDirect_1(bevd_0);
case -1408250373: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1110424797: return bem_csynSetDirect_1(bevd_0);
case 1379462839: return bem_methodsSetDirect_1(bevd_0);
case -1882265402: return bem_qSetDirect_1(bevd_0);
case 852712657: return bem_returnTypeSet_1(bevd_0);
case 798638519: return bem_idToNamePathSet_1(bevd_0);
case 829173481: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1436211913: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -808542514: return bem_nameToIdSetDirect_1(bevd_0);
case 1727063269: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 837428350: return bem_fullLibEmitNameSet_1(bevd_0);
case 1973983979: return bem_lastMethodsLinesSet_1(bevd_0);
case 1794321275: return bem_falseValueSet_1(bevd_0);
case 422542432: return bem_defined_1(bevd_0);
case -557261067: return bem_inClassSetDirect_1(bevd_0);
case -1950364978: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -1134501647: return bem_transSet_1(bevd_0);
case 1524398879: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1006244404: return bem_nullValueSetDirect_1(bevd_0);
case 463884319: return bem_copyTo_1(bevd_0);
case -729479794: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1457957849: return bem_inClassSet_1(bevd_0);
case -959427074: return bem_idToNameSetDirect_1(bevd_0);
case 1272497102: return bem_classCallsSet_1(bevd_0);
case 1146576891: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1331801233: return bem_ntypesSetDirect_1(bevd_0);
case 242026188: return bem_invpSet_1(bevd_0);
case -1511212155: return bem_inFilePathedSetDirect_1(bevd_0);
case -1468110679: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -490319654: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1639368089: return bem_onceCountSetDirect_1(bevd_0);
case 1084045305: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -970630207: return bem_dynMethodsSetDirect_1(bevd_0);
case -105160997: return bem_maxDynArgsSetDirect_1(bevd_0);
case -531130199: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 107703790: return bem_onceDecsSetDirect_1(bevd_0);
case -290806052: return bem_propertyDecsSetDirect_1(bevd_0);
case 1794051346: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1585217221: return bem_stringNpSetDirect_1(bevd_0);
case -1058199856: return bem_instanceEqualSetDirect_1(bevd_0);
case -1849667194: return bem_lastMethodsSizeSet_1(bevd_0);
case -303283603: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -287873339: return bem_sameObject_1(bevd_0);
case -1188834126: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1591694063: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1150415934: return bem_sameType_1(bevd_0);
case -990852922: return bem_methodCatchSet_1(bevd_0);
case -583057928: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 148357881: return bem_shlibeSetDirect_1(bevd_0);
case 2024097056: return bem_randSet_1(bevd_0);
case 496818148: return bem_smnlcsSetDirect_1(bevd_0);
case -9732990: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1991338749: return bem_intNpSet_1(bevd_0);
case 1788883074: return bem_methodCallsSet_1(bevd_0);
case -697925693: return bem_msynSet_1(bevd_0);
case 1789644762: return bem_scvpSet_1(bevd_0);
case 1337145207: return bem_floatNpSet_1(bevd_0);
case -349097034: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1251230934: return bem_undefined_1(bevd_0);
case 1632771976: return bem_callNamesSet_1(bevd_0);
case 831489736: return bem_floatNpSetDirect_1(bevd_0);
case 531195078: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1317070124: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1502936261: return bem_exceptDecSetDirect_1(bevd_0);
case 1559473374: return bem_ccMethodsSetDirect_1(bevd_0);
case 2085336111: return bem_qSet_1(bevd_0);
case 936600922: return bem_ccMethodsSet_1(bevd_0);
case 1294206597: return bem_onceCountSet_1(bevd_0);
case 1516519363: return bem_instOfSetDirect_1(bevd_0);
case -577321578: return bem_synEmitPathSetDirect_1(bevd_0);
case 2136465215: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1711288353: return bem_emitLangSetDirect_1(bevd_0);
case -646320831: return bem_maxDynArgsSet_1(bevd_0);
case 196640450: return bem_callNamesSetDirect_1(bevd_0);
case -1632480364: return bem_buildSet_1(bevd_0);
case -675258880: return bem_fileExtSet_1(bevd_0);
case 1004709629: return bem_superCallsSetDirect_1(bevd_0);
case 1059867869: return bem_methodBodySet_1(bevd_0);
case 328764114: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -722994567: return bem_nlSetDirect_1(bevd_0);
case -944779117: return bem_superCallsSet_1(bevd_0);
case 2137269925: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1199011865: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1110640773: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1212373792: return bem_constSet_1(bevd_0);
case -865743885: return bem_boolNpSetDirect_1(bevd_0);
case -276578687: return bem_smnlecsSetDirect_1(bevd_0);
case 1801075298: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -1048308727: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -97987822: return bem_instanceEqualSet_1(bevd_0);
case 1964342019: return bem_lastMethodBodySizeSet_1(bevd_0);
case -145840176: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1602231251: return bem_intNpSetDirect_1(bevd_0);
case 2115687106: return bem_mnodeSet_1(bevd_0);
case 1672833569: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 322889545: return bem_dynMethodsSet_1(bevd_0);
case 339939754: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -2051460262: return bem_def_1(bevd_0);
case 1485382848: return bem_onceDecsSet_1(bevd_0);
case 1842693706: return bem_libEmitNameSetDirect_1(bevd_0);
case 734265416: return bem_inFilePathedSet_1(bevd_0);
case 152550456: return bem_instanceNotEqualSet_1(bevd_0);
case -1318676750: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -704356993: return bem_scvpSetDirect_1(bevd_0);
case -1511698342: return bem_notEquals_1(bevd_0);
case 1166511807: return bem_smnlcsSet_1(bevd_0);
case 1730418043: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 413846573: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -1640112246: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 2014890982: return bem_nameToIdSet_1(bevd_0);
case -1562713873: return bem_equals_1(bevd_0);
case -393845209: return bem_classEmitsSetDirect_1(bevd_0);
case -1465111366: return bem_maxSpillArgsLenSet_1(bevd_0);
case 448988103: return bem_lastCallSetDirect_1(bevd_0);
case -1131895608: return bem_classConfSet_1(bevd_0);
case 1307212859: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -423290008: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 139981047: return bem_trueValueSetDirect_1(bevd_0);
case 815862100: return bem_nameToIdPathSet_1(bevd_0);
case 1699625277: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1375032861: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 729075656: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2091604653: return bem_invpSetDirect_1(bevd_0);
case -2070632812: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1812079184: return bem_otherType_1(bevd_0);
case -66178835: return bem_classConfSetDirect_1(bevd_0);
case -1901525148: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -625251330: return bem_methodsSet_1(bevd_0);
case 1359291010: return bem_objectNpSet_1(bevd_0);
case 1714725507: return bem_allOnceDecsSetDirect_1(bevd_0);
case 708794896: return bem_instOfSet_1(bevd_0);
case 1328218678: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1455520849: return bem_undef_1(bevd_0);
case -137091418: return bem_exceptDecSet_1(bevd_0);
case 1854916705: return bem_sameClass_1(bevd_0);
case -1496365189: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 2069306316: return bem_ntypesSet_1(bevd_0);
case -660675468: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 228868307: return bem_lastCallSet_1(bevd_0);
case 88505207: return bem_idToNameSet_1(bevd_0);
case -1630856621: return bem_allOnceDecsSet_1(bevd_0);
case 1934876413: return bem_nlSet_1(bevd_0);
case -139053901: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1395274091: return bem_preClassSetDirect_1(bevd_0);
case -620224329: return bem_classEmitsSet_1(bevd_0);
case 345320697: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1696591435: return bem_begin_1(bevd_0);
case 1900435237: return bem_end_1(bevd_0);
case -1134411169: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1867010519: return bem_methodBodySetDirect_1(bevd_0);
case 1770381517: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -790087631: return bem_fileExtSetDirect_1(bevd_0);
case 581631223: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -953664468: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -82062469: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 218881664: return bem_ccCacheSetDirect_1(bevd_0);
case 968540410: return bem_libEmitNameSet_1(bevd_0);
case -893866024: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -2044539037: return bem_buildSetDirect_1(bevd_0);
case 770203026: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1706855020: return bem_classCallsSetDirect_1(bevd_0);
case -2005991951: return bem_randSetDirect_1(bevd_0);
case -2028072447: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -656788052: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -464294724: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1394774010: return bem_nativeCSlotsSet_1(bevd_0);
case -1257607820: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -724777045: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1898795792: return bem_classesInDepthOrderSet_1(bevd_0);
case 1988542700: return bem_cnodeSet_1(bevd_0);
case -127381599: return bem_nullValueSet_1(bevd_0);
case 1297518594: return bem_falseValueSetDirect_1(bevd_0);
case 2003796398: return bem_libEmitPathSetDirect_1(bevd_0);
case -1596538813: return bem_methodCatchSetDirect_1(bevd_0);
case -1107758475: return bem_methodCallsSetDirect_1(bevd_0);
case -2116901388: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -760483685: return bem_lineCountSetDirect_1(bevd_0);
case 1158313319: return bem_preClassSet_1(bevd_0);
case 1750712309: return bem_objectNpSetDirect_1(bevd_0);
case -980434890: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1601243692: return bem_objectCcSetDirect_1(bevd_0);
case 370497472: return bem_trueValueSet_1(bevd_0);
case -405423960: return bem_msynSetDirect_1(bevd_0);
case -215451920: return bem_nameToIdPathSetDirect_1(bevd_0);
case -234584257: return bem_transSetDirect_1(bevd_0);
case -1941304859: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1684661398: return bem_constSetDirect_1(bevd_0);
case 494437004: return bem_emitLangSet_1(bevd_0);
case -1798134854: return bem_libEmitPathSet_1(bevd_0);
case -320001152: return bem_boolCcSetDirect_1(bevd_0);
case -1273709416: return bem_propertyDecsSet_1(bevd_0);
case -571752535: return bem_csynSet_1(bevd_0);
case -2070756798: return bem_synEmitPathSet_1(bevd_0);
case -413408753: return bem_otherClass_1(bevd_0);
case 1138889538: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -627030634: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1766791629: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1199360949: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1647214192: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 60044804: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -122254137: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -793603040: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2126418525: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1265614070: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1942280160: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 258846159: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1661600038: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1589994776: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 544024325: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 90070391: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1731912226: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1460908619: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 268362700: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1766146489: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 147492644: return bem_writeOnceDecs_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -456916595: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1089085243: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -232722551: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1136692412: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1984309752: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -160523275: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 1699530549: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -933044287: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
}
