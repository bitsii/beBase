namespace be {
/* IO:File: source/extended/Json.be */
public sealed class BEC_2_4_7_JsonEscapes : BEC_2_6_6_SystemObject {
public BEC_2_4_7_JsonEscapes() { }
static BEC_2_4_7_JsonEscapes() { }
private static byte[] becc_BEC_2_4_7_JsonEscapes_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x45,0x73,0x63,0x61,0x70,0x65,0x73};
private static byte[] becc_BEC_2_4_7_JsonEscapes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_0 = {0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_1 = {0x5C,0x5C};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_JsonEscapes_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_JsonEscapes_bels_0, 1));
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_2 = {0x08};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_3 = {0x5C,0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_4 = {0x0C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_5 = {0x5C,0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_6 = {0x0A};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_7 = {0x5C,0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_8 = {0x0D};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_9 = {0x5C,0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_10 = {0x09};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_11 = {0x5C,0x74};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_12 = {0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_13 = {0x5C,0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_14 = {0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_15 = {0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_16 = {0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_17 = {0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_18 = {0x74};
public static new BEC_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_inst;

public static new BET_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_type;

public BEC_2_9_3_ContainerMap bevp_toEscapes;
public BEC_2_9_3_ContainerMap bevp_fromEscapes;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_default_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevp_toEscapes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_1));
bevp_toEscapes.bem_put_2(bevt_0_tmpany_phold, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_quoteGet_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_7_JsonEscapes_bevo_0;
bevt_11_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_quoteGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevp_toEscapes.bem_put_2(bevt_4_tmpany_phold, bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_3));
bevp_toEscapes.bem_put_2(bevt_12_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_5));
bevp_toEscapes.bem_put_2(bevt_16_tmpany_phold, bevt_19_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevt_21_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_7));
bevp_toEscapes.bem_put_2(bevt_20_tmpany_phold, bevt_23_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_9));
bevp_toEscapes.bem_put_2(bevt_24_tmpany_phold, bevt_27_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevt_29_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_11));
bevp_toEscapes.bem_put_2(bevt_28_tmpany_phold, bevt_31_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_13));
bevp_toEscapes.bem_put_2(bevt_32_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevp_fromEscapes.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_quoteGet_0();
bevt_41_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_quoteGet_0();
bevp_fromEscapes.bem_put_2(bevt_38_tmpany_phold, bevt_40_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_14));
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_2));
bevp_fromEscapes.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_15));
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevp_fromEscapes.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_16));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevp_fromEscapes.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_17));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevp_fromEscapes.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_18));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevp_fromEscapes.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevp_fromEscapes.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGet_0() {
return bevp_toEscapes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGetDirect_0() {
return bevp_toEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGet_0() {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGetDirect_0() {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {262, 263, 265, 265, 265, 265, 265, 266, 266, 266, 266, 266, 266, 266, 266, 266, 267, 267, 267, 267, 267, 268, 268, 268, 268, 268, 269, 269, 269, 269, 269, 270, 270, 270, 270, 270, 271, 271, 271, 271, 271, 272, 272, 272, 272, 272, 274, 274, 274, 275, 275, 275, 275, 275, 276, 276, 276, 277, 277, 277, 278, 278, 278, 279, 279, 279, 280, 280, 280, 281, 281, 281, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 167, 170, 173, 177, 181, 184, 187, 191};
/* BEGIN LINEINFO 
assign 1 262 92
new 0 262 92
assign 1 263 93
new 0 263 93
assign 1 265 94
new 0 265 94
assign 1 265 95
new 0 265 95
assign 1 265 96
addValue 1 265 96
assign 1 265 97
new 0 265 97
put 2 265 98
assign 1 266 99
new 0 266 99
assign 1 266 100
new 0 266 100
assign 1 266 101
quoteGet 0 266 101
assign 1 266 102
addValue 1 266 102
assign 1 266 103
new 0 266 103
assign 1 266 104
new 0 266 104
assign 1 266 105
quoteGet 0 266 105
assign 1 266 106
add 1 266 106
put 2 266 107
assign 1 267 108
new 0 267 108
assign 1 267 109
new 0 267 109
assign 1 267 110
addValue 1 267 110
assign 1 267 111
new 0 267 111
put 2 267 112
assign 1 268 113
new 0 268 113
assign 1 268 114
new 0 268 114
assign 1 268 115
addValue 1 268 115
assign 1 268 116
new 0 268 116
put 2 268 117
assign 1 269 118
new 0 269 118
assign 1 269 119
new 0 269 119
assign 1 269 120
addValue 1 269 120
assign 1 269 121
new 0 269 121
put 2 269 122
assign 1 270 123
new 0 270 123
assign 1 270 124
new 0 270 124
assign 1 270 125
addValue 1 270 125
assign 1 270 126
new 0 270 126
put 2 270 127
assign 1 271 128
new 0 271 128
assign 1 271 129
new 0 271 129
assign 1 271 130
addValue 1 271 130
assign 1 271 131
new 0 271 131
put 2 271 132
assign 1 272 133
new 0 272 133
assign 1 272 134
new 0 272 134
assign 1 272 135
addValue 1 272 135
assign 1 272 136
new 0 272 136
put 2 272 137
assign 1 274 138
new 0 274 138
assign 1 274 139
new 0 274 139
put 2 274 140
assign 1 275 141
new 0 275 141
assign 1 275 142
quoteGet 0 275 142
assign 1 275 143
new 0 275 143
assign 1 275 144
quoteGet 0 275 144
put 2 275 145
assign 1 276 146
new 0 276 146
assign 1 276 147
new 0 276 147
put 2 276 148
assign 1 277 149
new 0 277 149
assign 1 277 150
new 0 277 150
put 2 277 151
assign 1 278 152
new 0 278 152
assign 1 278 153
new 0 278 153
put 2 278 154
assign 1 279 155
new 0 279 155
assign 1 279 156
new 0 279 156
put 2 279 157
assign 1 280 158
new 0 280 158
assign 1 280 159
new 0 280 159
put 2 280 160
assign 1 281 161
new 0 281 161
assign 1 281 162
new 0 281 162
put 2 281 163
return 1 0 167
return 1 0 170
assign 1 0 173
assign 1 0 177
return 1 0 181
return 1 0 184
assign 1 0 187
assign 1 0 191
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2015254586: return bem_fromEscapesGet_0();
case -1852877275: return bem_new_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -236887613: return bem_classNameGet_0();
case 1076647192: return bem_create_0();
case -2092760709: return bem_once_0();
case 1359360249: return bem_echo_0();
case 1064677251: return bem_many_0();
case -1341754076: return bem_toEscapesGetDirect_0();
case 605836827: return bem_sourceFileNameGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 928457034: return bem_serializeContents_0();
case -1430066973: return bem_print_0();
case -323661464: return bem_serializeToString_0();
case 849387251: return bem_toAny_0();
case -462657523: return bem_fromEscapesGetDirect_0();
case 1910979786: return bem_default_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
case 996718380: return bem_toString_0();
case -2098132877: return bem_toEscapesGet_0();
case -1369483363: return bem_fieldNamesGet_0();
case 864393987: return bem_tagGet_0();
case 2070502838: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1531607006: return bem_toEscapesSetDirect_1(bevd_0);
case -960159496: return bem_otherClass_1(bevd_0);
case -1630636346: return bem_fromEscapesSet_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 338237841: return bem_fromEscapesSetDirect_1(bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1572643853: return bem_toEscapesSet_1(bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_JsonEscapes_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_7_JsonEscapes_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_JsonEscapes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst = (BEC_2_4_7_JsonEscapes) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_type;
}
}
}
