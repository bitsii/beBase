namespace be {
/* IO:File: source/extended/Json.be */
public sealed class BEC_2_4_7_JsonEscapes : BEC_2_6_6_SystemObject {
public BEC_2_4_7_JsonEscapes() { }
static BEC_2_4_7_JsonEscapes() { }
private static byte[] becc_BEC_2_4_7_JsonEscapes_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x45,0x73,0x63,0x61,0x70,0x65,0x73};
private static byte[] becc_BEC_2_4_7_JsonEscapes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_0 = {0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_1 = {0x5C,0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_2 = {0x5C};
private static BEC_2_4_6_TextString bece_BEC_2_4_7_JsonEscapes_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_JsonEscapes_bels_2, 1));
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_3 = {0x08};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_4 = {0x5C,0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_5 = {0x0C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_6 = {0x5C,0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_7 = {0x0A};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_8 = {0x5C,0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_9 = {0x0D};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_10 = {0x5C,0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_11 = {0x09};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_12 = {0x5C,0x74};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_13 = {0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_14 = {0x5C,0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_15 = {0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_16 = {0x5C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_17 = {0x62};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_18 = {0x08};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_19 = {0x66};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_20 = {0x0C};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_21 = {0x6E};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_22 = {0x0A};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_23 = {0x72};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_24 = {0x0D};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_25 = {0x74};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_26 = {0x09};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_27 = {0x2F};
private static byte[] bece_BEC_2_4_7_JsonEscapes_bels_28 = {0x2F};
public static new BEC_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_inst;

public static new BET_2_4_7_JsonEscapes bece_BEC_2_4_7_JsonEscapes_bevs_type;

public BEC_2_9_3_ContainerMap bevp_toEscapes;
public BEC_2_9_3_ContainerMap bevp_fromEscapes;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_default_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
bevp_toEscapes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_0));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_1));
bevp_toEscapes.bem_put_2(bevt_0_tmpany_phold, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_quoteGet_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_7_JsonEscapes_bevo_0;
bevt_11_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_quoteGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevp_toEscapes.bem_put_2(bevt_4_tmpany_phold, bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_3));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_4));
bevp_toEscapes.bem_put_2(bevt_12_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_5));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_6));
bevp_toEscapes.bem_put_2(bevt_16_tmpany_phold, bevt_19_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_7));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevt_21_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_8));
bevp_toEscapes.bem_put_2(bevt_20_tmpany_phold, bevt_23_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_9));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_10));
bevp_toEscapes.bem_put_2(bevt_24_tmpany_phold, bevt_27_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_11));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevt_29_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_12));
bevp_toEscapes.bem_put_2(bevt_28_tmpany_phold, bevt_31_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_13));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_JsonEscapes_bels_14));
bevp_toEscapes.bem_put_2(bevt_32_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_15));
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_16));
bevp_fromEscapes.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_quoteGet_0();
bevt_41_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_quoteGet_0();
bevp_fromEscapes.bem_put_2(bevt_38_tmpany_phold, bevt_40_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_17));
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_18));
bevp_fromEscapes.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_19));
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_20));
bevp_fromEscapes.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_21));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_22));
bevp_fromEscapes.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_23));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_24));
bevp_fromEscapes.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_25));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_26));
bevp_fromEscapes.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_27));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_JsonEscapes_bels_28));
bevp_fromEscapes.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGet_0() {
return bevp_toEscapes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_toEscapesGetDirect_0() {
return bevp_toEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_toEscapesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGet_0() {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_fromEscapesGetDirect_0() {
return bevp_fromEscapes;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_7_JsonEscapes bem_fromEscapesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromEscapes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {263, 264, 266, 266, 266, 266, 266, 267, 267, 267, 267, 267, 267, 267, 267, 267, 268, 268, 268, 268, 268, 269, 269, 269, 269, 269, 270, 270, 270, 270, 270, 271, 271, 271, 271, 271, 272, 272, 272, 272, 272, 273, 273, 273, 273, 273, 275, 275, 275, 276, 276, 276, 276, 276, 277, 277, 277, 278, 278, 278, 279, 279, 279, 280, 280, 280, 281, 281, 281, 282, 282, 282, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 177, 180, 183, 187, 191, 194, 197, 201};
/* BEGIN LINEINFO 
assign 1 263 102
new 0 263 102
assign 1 264 103
new 0 264 103
assign 1 266 104
new 0 266 104
assign 1 266 105
new 0 266 105
assign 1 266 106
addValue 1 266 106
assign 1 266 107
new 0 266 107
put 2 266 108
assign 1 267 109
new 0 267 109
assign 1 267 110
new 0 267 110
assign 1 267 111
quoteGet 0 267 111
assign 1 267 112
addValue 1 267 112
assign 1 267 113
new 0 267 113
assign 1 267 114
new 0 267 114
assign 1 267 115
quoteGet 0 267 115
assign 1 267 116
add 1 267 116
put 2 267 117
assign 1 268 118
new 0 268 118
assign 1 268 119
new 0 268 119
assign 1 268 120
addValue 1 268 120
assign 1 268 121
new 0 268 121
put 2 268 122
assign 1 269 123
new 0 269 123
assign 1 269 124
new 0 269 124
assign 1 269 125
addValue 1 269 125
assign 1 269 126
new 0 269 126
put 2 269 127
assign 1 270 128
new 0 270 128
assign 1 270 129
new 0 270 129
assign 1 270 130
addValue 1 270 130
assign 1 270 131
new 0 270 131
put 2 270 132
assign 1 271 133
new 0 271 133
assign 1 271 134
new 0 271 134
assign 1 271 135
addValue 1 271 135
assign 1 271 136
new 0 271 136
put 2 271 137
assign 1 272 138
new 0 272 138
assign 1 272 139
new 0 272 139
assign 1 272 140
addValue 1 272 140
assign 1 272 141
new 0 272 141
put 2 272 142
assign 1 273 143
new 0 273 143
assign 1 273 144
new 0 273 144
assign 1 273 145
addValue 1 273 145
assign 1 273 146
new 0 273 146
put 2 273 147
assign 1 275 148
new 0 275 148
assign 1 275 149
new 0 275 149
put 2 275 150
assign 1 276 151
new 0 276 151
assign 1 276 152
quoteGet 0 276 152
assign 1 276 153
new 0 276 153
assign 1 276 154
quoteGet 0 276 154
put 2 276 155
assign 1 277 156
new 0 277 156
assign 1 277 157
new 0 277 157
put 2 277 158
assign 1 278 159
new 0 278 159
assign 1 278 160
new 0 278 160
put 2 278 161
assign 1 279 162
new 0 279 162
assign 1 279 163
new 0 279 163
put 2 279 164
assign 1 280 165
new 0 280 165
assign 1 280 166
new 0 280 166
put 2 280 167
assign 1 281 168
new 0 281 168
assign 1 281 169
new 0 281 169
put 2 281 170
assign 1 282 171
new 0 282 171
assign 1 282 172
new 0 282 172
put 2 282 173
return 1 0 177
return 1 0 180
assign 1 0 183
assign 1 0 187
return 1 0 191
return 1 0 194
assign 1 0 197
assign 1 0 201
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -963755335: return bem_fieldIteratorGet_0();
case 2146312392: return bem_fromEscapesGetDirect_0();
case -1004079418: return bem_once_0();
case -1108167878: return bem_serializeToString_0();
case 1603326601: return bem_many_0();
case -410444281: return bem_fromEscapesGet_0();
case 1540291824: return bem_toEscapesGetDirect_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -469171007: return bem_serializeContents_0();
case -545958368: return bem_toAny_0();
case -2073959559: return bem_default_0();
case -632169362: return bem_print_0();
case -2048609488: return bem_tagGet_0();
case -212376625: return bem_iteratorGet_0();
case 1909096874: return bem_create_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case 1419414154: return bem_new_0();
case 2077040828: return bem_copy_0();
case 429419643: return bem_echo_0();
case 1730620110: return bem_serializationIteratorGet_0();
case 1741010261: return bem_classNameGet_0();
case -1918539521: return bem_toString_0();
case -811598956: return bem_fieldNamesGet_0();
case 2119790095: return bem_toEscapesGet_0();
case 1687921048: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1013593669: return bem_fromEscapesSet_1(bevd_0);
case -1333243591: return bem_fromEscapesSetDirect_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -363168387: return bem_sameType_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case -1727962266: return bem_toEscapesSet_1(bevd_0);
case -479943388: return bem_toEscapesSetDirect_1(bevd_0);
case -1434304379: return bem_otherType_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_JsonEscapes_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_7_JsonEscapes_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_JsonEscapes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst = (BEC_2_4_7_JsonEscapes) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_type;
}
}
}
