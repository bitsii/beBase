namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_7_IOFileReaderCommand : BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
static BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0, 8));
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1, 30));
public static new BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static new BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva__command) {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) {
base.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool) /* Line: 758 */ {
bevt_3_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_command);
bevt_4_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 759 */
return this;
} /*method end*/
public override BEC_2_2_6_IOReader bem_close_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {721, 725, 729, 731, 742, 757, 759, 759, 759, 759, 759, 759, 772, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 25, 29, 30, 41, 42, 44, 45, 46, 47, 48, 49, 54, 58, 61, 64, 68};
/* BEGIN LINEINFO 
new 0 721 21
commandNew 1 725 25
new 0 729 29
assign 1 731 30
assign 1 742 41
assign 1 757 42
assign 1 759 44
new 0 759 44
assign 1 759 45
add 1 759 45
assign 1 759 46
new 0 759 46
assign 1 759 47
add 1 759 47
assign 1 759 48
new 1 759 48
throw 1 759 49
assign 1 772 54
new 0 772 54
return 1 0 58
return 1 0 61
assign 1 0 64
assign 1 0 68
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1966412141: return bem_iteratorGet_0();
case 165794641: return bem_once_0();
case 575220420: return bem_fieldIteratorGet_0();
case 1598337480: return bem_readString_0();
case -1742048806: return bem_readStringClose_0();
case -1808490847: return bem_pathGet_0();
case -180542304: return bem_classNameGet_0();
case -909311275: return bem_blockSizeGet_0();
case -1901410949: return bem_readBuffer_0();
case 2141644828: return bem_hashGet_0();
case -1098779005: return bem_blockSizeGetDirect_0();
case -63902536: return bem_pathGetDirect_0();
case -1978814506: return bem_open_0();
case 752743955: return bem_extOpen_0();
case 585348009: return bem_fieldNamesGet_0();
case -393323283: return bem_toAny_0();
case -67472695: return bem_vfileGet_0();
case 1965078651: return bem_vfileGetDirect_0();
case 1185842043: return bem_sourceFileNameGet_0();
case -694583539: return bem_commandGetDirect_0();
case 1934923088: return bem_byteReaderGet_0();
case 1912156906: return bem_serializeToString_0();
case 1558292825: return bem_deserializeClassNameGet_0();
case 542895814: return bem_commandGet_0();
case 896197971: return bem_tagGet_0();
case 1158828766: return bem_isClosedGetDirect_0();
case 526804620: return bem_isClosedGet_0();
case -763923474: return bem_new_0();
case 1724083576: return bem_serializeContents_0();
case -307062183: return bem_toString_0();
case -348788042: return bem_copy_0();
case 30730421: return bem_many_0();
case -591889797: return bem_create_0();
case -1925117861: return bem_print_0();
case 644616544: return bem_serializationIteratorGet_0();
case -1352792576: return bem_close_0();
case -1674239636: return bem_echo_0();
case -1094321702: return bem_readBufferLine_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 404510287: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1825130896: return bem_pathSetDirect_1(bevd_0);
case -291041689: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1471364419: return bem_commandSetDirect_1(bevd_0);
case 1294060201: return bem_sameClass_1(bevd_0);
case 609382991: return bem_copyTo_1(bevd_0);
case -626901559: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 869146451: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -1353025300: return bem_equals_1(bevd_0);
case 1344352889: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 422988859: return bem_sameObject_1(bevd_0);
case 1742484831: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1454953713: return bem_isClosedSet_1(bevd_0);
case 543167157: return bem_otherClass_1(bevd_0);
case -829145507: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -642381822: return bem_undefined_1(bevd_0);
case 1321328032: return bem_defined_1(bevd_0);
case -735046391: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1311203330: return bem_def_1(bevd_0);
case -231248441: return bem_undef_1(bevd_0);
case 1953734144: return bem_otherType_1(bevd_0);
case 1602078864: return bem_pathSet_1(bevd_0);
case -1509749841: return bem_commandSet_1(bevd_0);
case 1921787508: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 901984148: return bem_vfileSetDirect_1(bevd_0);
case -598110752: return bem_new_1(bevd_0);
case 1160412715: return bem_sameType_1(bevd_0);
case -126899454: return bem_blockSizeSetDirect_1(bevd_0);
case 1299414631: return bem_notEquals_1(bevd_0);
case 1661383499: return bem_isClosedSetDirect_1(bevd_0);
case -371567792: return bem_blockSizeSet_1(bevd_0);
case 1121300695: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1020826997: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1330154191: return bem_vfileSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1545946221: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1682184009: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2094225927: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1212138034: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1122797756: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1822516892: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936030170: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1462387057: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1628093637: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1358351565: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
}
