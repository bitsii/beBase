namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_7_IOFileReaderCommand : BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
static BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
public static new BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static new BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva__command) {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) {
base.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool)/* Line: 832*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_command);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_ta_ph);
throw new be.BECS_ThrowBack(bevt_0_ta_ph);
} /* Line: 833*/
return this;
} /*method end*/
public override BEC_2_2_6_IOReader bem_close_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {795, 799, 803, 805, 816, 831, 833, 833, 833, 833, 833, 833, 846, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 23, 27, 28, 39, 40, 42, 43, 44, 45, 46, 47, 52, 56, 59, 62, 66};
/* BEGIN LINEINFO 
new 0 795 19
commandNew 1 799 23
new 0 803 27
assign 1 805 28
assign 1 816 39
assign 1 831 40
assign 1 833 42
new 0 833 42
assign 1 833 43
add 1 833 43
assign 1 833 44
new 0 833 44
assign 1 833 45
add 1 833 45
assign 1 833 46
new 1 833 46
throw 1 833 47
assign 1 846 52
new 0 846 52
return 1 0 56
return 1 0 59
assign 1 0 62
assign 1 0 66
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1407722929: return bem_open_0();
case 834374027: return bem_commandGetDirect_0();
case -1848718184: return bem_hashGet_0();
case -1143093403: return bem_vfileGetDirect_0();
case -31114048: return bem_iteratorGet_0();
case 259850418: return bem_pathGetDirect_0();
case -1182685766: return bem_blockSizeGetDirect_0();
case 1620440500: return bem_byteReaderGet_0();
case 180027436: return bem_readBuffer_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -479166709: return bem_tagGet_0();
case 185174991: return bem_copy_0();
case 1290742222: return bem_readStringClose_0();
case 1543897957: return bem_vfileGet_0();
case -1094921715: return bem_readDiscard_0();
case -746182443: return bem_readDiscardClose_0();
case -273137825: return bem_close_0();
case -1902089216: return bem_toString_0();
case -785258946: return bem_create_0();
case 2038193605: return bem_fieldNamesGet_0();
case 217968364: return bem_classNameGet_0();
case 1029695809: return bem_echo_0();
case 1137009070: return bem_once_0();
case -1041663719: return bem_pathGet_0();
case -633404169: return bem_commandGet_0();
case 1562608535: return bem_print_0();
case 390136468: return bem_extOpen_0();
case -1844917728: return bem_many_0();
case 811691829: return bem_isClosedGet_0();
case 33395674: return bem_isClosedGetDirect_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -8643043: return bem_serializeContents_0();
case 468018334: return bem_readBufferLine_0();
case 102554564: return bem_fieldIteratorGet_0();
case 1688687204: return bem_serializeToString_0();
case 126670515: return bem_toAny_0();
case 114200084: return bem_readString_0();
case -1725405782: return bem_sourceFileNameGet_0();
case -1523990843: return bem_blockSizeGet_0();
case -1026733174: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 398725636: return bem_sameType_1(bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 917875808: return bem_blockSizeSetDirect_1(bevd_0);
case 1942655457: return bem_isClosedSet_1(bevd_0);
case 1579992995: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case 1452006586: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 389177729: return bem_new_1(bevd_0);
case -1696984580: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1161829704: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 422984328: return bem_commandSet_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 1458446294: return bem_vfileSet_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case -1783320294: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 893180093: return bem_commandSetDirect_1(bevd_0);
case -21713989: return bem_pathSetDirect_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 795985106: return bem_blockSizeSet_1(bevd_0);
case -1627064419: return bem_vfileSetDirect_1(bevd_0);
case 1288064037: return bem_isClosedSetDirect_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 530639018: return bem_pathSet_1(bevd_0);
case 1503540268: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1018866991: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1906132053: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -380940593: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1175297088: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
}
