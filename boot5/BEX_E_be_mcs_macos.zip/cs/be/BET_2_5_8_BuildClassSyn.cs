namespace be {
public class BET_2_5_8_BuildClassSyn : BETS_Object {
public BET_2_5_8_BuildClassSyn() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "maxMtdxGet_0", "hasDefaultGet_0", "new_2", "castsTo_1", "integrate_1", "checkInheritance_2", "checkTypes_5", "new_1", "loadClass_1", "postLoad_0", "superNpGet_0", "superNpSet_1", "depthGet_0", "depthSet_1", "namepathGet_0", "namepathSet_1", "fromFileGet_0", "fromFileSet_1", "libNameGet_0", "libNameSet_1", "isLocalGet_0", "isLocalSet_1", "isNotNullGet_0", "isNotNullSet_1", "newMbrsGet_0", "newMbrsSet_1", "newMtdsGet_0", "newMtdsSet_1", "defMtdsGet_0", "defMtdsSet_1", "directPropertiesGet_0", "directPropertiesSet_1", "directMethodsGet_0", "directMethodsSet_1", "allTypesGet_0", "allTypesSet_1", "superListGet_0", "superListSet_1", "mtdMapGet_0", "mtdMapSet_1", "mtdListGet_0", "mtdListSet_1", "ptyMapGet_0", "ptyMapSet_1", "ptyListGet_0", "ptyListSet_1", "allNamesGet_0", "allNamesSet_1", "foreignClassesGet_0", "foreignClassesSet_1", "allAncestorsCloseGet_0", "allAncestorsCloseSet_1", "integratedGet_0", "integratedSet_1", "iCheckedGet_0", "iCheckedSet_1", "usesGet_0", "usesSet_1", "isFinalGet_0", "isFinalSet_1", "signatureChangedGet_0", "signatureChangedSet_1", "signatureCheckedGet_0", "signatureCheckedSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
static BET_2_5_8_BuildClassSyn() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_8_BuildClassSyn();
}
}
}
