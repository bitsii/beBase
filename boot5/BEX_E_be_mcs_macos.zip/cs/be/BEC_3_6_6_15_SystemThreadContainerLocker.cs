namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 824 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 826 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 829 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 835 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(1116160409, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 837 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 840 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 847 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-1228942573, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 849 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 852 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 859 */ {
bevl_r = bevp_container.bemd_0(-878499851);
bevp_lock.bem_unlock_0();
} /* Line: 861 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 864 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 871 */ {
bevl_r = bevp_container.bemd_1(1736756437, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 873 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 876 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 883 */ {
bevl_r = bevp_container.bemd_1(1736756437, beva_key);
bevp_container.bemd_1(-1251320534, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 886 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 889 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 896 */ {
bevl_r = bevp_container.bemd_2(313143658, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 898 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 901 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 908 */ {
bevp_container.bemd_1(847007748, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 910 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 913 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 919 */ {
bevl_r = bevp_container.bemd_1(534139314, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 921 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 924 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 931 */ {
bevp_container.bemd_1(534139314, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 933 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 936 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 942 */ {
bevl_r = bevp_container.bemd_2(1159538561, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 944 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 947 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 954 */ {
bevp_container.bemd_2(1159538561, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 956 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 959 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 965 */ {
bevl_rc = bevp_container.bemd_3(1964997293, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 967 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 970 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 977 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1984926219);
bevp_lock.bem_unlock_0();
} /* Line: 979 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 982 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-1191535971, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1001 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(1116160409, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1002 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 1003 */
 else  /* Line: 1004 */ {
bevp_container.bemd_2(1159538561, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1006 */
bevp_lock.bem_unlock_0();
} /* Line: 1008 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1011 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1018 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(1116160409, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1019 */ {
bevl_result = bevp_container.bemd_1(1736756437, beva_key);
} /* Line: 1020 */
 else  /* Line: 1021 */ {
bevp_container.bemd_2(1159538561, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1023 */
bevp_lock.bem_unlock_0();
} /* Line: 1025 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1028 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1035 */ {
bevp_container.bemd_3(-1634994731, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1037 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1040 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1046 */ {
bevl_r = bevp_container.bemd_1(-1251320534, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1048 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1051 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1058 */ {
bevl_r = bevp_container.bemd_2(286591152, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1060 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1063 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1070 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(701811494);
bevp_lock.bem_unlock_0();
} /* Line: 1072 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1075 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1082 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(270831604);
bevp_lock.bem_unlock_0();
} /* Line: 1084 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1087 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1094 */ {
bevl_r = bevp_container.bemd_0(1907596400);
bevp_lock.bem_unlock_0();
} /* Line: 1096 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1099 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1106 */ {
bevp_container.bemd_0(-1788339241);
bevp_lock.bem_unlock_0();
} /* Line: 1108 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1111 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1117 */ {
bevp_container.bemd_0(1785282761);
bevp_lock.bem_unlock_0();
} /* Line: 1119 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1122 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {820, 823, 825, 826, 828, 829, 834, 836, 837, 839, 840, 842, 846, 848, 849, 851, 852, 854, 858, 860, 861, 863, 864, 866, 870, 872, 873, 875, 876, 878, 882, 884, 885, 886, 888, 889, 891, 895, 897, 898, 900, 901, 903, 907, 909, 910, 912, 913, 918, 920, 921, 923, 924, 926, 930, 932, 933, 935, 936, 941, 943, 944, 946, 947, 949, 953, 955, 956, 958, 959, 964, 966, 967, 969, 970, 972, 976, 978, 979, 981, 982, 984, 988, 990, 991, 993, 994, 996, 1000, 1002, 1003, 1005, 1006, 1008, 1010, 1011, 1013, 1017, 1019, 1020, 1022, 1023, 1025, 1027, 1028, 1030, 1034, 1036, 1037, 1039, 1040, 1045, 1047, 1048, 1050, 1051, 1053, 1057, 1059, 1060, 1062, 1063, 1065, 1069, 1071, 1072, 1074, 1075, 1077, 1081, 1083, 1084, 1086, 1087, 1089, 1093, 1095, 1096, 1098, 1099, 1101, 1105, 1107, 1108, 1110, 1111, 1116, 1118, 1119, 1121, 1122, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 59, 60, 62, 67, 69, 70, 74, 75, 77, 82, 84, 85, 89, 90, 92, 97, 99, 100, 101, 105, 106, 108, 113, 115, 116, 120, 121, 123, 127, 129, 130, 134, 135, 142, 144, 145, 149, 150, 152, 156, 158, 159, 163, 164, 171, 173, 174, 178, 179, 181, 185, 187, 188, 192, 193, 200, 202, 203, 207, 208, 210, 215, 217, 218, 222, 223, 225, 230, 232, 233, 237, 238, 240, 246, 248, 250, 253, 254, 256, 260, 261, 263, 269, 271, 273, 276, 277, 279, 283, 284, 286, 290, 292, 293, 297, 298, 305, 307, 308, 312, 313, 315, 320, 322, 323, 327, 328, 330, 335, 337, 338, 342, 343, 345, 350, 352, 353, 357, 358, 360, 365, 367, 368, 372, 373, 375, 379, 381, 382, 386, 387, 393, 395, 396, 400, 401, 406, 409, 413, 416};
/* BEGIN LINEINFO 
assign 1 820 21
new 0 820 21
lock 0 823 22
assign 1 825 24
unlock 0 826 25
unlock 0 828 29
throw 1 829 30
lock 0 834 37
assign 1 836 39
has 1 836 39
unlock 0 837 40
unlock 0 839 44
throw 1 840 45
return 1 842 47
lock 0 846 52
assign 1 848 54
has 2 848 54
unlock 0 849 55
unlock 0 851 59
throw 1 852 60
return 1 854 62
lock 0 858 67
assign 1 860 69
get 0 860 69
unlock 0 861 70
unlock 0 863 74
throw 1 864 75
return 1 866 77
lock 0 870 82
assign 1 872 84
get 1 872 84
unlock 0 873 85
unlock 0 875 89
throw 1 876 90
return 1 878 92
lock 0 882 97
assign 1 884 99
get 1 884 99
delete 1 885 100
unlock 0 886 101
unlock 0 888 105
throw 1 889 106
return 1 891 108
lock 0 895 113
assign 1 897 115
get 2 897 115
unlock 0 898 116
unlock 0 900 120
throw 1 901 121
return 1 903 123
lock 0 907 127
addValue 1 909 129
unlock 0 910 130
unlock 0 912 134
throw 1 913 135
lock 0 918 142
assign 1 920 144
put 1 920 144
unlock 0 921 145
unlock 0 923 149
throw 1 924 150
return 1 926 152
lock 0 930 156
put 1 932 158
unlock 0 933 159
unlock 0 935 163
throw 1 936 164
lock 0 941 171
assign 1 943 173
put 2 943 173
unlock 0 944 174
unlock 0 946 178
throw 1 947 179
return 1 949 181
lock 0 953 185
put 2 955 187
unlock 0 956 188
unlock 0 958 192
throw 1 959 193
lock 0 964 200
assign 1 966 202
testAndPut 3 966 202
unlock 0 967 203
unlock 0 969 207
throw 1 970 208
return 1 972 210
lock 0 976 215
assign 1 978 217
getMap 0 978 217
unlock 0 979 218
unlock 0 981 222
throw 1 982 223
return 1 984 225
lock 0 988 230
assign 1 990 232
getMap 1 990 232
unlock 0 991 233
unlock 0 993 237
throw 1 994 238
return 1 996 240
lock 0 1000 246
assign 1 1002 248
has 1 1002 248
assign 1 1003 250
new 0 1003 250
put 2 1005 253
assign 1 1006 254
new 0 1006 254
unlock 0 1008 256
unlock 0 1010 260
throw 1 1011 261
return 1 1013 263
lock 0 1017 269
assign 1 1019 271
has 1 1019 271
assign 1 1020 273
get 1 1020 273
put 2 1022 276
assign 1 1023 277
unlock 0 1025 279
unlock 0 1027 283
throw 1 1028 284
return 1 1030 286
lock 0 1034 290
put 3 1036 292
unlock 0 1037 293
unlock 0 1039 297
throw 1 1040 298
lock 0 1045 305
assign 1 1047 307
delete 1 1047 307
unlock 0 1048 308
unlock 0 1050 312
throw 1 1051 313
return 1 1053 315
lock 0 1057 320
assign 1 1059 322
delete 2 1059 322
unlock 0 1060 323
unlock 0 1062 327
throw 1 1063 328
return 1 1065 330
lock 0 1069 335
assign 1 1071 337
sizeGet 0 1071 337
unlock 0 1072 338
unlock 0 1074 342
throw 1 1075 343
return 1 1077 345
lock 0 1081 350
assign 1 1083 352
isEmptyGet 0 1083 352
unlock 0 1084 353
unlock 0 1086 357
throw 1 1087 358
return 1 1089 360
lock 0 1093 365
assign 1 1095 367
copy 0 1095 367
unlock 0 1096 368
unlock 0 1098 372
throw 1 1099 373
return 1 1101 375
lock 0 1105 379
clear 0 1107 381
unlock 0 1108 382
unlock 0 1110 386
throw 1 1111 387
lock 0 1116 393
close 0 1118 395
unlock 0 1119 396
unlock 0 1121 400
throw 1 1122 401
return 1 0 406
assign 1 0 409
return 1 0 413
assign 1 0 416
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1714984646: return bem_serializeToString_0();
case 1348777534: return bem_many_0();
case 270831604: return bem_isEmptyGet_0();
case -873085717: return bem_iteratorGet_0();
case 1907596400: return bem_copy_0();
case -1788339241: return bem_clear_0();
case 1534217891: return bem_copyContainer_0();
case -1320125172: return bem_once_0();
case -878499851: return bem_get_0();
case 713197195: return bem_deserializeClassNameGet_0();
case -977833063: return bem_toString_0();
case -1698152847: return bem_serializationIteratorGet_0();
case -1435450334: return bem_classNameGet_0();
case -100075913: return bem_new_0();
case 701811494: return bem_sizeGet_0();
case 975002362: return bem_tagGet_0();
case -2080318285: return bem_sourceFileNameGet_0();
case 823358342: return bem_lockGet_0();
case 1418537405: return bem_fieldIteratorGet_0();
case 1984926219: return bem_getMap_0();
case -92908170: return bem_print_0();
case 596758489: return bem_create_0();
case 189986949: return bem_toAny_0();
case 1732066970: return bem_echo_0();
case 1785282761: return bem_close_0();
case -328171317: return bem_hashGet_0();
case 1361238708: return bem_serializeContents_0();
case -1154130332: return bem_containerGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 847007748: return bem_addValue_1(bevd_0);
case -36926033: return bem_notEquals_1(bevd_0);
case 534139314: return bem_put_1(bevd_0);
case -1251320534: return bem_delete_1(bevd_0);
case -796619944: return bem_lockSet_1(bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1371183184: return bem_putReturn_1(bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case 256146165: return bem_getAndClear_1(bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case -289777042: return bem_containerSet_1(bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case 1736756437: return bem_get_1(bevd_0);
case -1685745238: return bem_new_1(bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1191535971: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1116160409: return bem_has_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 286591152: return bem_delete_2(bevd_0, bevd_1);
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1830106206: return bem_getOrPut_2(bevd_0, bevd_1);
case 1159538561: return bem_put_2(bevd_0, bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1228942573: return bem_has_2(bevd_0, bevd_1);
case -40751233: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 313143658: return bem_get_2(bevd_0, bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 683441951: return bem_putReturn_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1964997293: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case -1634994731: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
