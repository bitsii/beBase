namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 809 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 811 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 814 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 820 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-416795215, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 822 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 825 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 832 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(596025507, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 834 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 837 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 844 */ {
bevl_r = bevp_container.bemd_0(-1281220749);
bevp_lock.bem_unlock_0();
} /* Line: 846 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 849 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 856 */ {
bevl_r = bevp_container.bemd_1(-939231299, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 858 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 861 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 868 */ {
bevl_r = bevp_container.bemd_1(-939231299, beva_key);
bevp_container.bemd_1(-1870139640, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 871 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 874 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 881 */ {
bevl_r = bevp_container.bemd_2(-1094139449, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 883 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 886 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 893 */ {
bevp_container.bemd_1(1109801847, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 895 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 898 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 904 */ {
bevl_r = bevp_container.bemd_1(167528721, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 906 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 909 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 916 */ {
bevp_container.bemd_1(167528721, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 918 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 921 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 927 */ {
bevl_r = bevp_container.bemd_2(353181024, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 929 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 932 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 939 */ {
bevp_container.bemd_2(353181024, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 941 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 944 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 950 */ {
bevl_rc = bevp_container.bemd_3(-1200492906, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 952 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 955 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 962 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(573555967);
bevp_lock.bem_unlock_0();
} /* Line: 964 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 967 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 974 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-692584425, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 976 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 979 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 986 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-416795215, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 987 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 988 */
 else  /* Line: 989 */ {
bevp_container.bemd_2(353181024, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 991 */
bevp_lock.bem_unlock_0();
} /* Line: 993 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 996 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1003 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-416795215, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1004 */ {
bevl_result = bevp_container.bemd_1(-939231299, beva_key);
} /* Line: 1005 */
 else  /* Line: 1006 */ {
bevp_container.bemd_2(353181024, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1008 */
bevp_lock.bem_unlock_0();
} /* Line: 1010 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1013 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1020 */ {
bevp_container.bemd_3(-591995215, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1022 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1025 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1031 */ {
bevl_r = bevp_container.bemd_1(-1870139640, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1033 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1036 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1043 */ {
bevl_r = bevp_container.bemd_2(1594196108, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1045 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1048 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1055 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-1392579772);
bevp_lock.bem_unlock_0();
} /* Line: 1057 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1060 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1067 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-1812251411);
bevp_lock.bem_unlock_0();
} /* Line: 1069 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1072 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1079 */ {
bevl_r = bevp_container.bemd_0(-1474180855);
bevp_lock.bem_unlock_0();
} /* Line: 1081 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1084 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1091 */ {
bevp_container.bemd_0(27835229);
bevp_lock.bem_unlock_0();
} /* Line: 1093 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1096 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1102 */ {
bevp_container.bemd_0(1092963492);
bevp_lock.bem_unlock_0();
} /* Line: 1104 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1107 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {805, 808, 810, 811, 813, 814, 819, 821, 822, 824, 825, 827, 831, 833, 834, 836, 837, 839, 843, 845, 846, 848, 849, 851, 855, 857, 858, 860, 861, 863, 867, 869, 870, 871, 873, 874, 876, 880, 882, 883, 885, 886, 888, 892, 894, 895, 897, 898, 903, 905, 906, 908, 909, 911, 915, 917, 918, 920, 921, 926, 928, 929, 931, 932, 934, 938, 940, 941, 943, 944, 949, 951, 952, 954, 955, 957, 961, 963, 964, 966, 967, 969, 973, 975, 976, 978, 979, 981, 985, 987, 988, 990, 991, 993, 995, 996, 998, 1002, 1004, 1005, 1007, 1008, 1010, 1012, 1013, 1015, 1019, 1021, 1022, 1024, 1025, 1030, 1032, 1033, 1035, 1036, 1038, 1042, 1044, 1045, 1047, 1048, 1050, 1054, 1056, 1057, 1059, 1060, 1062, 1066, 1068, 1069, 1071, 1072, 1074, 1078, 1080, 1081, 1083, 1084, 1086, 1090, 1092, 1093, 1095, 1096, 1101, 1103, 1104, 1106, 1107, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 59, 60, 62, 67, 69, 70, 74, 75, 77, 82, 84, 85, 89, 90, 92, 97, 99, 100, 101, 105, 106, 108, 113, 115, 116, 120, 121, 123, 127, 129, 130, 134, 135, 142, 144, 145, 149, 150, 152, 156, 158, 159, 163, 164, 171, 173, 174, 178, 179, 181, 185, 187, 188, 192, 193, 200, 202, 203, 207, 208, 210, 215, 217, 218, 222, 223, 225, 230, 232, 233, 237, 238, 240, 246, 248, 250, 253, 254, 256, 260, 261, 263, 269, 271, 273, 276, 277, 279, 283, 284, 286, 290, 292, 293, 297, 298, 305, 307, 308, 312, 313, 315, 320, 322, 323, 327, 328, 330, 335, 337, 338, 342, 343, 345, 350, 352, 353, 357, 358, 360, 365, 367, 368, 372, 373, 375, 379, 381, 382, 386, 387, 393, 395, 396, 400, 401, 406, 409, 412, 416, 420, 423, 426, 430};
/* BEGIN LINEINFO 
assign 1 805 21
new 0 805 21
lock 0 808 22
assign 1 810 24
unlock 0 811 25
unlock 0 813 29
throw 1 814 30
lock 0 819 37
assign 1 821 39
has 1 821 39
unlock 0 822 40
unlock 0 824 44
throw 1 825 45
return 1 827 47
lock 0 831 52
assign 1 833 54
has 2 833 54
unlock 0 834 55
unlock 0 836 59
throw 1 837 60
return 1 839 62
lock 0 843 67
assign 1 845 69
get 0 845 69
unlock 0 846 70
unlock 0 848 74
throw 1 849 75
return 1 851 77
lock 0 855 82
assign 1 857 84
get 1 857 84
unlock 0 858 85
unlock 0 860 89
throw 1 861 90
return 1 863 92
lock 0 867 97
assign 1 869 99
get 1 869 99
delete 1 870 100
unlock 0 871 101
unlock 0 873 105
throw 1 874 106
return 1 876 108
lock 0 880 113
assign 1 882 115
get 2 882 115
unlock 0 883 116
unlock 0 885 120
throw 1 886 121
return 1 888 123
lock 0 892 127
addValue 1 894 129
unlock 0 895 130
unlock 0 897 134
throw 1 898 135
lock 0 903 142
assign 1 905 144
put 1 905 144
unlock 0 906 145
unlock 0 908 149
throw 1 909 150
return 1 911 152
lock 0 915 156
put 1 917 158
unlock 0 918 159
unlock 0 920 163
throw 1 921 164
lock 0 926 171
assign 1 928 173
put 2 928 173
unlock 0 929 174
unlock 0 931 178
throw 1 932 179
return 1 934 181
lock 0 938 185
put 2 940 187
unlock 0 941 188
unlock 0 943 192
throw 1 944 193
lock 0 949 200
assign 1 951 202
testAndPut 3 951 202
unlock 0 952 203
unlock 0 954 207
throw 1 955 208
return 1 957 210
lock 0 961 215
assign 1 963 217
getMap 0 963 217
unlock 0 964 218
unlock 0 966 222
throw 1 967 223
return 1 969 225
lock 0 973 230
assign 1 975 232
getMap 1 975 232
unlock 0 976 233
unlock 0 978 237
throw 1 979 238
return 1 981 240
lock 0 985 246
assign 1 987 248
has 1 987 248
assign 1 988 250
new 0 988 250
put 2 990 253
assign 1 991 254
new 0 991 254
unlock 0 993 256
unlock 0 995 260
throw 1 996 261
return 1 998 263
lock 0 1002 269
assign 1 1004 271
has 1 1004 271
assign 1 1005 273
get 1 1005 273
put 2 1007 276
assign 1 1008 277
unlock 0 1010 279
unlock 0 1012 283
throw 1 1013 284
return 1 1015 286
lock 0 1019 290
put 3 1021 292
unlock 0 1022 293
unlock 0 1024 297
throw 1 1025 298
lock 0 1030 305
assign 1 1032 307
delete 1 1032 307
unlock 0 1033 308
unlock 0 1035 312
throw 1 1036 313
return 1 1038 315
lock 0 1042 320
assign 1 1044 322
delete 2 1044 322
unlock 0 1045 323
unlock 0 1047 327
throw 1 1048 328
return 1 1050 330
lock 0 1054 335
assign 1 1056 337
sizeGet 0 1056 337
unlock 0 1057 338
unlock 0 1059 342
throw 1 1060 343
return 1 1062 345
lock 0 1066 350
assign 1 1068 352
isEmptyGet 0 1068 352
unlock 0 1069 353
unlock 0 1071 357
throw 1 1072 358
return 1 1074 360
lock 0 1078 365
assign 1 1080 367
copy 0 1080 367
unlock 0 1081 368
unlock 0 1083 372
throw 1 1084 373
return 1 1086 375
lock 0 1090 379
clear 0 1092 381
unlock 0 1093 382
unlock 0 1095 386
throw 1 1096 387
lock 0 1101 393
close 0 1103 395
unlock 0 1104 396
unlock 0 1106 400
throw 1 1107 401
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -183071211: return bem_new_0();
case -1281220749: return bem_get_0();
case 572166870: return bem_lockGet_0();
case -1472038924: return bem_toAny_0();
case 439322172: return bem_classNameGet_0();
case -850133764: return bem_copyContainer_0();
case 1659508682: return bem_iteratorGet_0();
case 2119526452: return bem_deserializeClassNameGet_0();
case 1683143409: return bem_containerGetDirect_0();
case 27835229: return bem_clear_0();
case 1979675315: return bem_toString_0();
case -267127873: return bem_containerGet_0();
case -941995054: return bem_print_0();
case -1812251411: return bem_isEmptyGet_0();
case -1713867889: return bem_serializationIteratorGet_0();
case -1474180855: return bem_copy_0();
case 1992383723: return bem_once_0();
case -1265013519: return bem_fieldNamesGet_0();
case -1030588527: return bem_lockGetDirect_0();
case -1392579772: return bem_sizeGet_0();
case 1937136245: return bem_create_0();
case -1684408485: return bem_serializeContents_0();
case -1302207362: return bem_serializeToString_0();
case 163561636: return bem_echo_0();
case -23361149: return bem_sourceFileNameGet_0();
case -436164110: return bem_hashGet_0();
case -1858345160: return bem_many_0();
case 573555967: return bem_getMap_0();
case -606275227: return bem_tagGet_0();
case 922739318: return bem_fieldIteratorGet_0();
case 1092963492: return bem_close_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1473811380: return bem_defined_1(bevd_0);
case 1269768387: return bem_lockSet_1(bevd_0);
case 987555878: return bem_sameType_1(bevd_0);
case -416795215: return bem_has_1(bevd_0);
case 233690225: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -264806622: return bem_undefined_1(bevd_0);
case -784703530: return bem_getAndClear_1(bevd_0);
case 322951285: return bem_lockSetDirect_1(bevd_0);
case 167528721: return bem_put_1(bevd_0);
case -939231299: return bem_get_1(bevd_0);
case -1896420044: return bem_containerSetDirect_1(bevd_0);
case 1960686692: return bem_notEquals_1(bevd_0);
case -1581273032: return bem_otherType_1(bevd_0);
case 1617129647: return bem_sameObject_1(bevd_0);
case -692584425: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 938978423: return bem_otherClass_1(bevd_0);
case -1031049575: return bem_copyTo_1(bevd_0);
case -1870139640: return bem_delete_1(bevd_0);
case 1959069618: return bem_new_1(bevd_0);
case 857223239: return bem_containerSet_1(bevd_0);
case -38791021: return bem_putReturn_1(bevd_0);
case -1106603847: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1109801847: return bem_addValue_1(bevd_0);
case -339333895: return bem_equals_1(bevd_0);
case 2017705831: return bem_def_1(bevd_0);
case 766930230: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1070735389: return bem_undef_1(bevd_0);
case 1524591721: return bem_sameClass_1(bevd_0);
case -805702504: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 353181024: return bem_put_2(bevd_0, bevd_1);
case -881140199: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1628937971: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1931290860: return bem_getOrPut_2(bevd_0, bevd_1);
case 1594196108: return bem_delete_2(bevd_0, bevd_1);
case -727572211: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1094139449: return bem_get_2(bevd_0, bevd_1);
case 329050020: return bem_putReturn_2(bevd_0, bevd_1);
case 391353131: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -779217973: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -961395565: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 923430668: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 596025507: return bem_has_2(bevd_0, bevd_1);
case 838418125: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1200492906: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case -591995215: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
