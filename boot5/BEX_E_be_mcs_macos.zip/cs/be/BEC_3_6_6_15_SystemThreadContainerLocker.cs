namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 794 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 796 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 799 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 805 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-383640751, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 807 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 810 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 817 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-237643184, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 819 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 822 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 829 */ {
bevl_r = bevp_container.bemd_0(-355041847);
bevp_lock.bem_unlock_0();
} /* Line: 831 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 834 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 841 */ {
bevl_r = bevp_container.bemd_1(-767519146, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 843 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 846 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 853 */ {
bevl_r = bevp_container.bemd_1(-767519146, beva_key);
bevp_container.bemd_1(71632622, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 856 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 859 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 866 */ {
bevl_r = bevp_container.bemd_2(892604091, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 868 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 871 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 878 */ {
bevp_container.bemd_1(-264866456, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 880 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 883 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 889 */ {
bevl_r = bevp_container.bemd_1(-1266006646, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 891 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 894 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 901 */ {
bevp_container.bemd_1(-1266006646, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 903 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 906 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 912 */ {
bevl_r = bevp_container.bemd_2(1075614417, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 914 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 917 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 924 */ {
bevp_container.bemd_2(1075614417, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 926 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 929 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 935 */ {
bevl_rc = bevp_container.bemd_3(-1743586386, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 937 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 940 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 947 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1228265996);
bevp_lock.bem_unlock_0();
} /* Line: 949 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 952 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 959 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-835917636, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 961 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 964 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 971 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-383640751, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 972 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 973 */
 else  /* Line: 974 */ {
bevp_container.bemd_2(1075614417, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 976 */
bevp_lock.bem_unlock_0();
} /* Line: 978 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 981 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 988 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-383640751, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 989 */ {
bevl_result = bevp_container.bemd_1(-767519146, beva_key);
} /* Line: 990 */
 else  /* Line: 991 */ {
bevp_container.bemd_2(1075614417, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 993 */
bevp_lock.bem_unlock_0();
} /* Line: 995 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 998 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1005 */ {
bevp_container.bemd_3(-1352559114, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1007 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1010 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1016 */ {
bevl_r = bevp_container.bemd_1(71632622, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1018 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1021 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1028 */ {
bevl_r = bevp_container.bemd_2(1667865274, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1030 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1033 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1040 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(1658721122);
bevp_lock.bem_unlock_0();
} /* Line: 1042 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1045 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1052 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-2003272432);
bevp_lock.bem_unlock_0();
} /* Line: 1054 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1057 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1064 */ {
bevl_r = bevp_container.bemd_0(-348788042);
bevp_lock.bem_unlock_0();
} /* Line: 1066 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1069 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1076 */ {
bevp_container.bemd_0(-463796871);
bevp_lock.bem_unlock_0();
} /* Line: 1078 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1081 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1087 */ {
bevp_container.bemd_0(-1352792576);
bevp_lock.bem_unlock_0();
} /* Line: 1089 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1092 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {790, 793, 795, 796, 798, 799, 804, 806, 807, 809, 810, 812, 816, 818, 819, 821, 822, 824, 828, 830, 831, 833, 834, 836, 840, 842, 843, 845, 846, 848, 852, 854, 855, 856, 858, 859, 861, 865, 867, 868, 870, 871, 873, 877, 879, 880, 882, 883, 888, 890, 891, 893, 894, 896, 900, 902, 903, 905, 906, 911, 913, 914, 916, 917, 919, 923, 925, 926, 928, 929, 934, 936, 937, 939, 940, 942, 946, 948, 949, 951, 952, 954, 958, 960, 961, 963, 964, 966, 970, 972, 973, 975, 976, 978, 980, 981, 983, 987, 989, 990, 992, 993, 995, 997, 998, 1000, 1004, 1006, 1007, 1009, 1010, 1015, 1017, 1018, 1020, 1021, 1023, 1027, 1029, 1030, 1032, 1033, 1035, 1039, 1041, 1042, 1044, 1045, 1047, 1051, 1053, 1054, 1056, 1057, 1059, 1063, 1065, 1066, 1068, 1069, 1071, 1075, 1077, 1078, 1080, 1081, 1086, 1088, 1089, 1091, 1092, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 59, 60, 62, 67, 69, 70, 74, 75, 77, 82, 84, 85, 89, 90, 92, 97, 99, 100, 101, 105, 106, 108, 113, 115, 116, 120, 121, 123, 127, 129, 130, 134, 135, 142, 144, 145, 149, 150, 152, 156, 158, 159, 163, 164, 171, 173, 174, 178, 179, 181, 185, 187, 188, 192, 193, 200, 202, 203, 207, 208, 210, 215, 217, 218, 222, 223, 225, 230, 232, 233, 237, 238, 240, 246, 248, 250, 253, 254, 256, 260, 261, 263, 269, 271, 273, 276, 277, 279, 283, 284, 286, 290, 292, 293, 297, 298, 305, 307, 308, 312, 313, 315, 320, 322, 323, 327, 328, 330, 335, 337, 338, 342, 343, 345, 350, 352, 353, 357, 358, 360, 365, 367, 368, 372, 373, 375, 379, 381, 382, 386, 387, 393, 395, 396, 400, 401, 406, 409, 412, 416, 420, 423, 426, 430};
/* BEGIN LINEINFO 
assign 1 790 21
new 0 790 21
lock 0 793 22
assign 1 795 24
unlock 0 796 25
unlock 0 798 29
throw 1 799 30
lock 0 804 37
assign 1 806 39
has 1 806 39
unlock 0 807 40
unlock 0 809 44
throw 1 810 45
return 1 812 47
lock 0 816 52
assign 1 818 54
has 2 818 54
unlock 0 819 55
unlock 0 821 59
throw 1 822 60
return 1 824 62
lock 0 828 67
assign 1 830 69
get 0 830 69
unlock 0 831 70
unlock 0 833 74
throw 1 834 75
return 1 836 77
lock 0 840 82
assign 1 842 84
get 1 842 84
unlock 0 843 85
unlock 0 845 89
throw 1 846 90
return 1 848 92
lock 0 852 97
assign 1 854 99
get 1 854 99
delete 1 855 100
unlock 0 856 101
unlock 0 858 105
throw 1 859 106
return 1 861 108
lock 0 865 113
assign 1 867 115
get 2 867 115
unlock 0 868 116
unlock 0 870 120
throw 1 871 121
return 1 873 123
lock 0 877 127
addValue 1 879 129
unlock 0 880 130
unlock 0 882 134
throw 1 883 135
lock 0 888 142
assign 1 890 144
put 1 890 144
unlock 0 891 145
unlock 0 893 149
throw 1 894 150
return 1 896 152
lock 0 900 156
put 1 902 158
unlock 0 903 159
unlock 0 905 163
throw 1 906 164
lock 0 911 171
assign 1 913 173
put 2 913 173
unlock 0 914 174
unlock 0 916 178
throw 1 917 179
return 1 919 181
lock 0 923 185
put 2 925 187
unlock 0 926 188
unlock 0 928 192
throw 1 929 193
lock 0 934 200
assign 1 936 202
testAndPut 3 936 202
unlock 0 937 203
unlock 0 939 207
throw 1 940 208
return 1 942 210
lock 0 946 215
assign 1 948 217
getMap 0 948 217
unlock 0 949 218
unlock 0 951 222
throw 1 952 223
return 1 954 225
lock 0 958 230
assign 1 960 232
getMap 1 960 232
unlock 0 961 233
unlock 0 963 237
throw 1 964 238
return 1 966 240
lock 0 970 246
assign 1 972 248
has 1 972 248
assign 1 973 250
new 0 973 250
put 2 975 253
assign 1 976 254
new 0 976 254
unlock 0 978 256
unlock 0 980 260
throw 1 981 261
return 1 983 263
lock 0 987 269
assign 1 989 271
has 1 989 271
assign 1 990 273
get 1 990 273
put 2 992 276
assign 1 993 277
unlock 0 995 279
unlock 0 997 283
throw 1 998 284
return 1 1000 286
lock 0 1004 290
put 3 1006 292
unlock 0 1007 293
unlock 0 1009 297
throw 1 1010 298
lock 0 1015 305
assign 1 1017 307
delete 1 1017 307
unlock 0 1018 308
unlock 0 1020 312
throw 1 1021 313
return 1 1023 315
lock 0 1027 320
assign 1 1029 322
delete 2 1029 322
unlock 0 1030 323
unlock 0 1032 327
throw 1 1033 328
return 1 1035 330
lock 0 1039 335
assign 1 1041 337
sizeGet 0 1041 337
unlock 0 1042 338
unlock 0 1044 342
throw 1 1045 343
return 1 1047 345
lock 0 1051 350
assign 1 1053 352
isEmptyGet 0 1053 352
unlock 0 1054 353
unlock 0 1056 357
throw 1 1057 358
return 1 1059 360
lock 0 1063 365
assign 1 1065 367
copy 0 1065 367
unlock 0 1066 368
unlock 0 1068 372
throw 1 1069 373
return 1 1071 375
lock 0 1075 379
clear 0 1077 381
unlock 0 1078 382
unlock 0 1080 386
throw 1 1081 387
lock 0 1086 393
close 0 1088 395
unlock 0 1089 396
unlock 0 1091 400
throw 1 1092 401
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -348788042: return bem_copy_0();
case 1914143778: return bem_lockGetDirect_0();
case -1228265996: return bem_getMap_0();
case -463796871: return bem_clear_0();
case 165794641: return bem_once_0();
case -2003272432: return bem_isEmptyGet_0();
case 1966412141: return bem_iteratorGet_0();
case -393323283: return bem_toAny_0();
case -1352792576: return bem_close_0();
case -355041847: return bem_get_0();
case 630420492: return bem_containerGetDirect_0();
case 896197971: return bem_tagGet_0();
case 100095788: return bem_lockGet_0();
case 644616544: return bem_serializationIteratorGet_0();
case 707233343: return bem_copyContainer_0();
case 575220420: return bem_fieldIteratorGet_0();
case -1674239636: return bem_echo_0();
case 30730421: return bem_many_0();
case -792258603: return bem_containerGet_0();
case 1724083576: return bem_serializeContents_0();
case 1558292825: return bem_deserializeClassNameGet_0();
case -307062183: return bem_toString_0();
case 585348009: return bem_fieldNamesGet_0();
case 2141644828: return bem_hashGet_0();
case -591889797: return bem_create_0();
case 1185842043: return bem_sourceFileNameGet_0();
case -763923474: return bem_new_0();
case 1658721122: return bem_sizeGet_0();
case 1912156906: return bem_serializeToString_0();
case -180542304: return bem_classNameGet_0();
case -1925117861: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -735046391: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291041689: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1311203330: return bem_def_1(bevd_0);
case -383640751: return bem_has_1(bevd_0);
case 1294060201: return bem_sameClass_1(bevd_0);
case -1353025300: return bem_equals_1(bevd_0);
case -642381822: return bem_undefined_1(bevd_0);
case 1299414631: return bem_notEquals_1(bevd_0);
case 1953734144: return bem_otherType_1(bevd_0);
case -835917636: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 404510287: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 588714245: return bem_lockSet_1(bevd_0);
case 1160412715: return bem_sameType_1(bevd_0);
case 1084665541: return bem_lockSetDirect_1(bevd_0);
case -617329904: return bem_getAndClear_1(bevd_0);
case -767519146: return bem_get_1(bevd_0);
case 1121300695: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -437264163: return bem_putReturn_1(bevd_0);
case 422988859: return bem_sameObject_1(bevd_0);
case 609382991: return bem_copyTo_1(bevd_0);
case -598110752: return bem_new_1(bevd_0);
case -264866456: return bem_addValue_1(bevd_0);
case 1321328032: return bem_defined_1(bevd_0);
case 71632622: return bem_delete_1(bevd_0);
case -231248441: return bem_undef_1(bevd_0);
case 1193851386: return bem_containerSet_1(bevd_0);
case -1266006646: return bem_put_1(bevd_0);
case 543167157: return bem_otherClass_1(bevd_0);
case 307403312: return bem_containerSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1075614417: return bem_put_2(bevd_0, bevd_1);
case 1682184009: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1545946221: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 936030170: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -237643184: return bem_has_2(bevd_0, bevd_1);
case -738475216: return bem_getOrPut_2(bevd_0, bevd_1);
case 1822516892: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2094225927: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 892604091: return bem_get_2(bevd_0, bevd_1);
case 1667865274: return bem_delete_2(bevd_0, bevd_1);
case 2078220161: return bem_putReturn_2(bevd_0, bevd_1);
case -1122797756: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1461569474: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 1462387057: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1743586386: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case -1352559114: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
