namespace be {
/* IO:File: source/build/Pass10.be */
public sealed class BEC_3_5_5_6_BuildVisitPass10 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass10() { }
static BEC_3_5_5_6_BuildVisitPass10() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x30};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass10_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x30,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitPass10_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_1 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_2 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_3 = {0x61,0x6E,0x63,0x68,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_5 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass10_bels_6 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
public static new BEC_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;

public static new BET_3_5_5_6_BuildVisitPass10 bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;

public BEC_2_6_6_SystemObject bem_condCall_2(BEC_2_6_6_SystemObject beva_condany, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_acc = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_5_4_BuildCall bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_cnode.bemd_1(-1046028261, bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_cnode.bemd_1(-1762903739, bevt_1_tmpany_phold);
bevl_acc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_acc.bemd_1(-1762903739, bevt_2_tmpany_phold);
bevl_acc.bemd_1(-1046028261, beva_condany);
bevl_cnode.bemd_1(1188023351, bevl_acc);
bevt_3_tmpany_phold = bevl_cnode.bemd_0(2079512979);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_0));
bevt_3_tmpany_phold.bemd_1(-768245062, bevt_4_tmpany_phold);
bevl_nnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nnode.bemd_1(-1762903739, beva_value);
bevl_cnode.bemd_1(1188023351, bevl_nnode);
return bevl_cnode;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_anchor = null;
BEC_2_6_6_SystemObject bevl_condany = null;
BEC_2_6_6_SystemObject bevl_cvnp = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_rinode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
bevt_4_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_5_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_4_tmpany_phold.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 32 */ {
bevt_8_tmpany_phold = beva_node.bem_containedGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_lengthGet_0();
bevt_9_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass10_bevo_0;
if (bevt_7_tmpany_phold.bevi_int == bevt_9_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 32 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 32 */
 else  /* Line: 32 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 32 */ {
bevt_13_tmpany_phold = beva_node.bem_containedGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_firstGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-271849414);
bevt_14_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(-1698354185, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 32 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 32 */
 else  /* Line: 32 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 32 */ {
bevt_16_tmpany_phold = beva_node.bem_containedGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_firstGet_0();
beva_node.bem_takeContents_1((BEC_2_5_4_BuildNode) bevt_15_tmpany_phold );
return beva_node;
} /* Line: 34 */
bevt_18_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_18_tmpany_phold.bevi_int == bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_20_tmpany_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_20_tmpany_phold);
beva_node.bem_syncVariable_1(this);
} /* Line: 39 */
bevt_22_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevt_26_tmpany_phold = beva_node.bem_heldGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-518995068);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_1));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(-1698354185, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 42 */ {
bevt_30_tmpany_phold = beva_node.bem_heldGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-518995068);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_2));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-1698354185, bevt_31_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 42 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 42 */
 else  /* Line: 42 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 42 */ {
bevl_anchor = beva_node.bem_anchorGet_0();
bevl_condany = bevl_anchor.bemd_0(1648322164);
if (bevl_condany == null) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass10_bels_3));
bevl_condany = bevl_anchor.bemd_2(-1853969009, bevt_33_tmpany_phold, bevp_build);
bevt_34_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_condany.bemd_1(215845561, bevt_34_tmpany_phold);
bevl_cvnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitPass10_bels_4));
bevl_cvnp.bemd_1(-806855228, bevt_35_tmpany_phold);
bevl_condany.bemd_1(1504564716, bevl_cvnp);
bevl_anchor.bemd_1(711497525, bevl_condany);
} /* Line: 53 */
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_36_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-1762903739, bevt_36_tmpany_phold);
bevl_inode.bemd_1(804392221, beva_node);
bevl_rinode = bevl_inode;
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(804392221, beva_node);
bevt_37_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-1762903739, bevt_37_tmpany_phold);
bevl_inode.bemd_1(1188023351, bevl_pnode);
bevt_39_tmpany_phold = beva_node.bem_containedGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_firstGet_0();
bevl_pnode.bemd_1(1188023351, bevt_38_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(804392221, beva_node);
bevt_40_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-1762903739, bevt_40_tmpany_phold);
bevl_inode.bemd_1(1188023351, bevl_bnode);
bevt_43_tmpany_phold = beva_node.bem_heldGet_0();
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(-518995068);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_5));
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(-1698354185, bevt_44_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_41_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevt_46_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_45_tmpany_phold = bem_condCall_2(bevl_condany, bevt_46_tmpany_phold);
bevl_bnode.bemd_1(1188023351, bevt_45_tmpany_phold);
} /* Line: 75 */
 else  /* Line: 77 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(804392221, beva_node);
bevt_47_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-1762903739, bevt_47_tmpany_phold);
bevl_inode.bemd_1(711497525, bevl_condany);
bevl_bnode.bemd_1(1188023351, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(804392221, beva_node);
bevt_48_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-1762903739, bevt_48_tmpany_phold);
bevl_inode.bemd_1(1188023351, bevl_pnode);
bevt_49_tmpany_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(1188023351, bevt_49_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(804392221, beva_node);
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-1762903739, bevt_50_tmpany_phold);
bevl_inode.bemd_1(1188023351, bevl_bnode);
bevt_52_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_51_tmpany_phold = bem_condCall_2(bevl_condany, bevt_52_tmpany_phold);
bevl_bnode.bemd_1(1188023351, bevt_51_tmpany_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(804392221, beva_node);
bevt_53_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-1762903739, bevt_53_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(804392221, beva_node);
bevt_54_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-1762903739, bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_55_tmpany_phold = bem_condCall_2(bevl_condany, bevt_56_tmpany_phold);
bevl_bnode.bemd_1(1188023351, bevt_55_tmpany_phold);
bevl_enode.bemd_1(1188023351, bevl_bnode);
bevl_inode.bemd_1(1188023351, bevl_enode);
} /* Line: 104 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(804392221, beva_node);
bevt_57_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-1762903739, bevt_57_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(804392221, beva_node);
bevt_58_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-1762903739, bevt_58_tmpany_phold);
bevl_rinode.bemd_1(1188023351, bevl_enode);
bevl_enode.bemd_1(1188023351, bevl_bnode);
bevt_61_tmpany_phold = beva_node.bem_heldGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-518995068);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_6_BuildVisitPass10_bels_6));
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_1(-1698354185, bevt_62_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 116 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(804392221, beva_node);
bevt_63_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(-1762903739, bevt_63_tmpany_phold);
bevl_inode.bemd_1(711497525, bevl_condany);
bevl_bnode.bemd_1(1188023351, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(804392221, beva_node);
bevt_64_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(-1762903739, bevt_64_tmpany_phold);
bevl_inode.bemd_1(1188023351, bevl_pnode);
bevt_65_tmpany_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(1188023351, bevt_65_tmpany_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(804392221, beva_node);
bevt_66_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-1762903739, bevt_66_tmpany_phold);
bevl_inode.bemd_1(1188023351, bevl_bnode);
bevt_68_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_67_tmpany_phold = bem_condCall_2(bevl_condany, bevt_68_tmpany_phold);
bevl_bnode.bemd_1(1188023351, bevt_67_tmpany_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(804392221, beva_node);
bevt_69_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(-1762903739, bevt_69_tmpany_phold);
bevl_inode.bemd_1(1188023351, bevl_enode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(804392221, beva_node);
bevt_70_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(-1762903739, bevt_70_tmpany_phold);
bevt_72_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_71_tmpany_phold = bem_condCall_2(bevl_condany, bevt_72_tmpany_phold);
bevl_bnode.bemd_1(1188023351, bevt_71_tmpany_phold);
bevl_enode.bemd_1(1188023351, bevl_bnode);
} /* Line: 142 */
 else  /* Line: 143 */ {
bevt_74_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_73_tmpany_phold = bem_condCall_2(bevl_condany, bevt_74_tmpany_phold);
bevl_bnode.bemd_1(1188023351, bevt_73_tmpany_phold);
} /* Line: 144 */
bevl_anchor.bemd_1(157456324, bevl_rinode);
beva_node.bem_containedSet_1(null);
bevt_75_tmpany_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_75_tmpany_phold);
beva_node.bem_heldSet_1(bevl_condany);
beva_node.bem_syncAddVariable_0();
bevt_76_tmpany_phold = bevl_rinode.bemd_0(208144379);
return (BEC_2_5_4_BuildNode) bevt_76_tmpany_phold;
} /* Line: 153 */
bevt_77_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_77_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 18, 19, 19, 20, 21, 21, 22, 23, 24, 24, 24, 25, 26, 27, 28, 32, 32, 32, 32, 32, 32, 32, 32, 32, 0, 0, 0, 32, 32, 32, 32, 32, 0, 0, 0, 33, 33, 33, 34, 37, 37, 37, 37, 38, 38, 39, 42, 42, 42, 42, 42, 42, 42, 42, 0, 42, 42, 42, 42, 0, 0, 0, 0, 0, 44, 45, 47, 47, 48, 48, 49, 49, 50, 51, 51, 52, 53, 56, 57, 57, 58, 60, 62, 63, 64, 64, 65, 67, 67, 67, 69, 70, 71, 71, 72, 74, 74, 74, 74, 75, 75, 75, 79, 80, 81, 81, 82, 83, 85, 86, 87, 87, 88, 89, 89, 90, 91, 92, 92, 93, 94, 94, 94, 96, 97, 98, 98, 99, 100, 101, 101, 102, 102, 102, 103, 104, 107, 108, 109, 109, 110, 111, 112, 112, 113, 114, 116, 116, 116, 116, 117, 118, 119, 119, 120, 121, 123, 124, 125, 125, 126, 127, 127, 128, 129, 130, 130, 131, 132, 132, 132, 134, 135, 136, 136, 137, 138, 139, 140, 140, 141, 141, 141, 142, 144, 144, 144, 148, 149, 150, 150, 151, 152, 153, 153, 156, 156};
public static new int[] bevs_smnlec
 = new int[] {29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 134, 135, 136, 141, 142, 143, 144, 145, 150, 151, 154, 158, 161, 162, 163, 164, 165, 167, 170, 174, 177, 178, 179, 180, 182, 183, 184, 189, 190, 191, 192, 194, 195, 196, 201, 202, 203, 204, 205, 207, 210, 211, 212, 213, 215, 218, 222, 225, 229, 232, 233, 234, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 273, 274, 275, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 364, 365, 366, 368, 369, 370, 371, 372, 373, 374, 375, 377, 378};
/* BEGIN LINEINFO 
assign 1 17 29
new 1 17 29
assign 1 18 30
new 0 18 30
heldSet 1 18 31
assign 1 19 32
CALLGet 0 19 32
typenameSet 1 19 33
assign 1 20 34
new 1 20 34
assign 1 21 35
VARGet 0 21 35
typenameSet 1 21 36
heldSet 1 22 37
addValue 1 23 38
assign 1 24 39
heldGet 0 24 39
assign 1 24 40
new 0 24 40
nameSet 1 24 41
assign 1 25 42
new 1 25 42
typenameSet 1 26 43
addValue 1 27 44
return 1 28 45
assign 1 32 134
typenameGet 0 32 134
assign 1 32 135
PARENSGet 0 32 135
assign 1 32 136
equals 1 32 141
assign 1 32 142
containedGet 0 32 142
assign 1 32 143
lengthGet 0 32 143
assign 1 32 144
new 0 32 144
assign 1 32 145
equals 1 32 150
assign 1 0 151
assign 1 0 154
assign 1 0 158
assign 1 32 161
containedGet 0 32 161
assign 1 32 162
firstGet 0 32 162
assign 1 32 163
typenameGet 0 32 163
assign 1 32 164
PARENSGet 0 32 164
assign 1 32 165
equals 1 32 165
assign 1 0 167
assign 1 0 170
assign 1 0 174
assign 1 33 177
containedGet 0 33 177
assign 1 33 178
firstGet 0 33 178
takeContents 1 33 179
return 1 34 180
assign 1 37 182
typenameGet 0 37 182
assign 1 37 183
IDGet 0 37 183
assign 1 37 184
equals 1 37 189
assign 1 38 190
VARGet 0 38 190
typenameSet 1 38 191
syncVariable 1 39 192
assign 1 42 194
typenameGet 0 42 194
assign 1 42 195
CALLGet 0 42 195
assign 1 42 196
equals 1 42 201
assign 1 42 202
heldGet 0 42 202
assign 1 42 203
nameGet 0 42 203
assign 1 42 204
new 0 42 204
assign 1 42 205
equals 1 42 205
assign 1 0 207
assign 1 42 210
heldGet 0 42 210
assign 1 42 211
nameGet 0 42 211
assign 1 42 212
new 0 42 212
assign 1 42 213
equals 1 42 213
assign 1 0 215
assign 1 0 218
assign 1 0 222
assign 1 0 225
assign 1 0 229
assign 1 44 232
anchorGet 0 44 232
assign 1 45 233
condanyGet 0 45 233
assign 1 47 234
undef 1 47 239
assign 1 48 240
new 0 48 240
assign 1 48 241
tmpVar 2 48 241
assign 1 49 242
new 0 49 242
isTypedSet 1 49 243
assign 1 50 244
new 0 50 244
assign 1 51 245
new 0 51 245
fromString 1 51 246
namepathSet 1 52 247
condanySet 1 53 248
assign 1 56 250
new 1 56 250
assign 1 57 251
IFGet 0 57 251
typenameSet 1 57 252
copyLoc 1 58 253
assign 1 60 254
assign 1 62 255
new 1 62 255
copyLoc 1 63 256
assign 1 64 257
PARENSGet 0 64 257
typenameSet 1 64 258
addValue 1 65 259
assign 1 67 260
containedGet 0 67 260
assign 1 67 261
firstGet 0 67 261
addValue 1 67 262
assign 1 69 263
new 1 69 263
copyLoc 1 70 264
assign 1 71 265
BRACESGet 0 71 265
typenameSet 1 71 266
addValue 1 72 267
assign 1 74 268
heldGet 0 74 268
assign 1 74 269
nameGet 0 74 269
assign 1 74 270
new 0 74 270
assign 1 74 271
equals 1 74 271
assign 1 75 273
TRUEGet 0 75 273
assign 1 75 274
condCall 2 75 274
addValue 1 75 275
assign 1 79 278
new 1 79 278
copyLoc 1 80 279
assign 1 81 280
IFGet 0 81 280
typenameSet 1 81 281
condanySet 1 82 282
addValue 1 83 283
assign 1 85 284
new 1 85 284
copyLoc 1 86 285
assign 1 87 286
PARENSGet 0 87 286
typenameSet 1 87 287
addValue 1 88 288
assign 1 89 289
secondGet 0 89 289
addValue 1 89 290
assign 1 90 291
new 1 90 291
copyLoc 1 91 292
assign 1 92 293
BRACESGet 0 92 293
typenameSet 1 92 294
addValue 1 93 295
assign 1 94 296
TRUEGet 0 94 296
assign 1 94 297
condCall 2 94 297
addValue 1 94 298
assign 1 96 299
new 1 96 299
copyLoc 1 97 300
assign 1 98 301
ELSEGet 0 98 301
typenameSet 1 98 302
assign 1 99 303
new 1 99 303
copyLoc 1 100 304
assign 1 101 305
BRACESGet 0 101 305
typenameSet 1 101 306
assign 1 102 307
FALSEGet 0 102 307
assign 1 102 308
condCall 2 102 308
addValue 1 102 309
addValue 1 103 310
addValue 1 104 311
assign 1 107 313
new 1 107 313
copyLoc 1 108 314
assign 1 109 315
ELSEGet 0 109 315
typenameSet 1 109 316
assign 1 110 317
new 1 110 317
copyLoc 1 111 318
assign 1 112 319
BRACESGet 0 112 319
typenameSet 1 112 320
addValue 1 113 321
addValue 1 114 322
assign 1 116 323
heldGet 0 116 323
assign 1 116 324
nameGet 0 116 324
assign 1 116 325
new 0 116 325
assign 1 116 326
equals 1 116 326
assign 1 117 328
new 1 117 328
copyLoc 1 118 329
assign 1 119 330
IFGet 0 119 330
typenameSet 1 119 331
condanySet 1 120 332
addValue 1 121 333
assign 1 123 334
new 1 123 334
copyLoc 1 124 335
assign 1 125 336
PARENSGet 0 125 336
typenameSet 1 125 337
addValue 1 126 338
assign 1 127 339
secondGet 0 127 339
addValue 1 127 340
assign 1 128 341
new 1 128 341
copyLoc 1 129 342
assign 1 130 343
BRACESGet 0 130 343
typenameSet 1 130 344
addValue 1 131 345
assign 1 132 346
TRUEGet 0 132 346
assign 1 132 347
condCall 2 132 347
addValue 1 132 348
assign 1 134 349
new 1 134 349
copyLoc 1 135 350
assign 1 136 351
ELSEGet 0 136 351
typenameSet 1 136 352
addValue 1 137 353
assign 1 138 354
new 1 138 354
copyLoc 1 139 355
assign 1 140 356
BRACESGet 0 140 356
typenameSet 1 140 357
assign 1 141 358
FALSEGet 0 141 358
assign 1 141 359
condCall 2 141 359
addValue 1 141 360
addValue 1 142 361
assign 1 144 364
FALSEGet 0 144 364
assign 1 144 365
condCall 2 144 365
addValue 1 144 366
beforeInsert 1 148 368
containedSet 1 149 369
assign 1 150 370
VARGet 0 150 370
typenameSet 1 150 371
heldSet 1 151 372
syncAddVariable 0 152 373
assign 1 153 374
nextDescendGet 0 153 374
return 1 153 375
assign 1 156 377
nextDescendGet 0 156 377
return 1 156 378
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -963755335: return bem_fieldIteratorGet_0();
case -615183710: return bem_constGet_0();
case -1004079418: return bem_once_0();
case -1108167878: return bem_serializeToString_0();
case 486528825: return bem_buildGet_0();
case 1603326601: return bem_many_0();
case -918875161: return bem_transGetDirect_0();
case -1786271241: return bem_sourceFileNameGet_0();
case -469171007: return bem_serializeContents_0();
case -545958368: return bem_toAny_0();
case -632169362: return bem_print_0();
case -2048609488: return bem_tagGet_0();
case -212376625: return bem_iteratorGet_0();
case 667887186: return bem_ntypesGet_0();
case 1262389595: return bem_ntypesGetDirect_0();
case 1909096874: return bem_create_0();
case 1059288816: return bem_deserializeClassNameGet_0();
case 1419414154: return bem_new_0();
case 603416881: return bem_constGetDirect_0();
case 2077040828: return bem_copy_0();
case 429419643: return bem_echo_0();
case 1730620110: return bem_serializationIteratorGet_0();
case 1741010261: return bem_classNameGet_0();
case -1918539521: return bem_toString_0();
case -31138328: return bem_transGet_0();
case -274080024: return bem_buildGetDirect_0();
case -811598956: return bem_fieldNamesGet_0();
case 1687921048: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -363168387: return bem_sameType_1(bevd_0);
case 89655582: return bem_sameClass_1(bevd_0);
case 9850015: return bem_end_1(bevd_0);
case -311056169: return bem_defined_1(bevd_0);
case 1136316771: return bem_constSetDirect_1(bevd_0);
case 2066297581: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1702353157: return bem_begin_1(bevd_0);
case -1698354185: return bem_equals_1(bevd_0);
case 1106452362: return bem_notEquals_1(bevd_0);
case 455477536: return bem_buildSetDirect_1(bevd_0);
case -1737509925: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1646953573: return bem_def_1(bevd_0);
case 943569262: return bem_transSet_1(bevd_0);
case 1651716346: return bem_sameObject_1(bevd_0);
case -1434304379: return bem_otherType_1(bevd_0);
case 1368764831: return bem_otherClass_1(bevd_0);
case 213280032: return bem_undefined_1(bevd_0);
case 1933770529: return bem_undef_1(bevd_0);
case -425873190: return bem_buildSet_1(bevd_0);
case 292605993: return bem_transSetDirect_1(bevd_0);
case -2088117046: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1208686813: return bem_constSet_1(bevd_0);
case -1192371039: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1521312747: return bem_ntypesSet_1(bevd_0);
case 1162742389: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 22257015: return bem_copyTo_1(bevd_0);
case -641770360: return bem_ntypesSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1573347156: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 499218292: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 442267417: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1605617010: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -389198907: return bem_condCall_2(bevd_0, bevd_1);
case -355419017: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1995014062: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -698280780: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass10_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass10_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass10();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst = (BEC_3_5_5_6_BuildVisitPass10) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_6_BuildVisitPass10.bece_BEC_3_5_5_6_BuildVisitPass10_bevs_type;
}
}
}
