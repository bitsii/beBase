namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_3_9_4_8_ContainerListIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
static BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_1 = (new BEC_2_4_3_MathInt(-1));
public static new BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;

public static new BET_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_list = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_3_9_4_8_ContainerListIterator_bevo_0;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_4_tmpany_phold = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 35 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 35 */
 else  /* Line: 35 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 35 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 36 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
bevt_2_tmpany_phold = bece_BEC_3_9_4_8_ContainerListIterator_bevo_1;
if (bevp_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_4_tmpany_phold = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 53 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_pos.bevi_int++;
bevt_0_tmpany_phold = bevp_list.bem_get_1(bevp_pos);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevp_pos.bevi_int++;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
bevp_pos = bevp_pos;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nposGet_0() {
return bevp_npos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_nposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 19, 20, 25, 26, 27, 31, 35, 35, 35, 35, 35, 35, 0, 0, 0, 36, 36, 38, 38, 42, 42, 46, 46, 50, 51, 52, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 55, 55, 59, 60, 60, 64, 65, 65, 69, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 24, 28, 29, 30, 34, 44, 45, 50, 51, 52, 57, 58, 61, 65, 68, 69, 71, 72, 76, 77, 81, 82, 92, 93, 94, 95, 100, 101, 102, 107, 108, 111, 115, 118, 119, 121, 122, 126, 127, 128, 132, 133, 134, 137, 142, 145, 149, 152, 156, 159};
/* BEGIN LINEINFO 
assign 1 18 21
new 0 18 21
assign 1 19 22
new 0 19 22
assign 1 19 23
new 1 19 23
assign 1 20 24
new 0 20 24
assign 1 25 28
new 0 25 28
assign 1 26 29
assign 1 27 30
new 0 27 30
return 1 31 34
assign 1 35 44
new 0 35 44
assign 1 35 45
greater 1 35 50
assign 1 35 51
lengthGet 0 35 51
assign 1 35 52
lesser 1 35 57
assign 1 0 58
assign 1 0 61
assign 1 0 65
assign 1 36 68
new 0 36 68
return 1 36 69
assign 1 38 71
new 0 38 71
return 1 38 72
assign 1 42 76
get 1 42 76
return 1 42 77
assign 1 46 81
put 2 46 81
return 1 46 82
setValue 1 50 92
incrementValue 0 51 93
assign 1 52 94
new 0 52 94
assign 1 52 95
greaterEquals 1 52 100
assign 1 52 101
lengthGet 0 52 101
assign 1 52 102
lesser 1 52 107
assign 1 0 108
assign 1 0 111
assign 1 0 115
assign 1 53 118
new 0 53 118
return 1 53 119
assign 1 55 121
new 0 55 121
return 1 55 122
incrementValue 0 59 126
assign 1 60 127
get 1 60 127
return 1 60 128
incrementValue 0 64 132
assign 1 65 133
put 2 65 133
return 1 65 134
assign 1 69 137
addValue 1 69 137
return 1 0 142
assign 1 0 145
return 1 0 149
assign 1 0 152
return 1 0 156
assign 1 0 159
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1714984646: return bem_serializeToString_0();
case 1348777534: return bem_many_0();
case -873085717: return bem_iteratorGet_0();
case 1907596400: return bem_copy_0();
case -1921829025: return bem_nextGet_0();
case 1644493631: return bem_nposGet_0();
case -1320125172: return bem_once_0();
case -2126482006: return bem_hasCurrentGet_0();
case 713197195: return bem_deserializeClassNameGet_0();
case -977833063: return bem_toString_0();
case -1698152847: return bem_serializationIteratorGet_0();
case -1435450334: return bem_classNameGet_0();
case -100075913: return bem_new_0();
case -442967792: return bem_posGet_0();
case 975002362: return bem_tagGet_0();
case -2080318285: return bem_sourceFileNameGet_0();
case -58474533: return bem_currentGet_0();
case 1418537405: return bem_fieldIteratorGet_0();
case 335515617: return bem_hasNextGet_0();
case 557461910: return bem_listGet_0();
case -92908170: return bem_print_0();
case 596758489: return bem_create_0();
case 189986949: return bem_toAny_0();
case 1732066970: return bem_echo_0();
case -328171317: return bem_hashGet_0();
case 1361238708: return bem_serializeContents_0();
case -1154130332: return bem_containerGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -36926033: return bem_notEquals_1(bevd_0);
case 1456864247: return bem_currentSet_1(bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case -1979278773: return bem_posSet_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case -1969178207: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case -1685745238: return bem_new_1(bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -528451924: return bem_listSet_1(bevd_0);
case -953808823: return bem_nposSet_1(bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case 410992223: return bem_nextSet_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_4_8_ContainerListIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;
}
}
}
