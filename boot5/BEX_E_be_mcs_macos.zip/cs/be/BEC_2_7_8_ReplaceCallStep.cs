namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_7_8_ReplaceCallStep : BEC_2_6_6_SystemObject {
public BEC_2_7_8_ReplaceCallStep() { }
static BEC_2_7_8_ReplaceCallStep() { }
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x43,0x61,0x6C,0x6C,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_7_8_ReplaceCallStep_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_7_8_ReplaceCallStep_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;

public static new BET_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_type;

public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_callArgs;
public virtual BEC_2_7_8_ReplaceCallStep bem_new_1(BEC_2_9_10_ContainerLinkedList beva_payloads) {
BEC_2_4_3_MathInt bevl_pi = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_callName = (BEC_2_4_6_TextString) beva_payloads.bem_get_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = beva_payloads.bem_lengthGet_0();
bevt_3_tmpany_phold = bece_BEC_2_7_8_ReplaceCallStep_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_subtract_1(bevt_3_tmpany_phold);
bevp_callArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_tmpany_phold);
bevl_pi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 23 */ {
bevt_5_tmpany_phold = beva_payloads.bem_lengthGet_0();
if (bevl_pi.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevt_7_tmpany_phold = bece_BEC_2_7_8_ReplaceCallStep_bevo_1;
bevt_6_tmpany_phold = bevl_pi.bem_subtract_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_payloads.bem_get_1(bevl_pi);
bevp_callArgs.bem_put_2(bevt_6_tmpany_phold, bevt_8_tmpany_phold);
bevl_pi = bevl_pi.bem_increment_0();
} /* Line: 23 */
 else  /* Line: 23 */ {
break;
} /* Line: 23 */
} /* Line: 23 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_r.bemd_2(69135057, bevp_callName, bevp_callArgs);
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_4_6_TextString bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_7_8_ReplaceCallStep bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_callArgsGet_0() {
return bevp_callArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_callArgsGetDirect_0() {
return bevp_callArgs;
} /*method end*/
public virtual BEC_2_7_8_ReplaceCallStep bem_callArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {19, 19, 20, 20, 20, 20, 23, 23, 23, 23, 24, 24, 24, 24, 23, 30, 30, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 30, 31, 32, 33, 36, 37, 42, 43, 44, 45, 46, 47, 57, 58, 61, 64, 67, 71, 75, 78, 81, 85};
/* BEGIN LINEINFO 
assign 1 19 27
new 0 19 27
assign 1 19 28
get 1 19 28
assign 1 20 29
lengthGet 0 20 29
assign 1 20 30
new 0 20 30
assign 1 20 31
subtract 1 20 31
assign 1 20 32
new 1 20 32
assign 1 23 33
new 0 23 33
assign 1 23 36
lengthGet 0 23 36
assign 1 23 37
lesser 1 23 42
assign 1 24 43
new 0 24 43
assign 1 24 44
subtract 1 24 44
assign 1 24 45
get 1 24 45
put 2 24 46
assign 1 23 47
increment 0 23 47
assign 1 30 57
invoke 2 30 57
return 1 30 58
return 1 0 61
return 1 0 64
assign 1 0 67
assign 1 0 71
return 1 0 75
return 1 0 78
assign 1 0 81
assign 1 0 85
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2130473897: return bem_callArgsGetDirect_0();
case -2055997260: return bem_fieldIteratorGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -323661464: return bem_serializeToString_0();
case -784931357: return bem_callArgsGet_0();
case -96748926: return bem_callNameGet_0();
case 1064677251: return bem_many_0();
case -2092760709: return bem_once_0();
case 1076647192: return bem_create_0();
case 849387251: return bem_toAny_0();
case -1430066973: return bem_print_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case 864393987: return bem_tagGet_0();
case 605836827: return bem_sourceFileNameGet_0();
case 1359360249: return bem_echo_0();
case -236887613: return bem_classNameGet_0();
case -1369483363: return bem_fieldNamesGet_0();
case -1045314855: return bem_callNameGetDirect_0();
case 2070502838: return bem_copy_0();
case -1852877275: return bem_new_0();
case 928457034: return bem_serializeContents_0();
case 996718380: return bem_toString_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -960159496: return bem_otherClass_1(bevd_0);
case -594063040: return bem_callArgsSetDirect_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1152417113: return bem_callArgsSet_1(bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case 1837250172: return bem_callNameSet_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case -1088647997: return bem_callNameSetDirect_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -607827829: return bem_handle_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
case 791078773: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_7_8_ReplaceCallStep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_8_ReplaceCallStep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_7_8_ReplaceCallStep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst = (BEC_2_7_8_ReplaceCallStep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_type;
}
}
}
