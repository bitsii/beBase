namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_19_SystemInvocationException : BEC_2_6_9_SystemException {
public BEC_2_6_19_SystemInvocationException() { }
static BEC_2_6_19_SystemInvocationException() { }
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_19_SystemInvocationException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_inst;

public static new BET_2_6_19_SystemInvocationException bece_BEC_2_6_19_SystemInvocationException_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -602506370: return bem_klassNameGetDirect_0();
case -2019148755: return bem_descriptionGet_0();
case 1724083576: return bem_serializeContents_0();
case 1233246625: return bem_translatedGet_0();
case 585348009: return bem_fieldNamesGet_0();
case 1786428719: return bem_lineNumberGet_0();
case -180542304: return bem_classNameGet_0();
case 575220420: return bem_fieldIteratorGet_0();
case 1912156906: return bem_serializeToString_0();
case 1966412141: return bem_iteratorGet_0();
case -882060690: return bem_klassNameGet_0();
case 1871932221: return bem_lineNumberGetDirect_0();
case 165794641: return bem_once_0();
case -348788042: return bem_copy_0();
case -1566913555: return bem_framesGet_0();
case 1526912451: return bem_vvGetDirect_0();
case 1472485105: return bem_emitLangGet_0();
case 30730421: return bem_many_0();
case -938209477: return bem_framesGetDirect_0();
case 1870965514: return bem_getFrameText_0();
case -1790672877: return bem_methodNameGetDirect_0();
case 1069246707: return bem_translatedGetDirect_0();
case 2055196463: return bem_translateEmittedExceptionInner_0();
case -1568880598: return bem_methodNameGet_0();
case -393323283: return bem_toAny_0();
case 1703036656: return bem_framesTextGetDirect_0();
case -763923474: return bem_new_0();
case 644616544: return bem_serializationIteratorGet_0();
case -1007073375: return bem_langGetDirect_0();
case 1137534835: return bem_framesTextGet_0();
case 1416734222: return bem_langGet_0();
case 1558292825: return bem_deserializeClassNameGet_0();
case -307062183: return bem_toString_0();
case -1925117861: return bem_print_0();
case -1674239636: return bem_echo_0();
case 1185842043: return bem_sourceFileNameGet_0();
case 319091158: return bem_vvGet_0();
case 806591950: return bem_translateEmittedException_0();
case -591889797: return bem_create_0();
case -723748773: return bem_fileNameGetDirect_0();
case 2141644828: return bem_hashGet_0();
case -377715420: return bem_emitLangGetDirect_0();
case -891849027: return bem_descriptionGetDirect_0();
case 896197971: return bem_tagGet_0();
case 2031551795: return bem_fileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1294060201: return bem_sameClass_1(bevd_0);
case 787176003: return bem_klassNameSet_1(bevd_0);
case -642381822: return bem_undefined_1(bevd_0);
case 1299414631: return bem_notEquals_1(bevd_0);
case 1321328032: return bem_defined_1(bevd_0);
case -231248441: return bem_undef_1(bevd_0);
case 1609856244: return bem_descriptionSet_1(bevd_0);
case 1510816246: return bem_framesTextSetDirect_1(bevd_0);
case 1394255048: return bem_vvSet_1(bevd_0);
case 1450684457: return bem_lineNumberSet_1(bevd_0);
case -431254658: return bem_descriptionSetDirect_1(bevd_0);
case 422988859: return bem_sameObject_1(bevd_0);
case 1215517661: return bem_lineNumberSetDirect_1(bevd_0);
case 947611661: return bem_framesTextSet_1(bevd_0);
case 1824585865: return bem_translatedSetDirect_1(bevd_0);
case 498180669: return bem_framesSet_1(bevd_0);
case -320293072: return bem_langSetDirect_1(bevd_0);
case -848839279: return bem_emitLangSet_1(bevd_0);
case -252643284: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1298268887: return bem_methodNameSet_1(bevd_0);
case 404510287: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -291041689: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1121300695: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1353025300: return bem_equals_1(bevd_0);
case 1138851301: return bem_emitLangSetDirect_1(bevd_0);
case 1735560104: return bem_translatedSet_1(bevd_0);
case 1160412715: return bem_sameType_1(bevd_0);
case 1160514328: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1311203330: return bem_def_1(bevd_0);
case -1460469933: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 290494934: return bem_langSet_1(bevd_0);
case -2114385737: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -227870137: return bem_fileNameSet_1(bevd_0);
case -77247542: return bem_fileNameSetDirect_1(bevd_0);
case 1953734144: return bem_otherType_1(bevd_0);
case -598110752: return bem_new_1(bevd_0);
case 96565154: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 543167157: return bem_otherClass_1(bevd_0);
case 977261775: return bem_klassNameSetDirect_1(bevd_0);
case -856700976: return bem_vvSetDirect_1(bevd_0);
case -1178829580: return bem_methodNameSetDirect_1(bevd_0);
case 896171781: return bem_framesSetDirect_1(bevd_0);
case -1904220785: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -735046391: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 609382991: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1545946221: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1682184009: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2094225927: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1122797756: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1822516892: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936030170: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1462387057: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -707790303: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemInvocationException_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_19_SystemInvocationException_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_19_SystemInvocationException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst = (BEC_2_6_19_SystemInvocationException) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_19_SystemInvocationException.bece_BEC_2_6_19_SystemInvocationException_bevs_type;
}
}
}
