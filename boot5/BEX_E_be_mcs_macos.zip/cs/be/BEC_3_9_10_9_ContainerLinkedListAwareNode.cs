namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_9_ContainerLinkedListAwareNode : BEC_3_9_10_4_ContainerLinkedListNode {
public BEC_3_9_10_9_ContainerLinkedListAwareNode() { }
static BEC_3_9_10_9_ContainerLinkedListAwareNode() { }
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x41,0x77,0x61,0x72,0x65,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;

public static new BET_3_9_10_9_ContainerLinkedListAwareNode bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;

public override BEC_3_9_10_4_ContainerLinkedListNode bem_new_2(BEC_2_6_6_SystemObject beva__held, BEC_2_9_10_ContainerLinkedList beva__mylist) {
bevp_held = beva__held;
bevp_held.bemd_1(-1925297702, this);
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public override BEC_3_9_10_4_ContainerLinkedListNode bem_heldSet_1(BEC_2_6_6_SystemObject beva__held) {
bevp_held = beva__held;
bevp_held.bemd_1(-1925297702, this);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {98, 99, 100, 104, 105};
public static new int[] bevs_smnlec
 = new int[] {13, 14, 15, 19, 20};
/* BEGIN LINEINFO 
assign 1 98 13
heldBySet 1 99 14
assign 1 100 15
assign 1 104 19
heldBySet 1 105 20
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 222096027: return bem_classNameGet_0();
case 1115258825: return bem_create_0();
case -1141049131: return bem_iteratorGet_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case -730791271: return bem_nextGet_0();
case -1841916235: return bem_priorGet_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 434654272: return bem_hashGet_0();
case -1738868718: return bem_priorGetDirect_0();
case -14767827: return bem_serializeToString_0();
case -31410563: return bem_once_0();
case 450669539: return bem_heldGet_0();
case -1121300979: return bem_fieldNamesGet_0();
case -2016997496: return bem_print_0();
case 313397795: return bem_nextGetDirect_0();
case -1194274080: return bem_toAny_0();
case 306116222: return bem_echo_0();
case 931849503: return bem_delete_0();
case -1319564975: return bem_mylistGet_0();
case 1747475389: return bem_many_0();
case 1999868679: return bem_fieldIteratorGet_0();
case -1186938268: return bem_heldGetDirect_0();
case 216845033: return bem_new_0();
case 1801694719: return bem_copy_0();
case 1366617398: return bem_tagGet_0();
case 2119098947: return bem_serializeContents_0();
case -1365182072: return bem_sourceFileNameGet_0();
case -1219673974: return bem_toString_0();
case 1256798506: return bem_mylistGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1876160136: return bem_nextSet_1(bevd_0);
case 1096471008: return bem_heldSet_1(bevd_0);
case -1246021533: return bem_equals_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case -1729296701: return bem_insertBefore_1(bevd_0);
case 2019270243: return bem_mylistSet_1(bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case 1458391009: return bem_nextSetDirect_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case 1144333376: return bem_heldSetDirect_1(bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 622475497: return bem_priorSet_1(bevd_0);
case -186128536: return bem_priorSetDirect_1(bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -240164168: return bem_undefined_1(bevd_0);
case -1062003278: return bem_mylistSetDirect_1(bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1925703576: return bem_new_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(30, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_9_ContainerLinkedListAwareNode_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_10_9_ContainerLinkedListAwareNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst = (BEC_3_9_10_9_ContainerLinkedListAwareNode) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_10_9_ContainerLinkedListAwareNode.bece_BEC_3_9_10_9_ContainerLinkedListAwareNode_bevs_type;
}
}
}
