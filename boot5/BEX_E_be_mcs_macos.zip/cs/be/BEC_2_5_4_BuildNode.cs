namespace be {
/* IO:File: source/build/Nodes.be */
public sealed class BEC_2_5_4_BuildNode : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
static BEC_2_5_4_BuildNode() { }
private static byte[] becc_BEC_2_5_4_BuildNode_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_2_5_4_BuildNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_0 = {0x3C};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_1 = {0x3E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_5 = {0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_6 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_7 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_8 = {0x20,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_9 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_10 = {0x5F,0x74,0x61,0x5F};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_11 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_12 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_13 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_15 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_4_BuildNode_bels_16 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
public static new BEC_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_inst;

public static new BET_2_5_4_BuildNode bece_BEC_2_5_4_BuildNode_bevs_type;

public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_3_9_10_9_ContainerLinkedListAwareNode bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condany;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_nlec = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_wideString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_ta_ph.bem_copy_0();
bevt_1_ta_ph = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_2_4_3_MathInt) bevt_1_ta_ph.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (bevp_contained == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_4_ta_ph = bevp_contained.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_5_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_ta_ph;
} /* Line: 45*/
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 49*/ {
if (bevl_ret == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 49*/ {
if (bevl_con == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 49*/
 else /* Line: 49*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 49*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 51*/
 else /* Line: 49*/ {
break;
} /* Line: 49*/
} /* Line: 49*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevl_ret = bem_nextPeerGet_0();
bevl_con = bem_containerGet_0();
while (true)
/* Line: 59*/ {
if (bevl_ret == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 59*/ {
if (bevl_con == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 59*/
 else /* Line: 59*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 59*/ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 61*/
 else /* Line: 59*/ {
break;
} /* Line: 59*/
} /* Line: 59*/
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 67*/ {
return null;
} /* Line: 68*/
bevl_hh = bevp_heldBy.bem_nextGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 71*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 72*/
bevt_2_ta_ph = bevl_hh.bemd_0(-425897411);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 78*/ {
return null;
} /* Line: 79*/
bevl_hh = bevp_heldBy.bem_priorGet_0();
if (bevl_hh == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 82*/ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 83*/
bevt_2_ta_ph = bevl_hh.bemd_0(-425897411);
return (BEC_2_5_4_BuildNode) bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 102*/
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
if (bevp_heldBy == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 108*/ {
bevt_3_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 108*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 108*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 108*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 109*/
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_11_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_12_ta_ph = null;
if (bevp_heldBy == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_4_ta_ph = bevp_heldBy.bem_priorGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 115*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_7_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_priorGet_0();
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 115*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 115*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 115*/ {
bevt_8_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 116*/
bevt_12_ta_ph = bevp_heldBy.bem_priorGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bem_priorGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_priorGet_0();
if (bevt_10_ta_ph == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
return bevt_9_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDelete_0() {
bevp_delayDelete = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 126*/ {
return null;
} /* Line: 127*/
bevp_heldBy.bem_delete_0();
bem_containerSet_1(null);
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
BEC_2_5_4_BuildNode bevt_3_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 135*/ {
return null;
} /* Line: 136*/
bevt_2_ta_ph = bevp_heldBy.bem_mylistGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_newNode_1(beva_x);
bevp_heldBy.bem_insertBefore_1(bevt_1_ta_ph);
bevt_3_ta_ph = bem_containerGet_0();
beva_x.bem_containerSet_1(bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_prepend_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 143*/ {
bem_initContained_0();
} /* Line: 144*/
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addValue_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 151*/ {
bem_initContained_0();
} /* Line: 152*/
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_reInitContained_0() {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_initContained_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_contained == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 163*/ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 164*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try /* Line: 170*/ {
bevl_res = bem_toStringCompact_0();
} /* Line: 171*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(939713627);
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 174*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_7_TextStrings bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_7_TextStrings bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_7_TextStrings bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_2_ta_ph = bevl_prefix.bemd_1(-2076338748, bevt_3_ta_ph);
bevt_4_ta_ph = bevp_typename.bem_toString_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(-2076338748, bevt_4_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = bevt_1_ta_ph.bemd_1(-2076338748, bevt_5_ta_ph);
bevt_10_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_9_ta_ph = bevt_10_ta_ph.bem_newlineGet_0();
bevt_8_ta_ph = bevl_ret.bemd_1(-2076338748, bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(-2076338748, bevl_prefix);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_4_BuildNode_bels_2));
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(-2076338748, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bemd_1(-2076338748, bevt_12_ta_ph);
if (bevp_inClassNp == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 183*/ {
if (bevp_inFile == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 183*/
 else /* Line: 183*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 183*/ {
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_21_ta_ph = bevt_22_ta_ph.bem_newlineGet_0();
bevt_20_ta_ph = bevl_ret.bemd_1(-2076338748, bevt_21_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(-2076338748, bevl_prefix);
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_BuildNode_bels_3));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-2076338748, bevt_23_ta_ph);
bevt_24_ta_ph = bevp_inClassNp.bem_toString_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(-2076338748, bevt_24_ta_ph);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_4_BuildNode_bels_4));
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(-2076338748, bevt_25_ta_ph);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-2076338748, bevp_inFile);
bevt_27_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_26_ta_ph = bevt_27_ta_ph.bem_newlineGet_0();
bevl_ret = bevt_15_ta_ph.bemd_1(-2076338748, bevt_26_ta_ph);
} /* Line: 184*/
if (bevp_held == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 186*/ {
bevt_32_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_31_ta_ph = bevt_32_ta_ph.bem_newlineGet_0();
bevt_30_ta_ph = bevl_ret.bemd_1(-2076338748, bevt_31_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(-2076338748, bevl_prefix);
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevl_ret = bevt_29_ta_ph.bemd_1(-2076338748, bevt_33_ta_ph);
bevt_34_ta_ph = bevp_held.bemd_0(1640157629);
bevl_ret = bevl_ret.bemd_1(-2076338748, bevt_34_ta_ph);
} /* Line: 188*/
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
bevl_prefix = bem_prefixGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_0));
bevt_1_ta_ph = bevl_prefix.bemd_1(-2076338748, bevt_2_ta_ph);
bevt_3_ta_ph = bevp_typename.bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-2076338748, bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_1));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(-2076338748, bevt_4_ta_ph);
if (bevp_nlc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 196*/ {
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_4_BuildNode_bels_6));
bevt_6_ta_ph = bevl_ret.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
} /* Line: 197*/
if (bevp_inClassNp == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 199*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_4_BuildNode_bels_7));
bevt_10_ta_ph = bevl_ret.bem_add_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_ta_ph.bem_add_1(bevt_12_ta_ph);
} /* Line: 200*/
if (bevp_held == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 202*/ {
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_BuildNode_bels_5));
bevt_14_ta_ph = bevl_ret.bem_add_1(bevt_15_ta_ph);
bevt_16_ta_ph = bevp_held.bemd_0(1640157629);
bevl_ret = bevt_14_ta_ph.bem_add_1(bevt_16_ta_ph);
} /* Line: 203*/
return bevl_ret;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_5_4_BuildNode bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_c = bem_containerGet_0();
while (true)
/* Line: 211*/ {
if (bevl_c == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 211*/ {
bevl_d.bevi_int++;
bevl_c = bevl_c.bem_containerGet_0();
} /* Line: 213*/
 else /* Line: 211*/ {
break;
} /* Line: 211*/
} /* Line: 211*/
return bevl_d;
} /*method end*/
public BEC_2_4_6_TextString bem_prefixGet_0() {
BEC_2_4_3_MathInt bevl_d = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_d = bem_depthGet_0();
bevl_p = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_4_BuildNode_bels_8));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 222*/ {
if (bevl_i.bevi_int < bevl_d.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 222*/ {
bevl_p = bevl_p.bem_add_1(bevl_q);
bevl_i.bevi_int++;
} /* Line: 222*/
 else /* Line: 222*/ {
break;
} /* Line: 222*/
} /* Line: 222*/
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 230*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 230*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(-298803409);
bevt_4_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(1128815336, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 230*/
 else /* Line: 230*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 230*/ {
bevl_targ = bevl_targ.bemd_0(73704721);
} /* Line: 231*/
 else /* Line: 230*/ {
break;
} /* Line: 230*/
} /* Line: 230*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpanyn = null;
BEC_2_6_6_SystemObject bevl_tmpany = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_clnode = bem_scopeGet_0();
bevt_1_ta_ph = bevl_clnode.bemd_0(-298803409);
bevt_2_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1128815336, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 238*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_4_BuildNode_bels_9));
bevt_3_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_3_ta_ph);
} /* Line: 239*/
bevt_6_ta_ph = bevl_clnode.bemd_0(-425897411);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(1004407968);
bevl_tmpanyn = bevt_5_ta_ph.bemd_0(1640157629);
bevt_8_ta_ph = bevl_clnode.bemd_0(-425897411);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(1004407968);
bevt_7_ta_ph.bemd_0(423503239);
bevl_tmpany = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_9_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(1305512908, bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tmpany.bemd_1(1800680972, bevt_10_ta_ph);
bevl_tmpany.bemd_1(-452315300, beva_suffix);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_BuildNode_bels_10));
bevt_12_ta_ph = bevl_tmpanyn.bemd_1(-2076338748, bevt_13_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(-2076338748, beva_suffix);
bevl_tmpany.bemd_1(-1232791091, bevt_11_ta_ph);
return bevl_tmpany;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_con = bem_containerGet_0();
while (true)
/* Line: 253*/ {
if (bevl_con == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 253*/ {
bevt_2_ta_ph = bevl_con.bem_typenameGet_0();
bevt_3_ta_ph = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 254*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 255*/
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 257*/
 else /* Line: 253*/ {
break;
} /* Line: 253*/
} /* Line: 253*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_addVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevl_v = bevp_held;
bevt_2_ta_ph = bevl_v.bemd_0(55849400);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1369818099);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 264*/ {
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1754250852, bevt_3_ta_ph);
bevl_sco = bem_scopeGet_0();
bevt_5_ta_ph = bevl_sco.bemd_0(-298803409);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(92268189, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 267*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bece_BEC_2_5_4_BuildNode_bels_11));
bevt_7_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_7_ta_ph);
} /* Line: 268*/
bevt_9_ta_ph = bem_inPropertiesGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 270*/ {
bevt_11_ta_ph = bevl_v.bemd_0(-238076325);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1369818099);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 270*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 270*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 270*/
 else /* Line: 270*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 270*/ {
bevl_sco = bem_classGet_0();
bevt_12_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1727631145, bevt_12_ta_ph);
} /* Line: 272*/
bevl_sc = bevl_sco.bemd_0(-425897411);
bevt_14_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_15_ta_ph = bevl_v.bemd_0(-1432171810);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_1(1711380209, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 275*/ {
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_2_5_4_BuildNode_bels_12));
bevt_16_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 276*/
bevt_18_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_19_ta_ph = bevl_v.bemd_0(-1432171810);
bevt_18_ta_ph.bemd_2(-1062155155, bevt_19_ta_ph, this);
bevt_20_ta_ph = bevl_sc.bemd_0(1444826768);
bevt_20_ta_ph.bemd_1(985217435, this);
} /* Line: 279*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncAddVariable_0() {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
bevl_v = bevp_held;
bevt_1_ta_ph = bevl_v.bemd_0(55849400);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1369818099);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 285*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1754250852, bevt_2_ta_ph);
bevl_sco = bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(-425897411);
bevt_4_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_5_ta_ph = bevl_v.bemd_0(-1432171810);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1711380209, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 289*/ {
bevt_6_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_7_ta_ph = bevl_v.bemd_0(-1432171810);
bevp_held = bevt_6_ta_ph.bemd_1(-1629777684, bevt_7_ta_ph);
} /* Line: 290*/
 else /* Line: 291*/ {
bevt_8_ta_ph = bem_classGet_0();
bevl_cl = bevt_8_ta_ph.bemd_0(-425897411);
bevt_10_ta_ph = bevl_cl.bemd_0(-1608519010);
bevt_11_ta_ph = bevl_v.bemd_0(-1432171810);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(1711380209, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 293*/ {
bevt_12_ta_ph = bevl_cl.bemd_0(-1608519010);
bevt_13_ta_ph = bevl_v.bemd_0(-1432171810);
bevp_held = bevt_12_ta_ph.bemd_1(-1629777684, bevt_13_ta_ph);
} /* Line: 294*/
 else /* Line: 295*/ {
bevt_14_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_15_ta_ph = bevl_v.bemd_0(-1432171810);
bevt_14_ta_ph.bemd_2(-1062155155, bevt_15_ta_ph, this);
bevt_16_ta_ph = bevl_sc.bemd_0(1444826768);
bevt_16_ta_ph.bemd_1(985217435, this);
bevt_18_ta_ph = bevl_sco.bemd_0(-298803409);
bevt_19_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(92268189, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 298*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_4_BuildNode_bels_13));
bevt_20_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 299*/
} /* Line: 298*/
} /* Line: 293*/
} /* Line: 289*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_13_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
bevl_vname = bevp_held;
bevt_0_ta_ph = bem_scopeGet_0();
bevl_sc = bevt_0_ta_ph.bemd_0(-425897411);
bevt_2_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(1711380209, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 310*/ {
bevt_4_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(-1629777684, bevl_vname);
bevp_held = bevt_3_ta_ph.bemd_0(-425897411);
} /* Line: 311*/
 else /* Line: 312*/ {
bevt_5_ta_ph = bem_classGet_0();
bevl_cl = bevt_5_ta_ph.bemd_0(-425897411);
bevt_7_ta_ph = bevl_cl.bemd_0(-1608519010);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_1(1711380209, bevl_vname);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 314*/ {
bevt_9_ta_ph = bevl_cl.bemd_0(-1608519010);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_1(-1629777684, bevl_vname);
bevp_held = bevt_8_ta_ph.bemd_0(-425897411);
} /* Line: 315*/
 else /* Line: 316*/ {
bevl_tunode = bem_transUnitGet_0();
bevt_11_ta_ph = bevl_tunode.bemd_0(-425897411);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(775528888);
bevl_np = bevt_10_ta_ph.bemd_1(-1629777684, bevl_vname);
if (bevl_np == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 319*/ {
bevt_14_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_aliasedGet_0();
bevl_np = bevt_13_ta_ph.bem_get_1(bevl_vname);
} /* Line: 320*/
if (bevl_np == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 322*/ {
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_14));
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevl_np);
bevt_16_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_16_ta_ph);
} /* Line: 323*/
 else /* Line: 324*/ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(-1232791091, bevl_vname);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_BuildNode_bels_15));
bevt_19_ta_ph = bevl_vname.bemd_1(92268189, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_19_ta_ph).bevi_bool)/* Line: 328*/ {
bevp_held = bevl_v;
bevt_21_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(385171610, bevt_21_ta_ph);
bevt_22_ta_ph = bevl_cl.bemd_0(314670399);
bevl_v.bemd_1(463143475, bevt_22_ta_ph);
bevt_23_ta_ph = bevl_sc.bemd_0(-1608519010);
bevt_23_ta_ph.bemd_2(-1062155155, bevl_vname, this);
bevt_24_ta_ph = bevl_sc.bemd_0(1444826768);
bevt_24_ta_ph.bemd_1(985217435, this);
} /* Line: 333*/
 else /* Line: 334*/ {
bevt_25_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_v.bemd_1(-62591351, bevt_25_ta_ph);
bevt_26_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(-1727631145, bevt_26_ta_ph);
bevp_held = bevl_v;
bevt_27_ta_ph = bevl_cl.bemd_0(-1608519010);
bevt_27_ta_ph.bemd_2(-1062155155, bevl_vname, this);
bevt_28_ta_ph = bevl_cl.bemd_0(1444826768);
bevt_28_ta_ph.bemd_1(985217435, this);
} /* Line: 339*/
} /* Line: 328*/
} /* Line: 322*/
} /* Line: 314*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevl_node = this;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 348*/ {
while (true)
/* Line: 349*/ {
bevt_2_ta_ph = bevp_constants.bem_anchorTypesGet_0();
bevt_3_ta_ph = bevl_node.bemd_0(-298803409);
bevt_1_ta_ph = bevt_2_ta_ph.bem_has_1(bevt_3_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 350*/ {
return bevl_node;
} /* Line: 351*/
 else /* Line: 352*/ {
bevl_node = bevl_node.bemd_0(73704721);
if (bevl_node == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 354*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_4_BuildNode_bels_16));
bevt_5_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_ta_ph, this);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 355*/
} /* Line: 354*/
} /* Line: 350*/
} /* Line: 349*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 364*/ {
if (bevl_targ == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 364*/ {
bevt_3_ta_ph = bevl_targ.bemd_0(-298803409);
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(1128815336, bevt_4_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 364*/
 else /* Line: 364*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 364*/ {
bevl_targ = bevl_targ.bemd_0(73704721);
} /* Line: 365*/
 else /* Line: 364*/ {
break;
} /* Line: 364*/
} /* Line: 364*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
bevl_targ = this;
while (true)
/* Line: 372*/ {
if (bevl_targ == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 372*/ {
bevt_5_ta_ph = bevl_targ.bemd_0(-298803409);
bevt_6_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(1128815336, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 372*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 372*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 372*/
 else /* Line: 372*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 372*/ {
bevt_8_ta_ph = bevl_targ.bemd_0(-298803409);
bevt_9_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(1128815336, bevt_9_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 372*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 372*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 372*/
 else /* Line: 372*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 372*/ {
bevt_11_ta_ph = bevl_targ.bemd_0(-298803409);
bevt_12_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bemd_1(1128815336, bevt_12_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 372*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 372*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 372*/
 else /* Line: 372*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 372*/ {
bevl_targ = bevl_targ.bemd_0(73704721);
} /* Line: 373*/
 else /* Line: 372*/ {
break;
} /* Line: 372*/
} /* Line: 372*/
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_BuildNode bevt_1_ta_ph = null;
if (bevp_heldBy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 379*/ {
return null;
} /* Line: 380*/
bevt_1_ta_ph = bem_containerGet_0();
beva_other.bem_containerSet_1(bevt_1_ta_ph);
bevp_heldBy.bem_heldSet_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) {
beva_other.bem_delete_0();
bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
/* Line: 393*/ {
bevt_0_ta_ph = bevl_it.bemd_0(36836391);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 393*/ {
bevl_i = bevl_it.bemd_0(528131764);
bevl_i.bemd_1(121763151, this);
} /* Line: 395*/
 else /* Line: 393*/ {
break;
} /* Line: 393*/
} /* Line: 393*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_resolveNp_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
bevt_1_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 401*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 403*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 404*/
} /* Line: 403*/
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 407*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-1540868113);
if (bevl_np == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 409*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 410*/
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(314670399);
if (bevl_np == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 413*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 414*/
bevt_8_ta_ph = bevp_held.bemd_0(-1540868113);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(1640157629);
bevp_held.bemd_1(-1232791091, bevt_7_ta_ph);
} /* Line: 416*/
bevt_10_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 418*/ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(-1540868113);
if (bevl_np == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 420*/ {
bevl_np.bem_resolve_1(this);
} /* Line: 421*/
} /* Line: 420*/
return this;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() {
return bevp_contained;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGetDirect_0() {
return bevp_contained;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGetDirect_0() {
return bevp_held;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_held = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGet_0() {
return bevp_heldBy;
} /*method end*/
public BEC_3_9_10_9_ContainerLinkedListAwareNode bem_heldByGetDirect_0() {
return bevp_heldBy;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_heldBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heldBy = (BEC_3_9_10_9_ContainerLinkedListAwareNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGet_0() {
return bevp_condany;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condanyGetDirect_0() {
return bevp_condany;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_condany = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_condanySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_condany = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGetDirect_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() {
return bevp_typeDetail;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGetDirect_0() {
return bevp_typeDetail;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typeDetail = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typeDetailSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typeDetail = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGetDirect_0() {
return bevp_delayDelete;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_delayDeleteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() {
return bevp_nlc;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGetDirect_0() {
return bevp_nlc;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() {
return bevp_nlec;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGetDirect_0() {
return bevp_nlec;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nlecSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGetDirect_0() {
return bevp_wideString;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_wideStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGetDirect_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() {
return bevp_typename;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGetDirect_0() {
return bevp_typename;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_typenameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGetDirect_0() {
return bevp_inlined;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inlinedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 24, 25, 26, 28, 29, 30, 31, 32, 37, 37, 38, 38, 39, 40, 44, 44, 44, 44, 44, 0, 0, 0, 45, 45, 47, 48, 49, 49, 49, 49, 0, 0, 0, 50, 51, 53, 57, 58, 59, 59, 59, 59, 0, 0, 0, 60, 61, 63, 67, 67, 68, 70, 71, 71, 72, 74, 74, 78, 78, 79, 81, 82, 82, 83, 85, 85, 89, 89, 93, 93, 97, 97, 101, 101, 102, 102, 104, 104, 104, 108, 108, 0, 108, 108, 108, 0, 0, 109, 109, 111, 111, 111, 111, 115, 115, 0, 115, 115, 115, 0, 0, 0, 115, 115, 115, 115, 0, 0, 116, 116, 118, 118, 118, 118, 118, 122, 126, 126, 127, 129, 130, 131, 135, 135, 136, 138, 138, 138, 139, 139, 143, 143, 144, 146, 147, 151, 151, 152, 154, 155, 159, 163, 163, 164, 171, 173, 174, 176, 180, 181, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 0, 0, 0, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 186, 187, 187, 187, 187, 187, 187, 188, 188, 190, 194, 195, 195, 195, 195, 195, 195, 196, 196, 197, 197, 197, 197, 199, 199, 200, 200, 200, 200, 202, 202, 203, 203, 203, 203, 205, 209, 210, 211, 211, 212, 213, 215, 219, 220, 221, 222, 222, 222, 223, 222, 225, 229, 230, 230, 230, 230, 230, 0, 0, 0, 231, 233, 237, 238, 238, 238, 239, 239, 239, 241, 241, 241, 242, 242, 242, 243, 244, 244, 245, 245, 246, 247, 247, 247, 247, 248, 252, 253, 253, 254, 254, 254, 254, 255, 255, 257, 259, 259, 263, 264, 264, 265, 265, 266, 267, 267, 267, 268, 268, 268, 270, 270, 270, 0, 0, 0, 271, 272, 272, 274, 275, 275, 275, 276, 276, 276, 278, 278, 278, 279, 279, 284, 285, 285, 286, 286, 287, 288, 289, 289, 289, 290, 290, 290, 292, 292, 293, 293, 293, 294, 294, 294, 296, 296, 296, 297, 297, 298, 298, 298, 299, 299, 299, 308, 309, 309, 310, 310, 311, 311, 311, 313, 313, 314, 314, 315, 315, 315, 317, 318, 318, 318, 319, 319, 320, 320, 320, 322, 322, 323, 323, 323, 323, 326, 327, 328, 328, 329, 330, 330, 331, 331, 332, 332, 333, 333, 335, 335, 336, 336, 337, 338, 338, 339, 339, 347, 348, 350, 350, 350, 351, 353, 354, 354, 355, 355, 355, 363, 364, 364, 364, 364, 364, 0, 0, 0, 365, 367, 371, 372, 372, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 372, 372, 372, 0, 0, 0, 373, 375, 379, 379, 380, 382, 382, 383, 387, 388, 392, 393, 393, 394, 395, 401, 401, 401, 402, 403, 403, 404, 407, 407, 407, 408, 409, 409, 410, 412, 413, 413, 414, 416, 416, 416, 418, 418, 418, 419, 420, 420, 421, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {47, 48, 49, 50, 51, 52, 53, 54, 55, 61, 62, 63, 64, 65, 66, 80, 85, 86, 87, 92, 93, 96, 100, 103, 104, 106, 107, 110, 115, 116, 121, 122, 125, 129, 132, 133, 139, 147, 148, 151, 156, 157, 162, 163, 166, 170, 173, 174, 180, 187, 192, 193, 195, 196, 201, 202, 204, 205, 212, 217, 218, 220, 221, 226, 227, 229, 230, 234, 235, 239, 240, 244, 245, 252, 257, 258, 259, 261, 262, 267, 278, 283, 284, 287, 288, 293, 294, 297, 301, 302, 304, 305, 306, 311, 327, 332, 333, 336, 337, 342, 343, 346, 350, 353, 354, 355, 360, 361, 364, 368, 369, 371, 372, 373, 374, 379, 382, 387, 392, 393, 395, 396, 397, 405, 410, 411, 413, 414, 415, 416, 417, 422, 427, 428, 430, 431, 436, 441, 442, 444, 445, 449, 454, 459, 460, 468, 472, 473, 475, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 535, 536, 541, 542, 545, 549, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 567, 572, 573, 574, 575, 576, 577, 578, 579, 580, 582, 604, 605, 606, 607, 608, 609, 610, 611, 616, 617, 618, 619, 620, 622, 627, 628, 629, 630, 631, 633, 638, 639, 640, 641, 642, 644, 650, 651, 654, 659, 660, 661, 667, 675, 676, 677, 678, 681, 686, 687, 688, 694, 703, 706, 711, 712, 713, 714, 716, 719, 723, 726, 732, 752, 753, 754, 755, 757, 758, 759, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 787, 790, 795, 796, 797, 798, 803, 804, 805, 807, 813, 814, 841, 842, 843, 845, 846, 847, 848, 849, 850, 852, 853, 854, 856, 858, 859, 861, 864, 868, 871, 872, 873, 875, 876, 877, 878, 880, 881, 882, 884, 885, 886, 887, 888, 919, 920, 921, 923, 924, 925, 926, 927, 928, 929, 931, 932, 933, 936, 937, 938, 939, 940, 942, 943, 944, 947, 948, 949, 950, 951, 952, 953, 954, 956, 957, 958, 1001, 1002, 1003, 1004, 1005, 1007, 1008, 1009, 1012, 1013, 1014, 1015, 1017, 1018, 1019, 1022, 1023, 1024, 1025, 1026, 1031, 1032, 1033, 1034, 1036, 1041, 1042, 1043, 1044, 1045, 1048, 1049, 1050, 1051, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1088, 1089, 1093, 1094, 1095, 1097, 1100, 1101, 1106, 1107, 1108, 1109, 1123, 1126, 1131, 1132, 1133, 1134, 1136, 1139, 1143, 1146, 1152, 1169, 1172, 1177, 1178, 1179, 1180, 1182, 1185, 1189, 1192, 1193, 1194, 1196, 1199, 1203, 1206, 1207, 1208, 1210, 1213, 1217, 1220, 1226, 1231, 1236, 1237, 1239, 1240, 1241, 1245, 1246, 1253, 1254, 1257, 1259, 1260, 1282, 1283, 1288, 1289, 1290, 1295, 1296, 1299, 1300, 1305, 1306, 1307, 1312, 1313, 1315, 1316, 1321, 1322, 1324, 1325, 1326, 1328, 1329, 1334, 1335, 1336, 1341, 1342, 1348, 1351, 1354, 1358, 1362, 1365, 1368, 1372, 1376, 1379, 1382, 1386, 1390, 1393, 1396, 1400, 1404, 1407, 1410, 1414, 1418, 1421, 1424, 1428, 1432, 1435, 1438, 1442, 1446, 1449, 1452, 1456, 1460, 1463, 1466, 1470, 1474, 1477, 1480, 1484, 1488, 1491, 1494, 1498, 1502, 1505, 1508, 1512, 1516, 1519, 1522, 1526, 1530, 1533, 1536, 1540, 1544, 1547, 1550, 1554, 1558, 1561, 1564, 1568, 1572, 1575, 1578, 1582};
/* BEGIN LINEINFO 
assign 1 23 47
new 0 23 47
assign 1 24 48
new 0 24 48
assign 1 25 49
new 0 25 49
assign 1 26 50
new 0 26 50
assign 1 28 51
assign 1 29 52
constantsGet 0 29 52
assign 1 30 53
ntypesGet 0 30 53
assign 1 31 54
TOKENGet 0 31 54
assign 1 32 55
new 0 32 55
assign 1 37 61
nlcGet 0 37 61
assign 1 37 62
copy 0 37 62
assign 1 38 63
nlecGet 0 38 63
assign 1 38 64
copy 0 38 64
assign 1 39 65
inClassNpGet 0 39 65
assign 1 40 66
inFileGet 0 40 66
assign 1 44 80
def 1 44 85
assign 1 44 86
firstGet 0 44 86
assign 1 44 87
def 1 44 92
assign 1 0 93
assign 1 0 96
assign 1 0 100
assign 1 45 103
firstGet 0 45 103
return 1 45 104
assign 1 47 106
nextPeerGet 0 47 106
assign 1 48 107
containerGet 0 48 107
assign 1 49 110
undef 1 49 115
assign 1 49 116
def 1 49 121
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 50 132
nextPeerGet 0 50 132
assign 1 51 133
containerGet 0 51 133
return 1 53 139
assign 1 57 147
nextPeerGet 0 57 147
assign 1 58 148
containerGet 0 58 148
assign 1 59 151
undef 1 59 156
assign 1 59 157
def 1 59 162
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 60 173
nextPeerGet 0 60 173
assign 1 61 174
containerGet 0 61 174
return 1 63 180
assign 1 67 187
undef 1 67 192
return 1 68 193
assign 1 70 195
nextGet 0 70 195
assign 1 71 196
undef 1 71 201
return 1 72 202
assign 1 74 204
heldGet 0 74 204
return 1 74 205
assign 1 78 212
undef 1 78 217
return 1 79 218
assign 1 81 220
priorGet 0 81 220
assign 1 82 221
undef 1 82 226
return 1 83 227
assign 1 85 229
heldGet 0 85 229
return 1 85 230
assign 1 89 234
firstGet 0 89 234
return 1 89 235
assign 1 93 239
secondGet 0 93 239
return 1 93 240
assign 1 97 244
thirdGet 0 97 244
return 1 97 245
assign 1 101 252
undef 1 101 257
assign 1 102 258
new 0 102 258
return 1 102 259
assign 1 104 261
priorGet 0 104 261
assign 1 104 262
undef 1 104 267
return 1 104 267
assign 1 108 278
undef 1 108 283
assign 1 0 284
assign 1 108 287
priorGet 0 108 287
assign 1 108 288
undef 1 108 293
assign 1 0 294
assign 1 0 297
assign 1 109 301
new 0 109 301
return 1 109 302
assign 1 111 304
priorGet 0 111 304
assign 1 111 305
priorGet 0 111 305
assign 1 111 306
undef 1 111 311
return 1 111 311
assign 1 115 327
undef 1 115 332
assign 1 0 333
assign 1 115 336
priorGet 0 115 336
assign 1 115 337
undef 1 115 342
assign 1 0 343
assign 1 0 346
assign 1 0 350
assign 1 115 353
priorGet 0 115 353
assign 1 115 354
priorGet 0 115 354
assign 1 115 355
undef 1 115 360
assign 1 0 361
assign 1 0 364
assign 1 116 368
new 0 116 368
return 1 116 369
assign 1 118 371
priorGet 0 118 371
assign 1 118 372
priorGet 0 118 372
assign 1 118 373
priorGet 0 118 373
assign 1 118 374
undef 1 118 379
return 1 118 379
assign 1 122 382
new 0 122 382
assign 1 126 387
undef 1 126 392
return 1 127 393
delete 0 129 395
containerSet 1 130 396
assign 1 131 397
assign 1 135 405
undef 1 135 410
return 1 136 411
assign 1 138 413
mylistGet 0 138 413
assign 1 138 414
newNode 1 138 414
insertBefore 1 138 415
assign 1 139 416
containerGet 0 139 416
containerSet 1 139 417
assign 1 143 422
undef 1 143 427
initContained 0 144 428
prepend 1 146 430
containerSet 1 147 431
assign 1 151 436
undef 1 151 441
initContained 0 152 442
addValue 1 154 444
containerSet 1 155 445
assign 1 159 449
new 0 159 449
assign 1 163 454
undef 1 163 459
assign 1 164 460
new 0 164 460
assign 1 171 468
toStringCompact 0 171 468
print 0 173 472
throw 1 174 473
return 1 176 475
assign 1 180 515
prefixGet 0 180 515
assign 1 181 516
new 0 181 516
assign 1 181 517
add 1 181 517
assign 1 181 518
toString 0 181 518
assign 1 181 519
add 1 181 519
assign 1 181 520
new 0 181 520
assign 1 181 521
add 1 181 521
assign 1 182 522
new 0 182 522
assign 1 182 523
newlineGet 0 182 523
assign 1 182 524
add 1 182 524
assign 1 182 525
add 1 182 525
assign 1 182 526
new 0 182 526
assign 1 182 527
add 1 182 527
assign 1 182 528
toString 0 182 528
assign 1 182 529
add 1 182 529
assign 1 183 530
def 1 183 535
assign 1 183 536
def 1 183 541
assign 1 0 542
assign 1 0 545
assign 1 0 549
assign 1 184 552
new 0 184 552
assign 1 184 553
newlineGet 0 184 553
assign 1 184 554
add 1 184 554
assign 1 184 555
add 1 184 555
assign 1 184 556
new 0 184 556
assign 1 184 557
add 1 184 557
assign 1 184 558
toString 0 184 558
assign 1 184 559
add 1 184 559
assign 1 184 560
new 0 184 560
assign 1 184 561
add 1 184 561
assign 1 184 562
add 1 184 562
assign 1 184 563
new 0 184 563
assign 1 184 564
newlineGet 0 184 564
assign 1 184 565
add 1 184 565
assign 1 186 567
def 1 186 572
assign 1 187 573
new 0 187 573
assign 1 187 574
newlineGet 0 187 574
assign 1 187 575
add 1 187 575
assign 1 187 576
add 1 187 576
assign 1 187 577
new 0 187 577
assign 1 187 578
add 1 187 578
assign 1 188 579
toString 0 188 579
assign 1 188 580
add 1 188 580
return 1 190 582
assign 1 194 604
prefixGet 0 194 604
assign 1 195 605
new 0 195 605
assign 1 195 606
add 1 195 606
assign 1 195 607
toString 0 195 607
assign 1 195 608
add 1 195 608
assign 1 195 609
new 0 195 609
assign 1 195 610
add 1 195 610
assign 1 196 611
def 1 196 616
assign 1 197 617
new 0 197 617
assign 1 197 618
add 1 197 618
assign 1 197 619
toString 0 197 619
assign 1 197 620
add 1 197 620
assign 1 199 622
def 1 199 627
assign 1 200 628
new 0 200 628
assign 1 200 629
add 1 200 629
assign 1 200 630
toString 0 200 630
assign 1 200 631
add 1 200 631
assign 1 202 633
def 1 202 638
assign 1 203 639
new 0 203 639
assign 1 203 640
add 1 203 640
assign 1 203 641
toString 0 203 641
assign 1 203 642
add 1 203 642
return 1 205 644
assign 1 209 650
new 0 209 650
assign 1 210 651
containerGet 0 210 651
assign 1 211 654
def 1 211 659
incrementValue 0 212 660
assign 1 213 661
containerGet 0 213 661
return 1 215 667
assign 1 219 675
depthGet 0 219 675
assign 1 220 676
new 0 220 676
assign 1 221 677
new 0 221 677
assign 1 222 678
new 0 222 678
assign 1 222 681
lesser 1 222 686
assign 1 223 687
add 1 223 687
incrementValue 0 222 688
return 1 225 694
assign 1 229 703
assign 1 230 706
def 1 230 711
assign 1 230 712
typenameGet 0 230 712
assign 1 230 713
TRANSUNITGet 0 230 713
assign 1 230 714
notEquals 1 230 714
assign 1 0 716
assign 1 0 719
assign 1 0 723
assign 1 231 726
containerGet 0 231 726
return 1 233 732
assign 1 237 752
scopeGet 0 237 752
assign 1 238 753
typenameGet 0 238 753
assign 1 238 754
METHODGet 0 238 754
assign 1 238 755
notEquals 1 238 755
assign 1 239 757
new 0 239 757
assign 1 239 758
new 2 239 758
throw 1 239 759
assign 1 241 761
heldGet 0 241 761
assign 1 241 762
tmpCntGet 0 241 762
assign 1 241 763
toString 0 241 763
assign 1 242 764
heldGet 0 242 764
assign 1 242 765
tmpCntGet 0 242 765
incrementValue 0 242 766
assign 1 243 767
new 0 243 767
assign 1 244 768
new 0 244 768
isTmpVarSet 1 244 769
assign 1 245 770
new 0 245 770
autoTypeSet 1 245 771
suffixSet 1 246 772
assign 1 247 773
new 0 247 773
assign 1 247 774
add 1 247 774
assign 1 247 775
add 1 247 775
nameSet 1 247 776
return 1 248 777
assign 1 252 787
containerGet 0 252 787
assign 1 253 790
def 1 253 795
assign 1 254 796
typenameGet 0 254 796
assign 1 254 797
PROPERTIESGet 0 254 797
assign 1 254 798
equals 1 254 803
assign 1 255 804
new 0 255 804
return 1 255 805
assign 1 257 807
containerGet 0 257 807
assign 1 259 813
new 0 259 813
return 1 259 814
assign 1 263 841
assign 1 264 842
isAddedGet 0 264 842
assign 1 264 843
not 0 264 843
assign 1 265 845
new 0 265 845
isAddedSet 1 265 846
assign 1 266 847
scopeGet 0 266 847
assign 1 267 848
typenameGet 0 267 848
assign 1 267 849
CLASSGet 0 267 849
assign 1 267 850
equals 1 267 850
assign 1 268 852
new 0 268 852
assign 1 268 853
new 2 268 853
throw 1 268 854
assign 1 270 856
inPropertiesGet 0 270 856
assign 1 270 858
isTmpVarGet 0 270 858
assign 1 270 859
not 0 270 859
assign 1 0 861
assign 1 0 864
assign 1 0 868
assign 1 271 871
classGet 0 271 871
assign 1 272 872
new 0 272 872
isPropertySet 1 272 873
assign 1 274 875
heldGet 0 274 875
assign 1 275 876
anyMapGet 0 275 876
assign 1 275 877
nameGet 0 275 877
assign 1 275 878
has 1 275 878
assign 1 276 880
new 0 276 880
assign 1 276 881
new 2 276 881
throw 1 276 882
assign 1 278 884
anyMapGet 0 278 884
assign 1 278 885
nameGet 0 278 885
put 2 278 886
assign 1 279 887
orderedVarsGet 0 279 887
addValue 1 279 888
assign 1 284 919
assign 1 285 920
isAddedGet 0 285 920
assign 1 285 921
not 0 285 921
assign 1 286 923
new 0 286 923
isAddedSet 1 286 924
assign 1 287 925
scopeGet 0 287 925
assign 1 288 926
heldGet 0 288 926
assign 1 289 927
anyMapGet 0 289 927
assign 1 289 928
nameGet 0 289 928
assign 1 289 929
has 1 289 929
assign 1 290 931
anyMapGet 0 290 931
assign 1 290 932
nameGet 0 290 932
assign 1 290 933
get 1 290 933
assign 1 292 936
classGet 0 292 936
assign 1 292 937
heldGet 0 292 937
assign 1 293 938
anyMapGet 0 293 938
assign 1 293 939
nameGet 0 293 939
assign 1 293 940
has 1 293 940
assign 1 294 942
anyMapGet 0 294 942
assign 1 294 943
nameGet 0 294 943
assign 1 294 944
get 1 294 944
assign 1 296 947
anyMapGet 0 296 947
assign 1 296 948
nameGet 0 296 948
put 2 296 949
assign 1 297 950
orderedVarsGet 0 297 950
addValue 1 297 951
assign 1 298 952
typenameGet 0 298 952
assign 1 298 953
CLASSGet 0 298 953
assign 1 298 954
equals 1 298 954
assign 1 299 956
new 0 299 956
assign 1 299 957
new 2 299 957
throw 1 299 958
assign 1 308 1001
assign 1 309 1002
scopeGet 0 309 1002
assign 1 309 1003
heldGet 0 309 1003
assign 1 310 1004
anyMapGet 0 310 1004
assign 1 310 1005
has 1 310 1005
assign 1 311 1007
anyMapGet 0 311 1007
assign 1 311 1008
get 1 311 1008
assign 1 311 1009
heldGet 0 311 1009
assign 1 313 1012
classGet 0 313 1012
assign 1 313 1013
heldGet 0 313 1013
assign 1 314 1014
anyMapGet 0 314 1014
assign 1 314 1015
has 1 314 1015
assign 1 315 1017
anyMapGet 0 315 1017
assign 1 315 1018
get 1 315 1018
assign 1 315 1019
heldGet 0 315 1019
assign 1 317 1022
transUnitGet 0 317 1022
assign 1 318 1023
heldGet 0 318 1023
assign 1 318 1024
aliasedGet 0 318 1024
assign 1 318 1025
get 1 318 1025
assign 1 319 1026
undef 1 319 1031
assign 1 320 1032
emitDataGet 0 320 1032
assign 1 320 1033
aliasedGet 0 320 1033
assign 1 320 1034
get 1 320 1034
assign 1 322 1036
def 1 322 1041
assign 1 323 1042
new 0 323 1042
assign 1 323 1043
add 1 323 1043
assign 1 323 1044
new 2 323 1044
throw 1 323 1045
assign 1 326 1048
new 0 326 1048
nameSet 1 327 1049
assign 1 328 1050
new 0 328 1050
assign 1 328 1051
equals 1 328 1051
assign 1 329 1053
assign 1 330 1054
new 0 330 1054
isTypedSet 1 330 1055
assign 1 331 1056
extendsGet 0 331 1056
namepathSet 1 331 1057
assign 1 332 1058
anyMapGet 0 332 1058
put 2 332 1059
assign 1 333 1060
orderedVarsGet 0 333 1060
addValue 1 333 1061
assign 1 335 1064
new 0 335 1064
isDeclaredSet 1 335 1065
assign 1 336 1066
new 0 336 1066
isPropertySet 1 336 1067
assign 1 337 1068
assign 1 338 1069
anyMapGet 0 338 1069
put 2 338 1070
assign 1 339 1071
orderedVarsGet 0 339 1071
addValue 1 339 1072
assign 1 347 1088
assign 1 348 1089
new 0 348 1089
assign 1 350 1093
anchorTypesGet 0 350 1093
assign 1 350 1094
typenameGet 0 350 1094
assign 1 350 1095
has 1 350 1095
return 1 351 1097
assign 1 353 1100
containerGet 0 353 1100
assign 1 354 1101
undef 1 354 1106
assign 1 355 1107
new 0 355 1107
assign 1 355 1108
new 2 355 1108
throw 1 355 1109
assign 1 363 1123
assign 1 364 1126
def 1 364 1131
assign 1 364 1132
typenameGet 0 364 1132
assign 1 364 1133
CLASSGet 0 364 1133
assign 1 364 1134
notEquals 1 364 1134
assign 1 0 1136
assign 1 0 1139
assign 1 0 1143
assign 1 365 1146
containerGet 0 365 1146
return 1 367 1152
assign 1 371 1169
assign 1 372 1172
def 1 372 1177
assign 1 372 1178
typenameGet 0 372 1178
assign 1 372 1179
CLASSGet 0 372 1179
assign 1 372 1180
notEquals 1 372 1180
assign 1 0 1182
assign 1 0 1185
assign 1 0 1189
assign 1 372 1192
typenameGet 0 372 1192
assign 1 372 1193
METHODGet 0 372 1193
assign 1 372 1194
notEquals 1 372 1194
assign 1 0 1196
assign 1 0 1199
assign 1 0 1203
assign 1 372 1206
typenameGet 0 372 1206
assign 1 372 1207
TRANSUNITGet 0 372 1207
assign 1 372 1208
notEquals 1 372 1208
assign 1 0 1210
assign 1 0 1213
assign 1 0 1217
assign 1 373 1220
containerGet 0 373 1220
return 1 375 1226
assign 1 379 1231
undef 1 379 1236
return 1 380 1237
assign 1 382 1239
containerGet 0 382 1239
containerSet 1 382 1240
heldSet 1 383 1241
delete 0 387 1245
addValue 1 388 1246
assign 1 392 1253
containedGet 0 392 1253
assign 1 393 1254
iteratorGet 0 393 1254
assign 1 393 1257
hasNextGet 0 393 1257
assign 1 394 1259
nextGet 0 394 1259
containerSet 1 395 1260
assign 1 401 1282
NAMEPATHGet 0 401 1282
assign 1 401 1283
equals 1 401 1288
assign 1 402 1289
assign 1 403 1290
def 1 403 1295
resolve 1 404 1296
assign 1 407 1299
CLASSGet 0 407 1299
assign 1 407 1300
equals 1 407 1305
assign 1 408 1306
namepathGet 0 408 1306
assign 1 409 1307
def 1 409 1312
resolve 1 410 1313
assign 1 412 1315
extendsGet 0 412 1315
assign 1 413 1316
def 1 413 1321
resolve 1 414 1322
assign 1 416 1324
namepathGet 0 416 1324
assign 1 416 1325
toString 0 416 1325
nameSet 1 416 1326
assign 1 418 1328
VARGet 0 418 1328
assign 1 418 1329
equals 1 418 1334
assign 1 419 1335
namepathGet 0 419 1335
assign 1 420 1336
def 1 420 1341
resolve 1 421 1342
return 1 0 1348
return 1 0 1351
assign 1 0 1354
assign 1 0 1358
return 1 0 1362
return 1 0 1365
assign 1 0 1368
assign 1 0 1372
return 1 0 1376
return 1 0 1379
assign 1 0 1382
assign 1 0 1386
return 1 0 1390
return 1 0 1393
assign 1 0 1396
assign 1 0 1400
return 1 0 1404
return 1 0 1407
assign 1 0 1410
assign 1 0 1414
return 1 0 1418
return 1 0 1421
assign 1 0 1424
assign 1 0 1428
return 1 0 1432
return 1 0 1435
assign 1 0 1438
assign 1 0 1442
return 1 0 1446
return 1 0 1449
assign 1 0 1452
assign 1 0 1456
return 1 0 1460
return 1 0 1463
assign 1 0 1466
assign 1 0 1470
return 1 0 1474
return 1 0 1477
assign 1 0 1480
assign 1 0 1484
return 1 0 1488
return 1 0 1491
assign 1 0 1494
assign 1 0 1498
return 1 0 1502
return 1 0 1505
assign 1 0 1508
assign 1 0 1512
return 1 0 1516
return 1 0 1519
assign 1 0 1522
assign 1 0 1526
return 1 0 1530
return 1 0 1533
assign 1 0 1536
assign 1 0 1540
return 1 0 1544
return 1 0 1547
assign 1 0 1550
assign 1 0 1554
return 1 0 1558
return 1 0 1561
assign 1 0 1564
assign 1 0 1568
return 1 0 1572
return 1 0 1575
assign 1 0 1578
assign 1 0 1582
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1653030156: return bem_nextDescendGet_0();
case -391944425: return bem_heldByGet_0();
case -178385347: return bem_iteratorGet_0();
case -1036391864: return bem_copy_0();
case -661090329: return bem_prefixGet_0();
case 1419385905: return bem_containedGetDirect_0();
case 2037996040: return bem_create_0();
case 734703271: return bem_nextAscendGet_0();
case 1089508338: return bem_constantsGetDirect_0();
case -1117796647: return bem_delete_0();
case 372018746: return bem_inlinedGet_0();
case 626206862: return bem_firstGet_0();
case -2070846101: return bem_hashGet_0();
case 1114595664: return bem_inFileGetDirect_0();
case -1456841929: return bem_wideStringGetDirect_0();
case 1042310114: return bem_scopeGet_0();
case 1258729534: return bem_echo_0();
case -1214137858: return bem_typenameGetDirect_0();
case -1221104789: return bem_sourceFileNameGet_0();
case -1253293660: return bem_serializeToString_0();
case 265079397: return bem_delayDelete_0();
case -1008854058: return bem_nlcGetDirect_0();
case 942507611: return bem_buildGetDirect_0();
case 939713627: return bem_print_0();
case 307193318: return bem_serializeContents_0();
case 621873738: return bem_containerGetDirect_0();
case 1640157629: return bem_toString_0();
case -1915722217: return bem_condanyGetDirect_0();
case 1037945939: return bem_inPropertiesGet_0();
case -1576931101: return bem_typeDetailGet_0();
case 1020685378: return bem_isFirstGet_0();
case 2112269448: return bem_isSecondGet_0();
case 1577298932: return bem_toStringBig_0();
case 371944728: return bem_secondGet_0();
case -469943446: return bem_thirdGet_0();
case -992974823: return bem_delayDeleteGet_0();
case 1562650783: return bem_fieldIteratorGet_0();
case 1878268220: return bem_buildGet_0();
case 1600735704: return bem_anchorGet_0();
case 364823398: return bem_inFileGet_0();
case 219804924: return bem_addVariable_0();
case -1906768398: return bem_classNameGet_0();
case 269374254: return bem_nlcGet_0();
case -492667092: return bem_syncAddVariable_0();
case -458055945: return bem_nextPeerGet_0();
case 1482005796: return bem_containedGet_0();
case 309165609: return bem_toStringCompact_0();
case -1808403821: return bem_nlecGetDirect_0();
case 986853403: return bem_depthGet_0();
case -434670818: return bem_heldGetDirect_0();
case -1548574974: return bem_condanyGet_0();
case 73704721: return bem_containerGet_0();
case -1588934741: return bem_reInitContained_0();
case -1121956180: return bem_delayDeleteGetDirect_0();
case 1178859874: return bem_constantsGet_0();
case 1833588536: return bem_priorPeerGet_0();
case -1777316122: return bem_serializationIteratorGet_0();
case -1485115267: return bem_inlinedGetDirect_0();
case 1866957322: return bem_classGet_0();
case -411722200: return bem_initContained_0();
case 1941247303: return bem_ntypesGet_0();
case -425897411: return bem_heldGet_0();
case 1460710096: return bem_tagGet_0();
case 1363753553: return bem_inClassNpGet_0();
case 1568423944: return bem_isThirdGet_0();
case -1772344344: return bem_ntypesGetDirect_0();
case 62239394: return bem_deserializeClassNameGet_0();
case -1170443841: return bem_heldByGetDirect_0();
case -1134463827: return bem_wideStringGet_0();
case 603655774: return bem_inClassNpGetDirect_0();
case 1721561375: return bem_resolveNp_0();
case -281213817: return bem_typeDetailGetDirect_0();
case -298803409: return bem_typenameGet_0();
case 873076018: return bem_new_0();
case 1071494954: return bem_nlecGet_0();
case -1893978913: return bem_transUnitGet_0();
case 1794395999: return bem_fieldNamesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1601584010: return bem_sameType_1(bevd_0);
case 1458219838: return bem_containedSet_1(bevd_0);
case -2030893878: return bem_typeDetailSetDirect_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 986596229: return bem_def_1(bevd_0);
case -645913487: return bem_ntypesSet_1(bevd_0);
case -1177603917: return bem_heldSetDirect_1(bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case 812082171: return bem_nlecSetDirect_1(bevd_0);
case -1756122224: return bem_inFileSet_1(bevd_0);
case -720855927: return bem_nlcSetDirect_1(bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 372045031: return bem_condanySetDirect_1(bevd_0);
case 1180578429: return bem_wideStringSet_1(bevd_0);
case 1227887515: return bem_nlcSet_1(bevd_0);
case -729311480: return bem_nlecSet_1(bevd_0);
case -1083109711: return bem_delayDeleteSetDirect_1(bevd_0);
case 1958026588: return bem_inClassNpSetDirect_1(bevd_0);
case 1259153354: return bem_wideStringSetDirect_1(bevd_0);
case -1545234541: return bem_inFileSetDirect_1(bevd_0);
case -285706899: return bem_condanySet_1(bevd_0);
case 1286489806: return bem_inlinedSetDirect_1(bevd_0);
case -834364667: return bem_heldBySet_1(bevd_0);
case 1528782257: return bem_copyTo_1(bevd_0);
case -110759999: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 218147927: return bem_constantsSet_1(bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 755822734: return bem_typenameSetDirect_1(bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case 1138824739: return bem_heldSet_1(bevd_0);
case -892482829: return bem_typeDetailSet_1(bevd_0);
case -268870180: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1080388876: return bem_inClassNpSet_1(bevd_0);
case 481358791: return bem_containerSetDirect_1(bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -493310448: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 47684234: return bem_buildSet_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 985217435: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case 4039371: return bem_ntypesSetDirect_1(bevd_0);
case 275490952: return bem_constantsSetDirect_1(bevd_0);
case 1241207915: return bem_inlinedSet_1(bevd_0);
case 2002913461: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case -1307348296: return bem_buildSetDirect_1(bevd_0);
case 796100878: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2132168487: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case -1866969837: return bem_delayDeleteSet_1(bevd_0);
case 2009355322: return bem_containedSetDirect_1(bevd_0);
case -1576730336: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case -1052618886: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case -28686241: return bem_typenameSet_1(bevd_0);
case 121763151: return bem_containerSet_1(bevd_0);
case -630835086: return bem_heldBySetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1470434971: return bem_tmpVar_2(bevd_0, bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildNode_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_4_BuildNode_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst = (BEC_2_5_4_BuildNode) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_BuildNode.bece_BEC_2_5_4_BuildNode_bevs_type;
}
}
}
