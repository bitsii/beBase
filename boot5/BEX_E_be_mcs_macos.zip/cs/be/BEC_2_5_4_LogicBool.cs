namespace be {
/* IO:File: source/base/Logic.be */
public sealed class BEC_2_5_4_LogicBool : BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }
static BEC_2_5_4_LogicBool() { }

   
    public bool bevi_bool;
    public BEC_2_5_4_LogicBool(bool bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_5 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
public static new BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static new BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(-2023862139, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 52 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(-2023862139, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 58 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 58 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 59 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 69 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_0_tmpany_phold;
} /* Line: 70 */
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 80 */ {
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 81 */
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 96 */
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 102 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_5));
return bevt_0_tmpany_phold;
} /* Line: 103 */
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_6));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {51, 51, 52, 52, 54, 54, 58, 58, 58, 58, 0, 0, 0, 59, 59, 61, 61, 65, 65, 70, 70, 72, 72, 76, 76, 81, 81, 83, 83, 87, 87, 91, 91, 96, 96, 98, 98, 103, 103, 105, 105, 109};
public static new int[] bevs_smnlec
 = new int[] {32, 33, 35, 36, 38, 39, 48, 53, 54, 55, 57, 60, 64, 67, 68, 70, 71, 75, 76, 82, 83, 85, 86, 90, 91, 97, 98, 100, 101, 105, 106, 110, 111, 117, 118, 120, 121, 127, 128, 130, 131, 134};
/* BEGIN LINEINFO 
assign 1 51 32
new 0 51 32
assign 1 51 33
equals 1 51 33
assign 1 52 35
new 0 52 35
return 1 52 36
assign 1 54 38
new 0 54 38
return 1 54 39
assign 1 58 48
def 1 58 53
assign 1 58 54
new 0 58 54
assign 1 58 55
equals 1 58 55
assign 1 0 57
assign 1 0 60
assign 1 0 64
assign 1 59 67
new 0 59 67
return 1 59 68
assign 1 61 70
new 0 61 70
return 1 61 71
assign 1 65 75
new 0 65 75
return 1 65 76
assign 1 70 82
new 0 70 82
return 1 70 83
assign 1 72 85
new 0 72 85
return 1 72 86
assign 1 76 90
new 0 76 90
return 1 76 91
assign 1 81 97
new 0 81 97
return 1 81 98
assign 1 83 100
new 0 83 100
return 1 83 101
assign 1 87 105
new 0 87 105
return 1 87 106
assign 1 91 110
new 0 91 110
return 1 91 111
assign 1 96 117
new 0 96 117
return 1 96 118
assign 1 98 120
new 0 98 120
return 1 98 121
assign 1 103 127
new 0 103 127
return 1 103 128
assign 1 105 130
new 0 105 130
return 1 105 131
return 1 109 134
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 341148236: return bem_once_0();
case -41276197: return bem_create_0();
case -139353918: return bem_toAny_0();
case -1797964019: return bem_classNameGet_0();
case 2121617532: return bem_hashGet_0();
case -2027679173: return bem_deserializeClassNameGet_0();
case 1310168666: return bem_copy_0();
case -865211167: return bem_many_0();
case 734060929: return bem_serializationIteratorGet_0();
case -2058654018: return bem_toString_0();
case 148319359: return bem_new_0();
case -1456235115: return bem_echo_0();
case -320545548: return bem_sourceFileNameGet_0();
case -740937572: return bem_print_0();
case 1119824080: return bem_decrement_0();
case 903178719: return bem_fieldNamesGet_0();
case 900791764: return bem_not_0();
case 1147856721: return bem_fieldIteratorGet_0();
case -1943120126: return bem_serializeToString_0();
case 1990625095: return bem_tagGet_0();
case 1903174517: return bem_increment_0();
case 332613786: return bem_serializeContents_0();
case -256176855: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1985783592: return bem_otherType_1(bevd_0);
case 55946271: return bem_notEquals_1(bevd_0);
case 906711890: return bem_sameObject_1(bevd_0);
case 1937418309: return bem_checkDefNew_1(bevd_0);
case 2070971991: return bem_def_1(bevd_0);
case 649776492: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2023862139: return bem_equals_1(bevd_0);
case -116587458: return bem_sameType_1(bevd_0);
case -264091635: return bem_copyTo_1(bevd_0);
case 261224447: return bem_new_1(bevd_0);
case 635105057: return bem_defined_1(bevd_0);
case 1865504944: return bem_sameClass_1(bevd_0);
case 1350346500: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1829045189: return bem_otherClass_1(bevd_0);
case 825055568: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -245605778: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 306277101: return bem_undefined_1(bevd_0);
case -1679251333: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 710095661: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1286703705: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 704289821: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1372536257: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1105189015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1798728092: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -275173380: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_LogicBool();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
}
