namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_4_BuildEmit : BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildEmit() { }
static BEC_2_5_4_BuildEmit() { }
private static byte[] becc_BEC_2_5_4_BuildEmit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74};
private static byte[] becc_BEC_2_5_4_BuildEmit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_inst;

public static new BET_2_5_4_BuildEmit bece_BEC_2_5_4_BuildEmit_bevs_type;

public BEC_2_4_6_TextString bevp_text;
public BEC_2_9_3_ContainerSet bevp_langs;
public BEC_2_5_4_BuildEmit bem_new_2(BEC_2_4_6_TextString beva__text, BEC_2_9_3_ContainerSet beva__langs) {
bevp_text = beva__text;
bevp_langs = beva__langs;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_textGet_0() {
return bevp_text;
} /*method end*/
public BEC_2_4_6_TextString bem_textGetDirect_0() {
return bevp_text;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_text = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_textSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_text = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGet_0() {
return bevp_langs;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_langsGetDirect_0() {
return bevp_langs;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildEmit bem_langsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_langs = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {73, 74, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 16, 20, 23, 26, 30, 34, 37, 40, 44};
/* BEGIN LINEINFO 
assign 1 73 15
assign 1 74 16
return 1 0 20
return 1 0 23
assign 1 0 26
assign 1 0 30
return 1 0 34
return 1 0 37
assign 1 0 40
assign 1 0 44
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1688687204: return bem_serializeToString_0();
case 2038193605: return bem_fieldNamesGet_0();
case -447714708: return bem_langsGetDirect_0();
case 1029695809: return bem_echo_0();
case -479166709: return bem_tagGet_0();
case 126670515: return bem_toAny_0();
case -1902089216: return bem_toString_0();
case -1844917728: return bem_many_0();
case -1779062531: return bem_serializationIteratorGet_0();
case 1562608535: return bem_print_0();
case -8643043: return bem_serializeContents_0();
case -785258946: return bem_create_0();
case -31114048: return bem_iteratorGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 388303658: return bem_textGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 217968364: return bem_classNameGet_0();
case 1137009070: return bem_once_0();
case -1026733174: return bem_new_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 1085224183: return bem_langsGet_0();
case -1848718184: return bem_hashGet_0();
case 185174991: return bem_copy_0();
case -892894595: return bem_textGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2125374017: return bem_langsSetDirect_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -554707016: return bem_textSet_1(bevd_0);
case -142198112: return bem_langsSet_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -1448947862: return bem_textSetDirect_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 497465062: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_3_ContainerSet) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_BuildEmit_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_4_BuildEmit_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_BuildEmit();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst = (BEC_2_5_4_BuildEmit) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_BuildEmit.bece_BEC_2_5_4_BuildEmit_bevs_type;
}
}
}
