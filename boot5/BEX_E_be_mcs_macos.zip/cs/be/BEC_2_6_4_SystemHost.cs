namespace be {

using System;
using System.Diagnostics;
/* IO:File: source/extended/Command.be */
public class BEC_2_6_4_SystemHost : BEC_2_6_6_SystemObject {
public BEC_2_6_4_SystemHost() { }
static BEC_2_6_4_SystemHost() { }
private static byte[] becc_BEC_2_6_4_SystemHost_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x48,0x6F,0x73,0x74};
private static byte[] becc_BEC_2_6_4_SystemHost_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_4_SystemHost_bels_0 = {0x68,0x6F,0x73,0x74,0x6E,0x61,0x6D,0x65,0x20,0x2D,0x73};
public static new BEC_2_6_4_SystemHost bece_BEC_2_6_4_SystemHost_bevs_inst;

public static new BET_2_6_4_SystemHost bece_BEC_2_6_4_SystemHost_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_4_SystemHost bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_hostnameGet_0() {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_o = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_4_2_4_6_7_IOFileReaderCommand bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_6_4_SystemHost_bels_0));
bevt_0_tmpany_phold = (BEC_4_2_4_6_7_IOFileReaderCommand) (new BEC_4_2_4_6_7_IOFileReaderCommand()).bem_new_1(bevt_1_tmpany_phold);
bevl_r = bevt_0_tmpany_phold.bem_open_0();
bevl_o = (BEC_2_4_6_TextString) bevl_r.bemd_0(1308379424);
bevl_r.bemd_0(-647640823);
bevl_l = bevl_o.bem_splitLines_0();
bevl_name = (BEC_2_4_6_TextString) bevl_l.bemd_0(652956900);
return bevl_name;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {201, 201, 201, 202, 203, 204, 205, 207};
public static new int[] bevs_smnlec
 = new int[] {29, 30, 31, 32, 33, 34, 35, 36};
/* BEGIN LINEINFO 
assign 1 201 29
new 0 201 29
assign 1 201 30
new 1 201 30
assign 1 201 31
open 0 201 31
assign 1 202 32
readString 0 202 32
close 0 203 33
assign 1 204 34
splitLines 0 204 34
assign 1 205 35
firstGet 0 205 35
return 1 207 36
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1194274080: return bem_toAny_0();
case -14767827: return bem_serializeToString_0();
case -1121300979: return bem_fieldNamesGet_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case -1365182072: return bem_sourceFileNameGet_0();
case -2016997496: return bem_print_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 1747475389: return bem_many_0();
case 306116222: return bem_echo_0();
case 434654272: return bem_hashGet_0();
case -1219673974: return bem_toString_0();
case 583960777: return bem_hostnameGet_0();
case 222096027: return bem_classNameGet_0();
case -256194891: return bem_default_0();
case 1801694719: return bem_copy_0();
case -31410563: return bem_once_0();
case 2119098947: return bem_serializeContents_0();
case 1366617398: return bem_tagGet_0();
case 1999868679: return bem_fieldIteratorGet_0();
case 1115258825: return bem_create_0();
case 216845033: return bem_new_0();
case -1141049131: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1246021533: return bem_equals_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -240164168: return bem_undefined_1(bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_SystemHost_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_4_SystemHost_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_4_SystemHost();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_inst = (BEC_2_6_4_SystemHost) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_4_SystemHost.bece_BEC_2_6_4_SystemHost_bevs_type;
}
}
}
