namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_6_BuildVarSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildVarSyn() { }
static BEC_2_5_6_BuildVarSyn() { }
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_inst;

public static new BET_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_npNew_1(BEC_2_5_8_BuildNamePath beva_np) {
bevp_namepath = beva_np;
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_anyNew_1(BEC_2_5_3_BuildVar beva_full) {
bevp_name = beva_full.bem_nameGet_0();
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_5_6_BuildVarSyn beva_o) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
if (beva_o == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 38*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 38*/
if (bevp_name == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_7_ta_ph = beva_o.bem_nameGet_0();
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 39*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 39*/
 else /* Line: 39*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 39*/ {
bevt_9_ta_ph = beva_o.bem_nameGet_0();
bevt_8_ta_ph = bevp_name.bem_notEquals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 39*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 39*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 39*/
 else /* Line: 39*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 39*/ {
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 40*/
bevt_12_ta_ph = beva_o.bem_isTypedGet_0();
bevt_11_ta_ph = bevp_isTyped.bem_notEquals_1(bevt_12_ta_ph);
if (bevt_11_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_13_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 43*/
if (bevp_isTyped.bevi_bool)/* Line: 45*/ {
bevt_15_ta_ph = beva_o.bem_namepathGet_0();
bevt_14_ta_ph = bevp_namepath.bem_notEquals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 45*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 45*/
 else /* Line: 45*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 45*/ {
bevt_16_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 46*/
bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGetDirect_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGetDirect_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGetDirect_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {19, 23, 24, 29, 30, 31, 32, 33, 38, 38, 38, 38, 39, 39, 39, 39, 39, 0, 0, 0, 39, 39, 0, 0, 0, 40, 40, 42, 42, 43, 43, 45, 45, 0, 0, 0, 46, 46, 48, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 22, 23, 27, 28, 29, 30, 31, 53, 58, 59, 60, 62, 67, 68, 69, 74, 75, 78, 82, 85, 86, 88, 91, 95, 98, 99, 101, 102, 104, 105, 108, 109, 111, 114, 118, 121, 122, 124, 125, 128, 131, 134, 138, 142, 145, 148, 152, 156, 159, 162, 166, 170, 173, 176, 180, 184, 187, 190, 194};
/* BEGIN LINEINFO 
assign 1 19 18
new 0 19 18
assign 1 23 22
assign 1 24 23
new 0 24 23
assign 1 29 27
nameGet 0 29 27
assign 1 30 28
namepathGet 0 30 28
assign 1 31 29
isTypedGet 0 31 29
assign 1 32 30
isSelfGet 0 32 30
assign 1 33 31
isThisGet 0 33 31
assign 1 38 53
undef 1 38 58
assign 1 38 59
new 0 38 59
return 1 38 60
assign 1 39 62
def 1 39 67
assign 1 39 68
nameGet 0 39 68
assign 1 39 69
def 1 39 74
assign 1 0 75
assign 1 0 78
assign 1 0 82
assign 1 39 85
nameGet 0 39 85
assign 1 39 86
notEquals 1 39 86
assign 1 0 88
assign 1 0 91
assign 1 0 95
assign 1 40 98
new 0 40 98
return 1 40 99
assign 1 42 101
isTypedGet 0 42 101
assign 1 42 102
notEquals 1 42 102
assign 1 43 104
new 0 43 104
return 1 43 105
assign 1 45 108
namepathGet 0 45 108
assign 1 45 109
notEquals 1 45 109
assign 1 0 111
assign 1 0 114
assign 1 0 118
assign 1 46 121
new 0 46 121
return 1 46 122
assign 1 48 124
new 0 48 124
return 1 48 125
return 1 0 128
return 1 0 131
assign 1 0 134
assign 1 0 138
return 1 0 142
return 1 0 145
assign 1 0 148
assign 1 0 152
return 1 0 156
return 1 0 159
assign 1 0 162
assign 1 0 166
return 1 0 170
return 1 0 173
assign 1 0 176
assign 1 0 180
return 1 0 184
return 1 0 187
assign 1 0 190
assign 1 0 194
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 110382217: return bem_sourceFileNameGet_0();
case 1986590366: return bem_hashGet_0();
case 879975179: return bem_classNameGet_0();
case -1279642058: return bem_nameGetDirect_0();
case -560013123: return bem_isSelfGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 887739950: return bem_serializeToString_0();
case -96610475: return bem_isTypedGetDirect_0();
case -2129983068: return bem_toAny_0();
case 1629744956: return bem_nameGet_0();
case 2062513077: return bem_namepathGet_0();
case 1098859404: return bem_isThisGetDirect_0();
case 233362262: return bem_many_0();
case 888041456: return bem_tagGet_0();
case -1880155711: return bem_isTypedGet_0();
case 385465349: return bem_namepathGetDirect_0();
case 1843544518: return bem_serializeContents_0();
case 1732513565: return bem_copy_0();
case -1588532100: return bem_echo_0();
case 978485429: return bem_isSelfGetDirect_0();
case 1383646476: return bem_iteratorGet_0();
case 1989693945: return bem_toString_0();
case 2071597061: return bem_create_0();
case -957918918: return bem_isThisGet_0();
case -1084228149: return bem_print_0();
case 714460463: return bem_once_0();
case 162533386: return bem_fieldNamesGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 1105152133: return bem_new_0();
case -153156208: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -367114969: return bem_npNew_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1527966045: return bem_isThisSet_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case -1974233027: return bem_isSelfSetDirect_1(bevd_0);
case -576826065: return bem_nameSetDirect_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case -333772671: return bem_isTypedSetDirect_1(bevd_0);
case 889054040: return bem_namepathSetDirect_1(bevd_0);
case 1731458371: return bem_isThisSetDirect_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case -1545076450: return bem_anyNew_1((BEC_2_5_3_BuildVar) bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case 2091015327: return bem_isTypedSet_1(bevd_0);
case -1850093812: return bem_nameSet_1(bevd_0);
case 1596664599: return bem_isSelfSet_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 2100750752: return bem_namepathSet_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case 643594779: return bem_contentsEqual_1((BEC_2_5_6_BuildVarSyn) bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildVarSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildVarSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildVarSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst = (BEC_2_5_6_BuildVarSyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_type;
}
}
}
