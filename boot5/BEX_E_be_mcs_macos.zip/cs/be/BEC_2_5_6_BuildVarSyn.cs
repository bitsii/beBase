namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_6_BuildVarSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildVarSyn() { }
static BEC_2_5_6_BuildVarSyn() { }
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildVarSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_6_BuildVarSyn bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_npNew_1(BEC_2_5_8_BuildNamePath beva_np) {
bevp_namepath = beva_np;
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_anyNew_1(BEC_2_5_3_BuildVar beva_full) {
bevp_name = beva_full.bem_nameGet_0();
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_5_6_BuildVarSyn beva_o) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_o == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 39 */
if (bevp_name == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_7_tmpany_phold = beva_o.bem_nameGet_0();
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_9_tmpany_phold = beva_o.bem_nameGet_0();
bevt_8_tmpany_phold = bevp_name.bem_notEquals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 41 */
bevt_12_tmpany_phold = beva_o.bem_isTypedGet_0();
bevt_11_tmpany_phold = bevp_isTyped.bem_notEquals_1(bevt_12_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_13_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 44 */
if (bevp_isTyped.bevi_bool) /* Line: 46 */ {
bevt_15_tmpany_phold = beva_o.bem_namepathGet_0();
bevt_14_tmpany_phold = bevp_namepath.bem_notEquals_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 46 */
 else  /* Line: 46 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 46 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 47 */
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 24, 25, 30, 31, 32, 33, 34, 39, 39, 39, 39, 40, 40, 40, 40, 40, 0, 0, 0, 40, 40, 0, 0, 0, 41, 41, 43, 43, 44, 44, 46, 46, 0, 0, 0, 47, 47, 49, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 19, 20, 24, 25, 26, 27, 28, 50, 55, 56, 57, 59, 64, 65, 66, 71, 72, 75, 79, 82, 83, 85, 88, 92, 95, 96, 98, 99, 101, 102, 105, 106, 108, 111, 115, 118, 119, 121, 122, 125, 128, 132, 135, 139, 142, 146, 149, 153, 156};
/* BEGIN LINEINFO 
assign 1 20 15
new 0 20 15
assign 1 24 19
assign 1 25 20
new 0 25 20
assign 1 30 24
nameGet 0 30 24
assign 1 31 25
namepathGet 0 31 25
assign 1 32 26
isTypedGet 0 32 26
assign 1 33 27
isSelfGet 0 33 27
assign 1 34 28
isThisGet 0 34 28
assign 1 39 50
undef 1 39 55
assign 1 39 56
new 0 39 56
return 1 39 57
assign 1 40 59
def 1 40 64
assign 1 40 65
nameGet 0 40 65
assign 1 40 66
def 1 40 71
assign 1 0 72
assign 1 0 75
assign 1 0 79
assign 1 40 82
nameGet 0 40 82
assign 1 40 83
notEquals 1 40 83
assign 1 0 85
assign 1 0 88
assign 1 0 92
assign 1 41 95
new 0 41 95
return 1 41 96
assign 1 43 98
isTypedGet 0 43 98
assign 1 43 99
notEquals 1 43 99
assign 1 44 101
new 0 44 101
return 1 44 102
assign 1 46 105
namepathGet 0 46 105
assign 1 46 106
notEquals 1 46 106
assign 1 0 108
assign 1 0 111
assign 1 0 115
assign 1 47 118
new 0 47 118
return 1 47 119
assign 1 49 121
new 0 49 121
return 1 49 122
return 1 0 125
assign 1 0 128
return 1 0 132
assign 1 0 135
return 1 0 139
assign 1 0 142
return 1 0 146
assign 1 0 149
return 1 0 153
assign 1 0 156
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1964495741: return bem_serializeContents_0();
case 716581775: return bem_fieldIteratorGet_0();
case -864977132: return bem_echo_0();
case -694642189: return bem_serializationIteratorGet_0();
case 1885938794: return bem_toAny_0();
case -1626502172: return bem_iteratorGet_0();
case 614595662: return bem_isSelfGet_0();
case 498230251: return bem_classNameGet_0();
case -1170883362: return bem_deserializeClassNameGet_0();
case -108593702: return bem_sourceFileNameGet_0();
case -640694898: return bem_many_0();
case -296700272: return bem_create_0();
case 1736428289: return bem_namepathGet_0();
case -231534902: return bem_new_0();
case -869030838: return bem_hashGet_0();
case -2071511275: return bem_nameGet_0();
case 1276785109: return bem_once_0();
case 1207509984: return bem_print_0();
case 1778404598: return bem_tagGet_0();
case -327890059: return bem_toString_0();
case -2084582003: return bem_isTypedGet_0();
case -838633237: return bem_serializeToString_0();
case -602026259: return bem_isThisGet_0();
case -1470416551: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1697977276: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 801560985: return bem_contentsEqual_1((BEC_2_5_6_BuildVarSyn) bevd_0);
case -1849236093: return bem_nameSet_1(bevd_0);
case -898771829: return bem_otherType_1(bevd_0);
case 1971930884: return bem_notEquals_1(bevd_0);
case 871367475: return bem_def_1(bevd_0);
case -587265418: return bem_anyNew_1((BEC_2_5_3_BuildVar) bevd_0);
case -1118008475: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -125588506: return bem_npNew_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2022931262: return bem_defined_1(bevd_0);
case -264609329: return bem_isTypedSet_1(bevd_0);
case 873867702: return bem_undef_1(bevd_0);
case -996916931: return bem_copyTo_1(bevd_0);
case -341054699: return bem_undefined_1(bevd_0);
case 1349020478: return bem_sameObject_1(bevd_0);
case -529840995: return bem_isThisSet_1(bevd_0);
case -503081019: return bem_namepathSet_1(bevd_0);
case 1029744872: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1805705632: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1363115649: return bem_equals_1(bevd_0);
case 1910312615: return bem_isSelfSet_1(bevd_0);
case 41506532: return bem_otherClass_1(bevd_0);
case -1237205225: return bem_sameClass_1(bevd_0);
case -1073870688: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 508127182: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1597816100: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -282965627: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1721714391: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -48765507: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1009765426: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1302207765: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildVarSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildVarSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildVarSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst = (BEC_2_5_6_BuildVarSyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildVarSyn.bece_BEC_2_5_6_BuildVarSyn_bevs_inst;
}
}
}
