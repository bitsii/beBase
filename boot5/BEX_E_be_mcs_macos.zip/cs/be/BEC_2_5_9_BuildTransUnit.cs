namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_9_BuildTransUnit : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransUnit() { }
static BEC_2_5_9_BuildTransUnit() { }
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x55,0x6E,0x69,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildTransUnit bece_BEC_2_5_9_BuildTransUnit_bevs_inst;

public static new BET_2_5_9_BuildTransUnit bece_BEC_2_5_9_BuildTransUnit_bevs_type;

public BEC_2_9_3_ContainerMap bevp_aliased;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_aliased = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_emits == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 61 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {55, 60, 60, 62, 65, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 20, 25, 26, 28, 32, 35, 39, 42};
/* BEGIN LINEINFO 
assign 1 55 15
new 0 55 15
assign 1 60 20
undef 1 60 25
assign 1 62 26
new 0 62 26
addValue 1 65 28
return 1 0 32
assign 1 0 35
return 1 0 39
assign 1 0 42
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -100075913: return bem_new_0();
case -92908170: return bem_print_0();
case -1435450334: return bem_classNameGet_0();
case -977833063: return bem_toString_0();
case 975002362: return bem_tagGet_0();
case 1732066970: return bem_echo_0();
case 1714984646: return bem_serializeToString_0();
case 189986949: return bem_toAny_0();
case 1348777534: return bem_many_0();
case -2080318285: return bem_sourceFileNameGet_0();
case -1698152847: return bem_serializationIteratorGet_0();
case 713197195: return bem_deserializeClassNameGet_0();
case 596758489: return bem_create_0();
case 1418537405: return bem_fieldIteratorGet_0();
case 1907596400: return bem_copy_0();
case 1361238708: return bem_serializeContents_0();
case -1320125172: return bem_once_0();
case -571285042: return bem_emitsGet_0();
case -1381529802: return bem_aliasedGet_0();
case -328171317: return bem_hashGet_0();
case -873085717: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -36926033: return bem_notEquals_1(bevd_0);
case -1175913089: return bem_copyTo_1(bevd_0);
case -1994926628: return bem_equals_1(bevd_0);
case 1751997360: return bem_sameType_1(bevd_0);
case -646630509: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1224722581: return bem_sameObject_1(bevd_0);
case 1518013019: return bem_sameClass_1(bevd_0);
case 1282405925: return bem_undef_1(bevd_0);
case -1216369595: return bem_emitsSet_1(bevd_0);
case 1352047622: return bem_otherType_1(bevd_0);
case 1426239673: return bem_addEmit_1(bevd_0);
case -1100168867: return bem_undefined_1(bevd_0);
case 260175125: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1853876470: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1396276210: return bem_defined_1(bevd_0);
case -755554524: return bem_aliasedSet_1(bevd_0);
case -1549856675: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1934176007: return bem_def_1(bevd_0);
case 1046870228: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2016086138: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1435346286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1420429474: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -736048547: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 330118335: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 59891114: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1935054934: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransUnit_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_9_BuildTransUnit_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransUnit();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst = (BEC_2_5_9_BuildTransUnit) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_type;
}
}
}
