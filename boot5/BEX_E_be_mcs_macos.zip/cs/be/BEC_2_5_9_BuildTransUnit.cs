namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_9_BuildTransUnit : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransUnit() { }
static BEC_2_5_9_BuildTransUnit() { }
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x55,0x6E,0x69,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransUnit_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildTransUnit bece_BEC_2_5_9_BuildTransUnit_bevs_inst;
public BEC_2_9_3_ContainerMap bevp_aliased;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_aliased = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_emits == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 61 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public BEC_2_5_9_BuildTransUnit bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {55, 60, 60, 62, 65, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {12, 17, 22, 23, 25, 29, 32, 36, 39};
/* BEGIN LINEINFO 
assign 1 55 12
new 0 55 12
assign 1 60 17
undef 1 60 22
assign 1 62 23
new 0 62 23
addValue 1 65 25
return 1 0 29
assign 1 0 32
return 1 0 36
assign 1 0 39
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 570560636: return bem_serializeToString_0();
case -993607120: return bem_fieldIteratorGet_0();
case 462697424: return bem_many_0();
case 1113679576: return bem_echo_0();
case -817841652: return bem_toAny_0();
case -1779073385: return bem_toString_0();
case -386274073: return bem_tagGet_0();
case -1620217339: return bem_serializeContents_0();
case -1683940834: return bem_create_0();
case -604042750: return bem_once_0();
case 32699518: return bem_copy_0();
case 1007010882: return bem_hashGet_0();
case -1921544600: return bem_emitsGet_0();
case 984657505: return bem_serializationIteratorGet_0();
case 1611504589: return bem_new_0();
case -829112796: return bem_sourceFileNameGet_0();
case -349248390: return bem_deserializeClassNameGet_0();
case -999823048: return bem_aliasedGet_0();
case 1467676516: return bem_iteratorGet_0();
case 967087648: return bem_classNameGet_0();
case -68587803: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1017703126: return bem_def_1(bevd_0);
case -2080970498: return bem_aliasedSet_1(bevd_0);
case 871077747: return bem_copyTo_1(bevd_0);
case 186027133: return bem_sameObject_1(bevd_0);
case -497225509: return bem_undef_1(bevd_0);
case -1003116355: return bem_undefined_1(bevd_0);
case -1371950595: return bem_sameType_1(bevd_0);
case -1163022531: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 768529536: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1219927083: return bem_equals_1(bevd_0);
case 400917403: return bem_sameClass_1(bevd_0);
case -1320126626: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1964832492: return bem_emitsSet_1(bevd_0);
case -1915157348: return bem_defined_1(bevd_0);
case -1394703037: return bem_notEquals_1(bevd_0);
case -337289143: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -236889018: return bem_addEmit_1(bevd_0);
case -1857123920: return bem_otherType_1(bevd_0);
case -690797068: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 963667386: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 194196311: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 5892141: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 980645593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -74821886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1893386943: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -423405168: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransUnit_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_9_BuildTransUnit_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransUnit();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst = (BEC_2_5_9_BuildTransUnit) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransUnit.bece_BEC_2_5_9_BuildTransUnit_bevs_inst;
}
}
}
