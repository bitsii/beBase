namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator : BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
static BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_2, 2));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_4, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x21};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_6, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_9, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_9, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_10, 51));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_10, 51));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_12, 35));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_13, 1));
public static new BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static new BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_debug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_restart_0() {
bem_new_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_start_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_2_ta_ph = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_ta_ph.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
while (true)
/* Line: 167*/ {
if (bevl_nxt == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_5_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_0;
bevt_4_ta_ph = bevl_nxt.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 167*/
 else /* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 167*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 168*/
 else /* Line: 167*/ {
break;
} /* Line: 167*/
} /* Line: 167*/
if (bevl_nxt == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_8_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_1;
bevt_7_ta_ph = bevl_nxt.bem_equals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 170*/
 else /* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 170*/ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 171*/
return this;
} /*method end*/
public virtual BEC_2_3_3_XmlTag bem_nextGet_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_13_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_14_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_15_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_16_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_17_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_18_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_19_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_7_TextStrings bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_3_8_XmlTextNode bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_3_7_XmlComment bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_5_4_LogicBool bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_5_4_LogicBool bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_5_4_LogicBool bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_5_4_LogicBool bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_5_4_LogicBool bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_5_4_LogicBool bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_5_4_LogicBool bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_5_4_LogicBool bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_5_4_LogicBool bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_4_6_TextString bevt_127_ta_ph = null;
BEC_2_5_4_LogicBool bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_4_LogicBool bevt_130_ta_ph = null;
BEC_2_4_6_TextString bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_ta_ph = null;
BEC_2_4_6_TextString bevt_134_ta_ph = null;
BEC_2_4_6_TextString bevt_135_ta_ph = null;
BEC_2_4_6_TextString bevt_136_ta_ph = null;
BEC_2_4_6_TextString bevt_137_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 176*/ {
bem_start_0();
} /* Line: 177*/
bevt_21_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_ta_ph.bem_quoteGet_0();
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_ta_ph.bem_newlineGet_0();
if (bevp_skip.bevi_bool)/* Line: 182*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-161234372);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 184*/
 else /* Line: 185*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 186*/
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 189*/ {
if (bevp_textNode.bevi_bool)/* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 189*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 189*/ {
while (true)
/* Line: 190*/ {
bevt_25_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_2;
bevt_24_ta_ph = bevl_nxt.bem_notEquals_1(bevt_25_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 190*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 192*/
 else /* Line: 190*/ {
break;
} /* Line: 190*/
} /* Line: 190*/
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_27_ta_ph = bevl_accum.bem_extractString_0();
bevt_26_ta_ph = (BEC_2_3_8_XmlTextNode) (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_ta_ph);
return bevt_26_ta_ph;
} /* Line: 196*/
 else /* Line: 189*/ {
if (bevl_nxt == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_30_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_3;
bevt_29_ta_ph = bevl_nxt.bem_equals_1(bevt_30_ta_ph);
if (bevt_29_ta_ph.bevi_bool)/* Line: 198*/ {
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
while (true)
/* Line: 205*/ {
bevt_32_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_4;
bevt_31_ta_ph = bevl_nxt.bem_notEquals_1(bevt_32_ta_ph);
if (bevt_31_ta_ph.bevi_bool)/* Line: 205*/ {
if (bevl_pinstruct.bevi_bool)/* Line: 206*/ {
bevl_instr = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
/* Line: 208*/ {
if (bevl_instr.bevi_bool)/* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 208*/ {
bevt_34_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_5;
bevt_33_ta_ph = bevl_nxt.bem_notEquals_1(bevt_34_ta_ph);
if (bevt_33_ta_ph.bevi_bool)/* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 208*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 208*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_ta_ph = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_ta_ph.bevi_bool)/* Line: 210*/ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 211*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 213*/
 else /* Line: 208*/ {
break;
} /* Line: 208*/
} /* Line: 208*/
bevt_36_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_36_ta_ph);
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
/* Line: 217*/ {
if (bevl_nxt == null) {
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_39_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_6;
bevt_38_ta_ph = bevl_nxt.bem_notEquals_1(bevt_39_ta_ph);
if (bevt_38_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 217*/
 else /* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 217*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 218*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_41_ta_ph = bevl_accum.bem_toString_0();
bevt_40_ta_ph = (BEC_2_3_21_XmlProcessingInstruction) (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_ta_ph);
return bevt_40_ta_ph;
} /* Line: 221*/
if (bevl_comment.bevi_bool)/* Line: 223*/ {
while (true)
/* Line: 224*/ {
bevt_43_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_7;
bevt_42_ta_ph = bevl_nxt.bem_notEquals_1(bevt_43_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 224*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
bevt_45_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_8;
bevt_44_ta_ph = bevl_nxt.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_48_ta_ph = bevl_accum.bem_toString_0();
bevt_49_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_9;
bevt_47_ta_ph = bevt_48_ta_ph.bem_ends_1(bevt_49_ta_ph);
if (bevt_47_ta_ph.bevi_bool) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 227*/
 else /* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 227*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 229*/
} /* Line: 227*/
 else /* Line: 224*/ {
break;
} /* Line: 224*/
} /* Line: 224*/
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
/* Line: 233*/ {
if (bevl_nxt == null) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_52_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_10;
bevt_51_ta_ph = bevl_nxt.bem_notEquals_1(bevt_52_ta_ph);
if (bevt_51_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 233*/
 else /* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 233*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 234*/
 else /* Line: 233*/ {
break;
} /* Line: 233*/
} /* Line: 233*/
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_53_ta_ph);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_55_ta_ph = bevl_accum.bem_extractString_0();
bevt_54_ta_ph = (BEC_2_3_7_XmlComment) (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_ta_ph);
return bevt_54_ta_ph;
} /* Line: 238*/
if (bevl_tagName.bevi_bool)/* Line: 240*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
while (true)
/* Line: 242*/ {
bevt_57_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_11;
bevt_56_ta_ph = bevl_nxt.bem_equals_1(bevt_57_ta_ph);
if (bevt_56_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_58_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 242*/ {
bevt_59_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_ta_ph.bevi_bool)/* Line: 243*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 243*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 244*/
 else /* Line: 242*/ {
break;
} /* Line: 242*/
} /* Line: 242*/
bevt_61_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_12;
bevt_60_ta_ph = bevl_nxt.bem_equals_1(bevt_61_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 246*/ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
bevl_accum.bem_extractString_0();
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_5));
bevl_accum.bem_addValue_1(bevt_62_ta_ph);
} /* Line: 251*/
 else /* Line: 246*/ {
bevt_64_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_13;
bevt_63_ta_ph = bevl_nxt.bem_equals_1(bevt_64_ta_ph);
if (bevt_63_ta_ph.bevi_bool)/* Line: 252*/ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
bevl_accum.bem_extractString_0();
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_7));
bevl_accum.bem_addValue_1(bevt_65_ta_ph);
} /* Line: 257*/
 else /* Line: 258*/ {
bevt_67_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_14;
bevt_66_ta_ph = bevl_nxt.bem_equals_1(bevt_67_ta_ph);
if (bevt_66_ta_ph.bevi_bool)/* Line: 259*/ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 261*/
while (true)
/* Line: 263*/ {
bevt_69_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_15;
bevt_68_ta_ph = bevl_nxt.bem_notEquals_1(bevt_69_ta_ph);
if (bevt_68_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_70_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_72_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_16;
bevt_71_ta_ph = bevl_nxt.bem_notEquals_1(bevt_72_ta_ph);
if (bevt_71_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_74_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_17;
bevt_73_ta_ph = bevl_nxt.bem_notEquals_1(bevt_74_ta_ph);
if (bevt_73_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 263*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 265*/
 else /* Line: 263*/ {
break;
} /* Line: 263*/
} /* Line: 263*/
bevt_75_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_ta_ph.bevi_bool)/* Line: 267*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 267*/
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 269*/ {
bevl_myElement = (BEC_2_3_12_XmlStartElement) (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_ta_ph);
} /* Line: 272*/
 else /* Line: 273*/ {
bevl_myEndElement = (BEC_2_3_10_XmlEndElement) (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_ta_ph = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_ta_ph);
bevl_myTag = bevl_myEndElement;
} /* Line: 276*/
bevt_79_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_18;
bevt_78_ta_ph = bevl_nxt.bem_equals_1(bevt_79_ta_ph);
if (bevt_78_ta_ph.bevi_bool)/* Line: 278*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 280*/ {
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 281*/
} /* Line: 280*/
 else /* Line: 278*/ {
bevt_81_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_19;
bevt_80_ta_ph = bevl_nxt.bem_equals_1(bevt_81_ta_ph);
if (bevt_80_ta_ph.bevi_bool)/* Line: 283*/ {
if (bevl_isStart.bevi_bool)/* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 283*/
 else /* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 283*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_82_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 286*/
 else /* Line: 278*/ {
if (bevl_isStart.bevi_bool)/* Line: 287*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 288*/
 else /* Line: 289*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 290*/
} /* Line: 278*/
} /* Line: 278*/
} /* Line: 278*/
} /* Line: 246*/
} /* Line: 246*/
if (bevl_attributeName.bevi_bool)/* Line: 294*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
while (true)
/* Line: 296*/ {
bevt_84_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_20;
bevt_83_ta_ph = bevl_nxt.bem_equals_1(bevt_84_ta_ph);
if (bevt_83_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_85_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 296*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 296*/ {
bevt_86_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_ta_ph.bevi_bool)/* Line: 297*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 297*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 298*/
 else /* Line: 296*/ {
break;
} /* Line: 296*/
} /* Line: 296*/
while (true)
/* Line: 300*/ {
bevt_88_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_21;
bevt_87_ta_ph = bevl_nxt.bem_notEquals_1(bevt_88_ta_ph);
if (bevt_87_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_89_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_14_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_91_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_22;
bevt_90_ta_ph = bevl_nxt.bem_notEquals_1(bevt_91_ta_ph);
if (bevt_90_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_13_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_93_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_23;
bevt_92_ta_ph = bevl_nxt.bem_notEquals_1(bevt_93_ta_ph);
if (bevt_92_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_12_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_95_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_24;
bevt_94_ta_ph = bevl_nxt.bem_notEquals_1(bevt_95_ta_ph);
if (bevt_94_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 300*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 302*/
 else /* Line: 300*/ {
break;
} /* Line: 300*/
} /* Line: 300*/
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_96_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_ta_ph.bevi_bool)/* Line: 305*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 305*/
bevt_98_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_25;
bevt_97_ta_ph = bevl_nxt.bem_equals_1(bevt_98_ta_ph);
if (bevt_97_ta_ph.bevi_bool)/* Line: 306*/ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 308*/
 else /* Line: 306*/ {
bevt_100_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_26;
bevt_99_ta_ph = bevl_nxt.bem_equals_1(bevt_100_ta_ph);
if (bevt_99_ta_ph.bevi_bool)/* Line: 309*/ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_101_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 312*/
 else /* Line: 313*/ {
bevt_102_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_ta_ph);
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 315*/
} /* Line: 306*/
} /* Line: 306*/
if (bevl_attributeValue.bevi_bool)/* Line: 318*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
while (true)
/* Line: 320*/ {
bevt_104_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_27;
bevt_103_ta_ph = bevl_nxt.bem_equals_1(bevt_104_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_105_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 320*/
if (bevt_16_ta_anchor.bevi_bool)/* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_107_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_28;
bevt_106_ta_ph = bevl_nxt.bem_equals_1(bevt_107_ta_ph);
if (bevt_106_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 320*/
if (bevt_15_ta_anchor.bevi_bool)/* Line: 320*/ {
bevt_108_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_ta_ph.bevi_bool)/* Line: 322*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 322*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 323*/
 else /* Line: 320*/ {
break;
} /* Line: 320*/
} /* Line: 320*/
bevt_109_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_ta_ph.bevi_bool)/* Line: 325*/ {
bevt_112_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_29;
bevt_113_ta_ph = bevp_line.bem_toString_0();
bevt_111_ta_ph = bevt_112_ta_ph.bem_add_1(bevt_113_ta_ph);
bevt_110_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_ta_ph);
throw new be.BECS_ThrowBack(bevt_110_ta_ph);
} /* Line: 326*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
while (true)
/* Line: 329*/ {
bevt_114_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_115_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_ta_ph.bevi_bool)/* Line: 330*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 330*/
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 332*/
 else /* Line: 329*/ {
break;
} /* Line: 329*/
} /* Line: 329*/
bevt_116_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_ta_ph.bevi_bool)/* Line: 334*/ {
bevt_119_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_30;
bevt_120_ta_ph = bevp_line.bem_toString_0();
bevt_118_ta_ph = bevt_119_ta_ph.bem_add_1(bevt_120_ta_ph);
bevt_117_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_ta_ph);
throw new be.BECS_ThrowBack(bevt_117_ta_ph);
} /* Line: 335*/
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_121_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_ta_ph);
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 339*/
} /* Line: 318*/
 else /* Line: 205*/ {
break;
} /* Line: 205*/
} /* Line: 205*/
if (bevl_myEndElement == null) {
bevt_122_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_122_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
if (bevl_myElement == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_124_ta_ph = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 342*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 342*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 342*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
while (true)
/* Line: 344*/ {
if (bevl_nxt == null) {
bevt_125_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_125_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_127_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_31;
bevt_126_ta_ph = bevl_nxt.bem_equals_1(bevt_127_ta_ph);
if (bevt_126_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_128_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 344*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 344*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 344*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(1799618430);
} /* Line: 344*/
 else /* Line: 344*/ {
break;
} /* Line: 344*/
} /* Line: 344*/
if (bevl_nxt == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_131_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_32;
bevt_130_ta_ph = bevl_nxt.bem_equals_1(bevt_131_ta_ph);
if (bevt_130_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 345*/
 else /* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_19_ta_anchor.bevi_bool)/* Line: 345*/ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 345*/
} /* Line: 345*/
} /* Line: 342*/
 else /* Line: 347*/ {
if (bevl_nxt == null) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 348*/ {
bevl_nxt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_11));
} /* Line: 348*/
bevt_136_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_33;
bevt_135_ta_ph = bevt_136_ta_ph.bem_add_1(bevl_nxt);
bevt_137_ta_ph = bece_BEC_2_3_11_XmlTagIterator_bevo_34;
bevt_134_ta_ph = bevt_135_ta_ph.bem_add_1(bevt_137_ta_ph);
bevt_133_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_ta_ph);
throw new be.BECS_ThrowBack(bevt_133_ta_ph);
} /* Line: 349*/
} /* Line: 198*/
} /* Line: 189*/
return bevl_myTag;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 356*/
bevt_2_ta_ph = bevp_iter.bemd_0(1091237859);
return (BEC_2_5_4_LogicBool) bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_xmlStringGet_0() {
return bevp_xmlString;
} /*method end*/
public BEC_2_4_6_TextString bem_xmlStringGetDirect_0() {
return bevp_xmlString;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xmlStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startedGet_0() {
return bevp_started;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startedGetDirect_0() {
return bevp_started;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_startedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_3_10_XmlXTokenizer bem_xtGet_0() {
return bevp_xt;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_xtGetDirect_0() {
return bevp_xt;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_resGet_0() {
return bevp_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_resGetDirect_0() {
return bevp_res;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_resSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterGetDirect_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iter = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_textNodeGet_0() {
return bevp_textNode;
} /*method end*/
public BEC_2_5_4_LogicBool bem_textNodeGetDirect_0() {
return bevp_textNode;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_textNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineGet_0() {
return bevp_line;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGetDirect_0() {
return bevp_line;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_lineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipGet_0() {
return bevp_skip;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipGetDirect_0() {
return bevp_skip;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_skipSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_debugGetDirect_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_debugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {137, 138, 139, 140, 141, 142, 143, 144, 149, 150, 154, 158, 162, 162, 163, 164, 166, 167, 167, 167, 167, 0, 0, 0, 168, 170, 170, 170, 170, 0, 0, 0, 171, 176, 176, 177, 180, 180, 181, 181, 183, 184, 186, 188, 189, 189, 0, 0, 0, 190, 190, 191, 192, 194, 195, 196, 196, 196, 197, 197, 198, 198, 199, 200, 201, 202, 203, 204, 205, 205, 207, 0, 208, 208, 0, 0, 209, 210, 211, 211, 213, 215, 215, 216, 217, 217, 217, 217, 0, 0, 0, 218, 220, 221, 221, 221, 224, 224, 225, 226, 227, 227, 227, 227, 227, 227, 227, 0, 0, 0, 228, 229, 232, 233, 233, 233, 233, 0, 0, 0, 234, 236, 236, 237, 238, 238, 238, 241, 242, 242, 0, 242, 0, 0, 243, 243, 244, 246, 246, 247, 248, 249, 250, 251, 251, 252, 252, 253, 254, 255, 256, 257, 257, 259, 259, 260, 261, 263, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 264, 265, 267, 267, 268, 270, 271, 272, 272, 274, 275, 275, 276, 278, 278, 279, 281, 283, 283, 0, 0, 0, 284, 285, 285, 286, 288, 290, 295, 296, 296, 0, 296, 0, 0, 297, 297, 298, 300, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 301, 302, 304, 305, 305, 306, 306, 307, 308, 309, 309, 310, 311, 311, 312, 314, 314, 315, 319, 320, 320, 0, 320, 0, 0, 0, 320, 320, 0, 0, 322, 322, 323, 325, 326, 326, 326, 326, 326, 328, 329, 330, 330, 331, 332, 334, 335, 335, 335, 335, 335, 337, 338, 338, 339, 342, 342, 0, 342, 342, 342, 0, 0, 0, 0, 0, 343, 344, 344, 344, 344, 0, 344, 0, 0, 0, 0, 0, 344, 345, 345, 345, 345, 0, 0, 0, 345, 348, 348, 348, 349, 349, 349, 349, 349, 349, 352, 356, 356, 356, 356, 357, 357, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {71, 72, 73, 74, 75, 76, 77, 78, 82, 83, 87, 91, 104, 105, 106, 107, 108, 111, 116, 117, 118, 120, 123, 127, 130, 136, 141, 142, 143, 145, 148, 152, 155, 312, 317, 318, 320, 321, 322, 323, 325, 326, 329, 331, 332, 337, 339, 342, 346, 351, 352, 354, 355, 361, 362, 363, 364, 365, 368, 373, 374, 375, 377, 378, 379, 380, 381, 382, 385, 386, 389, 393, 396, 397, 399, 402, 406, 407, 409, 414, 415, 421, 422, 423, 426, 431, 432, 433, 435, 438, 442, 445, 451, 452, 453, 454, 459, 460, 462, 463, 464, 465, 467, 468, 469, 470, 475, 476, 479, 483, 486, 487, 494, 497, 502, 503, 504, 506, 509, 513, 516, 522, 523, 524, 525, 526, 527, 530, 533, 534, 536, 539, 541, 544, 548, 550, 552, 558, 559, 561, 562, 563, 564, 565, 566, 569, 570, 572, 573, 574, 575, 576, 577, 580, 581, 583, 584, 588, 589, 591, 593, 596, 600, 603, 604, 606, 609, 613, 616, 617, 619, 622, 626, 629, 630, 636, 638, 640, 642, 643, 644, 645, 648, 649, 650, 651, 653, 654, 656, 658, 662, 663, 666, 669, 673, 676, 677, 678, 679, 683, 686, 694, 697, 698, 700, 703, 705, 708, 712, 714, 716, 724, 725, 727, 729, 732, 736, 739, 740, 742, 745, 749, 752, 753, 755, 758, 762, 765, 766, 768, 771, 775, 778, 779, 785, 786, 788, 790, 791, 793, 794, 797, 798, 800, 801, 802, 803, 806, 807, 808, 813, 816, 817, 819, 822, 824, 827, 831, 834, 835, 837, 840, 844, 846, 848, 854, 856, 857, 858, 859, 860, 862, 865, 867, 869, 871, 872, 878, 880, 881, 882, 883, 884, 886, 887, 888, 889, 896, 901, 902, 905, 910, 911, 913, 916, 920, 923, 926, 930, 933, 938, 939, 940, 942, 945, 947, 950, 954, 957, 961, 964, 970, 975, 976, 977, 979, 982, 986, 989, 994, 999, 1000, 1002, 1003, 1004, 1005, 1006, 1007, 1011, 1017, 1022, 1023, 1024, 1026, 1027, 1030, 1033, 1036, 1040, 1044, 1047, 1050, 1054, 1058, 1061, 1064, 1068, 1072, 1075, 1078, 1082, 1086, 1089, 1092, 1096, 1100, 1103, 1106, 1110, 1114, 1117, 1120, 1124, 1128, 1131, 1134, 1138, 1142, 1145, 1148, 1152};
/* BEGIN LINEINFO 
assign 1 137 71
new 0 137 71
assign 1 138 72
new 0 138 72
assign 1 139 73
assign 1 140 74
assign 1 141 75
new 0 141 75
assign 1 142 76
new 0 142 76
assign 1 143 77
new 0 143 77
assign 1 144 78
new 0 144 78
new 0 149 82
assign 1 150 83
new 0 154 87
return 1 158 91
assign 1 162 104
tokGet 0 162 104
assign 1 162 105
tokenize 1 162 105
assign 1 163 106
iteratorGet 0 163 106
assign 1 164 107
new 0 164 107
assign 1 166 108
nextGet 0 166 108
assign 1 167 111
def 1 167 116
assign 1 167 117
new 0 167 117
assign 1 167 118
notEquals 1 167 118
assign 1 0 120
assign 1 0 123
assign 1 0 127
assign 1 168 130
nextGet 0 168 130
assign 1 170 136
def 1 170 141
assign 1 170 142
new 0 170 142
assign 1 170 143
equals 1 170 143
assign 1 0 145
assign 1 0 148
assign 1 0 152
assign 1 171 155
new 0 171 155
assign 1 176 312
not 0 176 317
start 0 177 318
assign 1 180 320
new 0 180 320
assign 1 180 321
quoteGet 0 180 321
assign 1 181 322
new 0 181 322
assign 1 181 323
newlineGet 0 181 323
assign 1 183 325
currentGet 0 183 325
assign 1 184 326
new 0 184 326
assign 1 186 329
nextGet 0 186 329
assign 1 188 331
new 0 188 331
assign 1 189 332
def 1 189 337
assign 1 0 339
assign 1 0 342
assign 1 0 346
assign 1 190 351
new 0 190 351
assign 1 190 352
notEquals 1 190 352
addValue 1 191 354
assign 1 192 355
nextGet 0 192 355
assign 1 194 361
new 0 194 361
assign 1 195 362
new 0 195 362
assign 1 196 363
extractString 0 196 363
assign 1 196 364
new 1 196 364
return 1 196 365
assign 1 197 368
def 1 197 373
assign 1 198 374
new 0 198 374
assign 1 198 375
equals 1 198 375
assign 1 199 377
new 0 199 377
assign 1 200 378
new 0 200 378
assign 1 201 379
new 0 201 379
assign 1 202 380
new 0 202 380
assign 1 203 381
new 0 203 381
assign 1 204 382
new 0 204 382
assign 1 205 385
new 0 205 385
assign 1 205 386
notEquals 1 205 386
assign 1 207 389
new 0 207 389
assign 1 0 393
assign 1 208 396
new 0 208 396
assign 1 208 397
notEquals 1 208 397
assign 1 0 399
assign 1 0 402
addValue 1 209 406
assign 1 210 407
equals 1 210 407
assign 1 211 409
not 0 211 414
assign 1 213 415
nextGet 0 213 415
assign 1 215 421
new 0 215 421
addValue 1 215 422
assign 1 216 423
new 0 216 423
assign 1 217 426
def 1 217 431
assign 1 217 432
new 0 217 432
assign 1 217 433
notEquals 1 217 433
assign 1 0 435
assign 1 0 438
assign 1 0 442
assign 1 218 445
nextGet 0 218 445
assign 1 220 451
new 0 220 451
assign 1 221 452
toString 0 221 452
assign 1 221 453
new 1 221 453
return 1 221 454
assign 1 224 459
new 0 224 459
assign 1 224 460
notEquals 1 224 460
addValue 1 225 462
assign 1 226 463
nextGet 0 226 463
assign 1 227 464
new 0 227 464
assign 1 227 465
equals 1 227 465
assign 1 227 467
toString 0 227 467
assign 1 227 468
new 0 227 468
assign 1 227 469
ends 1 227 469
assign 1 227 470
not 0 227 475
assign 1 0 476
assign 1 0 479
assign 1 0 483
addValue 1 228 486
assign 1 229 487
nextGet 0 229 487
assign 1 232 494
new 0 232 494
assign 1 233 497
def 1 233 502
assign 1 233 503
new 0 233 503
assign 1 233 504
notEquals 1 233 504
assign 1 0 506
assign 1 0 509
assign 1 0 513
assign 1 234 516
nextGet 0 234 516
assign 1 236 522
new 0 236 522
addValue 1 236 523
assign 1 237 524
new 0 237 524
assign 1 238 525
extractString 0 238 525
assign 1 238 526
new 1 238 526
return 1 238 527
assign 1 241 530
nextGet 0 241 530
assign 1 242 533
new 0 242 533
assign 1 242 534
equals 1 242 534
assign 1 0 536
assign 1 242 539
equals 1 242 539
assign 1 0 541
assign 1 0 544
assign 1 243 548
equals 1 243 548
assign 1 243 550
increment 0 243 550
assign 1 244 552
nextGet 0 244 552
assign 1 246 558
new 0 246 558
assign 1 246 559
equals 1 246 559
assign 1 247 561
new 0 247 561
assign 1 248 562
new 0 248 562
assign 1 249 563
nextGet 0 249 563
extractString 0 250 564
assign 1 251 565
new 0 251 565
addValue 1 251 566
assign 1 252 569
new 0 252 569
assign 1 252 570
equals 1 252 570
assign 1 253 572
new 0 253 572
assign 1 254 573
new 0 254 573
assign 1 255 574
nextGet 0 255 574
extractString 0 256 575
assign 1 257 576
new 0 257 576
addValue 1 257 577
assign 1 259 580
new 0 259 580
assign 1 259 581
equals 1 259 581
assign 1 260 583
new 0 260 583
assign 1 261 584
nextGet 0 261 584
assign 1 263 588
new 0 263 588
assign 1 263 589
notEquals 1 263 589
assign 1 263 591
notEquals 1 263 591
assign 1 0 593
assign 1 0 596
assign 1 0 600
assign 1 263 603
new 0 263 603
assign 1 263 604
notEquals 1 263 604
assign 1 0 606
assign 1 0 609
assign 1 0 613
assign 1 263 616
new 0 263 616
assign 1 263 617
notEquals 1 263 617
assign 1 0 619
assign 1 0 622
assign 1 0 626
addValue 1 264 629
assign 1 265 630
nextGet 0 265 630
assign 1 267 636
equals 1 267 636
assign 1 267 638
increment 0 267 638
assign 1 268 640
new 0 268 640
assign 1 270 642
new 0 270 642
assign 1 271 643
assign 1 272 644
extractString 0 272 644
nameSet 1 272 645
assign 1 274 648
new 0 274 648
assign 1 275 649
extractString 0 275 649
nameSet 1 275 650
assign 1 276 651
assign 1 278 653
new 0 278 653
assign 1 278 654
equals 1 278 654
assign 1 279 656
new 0 279 656
assign 1 281 658
new 0 281 658
assign 1 283 662
new 0 283 662
assign 1 283 663
equals 1 283 663
assign 1 0 666
assign 1 0 669
assign 1 0 673
assign 1 284 676
new 0 284 676
assign 1 285 677
new 0 285 677
isClosedSet 1 285 678
assign 1 286 679
nextGet 0 286 679
assign 1 288 683
new 0 288 683
assign 1 290 686
new 0 290 686
assign 1 295 694
nextGet 0 295 694
assign 1 296 697
new 0 296 697
assign 1 296 698
equals 1 296 698
assign 1 0 700
assign 1 296 703
equals 1 296 703
assign 1 0 705
assign 1 0 708
assign 1 297 712
equals 1 297 712
assign 1 297 714
increment 0 297 714
assign 1 298 716
nextGet 0 298 716
assign 1 300 724
new 0 300 724
assign 1 300 725
notEquals 1 300 725
assign 1 300 727
notEquals 1 300 727
assign 1 0 729
assign 1 0 732
assign 1 0 736
assign 1 300 739
new 0 300 739
assign 1 300 740
notEquals 1 300 740
assign 1 0 742
assign 1 0 745
assign 1 0 749
assign 1 300 752
new 0 300 752
assign 1 300 753
notEquals 1 300 753
assign 1 0 755
assign 1 0 758
assign 1 0 762
assign 1 300 765
new 0 300 765
assign 1 300 766
notEquals 1 300 766
assign 1 0 768
assign 1 0 771
assign 1 0 775
addValue 1 301 778
assign 1 302 779
nextGet 0 302 779
assign 1 304 785
new 0 304 785
assign 1 305 786
equals 1 305 786
assign 1 305 788
increment 0 305 788
assign 1 306 790
new 0 306 790
assign 1 306 791
equals 1 306 791
assign 1 307 793
new 0 307 793
assign 1 308 794
new 0 308 794
assign 1 309 797
new 0 309 797
assign 1 309 798
equals 1 309 798
assign 1 310 800
new 0 310 800
assign 1 311 801
new 0 311 801
isClosedSet 1 311 802
assign 1 312 803
nextGet 0 312 803
assign 1 314 806
extractString 0 314 806
addAttributeName 1 314 807
assign 1 315 808
new 0 315 808
assign 1 319 813
nextGet 0 319 813
assign 1 320 816
new 0 320 816
assign 1 320 817
equals 1 320 817
assign 1 0 819
assign 1 320 822
equals 1 320 822
assign 1 0 824
assign 1 0 827
assign 1 0 831
assign 1 320 834
new 0 320 834
assign 1 320 835
equals 1 320 835
assign 1 0 837
assign 1 0 840
assign 1 322 844
equals 1 322 844
assign 1 322 846
increment 0 322 846
assign 1 323 848
nextGet 0 323 848
assign 1 325 854
notEquals 1 325 854
assign 1 326 856
new 0 326 856
assign 1 326 857
toString 0 326 857
assign 1 326 858
add 1 326 858
assign 1 326 859
new 1 326 859
throw 1 326 860
assign 1 328 862
nextGet 0 328 862
assign 1 329 865
notEquals 1 329 865
assign 1 330 867
equals 1 330 867
assign 1 330 869
increment 0 330 869
addValue 1 331 871
assign 1 332 872
nextGet 0 332 872
assign 1 334 878
notEquals 1 334 878
assign 1 335 880
new 0 335 880
assign 1 335 881
toString 0 335 881
assign 1 335 882
add 1 335 882
assign 1 335 883
new 1 335 883
throw 1 335 884
assign 1 337 886
new 0 337 886
assign 1 338 887
extractString 0 338 887
addAttributeValue 1 338 888
assign 1 339 889
new 0 339 889
assign 1 342 896
def 1 342 901
assign 1 0 902
assign 1 342 905
def 1 342 910
assign 1 342 911
isClosedGet 0 342 911
assign 1 0 913
assign 1 0 916
assign 1 0 920
assign 1 0 923
assign 1 0 926
assign 1 343 930
nextGet 0 343 930
assign 1 344 933
def 1 344 938
assign 1 344 939
new 0 344 939
assign 1 344 940
equals 1 344 940
assign 1 0 942
assign 1 344 945
equals 1 344 945
assign 1 0 947
assign 1 0 950
assign 1 0 954
assign 1 0 957
assign 1 0 961
assign 1 344 964
nextGet 0 344 964
assign 1 345 970
def 1 345 975
assign 1 345 976
new 0 345 976
assign 1 345 977
equals 1 345 977
assign 1 0 979
assign 1 0 982
assign 1 0 986
assign 1 345 989
new 0 345 989
assign 1 348 994
undef 1 348 999
assign 1 348 1000
new 0 348 1000
assign 1 349 1002
new 0 349 1002
assign 1 349 1003
add 1 349 1003
assign 1 349 1004
new 0 349 1004
assign 1 349 1005
add 1 349 1005
assign 1 349 1006
new 1 349 1006
throw 1 349 1007
return 1 352 1011
assign 1 356 1017
not 0 356 1022
assign 1 356 1023
new 0 356 1023
return 1 356 1024
assign 1 357 1026
hasNextGet 0 357 1026
return 1 357 1027
return 1 0 1030
return 1 0 1033
assign 1 0 1036
assign 1 0 1040
return 1 0 1044
return 1 0 1047
assign 1 0 1050
assign 1 0 1054
return 1 0 1058
return 1 0 1061
assign 1 0 1064
assign 1 0 1068
return 1 0 1072
return 1 0 1075
assign 1 0 1078
assign 1 0 1082
return 1 0 1086
return 1 0 1089
assign 1 0 1092
assign 1 0 1096
return 1 0 1100
return 1 0 1103
assign 1 0 1106
assign 1 0 1110
return 1 0 1114
return 1 0 1117
assign 1 0 1120
assign 1 0 1124
return 1 0 1128
return 1 0 1131
assign 1 0 1134
assign 1 0 1138
return 1 0 1142
return 1 0 1145
assign 1 0 1148
assign 1 0 1152
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 110382217: return bem_sourceFileNameGet_0();
case -968273985: return bem_skipGetDirect_0();
case 1986590366: return bem_hashGet_0();
case 879975179: return bem_classNameGet_0();
case -1802459344: return bem_iterGetDirect_0();
case 785959487: return bem_xtGetDirect_0();
case 1099757203: return bem_skipGet_0();
case 713230345: return bem_textNodeGetDirect_0();
case -1022914098: return bem_debugGetDirect_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 887739950: return bem_serializeToString_0();
case -119690365: return bem_debugGet_0();
case 2146138318: return bem_xtGet_0();
case 1799618430: return bem_nextGet_0();
case -2129983068: return bem_toAny_0();
case 1576446469: return bem_startedGetDirect_0();
case -196180702: return bem_textNodeGet_0();
case 233362262: return bem_many_0();
case 888041456: return bem_tagGet_0();
case 1843544518: return bem_serializeContents_0();
case 1732513565: return bem_copy_0();
case -1588532100: return bem_echo_0();
case -1978980962: return bem_startedGet_0();
case 1383646476: return bem_iteratorGet_0();
case 1903557359: return bem_lineGetDirect_0();
case 1989693945: return bem_toString_0();
case 2071597061: return bem_create_0();
case -1833149527: return bem_lineGet_0();
case -1537586941: return bem_restart_0();
case -1321407891: return bem_resGetDirect_0();
case -1084228149: return bem_print_0();
case 714460463: return bem_once_0();
case -305846219: return bem_xmlStringGet_0();
case -531071393: return bem_iterGet_0();
case 1091237859: return bem_hasNextGet_0();
case -614078662: return bem_xmlStringGetDirect_0();
case -794571513: return bem_start_0();
case 162533386: return bem_fieldNamesGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 1105152133: return bem_new_0();
case -153156208: return bem_serializationIteratorGet_0();
case 1814341057: return bem_resGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 189193717: return bem_xmlStringSet_1(bevd_0);
case 287719922: return bem_textNodeSetDirect_1(bevd_0);
case 260383829: return bem_lineSet_1(bevd_0);
case -1079511013: return bem_startedSetDirect_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case -251049677: return bem_xmlStringSetDirect_1(bevd_0);
case -921667111: return bem_iterSetDirect_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -1509106529: return bem_resSet_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case -331544750: return bem_startedSet_1(bevd_0);
case -222104810: return bem_textNodeSet_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case 502887620: return bem_debugSet_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case -58855624: return bem_skipSet_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -700221224: return bem_lineSetDirect_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1728283311: return bem_xtSet_1(bevd_0);
case 1208435563: return bem_resSetDirect_1(bevd_0);
case -2047602659: return bem_debugSetDirect_1(bevd_0);
case 605419167: return bem_xtSetDirect_1(bevd_0);
case 418953892: return bem_skipSetDirect_1(bevd_0);
case -1758884794: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1022142979: return bem_iterSet_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_11_XmlTagIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
}
