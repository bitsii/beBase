namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator : BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
static BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_0, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_1, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_2, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_3, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_4, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_5, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_7, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_8, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_9, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_10, 2));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_11, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_13, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_14 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_14, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_15 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_16 = {0x21};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_16, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_17 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_18 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_18, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_19 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_19, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_20 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_20, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_21 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_21, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_22 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_22, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_23 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_23, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_24 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_24, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_25 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_25, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_26 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_26, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_27 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_27, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_28 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_28, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_29 = {0x3E};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_29, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_30 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_30, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_31 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_31, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_32 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_32, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_33 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_33, 51));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_34 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_34, 51));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_35 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_35, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_36 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_36, 1));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_37 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_38 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_38, 35));
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_39 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_3_11_XmlTagIterator_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_3_11_XmlTagIterator_bels_39, 1));
public static new BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static new BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_debug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_restart_0() {
bem_new_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_start_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
while (true)
 /* Line: 168 */ {
if (bevl_nxt == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_5_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_0;
bevt_4_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 168 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 169 */
 else  /* Line: 168 */ {
break;
} /* Line: 168 */
} /* Line: 168 */
if (bevl_nxt == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_8_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_1;
bevt_7_tmpany_phold = bevl_nxt.bem_equals_1(bevt_8_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 171 */ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 172 */
return this;
} /*method end*/
public virtual BEC_2_3_3_XmlTag bem_nextGet_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_21_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_3_8_XmlTextNode bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_3_7_XmlComment bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_116_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_tmpany_phold = null;
BEC_2_4_6_TextString bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 177 */ {
bem_start_0();
} /* Line: 178 */
bevt_21_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_tmpany_phold.bem_quoteGet_0();
bevt_22_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_tmpany_phold.bem_newlineGet_0();
if (bevp_skip.bevi_bool) /* Line: 183 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-42213840);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 185 */
 else  /* Line: 186 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 187 */
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 190 */ {
if (bevp_textNode.bevi_bool) /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 190 */
 else  /* Line: 190 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 190 */ {
while (true)
 /* Line: 191 */ {
bevt_25_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_2;
bevt_24_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_25_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 193 */
 else  /* Line: 191 */ {
break;
} /* Line: 191 */
} /* Line: 191 */
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_27_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_26_tmpany_phold = (BEC_2_3_8_XmlTextNode) (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_tmpany_phold);
return bevt_26_tmpany_phold;
} /* Line: 197 */
 else  /* Line: 190 */ {
if (bevl_nxt == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_30_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_3;
bevt_29_tmpany_phold = bevl_nxt.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 206 */ {
bevt_32_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_4;
bevt_31_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_32_tmpany_phold);
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 206 */ {
if (bevl_pinstruct.bevi_bool) /* Line: 207 */ {
bevl_instr = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 209 */ {
if (bevl_instr.bevi_bool) /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_34_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_5;
bevt_33_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_34_tmpany_phold);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 209 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 209 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 209 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_tmpany_phold = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 211 */ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 212 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 214 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_6));
bevl_accum.bem_addValue_1(bevt_36_tmpany_phold);
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 218 */ {
if (bevl_nxt == null) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_39_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_6;
bevt_38_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
 else  /* Line: 218 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 218 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 219 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_41_tmpany_phold = bevl_accum.bem_toString_0();
bevt_40_tmpany_phold = (BEC_2_3_21_XmlProcessingInstruction) (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_tmpany_phold);
return bevt_40_tmpany_phold;
} /* Line: 222 */
if (bevl_comment.bevi_bool) /* Line: 224 */ {
while (true)
 /* Line: 225 */ {
bevt_43_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_7;
bevt_42_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_43_tmpany_phold);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
bevt_45_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_8;
bevt_44_tmpany_phold = bevl_nxt.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_48_tmpany_phold = bevl_accum.bem_toString_0();
bevt_49_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_9;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_ends_1(bevt_49_tmpany_phold);
if (bevt_47_tmpany_phold.bevi_bool) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 228 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 230 */
} /* Line: 228 */
 else  /* Line: 225 */ {
break;
} /* Line: 225 */
} /* Line: 225 */
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
 /* Line: 234 */ {
if (bevl_nxt == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_52_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_10;
bevt_51_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_52_tmpany_phold);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 234 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 235 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_12));
bevl_accum.bem_addValue_1(bevt_53_tmpany_phold);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_55_tmpany_phold = bevl_accum.bem_extractString_0();
bevt_54_tmpany_phold = (BEC_2_3_7_XmlComment) (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_tmpany_phold);
return bevt_54_tmpany_phold;
} /* Line: 239 */
if (bevl_tagName.bevi_bool) /* Line: 241 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
while (true)
 /* Line: 243 */ {
bevt_57_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_11;
bevt_56_tmpany_phold = bevl_nxt.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_58_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevt_59_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 244 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 244 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 245 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
bevt_61_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_12;
bevt_60_tmpany_phold = bevl_nxt.bem_equals_1(bevt_61_tmpany_phold);
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
bevl_accum.bem_extractString_0();
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_15));
bevl_accum.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 252 */
 else  /* Line: 247 */ {
bevt_64_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_13;
bevt_63_tmpany_phold = bevl_nxt.bem_equals_1(bevt_64_tmpany_phold);
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
bevl_accum.bem_extractString_0();
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_17));
bevl_accum.bem_addValue_1(bevt_65_tmpany_phold);
} /* Line: 258 */
 else  /* Line: 259 */ {
bevt_67_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_14;
bevt_66_tmpany_phold = bevl_nxt.bem_equals_1(bevt_67_tmpany_phold);
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 262 */
while (true)
 /* Line: 264 */ {
bevt_69_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_15;
bevt_68_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_69_tmpany_phold);
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_70_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_72_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_16;
bevt_71_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevt_74_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_17;
bevt_73_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_74_tmpany_phold);
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 264 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 266 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevt_75_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 268 */
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 270 */ {
bevl_myElement = (BEC_2_3_12_XmlStartElement) (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_tmpany_phold);
} /* Line: 273 */
 else  /* Line: 274 */ {
bevl_myEndElement = (BEC_2_3_10_XmlEndElement) (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_tmpany_phold);
bevl_myTag = bevl_myEndElement;
} /* Line: 277 */
bevt_79_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_18;
bevt_78_tmpany_phold = bevl_nxt.bem_equals_1(bevt_79_tmpany_phold);
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 279 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool) /* Line: 281 */ {
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 282 */
} /* Line: 281 */
 else  /* Line: 279 */ {
bevt_81_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_19;
bevt_80_tmpany_phold = bevl_nxt.bem_equals_1(bevt_81_tmpany_phold);
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 284 */ {
if (bevl_isStart.bevi_bool) /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_82_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 287 */
 else  /* Line: 279 */ {
if (bevl_isStart.bevi_bool) /* Line: 288 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 289 */
 else  /* Line: 290 */ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 291 */
} /* Line: 279 */
} /* Line: 279 */
} /* Line: 279 */
} /* Line: 247 */
} /* Line: 247 */
if (bevl_attributeName.bevi_bool) /* Line: 295 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
while (true)
 /* Line: 297 */ {
bevt_84_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_20;
bevt_83_tmpany_phold = bevl_nxt.bem_equals_1(bevt_84_tmpany_phold);
if (bevt_83_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_85_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 297 */ {
bevt_86_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 298 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 299 */
 else  /* Line: 297 */ {
break;
} /* Line: 297 */
} /* Line: 297 */
while (true)
 /* Line: 301 */ {
bevt_88_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_21;
bevt_87_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_88_tmpany_phold);
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_89_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_91_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_22;
bevt_90_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_91_tmpany_phold);
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_93_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_23;
bevt_92_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_93_tmpany_phold);
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevt_95_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_24;
bevt_94_tmpany_phold = bevl_nxt.bem_notEquals_1(bevt_95_tmpany_phold);
if (bevt_94_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 301 */
 else  /* Line: 301 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 301 */ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 303 */
 else  /* Line: 301 */ {
break;
} /* Line: 301 */
} /* Line: 301 */
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_96_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 306 */
bevt_98_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_25;
bevt_97_tmpany_phold = bevl_nxt.bem_equals_1(bevt_98_tmpany_phold);
if (bevt_97_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 309 */
 else  /* Line: 307 */ {
bevt_100_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_26;
bevt_99_tmpany_phold = bevl_nxt.bem_equals_1(bevt_100_tmpany_phold);
if (bevt_99_tmpany_phold.bevi_bool) /* Line: 310 */ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_101_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_tmpany_phold);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevt_102_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_tmpany_phold);
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 316 */
} /* Line: 307 */
} /* Line: 307 */
if (bevl_attributeValue.bevi_bool) /* Line: 319 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
while (true)
 /* Line: 321 */ {
bevt_104_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_27;
bevt_103_tmpany_phold = bevl_nxt.bem_equals_1(bevt_104_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_105_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_16_tmpany_anchor.bevi_bool) /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_107_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_28;
bevt_106_tmpany_phold = bevl_nxt.bem_equals_1(bevt_107_tmpany_phold);
if (bevt_106_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_15_tmpany_anchor.bevi_bool) /* Line: 321 */ {
bevt_108_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 323 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
bevt_109_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 326 */ {
bevt_112_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_29;
bevt_113_tmpany_phold = bevp_line.bem_toString_0();
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bem_add_1(bevt_113_tmpany_phold);
bevt_110_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_110_tmpany_phold);
} /* Line: 327 */
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
while (true)
 /* Line: 330 */ {
bevt_114_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevt_115_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 331 */
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 333 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
bevt_116_tmpany_phold = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_tmpany_phold.bevi_bool) /* Line: 335 */ {
bevt_119_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_30;
bevt_120_tmpany_phold = bevp_line.bem_toString_0();
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bem_add_1(bevt_120_tmpany_phold);
bevt_117_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 336 */
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_121_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_tmpany_phold);
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 340 */
} /* Line: 319 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
if (bevl_myEndElement == null) {
bevt_122_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
if (bevl_myElement == null) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_124_tmpany_phold = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_tmpany_phold.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 343 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 343 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 343 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 343 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
while (true)
 /* Line: 345 */ {
if (bevl_nxt == null) {
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_125_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_127_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_31;
bevt_126_tmpany_phold = bevl_nxt.bem_equals_1(bevt_127_tmpany_phold);
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_128_tmpany_phold = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_tmpany_phold.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 345 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 345 */
 else  /* Line: 345 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 345 */ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(343187118);
} /* Line: 345 */
 else  /* Line: 345 */ {
break;
} /* Line: 345 */
} /* Line: 345 */
if (bevl_nxt == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_131_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_32;
bevt_130_tmpany_phold = bevl_nxt.bem_equals_1(bevt_131_tmpany_phold);
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
 else  /* Line: 346 */ {
bevt_19_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpany_anchor.bevi_bool) /* Line: 346 */ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 346 */
} /* Line: 346 */
} /* Line: 343 */
 else  /* Line: 348 */ {
if (bevl_nxt == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevl_nxt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_37));
} /* Line: 349 */
bevt_136_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_33;
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bem_add_1(bevl_nxt);
bevt_137_tmpany_phold = bece_BEC_2_3_11_XmlTagIterator_bevo_34;
bevt_134_tmpany_phold = bevt_135_tmpany_phold.bem_add_1(bevt_137_tmpany_phold);
bevt_133_tmpany_phold = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_133_tmpany_phold);
} /* Line: 350 */
} /* Line: 199 */
} /* Line: 190 */
return bevl_myTag;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_started.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 357 */
bevt_2_tmpany_phold = bevp_iter.bemd_0(-223255363);
return (BEC_2_5_4_LogicBool) bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_xmlStringGet_0() {
return bevp_xmlString;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startedGet_0() {
return bevp_started;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_3_10_XmlXTokenizer bem_xtGet_0() {
return bevp_xt;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_resGet_0() {
return bevp_res;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_textNodeGet_0() {
return bevp_textNode;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineGet_0() {
return bevp_line;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipGet_0() {
return bevp_skip;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {138, 139, 140, 141, 142, 143, 144, 145, 150, 151, 155, 159, 163, 163, 164, 165, 167, 168, 168, 168, 168, 0, 0, 0, 169, 171, 171, 171, 171, 0, 0, 0, 172, 177, 177, 178, 181, 181, 182, 182, 184, 185, 187, 189, 190, 190, 0, 0, 0, 191, 191, 192, 193, 195, 196, 197, 197, 197, 198, 198, 199, 199, 200, 201, 202, 203, 204, 205, 206, 206, 208, 0, 209, 209, 0, 0, 210, 211, 212, 212, 214, 216, 216, 217, 218, 218, 218, 218, 0, 0, 0, 219, 221, 222, 222, 222, 225, 225, 226, 227, 228, 228, 228, 228, 228, 228, 228, 0, 0, 0, 229, 230, 233, 234, 234, 234, 234, 0, 0, 0, 235, 237, 237, 238, 239, 239, 239, 242, 243, 243, 0, 243, 0, 0, 244, 244, 245, 247, 247, 248, 249, 250, 251, 252, 252, 253, 253, 254, 255, 256, 257, 258, 258, 260, 260, 261, 262, 264, 264, 264, 0, 0, 0, 264, 264, 0, 0, 0, 264, 264, 0, 0, 0, 265, 266, 268, 268, 269, 271, 272, 273, 273, 275, 276, 276, 277, 279, 279, 280, 282, 284, 284, 0, 0, 0, 285, 286, 286, 287, 289, 291, 296, 297, 297, 0, 297, 0, 0, 298, 298, 299, 301, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 301, 301, 0, 0, 0, 302, 303, 305, 306, 306, 307, 307, 308, 309, 310, 310, 311, 312, 312, 313, 315, 315, 316, 320, 321, 321, 0, 321, 0, 0, 0, 321, 321, 0, 0, 323, 323, 324, 326, 327, 327, 327, 327, 327, 329, 330, 331, 331, 332, 333, 335, 336, 336, 336, 336, 336, 338, 339, 339, 340, 343, 343, 0, 343, 343, 343, 0, 0, 0, 0, 0, 344, 345, 345, 345, 345, 0, 345, 0, 0, 0, 0, 0, 345, 346, 346, 346, 346, 0, 0, 0, 346, 349, 349, 349, 350, 350, 350, 350, 350, 350, 353, 357, 357, 357, 357, 358, 358, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {97, 98, 99, 100, 101, 102, 103, 104, 108, 109, 113, 117, 130, 131, 132, 133, 134, 137, 142, 143, 144, 146, 149, 153, 156, 162, 167, 168, 169, 171, 174, 178, 181, 338, 343, 344, 346, 347, 348, 349, 351, 352, 355, 357, 358, 363, 365, 368, 372, 377, 378, 380, 381, 387, 388, 389, 390, 391, 394, 399, 400, 401, 403, 404, 405, 406, 407, 408, 411, 412, 415, 419, 422, 423, 425, 428, 432, 433, 435, 440, 441, 447, 448, 449, 452, 457, 458, 459, 461, 464, 468, 471, 477, 478, 479, 480, 485, 486, 488, 489, 490, 491, 493, 494, 495, 496, 501, 502, 505, 509, 512, 513, 520, 523, 528, 529, 530, 532, 535, 539, 542, 548, 549, 550, 551, 552, 553, 556, 559, 560, 562, 565, 567, 570, 574, 576, 578, 584, 585, 587, 588, 589, 590, 591, 592, 595, 596, 598, 599, 600, 601, 602, 603, 606, 607, 609, 610, 614, 615, 617, 619, 622, 626, 629, 630, 632, 635, 639, 642, 643, 645, 648, 652, 655, 656, 662, 664, 666, 668, 669, 670, 671, 674, 675, 676, 677, 679, 680, 682, 684, 688, 689, 692, 695, 699, 702, 703, 704, 705, 709, 712, 720, 723, 724, 726, 729, 731, 734, 738, 740, 742, 750, 751, 753, 755, 758, 762, 765, 766, 768, 771, 775, 778, 779, 781, 784, 788, 791, 792, 794, 797, 801, 804, 805, 811, 812, 814, 816, 817, 819, 820, 823, 824, 826, 827, 828, 829, 832, 833, 834, 839, 842, 843, 845, 848, 850, 853, 857, 860, 861, 863, 866, 870, 872, 874, 880, 882, 883, 884, 885, 886, 888, 891, 893, 895, 897, 898, 904, 906, 907, 908, 909, 910, 912, 913, 914, 915, 922, 927, 928, 931, 936, 937, 939, 942, 946, 949, 952, 956, 959, 964, 965, 966, 968, 971, 973, 976, 980, 983, 987, 990, 996, 1001, 1002, 1003, 1005, 1008, 1012, 1015, 1020, 1025, 1026, 1028, 1029, 1030, 1031, 1032, 1033, 1037, 1043, 1048, 1049, 1050, 1052, 1053, 1056, 1059, 1063, 1066, 1070, 1073, 1077, 1080, 1084, 1087, 1091, 1094, 1098, 1101, 1105, 1108, 1112, 1115};
/* BEGIN LINEINFO 
assign 1 138 97
new 0 138 97
assign 1 139 98
new 0 139 98
assign 1 140 99
assign 1 141 100
assign 1 142 101
new 0 142 101
assign 1 143 102
new 0 143 102
assign 1 144 103
new 0 144 103
assign 1 145 104
new 0 145 104
new 0 150 108
assign 1 151 109
new 0 155 113
return 1 159 117
assign 1 163 130
tokGet 0 163 130
assign 1 163 131
tokenize 1 163 131
assign 1 164 132
iteratorGet 0 164 132
assign 1 165 133
new 0 165 133
assign 1 167 134
nextGet 0 167 134
assign 1 168 137
def 1 168 142
assign 1 168 143
new 0 168 143
assign 1 168 144
notEquals 1 168 144
assign 1 0 146
assign 1 0 149
assign 1 0 153
assign 1 169 156
nextGet 0 169 156
assign 1 171 162
def 1 171 167
assign 1 171 168
new 0 171 168
assign 1 171 169
equals 1 171 169
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 172 181
new 0 172 181
assign 1 177 338
not 0 177 343
start 0 178 344
assign 1 181 346
new 0 181 346
assign 1 181 347
quoteGet 0 181 347
assign 1 182 348
new 0 182 348
assign 1 182 349
newlineGet 0 182 349
assign 1 184 351
currentGet 0 184 351
assign 1 185 352
new 0 185 352
assign 1 187 355
nextGet 0 187 355
assign 1 189 357
new 0 189 357
assign 1 190 358
def 1 190 363
assign 1 0 365
assign 1 0 368
assign 1 0 372
assign 1 191 377
new 0 191 377
assign 1 191 378
notEquals 1 191 378
addValue 1 192 380
assign 1 193 381
nextGet 0 193 381
assign 1 195 387
new 0 195 387
assign 1 196 388
new 0 196 388
assign 1 197 389
extractString 0 197 389
assign 1 197 390
new 1 197 390
return 1 197 391
assign 1 198 394
def 1 198 399
assign 1 199 400
new 0 199 400
assign 1 199 401
equals 1 199 401
assign 1 200 403
new 0 200 403
assign 1 201 404
new 0 201 404
assign 1 202 405
new 0 202 405
assign 1 203 406
new 0 203 406
assign 1 204 407
new 0 204 407
assign 1 205 408
new 0 205 408
assign 1 206 411
new 0 206 411
assign 1 206 412
notEquals 1 206 412
assign 1 208 415
new 0 208 415
assign 1 0 419
assign 1 209 422
new 0 209 422
assign 1 209 423
notEquals 1 209 423
assign 1 0 425
assign 1 0 428
addValue 1 210 432
assign 1 211 433
equals 1 211 433
assign 1 212 435
not 0 212 440
assign 1 214 441
nextGet 0 214 441
assign 1 216 447
new 0 216 447
addValue 1 216 448
assign 1 217 449
new 0 217 449
assign 1 218 452
def 1 218 457
assign 1 218 458
new 0 218 458
assign 1 218 459
notEquals 1 218 459
assign 1 0 461
assign 1 0 464
assign 1 0 468
assign 1 219 471
nextGet 0 219 471
assign 1 221 477
new 0 221 477
assign 1 222 478
toString 0 222 478
assign 1 222 479
new 1 222 479
return 1 222 480
assign 1 225 485
new 0 225 485
assign 1 225 486
notEquals 1 225 486
addValue 1 226 488
assign 1 227 489
nextGet 0 227 489
assign 1 228 490
new 0 228 490
assign 1 228 491
equals 1 228 491
assign 1 228 493
toString 0 228 493
assign 1 228 494
new 0 228 494
assign 1 228 495
ends 1 228 495
assign 1 228 496
not 0 228 501
assign 1 0 502
assign 1 0 505
assign 1 0 509
addValue 1 229 512
assign 1 230 513
nextGet 0 230 513
assign 1 233 520
new 0 233 520
assign 1 234 523
def 1 234 528
assign 1 234 529
new 0 234 529
assign 1 234 530
notEquals 1 234 530
assign 1 0 532
assign 1 0 535
assign 1 0 539
assign 1 235 542
nextGet 0 235 542
assign 1 237 548
new 0 237 548
addValue 1 237 549
assign 1 238 550
new 0 238 550
assign 1 239 551
extractString 0 239 551
assign 1 239 552
new 1 239 552
return 1 239 553
assign 1 242 556
nextGet 0 242 556
assign 1 243 559
new 0 243 559
assign 1 243 560
equals 1 243 560
assign 1 0 562
assign 1 243 565
equals 1 243 565
assign 1 0 567
assign 1 0 570
assign 1 244 574
equals 1 244 574
assign 1 244 576
increment 0 244 576
assign 1 245 578
nextGet 0 245 578
assign 1 247 584
new 0 247 584
assign 1 247 585
equals 1 247 585
assign 1 248 587
new 0 248 587
assign 1 249 588
new 0 249 588
assign 1 250 589
nextGet 0 250 589
extractString 0 251 590
assign 1 252 591
new 0 252 591
addValue 1 252 592
assign 1 253 595
new 0 253 595
assign 1 253 596
equals 1 253 596
assign 1 254 598
new 0 254 598
assign 1 255 599
new 0 255 599
assign 1 256 600
nextGet 0 256 600
extractString 0 257 601
assign 1 258 602
new 0 258 602
addValue 1 258 603
assign 1 260 606
new 0 260 606
assign 1 260 607
equals 1 260 607
assign 1 261 609
new 0 261 609
assign 1 262 610
nextGet 0 262 610
assign 1 264 614
new 0 264 614
assign 1 264 615
notEquals 1 264 615
assign 1 264 617
notEquals 1 264 617
assign 1 0 619
assign 1 0 622
assign 1 0 626
assign 1 264 629
new 0 264 629
assign 1 264 630
notEquals 1 264 630
assign 1 0 632
assign 1 0 635
assign 1 0 639
assign 1 264 642
new 0 264 642
assign 1 264 643
notEquals 1 264 643
assign 1 0 645
assign 1 0 648
assign 1 0 652
addValue 1 265 655
assign 1 266 656
nextGet 0 266 656
assign 1 268 662
equals 1 268 662
assign 1 268 664
increment 0 268 664
assign 1 269 666
new 0 269 666
assign 1 271 668
new 0 271 668
assign 1 272 669
assign 1 273 670
extractString 0 273 670
nameSet 1 273 671
assign 1 275 674
new 0 275 674
assign 1 276 675
extractString 0 276 675
nameSet 1 276 676
assign 1 277 677
assign 1 279 679
new 0 279 679
assign 1 279 680
equals 1 279 680
assign 1 280 682
new 0 280 682
assign 1 282 684
new 0 282 684
assign 1 284 688
new 0 284 688
assign 1 284 689
equals 1 284 689
assign 1 0 692
assign 1 0 695
assign 1 0 699
assign 1 285 702
new 0 285 702
assign 1 286 703
new 0 286 703
isClosedSet 1 286 704
assign 1 287 705
nextGet 0 287 705
assign 1 289 709
new 0 289 709
assign 1 291 712
new 0 291 712
assign 1 296 720
nextGet 0 296 720
assign 1 297 723
new 0 297 723
assign 1 297 724
equals 1 297 724
assign 1 0 726
assign 1 297 729
equals 1 297 729
assign 1 0 731
assign 1 0 734
assign 1 298 738
equals 1 298 738
assign 1 298 740
increment 0 298 740
assign 1 299 742
nextGet 0 299 742
assign 1 301 750
new 0 301 750
assign 1 301 751
notEquals 1 301 751
assign 1 301 753
notEquals 1 301 753
assign 1 0 755
assign 1 0 758
assign 1 0 762
assign 1 301 765
new 0 301 765
assign 1 301 766
notEquals 1 301 766
assign 1 0 768
assign 1 0 771
assign 1 0 775
assign 1 301 778
new 0 301 778
assign 1 301 779
notEquals 1 301 779
assign 1 0 781
assign 1 0 784
assign 1 0 788
assign 1 301 791
new 0 301 791
assign 1 301 792
notEquals 1 301 792
assign 1 0 794
assign 1 0 797
assign 1 0 801
addValue 1 302 804
assign 1 303 805
nextGet 0 303 805
assign 1 305 811
new 0 305 811
assign 1 306 812
equals 1 306 812
assign 1 306 814
increment 0 306 814
assign 1 307 816
new 0 307 816
assign 1 307 817
equals 1 307 817
assign 1 308 819
new 0 308 819
assign 1 309 820
new 0 309 820
assign 1 310 823
new 0 310 823
assign 1 310 824
equals 1 310 824
assign 1 311 826
new 0 311 826
assign 1 312 827
new 0 312 827
isClosedSet 1 312 828
assign 1 313 829
nextGet 0 313 829
assign 1 315 832
extractString 0 315 832
addAttributeName 1 315 833
assign 1 316 834
new 0 316 834
assign 1 320 839
nextGet 0 320 839
assign 1 321 842
new 0 321 842
assign 1 321 843
equals 1 321 843
assign 1 0 845
assign 1 321 848
equals 1 321 848
assign 1 0 850
assign 1 0 853
assign 1 0 857
assign 1 321 860
new 0 321 860
assign 1 321 861
equals 1 321 861
assign 1 0 863
assign 1 0 866
assign 1 323 870
equals 1 323 870
assign 1 323 872
increment 0 323 872
assign 1 324 874
nextGet 0 324 874
assign 1 326 880
notEquals 1 326 880
assign 1 327 882
new 0 327 882
assign 1 327 883
toString 0 327 883
assign 1 327 884
add 1 327 884
assign 1 327 885
new 1 327 885
throw 1 327 886
assign 1 329 888
nextGet 0 329 888
assign 1 330 891
notEquals 1 330 891
assign 1 331 893
equals 1 331 893
assign 1 331 895
increment 0 331 895
addValue 1 332 897
assign 1 333 898
nextGet 0 333 898
assign 1 335 904
notEquals 1 335 904
assign 1 336 906
new 0 336 906
assign 1 336 907
toString 0 336 907
assign 1 336 908
add 1 336 908
assign 1 336 909
new 1 336 909
throw 1 336 910
assign 1 338 912
new 0 338 912
assign 1 339 913
extractString 0 339 913
addAttributeValue 1 339 914
assign 1 340 915
new 0 340 915
assign 1 343 922
def 1 343 927
assign 1 0 928
assign 1 343 931
def 1 343 936
assign 1 343 937
isClosedGet 0 343 937
assign 1 0 939
assign 1 0 942
assign 1 0 946
assign 1 0 949
assign 1 0 952
assign 1 344 956
nextGet 0 344 956
assign 1 345 959
def 1 345 964
assign 1 345 965
new 0 345 965
assign 1 345 966
equals 1 345 966
assign 1 0 968
assign 1 345 971
equals 1 345 971
assign 1 0 973
assign 1 0 976
assign 1 0 980
assign 1 0 983
assign 1 0 987
assign 1 345 990
nextGet 0 345 990
assign 1 346 996
def 1 346 1001
assign 1 346 1002
new 0 346 1002
assign 1 346 1003
equals 1 346 1003
assign 1 0 1005
assign 1 0 1008
assign 1 0 1012
assign 1 346 1015
new 0 346 1015
assign 1 349 1020
undef 1 349 1025
assign 1 349 1026
new 0 349 1026
assign 1 350 1028
new 0 350 1028
assign 1 350 1029
add 1 350 1029
assign 1 350 1030
new 0 350 1030
assign 1 350 1031
add 1 350 1031
assign 1 350 1032
new 1 350 1032
throw 1 350 1033
return 1 353 1037
assign 1 357 1043
not 0 357 1048
assign 1 357 1049
new 0 357 1049
return 1 357 1050
assign 1 358 1052
hasNextGet 0 358 1052
return 1 358 1053
return 1 0 1056
assign 1 0 1059
return 1 0 1063
assign 1 0 1066
return 1 0 1070
assign 1 0 1073
return 1 0 1077
assign 1 0 1080
return 1 0 1084
assign 1 0 1087
return 1 0 1091
assign 1 0 1094
return 1 0 1098
assign 1 0 1101
return 1 0 1105
assign 1 0 1108
return 1 0 1112
assign 1 0 1115
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 607172645: return bem_toString_0();
case -363466581: return bem_iteratorGet_0();
case -493653728: return bem_restart_0();
case 1874352577: return bem_many_0();
case 1718503463: return bem_sourceFileNameGet_0();
case -431207580: return bem_lineGet_0();
case 31427635: return bem_serializationIteratorGet_0();
case 538430095: return bem_iterGet_0();
case -334320127: return bem_startedGet_0();
case 1423232549: return bem_debugGet_0();
case 277726065: return bem_new_0();
case -1768554896: return bem_hashGet_0();
case 569838822: return bem_xtGet_0();
case -1384853896: return bem_serializeContents_0();
case 224797497: return bem_xmlStringGet_0();
case -223255363: return bem_hasNextGet_0();
case -1869194774: return bem_toAny_0();
case 2094126469: return bem_serializeToString_0();
case 823263979: return bem_tagGet_0();
case 321935489: return bem_resGet_0();
case -788077321: return bem_classNameGet_0();
case -649794280: return bem_echo_0();
case 605551831: return bem_create_0();
case 371550396: return bem_start_0();
case 994125870: return bem_fieldIteratorGet_0();
case -149038646: return bem_textNodeGet_0();
case -1988056437: return bem_skipGet_0();
case 2008488187: return bem_deserializeClassNameGet_0();
case -1000431791: return bem_copy_0();
case -1961384722: return bem_once_0();
case -618905808: return bem_print_0();
case 343187118: return bem_nextGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2111682385: return bem_undef_1(bevd_0);
case 831887130: return bem_equals_1(bevd_0);
case -552291791: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1877145477: return bem_textNodeSet_1(bevd_0);
case 412211091: return bem_lineSet_1(bevd_0);
case 1242105458: return bem_def_1(bevd_0);
case 1887876059: return bem_undefined_1(bevd_0);
case 1472823942: return bem_skipSet_1(bevd_0);
case 1539287118: return bem_iterSet_1(bevd_0);
case 277308251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 197535869: return bem_otherType_1(bevd_0);
case -547433207: return bem_copyTo_1(bevd_0);
case -2027172866: return bem_sameClass_1(bevd_0);
case 1220223304: return bem_otherClass_1(bevd_0);
case 11747238: return bem_defined_1(bevd_0);
case 411925173: return bem_sameType_1(bevd_0);
case -108174775: return bem_xmlStringSet_1(bevd_0);
case 369373882: return bem_startedSet_1(bevd_0);
case 1112246860: return bem_notEquals_1(bevd_0);
case 1144205149: return bem_resSet_1(bevd_0);
case -1263127801: return bem_sameObject_1(bevd_0);
case 926344794: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1134064849: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1075723242: return bem_xtSet_1(bevd_0);
case -1138390854: return bem_debugSet_1(bevd_0);
case -605365957: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -129206367: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1992907065: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1805532369: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1779420493: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1717448787: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1586496733: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1946581493: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_11_XmlTagIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
}
