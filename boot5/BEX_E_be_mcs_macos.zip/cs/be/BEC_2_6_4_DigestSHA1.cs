namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_DigestSHA1 : BEC_2_6_6_SystemObject {
public BEC_2_6_4_DigestSHA1() { }
static BEC_2_6_4_DigestSHA1() { }

    public SHA1Managed bevi_md; 
   private static byte[] becc_BEC_2_6_4_DigestSHA1_clname = {0x44,0x69,0x67,0x65,0x73,0x74,0x3A,0x53,0x48,0x41,0x31};
private static byte[] becc_BEC_2_6_4_DigestSHA1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
public static new BEC_2_6_4_DigestSHA1 bece_BEC_2_6_4_DigestSHA1_bevs_inst;

public static new BET_2_6_4_DigestSHA1 bece_BEC_2_6_4_DigestSHA1_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {

        bevi_md = new SHA1Managed();
        return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_digest_1(BEC_2_4_6_TextString beva_with) {
BEC_2_4_6_TextString bevl_res = null;
bem_new_0();

        bevl_res = new BEC_2_4_6_TextString(
          bevi_md.ComputeHash(beva_with.bevi_bytes, 0, beva_with.bevp_size.bevi_int)
        );
        return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_digestToHex_1(BEC_2_4_6_TextString beva_input) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_3_EncodeHex bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevt_2_tmpany_phold = bem_digest_1(beva_input);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_encode_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {149, 164, 168, 168, 168, 168};
public static new int[] bevs_smnlec
 = new int[] {23, 28, 34, 35, 36, 37};
/* BEGIN LINEINFO 
new 0 149 23
return 1 164 28
assign 1 168 34
new 0 168 34
assign 1 168 35
digest 1 168 35
assign 1 168 36
encode 1 168 36
return 1 168 37
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 341148236: return bem_once_0();
case -41276197: return bem_create_0();
case -139353918: return bem_toAny_0();
case -1797964019: return bem_classNameGet_0();
case 2121617532: return bem_hashGet_0();
case -2027679173: return bem_deserializeClassNameGet_0();
case 1310168666: return bem_copy_0();
case -865211167: return bem_many_0();
case 734060929: return bem_serializationIteratorGet_0();
case -2058654018: return bem_toString_0();
case 148319359: return bem_new_0();
case -1456235115: return bem_echo_0();
case -320545548: return bem_sourceFileNameGet_0();
case -740937572: return bem_print_0();
case 903178719: return bem_fieldNamesGet_0();
case 1147856721: return bem_fieldIteratorGet_0();
case -1943120126: return bem_serializeToString_0();
case 1990625095: return bem_tagGet_0();
case 332613786: return bem_serializeContents_0();
case -256176855: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2070971991: return bem_def_1(bevd_0);
case -685523033: return bem_digest_1((BEC_2_4_6_TextString) bevd_0);
case 306277101: return bem_undefined_1(bevd_0);
case -116587458: return bem_sameType_1(bevd_0);
case 1985783592: return bem_otherType_1(bevd_0);
case -264091635: return bem_copyTo_1(bevd_0);
case 1865504944: return bem_sameClass_1(bevd_0);
case 1067671270: return bem_digestToHex_1((BEC_2_4_6_TextString) bevd_0);
case -245605778: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 635105057: return bem_defined_1(bevd_0);
case 825055568: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1350346500: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1679251333: return bem_undef_1(bevd_0);
case 55946271: return bem_notEquals_1(bevd_0);
case 649776492: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2023862139: return bem_equals_1(bevd_0);
case -1829045189: return bem_otherClass_1(bevd_0);
case 906711890: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 710095661: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1286703705: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 704289821: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1372536257: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1105189015: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1798728092: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -275173380: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_DigestSHA1_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_DigestSHA1_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_4_DigestSHA1();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_inst = (BEC_2_6_4_DigestSHA1) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_type;
}
}
}
