namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps : BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerMaps() { }
static BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerMaps_bevo_0 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;

public static new BET_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_type;

public virtual BEC_2_9_4_ContainerMaps bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_ls = beva_list.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerMaps_bevo_0;
bevt_0_tmpany_phold = bevl_ls.bem_add_1(bevt_1_tmpany_phold);
bevl_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 725 */ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 725 */ {
bevt_3_tmpany_phold = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_5_tmpany_phold = bevl_i;
bevt_4_tmpany_phold = beva_list.bem_get_1(bevt_5_tmpany_phold);
bevl_map.bem_put_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 725 */
 else  /* Line: 725 */ {
break;
} /* Line: 725 */
} /* Line: 725 */
return bevl_map;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-2055997260);
while (true)
 /* Line: 732 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 732 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(419860767);
bevt_2_tmpany_phold = bevl_i.bemd_0(-452211145);
beva_res.bem_put_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 733 */
 else  /* Line: 732 */ {
break;
} /* Line: 732 */
} /* Line: 732 */
return beva_res;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(-2055997260);
while (true)
 /* Line: 739 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(-346732097);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 739 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(419860767);
bevt_1_tmpany_phold = beva_from.bem_get_1(bevt_2_tmpany_phold);
bevl_i.bemd_1(-23725889, bevt_1_tmpany_phold);
} /* Line: 740 */
 else  /* Line: 739 */ {
break;
} /* Line: 739 */
} /* Line: 739 */
return beva_inst;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {723, 724, 724, 724, 725, 725, 725, 726, 726, 726, 726, 725, 728, 732, 732, 733, 733, 733, 735, 739, 739, 740, 740, 740, 742};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 29, 30, 33, 38, 39, 40, 42, 43, 44, 50, 57, 60, 62, 63, 64, 70, 77, 80, 82, 83, 84, 90};
/* BEGIN LINEINFO 
assign 1 723 26
sizeGet 0 723 26
assign 1 724 27
new 0 724 27
assign 1 724 28
add 1 724 28
assign 1 724 29
new 1 724 29
assign 1 725 30
new 0 725 30
assign 1 725 33
lesser 1 725 38
assign 1 726 39
get 1 726 39
assign 1 726 40
incrementValue 0 726 40
assign 1 726 42
get 1 726 42
put 2 726 43
incrementValue 0 725 44
return 1 728 50
assign 1 732 57
fieldIteratorGet 0 732 57
assign 1 732 60
hasNextGet 0 732 60
assign 1 733 62
nextNameGet 0 733 62
assign 1 733 63
currentGet 0 733 63
put 2 733 64
return 1 735 70
assign 1 739 77
fieldIteratorGet 0 739 77
assign 1 739 80
hasNextGet 0 739 80
assign 1 740 82
nextNameGet 0 740 82
assign 1 740 83
get 1 740 83
currentSet 1 740 84
return 1 742 90
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1852877275: return bem_new_0();
case -1153070277: return bem_deserializeClassNameGet_0();
case -20123619: return bem_serializationIteratorGet_0();
case -236887613: return bem_classNameGet_0();
case 1076647192: return bem_create_0();
case -2092760709: return bem_once_0();
case 1359360249: return bem_echo_0();
case 1064677251: return bem_many_0();
case 605836827: return bem_sourceFileNameGet_0();
case -2055997260: return bem_fieldIteratorGet_0();
case 928457034: return bem_serializeContents_0();
case -1430066973: return bem_print_0();
case -323661464: return bem_serializeToString_0();
case 849387251: return bem_toAny_0();
case 1910979786: return bem_default_0();
case 1372644764: return bem_hashGet_0();
case -842207018: return bem_iteratorGet_0();
case 996718380: return bem_toString_0();
case -1369483363: return bem_fieldNamesGet_0();
case 864393987: return bem_tagGet_0();
case 2070502838: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -960159496: return bem_otherClass_1(bevd_0);
case 975852941: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1527425699: return bem_def_1(bevd_0);
case 2127127546: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 34689954: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case 1570647300: return bem_equals_1(bevd_0);
case 155960598: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1527507332: return bem_undefined_1(bevd_0);
case 1119806757: return bem_undef_1(bevd_0);
case -458239489: return bem_notEquals_1(bevd_0);
case 1953764074: return bem_copyTo_1(bevd_0);
case 123527324: return bem_defined_1(bevd_0);
case -971345338: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1583465687: return bem_otherType_1(bevd_0);
case -2138027432: return bem_sameType_1(bevd_0);
case -1519518153: return bem_sameObject_1(bevd_0);
case 1803565113: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1513693181: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case 69135057: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1399866369: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -141522845: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -384689933: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1840814788: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
case -1840833746: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -721430417: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1122057919: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerMaps();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_type;
}
}
}
