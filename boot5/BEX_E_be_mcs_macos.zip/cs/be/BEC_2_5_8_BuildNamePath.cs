namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_8_BuildNamePath : BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
static BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
public static new BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static new BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_ta_ph.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
if (bevp_label == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 19*/ {
bevt_2_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_1_ta_ph = bevt_2_ta_ph.bem_lastGet_0();
return bevt_1_ta_ph;
} /* Line: 20*/
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_0));
bevt_1_ta_ph = bevl_oldpath.bem_equals_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 28*/ {
return this;
} /* Line: 28*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_8_BuildNamePath_bels_1));
bevt_3_ta_ph = bevl_oldpath.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 29*/ {
return this;
} /* Line: 29*/
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(-973183885);
bevt_6_ta_ph = bevl_tunode.bem_heldGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(265021532);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_ta_ph.bemd_1(-609621197, bevl_fstep);
if (bevl_par == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 33*/ {
bevt_10_ta_ph = beva_node.bemd_0(1145690698);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-1671980253);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(265021532);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_ta_ph.bemd_1(-609621197, bevl_fstep);
} /* Line: 34*/
if (bevl_par == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_14_ta_ph = bem_pathGet_0();
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_8_BuildNamePath_bels_2));
bevt_13_ta_ph = bevt_14_ta_ph.bem_has_1(bevt_15_ta_ph);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 36*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 36*/ {
bevl_np2 = (BEC_2_6_8_SystemBasePath) bem_deleteFirstStep_0();
bevl_np = (BEC_2_6_8_SystemBasePath) bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 39*/
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(1520072392);
if (bevl_clnode == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_17_ta_ph = bevl_clnode.bem_heldGet_0();
bevt_17_ta_ph.bemd_1(389525285, this);
} /* Line: 43*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_labelGetDirect_0() {
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {14, 14, 15, 19, 19, 20, 20, 20, 23, 27, 28, 28, 28, 29, 29, 29, 30, 31, 32, 32, 32, 33, 33, 34, 34, 34, 34, 36, 36, 36, 36, 36, 36, 36, 0, 0, 0, 37, 38, 39, 41, 42, 42, 43, 43, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 20, 27, 32, 33, 34, 35, 37, 65, 66, 67, 69, 71, 72, 74, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 92, 97, 98, 99, 100, 101, 106, 107, 110, 114, 117, 118, 119, 121, 122, 127, 128, 129, 134, 137, 141};
/* BEGIN LINEINFO 
assign 1 14 18
new 0 14 18
assign 1 14 19
colonGet 0 14 19
fromString 1 15 20
assign 1 19 27
undef 1 19 32
assign 1 20 33
split 1 20 33
assign 1 20 34
lastGet 0 20 34
return 1 20 35
return 1 23 37
assign 1 27 65
pathGet 0 27 65
assign 1 28 66
new 0 28 66
assign 1 28 67
equals 1 28 67
return 1 28 69
assign 1 29 71
new 0 29 71
assign 1 29 72
equals 1 29 72
return 1 29 74
assign 1 30 76
firstStepGet 0 30 76
assign 1 31 77
transUnitGet 0 31 77
assign 1 32 78
heldGet 0 32 78
assign 1 32 79
aliasedGet 0 32 79
assign 1 32 80
get 1 32 80
assign 1 33 81
undef 1 33 86
assign 1 34 87
buildGet 0 34 87
assign 1 34 88
emitDataGet 0 34 88
assign 1 34 89
aliasedGet 0 34 89
assign 1 34 90
get 1 34 90
assign 1 36 92
def 1 36 97
assign 1 36 98
pathGet 0 36 98
assign 1 36 99
new 0 36 99
assign 1 36 100
has 1 36 100
assign 1 36 101
not 0 36 106
assign 1 0 107
assign 1 0 110
assign 1 0 114
assign 1 37 117
deleteFirstStep 0 37 117
assign 1 38 118
add 1 38 118
assign 1 39 119
pathGet 0 39 119
assign 1 41 121
classGet 0 41 121
assign 1 42 122
def 1 42 127
assign 1 43 128
heldGet 0 43 128
addUsed 1 43 129
return 1 0 134
assign 1 0 137
assign 1 0 141
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1029695809: return bem_echo_0();
case -824858519: return bem_lastStepGet_0();
case 1196360961: return bem_makeNonAbsolute_0();
case -1844917728: return bem_many_0();
case -1041663719: return bem_pathGet_0();
case 2006790444: return bem_firstStepGet_0();
case 259850418: return bem_pathGetDirect_0();
case -1848718184: return bem_hashGet_0();
case 170729636: return bem_separatorGetDirect_0();
case -1902089216: return bem_toString_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -1602364653: return bem_parentGet_0();
case 217968364: return bem_classNameGet_0();
case 271090330: return bem_labelGet_0();
case -8643043: return bem_serializeContents_0();
case 2038193605: return bem_fieldNamesGet_0();
case -479166709: return bem_tagGet_0();
case -1289831900: return bem_deleteFirstStep_0();
case -1026733174: return bem_new_0();
case -785258946: return bem_create_0();
case -484005056: return bem_isAbsoluteGet_0();
case -1544996320: return bem_separatorGet_0();
case 1688687204: return bem_serializeToString_0();
case -112556155: return bem_stepsGet_0();
case 1428206002: return bem_stepListGet_0();
case 126670515: return bem_toAny_0();
case 1137009070: return bem_once_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 1562608535: return bem_print_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case 102554564: return bem_fieldIteratorGet_0();
case 185174991: return bem_copy_0();
case -31114048: return bem_iteratorGet_0();
case -526543693: return bem_makeAbsolute_0();
case -1305203808: return bem_labelGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1811318132: return bem_defined_1(bevd_0);
case 190608648: return bem_addStep_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -1879276718: return bem_addSteps_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -1327395216: return bem_separatorSet_1(bevd_0);
case -2114747645: return bem_resolve_1(bevd_0);
case 415371943: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case 1140836940: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 256255984: return bem_separatorSetDirect_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 2040222554: return bem_labelSet_1(bevd_0);
case -809005808: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 1967947616: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 926458045: return bem_add_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 389177729: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 530639018: return bem_pathSet_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case -21713989: return bem_pathSetDirect_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1566401860: return bem_labelSetDirect_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1597556842: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -2078275004: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2111854957: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 851967397: return bem_addSteps_2(bevd_0, bevd_1);
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildNamePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
}
