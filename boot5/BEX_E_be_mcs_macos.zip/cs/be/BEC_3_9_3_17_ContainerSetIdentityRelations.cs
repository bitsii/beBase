namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_17_ContainerSetIdentityRelations : BEC_3_9_3_9_ContainerSetRelations {
public BEC_3_9_3_17_ContainerSetIdentityRelations() { }
static BEC_3_9_3_17_ContainerSetIdentityRelations() { }
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
public override BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_0(-85596330);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_1(-1825570190, beva_l);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {79, 79, 83, 83};
public static new int[] bevs_smnlec
 = new int[] {11, 12, 16, 17};
/* BEGIN LINEINFO 
assign 1 79 11
tagGet 0 79 11
return 1 79 12
assign 1 83 16
sameObject 1 83 16
return 1 83 17
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case -2066691170: return bem_hashGet_0();
case 876844323: return bem_serializationIteratorGet_0();
case 332749494: return bem_many_0();
case 913636711: return bem_toAny_0();
case -853067962: return bem_serializeContents_0();
case -945812364: return bem_once_0();
case -904557663: return bem_print_0();
case -1427622449: return bem_create_0();
case 1398390067: return bem_classNameGet_0();
case -1414488789: return bem_copy_0();
case 1796230342: return bem_toString_0();
case 905853766: return bem_default_0();
case -1059501870: return bem_fieldIteratorGet_0();
case -551829583: return bem_echo_0();
case 509465600: return bem_iteratorGet_0();
case 627584199: return bem_new_0();
case 1395453592: return bem_serializeToString_0();
case 1965225689: return bem_sourceFileNameGet_0();
case -85596330: return bem_tagGet_0();
case -1254976075: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case -2064416533: return bem_copyTo_1(bevd_0);
case 632969730: return bem_otherType_1(bevd_0);
case -375396806: return bem_sameType_1(bevd_0);
case -282488764: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1650785007: return bem_undefined_1(bevd_0);
case -1410322621: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1789153529: return bem_equals_1(bevd_0);
case 2142029115: return bem_undef_1(bevd_0);
case 414867900: return bem_otherClass_1(bevd_0);
case 1081898105: return bem_def_1(bevd_0);
case 251217946: return bem_defined_1(bevd_0);
case -2038649804: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1121775076: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1213922529: return bem_notEquals_1(bevd_0);
case -1825570190: return bem_sameObject_1(bevd_0);
case -1398432640: return bem_sameClass_1(bevd_0);
case 308562284: return bem_getHash_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1896530483: return bem_isEqual_2(bevd_0, bevd_1);
case 75445916: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1518297580: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1467397408: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -113794903: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1606481035: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1716376212: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1418573133: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(31, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_17_ContainerSetIdentityRelations();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst = (BEC_3_9_3_17_ContainerSetIdentityRelations) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
}
}
}
