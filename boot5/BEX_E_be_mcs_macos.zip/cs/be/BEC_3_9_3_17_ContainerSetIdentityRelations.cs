namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_17_ContainerSetIdentityRelations : BEC_3_9_3_9_ContainerSetRelations {
public BEC_3_9_3_17_ContainerSetIdentityRelations() { }
static BEC_3_9_3_17_ContainerSetIdentityRelations() { }
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;

public static new BET_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;

public override BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_0(-479359240);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_1(-1416339029, beva_l);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {79, 79, 83, 83};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20};
/* BEGIN LINEINFO 
assign 1 79 14
tagGet 0 79 14
return 1 79 15
assign 1 83 19
sameObject 1 83 19
return 1 83 20
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1453318633: return bem_new_0();
case -1596775328: return bem_serializeToString_0();
case 1552820506: return bem_classNameGet_0();
case -688862469: return bem_toString_0();
case 2066844567: return bem_fieldNamesGet_0();
case 770044727: return bem_deserializeClassNameGet_0();
case 965815191: return bem_echo_0();
case 617667581: return bem_toAny_0();
case -2015039528: return bem_iteratorGet_0();
case 940651019: return bem_once_0();
case -1578327045: return bem_serializeContents_0();
case 1167480829: return bem_copy_0();
case -296688753: return bem_print_0();
case -1400364749: return bem_serializationIteratorGet_0();
case -1039531132: return bem_create_0();
case 993863115: return bem_fieldIteratorGet_0();
case -479359240: return bem_tagGet_0();
case -835881829: return bem_default_0();
case -639622757: return bem_hashGet_0();
case 1470127612: return bem_sourceFileNameGet_0();
case 105645045: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1489408670: return bem_sameType_1(bevd_0);
case 419445436: return bem_copyTo_1(bevd_0);
case -884635357: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1073960196: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1202688048: return bem_def_1(bevd_0);
case 189658019: return bem_defined_1(bevd_0);
case -1365097484: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1197332143: return bem_otherClass_1(bevd_0);
case -1447883638: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 851940283: return bem_getHash_1(bevd_0);
case 1879722769: return bem_sameClass_1(bevd_0);
case -1596168486: return bem_equals_1(bevd_0);
case 323831111: return bem_undef_1(bevd_0);
case -1076480041: return bem_notEquals_1(bevd_0);
case 1503413748: return bem_undefined_1(bevd_0);
case -1416339029: return bem_sameObject_1(bevd_0);
case -1300492421: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 787023569: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1285045766: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -624371870: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 398529607: return bem_isEqual_2(bevd_0, bevd_1);
case 282981748: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1323585037: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2145191247: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -437555976: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(31, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_17_ContainerSetIdentityRelations();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst = (BEC_3_9_3_17_ContainerSetIdentityRelations) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;
}
}
}
