namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(-1028270983);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1219927083, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 385 */ {
bevt_4_tmpany_phold = (BEC_2_6_8_SystemBasePath) bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 386 */
bevt_5_tmpany_phold = beva_other.bemd_0(1242061384);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 388 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(32699518);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 389 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(-1028270983);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(-309293785, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 393 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 393 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 395 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 411 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 411 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 413 */
 else  /* Line: 414 */ {
bevl_i.bem_nextGet_0();
} /* Line: 415 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 417 */
 else  /* Line: 411 */ {
break;
} /* Line: 411 */
} /* Line: 411 */
bevt_4_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 420 */
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 426 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 426 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 426 */
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 427 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 428 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 434 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 435 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 441 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 446 */ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 451 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 451 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 452 */ {
break;
} /* Line: 452 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 451 */
 else  /* Line: 451 */ {
break;
} /* Line: 451 */
} /* Line: 451 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 457 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 470 */
 else  /* Line: 471 */ {
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 472 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 478 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 478 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 479 */
 else  /* Line: 478 */ {
break;
} /* Line: 478 */
} /* Line: 478 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_8_SystemBasePath) bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(-1857123920, this);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 518 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(-1028270983);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 518 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 518 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 518 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 519 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 530 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 531 */
 else  /* Line: 532 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 533 */
bevl_res = bem_create_0();
bevl_res.bemd_1(680024470, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-391255342, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {346, 346, 350, 351, 355, 359, 363, 363, 367, 368, 368, 369, 373, 373, 377, 377, 377, 381, 381, 381, 385, 385, 385, 385, 386, 386, 388, 389, 389, 391, 392, 392, 393, 393, 394, 395, 397, 397, 398, 399, 401, 405, 406, 407, 407, 408, 409, 410, 411, 411, 412, 412, 413, 413, 415, 417, 419, 420, 422, 426, 426, 0, 426, 426, 426, 426, 426, 0, 0, 426, 426, 427, 427, 427, 428, 428, 430, 430, 434, 435, 435, 435, 440, 440, 440, 441, 446, 446, 446, 447, 448, 450, 451, 451, 451, 452, 452, 453, 454, 455, 451, 457, 462, 463, 464, 468, 469, 469, 470, 470, 472, 472, 472, 472, 477, 478, 478, 479, 479, 481, 485, 485, 489, 490, 491, 492, 496, 497, 498, 498, 499, 503, 503, 507, 507, 511, 511, 511, 518, 518, 0, 518, 0, 0, 0, 518, 518, 0, 0, 519, 519, 521, 521, 525, 525, 529, 530, 530, 531, 533, 535, 536, 537, 537, 537, 538, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 29, 30, 34, 38, 42, 43, 49, 50, 51, 52, 56, 57, 62, 63, 64, 69, 70, 71, 90, 91, 92, 93, 95, 96, 98, 100, 101, 103, 104, 105, 106, 109, 111, 112, 118, 119, 120, 121, 122, 135, 136, 137, 138, 139, 140, 141, 142, 145, 147, 152, 153, 154, 157, 159, 165, 167, 169, 184, 189, 190, 193, 194, 195, 196, 201, 202, 205, 209, 210, 212, 213, 214, 216, 217, 219, 220, 226, 228, 229, 230, 237, 238, 243, 244, 257, 258, 263, 264, 265, 266, 267, 270, 275, 276, 281, 284, 285, 286, 287, 293, 299, 300, 301, 311, 312, 317, 318, 319, 322, 323, 324, 325, 334, 335, 338, 340, 341, 347, 352, 353, 357, 358, 359, 360, 366, 367, 368, 369, 370, 374, 375, 379, 380, 385, 386, 391, 402, 407, 408, 411, 413, 416, 420, 423, 424, 426, 429, 433, 434, 436, 437, 441, 442, 451, 452, 457, 458, 461, 463, 464, 465, 466, 467, 468, 471, 474, 478, 481};
/* BEGIN LINEINFO 
assign 1 346 24
new 0 346 24
new 1 346 25
assign 1 350 29
new 0 350 29
fromString 1 351 30
assign 1 355 34
return 1 359 38
assign 1 363 42
toStringWithSeparator 1 363 42
return 1 363 43
assign 1 367 49
split 1 367 49
assign 1 368 50
new 0 368 50
assign 1 368 51
join 2 368 51
return 1 369 52
assign 1 373 56
split 1 373 56
return 1 373 57
assign 1 377 62
split 1 377 62
assign 1 377 63
firstGet 0 377 63
return 1 377 64
assign 1 381 69
split 1 381 69
assign 1 381 70
lastGet 0 381 70
return 1 381 71
assign 1 385 90
pathGet 0 385 90
assign 1 385 91
new 0 385 91
assign 1 385 92
emptyGet 0 385 92
assign 1 385 93
equals 1 385 93
assign 1 386 95
copy 0 386 95
return 1 386 96
assign 1 388 98
isAbsoluteGet 0 388 98
assign 1 389 100
copy 0 389 100
return 1 389 101
assign 1 391 103
split 1 391 103
assign 1 392 104
pathGet 0 392 104
assign 1 392 105
split 1 392 105
assign 1 393 106
linkedListIteratorGet 0 393 106
assign 1 393 109
hasNextGet 0 393 109
assign 1 394 111
nextGet 0 394 111
addValue 1 395 112
assign 1 397 118
new 0 397 118
assign 1 397 119
join 2 397 119
assign 1 398 120
copy 0 398 120
assign 1 399 121
fromString 1 399 121
return 1 401 122
assign 1 405 135
split 1 405 135
assign 1 406 136
copy 0 406 136
assign 1 407 137
new 0 407 137
pathSet 1 407 138
assign 1 408 139
lengthGet 0 408 139
assign 1 409 140
decrement 0 409 140
assign 1 410 141
new 0 410 141
assign 1 411 142
linkedListIteratorGet 0 411 142
assign 1 411 145
hasNextGet 0 411 145
assign 1 412 147
lesser 1 412 152
assign 1 413 153
nextGet 0 413 153
addStep 1 413 154
nextGet 0 415 157
assign 1 417 159
increment 0 417 159
assign 1 419 165
isAbsoluteGet 0 419 165
makeAbsolute 0 420 167
return 1 422 169
assign 1 426 184
undef 1 426 189
assign 1 0 190
assign 1 426 193
toString 0 426 193
assign 1 426 194
sizeGet 0 426 194
assign 1 426 195
new 0 426 195
assign 1 426 196
lesser 1 426 201
assign 1 0 202
assign 1 0 205
assign 1 426 209
new 0 426 209
return 1 426 210
assign 1 427 212
new 0 427 212
assign 1 427 213
getPoint 1 427 213
assign 1 427 214
equals 1 427 214
assign 1 428 216
new 0 428 216
return 1 428 217
assign 1 430 219
new 0 430 219
return 1 430 220
assign 1 434 226
isAbsoluteGet 0 434 226
assign 1 435 228
new 0 435 228
assign 1 435 229
sizeGet 0 435 229
assign 1 435 230
substring 2 435 230
assign 1 440 237
isAbsoluteGet 0 440 237
assign 1 440 238
not 0 440 243
assign 1 441 244
add 1 441 244
assign 1 446 257
new 0 446 257
assign 1 446 258
greater 1 446 263
makeNonAbsolute 0 447 264
assign 1 448 265
split 1 448 265
assign 1 450 266
firstNodeGet 0 450 266
assign 1 451 267
new 0 451 267
assign 1 451 270
lesser 1 451 275
assign 1 452 276
undef 1 452 281
assign 1 453 284
assign 1 454 285
nextGet 0 454 285
delete 0 455 286
assign 1 451 287
increment 0 451 287
assign 1 457 293
join 2 457 293
assign 1 462 299
split 1 462 299
addValue 1 463 300
assign 1 464 301
join 2 464 301
assign 1 468 311
find 1 468 311
assign 1 469 312
undef 1 469 317
assign 1 470 318
new 0 470 318
assign 1 470 319
emptyGet 0 470 319
assign 1 472 322
new 0 472 322
assign 1 472 323
add 1 472 323
assign 1 472 324
sizeGet 0 472 324
assign 1 472 325
substring 2 472 325
assign 1 477 334
split 1 477 334
assign 1 478 335
linkedListIteratorGet 0 478 335
assign 1 478 338
hasNextGet 0 478 338
assign 1 479 340
nextGet 0 479 340
addValue 1 479 341
assign 1 481 347
join 2 481 347
assign 1 485 352
addStep 1 485 352
return 1 485 353
assign 1 489 357
split 1 489 357
addValue 1 490 358
addValue 1 491 359
assign 1 492 360
join 2 492 360
assign 1 496 366
create 0 496 366
copyTo 1 497 367
assign 1 498 368
copy 0 498 368
pathSet 1 498 369
return 1 499 370
assign 1 503 374
split 1 503 374
return 1 503 375
assign 1 507 379
hashGet 0 507 379
return 1 507 380
assign 1 511 385
equals 1 511 385
assign 1 511 386
not 0 511 391
return 1 511 391
assign 1 518 402
undef 1 518 407
assign 1 0 408
assign 1 518 411
otherType 1 518 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 518 423
pathGet 0 518 423
assign 1 518 424
notEquals 1 518 424
assign 1 0 426
assign 1 0 429
assign 1 519 433
new 0 519 433
return 1 519 434
assign 1 521 436
new 0 521 436
return 1 521 437
assign 1 525 441
subPath 2 525 441
return 1 525 442
assign 1 529 451
stepsGet 0 529 451
assign 1 530 452
undef 1 530 457
assign 1 531 458
subList 1 531 458
assign 1 533 461
subList 2 533 461
assign 1 535 463
create 0 535 463
separatorSet 1 536 464
assign 1 537 465
new 0 537 465
assign 1 537 466
join 2 537 466
pathSet 1 537 467
return 1 538 468
return 1 0 471
assign 1 0 474
return 1 0 478
assign 1 0 481
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -993607120: return bem_fieldIteratorGet_0();
case -1028270983: return bem_pathGet_0();
case -1683940834: return bem_create_0();
case 570560636: return bem_serializeToString_0();
case 32699518: return bem_copy_0();
case -349248390: return bem_deserializeClassNameGet_0();
case 1467676516: return bem_iteratorGet_0();
case 462697424: return bem_many_0();
case -829112796: return bem_sourceFileNameGet_0();
case 967087648: return bem_classNameGet_0();
case 1891180934: return bem_stepsGet_0();
case -1779073385: return bem_toString_0();
case 1007010882: return bem_hashGet_0();
case 1936633270: return bem_makeAbsolute_0();
case 1113679576: return bem_echo_0();
case -369710851: return bem_separatorGet_0();
case 984657505: return bem_serializationIteratorGet_0();
case -386274073: return bem_tagGet_0();
case 305718102: return bem_lastStepGet_0();
case -1317894619: return bem_stepListGet_0();
case -25899985: return bem_firstStepGet_0();
case 3302382: return bem_deleteFirstStep_0();
case 1611504589: return bem_new_0();
case -1620217339: return bem_serializeContents_0();
case -604042750: return bem_once_0();
case -68587803: return bem_print_0();
case 1242061384: return bem_isAbsoluteGet_0();
case -817841652: return bem_toAny_0();
case -789400756: return bem_makeNonAbsolute_0();
case 370596559: return bem_parentGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1915157348: return bem_defined_1(bevd_0);
case -337289143: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 442788356: return bem_add_1(bevd_0);
case -690797068: return bem_otherClass_1(bevd_0);
case 1307311070: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 400917403: return bem_sameClass_1(bevd_0);
case 897063644: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1371950595: return bem_sameType_1(bevd_0);
case 194288895: return bem_addSteps_1(bevd_0);
case -1883762151: return bem_addStep_1(bevd_0);
case 1890025502: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -391255342: return bem_pathSet_1(bevd_0);
case 680024470: return bem_separatorSet_1(bevd_0);
case 1412822362: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 186027133: return bem_sameObject_1(bevd_0);
case -1163022531: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 871077747: return bem_copyTo_1(bevd_0);
case 1017703126: return bem_def_1(bevd_0);
case -1003116355: return bem_undefined_1(bevd_0);
case 768529536: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1394703037: return bem_notEquals_1(bevd_0);
case -758933213: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1219927083: return bem_equals_1(bevd_0);
case -497225509: return bem_undef_1(bevd_0);
case -1320126626: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1857123920: return bem_otherType_1(bevd_0);
case 1693411664: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 2025283811: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 963667386: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 5892141: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -423405168: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1893386943: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -74821886: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -858254077: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 194196311: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 980645593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -238396678: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
}
}
