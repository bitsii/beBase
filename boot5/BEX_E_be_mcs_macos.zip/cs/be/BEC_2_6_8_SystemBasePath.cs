namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
public static new BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static new BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_ta_ph.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_8_SystemBasePath bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_7_TextStrings bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_other.bemd_0(631553665);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(92268189, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 103*/ {
bevt_4_ta_ph = (BEC_2_6_8_SystemBasePath) bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_ta_ph;
} /* Line: 104*/
bevt_5_ta_ph = beva_other.bemd_0(-1530011752);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 106*/ {
bevt_6_ta_ph = beva_other.bemd_0(-1036391864);
return (BEC_2_6_8_SystemBasePath) bevt_6_ta_ph;
} /* Line: 107*/
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_ta_ph = beva_other.bemd_0(631553665);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_ta_ph.bemd_1(-2029878140, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 111*/ {
bevt_8_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 111*/ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 113*/
 else /* Line: 111*/ {
break;
} /* Line: 111*/
} /* Line: 111*/
bevt_9_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_ta_ph.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_ta_ph);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 129*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 129*/ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_3_ta_ph = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_ta_ph);
} /* Line: 131*/
 else /* Line: 132*/ {
bevl_i.bem_nextGet_0();
} /* Line: 133*/
bevl_c = bevl_c.bem_increment_0();
} /* Line: 135*/
 else /* Line: 129*/ {
break;
} /* Line: 129*/
} /* Line: 129*/
bevt_4_ta_ph = bem_isAbsoluteGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 137*/ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 138*/
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (bevp_path == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_4_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_sizeGet_0();
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 144*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 144*/ {
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 144*/
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bevp_path.bem_getPoint_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_equals_1(bevp_separator);
if (bevt_7_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 146*/
bevt_11_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 153*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_isAbsoluteGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 158*/ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 159*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_howMany.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 164*/ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 169*/ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 169*/ {
if (bevl_next == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 170*/ {
break;
} /* Line: 170*/
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 169*/
 else /* Line: 169*/ {
break;
} /* Line: 169*/
} /* Line: 169*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 175*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 187*/ {
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_ta_ph.bem_emptyGet_0();
} /* Line: 188*/
 else /* Line: 189*/ {
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevl_fp.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_ta_ph, bevt_4_ta_ph);
} /* Line: 190*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
/* Line: 196*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 196*/ {
bevt_1_ta_ph = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_ta_ph);
} /* Line: 197*/
 else /* Line: 196*/ {
break;
} /* Line: 196*/
} /* Line: 196*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_8_SystemBasePath) bem_addStep_1(beva_step);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_3_ta_ph = beva_x.bemd_1(-1420800859, this);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_5_ta_ph = beva_x.bemd_0(631553665);
bevt_4_ta_ph = bevp_path.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 237*/
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_subPath_2(beva_start, null);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 248*/ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 249*/
 else /* Line: 250*/ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 251*/
bevl_res = bem_create_0();
bevl_res.bemd_1(-1236395496, bevp_separator);
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(509303358, bevt_1_ta_ph);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGetDirect_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {64, 64, 68, 69, 73, 77, 81, 81, 85, 86, 86, 87, 91, 91, 95, 95, 95, 99, 99, 99, 103, 103, 103, 103, 104, 104, 106, 107, 107, 109, 110, 110, 111, 111, 112, 113, 115, 115, 116, 117, 119, 123, 124, 125, 125, 126, 127, 128, 129, 129, 130, 130, 131, 131, 133, 135, 137, 138, 140, 144, 144, 0, 144, 144, 144, 144, 144, 0, 0, 144, 144, 145, 145, 145, 146, 146, 148, 148, 152, 153, 153, 153, 158, 158, 158, 159, 164, 164, 164, 165, 166, 168, 169, 169, 169, 170, 170, 171, 172, 173, 169, 175, 180, 181, 182, 186, 187, 187, 188, 188, 190, 190, 190, 190, 195, 196, 196, 197, 197, 199, 203, 203, 207, 208, 209, 210, 214, 215, 216, 216, 217, 221, 221, 225, 225, 229, 229, 229, 236, 236, 0, 236, 0, 0, 0, 236, 236, 0, 0, 237, 237, 239, 239, 243, 243, 247, 248, 248, 249, 251, 253, 254, 255, 255, 255, 256, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 26, 27, 31, 35, 39, 40, 46, 47, 48, 49, 53, 54, 59, 60, 61, 66, 67, 68, 87, 88, 89, 90, 92, 93, 95, 97, 98, 100, 101, 102, 103, 106, 108, 109, 115, 116, 117, 118, 119, 132, 133, 134, 135, 136, 137, 138, 139, 142, 144, 149, 150, 151, 154, 156, 162, 164, 166, 181, 186, 187, 190, 191, 192, 193, 198, 199, 202, 206, 207, 209, 210, 211, 213, 214, 216, 217, 223, 225, 226, 227, 234, 235, 240, 241, 254, 255, 260, 261, 262, 263, 264, 267, 272, 273, 278, 281, 282, 283, 284, 290, 296, 297, 298, 308, 309, 314, 315, 316, 319, 320, 321, 322, 331, 332, 335, 337, 338, 344, 349, 350, 354, 355, 356, 357, 363, 364, 365, 366, 367, 371, 372, 376, 377, 382, 383, 388, 399, 404, 405, 408, 410, 413, 417, 420, 421, 423, 426, 430, 431, 433, 434, 438, 439, 448, 449, 454, 455, 458, 460, 461, 462, 463, 464, 465, 468, 471, 474, 478, 482, 485, 488, 492};
/* BEGIN LINEINFO 
assign 1 64 21
new 0 64 21
new 1 64 22
assign 1 68 26
new 0 68 26
fromString 1 69 27
assign 1 73 31
return 1 77 35
assign 1 81 39
toStringWithSeparator 1 81 39
return 1 81 40
assign 1 85 46
split 1 85 46
assign 1 86 47
new 0 86 47
assign 1 86 48
join 2 86 48
return 1 87 49
assign 1 91 53
split 1 91 53
return 1 91 54
assign 1 95 59
split 1 95 59
assign 1 95 60
firstGet 0 95 60
return 1 95 61
assign 1 99 66
split 1 99 66
assign 1 99 67
lastGet 0 99 67
return 1 99 68
assign 1 103 87
pathGet 0 103 87
assign 1 103 88
new 0 103 88
assign 1 103 89
emptyGet 0 103 89
assign 1 103 90
equals 1 103 90
assign 1 104 92
copy 0 104 92
return 1 104 93
assign 1 106 95
isAbsoluteGet 0 106 95
assign 1 107 97
copy 0 107 97
return 1 107 98
assign 1 109 100
split 1 109 100
assign 1 110 101
pathGet 0 110 101
assign 1 110 102
split 1 110 102
assign 1 111 103
linkedListIteratorGet 0 111 103
assign 1 111 106
hasNextGet 0 111 106
assign 1 112 108
nextGet 0 112 108
addValue 1 113 109
assign 1 115 115
new 0 115 115
assign 1 115 116
join 2 115 116
assign 1 116 117
copy 0 116 117
assign 1 117 118
fromString 1 117 118
return 1 119 119
assign 1 123 132
split 1 123 132
assign 1 124 133
copy 0 124 133
assign 1 125 134
new 0 125 134
pathSet 1 125 135
assign 1 126 136
lengthGet 0 126 136
assign 1 127 137
decrement 0 127 137
assign 1 128 138
new 0 128 138
assign 1 129 139
linkedListIteratorGet 0 129 139
assign 1 129 142
hasNextGet 0 129 142
assign 1 130 144
lesser 1 130 149
assign 1 131 150
nextGet 0 131 150
addStep 1 131 151
nextGet 0 133 154
assign 1 135 156
increment 0 135 156
assign 1 137 162
isAbsoluteGet 0 137 162
makeAbsolute 0 138 164
return 1 140 166
assign 1 144 181
undef 1 144 186
assign 1 0 187
assign 1 144 190
toString 0 144 190
assign 1 144 191
sizeGet 0 144 191
assign 1 144 192
new 0 144 192
assign 1 144 193
lesser 1 144 198
assign 1 0 199
assign 1 0 202
assign 1 144 206
new 0 144 206
return 1 144 207
assign 1 145 209
new 0 145 209
assign 1 145 210
getPoint 1 145 210
assign 1 145 211
equals 1 145 211
assign 1 146 213
new 0 146 213
return 1 146 214
assign 1 148 216
new 0 148 216
return 1 148 217
assign 1 152 223
isAbsoluteGet 0 152 223
assign 1 153 225
new 0 153 225
assign 1 153 226
sizeGet 0 153 226
assign 1 153 227
substring 2 153 227
assign 1 158 234
isAbsoluteGet 0 158 234
assign 1 158 235
not 0 158 240
assign 1 159 241
add 1 159 241
assign 1 164 254
new 0 164 254
assign 1 164 255
greater 1 164 260
makeNonAbsolute 0 165 261
assign 1 166 262
split 1 166 262
assign 1 168 263
firstNodeGet 0 168 263
assign 1 169 264
new 0 169 264
assign 1 169 267
lesser 1 169 272
assign 1 170 273
undef 1 170 278
assign 1 171 281
assign 1 172 282
nextGet 0 172 282
delete 0 173 283
assign 1 169 284
increment 0 169 284
assign 1 175 290
join 2 175 290
assign 1 180 296
split 1 180 296
addValue 1 181 297
assign 1 182 298
join 2 182 298
assign 1 186 308
find 1 186 308
assign 1 187 309
undef 1 187 314
assign 1 188 315
new 0 188 315
assign 1 188 316
emptyGet 0 188 316
assign 1 190 319
new 0 190 319
assign 1 190 320
add 1 190 320
assign 1 190 321
sizeGet 0 190 321
assign 1 190 322
substring 2 190 322
assign 1 195 331
split 1 195 331
assign 1 196 332
linkedListIteratorGet 0 196 332
assign 1 196 335
hasNextGet 0 196 335
assign 1 197 337
nextGet 0 197 337
addValue 1 197 338
assign 1 199 344
join 2 199 344
assign 1 203 349
addStep 1 203 349
return 1 203 350
assign 1 207 354
split 1 207 354
addValue 1 208 355
addValue 1 209 356
assign 1 210 357
join 2 210 357
assign 1 214 363
create 0 214 363
copyTo 1 215 364
assign 1 216 365
copy 0 216 365
pathSet 1 216 366
return 1 217 367
assign 1 221 371
split 1 221 371
return 1 221 372
assign 1 225 376
hashGet 0 225 376
return 1 225 377
assign 1 229 382
equals 1 229 382
assign 1 229 383
not 0 229 388
return 1 229 388
assign 1 236 399
undef 1 236 404
assign 1 0 405
assign 1 236 408
otherType 1 236 408
assign 1 0 410
assign 1 0 413
assign 1 0 417
assign 1 236 420
pathGet 0 236 420
assign 1 236 421
notEquals 1 236 421
assign 1 0 423
assign 1 0 426
assign 1 237 430
new 0 237 430
return 1 237 431
assign 1 239 433
new 0 239 433
return 1 239 434
assign 1 243 438
subPath 2 243 438
return 1 243 439
assign 1 247 448
stepsGet 0 247 448
assign 1 248 449
undef 1 248 454
assign 1 249 455
subList 1 249 455
assign 1 251 458
subList 2 251 458
assign 1 253 460
create 0 253 460
separatorSet 1 254 461
assign 1 255 462
new 0 255 462
assign 1 255 463
join 2 255 463
pathSet 1 255 464
return 1 256 465
return 1 0 468
return 1 0 471
assign 1 0 474
assign 1 0 478
return 1 0 482
return 1 0 485
assign 1 0 488
assign 1 0 492
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 631553665: return bem_pathGet_0();
case 62239394: return bem_deserializeClassNameGet_0();
case 676030373: return bem_stepsGet_0();
case 1460710096: return bem_tagGet_0();
case -1253293660: return bem_serializeToString_0();
case 1640157629: return bem_toString_0();
case 1562650783: return bem_fieldIteratorGet_0();
case 2030445919: return bem_lastStepGet_0();
case 307193318: return bem_serializeContents_0();
case -1530011752: return bem_isAbsoluteGet_0();
case 2037996040: return bem_create_0();
case -1401273642: return bem_separatorGetDirect_0();
case 1441339820: return bem_pathGetDirect_0();
case 1143960145: return bem_parentGet_0();
case -2070846101: return bem_hashGet_0();
case -1221104789: return bem_sourceFileNameGet_0();
case -1036391864: return bem_copy_0();
case -1777316122: return bem_serializationIteratorGet_0();
case 1745356283: return bem_firstStepGet_0();
case 939713627: return bem_print_0();
case -178385347: return bem_iteratorGet_0();
case 516548713: return bem_makeAbsolute_0();
case 1308996841: return bem_separatorGet_0();
case -1906768398: return bem_classNameGet_0();
case -1200560241: return bem_makeNonAbsolute_0();
case 873076018: return bem_new_0();
case 92457972: return bem_stepListGet_0();
case 2004491413: return bem_deleteFirstStep_0();
case 1258729534: return bem_echo_0();
case 1794395999: return bem_fieldNamesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1528782257: return bem_copyTo_1(bevd_0);
case -2076338748: return bem_add_1(bevd_0);
case 509303358: return bem_pathSet_1(bevd_0);
case 1305176557: return bem_addSteps_1(bevd_0);
case -493310448: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1747479275: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 92268189: return bem_equals_1(bevd_0);
case -1876528720: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -19427502: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1420800859: return bem_otherType_1(bevd_0);
case 409953036: return bem_sameObject_1(bevd_0);
case 1630850770: return bem_addStep_1(bevd_0);
case 1195923940: return bem_undef_1(bevd_0);
case 1601584010: return bem_sameType_1(bevd_0);
case -1127191136: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -178752693: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1536671288: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1128815336: return bem_notEquals_1(bevd_0);
case 1128207149: return bem_otherClass_1(bevd_0);
case 1017689147: return bem_pathSetDirect_1(bevd_0);
case -1633406915: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 2084409351: return bem_sameClass_1(bevd_0);
case -1236395496: return bem_separatorSet_1(bevd_0);
case -408388070: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1395865927: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 986596229: return bem_def_1(bevd_0);
case 29741396: return bem_separatorSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 141582642: return bem_addSteps_2(bevd_0, bevd_1);
case 776368499: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 68756576: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1501275792: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -4013609: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1507851267: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 524533306: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
}
