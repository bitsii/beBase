namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static new BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_ta_ph.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_0_ta_ph = bevt_1_ta_ph.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_6_8_SystemBasePath bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_7_TextStrings bevt_9_ta_ph = null;
bevt_1_ta_ph = beva_other.bemd_0(-1678567911);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_emptyGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1028670892, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 103*/ {
bevt_4_ta_ph = (BEC_2_6_8_SystemBasePath) bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_ta_ph;
} /* Line: 104*/
bevt_5_ta_ph = beva_other.bemd_0(-1332314029);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 106*/ {
bevt_6_ta_ph = beva_other.bemd_0(1732513565);
return (BEC_2_6_8_SystemBasePath) bevt_6_ta_ph;
} /* Line: 107*/
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_ta_ph = beva_other.bemd_0(-1678567911);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_ta_ph.bemd_1(619583891, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 111*/ {
bevt_8_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 111*/ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 113*/
 else /* Line: 111*/ {
break;
} /* Line: 111*/
} /* Line: 111*/
bevt_9_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_ta_ph.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_ta_ph);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
/* Line: 129*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 129*/ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_3_ta_ph = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_ta_ph);
} /* Line: 131*/
 else /* Line: 132*/ {
bevl_i.bem_nextGet_0();
} /* Line: 133*/
bevl_c = bevl_c.bem_increment_0();
} /* Line: 135*/
 else /* Line: 129*/ {
break;
} /* Line: 129*/
} /* Line: 129*/
bevt_4_ta_ph = bem_isAbsoluteGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 137*/ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 138*/
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (bevp_path == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_4_ta_ph = bevp_path.bem_toString_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_sizeGet_0();
bevt_5_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_ta_ph.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 144*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 144*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 144*/ {
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 144*/
bevt_9_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_ta_ph = bevp_path.bem_getPoint_1(bevt_9_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_equals_1(bevp_separator);
if (bevt_7_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 146*/
bevt_11_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_1_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_ta_ph, bevt_2_ta_ph);
} /* Line: 153*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_isAbsoluteGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 158*/ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 159*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 164*/ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 169*/ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 169*/ {
if (bevl_next == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 170*/ {
break;
} /* Line: 170*/
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 169*/
 else /* Line: 169*/ {
break;
} /* Line: 169*/
} /* Line: 169*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 175*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 187*/ {
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_ta_ph.bem_emptyGet_0();
} /* Line: 188*/
 else /* Line: 189*/ {
bevt_3_ta_ph = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_ta_ph = bevl_fp.bem_add_1(bevt_3_ta_ph);
bevt_4_ta_ph = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_ta_ph, bevt_4_ta_ph);
} /* Line: 190*/
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
/* Line: 196*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 196*/ {
bevt_1_ta_ph = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_ta_ph);
} /* Line: 197*/
 else /* Line: 196*/ {
break;
} /* Line: 196*/
} /* Line: 196*/
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_8_SystemBasePath) bem_addStep_1(beva_step);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_split_1(bevp_separator);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_path.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_3_ta_ph = beva_x.bemd_1(-1089350026, this);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_5_ta_ph = beva_x.bemd_0(-1678567911);
bevt_4_ta_ph = bevp_path.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 236*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 236*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 236*/ {
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 237*/
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_subPath_2(beva_start, null);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 248*/ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 249*/
 else /* Line: 250*/ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 251*/
bevl_res = bem_create_0();
bevl_res.bemd_1(1572270499, bevp_separator);
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(601132602, bevt_1_ta_ph);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGetDirect_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {64, 64, 68, 69, 73, 77, 81, 81, 85, 86, 86, 87, 91, 91, 95, 95, 95, 99, 99, 99, 103, 103, 103, 103, 104, 104, 106, 107, 107, 109, 110, 110, 111, 111, 112, 113, 115, 115, 116, 117, 119, 123, 124, 125, 125, 126, 127, 128, 129, 129, 130, 130, 131, 131, 133, 135, 137, 138, 140, 144, 144, 0, 144, 144, 144, 144, 144, 0, 0, 144, 144, 145, 145, 145, 146, 146, 148, 148, 152, 153, 153, 153, 158, 158, 158, 159, 164, 164, 164, 165, 166, 168, 169, 169, 169, 170, 170, 171, 172, 173, 169, 175, 180, 181, 182, 186, 187, 187, 188, 188, 190, 190, 190, 190, 195, 196, 196, 197, 197, 199, 203, 203, 207, 208, 209, 210, 214, 215, 216, 216, 217, 221, 221, 225, 225, 229, 229, 229, 236, 236, 0, 236, 0, 0, 0, 236, 236, 0, 0, 237, 237, 239, 239, 243, 243, 247, 248, 248, 249, 251, 253, 254, 255, 255, 255, 256, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 31, 32, 36, 40, 44, 45, 51, 52, 53, 54, 58, 59, 64, 65, 66, 71, 72, 73, 92, 93, 94, 95, 97, 98, 100, 102, 103, 105, 106, 107, 108, 111, 113, 114, 120, 121, 122, 123, 124, 137, 138, 139, 140, 141, 142, 143, 144, 147, 149, 154, 155, 156, 159, 161, 167, 169, 171, 186, 191, 192, 195, 196, 197, 198, 203, 204, 207, 211, 212, 214, 215, 216, 218, 219, 221, 222, 228, 230, 231, 232, 239, 240, 245, 246, 259, 260, 265, 266, 267, 268, 269, 272, 277, 278, 283, 286, 287, 288, 289, 295, 301, 302, 303, 313, 314, 319, 320, 321, 324, 325, 326, 327, 336, 337, 340, 342, 343, 349, 354, 355, 359, 360, 361, 362, 368, 369, 370, 371, 372, 376, 377, 381, 382, 387, 388, 393, 404, 409, 410, 413, 415, 418, 422, 425, 426, 428, 431, 435, 436, 438, 439, 443, 444, 453, 454, 459, 460, 463, 465, 466, 467, 468, 469, 470, 473, 476, 479, 483, 487, 490, 493, 497};
/* BEGIN LINEINFO 
assign 1 64 26
new 0 64 26
new 1 64 27
assign 1 68 31
new 0 68 31
fromString 1 69 32
assign 1 73 36
return 1 77 40
assign 1 81 44
toStringWithSeparator 1 81 44
return 1 81 45
assign 1 85 51
split 1 85 51
assign 1 86 52
new 0 86 52
assign 1 86 53
join 2 86 53
return 1 87 54
assign 1 91 58
split 1 91 58
return 1 91 59
assign 1 95 64
split 1 95 64
assign 1 95 65
firstGet 0 95 65
return 1 95 66
assign 1 99 71
split 1 99 71
assign 1 99 72
lastGet 0 99 72
return 1 99 73
assign 1 103 92
pathGet 0 103 92
assign 1 103 93
new 0 103 93
assign 1 103 94
emptyGet 0 103 94
assign 1 103 95
equals 1 103 95
assign 1 104 97
copy 0 104 97
return 1 104 98
assign 1 106 100
isAbsoluteGet 0 106 100
assign 1 107 102
copy 0 107 102
return 1 107 103
assign 1 109 105
split 1 109 105
assign 1 110 106
pathGet 0 110 106
assign 1 110 107
split 1 110 107
assign 1 111 108
linkedListIteratorGet 0 111 108
assign 1 111 111
hasNextGet 0 111 111
assign 1 112 113
nextGet 0 112 113
addValue 1 113 114
assign 1 115 120
new 0 115 120
assign 1 115 121
join 2 115 121
assign 1 116 122
copy 0 116 122
assign 1 117 123
fromString 1 117 123
return 1 119 124
assign 1 123 137
split 1 123 137
assign 1 124 138
copy 0 124 138
assign 1 125 139
new 0 125 139
pathSet 1 125 140
assign 1 126 141
lengthGet 0 126 141
assign 1 127 142
decrement 0 127 142
assign 1 128 143
new 0 128 143
assign 1 129 144
linkedListIteratorGet 0 129 144
assign 1 129 147
hasNextGet 0 129 147
assign 1 130 149
lesser 1 130 154
assign 1 131 155
nextGet 0 131 155
addStep 1 131 156
nextGet 0 133 159
assign 1 135 161
increment 0 135 161
assign 1 137 167
isAbsoluteGet 0 137 167
makeAbsolute 0 138 169
return 1 140 171
assign 1 144 186
undef 1 144 191
assign 1 0 192
assign 1 144 195
toString 0 144 195
assign 1 144 196
sizeGet 0 144 196
assign 1 144 197
new 0 144 197
assign 1 144 198
lesser 1 144 203
assign 1 0 204
assign 1 0 207
assign 1 144 211
new 0 144 211
return 1 144 212
assign 1 145 214
new 0 145 214
assign 1 145 215
getPoint 1 145 215
assign 1 145 216
equals 1 145 216
assign 1 146 218
new 0 146 218
return 1 146 219
assign 1 148 221
new 0 148 221
return 1 148 222
assign 1 152 228
isAbsoluteGet 0 152 228
assign 1 153 230
new 0 153 230
assign 1 153 231
sizeGet 0 153 231
assign 1 153 232
substring 2 153 232
assign 1 158 239
isAbsoluteGet 0 158 239
assign 1 158 240
not 0 158 245
assign 1 159 246
add 1 159 246
assign 1 164 259
new 0 164 259
assign 1 164 260
greater 1 164 265
makeNonAbsolute 0 165 266
assign 1 166 267
split 1 166 267
assign 1 168 268
firstNodeGet 0 168 268
assign 1 169 269
new 0 169 269
assign 1 169 272
lesser 1 169 277
assign 1 170 278
undef 1 170 283
assign 1 171 286
assign 1 172 287
nextGet 0 172 287
delete 0 173 288
assign 1 169 289
increment 0 169 289
assign 1 175 295
join 2 175 295
assign 1 180 301
split 1 180 301
addValue 1 181 302
assign 1 182 303
join 2 182 303
assign 1 186 313
find 1 186 313
assign 1 187 314
undef 1 187 319
assign 1 188 320
new 0 188 320
assign 1 188 321
emptyGet 0 188 321
assign 1 190 324
new 0 190 324
assign 1 190 325
add 1 190 325
assign 1 190 326
sizeGet 0 190 326
assign 1 190 327
substring 2 190 327
assign 1 195 336
split 1 195 336
assign 1 196 337
linkedListIteratorGet 0 196 337
assign 1 196 340
hasNextGet 0 196 340
assign 1 197 342
nextGet 0 197 342
addValue 1 197 343
assign 1 199 349
join 2 199 349
assign 1 203 354
addStep 1 203 354
return 1 203 355
assign 1 207 359
split 1 207 359
addValue 1 208 360
addValue 1 209 361
assign 1 210 362
join 2 210 362
assign 1 214 368
create 0 214 368
copyTo 1 215 369
assign 1 216 370
copy 0 216 370
pathSet 1 216 371
return 1 217 372
assign 1 221 376
split 1 221 376
return 1 221 377
assign 1 225 381
hashGet 0 225 381
return 1 225 382
assign 1 229 387
equals 1 229 387
assign 1 229 388
not 0 229 393
return 1 229 393
assign 1 236 404
undef 1 236 409
assign 1 0 410
assign 1 236 413
otherType 1 236 413
assign 1 0 415
assign 1 0 418
assign 1 0 422
assign 1 236 425
pathGet 0 236 425
assign 1 236 426
notEquals 1 236 426
assign 1 0 428
assign 1 0 431
assign 1 237 435
new 0 237 435
return 1 237 436
assign 1 239 438
new 0 239 438
return 1 239 439
assign 1 243 443
subPath 2 243 443
return 1 243 444
assign 1 247 453
stepsGet 0 247 453
assign 1 248 454
undef 1 248 459
assign 1 249 460
subList 1 249 460
assign 1 251 463
subList 2 251 463
assign 1 253 465
create 0 253 465
separatorSet 1 254 466
assign 1 255 467
new 0 255 467
assign 1 255 468
join 2 255 468
pathSet 1 255 469
return 1 256 470
return 1 0 473
return 1 0 476
assign 1 0 479
assign 1 0 483
return 1 0 487
return 1 0 490
assign 1 0 493
assign 1 0 497
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1084228149: return bem_print_0();
case -2129983068: return bem_toAny_0();
case 1105152133: return bem_new_0();
case 2097519916: return bem_parentGet_0();
case 2071597061: return bem_create_0();
case 1175420009: return bem_deleteFirstStep_0();
case 1989693945: return bem_toString_0();
case 162533386: return bem_fieldNamesGet_0();
case 233362262: return bem_many_0();
case 110382217: return bem_sourceFileNameGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
case 1759899809: return bem_makeAbsolute_0();
case -1678567911: return bem_pathGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case -945577039: return bem_pathGetDirect_0();
case -687298865: return bem_makeNonAbsolute_0();
case 714460463: return bem_once_0();
case 1843544518: return bem_serializeContents_0();
case 887739950: return bem_serializeToString_0();
case 549012775: return bem_stepsGet_0();
case -1332314029: return bem_isAbsoluteGet_0();
case 2115671973: return bem_firstStepGet_0();
case 888041456: return bem_tagGet_0();
case 1986590366: return bem_hashGet_0();
case -389223600: return bem_separatorGetDirect_0();
case 1383646476: return bem_iteratorGet_0();
case 1772071353: return bem_stepListGet_0();
case -153156208: return bem_serializationIteratorGet_0();
case 285351750: return bem_separatorGet_0();
case 879975179: return bem_classNameGet_0();
case -1770680225: return bem_lastStepGet_0();
case -1588532100: return bem_echo_0();
case 1732513565: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1208262820: return bem_addStep_1(bevd_0);
case 156136873: return bem_pathSetDirect_1(bevd_0);
case 1980192449: return bem_separatorSetDirect_1(bevd_0);
case 1811613147: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 1526801060: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case -412051597: return bem_add_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case 846706065: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1679524237: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case -1963839199: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 601132602: return bem_pathSet_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case 895709744: return bem_addSteps_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case 1572270499: return bem_separatorSet_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case 301786773: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1051352451: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 49193186: return bem_addSteps_2(bevd_0, bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -379407304: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
}
