namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public sealed class BEC_2_6_5_SystemTypes : BEC_2_6_6_SystemObject {
public BEC_2_6_5_SystemTypes() { }
static BEC_2_6_5_SystemTypes() { }
private static byte[] becc_BEC_2_6_5_SystemTypes_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_6_5_SystemTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_inst;

public static new BET_2_6_5_SystemTypes bece_BEC_2_6_5_SystemTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_bool;
public BEC_2_4_5_MathFloat bevp_float;
public BEC_2_6_5_SystemThing bevp_thing;
public BEC_2_4_6_TextString bevp_string;
public BEC_2_4_6_TextString bevp_byteBuffer;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_default_0() {
bevp_int = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_bool = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_float = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
bevp_thing = (BEC_2_6_5_SystemThing) (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_string = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_byteBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGet_0() {
return bevp_bool;
} /*method end*/
public BEC_2_5_4_LogicBool bem_boolGetDirect_0() {
return bevp_bool;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_boolSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_bool = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGet_0() {
return bevp_float;
} /*method end*/
public BEC_2_4_5_MathFloat bem_floatGetDirect_0() {
return bevp_float;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_floatSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_float = (BEC_2_4_5_MathFloat) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemThing bem_thingGetDirect_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_thing = (BEC_2_6_5_SystemThing) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGet_0() {
return bevp_string;
} /*method end*/
public BEC_2_4_6_TextString bem_stringGetDirect_0() {
return bevp_string;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_string = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_stringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_string = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGet_0() {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_byteBufferGetDirect_0() {
return bevp_byteBuffer;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_5_SystemTypes bem_byteBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_byteBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {42, 43, 44, 45, 46, 47, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 29, 30, 31, 35, 38, 41, 45, 49, 52, 55, 59, 63, 66, 69, 73, 77, 80, 83, 87, 91, 94, 97, 101, 105, 108, 111, 115};
/* BEGIN LINEINFO 
assign 1 42 26
new 0 42 26
assign 1 43 27
new 0 43 27
assign 1 44 28
new 0 44 28
assign 1 45 29
new 0 45 29
assign 1 46 30
new 0 46 30
assign 1 47 31
new 0 47 31
return 1 0 35
return 1 0 38
assign 1 0 41
assign 1 0 45
return 1 0 49
return 1 0 52
assign 1 0 55
assign 1 0 59
return 1 0 63
return 1 0 66
assign 1 0 69
assign 1 0 73
return 1 0 77
return 1 0 80
assign 1 0 83
assign 1 0 87
return 1 0 91
return 1 0 94
assign 1 0 97
assign 1 0 101
return 1 0 105
return 1 0 108
assign 1 0 111
assign 1 0 115
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -291345224: return bem_byteBufferGet_0();
case -1848718184: return bem_hashGet_0();
case -31114048: return bem_iteratorGet_0();
case -493080624: return bem_byteBufferGetDirect_0();
case -164145177: return bem_boolGet_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -479166709: return bem_tagGet_0();
case -1466357930: return bem_stringGet_0();
case 185174991: return bem_copy_0();
case 1377915572: return bem_floatGetDirect_0();
case -1902089216: return bem_toString_0();
case -785258946: return bem_create_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1627438273: return bem_default_0();
case 596145162: return bem_floatGet_0();
case 1307930618: return bem_thingGet_0();
case 217968364: return bem_classNameGet_0();
case -1665436764: return bem_boolGetDirect_0();
case 1029695809: return bem_echo_0();
case 1137009070: return bem_once_0();
case 1562608535: return bem_print_0();
case -1267234927: return bem_thingGetDirect_0();
case -1844917728: return bem_many_0();
case 1402478572: return bem_stringGetDirect_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -8643043: return bem_serializeContents_0();
case 102554564: return bem_fieldIteratorGet_0();
case 1688687204: return bem_serializeToString_0();
case 126670515: return bem_toAny_0();
case 1978132718: return bem_intGetDirect_0();
case -1725405782: return bem_sourceFileNameGet_0();
case -1354856967: return bem_intGet_0();
case -1026733174: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1811318132: return bem_defined_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case -1322534658: return bem_stringSet_1(bevd_0);
case 1417911845: return bem_thingSetDirect_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1128070885: return bem_floatSet_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 1492261294: return bem_intSetDirect_1(bevd_0);
case 176169505: return bem_thingSet_1(bevd_0);
case -1858225524: return bem_boolSetDirect_1(bevd_0);
case 225460690: return bem_floatSetDirect_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 1536804815: return bem_boolSet_1(bevd_0);
case 1361795344: return bem_byteBufferSet_1(bevd_0);
case 447638422: return bem_stringSetDirect_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -329980553: return bem_intSet_1(bevd_0);
case 648428368: return bem_byteBufferSetDirect_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_6_5_SystemTypes_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_5_SystemTypes_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_5_SystemTypes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst = (BEC_2_6_5_SystemTypes) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_type;
}
}
}
