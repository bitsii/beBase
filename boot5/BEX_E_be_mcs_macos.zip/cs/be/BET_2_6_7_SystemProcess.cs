namespace be {
public class BET_2_6_7_SystemProcess : BETS_Object {
public BET_2_6_7_SystemProcess() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "default_0", "execNameGet_0", "execPathGet_0", "fullExecNameGet_0", "prepArgs_0", "exit_0", "exit_1", "start_1", "startByName_1", "argsGet_0", "argsSet_1", "numArgsGet_0", "numArgsSet_1", "execNameSet_1", "targetGet_0", "targetSet_1", "resultGet_0", "resultSet_1", "exceptGet_0", "exceptSet_1", "platformGet_0", "platformSet_1", "fullExecNameSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
static BET_2_6_7_SystemProcess() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_7_SystemProcess();
}
}
}
