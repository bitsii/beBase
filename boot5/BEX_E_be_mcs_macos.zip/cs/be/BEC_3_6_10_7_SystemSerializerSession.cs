namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_3_6_10_7_SystemSerializerSession : BEC_2_6_6_SystemObject {
public BEC_3_6_10_7_SystemSerializerSession() { }
static BEC_3_6_10_7_SystemSerializerSession() { }
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x3A,0x53,0x65,0x73,0x73,0x69,0x6F,0x6E};
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static new BEC_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;

public static new BET_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;

public BEC_2_9_3_ContainerMap bevp_classTagMap;
public BEC_2_4_3_MathInt bevp_classTagCount;
public BEC_2_4_3_MathInt bevp_serialCount;
public BEC_2_9_11_ContainerIdentityMap bevp_unique;
public BEC_2_6_6_SystemObject bevp_instWriter;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classTagCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_serialCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) (new BEC_2_9_11_ContainerIdentityMap()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_new_1(BEC_2_6_6_SystemObject beva__instWriter) {
bem_new_0();
bevp_instWriter = beva__instWriter;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_classTagMapGet_0() {
return bevp_classTagMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classTagMapGetDirect_0() {
return bevp_classTagMap;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_classTagCountGet_0() {
return bevp_classTagCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_classTagCountGetDirect_0() {
return bevp_classTagCount;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_serialCountGet_0() {
return bevp_serialCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_serialCountGetDirect_0() {
return bevp_serialCount;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_serialCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_serialCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_11_ContainerIdentityMap bem_uniqueGet_0() {
return bevp_unique;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_uniqueGetDirect_0() {
return bevp_unique;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_uniqueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_uniqueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_instWriterGet_0() {
return bevp_instWriter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instWriterGetDirect_0() {
return bevp_instWriter;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_instWriterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instWriter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_instWriterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instWriter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {29, 30, 31, 32, 38, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 20, 21, 25, 26, 30, 33, 36, 40, 44, 47, 50, 54, 58, 61, 64, 68, 72, 75, 78, 82, 86, 89, 92, 96};
/* BEGIN LINEINFO 
assign 1 29 18
new 0 29 18
assign 1 30 19
new 0 30 19
assign 1 31 20
new 0 31 20
assign 1 32 21
new 0 32 21
new 0 38 25
assign 1 39 26
return 1 0 30
return 1 0 33
assign 1 0 36
assign 1 0 40
return 1 0 44
return 1 0 47
assign 1 0 50
assign 1 0 54
return 1 0 58
return 1 0 61
assign 1 0 64
assign 1 0 68
return 1 0 72
return 1 0 75
assign 1 0 78
assign 1 0 82
return 1 0 86
return 1 0 89
assign 1 0 92
assign 1 0 96
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1776712568: return bem_iteratorGet_0();
case -856707590: return bem_tagGet_0();
case -777274706: return bem_classTagMapGet_0();
case -989882155: return bem_instWriterGet_0();
case -674280457: return bem_instWriterGetDirect_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 1365471067: return bem_print_0();
case -1383276667: return bem_uniqueGet_0();
case -723282878: return bem_serializeContents_0();
case 353377191: return bem_classNameGet_0();
case -1045627857: return bem_create_0();
case 756642383: return bem_fieldNamesGet_0();
case -1723287273: return bem_fieldIteratorGet_0();
case 1426474238: return bem_once_0();
case -1303115743: return bem_hashGet_0();
case -835303456: return bem_many_0();
case -1287943088: return bem_copy_0();
case 1615413553: return bem_classTagCountGetDirect_0();
case 1963695386: return bem_toString_0();
case -313653072: return bem_uniqueGetDirect_0();
case 805348767: return bem_serializationIteratorGet_0();
case 676790499: return bem_classTagCountGet_0();
case 1160612422: return bem_serialCountGetDirect_0();
case -348782970: return bem_serializeToString_0();
case 1340694490: return bem_new_0();
case 1690848108: return bem_echo_0();
case -994969799: return bem_classTagMapGetDirect_0();
case -2091217929: return bem_toAny_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case 802163136: return bem_serialCountGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -793887534: return bem_otherClass_1(bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case -1259848463: return bem_serialCountSetDirect_1(bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case -1102035156: return bem_instWriterSet_1(bevd_0);
case -719725575: return bem_classTagMapSet_1(bevd_0);
case 871540594: return bem_serialCountSet_1(bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case -1412377002: return bem_undef_1(bevd_0);
case -592722541: return bem_classTagCountSet_1(bevd_0);
case -480348635: return bem_def_1(bevd_0);
case -1718327900: return bem_uniqueSet_1(bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case -550139783: return bem_otherType_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2129603513: return bem_defined_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 95963828: return bem_uniqueSetDirect_1(bevd_0);
case -1210553257: return bem_classTagMapSetDirect_1(bevd_0);
case -820222695: return bem_instWriterSetDirect_1(bevd_0);
case 1075219679: return bem_classTagCountSetDirect_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -742775900: return bem_new_1(bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_6_10_7_SystemSerializerSession_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_3_6_10_7_SystemSerializerSession_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_10_7_SystemSerializerSession();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst = (BEC_3_6_10_7_SystemSerializerSession) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;
}
}
}
