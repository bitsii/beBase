namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_8_IOFileWriterNoOutput : BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
static BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x4E,0x6F,0x4F,0x75,0x74,0x70,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;

public static new BET_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;

public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_default_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_writeIfPossible_1(BEC_2_6_6_SystemObject beva_str) {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_write_1(BEC_2_4_6_TextString beva_str) {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isClosedGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_open_0() {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_close_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {768, 777, 777};
public static new int[] bevs_smnlec
 = new int[] {16, 30, 31};
/* BEGIN LINEINFO 
assign 1 768 16
new 0 768 16
assign 1 777 30
new 0 777 30
return 1 777 31
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -945577039: return bem_pathGetDirect_0();
case -354002036: return bem_default_0();
case -2129983068: return bem_toAny_0();
case 879975179: return bem_classNameGet_0();
case -86663906: return bem_close_0();
case 1265739597: return bem_openTruncate_0();
case 1540671271: return bem_vfileGetDirect_0();
case 1473511713: return bem_isClosedGetDirect_0();
case 1308716433: return bem_open_0();
case -1084228149: return bem_print_0();
case -1134454888: return bem_isClosedGet_0();
case 1843544518: return bem_serializeContents_0();
case -153156208: return bem_serializationIteratorGet_0();
case -1588532100: return bem_echo_0();
case 162533386: return bem_fieldNamesGet_0();
case 233362262: return bem_many_0();
case 887739950: return bem_serializeToString_0();
case -1678567911: return bem_pathGet_0();
case 1729533112: return bem_vfileGet_0();
case 110382217: return bem_sourceFileNameGet_0();
case 2071597061: return bem_create_0();
case 1989693945: return bem_toString_0();
case 888041456: return bem_tagGet_0();
case -1463589423: return bem_openAppend_0();
case 714460463: return bem_once_0();
case -2135161631: return bem_extOpen_0();
case 1105152133: return bem_new_0();
case 1986590366: return bem_hashGet_0();
case -1262905199: return bem_deserializeClassNameGet_0();
case 1732513565: return bem_copy_0();
case 1383646476: return bem_iteratorGet_0();
case 1019007593: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 156136873: return bem_pathSetDirect_1(bevd_0);
case 1526801060: return bem_new_1(bevd_0);
case 1178658080: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -846214228: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1096638030: return bem_undefined_1(bevd_0);
case 1667241565: return bem_sameType_1(bevd_0);
case 1101117668: return bem_isClosedSet_1(bevd_0);
case -1078366123: return bem_writeIfPossible_1(bevd_0);
case 763349829: return bem_sameObject_1(bevd_0);
case -1089350026: return bem_otherType_1(bevd_0);
case -1354253064: return bem_def_1(bevd_0);
case -872426559: return bem_notEquals_1(bevd_0);
case 391788880: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 895720563: return bem_otherClass_1(bevd_0);
case -362220326: return bem_isClosedSetDirect_1(bevd_0);
case 233420470: return bem_vfileSet_1(bevd_0);
case 601132602: return bem_pathSet_1(bevd_0);
case 1378784174: return bem_sameClass_1(bevd_0);
case 600412981: return bem_copyTo_1(bevd_0);
case -1028670892: return bem_equals_1(bevd_0);
case -1659142290: return bem_vfileSetDirect_1(bevd_0);
case -2133412036: return bem_defined_1(bevd_0);
case 1879402465: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case 932770312: return bem_undef_1(bevd_0);
case 1345596903: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 568704480: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -467903211: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -186509620: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1715154488: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -160867326: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 126363021: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -481506242: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1290680433: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1543637699: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_8_IOFileWriterNoOutput();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst = (BEC_4_2_4_6_8_IOFileWriterNoOutput) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;
}
}
}
