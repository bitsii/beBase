namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_8_IOFileWriterNoOutput : BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
static BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x4E,0x6F,0x4F,0x75,0x74,0x70,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;

public static new BET_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;

public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_default_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_writeIfPossible_1(BEC_2_6_6_SystemObject beva_str) {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_write_1(BEC_2_4_6_TextString beva_str) {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isClosedGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_open_0() {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_close_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {694, 703, 703};
public static new int[] bevs_smnlec
 = new int[] {16, 30, 31};
/* BEGIN LINEINFO 
assign 1 694 16
new 0 694 16
assign 1 703 30
new 0 703 30
return 1 703 31
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -348788042: return bem_copy_0();
case -63902536: return bem_pathGetDirect_0();
case -479831943: return bem_openAppend_0();
case 165794641: return bem_once_0();
case 1966412141: return bem_iteratorGet_0();
case -342457257: return bem_openTruncate_0();
case -393323283: return bem_toAny_0();
case -1352792576: return bem_close_0();
case 1158828766: return bem_isClosedGetDirect_0();
case 896197971: return bem_tagGet_0();
case 644616544: return bem_serializationIteratorGet_0();
case 575220420: return bem_fieldIteratorGet_0();
case -1674239636: return bem_echo_0();
case 30730421: return bem_many_0();
case 526804620: return bem_isClosedGet_0();
case 1724083576: return bem_serializeContents_0();
case 1558292825: return bem_deserializeClassNameGet_0();
case -307062183: return bem_toString_0();
case -1808490847: return bem_pathGet_0();
case -1978814506: return bem_open_0();
case 585348009: return bem_fieldNamesGet_0();
case 2141644828: return bem_hashGet_0();
case -591889797: return bem_create_0();
case 1185842043: return bem_sourceFileNameGet_0();
case -763923474: return bem_new_0();
case -67472695: return bem_vfileGet_0();
case 1912156906: return bem_serializeToString_0();
case 1965078651: return bem_vfileGetDirect_0();
case -2049832891: return bem_default_0();
case -180542304: return bem_classNameGet_0();
case -1925117861: return bem_print_0();
case 752743955: return bem_extOpen_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -735046391: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291041689: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1311203330: return bem_def_1(bevd_0);
case -1454953713: return bem_isClosedSet_1(bevd_0);
case 1294060201: return bem_sameClass_1(bevd_0);
case -1353025300: return bem_equals_1(bevd_0);
case -642381822: return bem_undefined_1(bevd_0);
case 1299414631: return bem_notEquals_1(bevd_0);
case 1953734144: return bem_otherType_1(bevd_0);
case 404510287: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1661383499: return bem_isClosedSetDirect_1(bevd_0);
case 1160412715: return bem_sameType_1(bevd_0);
case -317302877: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 367903462: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case -1825130896: return bem_pathSetDirect_1(bevd_0);
case 1121300695: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1012471486: return bem_writeIfPossible_1(bevd_0);
case 422988859: return bem_sameObject_1(bevd_0);
case 609382991: return bem_copyTo_1(bevd_0);
case -598110752: return bem_new_1(bevd_0);
case 1602078864: return bem_pathSet_1(bevd_0);
case 1321328032: return bem_defined_1(bevd_0);
case -231248441: return bem_undef_1(bevd_0);
case 1330154191: return bem_vfileSet_1(bevd_0);
case 543167157: return bem_otherClass_1(bevd_0);
case 901984148: return bem_vfileSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1545946221: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1682184009: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2094225927: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1122797756: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1822516892: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936030170: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1462387057: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_8_IOFileWriterNoOutput();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst = (BEC_4_2_4_6_8_IOFileWriterNoOutput) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;
}
}
}
