namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_12_XmlStartElement : BEC_2_3_3_XmlTag {
public BEC_2_3_12_XmlStartElement() { }
static BEC_2_3_12_XmlStartElement() { }
private static byte[] becc_BEC_2_3_12_XmlStartElement_clname = {0x58,0x6D,0x6C,0x3A,0x53,0x74,0x61,0x72,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_12_XmlStartElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_1 = {0x20};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_2 = {0x3D};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_3 = {0x2F,0x3E};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_4 = {0x3E};
public static new BEC_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_inst;

public static new BET_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_6_TextString bevp_attName;
public BEC_2_9_3_ContainerMap bevp_attributes;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_addAttributeName_1(BEC_2_4_6_TextString beva_pname) {
bevp_attName = beva_pname;
return this;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_addAttributeValue_1(BEC_2_4_6_TextString beva_pval) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_attributes == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 44 */ {
bevp_attributes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 45 */
bevp_attributes.bem_put_2(bevp_attName, beva_pval);
bevp_attName = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_6_6_SystemObject bevl_entry = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_0));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevl_accum.bem_addValue_1(bevt_2_tmpany_phold);
bevt_1_tmpany_phold.bem_addValue_1(bevp_name);
if (bevp_attributes == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevt_4_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_4_tmpany_phold.bem_quoteGet_0();
bevt_0_tmpany_loop = bevp_attributes.bem_mapIteratorGet_0();
while (true)
 /* Line: 56 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevl_entry = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_1));
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevl_accum.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevl_entry.bemd_0(475187258);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_2));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevl_q);
bevt_14_tmpany_phold = bevl_entry.bemd_0(1211749133);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevl_q);
} /* Line: 57 */
 else  /* Line: 56 */ {
break;
} /* Line: 56 */
} /* Line: 56 */
} /* Line: 56 */
if (bevp_isClosed.bevi_bool) /* Line: 60 */ {
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_12_XmlStartElement_bels_3));
bevl_accum.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_4));
bevl_accum.bem_addValue_1(bevt_16_tmpany_phold);
} /* Line: 63 */
bevt_17_tmpany_phold = bevl_accum.bem_extractString_0();
return bevt_17_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isClosedGet_0() {
return bevp_isClosed;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGetDirect_0() {
return bevp_isClosed;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_isClosedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_attNameGet_0() {
return bevp_attName;
} /*method end*/
public BEC_2_4_6_TextString bem_attNameGetDirect_0() {
return bevp_attName;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_attNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_attributesGet_0() {
return bevp_attributes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_attributesGetDirect_0() {
return bevp_attributes;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_attributesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attributesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {39, 44, 44, 45, 47, 48, 52, 53, 53, 53, 54, 54, 55, 55, 56, 0, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 61, 61, 63, 63, 65, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 30, 35, 36, 38, 39, 64, 65, 66, 67, 68, 73, 74, 75, 76, 76, 79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 99, 100, 103, 104, 106, 107, 110, 113, 116, 120, 124, 127, 130, 134, 138, 141, 144, 148, 152, 155, 158, 162};
/* BEGIN LINEINFO 
assign 1 39 25
assign 1 44 30
undef 1 44 35
assign 1 45 36
new 0 45 36
put 2 47 38
assign 1 48 39
assign 1 52 64
new 0 52 64
assign 1 53 65
new 0 53 65
assign 1 53 66
addValue 1 53 66
addValue 1 53 67
assign 1 54 68
def 1 54 73
assign 1 55 74
new 0 55 74
assign 1 55 75
quoteGet 0 55 75
assign 1 56 76
mapIteratorGet 0 0 76
assign 1 56 79
hasNextGet 0 56 79
assign 1 56 81
nextGet 0 56 81
assign 1 57 82
new 0 57 82
assign 1 57 83
addValue 1 57 83
assign 1 57 84
keyGet 0 57 84
assign 1 57 85
addValue 1 57 85
assign 1 57 86
new 0 57 86
assign 1 57 87
addValue 1 57 87
assign 1 57 88
addValue 1 57 88
assign 1 57 89
valueGet 0 57 89
assign 1 57 90
addValue 1 57 90
addValue 1 57 91
assign 1 61 99
new 0 61 99
addValue 1 61 100
assign 1 63 103
new 0 63 103
addValue 1 63 104
assign 1 65 106
extractString 0 65 106
return 1 65 107
return 1 0 110
return 1 0 113
assign 1 0 116
assign 1 0 120
return 1 0 124
return 1 0 127
assign 1 0 130
assign 1 0 134
return 1 0 138
return 1 0 141
assign 1 0 144
assign 1 0 148
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1185842043: return bem_sourceFileNameGet_0();
case 1966412141: return bem_iteratorGet_0();
case 165794641: return bem_once_0();
case 575220420: return bem_fieldIteratorGet_0();
case 1912156906: return bem_serializeToString_0();
case 1558292825: return bem_deserializeClassNameGet_0();
case -875216266: return bem_nameGet_0();
case 896197971: return bem_tagGet_0();
case -1199426144: return bem_attributesGetDirect_0();
case 1968323465: return bem_attributesGet_0();
case 1158828766: return bem_isClosedGetDirect_0();
case 526804620: return bem_isClosedGet_0();
case -1440182653: return bem_nameGetDirect_0();
case -180542304: return bem_classNameGet_0();
case -763923474: return bem_new_0();
case 1724083576: return bem_serializeContents_0();
case -307062183: return bem_toString_0();
case -348788042: return bem_copy_0();
case 2141644828: return bem_hashGet_0();
case 30730421: return bem_many_0();
case 1452526672: return bem_attNameGetDirect_0();
case 840566362: return bem_attNameGet_0();
case -1925117861: return bem_print_0();
case -591889797: return bem_create_0();
case 644616544: return bem_serializationIteratorGet_0();
case 585348009: return bem_fieldNamesGet_0();
case -393323283: return bem_toAny_0();
case -1674239636: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -806954841: return bem_attNameSetDirect_1(bevd_0);
case -735046391: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291041689: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1311203330: return bem_def_1(bevd_0);
case -1454953713: return bem_isClosedSet_1(bevd_0);
case 1294060201: return bem_sameClass_1(bevd_0);
case 427571513: return bem_addAttributeName_1((BEC_2_4_6_TextString) bevd_0);
case -1353025300: return bem_equals_1(bevd_0);
case -642381822: return bem_undefined_1(bevd_0);
case 1299414631: return bem_notEquals_1(bevd_0);
case 1953734144: return bem_otherType_1(bevd_0);
case 465956503: return bem_addAttributeValue_1((BEC_2_4_6_TextString) bevd_0);
case -479690973: return bem_attributesSet_1(bevd_0);
case 1915981696: return bem_nameSetDirect_1(bevd_0);
case 404510287: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1661383499: return bem_isClosedSetDirect_1(bevd_0);
case 1160412715: return bem_sameType_1(bevd_0);
case 1721970221: return bem_nameSet_1(bevd_0);
case 1612281092: return bem_attributesSetDirect_1(bevd_0);
case -723146948: return bem_attNameSet_1(bevd_0);
case 1121300695: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 422988859: return bem_sameObject_1(bevd_0);
case 609382991: return bem_copyTo_1(bevd_0);
case 1321328032: return bem_defined_1(bevd_0);
case -231248441: return bem_undef_1(bevd_0);
case 543167157: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1545946221: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1682184009: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2094225927: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1122797756: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1822516892: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 936030170: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1462387057: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_3_12_XmlStartElement_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_12_XmlStartElement_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_12_XmlStartElement();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst = (BEC_2_3_12_XmlStartElement) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_type;
}
}
}
