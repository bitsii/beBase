namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
static BEC_2_9_5_ContainerStack() { }
private static byte[] becc_BEC_2_9_5_ContainerStack_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_BEC_2_9_5_ContainerStack_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_inst;

public static new BET_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 38 */ {
if (bevp_holder == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 40 */
 else  /* Line: 41 */ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 43 */
} /* Line: 39 */
 else  /* Line: 38 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_4_tmpany_phold = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 48 */
 else  /* Line: 49 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 50 */
} /* Line: 38 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_pop_0() {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 57 */ {
return bevp_top;
} /* Line: 58 */
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 62 */ {
bevp_holder = bevl_last;
} /* Line: 63 */
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 65 */ {
return null;
} /* Line: 66 */
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_peek_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 75 */ {
return bevp_top;
} /* Line: 76 */
bevt_1_tmpany_phold = bevp_top.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) {
bem_push_1(beva_item);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_pop.bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /* Line: 95 */
bevt_1_tmpany_phold = bem_peek_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) {
bem_push_1(beva_item);
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_topGet_0() {
return bevp_top;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGetDirect_0() {
return bevp_top;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() {
return bevp_holder;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGetDirect_0() {
return bevp_holder;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {32, 38, 38, 39, 39, 40, 42, 43, 45, 45, 45, 46, 46, 47, 47, 48, 50, 52, 53, 57, 57, 58, 60, 61, 62, 62, 63, 65, 65, 66, 68, 69, 70, 71, 75, 75, 76, 78, 78, 82, 82, 86, 90, 90, 95, 95, 97, 97, 101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 26, 31, 32, 37, 38, 41, 42, 46, 47, 52, 53, 54, 55, 56, 57, 60, 63, 64, 73, 78, 79, 81, 82, 83, 88, 89, 91, 96, 97, 99, 100, 101, 102, 107, 112, 113, 115, 116, 120, 125, 128, 133, 134, 140, 141, 143, 144, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189};
/* BEGIN LINEINFO 
assign 1 32 16
new 0 32 16
assign 1 38 26
undef 1 38 31
assign 1 39 32
undef 1 39 37
assign 1 40 38
new 0 40 38
assign 1 42 41
assign 1 43 42
assign 1 45 46
nextGet 0 45 46
assign 1 45 47
undef 1 45 52
assign 1 46 53
new 0 46 53
nextSet 1 46 54
assign 1 47 55
nextGet 0 47 55
priorSet 1 47 56
assign 1 48 57
nextGet 0 48 57
assign 1 50 60
nextGet 0 50 60
heldSet 1 52 63
assign 1 53 64
increment 0 53 64
assign 1 57 73
undef 1 57 78
return 1 58 79
assign 1 60 81
assign 1 61 82
priorGet 0 61 82
assign 1 62 83
undef 1 62 88
assign 1 63 89
assign 1 65 91
undef 1 65 96
return 1 66 97
assign 1 68 99
heldGet 0 68 99
heldSet 1 69 100
assign 1 70 101
decrement 0 70 101
return 1 71 102
assign 1 75 107
undef 1 75 112
return 1 76 113
assign 1 78 115
heldGet 0 78 115
return 1 78 116
assign 1 82 120
undef 1 82 125
return 1 82 125
push 1 86 128
assign 1 90 133
pop 0 90 133
return 1 90 134
assign 1 95 140
pop 0 95 140
return 1 95 141
assign 1 97 143
peek 0 97 143
return 1 97 144
push 1 101 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1826788951: return bem_holderGet_0();
case 64930083: return bem_new_0();
case -1160093527: return bem_fieldIteratorGet_0();
case 265775004: return bem_tagGet_0();
case 1259379161: return bem_sourceFileNameGet_0();
case -1088345537: return bem_sizeGet_0();
case 338892103: return bem_serializeContents_0();
case 1685630819: return bem_toAny_0();
case 324558137: return bem_serializationIteratorGet_0();
case -1924670591: return bem_print_0();
case 1616298039: return bem_toString_0();
case -477793454: return bem_deserializeClassNameGet_0();
case -2145124906: return bem_fieldNamesGet_0();
case -383409287: return bem_hashGet_0();
case 1535490926: return bem_isEmptyGet_0();
case -1672982659: return bem_get_0();
case 1698440478: return bem_classNameGet_0();
case 1409367716: return bem_iteratorGet_0();
case -698592158: return bem_once_0();
case 857744439: return bem_serializeToString_0();
case -1941348952: return bem_holderGetDirect_0();
case 447398905: return bem_copy_0();
case 172575309: return bem_pop_0();
case 1710417731: return bem_topGet_0();
case 1359093680: return bem_peek_0();
case 24523401: return bem_create_0();
case 1574541715: return bem_echo_0();
case 1324094314: return bem_topGetDirect_0();
case 621904783: return bem_many_0();
case -1678575421: return bem_sizeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -52657747: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 604959651: return bem_otherClass_1(bevd_0);
case 1464921499: return bem_def_1(bevd_0);
case -1768544084: return bem_notEquals_1(bevd_0);
case -911377735: return bem_put_1(bevd_0);
case -1818045574: return bem_push_1(bevd_0);
case -1237963680: return bem_addValue_1(bevd_0);
case -1974306504: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case 1593761925: return bem_topSetDirect_1(bevd_0);
case -1921243842: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2143817101: return bem_copyTo_1(bevd_0);
case 1582703619: return bem_undef_1(bevd_0);
case -1378981491: return bem_sizeSet_1(bevd_0);
case 854851905: return bem_sameType_1(bevd_0);
case 1768597066: return bem_holderSetDirect_1(bevd_0);
case -968521563: return bem_sameObject_1(bevd_0);
case -1270041233: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -454090959: return bem_defined_1(bevd_0);
case -346349789: return bem_equals_1(bevd_0);
case 2106844355: return bem_topSet_1(bevd_0);
case 1365862161: return bem_sizeSetDirect_1(bevd_0);
case -1932510652: return bem_sameClass_1(bevd_0);
case 1882195140: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -907096239: return bem_otherType_1(bevd_0);
case 1959099602: return bem_holderSet_1(bevd_0);
case -685667652: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1030898412: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1425194636: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1465437715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -918533412: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1025227425: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2024613175: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1438061795: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerStack_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerStack_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerStack();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst = (BEC_2_9_5_ContainerStack) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_type;
}
}
}
