namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileWriter : BEC_2_2_6_IOWriter {
public BEC_3_2_4_6_IOFileWriter() { }
static BEC_3_2_4_6_IOFileWriter() { }
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_0 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_1 = {0x61,0x62};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileWriter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileWriter_bels_1, 2));
public static new BEC_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;

public static new BET_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public virtual BEC_3_2_4_6_IOFileWriter bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_openTruncate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_openAppend_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_open_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_open_1(BEC_2_4_6_TextString beva_mode) {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevl_append = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_fhpatha = bevp_path.bem_toString_0();
 /* Line: 428 */ {
if (beva_mode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_3_tmpany_phold = bece_BEC_3_2_4_6_IOFileWriter_bevo_0;
bevt_2_tmpany_phold = beva_mode.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 429 */
 else  /* Line: 429 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 429 */ {
bevl_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 430 */
 else  /* Line: 431 */ {
bevl_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 432 */
} /* Line: 429 */

      if (this.bevi_os == null) {
        string bevls_spath = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        if (bevl_append.bevi_bool) {
            this.bevi_os = new FileStream(bevls_spath, FileMode.Append, FileAccess.Write, FileShare.Write, 64);
        } else {
            this.bevi_os = new FileStream(bevls_spath, FileMode.Create, FileAccess.Write, FileShare.Write, 64);
        }
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {388, 389, 389, 393, 393, 397, 397, 401, 401, 412, 429, 429, 429, 429, 0, 0, 0, 430, 432, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 28, 29, 34, 35, 40, 41, 57, 59, 64, 65, 66, 68, 71, 75, 78, 81, 97, 100, 103, 107};
/* BEGIN LINEINFO 
assign 1 388 21
new 0 388 21
assign 1 389 22
new 1 389 22
pathSet 1 389 23
assign 1 393 28
new 0 393 28
open 1 393 29
assign 1 397 34
new 0 397 34
open 1 397 35
assign 1 401 40
new 0 401 40
open 1 401 41
assign 1 412 57
toString 0 412 57
assign 1 429 59
def 1 429 64
assign 1 429 65
new 0 429 65
assign 1 429 66
equals 1 429 66
assign 1 0 68
assign 1 0 71
assign 1 0 75
assign 1 430 78
new 0 430 78
assign 1 432 81
new 0 432 81
return 1 0 97
return 1 0 100
assign 1 0 103
assign 1 0 107
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1247130742: return bem_openTruncate_0();
case 1135819432: return bem_pathGetDirect_0();
case 24523401: return bem_create_0();
case -1750089061: return bem_pathGet_0();
case 621904783: return bem_many_0();
case 447398905: return bem_copy_0();
case -2145124906: return bem_fieldNamesGet_0();
case -383409287: return bem_hashGet_0();
case 338892103: return bem_serializeContents_0();
case 1685630819: return bem_toAny_0();
case 1574541715: return bem_echo_0();
case -1924670591: return bem_print_0();
case 324558137: return bem_serializationIteratorGet_0();
case -1176006467: return bem_open_0();
case -1715122541: return bem_vfileGet_0();
case 987760081: return bem_extOpen_0();
case 64930083: return bem_new_0();
case 1616298039: return bem_toString_0();
case 265775004: return bem_tagGet_0();
case 1409367716: return bem_iteratorGet_0();
case -698592158: return bem_once_0();
case 1259379161: return bem_sourceFileNameGet_0();
case -1897612152: return bem_isClosedGet_0();
case 1690315788: return bem_openAppend_0();
case -477793454: return bem_deserializeClassNameGet_0();
case -1814802934: return bem_isClosedGetDirect_0();
case -1160093527: return bem_fieldIteratorGet_0();
case 1698440478: return bem_classNameGet_0();
case 857744439: return bem_serializeToString_0();
case 304337241: return bem_vfileGetDirect_0();
case -913233948: return bem_close_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -454090959: return bem_defined_1(bevd_0);
case 1603137691: return bem_pathSet_1(bevd_0);
case 604959651: return bem_otherClass_1(bevd_0);
case -1402939017: return bem_isClosedSetDirect_1(bevd_0);
case -260271169: return bem_isClosedSet_1(bevd_0);
case -2124255197: return bem_vfileSet_1(bevd_0);
case 854851905: return bem_sameType_1(bevd_0);
case 1464921499: return bem_def_1(bevd_0);
case -1859292781: return bem_new_1(bevd_0);
case 1582703619: return bem_undef_1(bevd_0);
case -1921243842: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -907096239: return bem_otherType_1(bevd_0);
case -346349789: return bem_equals_1(bevd_0);
case -1270041233: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1768544084: return bem_notEquals_1(bevd_0);
case -52657747: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1882195140: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1229079031: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 192528990: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 2143817101: return bem_copyTo_1(bevd_0);
case -1932510652: return bem_sameClass_1(bevd_0);
case 288495793: return bem_vfileSetDirect_1(bevd_0);
case 2136354395: return bem_pathSetDirect_1(bevd_0);
case -968521563: return bem_sameObject_1(bevd_0);
case -685667652: return bem_undefined_1(bevd_0);
case 931303181: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1030898412: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1425194636: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1465437715: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -918533412: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1025227425: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2024613175: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1438061795: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileWriter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileWriter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_6_IOFileWriter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst = (BEC_3_2_4_6_IOFileWriter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_type;
}
}
}
