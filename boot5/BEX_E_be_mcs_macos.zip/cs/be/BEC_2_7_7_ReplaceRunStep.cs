namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_7_7_ReplaceRunStep : BEC_2_6_6_SystemObject {
public BEC_2_7_7_ReplaceRunStep() { }
static BEC_2_7_7_ReplaceRunStep() { }
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x52,0x75,0x6E,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;

public static new BET_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_4_6_TextString bevp_str;
public virtual BEC_2_7_7_ReplaceRunStep bem_new_2(BEC_2_8_7_TemplateReplace beva__replace, BEC_2_4_6_TextString beva__str) {
bevp_replace = beva__replace;
bevp_str = beva__str;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) {
BEC_2_4_6_TextString bevl_toSwap = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_r.bemd_0(250717557);
bevl_toSwap = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(-609621197, bevp_str);
if (bevl_toSwap == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 156*/ {
return bevl_toSwap;
} /* Line: 157*/
return bevp_str;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_replaceGet_0() {
return bevp_replace;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGetDirect_0() {
return bevp_replace;
} /*method end*/
public virtual BEC_2_7_7_ReplaceRunStep bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_replaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_7_7_ReplaceRunStep bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {148, 149, 155, 155, 156, 156, 157, 159, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 16, 23, 24, 25, 30, 31, 33, 36, 39, 42, 46, 50, 53, 56, 60};
/* BEGIN LINEINFO 
assign 1 148 15
assign 1 149 16
assign 1 155 23
swapGet 0 155 23
assign 1 155 24
get 1 155 24
assign 1 156 25
def 1 156 30
return 1 157 31
return 1 159 33
return 1 0 36
return 1 0 39
assign 1 0 42
assign 1 0 46
return 1 0 50
return 1 0 53
assign 1 0 56
assign 1 0 60
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1562608535: return bem_print_0();
case 1688687204: return bem_serializeToString_0();
case 1029695809: return bem_echo_0();
case -1844917728: return bem_many_0();
case -1026733174: return bem_new_0();
case -1902089216: return bem_toString_0();
case 102554564: return bem_fieldIteratorGet_0();
case -948653934: return bem_strGet_0();
case -479166709: return bem_tagGet_0();
case 185174991: return bem_copy_0();
case -1848718184: return bem_hashGet_0();
case 126670515: return bem_toAny_0();
case -31114048: return bem_iteratorGet_0();
case -1779062531: return bem_serializationIteratorGet_0();
case -8643043: return bem_serializeContents_0();
case 1086967570: return bem_strGetDirect_0();
case -427165667: return bem_replaceGetDirect_0();
case 1137009070: return bem_once_0();
case -785258946: return bem_create_0();
case 2038193605: return bem_fieldNamesGet_0();
case 1809383255: return bem_deserializeClassNameGet_0();
case -1725405782: return bem_sourceFileNameGet_0();
case 1274837160: return bem_replaceGet_0();
case 217968364: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1310506003: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1289000200: return bem_equals_1(bevd_0);
case 1443498796: return bem_strSet_1(bevd_0);
case -502153488: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1092430958: return bem_otherClass_1(bevd_0);
case 150193228: return bem_copyTo_1(bevd_0);
case 1595336757: return bem_def_1(bevd_0);
case 2066291468: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 772032280: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 881973505: return bem_handle_1(bevd_0);
case 1811318132: return bem_defined_1(bevd_0);
case -2068022953: return bem_undefined_1(bevd_0);
case 572345712: return bem_strSetDirect_1(bevd_0);
case 87356086: return bem_notEquals_1(bevd_0);
case -559891981: return bem_replaceSetDirect_1(bevd_0);
case -519460839: return bem_sameObject_1(bevd_0);
case -1057358062: return bem_otherType_1(bevd_0);
case 1089012067: return bem_replaceSet_1(bevd_0);
case -2073368439: return bem_undef_1(bevd_0);
case 1731923810: return bem_sameClass_1(bevd_0);
case 398725636: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 885411613: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1499306018: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -855029170: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 90572634: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1885851803: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 497465062: return bem_new_2((BEC_2_8_7_TemplateReplace) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2005780752: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -617712632: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_7_7_ReplaceRunStep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_7_ReplaceRunStep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_7_7_ReplaceRunStep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst = (BEC_2_7_7_ReplaceRunStep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_type;
}
}
}
