namespace be {
/* IO:File: source/build/Library.be */
public sealed class BEC_2_5_7_BuildLibrary : BEC_2_6_6_SystemObject {
public BEC_2_5_7_BuildLibrary() { }
static BEC_2_5_7_BuildLibrary() { }
private static byte[] becc_BEC_2_5_7_BuildLibrary_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] becc_BEC_2_5_7_BuildLibrary_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x2E,0x62,0x65};
public static new BEC_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_inst;

public static new BET_2_5_7_BuildLibrary bece_BEC_2_5_7_BuildLibrary_bevs_type;

public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_5_9_BuildClassInfo bevp_libnameInfo;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_5_7_BuildLibrary bem_new_2(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build) {
BEC_3_2_4_4_IOFilePath bevl_libPath = null;
BEC_2_6_6_SystemObject bevl_libnameNp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevp_build = beva__build;
if (bevp_libName == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 17 */ {
bevl_libPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevl_libPath.bem_parentGet_0();
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_1_tmpany_phold = bevl_libPath.bem_stepsGet_0();
bevp_libName = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lastGet_0();
} /* Line: 21 */
 else  /* Line: 22 */ {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
} /* Line: 24 */
if (bevp_libName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 26 */ {
bevl_libnameNp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_libnameNp.bemd_1(1526623563, bevp_libName);
if (bevp_exeName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevp_exeName = bevp_libName;
} /* Line: 29 */
bevt_4_tmpany_phold = bevp_build.bem_emitterGet_0();
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) (new BEC_2_5_9_BuildClassInfo()).bem_new_5((BEC_2_5_8_BuildNamePath) bevl_libnameNp , bevt_4_tmpany_phold, bevp_emitPath, bevp_libName, bevp_exeName);
} /* Line: 30 */
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_new_4(BEC_2_4_6_TextString beva_spath, BEC_2_5_5_BuildBuild beva__build, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) {
bevp_libName = beva__libName;
bevp_exeName = beva__exeName;
bem_new_2(beva_spath, beva__build);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInfoGet_0() {
return bevp_libnameInfo;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInfoGetDirect_0() {
return bevp_libnameInfo;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libnameInfoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_libnameInfoSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInfo = (BEC_2_5_9_BuildClassInfo) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGetDirect_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGetDirect_0() {
return bevp_basePath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_basePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {13, 17, 17, 18, 19, 20, 21, 21, 23, 24, 26, 26, 27, 28, 29, 29, 29, 30, 30, 35, 36, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 32, 33, 34, 35, 36, 37, 40, 41, 43, 48, 49, 50, 51, 56, 57, 59, 60, 65, 66, 67, 71, 74, 77, 81, 85, 88, 91, 95, 99, 102, 105, 109, 113, 116, 119, 123, 127, 130, 133, 137, 141, 144, 147, 151};
/* BEGIN LINEINFO 
assign 1 13 26
assign 1 17 27
undef 1 17 32
assign 1 18 33
new 1 18 33
assign 1 19 34
parentGet 0 19 34
assign 1 20 35
copy 0 20 35
assign 1 21 36
stepsGet 0 21 36
assign 1 21 37
lastGet 0 21 37
assign 1 23 40
new 1 23 40
assign 1 24 41
copy 0 24 41
assign 1 26 43
def 1 26 48
assign 1 27 49
new 0 27 49
fromString 1 28 50
assign 1 29 51
undef 1 29 56
assign 1 29 57
assign 1 30 59
emitterGet 0 30 59
assign 1 30 60
new 5 30 60
assign 1 35 65
assign 1 36 66
new 2 37 67
return 1 0 71
return 1 0 74
assign 1 0 77
assign 1 0 81
return 1 0 85
return 1 0 88
assign 1 0 91
assign 1 0 95
return 1 0 99
return 1 0 102
assign 1 0 105
assign 1 0 109
return 1 0 113
return 1 0 116
assign 1 0 119
assign 1 0 123
return 1 0 127
return 1 0 130
assign 1 0 133
assign 1 0 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 87072509: return bem_toAny_0();
case 658678414: return bem_new_0();
case 705946713: return bem_serializationIteratorGet_0();
case -33412605: return bem_exeNameGetDirect_0();
case 945522219: return bem_hashGet_0();
case -457703447: return bem_deserializeClassNameGet_0();
case 2070479187: return bem_emitPathGetDirect_0();
case -953813177: return bem_libnameInfoGet_0();
case -1922780248: return bem_iteratorGet_0();
case 457529483: return bem_serializeContents_0();
case -1523587008: return bem_exeNameGet_0();
case -1339627276: return bem_basePathGetDirect_0();
case 1440687481: return bem_libNameGet_0();
case 615981380: return bem_fieldNamesGet_0();
case -711514807: return bem_sourceFileNameGet_0();
case 624386533: return bem_serializeToString_0();
case -292945961: return bem_create_0();
case 1095611429: return bem_once_0();
case 1758175538: return bem_libnameInfoGetDirect_0();
case 1094851260: return bem_libNameGetDirect_0();
case 1878894995: return bem_classNameGet_0();
case 1855506680: return bem_toString_0();
case 331824626: return bem_buildGetDirect_0();
case 977377129: return bem_emitPathGet_0();
case -423160261: return bem_buildGet_0();
case -84103940: return bem_many_0();
case 1835544527: return bem_print_0();
case -1354126741: return bem_tagGet_0();
case 2087771877: return bem_echo_0();
case -1725699695: return bem_fieldIteratorGet_0();
case 1284640786: return bem_copy_0();
case 339172641: return bem_basePathGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -656840793: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 465199415: return bem_sameClass_1(bevd_0);
case -609592550: return bem_emitPathSet_1(bevd_0);
case -586455400: return bem_defined_1(bevd_0);
case -1228903581: return bem_libnameInfoSet_1(bevd_0);
case 126395237: return bem_sameObject_1(bevd_0);
case -2109400999: return bem_copyTo_1(bevd_0);
case -597509561: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -341234740: return bem_notEquals_1(bevd_0);
case -1853469220: return bem_exeNameSetDirect_1(bevd_0);
case -1368724020: return bem_sameType_1(bevd_0);
case 69791278: return bem_libNameSetDirect_1(bevd_0);
case -1971460437: return bem_otherClass_1(bevd_0);
case -1383533410: return bem_undef_1(bevd_0);
case 1894284601: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 18092178: return bem_libnameInfoSetDirect_1(bevd_0);
case -1897607279: return bem_equals_1(bevd_0);
case -1591077116: return bem_buildSet_1(bevd_0);
case 58606191: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -754260669: return bem_def_1(bevd_0);
case 934765991: return bem_libNameSet_1(bevd_0);
case 508893484: return bem_buildSetDirect_1(bevd_0);
case -701846850: return bem_otherType_1(bevd_0);
case -1551748546: return bem_undefined_1(bevd_0);
case 778072296: return bem_emitPathSetDirect_1(bevd_0);
case 1509862060: return bem_exeNameSet_1(bevd_0);
case 1061160086: return bem_basePathSetDirect_1(bevd_0);
case -232013234: return bem_basePathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1810583739: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1864186690: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case -687329733: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 703022748: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -871246707: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1013064550: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1390383369: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1845172722: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 883565224: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_5_7_BuildLibrary_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_5_7_BuildLibrary_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_7_BuildLibrary();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst = (BEC_2_5_7_BuildLibrary) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_7_BuildLibrary.bece_BEC_2_5_7_BuildLibrary_bevs_type;
}
}
}
