namespace be {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_4_IOLogs : BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOLogs() { }
static BEC_2_2_4_IOLogs() { }
private static byte[] becc_BEC_2_2_4_IOLogs_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67,0x73};
private static byte[] becc_BEC_2_2_4_IOLogs_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
public static new BEC_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_inst;

public static new BET_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_type;

public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_9_3_ContainerSet bevp_overrides;
public BEC_2_9_3_ContainerMap bevp_loggers;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_4_3_MathInt bevp_defaultOutputLevel;
public BEC_2_4_3_MathInt bevp_defaultLevel;
public BEC_2_6_6_SystemObject bevp_sink;
public virtual BEC_2_2_4_IOLogs bem_default_0() {
bevp_debug = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(400));
bevp_info = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(300));
bevp_warn = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(200));
bevp_error = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(100));
bevp_fatal = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_overrides = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_loggers = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_defaultOutputLevel = bevp_error;
bevp_defaultLevel = bevp_info;
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_setDefaultLevels_2(BEC_2_4_3_MathInt beva__defaultOutputLevel, BEC_2_4_3_MathInt beva__defaultLevel) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
try  /* Line: 38 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = beva__defaultOutputLevel;
bevp_defaultLevel = beva__defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 42 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_kv.bemd_0(1049317738);
bevt_2_tmpany_phold = bevp_overrides.bem_has_1(bevt_3_tmpany_phold);
if (!(bevt_2_tmpany_phold.bevi_bool)) /* Line: 43 */ {
bevt_4_tmpany_phold = bevl_kv.bemd_0(312620823);
bevt_4_tmpany_phold.bemd_2(-416924427, bevp_defaultOutputLevel, bevp_defaultLevel);
} /* Line: 44 */
} /* Line: 43 */
 else  /* Line: 42 */ {
break;
} /* Line: 42 */
} /* Line: 42 */
bevp_lock.bem_unlock_0();
} /* Line: 47 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 49 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_putKeyLevels_3(BEC_2_4_6_TextString beva_key, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 54 */ {
bevp_lock.bem_lock_0();
bevp_overrides.bem_put_1(beva_key);
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevl_log = (BEC_2_2_3_IOLog) (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, beva_level, beva_outputLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevl_log.bem_levelSet_1(beva_level);
bevl_log.bem_outputLevelSet_1(beva_outputLevel);
} /* Line: 64 */
bevp_lock.bem_unlock_0();
} /* Line: 66 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 68 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_putLevels_3(BEC_2_6_6_SystemObject beva_inst, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_inst.bemd_0(222096027);
bem_putKeyLevels_3((BEC_2_4_6_TextString) bevt_0_tmpany_phold , beva_level, beva_outputLevel);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_getKey_1(BEC_2_4_6_TextString beva_key) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 77 */ {
bevp_lock.bem_lock_0();
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevl_log = (BEC_2_2_3_IOLog) (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, bevp_defaultOutputLevel, bevp_defaultLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 82 */
bevp_lock.bem_unlock_0();
} /* Line: 84 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 86 */
return bevl_log;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_get_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_2_3_IOLog bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_inst.bemd_0(222096027);
bevt_0_tmpany_phold = bem_getKey_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_turnOn_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
try  /* Line: 96 */ {
bevp_lock.bem_lock_0();
bevl_log = bem_get_1(beva_inst);
bevt_0_tmpany_phold = bevl_log.bem_levelGet_0();
bevt_1_tmpany_phold = bevl_log.bem_levelGet_0();
bem_putLevels_3(beva_inst, bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevp_lock.bem_unlock_0();
} /* Line: 100 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 102 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_turnOnAll_0() {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
try  /* Line: 107 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = bevp_defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 110 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_kv.bemd_0(312620823);
bevt_2_tmpany_phold.bemd_1(1193228587, bevp_defaultOutputLevel);
bevt_3_tmpany_phold = bevl_kv.bemd_0(312620823);
bevt_3_tmpany_phold.bemd_1(1966007854, bevp_defaultLevel);
} /* Line: 112 */
 else  /* Line: 110 */ {
break;
} /* Line: 110 */
} /* Line: 110 */
bevp_lock.bem_unlock_0();
} /* Line: 114 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 116 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_setAllSinks_1(BEC_2_6_6_SystemObject beva__sink) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
try  /* Line: 121 */ {
bevp_lock.bem_lock_0();
bevp_sink = beva__sink;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 124 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_kv.bemd_0(312620823);
bevt_2_tmpany_phold.bemd_1(-538733103, beva__sink);
} /* Line: 125 */
 else  /* Line: 124 */ {
break;
} /* Line: 124 */
} /* Line: 124 */
bevp_lock.bem_unlock_0();
} /* Line: 127 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 129 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public BEC_2_4_3_MathInt bem_debugGetDirect_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_debugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_infoGet_0() {
return bevp_info;
} /*method end*/
public BEC_2_4_3_MathInt bem_infoGetDirect_0() {
return bevp_info;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_infoSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_warnGet_0() {
return bevp_warn;
} /*method end*/
public BEC_2_4_3_MathInt bem_warnGetDirect_0() {
return bevp_warn;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_warnSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_errorGet_0() {
return bevp_error;
} /*method end*/
public BEC_2_4_3_MathInt bem_errorGetDirect_0() {
return bevp_error;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_errorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_fatalGet_0() {
return bevp_fatal;
} /*method end*/
public BEC_2_4_3_MathInt bem_fatalGetDirect_0() {
return bevp_fatal;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_fatalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_overridesGet_0() {
return bevp_overrides;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_overridesGetDirect_0() {
return bevp_overrides;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_overridesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_overridesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_loggersGet_0() {
return bevp_loggers;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_loggersGetDirect_0() {
return bevp_loggers;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_loggersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_loggersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_defaultOutputLevelGet_0() {
return bevp_defaultOutputLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultOutputLevelGetDirect_0() {
return bevp_defaultOutputLevel;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_defaultOutputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultOutputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_defaultLevelGet_0() {
return bevp_defaultLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultLevelGetDirect_0() {
return bevp_defaultLevel;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_defaultLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sinkGet_0() {
return bevp_sink;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGetDirect_0() {
return bevp_sink;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {19, 20, 21, 22, 23, 24, 25, 26, 28, 29, 39, 40, 41, 42, 0, 42, 42, 43, 43, 44, 44, 47, 49, 55, 56, 58, 59, 59, 60, 61, 63, 64, 66, 68, 73, 73, 78, 79, 80, 80, 81, 82, 84, 86, 88, 92, 92, 92, 97, 98, 99, 99, 99, 100, 102, 108, 109, 110, 0, 110, 110, 111, 111, 112, 112, 114, 116, 122, 123, 124, 0, 124, 124, 125, 125, 127, 129, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 45, 46, 47, 48, 48, 51, 53, 54, 55, 57, 58, 65, 69, 78, 79, 80, 81, 86, 87, 88, 91, 92, 94, 98, 104, 105, 113, 114, 115, 120, 121, 122, 124, 128, 130, 135, 136, 137, 145, 146, 147, 148, 149, 150, 154, 166, 167, 168, 168, 171, 173, 174, 175, 176, 177, 183, 187, 198, 199, 200, 200, 203, 205, 206, 207, 213, 217, 222, 225, 228, 232, 236, 239, 242, 246, 250, 253, 256, 260, 264, 267, 270, 274, 278, 281, 284, 288, 292, 295, 298, 302, 306, 309, 312, 316, 320, 323, 326, 330, 334, 337, 340, 344, 348, 351, 354, 358, 362, 365, 368, 372};
/* BEGIN LINEINFO 
assign 1 19 24
new 0 19 24
assign 1 20 25
new 0 20 25
assign 1 21 26
new 0 21 26
assign 1 22 27
new 0 22 27
assign 1 23 28
new 0 23 28
assign 1 24 29
new 0 24 29
assign 1 25 30
new 0 25 30
assign 1 26 31
new 0 26 31
assign 1 28 32
assign 1 29 33
lock 0 39 45
assign 1 40 46
assign 1 41 47
assign 1 42 48
mapIteratorGet 0 0 48
assign 1 42 51
hasNextGet 0 42 51
assign 1 42 53
nextGet 0 42 53
assign 1 43 54
keyGet 0 43 54
assign 1 43 55
has 1 43 55
assign 1 44 57
valueGet 0 44 57
setLevels 2 44 58
unlock 0 47 65
unlock 0 49 69
lock 0 55 78
put 1 56 79
assign 1 58 80
get 1 58 80
assign 1 59 81
undef 1 59 86
assign 1 60 87
new 3 60 87
put 2 61 88
levelSet 1 63 91
outputLevelSet 1 64 92
unlock 0 66 94
unlock 0 68 98
assign 1 73 104
classNameGet 0 73 104
putKeyLevels 3 73 105
lock 0 78 113
assign 1 79 114
get 1 79 114
assign 1 80 115
undef 1 80 120
assign 1 81 121
new 3 81 121
put 2 82 122
unlock 0 84 124
unlock 0 86 128
return 1 88 130
assign 1 92 135
classNameGet 0 92 135
assign 1 92 136
getKey 1 92 136
return 1 92 137
lock 0 97 145
assign 1 98 146
get 1 98 146
assign 1 99 147
levelGet 0 99 147
assign 1 99 148
levelGet 0 99 148
putLevels 3 99 149
unlock 0 100 150
unlock 0 102 154
lock 0 108 166
assign 1 109 167
assign 1 110 168
mapIteratorGet 0 0 168
assign 1 110 171
hasNextGet 0 110 171
assign 1 110 173
nextGet 0 110 173
assign 1 111 174
valueGet 0 111 174
outputLevelSet 1 111 175
assign 1 112 176
valueGet 0 112 176
levelSet 1 112 177
unlock 0 114 183
unlock 0 116 187
lock 0 122 198
assign 1 123 199
assign 1 124 200
mapIteratorGet 0 0 200
assign 1 124 203
hasNextGet 0 124 203
assign 1 124 205
nextGet 0 124 205
assign 1 125 206
valueGet 0 125 206
sinkSet 1 125 207
unlock 0 127 213
unlock 0 129 217
return 1 0 222
return 1 0 225
assign 1 0 228
assign 1 0 232
return 1 0 236
return 1 0 239
assign 1 0 242
assign 1 0 246
return 1 0 250
return 1 0 253
assign 1 0 256
assign 1 0 260
return 1 0 264
return 1 0 267
assign 1 0 270
assign 1 0 274
return 1 0 278
return 1 0 281
assign 1 0 284
assign 1 0 288
return 1 0 292
return 1 0 295
assign 1 0 298
assign 1 0 302
return 1 0 306
return 1 0 309
assign 1 0 312
assign 1 0 316
return 1 0 320
return 1 0 323
assign 1 0 326
assign 1 0 330
return 1 0 334
return 1 0 337
assign 1 0 340
assign 1 0 344
return 1 0 348
return 1 0 351
assign 1 0 354
assign 1 0 358
return 1 0 362
return 1 0 365
assign 1 0 368
assign 1 0 372
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1366617398: return bem_tagGet_0();
case -1812137924: return bem_sinkGetDirect_0();
case 222096027: return bem_classNameGet_0();
case 306116222: return bem_echo_0();
case 2119098947: return bem_serializeContents_0();
case 1439692006: return bem_warnGet_0();
case 434654272: return bem_hashGet_0();
case -1985717472: return bem_defaultOutputLevelGet_0();
case 1803521187: return bem_deserializeClassNameGet_0();
case 1747475389: return bem_many_0();
case 1999868679: return bem_fieldIteratorGet_0();
case 342536267: return bem_overridesGet_0();
case -1365182072: return bem_sourceFileNameGet_0();
case -1219673974: return bem_toString_0();
case -1141049131: return bem_iteratorGet_0();
case -31410563: return bem_once_0();
case -14767827: return bem_serializeToString_0();
case 1612622076: return bem_serializationIteratorGet_0();
case 1544585223: return bem_turnOnAll_0();
case -256194891: return bem_default_0();
case -1510598728: return bem_defaultOutputLevelGetDirect_0();
case -100613197: return bem_overridesGetDirect_0();
case -1806050530: return bem_lockGetDirect_0();
case -1121300979: return bem_fieldNamesGet_0();
case -1008455832: return bem_infoGet_0();
case -2076976184: return bem_loggersGetDirect_0();
case -51910082: return bem_debugGet_0();
case -581504360: return bem_fatalGetDirect_0();
case 409261586: return bem_loggersGet_0();
case -102122591: return bem_errorGet_0();
case 1465629387: return bem_defaultLevelGet_0();
case 1284638408: return bem_lockGet_0();
case -997228445: return bem_errorGetDirect_0();
case 216845033: return bem_new_0();
case 1115258825: return bem_create_0();
case 1801694719: return bem_copy_0();
case -1285723842: return bem_fatalGet_0();
case 1704970925: return bem_defaultLevelGetDirect_0();
case 52606816: return bem_sinkGet_0();
case -490636577: return bem_debugGetDirect_0();
case -2016997496: return bem_print_0();
case 562749973: return bem_infoGetDirect_0();
case -1194274080: return bem_toAny_0();
case -1604634115: return bem_warnGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -240164168: return bem_undefined_1(bevd_0);
case 1328880405: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1222686317: return bem_warnSet_1(bevd_0);
case 1061436860: return bem_infoSetDirect_1(bevd_0);
case -26559335: return bem_debugSetDirect_1(bevd_0);
case 242241885: return bem_defaultOutputLevelSetDirect_1(bevd_0);
case 678596289: return bem_defaultLevelSetDirect_1(bevd_0);
case -538733103: return bem_sinkSet_1(bevd_0);
case 990384501: return bem_warnSetDirect_1(bevd_0);
case -1445837181: return bem_overridesSet_1(bevd_0);
case -2108210100: return bem_otherClass_1(bevd_0);
case -1698831397: return bem_undef_1(bevd_0);
case -219683086: return bem_otherType_1(bevd_0);
case -830380765: return bem_sameType_1(bevd_0);
case -2103528320: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -993685004: return bem_defaultLevelSet_1(bevd_0);
case 1027057672: return bem_def_1(bevd_0);
case -2008483487: return bem_fatalSetDirect_1(bevd_0);
case -500708291: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1556510073: return bem_overridesSetDirect_1(bevd_0);
case -901256688: return bem_get_1(bevd_0);
case 1548474334: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2055886847: return bem_fatalSet_1(bevd_0);
case 898619757: return bem_getKey_1((BEC_2_4_6_TextString) bevd_0);
case 1682928031: return bem_copyTo_1(bevd_0);
case 185356435: return bem_notEquals_1(bevd_0);
case 1411254985: return bem_errorSet_1(bevd_0);
case 344109908: return bem_defaultOutputLevelSet_1(bevd_0);
case -1746651946: return bem_defined_1(bevd_0);
case -275853582: return bem_lockSet_1(bevd_0);
case -1941122612: return bem_errorSetDirect_1(bevd_0);
case -239392275: return bem_debugSet_1(bevd_0);
case 2015118514: return bem_loggersSet_1(bevd_0);
case -50515247: return bem_infoSet_1(bevd_0);
case -1524366942: return bem_sameClass_1(bevd_0);
case -631893096: return bem_sinkSetDirect_1(bevd_0);
case 1891349788: return bem_sameObject_1(bevd_0);
case 1616263570: return bem_lockSetDirect_1(bevd_0);
case -1987237715: return bem_turnOn_1(bevd_0);
case -1246021533: return bem_equals_1(bevd_0);
case -591805468: return bem_loggersSetDirect_1(bevd_0);
case -1588230316: return bem_setAllSinks_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1230596881: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -350484263: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 173960944: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1232647657: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1252060647: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1544152464: return bem_setDefaultLevels_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -329498362: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1709660263: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -370891077: return bem_putKeyLevels_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 790969970: return bem_putLevels_3(bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOLogs_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_4_IOLogs_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_4_IOLogs();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst = (BEC_2_2_4_IOLogs) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_type;
}
}
}
