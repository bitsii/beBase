namespace be {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_4_IOLogs : BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOLogs() { }
static BEC_2_2_4_IOLogs() { }
private static byte[] becc_BEC_2_2_4_IOLogs_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67,0x73};
private static byte[] becc_BEC_2_2_4_IOLogs_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
public static new BEC_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_inst;

public static new BET_2_2_4_IOLogs bece_BEC_2_2_4_IOLogs_bevs_type;

public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_9_3_ContainerSet bevp_overrides;
public BEC_2_9_3_ContainerMap bevp_loggers;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_4_3_MathInt bevp_defaultOutputLevel;
public BEC_2_4_3_MathInt bevp_defaultLevel;
public BEC_2_6_6_SystemObject bevp_sink;
public virtual BEC_2_2_4_IOLogs bem_default_0() {
bevp_debug = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(400));
bevp_info = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(300));
bevp_warn = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(200));
bevp_error = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(100));
bevp_fatal = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_overrides = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_loggers = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_defaultOutputLevel = bevp_error;
bevp_defaultLevel = bevp_info;
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_setDefaultLevels_2(BEC_2_4_3_MathInt beva__defaultOutputLevel, BEC_2_4_3_MathInt beva__defaultLevel) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
try  /* Line: 37 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = beva__defaultOutputLevel;
bevp_defaultLevel = beva__defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 41 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 41 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_kv.bemd_0(137873176);
bevt_2_tmpany_phold = bevp_overrides.bem_has_1(bevt_3_tmpany_phold);
if (!(bevt_2_tmpany_phold.bevi_bool)) /* Line: 42 */ {
bevt_4_tmpany_phold = bevl_kv.bemd_0(-398083469);
bevt_4_tmpany_phold.bemd_2(-1216307682, bevp_defaultOutputLevel, bevp_defaultLevel);
} /* Line: 43 */
} /* Line: 42 */
 else  /* Line: 41 */ {
break;
} /* Line: 41 */
} /* Line: 41 */
bevp_lock.bem_unlock_0();
} /* Line: 46 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 48 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_putKeyLevels_3(BEC_2_4_6_TextString beva_key, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 53 */ {
bevp_lock.bem_lock_0();
bevp_overrides.bem_put_1(beva_key);
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
bevl_log = (BEC_2_2_3_IOLog) (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, beva_level, beva_outputLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 60 */
 else  /* Line: 61 */ {
bevl_log.bem_levelSet_1(beva_level);
bevl_log.bem_outputLevelSet_1(beva_outputLevel);
} /* Line: 63 */
bevp_lock.bem_unlock_0();
} /* Line: 65 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 67 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_putLevels_3(BEC_2_6_6_SystemObject beva_inst, BEC_2_4_3_MathInt beva_level, BEC_2_4_3_MathInt beva_outputLevel) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_inst.bemd_0(353377191);
bem_putKeyLevels_3((BEC_2_4_6_TextString) bevt_0_tmpany_phold , beva_level, beva_outputLevel);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_getKey_1(BEC_2_4_6_TextString beva_key) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
try  /* Line: 76 */ {
bevp_lock.bem_lock_0();
bevl_log = (BEC_2_2_3_IOLog) bevp_loggers.bem_get_1(beva_key);
if (bevl_log == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 79 */ {
bevl_log = (BEC_2_2_3_IOLog) (new BEC_2_2_3_IOLog()).bem_new_3(bevp_sink, bevp_defaultOutputLevel, bevp_defaultLevel);
bevp_loggers.bem_put_2(beva_key, bevl_log);
} /* Line: 81 */
bevp_lock.bem_unlock_0();
} /* Line: 83 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 85 */
return bevl_log;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_get_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_2_3_IOLog bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_inst.bemd_0(353377191);
bevt_0_tmpany_phold = bem_getKey_1((BEC_2_4_6_TextString) bevt_1_tmpany_phold );
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_turnOn_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_2_3_IOLog bevl_log = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
try  /* Line: 95 */ {
bevp_lock.bem_lock_0();
bevl_log = bem_get_1(beva_inst);
bevt_0_tmpany_phold = bevl_log.bem_levelGet_0();
bevt_1_tmpany_phold = bevl_log.bem_levelGet_0();
bem_putLevels_3(beva_inst, bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevp_lock.bem_unlock_0();
} /* Line: 99 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 101 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_turnOnAll_0() {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
try  /* Line: 106 */ {
bevp_lock.bem_lock_0();
bevp_defaultOutputLevel = bevp_defaultLevel;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 109 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_kv.bemd_0(-398083469);
bevt_2_tmpany_phold.bemd_1(-1274998882, bevp_defaultOutputLevel);
bevt_3_tmpany_phold = bevl_kv.bemd_0(-398083469);
bevt_3_tmpany_phold.bemd_1(24237166, bevp_defaultLevel);
} /* Line: 111 */
 else  /* Line: 109 */ {
break;
} /* Line: 109 */
} /* Line: 109 */
bevp_lock.bem_unlock_0();
} /* Line: 113 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 115 */
return this;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_setAllSinks_1(BEC_2_6_6_SystemObject beva__sink) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
try  /* Line: 120 */ {
bevp_lock.bem_lock_0();
bevp_sink = beva__sink;
bevt_0_tmpany_loop = bevp_loggers.bem_mapIteratorGet_0();
while (true)
 /* Line: 123 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevl_kv = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_kv.bemd_0(-398083469);
bevt_2_tmpany_phold.bemd_1(-1844173696, beva__sink);
} /* Line: 124 */
 else  /* Line: 123 */ {
break;
} /* Line: 123 */
} /* Line: 123 */
bevp_lock.bem_unlock_0();
} /* Line: 126 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
} /* Line: 128 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public BEC_2_4_3_MathInt bem_debugGetDirect_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_debugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_infoGet_0() {
return bevp_info;
} /*method end*/
public BEC_2_4_3_MathInt bem_infoGetDirect_0() {
return bevp_info;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_infoSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_warnGet_0() {
return bevp_warn;
} /*method end*/
public BEC_2_4_3_MathInt bem_warnGetDirect_0() {
return bevp_warn;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_warnSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_errorGet_0() {
return bevp_error;
} /*method end*/
public BEC_2_4_3_MathInt bem_errorGetDirect_0() {
return bevp_error;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_errorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_fatalGet_0() {
return bevp_fatal;
} /*method end*/
public BEC_2_4_3_MathInt bem_fatalGetDirect_0() {
return bevp_fatal;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_fatalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_overridesGet_0() {
return bevp_overrides;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_overridesGetDirect_0() {
return bevp_overrides;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_overridesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_overridesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_overrides = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_loggersGet_0() {
return bevp_loggers;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_loggersGetDirect_0() {
return bevp_loggers;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_loggersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_loggersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loggers = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_defaultOutputLevelGet_0() {
return bevp_defaultOutputLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultOutputLevelGetDirect_0() {
return bevp_defaultOutputLevel;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_defaultOutputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultOutputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultOutputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_defaultLevelGet_0() {
return bevp_defaultLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_defaultLevelGetDirect_0() {
return bevp_defaultLevel;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_defaultLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_defaultLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defaultLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sinkGet_0() {
return bevp_sink;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGetDirect_0() {
return bevp_sink;
} /*method end*/
public virtual BEC_2_2_4_IOLogs bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOLogs bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sink = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 38, 39, 40, 41, 0, 41, 41, 42, 42, 43, 43, 46, 48, 54, 55, 57, 58, 58, 59, 60, 62, 63, 65, 67, 72, 72, 77, 78, 79, 79, 80, 81, 83, 85, 87, 91, 91, 91, 96, 97, 98, 98, 98, 99, 101, 107, 108, 109, 0, 109, 109, 110, 110, 111, 111, 113, 115, 121, 122, 123, 0, 123, 123, 124, 124, 126, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 45, 46, 47, 48, 48, 51, 53, 54, 55, 57, 58, 65, 69, 78, 79, 80, 81, 86, 87, 88, 91, 92, 94, 98, 104, 105, 113, 114, 115, 120, 121, 122, 124, 128, 130, 135, 136, 137, 145, 146, 147, 148, 149, 150, 154, 166, 167, 168, 168, 171, 173, 174, 175, 176, 177, 183, 187, 198, 199, 200, 200, 203, 205, 206, 207, 213, 217, 222, 225, 228, 232, 236, 239, 242, 246, 250, 253, 256, 260, 264, 267, 270, 274, 278, 281, 284, 288, 292, 295, 298, 302, 306, 309, 312, 316, 320, 323, 326, 330, 334, 337, 340, 344, 348, 351, 354, 358, 362, 365, 368, 372};
/* BEGIN LINEINFO 
assign 1 18 24
new 0 18 24
assign 1 19 25
new 0 19 25
assign 1 20 26
new 0 20 26
assign 1 21 27
new 0 21 27
assign 1 22 28
new 0 22 28
assign 1 23 29
new 0 23 29
assign 1 24 30
new 0 24 30
assign 1 25 31
new 0 25 31
assign 1 27 32
assign 1 28 33
lock 0 38 45
assign 1 39 46
assign 1 40 47
assign 1 41 48
mapIteratorGet 0 0 48
assign 1 41 51
hasNextGet 0 41 51
assign 1 41 53
nextGet 0 41 53
assign 1 42 54
keyGet 0 42 54
assign 1 42 55
has 1 42 55
assign 1 43 57
valueGet 0 43 57
setLevels 2 43 58
unlock 0 46 65
unlock 0 48 69
lock 0 54 78
put 1 55 79
assign 1 57 80
get 1 57 80
assign 1 58 81
undef 1 58 86
assign 1 59 87
new 3 59 87
put 2 60 88
levelSet 1 62 91
outputLevelSet 1 63 92
unlock 0 65 94
unlock 0 67 98
assign 1 72 104
classNameGet 0 72 104
putKeyLevels 3 72 105
lock 0 77 113
assign 1 78 114
get 1 78 114
assign 1 79 115
undef 1 79 120
assign 1 80 121
new 3 80 121
put 2 81 122
unlock 0 83 124
unlock 0 85 128
return 1 87 130
assign 1 91 135
classNameGet 0 91 135
assign 1 91 136
getKey 1 91 136
return 1 91 137
lock 0 96 145
assign 1 97 146
get 1 97 146
assign 1 98 147
levelGet 0 98 147
assign 1 98 148
levelGet 0 98 148
putLevels 3 98 149
unlock 0 99 150
unlock 0 101 154
lock 0 107 166
assign 1 108 167
assign 1 109 168
mapIteratorGet 0 0 168
assign 1 109 171
hasNextGet 0 109 171
assign 1 109 173
nextGet 0 109 173
assign 1 110 174
valueGet 0 110 174
outputLevelSet 1 110 175
assign 1 111 176
valueGet 0 111 176
levelSet 1 111 177
unlock 0 113 183
unlock 0 115 187
lock 0 121 198
assign 1 122 199
assign 1 123 200
mapIteratorGet 0 0 200
assign 1 123 203
hasNextGet 0 123 203
assign 1 123 205
nextGet 0 123 205
assign 1 124 206
valueGet 0 124 206
sinkSet 1 124 207
unlock 0 126 213
unlock 0 128 217
return 1 0 222
return 1 0 225
assign 1 0 228
assign 1 0 232
return 1 0 236
return 1 0 239
assign 1 0 242
assign 1 0 246
return 1 0 250
return 1 0 253
assign 1 0 256
assign 1 0 260
return 1 0 264
return 1 0 267
assign 1 0 270
assign 1 0 274
return 1 0 278
return 1 0 281
assign 1 0 284
assign 1 0 288
return 1 0 292
return 1 0 295
assign 1 0 298
assign 1 0 302
return 1 0 306
return 1 0 309
assign 1 0 312
assign 1 0 316
return 1 0 320
return 1 0 323
assign 1 0 326
assign 1 0 330
return 1 0 334
return 1 0 337
assign 1 0 340
assign 1 0 344
return 1 0 348
return 1 0 351
assign 1 0 354
assign 1 0 358
return 1 0 362
return 1 0 365
assign 1 0 368
assign 1 0 372
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 237106258: return bem_default_0();
case -1116660494: return bem_sinkGetDirect_0();
case 1776712568: return bem_iteratorGet_0();
case 54812233: return bem_overridesGetDirect_0();
case 432493916: return bem_infoGet_0();
case -856707590: return bem_tagGet_0();
case 681361000: return bem_warnGetDirect_0();
case 1226029206: return bem_loggersGet_0();
case 1136476774: return bem_sourceFileNameGet_0();
case 1365471067: return bem_print_0();
case -41150987: return bem_warnGet_0();
case -863944996: return bem_fatalGetDirect_0();
case 466970608: return bem_turnOnAll_0();
case -723282878: return bem_serializeContents_0();
case 353377191: return bem_classNameGet_0();
case -1832062139: return bem_errorGet_0();
case -1237274197: return bem_overridesGet_0();
case -1045627857: return bem_create_0();
case 105768045: return bem_debugGetDirect_0();
case 756642383: return bem_fieldNamesGet_0();
case -1723287273: return bem_fieldIteratorGet_0();
case -1892091547: return bem_fatalGet_0();
case 1426474238: return bem_once_0();
case -1303115743: return bem_hashGet_0();
case -835303456: return bem_many_0();
case -1287943088: return bem_copy_0();
case -880479170: return bem_debugGet_0();
case 1128845831: return bem_lockGet_0();
case -1995851177: return bem_loggersGetDirect_0();
case 1963695386: return bem_toString_0();
case -2134967378: return bem_sinkGet_0();
case 805348767: return bem_serializationIteratorGet_0();
case 1759304586: return bem_defaultLevelGet_0();
case 1874076487: return bem_defaultLevelGetDirect_0();
case 914726274: return bem_defaultOutputLevelGet_0();
case -348782970: return bem_serializeToString_0();
case 219217934: return bem_defaultOutputLevelGetDirect_0();
case 1340694490: return bem_new_0();
case 2052914582: return bem_lockGetDirect_0();
case 1690848108: return bem_echo_0();
case 417915623: return bem_infoGetDirect_0();
case -2091217929: return bem_toAny_0();
case -1486839688: return bem_deserializeClassNameGet_0();
case -352407603: return bem_errorGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1964182658: return bem_turnOn_1(bevd_0);
case 108686021: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1563694476: return bem_errorSetDirect_1(bevd_0);
case -1547411535: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -658383575: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1230070871: return bem_defaultOutputLevelSetDirect_1(bevd_0);
case -27700260: return bem_loggersSetDirect_1(bevd_0);
case -1066324647: return bem_undefined_1(bevd_0);
case 2019573927: return bem_fatalSet_1(bevd_0);
case -1412377002: return bem_undef_1(bevd_0);
case 1680939498: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1026559917: return bem_setAllSinks_1(bevd_0);
case 1685164654: return bem_debugSet_1(bevd_0);
case 1405911029: return bem_sameType_1(bevd_0);
case -356881209: return bem_lockSetDirect_1(bevd_0);
case -100895294: return bem_lockSet_1(bevd_0);
case -1844173696: return bem_sinkSet_1(bevd_0);
case 567969860: return bem_warnSet_1(bevd_0);
case -242127238: return bem_defaultLevelSet_1(bevd_0);
case -550139783: return bem_otherType_1(bevd_0);
case 674421585: return bem_notEquals_1(bevd_0);
case 552408661: return bem_fatalSetDirect_1(bevd_0);
case 1023382552: return bem_infoSetDirect_1(bevd_0);
case -1465221789: return bem_sameClass_1(bevd_0);
case -1240663197: return bem_copyTo_1(bevd_0);
case -760092769: return bem_overridesSetDirect_1(bevd_0);
case 215037794: return bem_infoSet_1(bevd_0);
case 1271932324: return bem_errorSet_1(bevd_0);
case 556895144: return bem_get_1(bevd_0);
case -1418613803: return bem_defaultLevelSetDirect_1(bevd_0);
case 958006792: return bem_overridesSet_1(bevd_0);
case -181259279: return bem_sinkSetDirect_1(bevd_0);
case -1992305809: return bem_defaultOutputLevelSet_1(bevd_0);
case 1275473814: return bem_debugSetDirect_1(bevd_0);
case -1069707608: return bem_sameObject_1(bevd_0);
case -480348635: return bem_def_1(bevd_0);
case -589398111: return bem_loggersSet_1(bevd_0);
case 276751456: return bem_warnSetDirect_1(bevd_0);
case 1925822948: return bem_getKey_1((BEC_2_4_6_TextString) bevd_0);
case 1949406125: return bem_equals_1(bevd_0);
case -793887534: return bem_otherClass_1(bevd_0);
case 2129603513: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1449839410: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1793154643: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1833947306: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -57841353: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2093472433: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 883719261: return bem_setDefaultLevels_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 391616877: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2031849090: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 735287326: return bem_putLevels_3(bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1669644160: return bem_putKeyLevels_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(7, becc_BEC_2_2_4_IOLogs_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_4_IOLogs_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_4_IOLogs();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst = (BEC_2_2_4_IOLogs) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_4_IOLogs.bece_BEC_2_2_4_IOLogs_bevs_type;
}
}
}
