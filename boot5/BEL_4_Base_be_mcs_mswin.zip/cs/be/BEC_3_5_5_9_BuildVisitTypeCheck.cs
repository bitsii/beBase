namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_9_BuildVisitTypeCheck : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
static BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x61,0x6E,0x79,0x29};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_2 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_2, 13));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_3 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_3, 13));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_4 = {0x28,0x42,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_4, 17));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_5 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_5, 10));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_6 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x61,0x6E,0x79,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_7 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_7, 30));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_8 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_8, 19));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_9 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_11 = {0x73,0x65,0x6C,0x66};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_13, 67));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_14 = {0x20};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_14, 1));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_15 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_16 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_17 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_18 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_18, 13));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_19 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_19, 13));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_20 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_20, 13));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_21 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_21, 10));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_22 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_23 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x61,0x6E,0x79,0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_23, 19));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_24 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_24, 13));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_25 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_25, 13));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_26 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_26, 52));
private static byte[] BEC_3_5_5_9_BuildVisitTypeCheck_bels_27 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(BEC_3_5_5_9_BuildVisitTypeCheck_bels_27, 5));
public static new BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cany = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_4_ContainerList bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_5_8_BuildClassSyn bevl_argSyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_115_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_4_6_TextString bevt_142_tmpany_phold = null;
BEC_2_4_6_TextString bevt_143_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_144_tmpany_phold = null;
BEC_2_4_6_TextString bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_4_6_TextString bevt_155_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_156_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_181_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_182_tmpany_phold = null;
BEC_2_4_6_TextString bevt_183_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpany_phold = null;
BEC_2_4_6_TextString bevt_191_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_197_tmpany_phold = null;
BEC_2_4_6_TextString bevt_198_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_200_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_204_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_206_tmpany_phold = null;
BEC_2_4_6_TextString bevt_207_tmpany_phold = null;
BEC_2_4_6_TextString bevt_208_tmpany_phold = null;
BEC_2_4_6_TextString bevt_209_tmpany_phold = null;
BEC_2_4_6_TextString bevt_210_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpany_phold = null;
BEC_2_4_6_TextString bevt_212_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_219_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_220_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_224_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_227_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_228_tmpany_phold = null;
BEC_2_4_6_TextString bevt_229_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_231_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_233_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_234_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_238_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_239_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_240_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_241_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_242_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_243_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_244_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_245_tmpany_phold = null;
BEC_2_4_6_TextString bevt_246_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_247_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_248_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_249_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_250_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_251_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_252_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_253_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_254_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_255_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_256_tmpany_phold = null;
BEC_2_4_6_TextString bevt_257_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_258_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_259_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_260_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_261_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_262_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_263_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_264_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_265_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_267_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_268_tmpany_phold = null;
BEC_2_4_6_TextString bevt_269_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_270_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_271_tmpany_phold = null;
BEC_2_4_6_TextString bevt_272_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_273_tmpany_phold = null;
BEC_2_4_6_TextString bevt_274_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_276_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_277_tmpany_phold = null;
BEC_2_4_6_TextString bevt_278_tmpany_phold = null;
BEC_2_4_6_TextString bevt_279_tmpany_phold = null;
BEC_2_4_6_TextString bevt_280_tmpany_phold = null;
BEC_2_4_6_TextString bevt_281_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_282_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_283_tmpany_phold = null;
BEC_2_4_6_TextString bevt_284_tmpany_phold = null;
BEC_2_4_6_TextString bevt_285_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_286_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_287_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_288_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_289_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_290_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_291_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_292_tmpany_phold = null;
BEC_2_4_6_TextString bevt_293_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_294_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_295_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_296_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_297_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_298_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_299_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_300_tmpany_phold = null;
BEC_2_4_6_TextString bevt_301_tmpany_phold = null;
BEC_2_4_6_TextString bevt_302_tmpany_phold = null;
BEC_2_4_6_TextString bevt_303_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_304_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_305_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_306_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_307_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_308_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_309_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_310_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_311_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_312_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_313_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_314_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_315_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_316_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_317_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_318_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_319_tmpany_phold = null;
BEC_2_4_6_TextString bevt_320_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_321_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_322_tmpany_phold = null;
BEC_2_4_6_TextString bevt_323_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_324_tmpany_phold = null;
BEC_2_4_6_TextString bevt_325_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_326_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_327_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_328_tmpany_phold = null;
BEC_2_4_6_TextString bevt_329_tmpany_phold = null;
BEC_2_4_6_TextString bevt_330_tmpany_phold = null;
BEC_2_4_6_TextString bevt_331_tmpany_phold = null;
BEC_2_4_6_TextString bevt_332_tmpany_phold = null;
BEC_2_4_6_TextString bevt_333_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_334_tmpany_phold = null;
BEC_2_4_6_TextString bevt_335_tmpany_phold = null;
BEC_2_4_6_TextString bevt_336_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_337_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_338_tmpany_phold = null;
bevt_12_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_13_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_12_tmpany_phold.bevi_int == bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_19_tmpany_phold = beva_node.bem_containedGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_firstGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 394 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, BEC_3_5_5_9_BuildVisitTypeCheck_bels_0));
bevt_20_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_21_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 395 */
} /* Line: 394 */
bevt_23_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_24_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_23_tmpany_phold.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevp_inClass = beva_node;
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_25_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_26_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 401 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 403 */ {
bevp_cpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 404 */
bevt_31_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_32_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_31_tmpany_phold.bevi_int == bevt_32_tmpany_phold.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_33_tmpany_phold = beva_node.bem_heldGet_0();
bevt_33_tmpany_phold.bemd_1(-2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_0_tmpany_loop = bevt_34_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 409 */ {
bevt_35_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_35_tmpany_phold != null && bevt_35_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpany_phold).bevi_bool) /* Line: 409 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_37_tmpany_phold = bevl_cci.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevt_39_tmpany_phold = bevl_cci.bem_heldGet_0();
bevt_39_tmpany_phold.bemd_1(-474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 411 */
} /* Line: 410 */
 else  /* Line: 409 */ {
break;
} /* Line: 409 */
} /* Line: 409 */
bevt_42_tmpany_phold = beva_node.bem_heldGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, BEC_3_5_5_9_BuildVisitTypeCheck_bels_1));
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpany_phold);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 422 */ {
bevt_44_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_44_tmpany_phold.bem_firstGet_0();
bevt_46_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 425 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 426 */
 else  /* Line: 427 */ {
bevt_48_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_50_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_49_tmpany_phold);
bevl_tany = bevt_47_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 428 */
bevt_52_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_51_tmpany_phold != null && bevt_51_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_51_tmpany_phold).bevi_bool) /* Line: 431 */ {
bevt_53_tmpany_phold = beva_node.bem_heldGet_0();
bevt_54_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_53_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_54_tmpany_phold);
} /* Line: 432 */
 else  /* Line: 433 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_56_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_57_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_56_tmpany_phold.bevi_int == bevt_57_tmpany_phold.bevi_int) {
bevt_55_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_55_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 435 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 435 */ {
bevt_59_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_60_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_59_tmpany_phold.bevi_int == bevt_60_tmpany_phold.bevi_int) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 435 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 435 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 435 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 435 */ {
bevt_61_tmpany_phold = beva_node.bem_heldGet_0();
bevt_62_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_61_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_62_tmpany_phold);
} /* Line: 437 */
 else  /* Line: 438 */ {
bevt_64_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevt_67_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_66_tmpany_phold != null && bevt_66_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_66_tmpany_phold).bevi_bool) /* Line: 440 */ {
bevl_oany = bevl_org.bem_heldGet_0();
} /* Line: 441 */
 else  /* Line: 442 */ {
bevt_69_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_71_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_70_tmpany_phold);
bevl_oany = bevt_68_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 444 */
} /* Line: 440 */
 else  /* Line: 439 */ {
bevt_73_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_74_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_73_tmpany_phold.bevi_int == bevt_74_tmpany_phold.bevi_int) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 447 */ {
bevt_75_tmpany_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_75_tmpany_phold.bem_firstGet_0();
bevt_77_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_76_tmpany_phold != null && bevt_76_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_76_tmpany_phold).bevi_bool) /* Line: 450 */ {
bevl_cany = bevl_ctarg.bem_heldGet_0();
} /* Line: 452 */
 else  /* Line: 453 */ {
bevt_79_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_81_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_80_tmpany_phold = bevt_81_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_80_tmpany_phold);
bevl_cany = bevt_78_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 455 */
bevl_syn = null;
bevt_84_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_83_tmpany_phold == null) {
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpany_phold.bevi_bool) /* Line: 459 */ {
bevt_86_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_tmpany_phold);
} /* Line: 460 */
 else  /* Line: 459 */ {
bevt_87_tmpany_phold = bevl_cany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_87_tmpany_phold != null && bevt_87_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_87_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevt_88_tmpany_phold = bevl_cany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_88_tmpany_phold);
} /* Line: 463 */
} /* Line: 459 */
if (bevl_syn == null) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 465 */ {
bevt_90_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_92_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_90_tmpany_phold.bem_get_1(bevt_91_tmpany_phold);
if (bevl_mtdc == null) {
bevt_93_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_93_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevt_94_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_95_tmpany_phold = bevo_0;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_94_tmpany_phold.bem_get_1(bevt_95_tmpany_phold);
if (bevl_fcms == null) {
bevt_96_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_96_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_99_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bem_toString_0();
bevt_100_tmpany_phold = bevo_1;
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_notEquals_1(bevt_100_tmpany_phold);
if (bevt_97_tmpany_phold.bevi_bool) /* Line: 469 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 469 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 469 */
 else  /* Line: 469 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 469 */ {
bevt_101_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_102_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_101_tmpany_phold.bemd_1(-1051551207, BEL_4_Base.bevn_isForwardSet_1, bevt_102_tmpany_phold);
} /* Line: 470 */
 else  /* Line: 471 */ {
bevt_107_tmpany_phold = bevo_2;
bevt_109_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevt_108_tmpany_phold);
bevt_110_tmpany_phold = bevo_3;
bevt_105_tmpany_phold = bevt_106_tmpany_phold.bem_add_1(bevt_110_tmpany_phold);
bevt_111_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_add_1(bevt_111_tmpany_phold);
bevt_103_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_104_tmpany_phold, bevl_org);
throw new be.BECS_ThrowBack(bevt_103_tmpany_phold);
} /* Line: 472 */
} /* Line: 469 */
 else  /* Line: 474 */ {
bevl_oany = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 475 */
} /* Line: 467 */
} /* Line: 465 */
} /* Line: 439 */
if (bevl_oany == null) {
bevt_112_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpany_phold.bevi_bool) /* Line: 479 */ {
bevt_113_tmpany_phold = bevl_oany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_113_tmpany_phold != null && bevt_113_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_113_tmpany_phold).bevi_bool) /* Line: 479 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 479 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_114_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 482 */ {
if (bevl_syn == null) {
bevt_115_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_115_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_115_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, BEC_3_5_5_9_BuildVisitTypeCheck_bels_6));
bevt_116_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_117_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_116_tmpany_phold);
} /* Line: 485 */
bevt_119_tmpany_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_120_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_120_tmpany_phold);
if (bevt_118_tmpany_phold != null && bevt_118_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_118_tmpany_phold).bevi_bool) /* Line: 490 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 492 */
 else  /* Line: 490 */ {
bevt_122_tmpany_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_122_tmpany_phold == null) {
bevt_121_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpany_phold.bevi_bool) /* Line: 493 */ {
bevt_125_tmpany_phold = bevp_build.bem_emitCommonGet_0();
bevt_124_tmpany_phold = bevt_125_tmpany_phold.bem_coanyiantReturnsGet_0();
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_123_tmpany_phold != null && bevt_123_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_123_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 493 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 493 */
 else  /* Line: 493 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 493 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 494 */
} /* Line: 490 */
} /* Line: 490 */
 else  /* Line: 482 */ {
if (bevl_mtdc == null) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 496 */ {
bevt_127_tmpany_phold = bevl_mtdc.bemd_2(-583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_127_tmpany_phold);
} /* Line: 497 */
 else  /* Line: 498 */ {
bevt_128_tmpany_phold = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_128_tmpany_phold);
} /* Line: 499 */
} /* Line: 482 */
bevt_130_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_129_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_130_tmpany_phold);
if (bevt_129_tmpany_phold != null && bevt_129_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_129_tmpany_phold).bevi_bool) /* Line: 503 */ {
bevt_131_tmpany_phold = beva_node.bem_heldGet_0();
bevt_132_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_131_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_132_tmpany_phold);
} /* Line: 505 */
 else  /* Line: 506 */ {
bevt_133_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_133_tmpany_phold != null && bevt_133_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_133_tmpany_phold).bevi_bool) /* Line: 507 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 508 */
 else  /* Line: 509 */ {
bevl_ovnp = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 510 */
bevt_134_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_134_tmpany_phold);
bevt_135_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_135_tmpany_phold != null && bevt_135_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_135_tmpany_phold).bevi_bool) /* Line: 513 */ {
bevt_136_tmpany_phold = beva_node.bem_heldGet_0();
bevt_137_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_136_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_137_tmpany_phold);
} /* Line: 515 */
 else  /* Line: 516 */ {
bevt_142_tmpany_phold = bevo_4;
bevt_144_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_143_tmpany_phold = bevt_144_tmpany_phold.bem_toString_0();
bevt_141_tmpany_phold = bevt_142_tmpany_phold.bem_add_1(bevt_143_tmpany_phold);
bevt_145_tmpany_phold = bevo_5;
bevt_140_tmpany_phold = bevt_141_tmpany_phold.bem_add_1(bevt_145_tmpany_phold);
bevt_146_tmpany_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_139_tmpany_phold = bevt_140_tmpany_phold.bem_add_1(bevt_146_tmpany_phold);
bevt_138_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_139_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_138_tmpany_phold);
} /* Line: 517 */
} /* Line: 513 */
if (bevl_castForSelf.bevi_bool) /* Line: 521 */ {
bevt_147_tmpany_phold = beva_node.bem_heldGet_0();
bevt_148_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_147_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_148_tmpany_phold);
} /* Line: 523 */
} /* Line: 521 */
bevt_151_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_150_tmpany_phold == null) {
bevt_149_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_149_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_149_tmpany_phold.bevi_bool) /* Line: 526 */ {
} /* Line: 526 */
} /* Line: 526 */
} /* Line: 435 */
} /* Line: 431 */
 else  /* Line: 422 */ {
bevt_154_tmpany_phold = beva_node.bem_heldGet_0();
bevt_153_tmpany_phold = bevt_154_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_155_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, BEC_3_5_5_9_BuildVisitTypeCheck_bels_9));
bevt_152_tmpany_phold = bevt_153_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_155_tmpany_phold);
if (bevt_152_tmpany_phold != null && bevt_152_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_152_tmpany_phold).bevi_bool) /* Line: 531 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_157_tmpany_phold = bevl_targ.bem_typenameGet_0();
bevt_158_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_157_tmpany_phold.bevi_int == bevt_158_tmpany_phold.bevi_int) {
bevt_156_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_156_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_156_tmpany_phold.bevi_bool) /* Line: 533 */ {
bevt_160_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_159_tmpany_phold = bevt_160_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_159_tmpany_phold != null && bevt_159_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_159_tmpany_phold).bevi_bool) /* Line: 534 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 535 */
 else  /* Line: 536 */ {
bevt_162_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_164_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_163_tmpany_phold = bevt_164_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_163_tmpany_phold);
bevl_tany = bevt_161_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 537 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_166_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_165_tmpany_phold != null && bevt_165_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_165_tmpany_phold).bevi_bool) /* Line: 541 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 542 */
 else  /* Line: 543 */ {
bevt_168_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_170_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_169_tmpany_phold = bevt_170_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_167_tmpany_phold = bevt_168_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_169_tmpany_phold);
bevl_tany = bevt_167_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 544 */
bevt_173_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_172_tmpany_phold = bevt_173_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_172_tmpany_phold == null) {
bevt_171_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_171_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_171_tmpany_phold.bevi_bool) /* Line: 547 */ {
bevt_176_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_175_tmpany_phold = bevt_176_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_174_tmpany_phold = bevt_175_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_174_tmpany_phold != null && bevt_174_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_174_tmpany_phold).bevi_bool) /* Line: 547 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 547 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 547 */
 else  /* Line: 547 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 547 */ {
bevt_178_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_177_tmpany_phold = bevt_178_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_177_tmpany_phold != null && bevt_177_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_177_tmpany_phold).bevi_bool) /* Line: 548 */ {
bevt_181_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_180_tmpany_phold = bevt_181_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_179_tmpany_phold = bevt_180_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_179_tmpany_phold != null && bevt_179_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_179_tmpany_phold).bevi_bool) /* Line: 549 */ {
bevt_183_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, BEC_3_5_5_9_BuildVisitTypeCheck_bels_10));
bevt_182_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_183_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_182_tmpany_phold);
} /* Line: 550 */
bevt_184_tmpany_phold = beva_node.bem_heldGet_0();
bevt_185_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_184_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_185_tmpany_phold);
} /* Line: 553 */
 else  /* Line: 554 */ {
bevt_188_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_187_tmpany_phold = bevt_188_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_186_tmpany_phold = bevt_187_tmpany_phold.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_186_tmpany_phold != null && bevt_186_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_186_tmpany_phold).bevi_bool) /* Line: 557 */ {
bevt_190_tmpany_phold = bevl_tany.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_191_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, BEC_3_5_5_9_BuildVisitTypeCheck_bels_11));
bevt_189_tmpany_phold = bevt_190_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_191_tmpany_phold);
if (bevt_189_tmpany_phold != null && bevt_189_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_189_tmpany_phold).bevi_bool) /* Line: 558 */ {
bevt_192_tmpany_phold = beva_node.bem_heldGet_0();
bevt_193_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_192_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_193_tmpany_phold);
} /* Line: 560 */
 else  /* Line: 561 */ {
bevt_196_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_195_tmpany_phold = bevt_196_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_194_tmpany_phold = bevt_195_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_194_tmpany_phold != null && bevt_194_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_194_tmpany_phold).bevi_bool) /* Line: 562 */ {
bevt_198_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, BEC_3_5_5_9_BuildVisitTypeCheck_bels_12));
bevt_197_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_198_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_197_tmpany_phold);
} /* Line: 563 */
bevt_199_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_199_tmpany_phold);
bevt_201_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_200_tmpany_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_201_tmpany_phold);
if (bevt_200_tmpany_phold != null && bevt_200_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_200_tmpany_phold).bevi_bool) /* Line: 566 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 566 */ {
bevt_203_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_202_tmpany_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_203_tmpany_phold);
if (bevt_202_tmpany_phold != null && bevt_202_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_202_tmpany_phold).bevi_bool) /* Line: 566 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 566 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 566 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 566 */ {
bevt_204_tmpany_phold = beva_node.bem_heldGet_0();
bevt_205_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_204_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_205_tmpany_phold);
} /* Line: 568 */
 else  /* Line: 569 */ {
bevt_210_tmpany_phold = bevo_6;
bevt_211_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_209_tmpany_phold = bevt_210_tmpany_phold.bem_add_1(bevt_211_tmpany_phold);
bevt_212_tmpany_phold = bevo_7;
bevt_208_tmpany_phold = bevt_209_tmpany_phold.bem_add_1(bevt_212_tmpany_phold);
bevt_213_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_207_tmpany_phold = bevt_208_tmpany_phold.bem_add_1(bevt_213_tmpany_phold);
bevt_206_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_207_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_206_tmpany_phold);
} /* Line: 570 */
} /* Line: 566 */
} /* Line: 558 */
 else  /* Line: 573 */ {
bevt_214_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_214_tmpany_phold);
bevt_218_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_217_tmpany_phold = bevt_218_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_216_tmpany_phold = bevt_217_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_215_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_216_tmpany_phold);
if (bevt_215_tmpany_phold != null && bevt_215_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_215_tmpany_phold).bevi_bool) /* Line: 575 */ {
bevt_219_tmpany_phold = beva_node.bem_heldGet_0();
bevt_220_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_219_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_220_tmpany_phold);
} /* Line: 577 */
 else  /* Line: 578 */ {
bevt_223_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_222_tmpany_phold = bevt_223_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_221_tmpany_phold = bevt_222_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_221_tmpany_phold);
bevt_225_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_224_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_225_tmpany_phold);
if (bevt_224_tmpany_phold != null && bevt_224_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_224_tmpany_phold).bevi_bool) /* Line: 580 */ {
bevt_226_tmpany_phold = beva_node.bem_heldGet_0();
bevt_227_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_226_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_227_tmpany_phold);
} /* Line: 582 */
 else  /* Line: 583 */ {
bevt_229_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, BEC_3_5_5_9_BuildVisitTypeCheck_bels_15));
bevt_228_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_229_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_228_tmpany_phold);
} /* Line: 584 */
} /* Line: 580 */
} /* Line: 575 */
} /* Line: 557 */
} /* Line: 548 */
 else  /* Line: 589 */ {
bevt_230_tmpany_phold = beva_node.bem_heldGet_0();
bevt_231_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_230_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_231_tmpany_phold);
} /* Line: 591 */
} /* Line: 547 */
 else  /* Line: 593 */ {
bevt_232_tmpany_phold = beva_node.bem_heldGet_0();
bevt_233_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_232_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_233_tmpany_phold);
} /* Line: 594 */
} /* Line: 533 */
 else  /* Line: 596 */ {
bevt_234_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_234_tmpany_phold.bem_firstGet_0();
bevt_236_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_235_tmpany_phold = bevt_236_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_235_tmpany_phold != null && bevt_235_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_235_tmpany_phold).bevi_bool) /* Line: 599 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 600 */
 else  /* Line: 601 */ {
bevt_238_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_240_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_239_tmpany_phold = bevt_240_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_237_tmpany_phold = bevt_238_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_239_tmpany_phold);
bevl_tany = bevt_237_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 602 */
bevt_242_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_241_tmpany_phold = bevt_242_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_241_tmpany_phold != null && bevt_241_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_241_tmpany_phold).bevi_bool) /* Line: 605 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 605 */ {
bevt_245_tmpany_phold = beva_node.bem_heldGet_0();
bevt_244_tmpany_phold = bevt_245_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_246_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, BEC_3_5_5_9_BuildVisitTypeCheck_bels_16));
bevt_243_tmpany_phold = bevt_244_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_246_tmpany_phold);
if (bevt_243_tmpany_phold != null && bevt_243_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_243_tmpany_phold).bevi_bool) /* Line: 605 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 605 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 605 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 605 */ {
bevt_247_tmpany_phold = beva_node.bem_heldGet_0();
bevt_248_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_247_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_248_tmpany_phold);
} /* Line: 606 */
 else  /* Line: 607 */ {
bevt_249_tmpany_phold = beva_node.bem_heldGet_0();
bevt_250_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_249_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_250_tmpany_phold);
bevt_252_tmpany_phold = beva_node.bem_heldGet_0();
bevt_251_tmpany_phold = bevt_252_tmpany_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_251_tmpany_phold != null && bevt_251_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_251_tmpany_phold).bevi_bool) /* Line: 609 */ {
bevt_255_tmpany_phold = beva_node.bem_heldGet_0();
bevt_254_tmpany_phold = bevt_255_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_254_tmpany_phold == null) {
bevt_253_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_253_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_253_tmpany_phold.bevi_bool) /* Line: 610 */ {
bevt_257_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, BEC_3_5_5_9_BuildVisitTypeCheck_bels_17));
bevt_256_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_257_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_256_tmpany_phold);
} /* Line: 611 */
bevt_259_tmpany_phold = beva_node.bem_heldGet_0();
bevt_258_tmpany_phold = bevt_259_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_258_tmpany_phold);
bevt_260_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_262_tmpany_phold = beva_node.bem_heldGet_0();
bevt_261_tmpany_phold = bevt_262_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_260_tmpany_phold.bem_get_1(bevt_261_tmpany_phold);
} /* Line: 614 */
 else  /* Line: 615 */ {
bevt_263_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_263_tmpany_phold);
bevt_264_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_266_tmpany_phold = beva_node.bem_heldGet_0();
bevt_265_tmpany_phold = bevt_266_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_264_tmpany_phold.bem_get_1(bevt_265_tmpany_phold);
} /* Line: 617 */
if (bevl_mtdc == null) {
bevt_267_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_267_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_267_tmpany_phold.bevi_bool) /* Line: 619 */ {
bevt_268_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_269_tmpany_phold = bevo_8;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_268_tmpany_phold.bem_get_1(bevt_269_tmpany_phold);
if (bevl_fcms == null) {
bevt_270_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_270_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_270_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_273_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_272_tmpany_phold = bevt_273_tmpany_phold.bem_toString_0();
bevt_274_tmpany_phold = bevo_9;
bevt_271_tmpany_phold = bevt_272_tmpany_phold.bem_notEquals_1(bevt_274_tmpany_phold);
if (bevt_271_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 621 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 621 */
 else  /* Line: 621 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 621 */ {
bevt_275_tmpany_phold = beva_node.bem_heldGet_0();
bevt_276_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_275_tmpany_phold.bemd_1(-1051551207, BEL_4_Base.bevn_isForwardSet_1, bevt_276_tmpany_phold);
} /* Line: 622 */
 else  /* Line: 623 */ {
bevt_281_tmpany_phold = bevo_10;
bevt_283_tmpany_phold = beva_node.bem_heldGet_0();
bevt_282_tmpany_phold = bevt_283_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_280_tmpany_phold = bevt_281_tmpany_phold.bem_add_1(bevt_282_tmpany_phold);
bevt_284_tmpany_phold = bevo_11;
bevt_279_tmpany_phold = bevt_280_tmpany_phold.bem_add_1(bevt_284_tmpany_phold);
bevt_286_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_285_tmpany_phold = bevt_286_tmpany_phold.bem_toString_0();
bevt_278_tmpany_phold = bevt_279_tmpany_phold.bem_add_1(bevt_285_tmpany_phold);
bevt_277_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_278_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_277_tmpany_phold);
} /* Line: 624 */
} /* Line: 621 */
if (bevl_mtdc == null) {
bevt_287_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_287_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_287_tmpany_phold.bevi_bool) /* Line: 627 */ {
bevl_argSyns = (BEC_2_9_4_ContainerList) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 630 */ {
bevt_289_tmpany_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_289_tmpany_phold.bevi_int) {
bevt_288_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_288_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_288_tmpany_phold.bevi_bool) /* Line: 630 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_290_tmpany_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_290_tmpany_phold.bevi_bool) /* Line: 632 */ {
if (bevl_nnode == null) {
bevt_291_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_291_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_291_tmpany_phold.bevi_bool) /* Line: 633 */ {
bevt_293_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, BEC_3_5_5_9_BuildVisitTypeCheck_bels_22));
bevt_292_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_293_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_292_tmpany_phold);
} /* Line: 634 */
 else  /* Line: 633 */ {
bevt_295_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_296_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_295_tmpany_phold.bevi_int != bevt_296_tmpany_phold.bevi_int) {
bevt_294_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_294_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_294_tmpany_phold.bevi_bool) /* Line: 635 */ {
bevt_298_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_299_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_298_tmpany_phold.bevi_int != bevt_299_tmpany_phold.bevi_int) {
bevt_297_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_297_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_297_tmpany_phold.bevi_bool) /* Line: 635 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 635 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 635 */
 else  /* Line: 635 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 635 */ {
bevt_302_tmpany_phold = bevo_12;
bevt_304_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_303_tmpany_phold = bevt_304_tmpany_phold.bem_toString_0();
bevt_301_tmpany_phold = bevt_302_tmpany_phold.bem_add_1(bevt_303_tmpany_phold);
bevt_300_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_301_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_300_tmpany_phold);
} /* Line: 636 */
} /* Line: 633 */
bevt_306_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_307_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_306_tmpany_phold.bevi_int == bevt_307_tmpany_phold.bevi_int) {
bevt_305_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_305_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_305_tmpany_phold.bevi_bool) /* Line: 638 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_309_tmpany_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_309_tmpany_phold.bevi_bool) {
bevt_308_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_308_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_308_tmpany_phold.bevi_bool) /* Line: 640 */ {
bevt_310_tmpany_phold = beva_node.bem_heldGet_0();
bevt_311_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_310_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_311_tmpany_phold);
bevt_313_tmpany_phold = beva_node.bem_heldGet_0();
bevt_312_tmpany_phold = bevt_313_tmpany_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_314_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_312_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_314_tmpany_phold);
} /* Line: 642 */
 else  /* Line: 644 */ {
bevt_315_tmpany_phold = bevl_carg.bem_namepathGet_0();
bevl_argSyn = bevp_build.bem_getSynNp_1(bevt_315_tmpany_phold);
bevt_318_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_317_tmpany_phold = bevl_argSyn.bem_castsTo_1(bevt_318_tmpany_phold);
bevt_316_tmpany_phold = bevt_317_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_316_tmpany_phold != null && bevt_316_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_316_tmpany_phold).bevi_bool) /* Line: 646 */ {
bevt_319_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_320_tmpany_phold = bevo_13;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_319_tmpany_phold.bem_get_1(bevt_320_tmpany_phold);
if (bevl_fcms == null) {
bevt_321_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_321_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_321_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_324_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_323_tmpany_phold = bevt_324_tmpany_phold.bem_toString_0();
bevt_325_tmpany_phold = bevo_14;
bevt_322_tmpany_phold = bevt_323_tmpany_phold.bem_notEquals_1(bevt_325_tmpany_phold);
if (bevt_322_tmpany_phold.bevi_bool) /* Line: 648 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 648 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 648 */
 else  /* Line: 648 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 648 */ {
bevt_326_tmpany_phold = beva_node.bem_heldGet_0();
bevt_327_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_326_tmpany_phold.bemd_1(-1051551207, BEL_4_Base.bevn_isForwardSet_1, bevt_327_tmpany_phold);
} /* Line: 649 */
 else  /* Line: 650 */ {
bevt_332_tmpany_phold = bevo_15;
bevt_334_tmpany_phold = bevl_argSyn.bem_namepathGet_0();
bevt_333_tmpany_phold = bevt_334_tmpany_phold.bem_toString_0();
bevt_331_tmpany_phold = bevt_332_tmpany_phold.bem_add_1(bevt_333_tmpany_phold);
bevt_335_tmpany_phold = bevo_16;
bevt_330_tmpany_phold = bevt_331_tmpany_phold.bem_add_1(bevt_335_tmpany_phold);
bevt_337_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_336_tmpany_phold = bevt_337_tmpany_phold.bem_toString_0();
bevt_329_tmpany_phold = bevt_330_tmpany_phold.bem_add_1(bevt_336_tmpany_phold);
bevt_328_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_329_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_328_tmpany_phold);
} /* Line: 651 */
} /* Line: 648 */
} /* Line: 646 */
} /* Line: 640 */
} /* Line: 638 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 630 */
 else  /* Line: 630 */ {
break;
} /* Line: 630 */
} /* Line: 630 */
} /* Line: 630 */
} /* Line: 627 */
} /* Line: 605 */
} /* Line: 422 */
} /* Line: 422 */
bevt_338_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_338_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {393, 393, 393, 393, 394, 394, 394, 394, 394, 394, 395, 395, 395, 398, 398, 398, 398, 399, 400, 400, 401, 401, 403, 403, 403, 403, 404, 406, 406, 406, 406, 407, 407, 408, 409, 409, 0, 409, 409, 410, 410, 410, 410, 411, 411, 422, 422, 422, 422, 423, 423, 425, 425, 426, 428, 428, 428, 428, 428, 431, 431, 432, 432, 432, 434, 435, 435, 435, 435, 0, 435, 435, 435, 435, 0, 0, 437, 437, 437, 439, 439, 439, 439, 440, 440, 441, 444, 444, 444, 444, 444, 447, 447, 447, 447, 448, 448, 450, 450, 452, 455, 455, 455, 455, 455, 458, 459, 459, 459, 459, 460, 460, 460, 461, 463, 463, 465, 465, 466, 466, 466, 466, 467, 467, 468, 468, 468, 469, 469, 469, 469, 469, 469, 0, 0, 0, 470, 470, 470, 472, 472, 472, 472, 472, 472, 472, 472, 472, 472, 475, 479, 479, 479, 0, 0, 0, 481, 482, 484, 484, 485, 485, 485, 490, 490, 490, 492, 493, 493, 493, 493, 493, 493, 0, 0, 0, 494, 496, 496, 497, 497, 499, 499, 503, 503, 505, 505, 505, 507, 508, 510, 512, 512, 513, 515, 515, 515, 517, 517, 517, 517, 517, 517, 517, 517, 517, 517, 523, 523, 523, 526, 526, 526, 526, 531, 531, 531, 531, 532, 533, 533, 533, 533, 534, 534, 535, 537, 537, 537, 537, 537, 540, 541, 541, 542, 544, 544, 544, 544, 544, 547, 547, 547, 547, 547, 547, 547, 0, 0, 0, 548, 548, 549, 549, 549, 550, 550, 550, 553, 553, 553, 557, 557, 557, 558, 558, 558, 560, 560, 560, 562, 562, 562, 563, 563, 563, 565, 565, 566, 566, 0, 566, 566, 0, 0, 568, 568, 568, 570, 570, 570, 570, 570, 570, 570, 570, 570, 574, 574, 575, 575, 575, 575, 577, 577, 577, 579, 579, 579, 579, 580, 580, 582, 582, 582, 584, 584, 584, 591, 591, 591, 594, 594, 594, 597, 597, 599, 599, 600, 602, 602, 602, 602, 602, 605, 605, 0, 605, 605, 605, 605, 0, 0, 606, 606, 606, 608, 608, 608, 609, 609, 610, 610, 610, 610, 611, 611, 611, 613, 613, 613, 614, 614, 614, 614, 616, 616, 617, 617, 617, 617, 619, 619, 620, 620, 620, 621, 621, 621, 621, 621, 621, 0, 0, 0, 622, 622, 622, 624, 624, 624, 624, 624, 624, 624, 624, 624, 624, 624, 627, 627, 628, 629, 630, 630, 630, 630, 631, 632, 633, 633, 634, 634, 634, 635, 635, 635, 635, 635, 635, 635, 635, 0, 0, 0, 636, 636, 636, 636, 636, 636, 638, 638, 638, 638, 639, 640, 640, 640, 641, 641, 641, 642, 642, 642, 642, 645, 645, 646, 646, 646, 647, 647, 647, 648, 648, 648, 648, 648, 648, 0, 0, 0, 649, 649, 649, 651, 651, 651, 651, 651, 651, 651, 651, 651, 651, 651, 661, 630, 667, 667, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {422, 423, 424, 429, 430, 431, 432, 433, 434, 435, 437, 438, 439, 442, 443, 444, 449, 450, 451, 452, 453, 454, 456, 457, 458, 463, 464, 466, 467, 468, 473, 474, 475, 476, 477, 478, 478, 481, 483, 484, 485, 486, 491, 492, 493, 500, 501, 502, 503, 505, 506, 507, 508, 510, 513, 514, 515, 516, 517, 519, 520, 522, 523, 524, 527, 528, 529, 530, 535, 536, 539, 540, 541, 546, 547, 550, 554, 555, 556, 559, 560, 561, 566, 567, 568, 570, 573, 574, 575, 576, 577, 581, 582, 583, 588, 589, 590, 591, 592, 594, 597, 598, 599, 600, 601, 603, 604, 605, 606, 611, 612, 613, 614, 617, 619, 620, 623, 628, 629, 630, 631, 632, 633, 638, 639, 640, 641, 642, 647, 648, 649, 650, 651, 653, 656, 660, 663, 664, 665, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 681, 686, 691, 692, 694, 697, 701, 704, 705, 707, 712, 713, 714, 715, 717, 718, 719, 721, 724, 725, 730, 731, 732, 733, 735, 738, 742, 745, 750, 755, 756, 757, 760, 761, 764, 765, 767, 768, 769, 772, 774, 777, 779, 780, 781, 783, 784, 785, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 801, 802, 803, 806, 807, 808, 813, 819, 820, 821, 822, 824, 825, 826, 827, 832, 833, 834, 836, 839, 840, 841, 842, 843, 845, 846, 847, 849, 852, 853, 854, 855, 856, 858, 859, 860, 865, 866, 867, 868, 870, 873, 877, 880, 881, 883, 884, 885, 887, 888, 889, 891, 892, 893, 896, 897, 898, 900, 901, 902, 904, 905, 906, 909, 910, 911, 913, 914, 915, 917, 918, 919, 920, 922, 925, 926, 928, 931, 935, 936, 937, 940, 941, 942, 943, 944, 945, 946, 947, 948, 953, 954, 955, 956, 957, 958, 960, 961, 962, 965, 966, 967, 968, 969, 970, 972, 973, 974, 977, 978, 979, 986, 987, 988, 992, 993, 994, 998, 999, 1000, 1001, 1003, 1006, 1007, 1008, 1009, 1010, 1012, 1013, 1015, 1018, 1019, 1020, 1021, 1023, 1026, 1030, 1031, 1032, 1035, 1036, 1037, 1038, 1039, 1041, 1042, 1043, 1048, 1049, 1050, 1051, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1062, 1063, 1064, 1065, 1066, 1067, 1069, 1074, 1075, 1076, 1077, 1078, 1083, 1084, 1085, 1086, 1087, 1089, 1092, 1096, 1099, 1100, 1101, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1117, 1122, 1123, 1124, 1125, 1128, 1129, 1134, 1135, 1136, 1138, 1143, 1144, 1145, 1146, 1149, 1150, 1151, 1156, 1157, 1158, 1159, 1164, 1165, 1168, 1172, 1175, 1176, 1177, 1178, 1179, 1180, 1183, 1184, 1185, 1190, 1191, 1192, 1193, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1208, 1209, 1210, 1211, 1212, 1214, 1215, 1216, 1217, 1222, 1223, 1224, 1225, 1226, 1228, 1231, 1235, 1238, 1239, 1240, 1243, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1259, 1260, 1271, 1272, 1275, 1278, 1282, 1285, 1289, 1292, 1296, 1299, 1303, 1306};
/* BEGIN LINEINFO 
assign 1 393 422
typenameGet 0 393 422
assign 1 393 423
CATCHGet 0 393 423
assign 1 393 424
equals 1 393 429
assign 1 394 430
containedGet 0 394 430
assign 1 394 431
firstGet 0 394 431
assign 1 394 432
containedGet 0 394 432
assign 1 394 433
firstGet 0 394 433
assign 1 394 434
heldGet 0 394 434
assign 1 394 435
isTypedGet 0 394 435
assign 1 395 437
new 0 395 437
assign 1 395 438
new 1 395 438
throw 1 395 439
assign 1 398 442
typenameGet 0 398 442
assign 1 398 443
CLASSGet 0 398 443
assign 1 398 444
equals 1 398 449
assign 1 399 450
assign 1 400 451
heldGet 0 400 451
assign 1 400 452
namepathGet 0 400 452
assign 1 401 453
heldGet 0 401 453
assign 1 401 454
synGet 0 401 454
assign 1 403 456
typenameGet 0 403 456
assign 1 403 457
METHODGet 0 403 457
assign 1 403 458
equals 1 403 463
assign 1 404 464
new 0 404 464
assign 1 406 466
typenameGet 0 406 466
assign 1 406 467
CALLGet 0 406 467
assign 1 406 468
equals 1 406 473
assign 1 407 474
heldGet 0 407 474
cposSet 1 407 475
assign 1 408 476
increment 0 408 476
assign 1 409 477
containedGet 0 409 477
assign 1 409 478
iteratorGet 0 0 478
assign 1 409 481
hasNextGet 0 409 481
assign 1 409 483
nextGet 0 409 483
assign 1 410 484
typenameGet 0 410 484
assign 1 410 485
VARGet 0 410 485
assign 1 410 486
equals 1 410 491
assign 1 411 492
heldGet 0 411 492
addCall 1 411 493
assign 1 422 500
heldGet 0 422 500
assign 1 422 501
orgNameGet 0 422 501
assign 1 422 502
new 0 422 502
assign 1 422 503
equals 1 422 503
assign 1 423 505
containedGet 0 423 505
assign 1 423 506
firstGet 0 423 506
assign 1 425 507
heldGet 0 425 507
assign 1 425 508
isDeclaredGet 0 425 508
assign 1 426 510
heldGet 0 426 510
assign 1 428 513
ptyMapGet 0 428 513
assign 1 428 514
heldGet 0 428 514
assign 1 428 515
nameGet 0 428 515
assign 1 428 516
get 1 428 516
assign 1 428 517
memSynGet 0 428 517
assign 1 431 519
isTypedGet 0 431 519
assign 1 431 520
not 0 431 520
assign 1 432 522
heldGet 0 432 522
assign 1 432 523
new 0 432 523
checkTypesSet 1 432 524
assign 1 434 527
secondGet 0 434 527
assign 1 435 528
typenameGet 0 435 528
assign 1 435 529
TRUEGet 0 435 529
assign 1 435 530
equals 1 435 535
assign 1 0 536
assign 1 435 539
typenameGet 0 435 539
assign 1 435 540
FALSEGet 0 435 540
assign 1 435 541
equals 1 435 546
assign 1 0 547
assign 1 0 550
assign 1 437 554
heldGet 0 437 554
assign 1 437 555
new 0 437 555
checkTypesSet 1 437 556
assign 1 439 559
typenameGet 0 439 559
assign 1 439 560
VARGet 0 439 560
assign 1 439 561
equals 1 439 566
assign 1 440 567
heldGet 0 440 567
assign 1 440 568
isDeclaredGet 0 440 568
assign 1 441 570
heldGet 0 441 570
assign 1 444 573
ptyMapGet 0 444 573
assign 1 444 574
heldGet 0 444 574
assign 1 444 575
nameGet 0 444 575
assign 1 444 576
get 1 444 576
assign 1 444 577
memSynGet 0 444 577
assign 1 447 581
typenameGet 0 447 581
assign 1 447 582
CALLGet 0 447 582
assign 1 447 583
equals 1 447 588
assign 1 448 589
containedGet 0 448 589
assign 1 448 590
firstGet 0 448 590
assign 1 450 591
heldGet 0 450 591
assign 1 450 592
isDeclaredGet 0 450 592
assign 1 452 594
heldGet 0 452 594
assign 1 455 597
ptyMapGet 0 455 597
assign 1 455 598
heldGet 0 455 598
assign 1 455 599
nameGet 0 455 599
assign 1 455 600
get 1 455 600
assign 1 455 601
memSynGet 0 455 601
assign 1 458 603
assign 1 459 604
heldGet 0 459 604
assign 1 459 605
newNpGet 0 459 605
assign 1 459 606
def 1 459 611
assign 1 460 612
heldGet 0 460 612
assign 1 460 613
newNpGet 0 460 613
assign 1 460 614
getSynNp 1 460 614
assign 1 461 617
isTypedGet 0 461 617
assign 1 463 619
namepathGet 0 463 619
assign 1 463 620
getSynNp 1 463 620
assign 1 465 623
def 1 465 628
assign 1 466 629
mtdMapGet 0 466 629
assign 1 466 630
heldGet 0 466 630
assign 1 466 631
nameGet 0 466 631
assign 1 466 632
get 1 466 632
assign 1 467 633
undef 1 467 638
assign 1 468 639
mtdMapGet 0 468 639
assign 1 468 640
new 0 468 640
assign 1 468 641
get 1 468 641
assign 1 469 642
def 1 469 647
assign 1 469 648
originGet 0 469 648
assign 1 469 649
toString 0 469 649
assign 1 469 650
new 0 469 650
assign 1 469 651
notEquals 1 469 651
assign 1 0 653
assign 1 0 656
assign 1 0 660
assign 1 470 663
heldGet 0 470 663
assign 1 470 664
new 0 470 664
isForwardSet 1 470 665
assign 1 472 668
new 0 472 668
assign 1 472 669
heldGet 0 472 669
assign 1 472 670
nameGet 0 472 670
assign 1 472 671
add 1 472 671
assign 1 472 672
new 0 472 672
assign 1 472 673
add 1 472 673
assign 1 472 674
namepathGet 0 472 674
assign 1 472 675
add 1 472 675
assign 1 472 676
new 2 472 676
throw 1 472 677
assign 1 475 681
rsynGet 0 475 681
assign 1 479 686
def 1 479 691
assign 1 479 692
isTypedGet 0 479 692
assign 1 0 694
assign 1 0 697
assign 1 0 701
assign 1 481 704
new 0 481 704
assign 1 482 705
isSelfGet 0 482 705
assign 1 484 707
undef 1 484 712
assign 1 485 713
new 0 485 713
assign 1 485 714
new 1 485 714
throw 1 485 715
assign 1 490 717
originGet 0 490 717
assign 1 490 718
namepathGet 0 490 718
assign 1 490 719
notEquals 1 490 719
assign 1 492 721
new 0 492 721
assign 1 493 724
emitCommonGet 0 493 724
assign 1 493 725
def 1 493 730
assign 1 493 731
emitCommonGet 0 493 731
assign 1 493 732
coanyiantReturnsGet 0 493 732
assign 1 493 733
not 0 493 733
assign 1 0 735
assign 1 0 738
assign 1 0 742
assign 1 494 745
new 0 494 745
assign 1 496 750
def 1 496 755
assign 1 497 756
getEmitReturnType 2 497 756
assign 1 497 757
getSynNp 1 497 757
assign 1 499 760
namepathGet 0 499 760
assign 1 499 761
getSynNp 1 499 761
assign 1 503 764
namepathGet 0 503 764
assign 1 503 765
castsTo 1 503 765
assign 1 505 767
heldGet 0 505 767
assign 1 505 768
new 0 505 768
checkTypesSet 1 505 769
assign 1 507 772
isSelfGet 0 507 772
assign 1 508 774
namepathGet 0 508 774
assign 1 510 777
namepathGet 0 510 777
assign 1 512 779
namepathGet 0 512 779
assign 1 512 780
getSynNp 1 512 780
assign 1 513 781
castsTo 1 513 781
assign 1 515 783
heldGet 0 515 783
assign 1 515 784
new 0 515 784
checkTypesSet 1 515 785
assign 1 517 788
new 0 517 788
assign 1 517 789
namepathGet 0 517 789
assign 1 517 790
toString 0 517 790
assign 1 517 791
add 1 517 791
assign 1 517 792
new 0 517 792
assign 1 517 793
add 1 517 793
assign 1 517 794
toString 0 517 794
assign 1 517 795
add 1 517 795
assign 1 517 796
new 2 517 796
throw 1 517 797
assign 1 523 801
heldGet 0 523 801
assign 1 523 802
new 0 523 802
checkTypesSet 1 523 803
assign 1 526 806
heldGet 0 526 806
assign 1 526 807
namepathGet 0 526 807
assign 1 526 808
def 1 526 813
assign 1 531 819
heldGet 0 531 819
assign 1 531 820
orgNameGet 0 531 820
assign 1 531 821
new 0 531 821
assign 1 531 822
equals 1 531 822
assign 1 532 824
secondGet 0 532 824
assign 1 533 825
typenameGet 0 533 825
assign 1 533 826
VARGet 0 533 826
assign 1 533 827
equals 1 533 832
assign 1 534 833
heldGet 0 534 833
assign 1 534 834
isDeclaredGet 0 534 834
assign 1 535 836
heldGet 0 535 836
assign 1 537 839
ptyMapGet 0 537 839
assign 1 537 840
heldGet 0 537 840
assign 1 537 841
nameGet 0 537 841
assign 1 537 842
get 1 537 842
assign 1 537 843
memSynGet 0 537 843
assign 1 540 845
scopeGet 0 540 845
assign 1 541 846
heldGet 0 541 846
assign 1 541 847
isDeclaredGet 0 541 847
assign 1 542 849
heldGet 0 542 849
assign 1 544 852
ptyMapGet 0 544 852
assign 1 544 853
heldGet 0 544 853
assign 1 544 854
nameGet 0 544 854
assign 1 544 855
get 1 544 855
assign 1 544 856
memSynGet 0 544 856
assign 1 547 858
heldGet 0 547 858
assign 1 547 859
rtypeGet 0 547 859
assign 1 547 860
def 1 547 865
assign 1 547 866
heldGet 0 547 866
assign 1 547 867
rtypeGet 0 547 867
assign 1 547 868
isTypedGet 0 547 868
assign 1 0 870
assign 1 0 873
assign 1 0 877
assign 1 548 880
isTypedGet 0 548 880
assign 1 548 881
not 0 548 881
assign 1 549 883
heldGet 0 549 883
assign 1 549 884
rtypeGet 0 549 884
assign 1 549 885
isThisGet 0 549 885
assign 1 550 887
new 0 550 887
assign 1 550 888
new 2 550 888
throw 1 550 889
assign 1 553 891
heldGet 0 553 891
assign 1 553 892
new 0 553 892
checkTypesSet 1 553 893
assign 1 557 896
heldGet 0 557 896
assign 1 557 897
rtypeGet 0 557 897
assign 1 557 898
isSelfGet 0 557 898
assign 1 558 900
nameGet 0 558 900
assign 1 558 901
new 0 558 901
assign 1 558 902
equals 1 558 902
assign 1 560 904
heldGet 0 560 904
assign 1 560 905
new 0 560 905
checkTypesSet 1 560 906
assign 1 562 909
heldGet 0 562 909
assign 1 562 910
rtypeGet 0 562 910
assign 1 562 911
isThisGet 0 562 911
assign 1 563 913
new 0 563 913
assign 1 563 914
new 2 563 914
throw 1 563 915
assign 1 565 917
namepathGet 0 565 917
assign 1 565 918
getSynNp 1 565 918
assign 1 566 919
namepathGet 0 566 919
assign 1 566 920
castsTo 1 566 920
assign 1 0 922
assign 1 566 925
namepathGet 0 566 925
assign 1 566 926
castsTo 1 566 926
assign 1 0 928
assign 1 0 931
assign 1 568 935
heldGet 0 568 935
assign 1 568 936
new 0 568 936
checkTypesSet 1 568 937
assign 1 570 940
new 0 570 940
assign 1 570 941
namepathGet 0 570 941
assign 1 570 942
add 1 570 942
assign 1 570 943
new 0 570 943
assign 1 570 944
add 1 570 944
assign 1 570 945
namepathGet 0 570 945
assign 1 570 946
add 1 570 946
assign 1 570 947
new 2 570 947
throw 1 570 948
assign 1 574 953
namepathGet 0 574 953
assign 1 574 954
getSynNp 1 574 954
assign 1 575 955
heldGet 0 575 955
assign 1 575 956
rtypeGet 0 575 956
assign 1 575 957
namepathGet 0 575 957
assign 1 575 958
castsTo 1 575 958
assign 1 577 960
heldGet 0 577 960
assign 1 577 961
new 0 577 961
checkTypesSet 1 577 962
assign 1 579 965
heldGet 0 579 965
assign 1 579 966
rtypeGet 0 579 966
assign 1 579 967
namepathGet 0 579 967
assign 1 579 968
getSynNp 1 579 968
assign 1 580 969
namepathGet 0 580 969
assign 1 580 970
castsTo 1 580 970
assign 1 582 972
heldGet 0 582 972
assign 1 582 973
new 0 582 973
checkTypesSet 1 582 974
assign 1 584 977
new 0 584 977
assign 1 584 978
new 2 584 978
throw 1 584 979
assign 1 591 986
heldGet 0 591 986
assign 1 591 987
new 0 591 987
checkTypesSet 1 591 988
assign 1 594 992
heldGet 0 594 992
assign 1 594 993
new 0 594 993
checkTypesSet 1 594 994
assign 1 597 998
containedGet 0 597 998
assign 1 597 999
firstGet 0 597 999
assign 1 599 1000
heldGet 0 599 1000
assign 1 599 1001
isDeclaredGet 0 599 1001
assign 1 600 1003
heldGet 0 600 1003
assign 1 602 1006
ptyMapGet 0 602 1006
assign 1 602 1007
heldGet 0 602 1007
assign 1 602 1008
nameGet 0 602 1008
assign 1 602 1009
get 1 602 1009
assign 1 602 1010
memSynGet 0 602 1010
assign 1 605 1012
isTypedGet 0 605 1012
assign 1 605 1013
not 0 605 1013
assign 1 0 1015
assign 1 605 1018
heldGet 0 605 1018
assign 1 605 1019
orgNameGet 0 605 1019
assign 1 605 1020
new 0 605 1020
assign 1 605 1021
equals 1 605 1021
assign 1 0 1023
assign 1 0 1026
assign 1 606 1030
heldGet 0 606 1030
assign 1 606 1031
new 0 606 1031
checkTypesSet 1 606 1032
assign 1 608 1035
heldGet 0 608 1035
assign 1 608 1036
new 0 608 1036
checkTypesSet 1 608 1037
assign 1 609 1038
heldGet 0 609 1038
assign 1 609 1039
isConstructGet 0 609 1039
assign 1 610 1041
heldGet 0 610 1041
assign 1 610 1042
newNpGet 0 610 1042
assign 1 610 1043
undef 1 610 1048
assign 1 611 1049
new 0 611 1049
assign 1 611 1050
new 1 611 1050
throw 1 611 1051
assign 1 613 1053
heldGet 0 613 1053
assign 1 613 1054
newNpGet 0 613 1054
assign 1 613 1055
getSynNp 1 613 1055
assign 1 614 1056
mtdMapGet 0 614 1056
assign 1 614 1057
heldGet 0 614 1057
assign 1 614 1058
nameGet 0 614 1058
assign 1 614 1059
get 1 614 1059
assign 1 616 1062
namepathGet 0 616 1062
assign 1 616 1063
getSynNp 1 616 1063
assign 1 617 1064
mtdMapGet 0 617 1064
assign 1 617 1065
heldGet 0 617 1065
assign 1 617 1066
nameGet 0 617 1066
assign 1 617 1067
get 1 617 1067
assign 1 619 1069
undef 1 619 1074
assign 1 620 1075
mtdMapGet 0 620 1075
assign 1 620 1076
new 0 620 1076
assign 1 620 1077
get 1 620 1077
assign 1 621 1078
def 1 621 1083
assign 1 621 1084
originGet 0 621 1084
assign 1 621 1085
toString 0 621 1085
assign 1 621 1086
new 0 621 1086
assign 1 621 1087
notEquals 1 621 1087
assign 1 0 1089
assign 1 0 1092
assign 1 0 1096
assign 1 622 1099
heldGet 0 622 1099
assign 1 622 1100
new 0 622 1100
isForwardSet 1 622 1101
assign 1 624 1104
new 0 624 1104
assign 1 624 1105
heldGet 0 624 1105
assign 1 624 1106
nameGet 0 624 1106
assign 1 624 1107
add 1 624 1107
assign 1 624 1108
new 0 624 1108
assign 1 624 1109
add 1 624 1109
assign 1 624 1110
namepathGet 0 624 1110
assign 1 624 1111
toString 0 624 1111
assign 1 624 1112
add 1 624 1112
assign 1 624 1113
new 2 624 1113
throw 1 624 1114
assign 1 627 1117
def 1 627 1122
assign 1 628 1123
argSynsGet 0 628 1123
assign 1 629 1124
nextPeerGet 0 629 1124
assign 1 630 1125
new 0 630 1125
assign 1 630 1128
lengthGet 0 630 1128
assign 1 630 1129
lesser 1 630 1134
assign 1 631 1135
get 1 631 1135
assign 1 632 1136
isTypedGet 0 632 1136
assign 1 633 1138
undef 1 633 1143
assign 1 634 1144
new 0 634 1144
assign 1 634 1145
new 2 634 1145
throw 1 634 1146
assign 1 635 1149
typenameGet 0 635 1149
assign 1 635 1150
VARGet 0 635 1150
assign 1 635 1151
notEquals 1 635 1156
assign 1 635 1157
typenameGet 0 635 1157
assign 1 635 1158
NULLGet 0 635 1158
assign 1 635 1159
notEquals 1 635 1164
assign 1 0 1165
assign 1 0 1168
assign 1 0 1172
assign 1 636 1175
new 0 636 1175
assign 1 636 1176
typenameGet 0 636 1176
assign 1 636 1177
toString 0 636 1177
assign 1 636 1178
add 1 636 1178
assign 1 636 1179
new 2 636 1179
throw 1 636 1180
assign 1 638 1183
typenameGet 0 638 1183
assign 1 638 1184
VARGet 0 638 1184
assign 1 638 1185
equals 1 638 1190
assign 1 639 1191
heldGet 0 639 1191
assign 1 640 1192
isTypedGet 0 640 1192
assign 1 640 1193
not 0 640 1198
assign 1 641 1199
heldGet 0 641 1199
assign 1 641 1200
new 0 641 1200
checkTypesSet 1 641 1201
assign 1 642 1202
heldGet 0 642 1202
assign 1 642 1203
argCastsGet 0 642 1203
assign 1 642 1204
namepathGet 0 642 1204
put 2 642 1205
assign 1 645 1208
namepathGet 0 645 1208
assign 1 645 1209
getSynNp 1 645 1209
assign 1 646 1210
namepathGet 0 646 1210
assign 1 646 1211
castsTo 1 646 1211
assign 1 646 1212
not 0 646 1212
assign 1 647 1214
mtdMapGet 0 647 1214
assign 1 647 1215
new 0 647 1215
assign 1 647 1216
get 1 647 1216
assign 1 648 1217
def 1 648 1222
assign 1 648 1223
originGet 0 648 1223
assign 1 648 1224
toString 0 648 1224
assign 1 648 1225
new 0 648 1225
assign 1 648 1226
notEquals 1 648 1226
assign 1 0 1228
assign 1 0 1231
assign 1 0 1235
assign 1 649 1238
heldGet 0 649 1238
assign 1 649 1239
new 0 649 1239
isForwardSet 1 649 1240
assign 1 651 1243
new 0 651 1243
assign 1 651 1244
namepathGet 0 651 1244
assign 1 651 1245
toString 0 651 1245
assign 1 651 1246
add 1 651 1246
assign 1 651 1247
new 0 651 1247
assign 1 651 1248
add 1 651 1248
assign 1 651 1249
namepathGet 0 651 1249
assign 1 651 1250
toString 0 651 1250
assign 1 651 1251
add 1 651 1251
assign 1 651 1252
new 2 651 1252
throw 1 651 1253
assign 1 661 1259
nextPeerGet 0 661 1259
assign 1 630 1260
increment 0 630 1260
assign 1 667 1271
nextDescendGet 0 667 1271
return 1 667 1272
return 1 0 1275
assign 1 0 1278
return 1 0 1282
assign 1 0 1285
return 1 0 1289
assign 1 0 1292
return 1 0 1296
assign 1 0 1299
return 1 0 1303
assign 1 0 1306
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -2028575047: return bem_emitterGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case -2041762316: return bem_inClassGet_0();
case -1012494862: return bem_once_0();
case -997464046: return bem_inClassSynGet_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -2030680063: return bem_inClassSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2117282045: return bem_cposSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
}
