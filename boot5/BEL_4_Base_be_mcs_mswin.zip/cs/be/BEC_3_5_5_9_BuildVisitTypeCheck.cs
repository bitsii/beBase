namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_9_BuildVisitTypeCheck : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
static BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x61,0x6E,0x79,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x41,0x72,0x67,0x73,0x5F,0x31};
private static byte[] bels_3 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x31};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 13));
private static byte[] bels_4 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20,0x42,0x20};
private static byte[] bels_5 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x61,0x6E,0x79,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_6 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 30));
private static byte[] bels_7 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_7, 19));
private static byte[] bels_8 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_9 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] bels_10 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_11 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x63,0x61,0x6E,0x20,0x6F,0x6E,0x6C,0x79,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x28,0x73,0x65,0x6C,0x66,0x29,0x3B,0x20,0x28,0x61,0x63,0x74,0x75,0x61,0x6C,0x20,0x73,0x65,0x6C,0x66,0x20,0x72,0x65,0x66,0x65,0x72,0x65,0x6E,0x63,0x65,0x29,0x20,0x66,0x6F,0x72,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73};
private static byte[] bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 67));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_17 = {0x41,0x72,0x67,0x73,0x5F,0x31};
private static byte[] bels_18 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x31};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 13));
private static byte[] bels_19 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20,0x43,0x20};
private static byte[] bels_20 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_21 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x61,0x6E,0x79,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_21, 19));
private static byte[] bels_22 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_22, 52));
private static byte[] bels_23 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_23, 5));
public static new BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cany = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_4_ContainerList bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_18_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_95_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_121_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_133_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_6_TextString bevt_137_tmpany_phold = null;
BEC_2_4_6_TextString bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_140_tmpany_phold = null;
BEC_2_4_6_TextString bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_6_TextString bevt_151_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_152_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_153_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_154_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_178_tmpany_phold = null;
BEC_2_4_6_TextString bevt_179_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_182_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_183_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_185_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpany_phold = null;
BEC_2_4_6_TextString bevt_187_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_189_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_191_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_193_tmpany_phold = null;
BEC_2_4_6_TextString bevt_194_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_197_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_198_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_200_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_201_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_202_tmpany_phold = null;
BEC_2_4_6_TextString bevt_203_tmpany_phold = null;
BEC_2_4_6_TextString bevt_204_tmpany_phold = null;
BEC_2_4_6_TextString bevt_205_tmpany_phold = null;
BEC_2_4_6_TextString bevt_206_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpany_phold = null;
BEC_2_4_6_TextString bevt_208_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_212_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_216_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_219_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_223_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_224_tmpany_phold = null;
BEC_2_4_6_TextString bevt_225_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_227_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_228_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_229_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_230_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_231_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_238_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_239_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_240_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_241_tmpany_phold = null;
BEC_2_4_6_TextString bevt_242_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_243_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_244_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_245_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_246_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_247_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_248_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_249_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_250_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_251_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_252_tmpany_phold = null;
BEC_2_4_6_TextString bevt_253_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_254_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_255_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_256_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_257_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_258_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_259_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_260_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_261_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_262_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_263_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_264_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_265_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_266_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_267_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_268_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_269_tmpany_phold = null;
BEC_2_4_6_TextString bevt_270_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_271_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_272_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_273_tmpany_phold = null;
BEC_2_4_6_TextString bevt_274_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_276_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_277_tmpany_phold = null;
BEC_2_4_6_TextString bevt_278_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_279_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_280_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_281_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_282_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_283_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_284_tmpany_phold = null;
BEC_2_4_6_TextString bevt_285_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_286_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_287_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_288_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_289_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_290_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_291_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_292_tmpany_phold = null;
BEC_2_4_6_TextString bevt_293_tmpany_phold = null;
BEC_2_4_6_TextString bevt_294_tmpany_phold = null;
BEC_2_4_6_TextString bevt_295_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_296_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_297_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_298_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_299_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_300_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_301_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_302_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_303_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_304_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_305_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_306_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_307_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_308_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_309_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_310_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_311_tmpany_phold = null;
BEC_2_4_6_TextString bevt_312_tmpany_phold = null;
BEC_2_4_6_TextString bevt_313_tmpany_phold = null;
BEC_2_4_6_TextString bevt_314_tmpany_phold = null;
BEC_2_4_6_TextString bevt_315_tmpany_phold = null;
BEC_2_4_6_TextString bevt_316_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_317_tmpany_phold = null;
BEC_2_4_6_TextString bevt_318_tmpany_phold = null;
BEC_2_4_6_TextString bevt_319_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_320_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_321_tmpany_phold = null;
bevt_11_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_12_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_11_tmpany_phold.bevi_int == bevt_12_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_18_tmpany_phold = beva_node.bem_containedGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_firstGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 397 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bels_0));
bevt_19_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_20_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 398 */
} /* Line: 397 */
bevt_22_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevp_inClass = beva_node;
bevt_24_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_24_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_25_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 404 */
bevt_27_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_28_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_27_tmpany_phold.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevp_cpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 407 */
bevt_30_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_31_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_tmpany_phold.bevi_int == bevt_31_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevt_32_tmpany_phold = beva_node.bem_heldGet_0();
bevt_32_tmpany_phold.bemd_1(-2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_33_tmpany_phold = beva_node.bem_containedGet_0();
bevt_0_tmpany_loop = bevt_33_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 412 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpany_phold).bevi_bool) /* Line: 412 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_36_tmpany_phold = bevl_cci.bem_typenameGet_0();
bevt_37_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_36_tmpany_phold.bevi_int == bevt_37_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 413 */ {
bevt_38_tmpany_phold = bevl_cci.bem_heldGet_0();
bevt_38_tmpany_phold.bemd_1(-474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 414 */
} /* Line: 413 */
 else  /* Line: 412 */ {
break;
} /* Line: 412 */
} /* Line: 412 */
bevt_41_tmpany_phold = beva_node.bem_heldGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_42_tmpany_phold);
if (bevt_39_tmpany_phold != null && bevt_39_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpany_phold).bevi_bool) /* Line: 425 */ {
bevt_43_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_43_tmpany_phold.bem_firstGet_0();
bevt_45_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_44_tmpany_phold != null && bevt_44_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_44_tmpany_phold).bevi_bool) /* Line: 428 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 429 */
 else  /* Line: 430 */ {
bevt_47_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_49_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_48_tmpany_phold);
bevl_tany = bevt_46_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 431 */
bevt_51_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpany_phold).bevi_bool) /* Line: 434 */ {
bevt_52_tmpany_phold = beva_node.bem_heldGet_0();
bevt_53_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_52_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_53_tmpany_phold);
} /* Line: 435 */
 else  /* Line: 436 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_55_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_56_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_55_tmpany_phold.bevi_int == bevt_56_tmpany_phold.bevi_int) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 438 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 438 */ {
bevt_58_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_59_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_59_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 438 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 438 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 438 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 438 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_60_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_61_tmpany_phold);
} /* Line: 440 */
 else  /* Line: 441 */ {
bevt_63_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 442 */ {
bevt_66_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_65_tmpany_phold != null && bevt_65_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_65_tmpany_phold).bevi_bool) /* Line: 443 */ {
bevl_oany = bevl_org.bem_heldGet_0();
} /* Line: 444 */
 else  /* Line: 445 */ {
bevt_68_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_70_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_69_tmpany_phold);
bevl_oany = bevt_67_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 447 */
} /* Line: 443 */
 else  /* Line: 442 */ {
bevt_72_tmpany_phold = bevl_org.bem_typenameGet_0();
bevt_73_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_72_tmpany_phold.bevi_int == bevt_73_tmpany_phold.bevi_int) {
bevt_71_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_71_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 450 */ {
bevt_74_tmpany_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_74_tmpany_phold.bem_firstGet_0();
bevt_76_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_75_tmpany_phold != null && bevt_75_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_75_tmpany_phold).bevi_bool) /* Line: 453 */ {
bevl_cany = bevl_ctarg.bem_heldGet_0();
} /* Line: 455 */
 else  /* Line: 456 */ {
bevt_78_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_80_tmpany_phold = bevl_ctarg.bem_heldGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_79_tmpany_phold);
bevl_cany = bevt_77_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 458 */
bevl_syn = null;
bevt_83_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_82_tmpany_phold == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_85_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_84_tmpany_phold);
} /* Line: 463 */
 else  /* Line: 462 */ {
bevt_86_tmpany_phold = bevl_cany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_86_tmpany_phold != null && bevt_86_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_86_tmpany_phold).bevi_bool) /* Line: 464 */ {
bevt_87_tmpany_phold = bevl_cany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_87_tmpany_phold);
} /* Line: 466 */
} /* Line: 462 */
if (bevl_syn == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 468 */ {
bevt_89_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_91_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_90_tmpany_phold = bevt_91_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_89_tmpany_phold.bem_get_1(bevt_90_tmpany_phold);
if (bevl_mtdc == null) {
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevt_95_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_98_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_2));
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_99_tmpany_phold);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_get_1(bevt_96_tmpany_phold);
if (bevt_94_tmpany_phold == null) {
bevt_93_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 472 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 472 */ {
bevt_102_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_103_tmpany_phold = bevo_0;
bevt_101_tmpany_phold = bevt_102_tmpany_phold.bem_get_1(bevt_103_tmpany_phold);
if (bevt_101_tmpany_phold == null) {
bevt_100_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_100_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_100_tmpany_phold.bevi_bool) /* Line: 472 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 472 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 472 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 472 */ {
bevt_104_tmpany_phold = bevl_org.bem_heldGet_0();
bevt_105_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_104_tmpany_phold.bemd_1(1154745507, BEL_4_Base.bevn_untypedSet_1, bevt_105_tmpany_phold);
} /* Line: 473 */
 else  /* Line: 474 */ {
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_4));
bevt_106_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_107_tmpany_phold, bevl_org);
throw new be.BECS_ThrowBack(bevt_106_tmpany_phold);
} /* Line: 475 */
} /* Line: 471 */
 else  /* Line: 477 */ {
bevl_oany = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 478 */
} /* Line: 470 */
} /* Line: 468 */
} /* Line: 442 */
if (bevl_oany == null) {
bevt_108_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_109_tmpany_phold = bevl_oany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_109_tmpany_phold != null && bevt_109_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_109_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 482 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 482 */
 else  /* Line: 482 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 482 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_110_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_110_tmpany_phold != null && bevt_110_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpany_phold).bevi_bool) /* Line: 485 */ {
if (bevl_syn == null) {
bevt_111_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_111_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_111_tmpany_phold.bevi_bool) /* Line: 487 */ {
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bels_5));
bevt_112_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_113_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_112_tmpany_phold);
} /* Line: 488 */
bevt_115_tmpany_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_116_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 493 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 495 */
 else  /* Line: 493 */ {
bevt_118_tmpany_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_118_tmpany_phold == null) {
bevt_117_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_117_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_117_tmpany_phold.bevi_bool) /* Line: 496 */ {
bevt_121_tmpany_phold = bevp_build.bem_emitCommonGet_0();
bevt_120_tmpany_phold = bevt_121_tmpany_phold.bem_coanyiantReturnsGet_0();
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_119_tmpany_phold != null && bevt_119_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpany_phold).bevi_bool) /* Line: 496 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 496 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 496 */
 else  /* Line: 496 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 496 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 497 */
} /* Line: 493 */
} /* Line: 493 */
 else  /* Line: 485 */ {
if (bevl_mtdc == null) {
bevt_122_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpany_phold.bevi_bool) /* Line: 499 */ {
bevt_123_tmpany_phold = bevl_mtdc.bemd_2(-583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_123_tmpany_phold);
} /* Line: 500 */
 else  /* Line: 501 */ {
bevt_124_tmpany_phold = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_124_tmpany_phold);
} /* Line: 502 */
} /* Line: 485 */
bevt_126_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_125_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_126_tmpany_phold);
if (bevt_125_tmpany_phold != null && bevt_125_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_125_tmpany_phold).bevi_bool) /* Line: 506 */ {
bevt_127_tmpany_phold = beva_node.bem_heldGet_0();
bevt_128_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_127_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_128_tmpany_phold);
} /* Line: 508 */
 else  /* Line: 509 */ {
bevt_129_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_129_tmpany_phold != null && bevt_129_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_129_tmpany_phold).bevi_bool) /* Line: 510 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 511 */
 else  /* Line: 512 */ {
bevl_ovnp = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 513 */
bevt_130_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_130_tmpany_phold);
bevt_131_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_131_tmpany_phold != null && bevt_131_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_131_tmpany_phold).bevi_bool) /* Line: 516 */ {
bevt_132_tmpany_phold = beva_node.bem_heldGet_0();
bevt_133_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_132_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_133_tmpany_phold);
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_138_tmpany_phold = bevo_1;
bevt_140_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_139_tmpany_phold = bevt_140_tmpany_phold.bem_toString_0();
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bem_add_1(bevt_139_tmpany_phold);
bevt_141_tmpany_phold = bevo_2;
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bem_add_1(bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bem_add_1(bevt_142_tmpany_phold);
bevt_134_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_135_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_134_tmpany_phold);
} /* Line: 520 */
} /* Line: 516 */
if (bevl_castForSelf.bevi_bool) /* Line: 524 */ {
bevt_143_tmpany_phold = beva_node.bem_heldGet_0();
bevt_144_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_143_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_144_tmpany_phold);
} /* Line: 526 */
} /* Line: 524 */
bevt_147_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_146_tmpany_phold == null) {
bevt_145_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_145_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_145_tmpany_phold.bevi_bool) /* Line: 529 */ {
} /* Line: 529 */
} /* Line: 529 */
} /* Line: 438 */
} /* Line: 434 */
 else  /* Line: 425 */ {
bevt_150_tmpany_phold = beva_node.bem_heldGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_151_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_8));
bevt_148_tmpany_phold = bevt_149_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_151_tmpany_phold);
if (bevt_148_tmpany_phold != null && bevt_148_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_148_tmpany_phold).bevi_bool) /* Line: 534 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_153_tmpany_phold = bevl_targ.bem_typenameGet_0();
bevt_154_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_153_tmpany_phold.bevi_int == bevt_154_tmpany_phold.bevi_int) {
bevt_152_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_152_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_152_tmpany_phold.bevi_bool) /* Line: 536 */ {
bevt_156_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_155_tmpany_phold = bevt_156_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_155_tmpany_phold != null && bevt_155_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_155_tmpany_phold).bevi_bool) /* Line: 537 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 538 */
 else  /* Line: 539 */ {
bevt_158_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_160_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_159_tmpany_phold = bevt_160_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_157_tmpany_phold = bevt_158_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_159_tmpany_phold);
bevl_tany = bevt_157_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 540 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_162_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_161_tmpany_phold != null && bevt_161_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_161_tmpany_phold).bevi_bool) /* Line: 544 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 545 */
 else  /* Line: 546 */ {
bevt_164_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_166_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_163_tmpany_phold = bevt_164_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_165_tmpany_phold);
bevl_tany = bevt_163_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 547 */
bevt_169_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_168_tmpany_phold = bevt_169_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_168_tmpany_phold == null) {
bevt_167_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_167_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_167_tmpany_phold.bevi_bool) /* Line: 550 */ {
bevt_172_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_171_tmpany_phold = bevt_172_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_170_tmpany_phold != null && bevt_170_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_170_tmpany_phold).bevi_bool) /* Line: 550 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 550 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 550 */
 else  /* Line: 550 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 550 */ {
bevt_174_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_173_tmpany_phold = bevt_174_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_173_tmpany_phold != null && bevt_173_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_173_tmpany_phold).bevi_bool) /* Line: 551 */ {
bevt_177_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_176_tmpany_phold = bevt_177_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_175_tmpany_phold = bevt_176_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_175_tmpany_phold != null && bevt_175_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_175_tmpany_phold).bevi_bool) /* Line: 552 */ {
bevt_179_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bels_9));
bevt_178_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_179_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_178_tmpany_phold);
} /* Line: 553 */
bevt_180_tmpany_phold = beva_node.bem_heldGet_0();
bevt_181_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_180_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_181_tmpany_phold);
} /* Line: 556 */
 else  /* Line: 557 */ {
bevt_184_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_183_tmpany_phold = bevt_184_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_182_tmpany_phold = bevt_183_tmpany_phold.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_182_tmpany_phold != null && bevt_182_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_182_tmpany_phold).bevi_bool) /* Line: 560 */ {
bevt_186_tmpany_phold = bevl_tany.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_187_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_10));
bevt_185_tmpany_phold = bevt_186_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_187_tmpany_phold);
if (bevt_185_tmpany_phold != null && bevt_185_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_185_tmpany_phold).bevi_bool) /* Line: 561 */ {
bevt_188_tmpany_phold = beva_node.bem_heldGet_0();
bevt_189_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_188_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_189_tmpany_phold);
} /* Line: 563 */
 else  /* Line: 564 */ {
bevt_192_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_191_tmpany_phold = bevt_192_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_190_tmpany_phold = bevt_191_tmpany_phold.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_190_tmpany_phold != null && bevt_190_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_190_tmpany_phold).bevi_bool) /* Line: 565 */ {
bevt_194_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bels_11));
bevt_193_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_194_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_193_tmpany_phold);
} /* Line: 566 */
bevt_195_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_195_tmpany_phold);
bevt_197_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_196_tmpany_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_197_tmpany_phold);
if (bevt_196_tmpany_phold != null && bevt_196_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_196_tmpany_phold).bevi_bool) /* Line: 569 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
bevt_199_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_198_tmpany_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_199_tmpany_phold);
if (bevt_198_tmpany_phold != null && bevt_198_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_198_tmpany_phold).bevi_bool) /* Line: 569 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 569 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 569 */ {
bevt_200_tmpany_phold = beva_node.bem_heldGet_0();
bevt_201_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_200_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_201_tmpany_phold);
} /* Line: 571 */
 else  /* Line: 572 */ {
bevt_206_tmpany_phold = bevo_3;
bevt_207_tmpany_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_205_tmpany_phold = bevt_206_tmpany_phold.bem_add_1(bevt_207_tmpany_phold);
bevt_208_tmpany_phold = bevo_4;
bevt_204_tmpany_phold = bevt_205_tmpany_phold.bem_add_1(bevt_208_tmpany_phold);
bevt_209_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_203_tmpany_phold = bevt_204_tmpany_phold.bem_add_1(bevt_209_tmpany_phold);
bevt_202_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_203_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_202_tmpany_phold);
} /* Line: 573 */
} /* Line: 569 */
} /* Line: 561 */
 else  /* Line: 576 */ {
bevt_210_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_210_tmpany_phold);
bevt_214_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_213_tmpany_phold = bevt_214_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_212_tmpany_phold = bevt_213_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_211_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_212_tmpany_phold);
if (bevt_211_tmpany_phold != null && bevt_211_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_211_tmpany_phold).bevi_bool) /* Line: 578 */ {
bevt_215_tmpany_phold = beva_node.bem_heldGet_0();
bevt_216_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_215_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_216_tmpany_phold);
} /* Line: 580 */
 else  /* Line: 581 */ {
bevt_219_tmpany_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_218_tmpany_phold = bevt_219_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_217_tmpany_phold = bevt_218_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_217_tmpany_phold);
bevt_221_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_220_tmpany_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_221_tmpany_phold);
if (bevt_220_tmpany_phold != null && bevt_220_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_220_tmpany_phold).bevi_bool) /* Line: 583 */ {
bevt_222_tmpany_phold = beva_node.bem_heldGet_0();
bevt_223_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_222_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_223_tmpany_phold);
} /* Line: 585 */
 else  /* Line: 586 */ {
bevt_225_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bels_14));
bevt_224_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_225_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_224_tmpany_phold);
} /* Line: 587 */
} /* Line: 583 */
} /* Line: 578 */
} /* Line: 560 */
} /* Line: 551 */
 else  /* Line: 592 */ {
bevt_226_tmpany_phold = beva_node.bem_heldGet_0();
bevt_227_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_226_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_227_tmpany_phold);
} /* Line: 594 */
} /* Line: 550 */
 else  /* Line: 596 */ {
bevt_228_tmpany_phold = beva_node.bem_heldGet_0();
bevt_229_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_228_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_229_tmpany_phold);
} /* Line: 597 */
} /* Line: 536 */
 else  /* Line: 599 */ {
bevt_230_tmpany_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_230_tmpany_phold.bem_firstGet_0();
bevt_232_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_231_tmpany_phold = bevt_232_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_231_tmpany_phold != null && bevt_231_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_231_tmpany_phold).bevi_bool) /* Line: 602 */ {
bevl_tany = bevl_targ.bem_heldGet_0();
} /* Line: 603 */
 else  /* Line: 604 */ {
bevt_234_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_236_tmpany_phold = bevl_targ.bem_heldGet_0();
bevt_235_tmpany_phold = bevt_236_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_233_tmpany_phold = bevt_234_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_235_tmpany_phold);
bevl_tany = bevt_233_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 605 */
bevt_238_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_237_tmpany_phold = bevt_238_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_237_tmpany_phold != null && bevt_237_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_237_tmpany_phold).bevi_bool) /* Line: 608 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 608 */ {
bevt_241_tmpany_phold = beva_node.bem_heldGet_0();
bevt_240_tmpany_phold = bevt_241_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_242_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_15));
bevt_239_tmpany_phold = bevt_240_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_242_tmpany_phold);
if (bevt_239_tmpany_phold != null && bevt_239_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_239_tmpany_phold).bevi_bool) /* Line: 608 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 608 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 608 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 608 */ {
bevt_243_tmpany_phold = beva_node.bem_heldGet_0();
bevt_244_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_243_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_244_tmpany_phold);
} /* Line: 609 */
 else  /* Line: 610 */ {
bevt_245_tmpany_phold = beva_node.bem_heldGet_0();
bevt_246_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_245_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_246_tmpany_phold);
bevt_248_tmpany_phold = beva_node.bem_heldGet_0();
bevt_247_tmpany_phold = bevt_248_tmpany_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_247_tmpany_phold != null && bevt_247_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_247_tmpany_phold).bevi_bool) /* Line: 612 */ {
bevt_251_tmpany_phold = beva_node.bem_heldGet_0();
bevt_250_tmpany_phold = bevt_251_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_250_tmpany_phold == null) {
bevt_249_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_249_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_249_tmpany_phold.bevi_bool) /* Line: 613 */ {
bevt_253_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_16));
bevt_252_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_253_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_252_tmpany_phold);
} /* Line: 614 */
bevt_255_tmpany_phold = beva_node.bem_heldGet_0();
bevt_254_tmpany_phold = bevt_255_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_254_tmpany_phold);
bevt_256_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_258_tmpany_phold = beva_node.bem_heldGet_0();
bevt_257_tmpany_phold = bevt_258_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_256_tmpany_phold.bem_get_1(bevt_257_tmpany_phold);
} /* Line: 617 */
 else  /* Line: 618 */ {
bevt_259_tmpany_phold = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_259_tmpany_phold);
bevt_260_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_262_tmpany_phold = beva_node.bem_heldGet_0();
bevt_261_tmpany_phold = bevt_262_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_260_tmpany_phold.bem_get_1(bevt_261_tmpany_phold);
} /* Line: 620 */
if (bevl_mtdc == null) {
bevt_263_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_263_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_263_tmpany_phold.bevi_bool) /* Line: 622 */ {
bevt_266_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_269_tmpany_phold = beva_node.bem_heldGet_0();
bevt_268_tmpany_phold = bevt_269_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_270_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_17));
bevt_267_tmpany_phold = bevt_268_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_270_tmpany_phold);
bevt_265_tmpany_phold = bevt_266_tmpany_phold.bem_get_1(bevt_267_tmpany_phold);
if (bevt_265_tmpany_phold == null) {
bevt_264_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_264_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_264_tmpany_phold.bevi_bool) /* Line: 624 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 624 */ {
bevt_273_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_274_tmpany_phold = bevo_5;
bevt_272_tmpany_phold = bevt_273_tmpany_phold.bem_get_1(bevt_274_tmpany_phold);
if (bevt_272_tmpany_phold == null) {
bevt_271_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_271_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_271_tmpany_phold.bevi_bool) /* Line: 624 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 624 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 624 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 624 */ {
bevt_275_tmpany_phold = beva_node.bem_heldGet_0();
bevt_276_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_275_tmpany_phold.bemd_1(1154745507, BEL_4_Base.bevn_untypedSet_1, bevt_276_tmpany_phold);
} /* Line: 625 */
 else  /* Line: 626 */ {
bevt_278_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_19));
bevt_277_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_278_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_277_tmpany_phold);
} /* Line: 627 */
} /* Line: 623 */
if (bevl_mtdc == null) {
bevt_279_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_279_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_279_tmpany_phold.bevi_bool) /* Line: 630 */ {
bevl_argSyns = (BEC_2_9_4_ContainerList) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 633 */ {
bevt_281_tmpany_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_281_tmpany_phold.bevi_int) {
bevt_280_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_280_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_280_tmpany_phold.bevi_bool) /* Line: 633 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_282_tmpany_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_282_tmpany_phold.bevi_bool) /* Line: 635 */ {
if (bevl_nnode == null) {
bevt_283_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_283_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_283_tmpany_phold.bevi_bool) /* Line: 636 */ {
bevt_285_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_20));
bevt_284_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_285_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_284_tmpany_phold);
} /* Line: 637 */
 else  /* Line: 636 */ {
bevt_287_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_288_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_287_tmpany_phold.bevi_int != bevt_288_tmpany_phold.bevi_int) {
bevt_286_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_286_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_286_tmpany_phold.bevi_bool) /* Line: 638 */ {
bevt_290_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_291_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_290_tmpany_phold.bevi_int != bevt_291_tmpany_phold.bevi_int) {
bevt_289_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_289_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_289_tmpany_phold.bevi_bool) /* Line: 638 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 638 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 638 */
 else  /* Line: 638 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 638 */ {
bevt_294_tmpany_phold = bevo_6;
bevt_296_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_295_tmpany_phold = bevt_296_tmpany_phold.bem_toString_0();
bevt_293_tmpany_phold = bevt_294_tmpany_phold.bem_add_1(bevt_295_tmpany_phold);
bevt_292_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_293_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_292_tmpany_phold);
} /* Line: 639 */
} /* Line: 636 */
bevt_298_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_299_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_298_tmpany_phold.bevi_int == bevt_299_tmpany_phold.bevi_int) {
bevt_297_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_297_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_297_tmpany_phold.bevi_bool) /* Line: 641 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_301_tmpany_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_301_tmpany_phold.bevi_bool) {
bevt_300_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_300_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_300_tmpany_phold.bevi_bool) /* Line: 643 */ {
bevt_302_tmpany_phold = beva_node.bem_heldGet_0();
bevt_303_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_302_tmpany_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_303_tmpany_phold);
bevt_305_tmpany_phold = beva_node.bem_heldGet_0();
bevt_304_tmpany_phold = bevt_305_tmpany_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_306_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_304_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_306_tmpany_phold);
} /* Line: 645 */
 else  /* Line: 647 */ {
bevt_307_tmpany_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_307_tmpany_phold);
bevt_310_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_309_tmpany_phold = bevl_syn.bem_castsTo_1(bevt_310_tmpany_phold);
bevt_308_tmpany_phold = bevt_309_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_308_tmpany_phold != null && bevt_308_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_308_tmpany_phold).bevi_bool) /* Line: 649 */ {
bevt_315_tmpany_phold = bevo_7;
bevt_317_tmpany_phold = bevl_syn.bem_namepathGet_0();
bevt_316_tmpany_phold = bevt_317_tmpany_phold.bem_toString_0();
bevt_314_tmpany_phold = bevt_315_tmpany_phold.bem_add_1(bevt_316_tmpany_phold);
bevt_318_tmpany_phold = bevo_8;
bevt_313_tmpany_phold = bevt_314_tmpany_phold.bem_add_1(bevt_318_tmpany_phold);
bevt_320_tmpany_phold = bevl_marg.bem_namepathGet_0();
bevt_319_tmpany_phold = bevt_320_tmpany_phold.bem_toString_0();
bevt_312_tmpany_phold = bevt_313_tmpany_phold.bem_add_1(bevt_319_tmpany_phold);
bevt_311_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_312_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_311_tmpany_phold);
} /* Line: 650 */
} /* Line: 649 */
} /* Line: 643 */
} /* Line: 641 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 633 */
 else  /* Line: 633 */ {
break;
} /* Line: 633 */
} /* Line: 633 */
} /* Line: 633 */
} /* Line: 630 */
} /* Line: 608 */
} /* Line: 425 */
} /* Line: 425 */
bevt_321_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_321_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public BEC_3_5_5_9_BuildVisitTypeCheck bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {396, 396, 396, 396, 397, 397, 397, 397, 397, 397, 398, 398, 398, 401, 401, 401, 401, 402, 403, 403, 404, 404, 406, 406, 406, 406, 407, 409, 409, 409, 409, 410, 410, 411, 412, 412, 0, 412, 412, 413, 413, 413, 413, 414, 414, 425, 425, 425, 425, 426, 426, 428, 428, 429, 431, 431, 431, 431, 431, 434, 434, 435, 435, 435, 437, 438, 438, 438, 438, 0, 438, 438, 438, 438, 0, 0, 440, 440, 440, 442, 442, 442, 442, 443, 443, 444, 447, 447, 447, 447, 447, 450, 450, 450, 450, 451, 451, 453, 453, 455, 458, 458, 458, 458, 458, 461, 462, 462, 462, 462, 463, 463, 463, 464, 466, 466, 468, 468, 469, 469, 469, 469, 470, 470, 471, 471, 471, 471, 471, 471, 471, 471, 0, 472, 472, 472, 472, 472, 0, 0, 473, 473, 473, 475, 475, 475, 478, 482, 482, 482, 0, 0, 0, 484, 485, 487, 487, 488, 488, 488, 493, 493, 493, 495, 496, 496, 496, 496, 496, 496, 0, 0, 0, 497, 499, 499, 500, 500, 502, 502, 506, 506, 508, 508, 508, 510, 511, 513, 515, 515, 516, 518, 518, 518, 520, 520, 520, 520, 520, 520, 520, 520, 520, 520, 526, 526, 526, 529, 529, 529, 529, 534, 534, 534, 534, 535, 536, 536, 536, 536, 537, 537, 538, 540, 540, 540, 540, 540, 543, 544, 544, 545, 547, 547, 547, 547, 547, 550, 550, 550, 550, 550, 550, 550, 0, 0, 0, 551, 551, 552, 552, 552, 553, 553, 553, 556, 556, 556, 560, 560, 560, 561, 561, 561, 563, 563, 563, 565, 565, 565, 566, 566, 566, 568, 568, 569, 569, 0, 569, 569, 0, 0, 571, 571, 571, 573, 573, 573, 573, 573, 573, 573, 573, 573, 577, 577, 578, 578, 578, 578, 580, 580, 580, 582, 582, 582, 582, 583, 583, 585, 585, 585, 587, 587, 587, 594, 594, 594, 597, 597, 597, 600, 600, 602, 602, 603, 605, 605, 605, 605, 605, 608, 608, 0, 608, 608, 608, 608, 0, 0, 609, 609, 609, 611, 611, 611, 612, 612, 613, 613, 613, 613, 614, 614, 614, 616, 616, 616, 617, 617, 617, 617, 619, 619, 620, 620, 620, 620, 622, 622, 623, 623, 623, 623, 623, 623, 623, 623, 0, 624, 624, 624, 624, 624, 0, 0, 625, 625, 625, 627, 627, 627, 630, 630, 631, 632, 633, 633, 633, 633, 634, 635, 636, 636, 637, 637, 637, 638, 638, 638, 638, 638, 638, 638, 638, 0, 0, 0, 639, 639, 639, 639, 639, 639, 641, 641, 641, 641, 642, 643, 643, 643, 644, 644, 644, 645, 645, 645, 645, 648, 648, 649, 649, 649, 650, 650, 650, 650, 650, 650, 650, 650, 650, 650, 650, 659, 633, 665, 665, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {391, 392, 393, 398, 399, 400, 401, 402, 403, 404, 406, 407, 408, 411, 412, 413, 418, 419, 420, 421, 422, 423, 425, 426, 427, 432, 433, 435, 436, 437, 442, 443, 444, 445, 446, 447, 447, 450, 452, 453, 454, 455, 460, 461, 462, 469, 470, 471, 472, 474, 475, 476, 477, 479, 482, 483, 484, 485, 486, 488, 489, 491, 492, 493, 496, 497, 498, 499, 504, 505, 508, 509, 510, 515, 516, 519, 523, 524, 525, 528, 529, 530, 535, 536, 537, 539, 542, 543, 544, 545, 546, 550, 551, 552, 557, 558, 559, 560, 561, 563, 566, 567, 568, 569, 570, 572, 573, 574, 575, 580, 581, 582, 583, 586, 588, 589, 592, 597, 598, 599, 600, 601, 602, 607, 608, 609, 610, 611, 612, 613, 614, 619, 620, 623, 624, 625, 626, 631, 632, 635, 639, 640, 641, 644, 645, 646, 650, 655, 660, 661, 663, 666, 670, 673, 674, 676, 681, 682, 683, 684, 686, 687, 688, 690, 693, 694, 699, 700, 701, 702, 704, 707, 711, 714, 719, 724, 725, 726, 729, 730, 733, 734, 736, 737, 738, 741, 743, 746, 748, 749, 750, 752, 753, 754, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 770, 771, 772, 775, 776, 777, 782, 788, 789, 790, 791, 793, 794, 795, 796, 801, 802, 803, 805, 808, 809, 810, 811, 812, 814, 815, 816, 818, 821, 822, 823, 824, 825, 827, 828, 829, 834, 835, 836, 837, 839, 842, 846, 849, 850, 852, 853, 854, 856, 857, 858, 860, 861, 862, 865, 866, 867, 869, 870, 871, 873, 874, 875, 878, 879, 880, 882, 883, 884, 886, 887, 888, 889, 891, 894, 895, 897, 900, 904, 905, 906, 909, 910, 911, 912, 913, 914, 915, 916, 917, 922, 923, 924, 925, 926, 927, 929, 930, 931, 934, 935, 936, 937, 938, 939, 941, 942, 943, 946, 947, 948, 955, 956, 957, 961, 962, 963, 967, 968, 969, 970, 972, 975, 976, 977, 978, 979, 981, 982, 984, 987, 988, 989, 990, 992, 995, 999, 1000, 1001, 1004, 1005, 1006, 1007, 1008, 1010, 1011, 1012, 1017, 1018, 1019, 1020, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1031, 1032, 1033, 1034, 1035, 1036, 1038, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1055, 1056, 1059, 1060, 1061, 1062, 1067, 1068, 1071, 1075, 1076, 1077, 1080, 1081, 1082, 1085, 1090, 1091, 1092, 1093, 1096, 1097, 1102, 1103, 1104, 1106, 1111, 1112, 1113, 1114, 1117, 1118, 1119, 1124, 1125, 1126, 1127, 1132, 1133, 1136, 1140, 1143, 1144, 1145, 1146, 1147, 1148, 1151, 1152, 1153, 1158, 1159, 1160, 1161, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173, 1176, 1177, 1178, 1179, 1180, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1197, 1198, 1209, 1210, 1213, 1216, 1220, 1223, 1227, 1230, 1234, 1237, 1241, 1244};
/* BEGIN LINEINFO 
assign 1 396 391
typenameGet 0 396 391
assign 1 396 392
CATCHGet 0 396 392
assign 1 396 393
equals 1 396 398
assign 1 397 399
containedGet 0 397 399
assign 1 397 400
firstGet 0 397 400
assign 1 397 401
containedGet 0 397 401
assign 1 397 402
firstGet 0 397 402
assign 1 397 403
heldGet 0 397 403
assign 1 397 404
isTypedGet 0 397 404
assign 1 398 406
new 0 398 406
assign 1 398 407
new 1 398 407
throw 1 398 408
assign 1 401 411
typenameGet 0 401 411
assign 1 401 412
CLASSGet 0 401 412
assign 1 401 413
equals 1 401 418
assign 1 402 419
assign 1 403 420
heldGet 0 403 420
assign 1 403 421
namepathGet 0 403 421
assign 1 404 422
heldGet 0 404 422
assign 1 404 423
synGet 0 404 423
assign 1 406 425
typenameGet 0 406 425
assign 1 406 426
METHODGet 0 406 426
assign 1 406 427
equals 1 406 432
assign 1 407 433
new 0 407 433
assign 1 409 435
typenameGet 0 409 435
assign 1 409 436
CALLGet 0 409 436
assign 1 409 437
equals 1 409 442
assign 1 410 443
heldGet 0 410 443
cposSet 1 410 444
assign 1 411 445
increment 0 411 445
assign 1 412 446
containedGet 0 412 446
assign 1 412 447
iteratorGet 0 0 447
assign 1 412 450
hasNextGet 0 412 450
assign 1 412 452
nextGet 0 412 452
assign 1 413 453
typenameGet 0 413 453
assign 1 413 454
VARGet 0 413 454
assign 1 413 455
equals 1 413 460
assign 1 414 461
heldGet 0 414 461
addCall 1 414 462
assign 1 425 469
heldGet 0 425 469
assign 1 425 470
orgNameGet 0 425 470
assign 1 425 471
new 0 425 471
assign 1 425 472
equals 1 425 472
assign 1 426 474
containedGet 0 426 474
assign 1 426 475
firstGet 0 426 475
assign 1 428 476
heldGet 0 428 476
assign 1 428 477
isDeclaredGet 0 428 477
assign 1 429 479
heldGet 0 429 479
assign 1 431 482
ptyMapGet 0 431 482
assign 1 431 483
heldGet 0 431 483
assign 1 431 484
nameGet 0 431 484
assign 1 431 485
get 1 431 485
assign 1 431 486
memSynGet 0 431 486
assign 1 434 488
isTypedGet 0 434 488
assign 1 434 489
not 0 434 489
assign 1 435 491
heldGet 0 435 491
assign 1 435 492
new 0 435 492
checkTypesSet 1 435 493
assign 1 437 496
secondGet 0 437 496
assign 1 438 497
typenameGet 0 438 497
assign 1 438 498
TRUEGet 0 438 498
assign 1 438 499
equals 1 438 504
assign 1 0 505
assign 1 438 508
typenameGet 0 438 508
assign 1 438 509
FALSEGet 0 438 509
assign 1 438 510
equals 1 438 515
assign 1 0 516
assign 1 0 519
assign 1 440 523
heldGet 0 440 523
assign 1 440 524
new 0 440 524
checkTypesSet 1 440 525
assign 1 442 528
typenameGet 0 442 528
assign 1 442 529
VARGet 0 442 529
assign 1 442 530
equals 1 442 535
assign 1 443 536
heldGet 0 443 536
assign 1 443 537
isDeclaredGet 0 443 537
assign 1 444 539
heldGet 0 444 539
assign 1 447 542
ptyMapGet 0 447 542
assign 1 447 543
heldGet 0 447 543
assign 1 447 544
nameGet 0 447 544
assign 1 447 545
get 1 447 545
assign 1 447 546
memSynGet 0 447 546
assign 1 450 550
typenameGet 0 450 550
assign 1 450 551
CALLGet 0 450 551
assign 1 450 552
equals 1 450 557
assign 1 451 558
containedGet 0 451 558
assign 1 451 559
firstGet 0 451 559
assign 1 453 560
heldGet 0 453 560
assign 1 453 561
isDeclaredGet 0 453 561
assign 1 455 563
heldGet 0 455 563
assign 1 458 566
ptyMapGet 0 458 566
assign 1 458 567
heldGet 0 458 567
assign 1 458 568
nameGet 0 458 568
assign 1 458 569
get 1 458 569
assign 1 458 570
memSynGet 0 458 570
assign 1 461 572
assign 1 462 573
heldGet 0 462 573
assign 1 462 574
newNpGet 0 462 574
assign 1 462 575
def 1 462 580
assign 1 463 581
heldGet 0 463 581
assign 1 463 582
newNpGet 0 463 582
assign 1 463 583
getSynNp 1 463 583
assign 1 464 586
isTypedGet 0 464 586
assign 1 466 588
namepathGet 0 466 588
assign 1 466 589
getSynNp 1 466 589
assign 1 468 592
def 1 468 597
assign 1 469 598
mtdMapGet 0 469 598
assign 1 469 599
heldGet 0 469 599
assign 1 469 600
nameGet 0 469 600
assign 1 469 601
get 1 469 601
assign 1 470 602
undef 1 470 607
assign 1 471 608
mtdMapGet 0 471 608
assign 1 471 609
heldGet 0 471 609
assign 1 471 610
orgNameGet 0 471 610
assign 1 471 611
new 0 471 611
assign 1 471 612
add 1 471 612
assign 1 471 613
get 1 471 613
assign 1 471 614
def 1 471 619
assign 1 0 620
assign 1 472 623
mtdMapGet 0 472 623
assign 1 472 624
new 0 472 624
assign 1 472 625
get 1 472 625
assign 1 472 626
def 1 472 631
assign 1 0 632
assign 1 0 635
assign 1 473 639
heldGet 0 473 639
assign 1 473 640
new 0 473 640
untypedSet 1 473 641
assign 1 475 644
new 0 475 644
assign 1 475 645
new 2 475 645
throw 1 475 646
assign 1 478 650
rsynGet 0 478 650
assign 1 482 655
def 1 482 660
assign 1 482 661
isTypedGet 0 482 661
assign 1 0 663
assign 1 0 666
assign 1 0 670
assign 1 484 673
new 0 484 673
assign 1 485 674
isSelfGet 0 485 674
assign 1 487 676
undef 1 487 681
assign 1 488 682
new 0 488 682
assign 1 488 683
new 1 488 683
throw 1 488 684
assign 1 493 686
originGet 0 493 686
assign 1 493 687
namepathGet 0 493 687
assign 1 493 688
notEquals 1 493 688
assign 1 495 690
new 0 495 690
assign 1 496 693
emitCommonGet 0 496 693
assign 1 496 694
def 1 496 699
assign 1 496 700
emitCommonGet 0 496 700
assign 1 496 701
coanyiantReturnsGet 0 496 701
assign 1 496 702
not 0 496 702
assign 1 0 704
assign 1 0 707
assign 1 0 711
assign 1 497 714
new 0 497 714
assign 1 499 719
def 1 499 724
assign 1 500 725
getEmitReturnType 2 500 725
assign 1 500 726
getSynNp 1 500 726
assign 1 502 729
namepathGet 0 502 729
assign 1 502 730
getSynNp 1 502 730
assign 1 506 733
namepathGet 0 506 733
assign 1 506 734
castsTo 1 506 734
assign 1 508 736
heldGet 0 508 736
assign 1 508 737
new 0 508 737
checkTypesSet 1 508 738
assign 1 510 741
isSelfGet 0 510 741
assign 1 511 743
namepathGet 0 511 743
assign 1 513 746
namepathGet 0 513 746
assign 1 515 748
namepathGet 0 515 748
assign 1 515 749
getSynNp 1 515 749
assign 1 516 750
castsTo 1 516 750
assign 1 518 752
heldGet 0 518 752
assign 1 518 753
new 0 518 753
checkTypesSet 1 518 754
assign 1 520 757
new 0 520 757
assign 1 520 758
namepathGet 0 520 758
assign 1 520 759
toString 0 520 759
assign 1 520 760
add 1 520 760
assign 1 520 761
new 0 520 761
assign 1 520 762
add 1 520 762
assign 1 520 763
toString 0 520 763
assign 1 520 764
add 1 520 764
assign 1 520 765
new 2 520 765
throw 1 520 766
assign 1 526 770
heldGet 0 526 770
assign 1 526 771
new 0 526 771
checkTypesSet 1 526 772
assign 1 529 775
heldGet 0 529 775
assign 1 529 776
namepathGet 0 529 776
assign 1 529 777
def 1 529 782
assign 1 534 788
heldGet 0 534 788
assign 1 534 789
orgNameGet 0 534 789
assign 1 534 790
new 0 534 790
assign 1 534 791
equals 1 534 791
assign 1 535 793
secondGet 0 535 793
assign 1 536 794
typenameGet 0 536 794
assign 1 536 795
VARGet 0 536 795
assign 1 536 796
equals 1 536 801
assign 1 537 802
heldGet 0 537 802
assign 1 537 803
isDeclaredGet 0 537 803
assign 1 538 805
heldGet 0 538 805
assign 1 540 808
ptyMapGet 0 540 808
assign 1 540 809
heldGet 0 540 809
assign 1 540 810
nameGet 0 540 810
assign 1 540 811
get 1 540 811
assign 1 540 812
memSynGet 0 540 812
assign 1 543 814
scopeGet 0 543 814
assign 1 544 815
heldGet 0 544 815
assign 1 544 816
isDeclaredGet 0 544 816
assign 1 545 818
heldGet 0 545 818
assign 1 547 821
ptyMapGet 0 547 821
assign 1 547 822
heldGet 0 547 822
assign 1 547 823
nameGet 0 547 823
assign 1 547 824
get 1 547 824
assign 1 547 825
memSynGet 0 547 825
assign 1 550 827
heldGet 0 550 827
assign 1 550 828
rtypeGet 0 550 828
assign 1 550 829
def 1 550 834
assign 1 550 835
heldGet 0 550 835
assign 1 550 836
rtypeGet 0 550 836
assign 1 550 837
isTypedGet 0 550 837
assign 1 0 839
assign 1 0 842
assign 1 0 846
assign 1 551 849
isTypedGet 0 551 849
assign 1 551 850
not 0 551 850
assign 1 552 852
heldGet 0 552 852
assign 1 552 853
rtypeGet 0 552 853
assign 1 552 854
isThisGet 0 552 854
assign 1 553 856
new 0 553 856
assign 1 553 857
new 2 553 857
throw 1 553 858
assign 1 556 860
heldGet 0 556 860
assign 1 556 861
new 0 556 861
checkTypesSet 1 556 862
assign 1 560 865
heldGet 0 560 865
assign 1 560 866
rtypeGet 0 560 866
assign 1 560 867
isSelfGet 0 560 867
assign 1 561 869
nameGet 0 561 869
assign 1 561 870
new 0 561 870
assign 1 561 871
equals 1 561 871
assign 1 563 873
heldGet 0 563 873
assign 1 563 874
new 0 563 874
checkTypesSet 1 563 875
assign 1 565 878
heldGet 0 565 878
assign 1 565 879
rtypeGet 0 565 879
assign 1 565 880
isThisGet 0 565 880
assign 1 566 882
new 0 566 882
assign 1 566 883
new 2 566 883
throw 1 566 884
assign 1 568 886
namepathGet 0 568 886
assign 1 568 887
getSynNp 1 568 887
assign 1 569 888
namepathGet 0 569 888
assign 1 569 889
castsTo 1 569 889
assign 1 0 891
assign 1 569 894
namepathGet 0 569 894
assign 1 569 895
castsTo 1 569 895
assign 1 0 897
assign 1 0 900
assign 1 571 904
heldGet 0 571 904
assign 1 571 905
new 0 571 905
checkTypesSet 1 571 906
assign 1 573 909
new 0 573 909
assign 1 573 910
namepathGet 0 573 910
assign 1 573 911
add 1 573 911
assign 1 573 912
new 0 573 912
assign 1 573 913
add 1 573 913
assign 1 573 914
namepathGet 0 573 914
assign 1 573 915
add 1 573 915
assign 1 573 916
new 2 573 916
throw 1 573 917
assign 1 577 922
namepathGet 0 577 922
assign 1 577 923
getSynNp 1 577 923
assign 1 578 924
heldGet 0 578 924
assign 1 578 925
rtypeGet 0 578 925
assign 1 578 926
namepathGet 0 578 926
assign 1 578 927
castsTo 1 578 927
assign 1 580 929
heldGet 0 580 929
assign 1 580 930
new 0 580 930
checkTypesSet 1 580 931
assign 1 582 934
heldGet 0 582 934
assign 1 582 935
rtypeGet 0 582 935
assign 1 582 936
namepathGet 0 582 936
assign 1 582 937
getSynNp 1 582 937
assign 1 583 938
namepathGet 0 583 938
assign 1 583 939
castsTo 1 583 939
assign 1 585 941
heldGet 0 585 941
assign 1 585 942
new 0 585 942
checkTypesSet 1 585 943
assign 1 587 946
new 0 587 946
assign 1 587 947
new 2 587 947
throw 1 587 948
assign 1 594 955
heldGet 0 594 955
assign 1 594 956
new 0 594 956
checkTypesSet 1 594 957
assign 1 597 961
heldGet 0 597 961
assign 1 597 962
new 0 597 962
checkTypesSet 1 597 963
assign 1 600 967
containedGet 0 600 967
assign 1 600 968
firstGet 0 600 968
assign 1 602 969
heldGet 0 602 969
assign 1 602 970
isDeclaredGet 0 602 970
assign 1 603 972
heldGet 0 603 972
assign 1 605 975
ptyMapGet 0 605 975
assign 1 605 976
heldGet 0 605 976
assign 1 605 977
nameGet 0 605 977
assign 1 605 978
get 1 605 978
assign 1 605 979
memSynGet 0 605 979
assign 1 608 981
isTypedGet 0 608 981
assign 1 608 982
not 0 608 982
assign 1 0 984
assign 1 608 987
heldGet 0 608 987
assign 1 608 988
orgNameGet 0 608 988
assign 1 608 989
new 0 608 989
assign 1 608 990
equals 1 608 990
assign 1 0 992
assign 1 0 995
assign 1 609 999
heldGet 0 609 999
assign 1 609 1000
new 0 609 1000
checkTypesSet 1 609 1001
assign 1 611 1004
heldGet 0 611 1004
assign 1 611 1005
new 0 611 1005
checkTypesSet 1 611 1006
assign 1 612 1007
heldGet 0 612 1007
assign 1 612 1008
isConstructGet 0 612 1008
assign 1 613 1010
heldGet 0 613 1010
assign 1 613 1011
newNpGet 0 613 1011
assign 1 613 1012
undef 1 613 1017
assign 1 614 1018
new 0 614 1018
assign 1 614 1019
new 1 614 1019
throw 1 614 1020
assign 1 616 1022
heldGet 0 616 1022
assign 1 616 1023
newNpGet 0 616 1023
assign 1 616 1024
getSynNp 1 616 1024
assign 1 617 1025
mtdMapGet 0 617 1025
assign 1 617 1026
heldGet 0 617 1026
assign 1 617 1027
nameGet 0 617 1027
assign 1 617 1028
get 1 617 1028
assign 1 619 1031
namepathGet 0 619 1031
assign 1 619 1032
getSynNp 1 619 1032
assign 1 620 1033
mtdMapGet 0 620 1033
assign 1 620 1034
heldGet 0 620 1034
assign 1 620 1035
nameGet 0 620 1035
assign 1 620 1036
get 1 620 1036
assign 1 622 1038
undef 1 622 1043
assign 1 623 1044
mtdMapGet 0 623 1044
assign 1 623 1045
heldGet 0 623 1045
assign 1 623 1046
orgNameGet 0 623 1046
assign 1 623 1047
new 0 623 1047
assign 1 623 1048
add 1 623 1048
assign 1 623 1049
get 1 623 1049
assign 1 623 1050
def 1 623 1055
assign 1 0 1056
assign 1 624 1059
mtdMapGet 0 624 1059
assign 1 624 1060
new 0 624 1060
assign 1 624 1061
get 1 624 1061
assign 1 624 1062
def 1 624 1067
assign 1 0 1068
assign 1 0 1071
assign 1 625 1075
heldGet 0 625 1075
assign 1 625 1076
new 0 625 1076
untypedSet 1 625 1077
assign 1 627 1080
new 0 627 1080
assign 1 627 1081
new 2 627 1081
throw 1 627 1082
assign 1 630 1085
def 1 630 1090
assign 1 631 1091
argSynsGet 0 631 1091
assign 1 632 1092
nextPeerGet 0 632 1092
assign 1 633 1093
new 0 633 1093
assign 1 633 1096
lengthGet 0 633 1096
assign 1 633 1097
lesser 1 633 1102
assign 1 634 1103
get 1 634 1103
assign 1 635 1104
isTypedGet 0 635 1104
assign 1 636 1106
undef 1 636 1111
assign 1 637 1112
new 0 637 1112
assign 1 637 1113
new 2 637 1113
throw 1 637 1114
assign 1 638 1117
typenameGet 0 638 1117
assign 1 638 1118
VARGet 0 638 1118
assign 1 638 1119
notEquals 1 638 1124
assign 1 638 1125
typenameGet 0 638 1125
assign 1 638 1126
NULLGet 0 638 1126
assign 1 638 1127
notEquals 1 638 1132
assign 1 0 1133
assign 1 0 1136
assign 1 0 1140
assign 1 639 1143
new 0 639 1143
assign 1 639 1144
typenameGet 0 639 1144
assign 1 639 1145
toString 0 639 1145
assign 1 639 1146
add 1 639 1146
assign 1 639 1147
new 2 639 1147
throw 1 639 1148
assign 1 641 1151
typenameGet 0 641 1151
assign 1 641 1152
VARGet 0 641 1152
assign 1 641 1153
equals 1 641 1158
assign 1 642 1159
heldGet 0 642 1159
assign 1 643 1160
isTypedGet 0 643 1160
assign 1 643 1161
not 0 643 1166
assign 1 644 1167
heldGet 0 644 1167
assign 1 644 1168
new 0 644 1168
checkTypesSet 1 644 1169
assign 1 645 1170
heldGet 0 645 1170
assign 1 645 1171
argCastsGet 0 645 1171
assign 1 645 1172
namepathGet 0 645 1172
put 2 645 1173
assign 1 648 1176
namepathGet 0 648 1176
assign 1 648 1177
getSynNp 1 648 1177
assign 1 649 1178
namepathGet 0 649 1178
assign 1 649 1179
castsTo 1 649 1179
assign 1 649 1180
not 0 649 1180
assign 1 650 1182
new 0 650 1182
assign 1 650 1183
namepathGet 0 650 1183
assign 1 650 1184
toString 0 650 1184
assign 1 650 1185
add 1 650 1185
assign 1 650 1186
new 0 650 1186
assign 1 650 1187
add 1 650 1187
assign 1 650 1188
namepathGet 0 650 1188
assign 1 650 1189
toString 0 650 1189
assign 1 650 1190
add 1 650 1190
assign 1 650 1191
new 2 650 1191
throw 1 650 1192
assign 1 659 1197
nextPeerGet 0 659 1197
assign 1 633 1198
increment 0 633 1198
assign 1 665 1209
nextDescendGet 0 665 1209
return 1 665 1210
return 1 0 1213
assign 1 0 1216
return 1 0 1220
assign 1 0 1223
return 1 0 1227
assign 1 0 1230
return 1 0 1234
assign 1 0 1237
return 1 0 1241
assign 1 0 1244
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -2028575047: return bem_emitterGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case -2041762316: return bem_inClassGet_0();
case -1012494862: return bem_once_0();
case -997464046: return bem_inClassSynGet_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -2030680063: return bem_inClassSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2117282045: return bem_cposSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
}
