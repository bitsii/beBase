namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_3_2_4_17_IOFileDirectoryIterator : BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }
static BEC_3_2_4_17_IOFileDirectoryIterator() { }

   
    public IEnumerator<string> bevi_dir;
    
   private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static new BEC_3_2_4_17_IOFileDirectoryIterator bevs_inst;
public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) {
this.bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 471 */
 else  /* Line: 473 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bels_0));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 474 */
if (bevp_closed.bevi_bool) /* Line: 477 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(64, bels_1));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 479 */
if (bevp_opened.bevi_bool) /* Line: 481 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_2));
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 482 */

      bevi_dir = Directory.EnumerateFileSystemEntries(bevl_path.bems_toCsString(), "*", SearchOption.TopDirectoryOnly).GetEnumerator();
      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 506 */
 else  /* Line: 507 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 510 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 515 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 515 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 516 */ {
this.bem_open_0();
} /* Line: 516 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 521 */ {
return null;
} /* Line: 521 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
this.bem_open_0();
} /* Line: 522 */
bevl_toRet = bevp_current;
this.bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 532 */ {
return this;
} /* Line: 532 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 533 */ {
return this;
} /* Line: 533 */
if (bevp_current == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 534 */ {
return this;
} /* Line: 534 */

      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 550 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 552 */
 else  /* Line: 553 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 556 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() {

      bevi_dir.Dispose();
      bevi_dir = null;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {453, 454, 455, 461, 462, 470, 470, 471, 471, 474, 474, 474, 479, 479, 479, 482, 482, 482, 503, 503, 505, 506, 509, 510, 515, 515, 516, 516, 516, 517, 517, 521, 522, 522, 522, 523, 524, 525, 532, 533, 533, 533, 534, 534, 534, 550, 550, 551, 552, 554, 555, 556, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {29, 30, 31, 35, 36, 51, 56, 57, 58, 61, 62, 63, 66, 67, 68, 71, 72, 73, 80, 85, 86, 87, 90, 91, 100, 101, 103, 108, 109, 111, 116, 122, 124, 129, 130, 132, 133, 134, 142, 144, 149, 150, 152, 157, 158, 164, 169, 170, 171, 174, 175, 176, 187, 190, 194, 197, 201, 204, 208, 211};
/* BEGIN LINEINFO 
assign 1 453 29
new 0 453 29
assign 1 454 30
new 0 454 30
assign 1 455 31
new 0 461 35
assign 1 462 36
assign 1 470 51
def 1 470 56
assign 1 471 57
pathGet 0 471 57
assign 1 471 58
toString 0 471 58
assign 1 474 61
new 0 474 61
assign 1 474 62
new 1 474 62
throw 1 474 63
assign 1 479 66
new 0 479 66
assign 1 479 67
new 1 479 67
throw 1 479 68
assign 1 482 71
new 0 482 71
assign 1 482 72
new 1 482 72
throw 1 482 73
assign 1 503 80
def 1 503 85
assign 1 505 86
new 0 505 86
assign 1 506 87
apNew 1 506 87
assign 1 509 90
new 0 509 90
assign 1 510 91
new 0 510 91
assign 1 515 100
new 0 515 100
return 1 515 101
assign 1 516 103
not 0 516 108
open 0 516 109
assign 1 517 111
def 1 517 116
return 1 517 116
return 1 521 122
assign 1 522 124
not 0 522 129
open 0 522 130
assign 1 523 132
advance 0 524 133
return 1 525 134
return 1 532 142
assign 1 533 144
not 0 533 149
return 1 533 150
assign 1 534 152
undef 1 534 157
return 1 534 158
assign 1 550 164
def 1 550 169
assign 1 551 170
new 0 551 170
assign 1 552 171
apNew 1 552 171
assign 1 554 174
new 0 554 174
assign 1 555 175
new 0 555 175
assign 1 556 176
return 1 0 187
assign 1 0 190
return 1 0 194
assign 1 0 197
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 218396922: return bem_dirGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 1446310798: return bem_currentGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 1194623572: return bem_nextGet_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case -809133133: return bem_advance_0();
case -1010579589: return bem_open_0();
case 513687198: return bem_openedGet_0();
case 866536361: return bem_close_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 108485850: return bem_hasNextGet_0();
case -1354714650: return bem_copy_0();
case 617762683: return bem_closedGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 524769451: return bem_openedSet_1(bevd_0);
case 628844936: return bem_closedSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 229479175: return bem_dirSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_17_IOFileDirectoryIterator.bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bevs_inst;
}
}
}
