namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 5));
private static byte[] bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_23 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_25 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_26 = {0x74,0x72,0x75,0x65};
private static byte[] bels_27 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_28 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_29 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_30 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_31 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_33 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_34 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_35 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_36 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_38 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_39 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_40 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_41 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_45 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_46 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_47 = {0x72,0x75,0x6E};
private static byte[] bels_48 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_49 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_50 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_51 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_52 = {0x67,0x63,0x63};
private static byte[] bels_53 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_54 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_55 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_55, 9));
private static byte[] bels_56 = {};
private static byte[] bels_57 = {0x63};
private static byte[] bels_58 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_58, 8));
private static byte[] bels_59 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_59, 7));
private static byte[] bels_60 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_61 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_62 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_62, 2));
private static byte[] bels_63 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_63, 2));
private static byte[] bels_64 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_64, 2));
private static byte[] bels_65 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_66 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_66, 19));
private static byte[] bels_67 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_67, 31));
private static byte[] bels_68 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_68, 41));
private static byte[] bels_69 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_69, 30));
private static byte[] bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_70, 31));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_71, 41));
private static byte[] bels_72 = {0x2F};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_72, 1));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_74, 41));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_75, 51));
private static byte[] bels_76 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_76, 14));
private static byte[] bels_77 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_77, 19));
private static byte[] bels_78 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_78, 9));
private static byte[] bels_79 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_79, 13));
private static byte[] bels_80 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 2));
private static byte[] bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 22));
private static byte[] bels_82 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_82, 3));
private static byte[] bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_83, 15));
private static byte[] bels_84 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_84, 4));
private static byte[] bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_85, 15));
private static byte[] bels_86 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_86, 5));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_87, 15));
private static byte[] bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_88, 6));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_90, 7));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_92, 8));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_94, 9));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 10));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_98, 11));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_43 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_99, 16));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_100, 12));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_45 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_101, 16));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_102, 13));
private static byte[] bels_103 = {0x20};
private static BEC_2_4_6_TextString bevo_47 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_103, 1));
private static byte[] bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_48 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_104, 16));
public static new BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 97 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevp_params.bem_get_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevl_res = this.bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 128 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 142 */ {
} /* Line: 142 */
return beva_addTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_113_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_11));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 152 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 153 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 156 */
} /* Line: 154 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
bevt_13_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_3;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 162 */
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_13));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_14));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_15));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 166 */
 else  /* Line: 167 */ {
bevp_exeName = bevp_libName;
} /* Line: 168 */
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_16));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_17));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_19));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_20));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_21));
bevt_36_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_22));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_2_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_23));
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_24));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_25));
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_26));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_27));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_28));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_29));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 182 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 183 */
bevt_55_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_30));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 187 */
bevt_57_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_31));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 191 */
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_32));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 195 */
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_33));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 199 */
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_34));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 203 */
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_35));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 206 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 207 */
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_36));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 211 */
bevt_69_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_37));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 215 */
bevt_71_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_38));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 219 */
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_39));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 222 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 223 */
 else  /* Line: 224 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 225 */
bevt_75_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_40));
bevt_76_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_41));
bevt_78_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_42));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_43));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_44));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 233 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_84_tmpvar_phold.bevi_bool) {
bevt_83_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_83_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 233 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 233 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 234 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 234 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 235 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
} /* Line: 234 */
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_45));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bels_46));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_47));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_48));
bevt_90_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_49));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_50));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_51));
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_52));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_53));
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_54));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_4;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_56));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 255 */
 else  /* Line: 256 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_57));
} /* Line: 257 */
bevt_106_tmpvar_phold = bevo_5;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 266 */
bevt_111_tmpvar_phold = bevo_6;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 270 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 271 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 275 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 275 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 276 */
 else  /* Line: 275 */ {
break;
} /* Line: 275 */
} /* Line: 275 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
if (bevt_118_tmpvar_phold.bevi_bool) {
bevt_117_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_117_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 284 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_122_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 289 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_60));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_61));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 303 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 305 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 310 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
} /* Line: 309 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 314 */
} /* Line: 305 */
 else  /* Line: 303 */ {
break;
} /* Line: 303 */
} /* Line: 303 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 321 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 323 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 334 */ {
return bevp_emitCommon;
} /* Line: 335 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 340 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_7;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 342 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 343 */
 else  /* Line: 342 */ {
bevt_5_tmpvar_phold = bevo_8;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 345 */
 else  /* Line: 342 */ {
bevt_7_tmpvar_phold = bevo_9;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 347 */
 else  /* Line: 348 */ {
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_65));
bevt_8_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 349 */
} /* Line: 342 */
} /* Line: 342 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 352 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_4_8_TimeInterval bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_16_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_21_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_23_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_24_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_37_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_64_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_76_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
bevt_4_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_4_tmpvar_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 362 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 365 */ {
bevt_7_tmpvar_phold = bevo_10;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_libName);
bevt_6_tmpvar_phold.bem_print_0();
} /* Line: 366 */
} /* Line: 365 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 371 */ {
bevt_8_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 371 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_10_tmpvar_phold.bevi_bool) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 372 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 375 */
} /* Line: 372 */
 else  /* Line: 371 */ {
break;
} /* Line: 371 */
} /* Line: 371 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 378 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 378 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpvar_phold.bevi_bool) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_14_tmpvar_phold = bevl_pack.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_14_tmpvar_phold);
} /* Line: 383 */
} /* Line: 379 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
if (bevp_parse.bevi_bool) /* Line: 386 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 388 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 388 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 391 */
 else  /* Line: 388 */ {
break;
} /* Line: 388 */
} /* Line: 388 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 393 */
bevt_17_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_16_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_17_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_16_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_19_tmpvar_phold = bevo_11;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_18_tmpvar_phold.bem_print_0();
bevt_21_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 400 */ {
bevt_22_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_22_tmpvar_phold.bem_now_0();
bevt_23_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_23_tmpvar_phold.bem_doEmit_0();
bevt_25_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_24_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_25_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_24_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_27_tmpvar_phold = bevo_12;
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_26_tmpvar_phold.bem_print_0();
bevt_29_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpvar_phold.bem_now_0();
bevl_emitTime = bevt_28_tmpvar_phold.bem_subtract_1(bevl_emitStart);
bevt_31_tmpvar_phold = bevo_13;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevl_emitTime);
bevt_30_tmpvar_phold.bem_print_0();
bevt_32_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_32_tmpvar_phold;
} /* Line: 408 */
if (bevp_doEmit.bevi_bool) /* Line: 410 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_33_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_33_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 414 */ {
bevt_34_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 414 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(-4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 416 */
 else  /* Line: 414 */ {
break;
} /* Line: 414 */
} /* Line: 414 */
bevl_em.bemd_0(-1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_35_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_35_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 420 */ {
bevt_36_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 420 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 422 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
} /* Line: 420 */
bevt_38_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_37_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_38_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_37_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_39_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_41_tmpvar_phold = bevo_14;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_40_tmpvar_phold.bem_print_0();
} /* Line: 428 */
bevt_43_tmpvar_phold = bevo_15;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_42_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 431 */ {
bevl_em.bemd_1(-1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 433 */
if (bevp_make.bevi_bool) /* Line: 436 */ {
if (bevp_genOnly.bevi_bool) {
bevt_44_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 437 */ {
bevl_em.bemd_1(-1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 440 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 441 */ {
bevt_45_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 441 */ {
bevl_bp = bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_46_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_46_tmpvar_phold.bemd_0(-159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_47_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_47_tmpvar_phold.bem_copy_0();
bevt_49_tmpvar_phold = bevl_cpFrom.bemd_0(-723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_48_tmpvar_phold);
bevt_51_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 445 */ {
bevt_52_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_52_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 446 */
bevt_55_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 448 */ {
bevt_56_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
} /* Line: 449 */
} /* Line: 448 */
 else  /* Line: 441 */ {
break;
} /* Line: 441 */
} /* Line: 441 */
} /* Line: 441 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 456 */ {
bevt_58_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 456 */ {
bevt_59_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 456 */
 else  /* Line: 456 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 456 */ {
bevt_60_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_60_tmpvar_phold);
bevt_65_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_64_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_65_tmpvar_phold.bem_copy_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_toString_0();
bevt_66_tmpvar_phold = bevo_16;
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_add_1(bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bem_add_1(bevt_67_tmpvar_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_61_tmpvar_phold);
bevt_69_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_68_tmpvar_phold != null && bevt_68_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_68_tmpvar_phold).bevi_bool) /* Line: 460 */ {
bevt_70_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_70_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 461 */
bevt_73_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 463 */ {
bevt_74_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_75_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
} /* Line: 464 */
} /* Line: 463 */
 else  /* Line: 456 */ {
break;
} /* Line: 456 */
} /* Line: 456 */
} /* Line: 456 */
} /* Line: 437 */
bevt_77_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_76_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_77_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_76_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_78_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 471 */ {
bevt_80_tmpvar_phold = bevo_17;
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_79_tmpvar_phold.bem_print_0();
} /* Line: 472 */
if (bevp_parseEmitTime == null) {
bevt_81_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 474 */ {
bevt_83_tmpvar_phold = bevo_18;
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_82_tmpvar_phold.bem_print_0();
} /* Line: 475 */
if (bevp_parseEmitCompileTime == null) {
bevt_84_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 477 */ {
bevt_86_tmpvar_phold = bevo_19;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_85_tmpvar_phold.bem_print_0();
} /* Line: 478 */
if (bevp_run.bevi_bool) /* Line: 481 */ {
bevt_87_tmpvar_phold = bevo_20;
bevt_87_tmpvar_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_90_tmpvar_phold = bevo_21;
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_add_1(bevl_result);
bevt_91_tmpvar_phold = bevo_22;
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_add_1(bevt_91_tmpvar_phold);
bevt_88_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 485 */
bevt_92_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_92_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 491 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 491 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 495 */
 else  /* Line: 491 */ {
break;
} /* Line: 491 */
} /* Line: 491 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 497 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 501 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
bevt_6_tmpvar_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 507 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 508 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 511 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 512 */
 else  /* Line: 513 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 521 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 523 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpvar_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 533 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 534 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 549 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 550 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 563 */ {
if (bevp_printSteps.bevi_bool) /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 564 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 564 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 564 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 564 */ {
bevt_4_tmpvar_phold = bevo_23;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 565 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 574 */ {
bevt_11_tmpvar_phold = bevo_24;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 575 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(-1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 578 */ {
bevt_13_tmpvar_phold = bevo_25;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 580 */
if (bevp_printSteps.bevi_bool) /* Line: 583 */ {
bevt_15_tmpvar_phold = bevo_26;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 584 */
bevt_16_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 587 */ {
bevt_17_tmpvar_phold = bevo_27;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 589 */
if (bevp_printSteps.bevi_bool) /* Line: 591 */ {
bevt_19_tmpvar_phold = bevo_28;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 592 */
bevt_20_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(-410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 597 */ {
bevt_21_tmpvar_phold = bevo_29;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 599 */
if (bevp_printSteps.bevi_bool) /* Line: 602 */ {
bevt_23_tmpvar_phold = bevo_30;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 603 */
bevt_24_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 606 */ {
bevt_25_tmpvar_phold = bevo_31;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 608 */
if (bevp_printSteps.bevi_bool) /* Line: 611 */ {
bevt_27_tmpvar_phold = bevo_32;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 612 */
bevt_28_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 615 */ {
bevt_29_tmpvar_phold = bevo_33;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 617 */
if (bevp_printSteps.bevi_bool) /* Line: 620 */ {
bevt_31_tmpvar_phold = bevo_34;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 621 */
bevt_32_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_33_tmpvar_phold = bevo_35;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_35_tmpvar_phold = bevo_36;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 630 */
bevt_36_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_37_tmpvar_phold = bevo_37;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_39_tmpvar_phold = bevo_38;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 639 */
bevt_40_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_41_tmpvar_phold = bevo_39;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_43_tmpvar_phold = bevo_40;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 648 */
bevt_44_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_45_tmpvar_phold = bevo_41;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_47_tmpvar_phold = bevo_42;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 657 */
bevt_48_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_49_tmpvar_phold = bevo_43;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 664 */ {
bevt_51_tmpvar_phold = bevo_44;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 665 */
bevt_52_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 668 */ {
bevt_53_tmpvar_phold = bevo_45;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 670 */
if (bevp_printSteps.bevi_bool) /* Line: 673 */ {
bevt_55_tmpvar_phold = bevo_46;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_47;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 675 */
bevt_57_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 678 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 678 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 678 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 678 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 678 */ {
bevt_58_tmpvar_phold = bevo_48;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 680 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 682 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 682 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(-1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(-568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(-557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 693 */
 else  /* Line: 682 */ {
break;
} /* Line: 682 */
} /* Line: 682 */
} /* Line: 682 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 703 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 703 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 707 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 708 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 710 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 712 */
} /* Line: 710 */
 else  /* Line: 703 */ {
break;
} /* Line: 703 */
} /* Line: 703 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_6_SystemObject bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_6_6_SystemObject bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_6_6_SystemObject bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {53, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 70, 72, 73, 74, 75, 75, 78, 81, 82, 88, 89, 90, 91, 91, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 144, 149, 151, 152, 152, 152, 153, 153, 0, 153, 153, 154, 154, 154, 155, 156, 156, 161, 161, 161, 161, 162, 164, 164, 164, 165, 165, 166, 166, 166, 168, 170, 170, 170, 170, 170, 170, 171, 172, 172, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 179, 179, 179, 180, 180, 180, 181, 181, 182, 182, 183, 185, 185, 186, 186, 187, 189, 189, 190, 190, 191, 193, 193, 194, 194, 195, 197, 197, 198, 198, 199, 201, 201, 202, 202, 203, 205, 205, 206, 206, 207, 209, 209, 210, 210, 211, 213, 213, 214, 214, 215, 217, 217, 218, 218, 219, 221, 221, 222, 222, 223, 225, 227, 227, 227, 228, 228, 228, 229, 229, 230, 230, 231, 232, 232, 233, 233, 233, 233, 233, 0, 0, 0, 234, 0, 234, 234, 235, 238, 238, 239, 239, 240, 240, 241, 241, 241, 242, 242, 243, 243, 244, 244, 244, 244, 245, 245, 245, 245, 246, 246, 246, 246, 246, 247, 248, 249, 250, 251, 254, 254, 255, 257, 264, 264, 264, 264, 264, 265, 265, 266, 266, 269, 269, 269, 270, 270, 271, 271, 274, 275, 275, 0, 275, 275, 276, 276, 278, 279, 280, 282, 283, 283, 283, 283, 284, 284, 286, 286, 287, 287, 288, 288, 289, 295, 296, 296, 296, 296, 296, 297, 297, 297, 297, 297, 298, 302, 303, 303, 303, 304, 305, 305, 305, 305, 306, 306, 306, 306, 307, 307, 307, 307, 307, 308, 308, 309, 0, 309, 309, 310, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 321, 321, 321, 322, 323, 323, 323, 323, 323, 323, 330, 330, 334, 334, 335, 340, 340, 341, 342, 342, 343, 344, 344, 345, 346, 346, 347, 349, 349, 349, 351, 352, 354, 359, 359, 360, 361, 362, 362, 363, 364, 366, 366, 366, 369, 371, 0, 371, 371, 372, 372, 372, 373, 374, 375, 378, 0, 378, 378, 379, 379, 379, 380, 381, 382, 383, 383, 388, 388, 389, 391, 393, 396, 396, 396, 398, 398, 398, 400, 400, 400, 402, 402, 403, 403, 404, 404, 404, 405, 405, 405, 406, 406, 406, 407, 407, 407, 408, 408, 411, 412, 414, 414, 414, 415, 416, 418, 419, 420, 420, 420, 421, 422, 426, 426, 426, 427, 427, 428, 428, 428, 430, 430, 430, 433, 437, 437, 438, 439, 441, 0, 441, 441, 442, 442, 443, 443, 444, 444, 444, 445, 445, 446, 446, 448, 448, 448, 449, 449, 449, 453, 454, 456, 456, 0, 0, 0, 457, 457, 458, 458, 458, 458, 458, 458, 458, 458, 460, 460, 461, 461, 463, 463, 463, 464, 464, 464, 469, 469, 469, 471, 471, 472, 472, 472, 474, 474, 475, 475, 475, 477, 477, 478, 478, 478, 482, 482, 483, 484, 484, 484, 484, 484, 485, 487, 487, 491, 491, 491, 492, 493, 493, 494, 495, 497, 497, 497, 498, 499, 499, 500, 501, 503, 503, 507, 507, 507, 507, 508, 508, 508, 510, 510, 511, 511, 511, 511, 512, 514, 514, 514, 514, 514, 516, 516, 517, 517, 518, 521, 521, 521, 523, 525, 525, 526, 526, 526, 526, 527, 531, 532, 532, 533, 533, 534, 540, 540, 541, 542, 549, 549, 550, 552, 557, 558, 559, 560, 561, 562, 562, 0, 0, 0, 565, 565, 565, 565, 567, 569, 569, 569, 569, 570, 570, 570, 571, 575, 575, 577, 577, 579, 579, 580, 580, 584, 584, 586, 586, 588, 588, 589, 589, 592, 592, 595, 595, 596, 598, 598, 599, 599, 603, 603, 605, 605, 607, 607, 608, 608, 612, 612, 614, 614, 616, 616, 617, 617, 621, 621, 623, 623, 625, 625, 626, 626, 630, 630, 632, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 665, 665, 667, 667, 669, 669, 670, 670, 674, 674, 675, 675, 677, 677, 0, 0, 0, 679, 679, 680, 680, 682, 682, 682, 683, 685, 686, 687, 687, 688, 689, 689, 689, 690, 691, 692, 693, 699, 700, 701, 702, 702, 703, 703, 704, 705, 705, 706, 707, 707, 708, 710, 710, 711, 712, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 272, 277, 278, 279, 281, 284, 285, 287, 290, 294, 297, 301, 304, 305, 307, 308, 314, 315, 316, 317, 324, 325, 326, 327, 328, 340, 341, 342, 343, 344, 345, 346, 347, 350, 355, 356, 357, 363, 371, 372, 373, 375, 376, 377, 381, 382, 383, 384, 385, 388, 392, 395, 399, 401, 407, 408, 409, 412, 548, 549, 550, 551, 556, 557, 558, 558, 561, 563, 564, 565, 570, 571, 572, 573, 581, 582, 583, 584, 586, 588, 589, 590, 591, 592, 594, 595, 596, 599, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 650, 651, 653, 654, 655, 660, 661, 663, 664, 665, 670, 671, 673, 674, 675, 680, 681, 683, 684, 685, 690, 691, 693, 694, 695, 700, 701, 703, 704, 705, 710, 711, 713, 714, 715, 720, 721, 723, 724, 725, 730, 731, 733, 734, 735, 740, 741, 743, 744, 745, 750, 751, 754, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 774, 775, 776, 781, 782, 785, 789, 792, 792, 795, 797, 798, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 841, 842, 845, 847, 848, 849, 850, 851, 852, 857, 858, 859, 861, 862, 863, 864, 869, 870, 871, 873, 874, 875, 875, 878, 880, 881, 882, 888, 889, 890, 891, 892, 893, 894, 899, 900, 901, 903, 908, 909, 910, 911, 912, 913, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 978, 979, 980, 983, 985, 986, 987, 988, 989, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1005, 1006, 1006, 1009, 1011, 1012, 1019, 1020, 1021, 1022, 1023, 1024, 1029, 1030, 1030, 1033, 1035, 1036, 1049, 1050, 1053, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1071, 1072, 1086, 1091, 1092, 1094, 1099, 1100, 1101, 1102, 1104, 1107, 1108, 1110, 1113, 1114, 1116, 1119, 1120, 1121, 1125, 1126, 1128, 1240, 1241, 1242, 1243, 1244, 1249, 1250, 1251, 1253, 1254, 1255, 1258, 1259, 1259, 1262, 1264, 1265, 1266, 1271, 1272, 1273, 1274, 1281, 1281, 1284, 1286, 1287, 1288, 1293, 1294, 1295, 1296, 1297, 1298, 1306, 1309, 1311, 1312, 1318, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1347, 1348, 1349, 1350, 1353, 1354, 1355, 1356, 1359, 1361, 1362, 1368, 1369, 1370, 1371, 1374, 1376, 1377, 1384, 1385, 1386, 1387, 1392, 1393, 1394, 1395, 1397, 1398, 1399, 1401, 1404, 1409, 1410, 1411, 1413, 1413, 1416, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1429, 1430, 1432, 1433, 1434, 1436, 1437, 1438, 1446, 1447, 1450, 1452, 1454, 1457, 1461, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1477, 1478, 1480, 1481, 1482, 1484, 1485, 1486, 1495, 1496, 1497, 1498, 1503, 1504, 1505, 1506, 1508, 1513, 1514, 1515, 1516, 1518, 1523, 1524, 1525, 1526, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1539, 1540, 1553, 1554, 1557, 1559, 1560, 1561, 1562, 1563, 1569, 1570, 1573, 1575, 1576, 1577, 1578, 1579, 1585, 1586, 1614, 1615, 1616, 1621, 1622, 1623, 1624, 1626, 1627, 1628, 1629, 1630, 1635, 1636, 1639, 1640, 1641, 1642, 1643, 1644, 1649, 1650, 1651, 1652, 1655, 1656, 1657, 1659, 1661, 1662, 1663, 1664, 1665, 1666, 1667, 1675, 1676, 1677, 1678, 1683, 1684, 1686, 1687, 1688, 1689, 1693, 1698, 1699, 1701, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1789, 1793, 1796, 1800, 1801, 1802, 1803, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1815, 1816, 1818, 1819, 1821, 1822, 1823, 1824, 1827, 1828, 1830, 1831, 1833, 1834, 1835, 1836, 1839, 1840, 1842, 1843, 1844, 1846, 1847, 1848, 1849, 1852, 1853, 1855, 1856, 1858, 1859, 1860, 1861, 1864, 1865, 1867, 1868, 1870, 1871, 1872, 1873, 1876, 1877, 1879, 1880, 1882, 1883, 1884, 1885, 1888, 1889, 1891, 1892, 1894, 1895, 1896, 1897, 1900, 1901, 1903, 1904, 1906, 1907, 1908, 1909, 1912, 1913, 1915, 1916, 1918, 1919, 1920, 1921, 1924, 1925, 1927, 1928, 1930, 1931, 1932, 1933, 1936, 1937, 1939, 1940, 1942, 1943, 1944, 1945, 1948, 1949, 1950, 1951, 1953, 1954, 1956, 1960, 1963, 1967, 1968, 1969, 1970, 1972, 1973, 1976, 1978, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990, 2012, 2013, 2014, 2015, 2016, 2017, 2020, 2022, 2023, 2024, 2025, 2026, 2027, 2029, 2031, 2032, 2034, 2035, 2045, 2048, 2052, 2055, 2059, 2062, 2066, 2069, 2073, 2076, 2080, 2083, 2087, 2090, 2094, 2097, 2101, 2104, 2108, 2111, 2115, 2118, 2122, 2125, 2129, 2132, 2136, 2139, 2143, 2146, 2150, 2153, 2157, 2160, 2164, 2167, 2171, 2174, 2178, 2181, 2185, 2188, 2192, 2195, 2199, 2202, 2206, 2209, 2213, 2216, 2220, 2223, 2227, 2230, 2234, 2237, 2241, 2244, 2248, 2251, 2255, 2258, 2262, 2265, 2269, 2272, 2276, 2279, 2283, 2286, 2290, 2293, 2297, 2300, 2304, 2307, 2311, 2314, 2318, 2321, 2325, 2328, 2332, 2335, 2339, 2342, 2346, 2349, 2353, 2356, 2360, 2363, 2367, 2370, 2374, 2377, 2381, 2384, 2388, 2391, 2395, 2398, 2402, 2405, 2409, 2412, 2416, 2419, 2423, 2426, 2430, 2433, 2437, 2440, 2444, 2447, 2451, 2454, 2458, 2461, 2465, 2468, 2472, 2475, 2479, 2482, 2486, 2489, 2493, 2496, 2500, 2503, 2507, 2510, 2514, 2517, 2521};
/* BEGIN LINEINFO 
assign 1 53 235
new 0 53 235
assign 1 55 236
new 0 55 236
assign 1 56 237
new 0 56 237
assign 1 57 238
new 0 57 238
assign 1 58 239
new 0 58 239
assign 1 60 240
new 0 60 240
assign 1 61 241
new 0 61 241
assign 1 62 242
new 0 62 242
assign 1 63 243
new 0 63 243
assign 1 64 244
new 0 64 244
assign 1 65 245
new 0 65 245
assign 1 66 246
new 0 66 246
assign 1 70 247
new 0 70 247
assign 1 72 248
new 1 72 248
assign 1 73 249
ntypesGet 0 73 249
assign 1 74 250
twtokGet 0 74 250
assign 1 75 251
new 0 75 251
assign 1 75 252
new 1 75 252
assign 1 78 253
new 0 78 253
assign 1 81 254
new 0 81 254
assign 1 82 255
new 0 82 255
assign 1 88 256
new 0 88 256
assign 1 89 257
new 0 89 257
assign 1 90 258
new 0 90 258
assign 1 91 259
new 0 91 259
assign 1 91 260
new 1 91 260
assign 1 96 272
def 1 96 277
assign 1 96 278
new 0 96 278
assign 1 96 279
equals 1 96 279
assign 1 0 281
assign 1 96 284
new 0 96 284
assign 1 96 285
ends 1 96 285
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 0 297
assign 1 0 301
assign 1 97 304
new 0 97 304
return 1 97 305
assign 1 99 307
new 0 99 307
return 1 99 308
assign 1 103 314
new 0 103 314
assign 1 103 315
new 0 103 315
assign 1 103 316
swap 2 103 316
return 1 103 317
assign 1 107 324
new 0 107 324
assign 1 107 325
argsGet 0 107 325
assign 1 108 326
new 0 108 326
assign 1 108 327
main 1 108 327
exit 1 108 328
assign 1 112 340
assign 1 113 341
new 1 113 341
assign 1 114 342
new 0 114 342
assign 1 114 343
new 0 114 343
assign 1 114 344
get 2 114 344
assign 1 114 345
firstGet 0 114 345
assign 1 114 346
new 1 114 346
assign 1 115 347
new 0 115 347
assign 1 115 350
lesser 1 115 355
assign 1 116 356
go 0 116 356
incrementValue 0 115 357
return 1 118 363
assign 1 122 371
new 0 122 371
config 0 123 372
assign 1 124 373
new 0 124 373
assign 1 126 375
new 0 126 375
assign 1 127 376
doWhat 0 127 376
assign 1 128 377
new 0 128 377
assign 1 130 381
toString 0 130 381
assign 1 131 382
new 0 131 382
assign 1 132 383
new 0 132 383
assign 1 132 384
add 1 132 384
assign 1 133 385
new 0 133 385
assign 1 0 388
assign 1 0 392
assign 1 0 395
print 0 136 399
return 1 138 401
assign 1 142 407
nameGet 0 142 407
assign 1 142 408
new 0 142 408
assign 1 142 409
equals 1 142 409
return 1 144 412
assign 1 149 548
new 0 149 548
assign 1 151 549
new 0 151 549
assign 1 152 550
get 1 152 550
assign 1 152 551
def 1 152 556
assign 1 153 557
get 1 153 557
assign 1 153 558
iteratorGet 0 0 558
assign 1 153 561
hasNextGet 0 153 561
assign 1 153 563
nextGet 0 153 563
assign 1 154 564
has 1 154 564
assign 1 154 565
not 0 154 570
put 1 155 571
assign 1 156 572
new 1 156 572
addFile 1 156 573
assign 1 161 581
new 0 161 581
assign 1 161 582
nameGet 0 161 582
assign 1 161 583
new 0 161 583
assign 1 161 584
equals 1 161 584
preProcessorSet 1 162 586
assign 1 164 588
new 0 164 588
assign 1 164 589
get 1 164 589
assign 1 164 590
firstGet 0 164 590
assign 1 165 591
new 0 165 591
assign 1 165 592
has 1 165 592
assign 1 166 594
new 0 166 594
assign 1 166 595
get 1 166 595
assign 1 166 596
firstGet 0 166 596
assign 1 168 599
assign 1 170 601
new 0 170 601
assign 1 170 602
new 0 170 602
assign 1 170 603
get 2 170 603
assign 1 170 604
firstGet 0 170 604
assign 1 170 605
new 1 170 605
assign 1 170 606
pathGet 0 170 606
addStep 1 171 607
assign 1 172 608
new 0 172 608
addStep 1 172 609
assign 1 173 610
new 0 173 610
assign 1 173 611
new 0 173 611
assign 1 173 612
get 2 173 612
assign 1 173 613
firstGet 0 173 613
assign 1 173 614
new 1 173 614
assign 1 173 615
pathGet 0 173 615
assign 1 174 616
new 0 174 616
assign 1 174 617
new 0 174 617
assign 1 174 618
nameGet 0 174 618
assign 1 174 619
get 2 174 619
assign 1 174 620
firstGet 0 174 620
assign 1 174 621
new 1 174 621
assign 1 175 622
new 0 175 622
assign 1 175 623
nameGet 0 175 623
assign 1 175 624
get 2 175 624
assign 1 175 625
firstGet 0 175 625
assign 1 175 626
new 1 175 626
assign 1 176 627
new 0 176 627
assign 1 176 628
new 0 176 628
assign 1 176 629
get 2 176 629
assign 1 176 630
firstGet 0 176 630
assign 1 176 631
new 1 176 631
assign 1 177 632
new 0 177 632
assign 1 177 633
new 0 177 633
assign 1 177 634
get 2 177 634
assign 1 177 635
firstGet 0 177 635
assign 1 177 636
new 1 177 636
assign 1 179 637
new 0 179 637
assign 1 179 638
get 1 179 638
assign 1 179 639
firstGet 0 179 639
assign 1 180 640
new 0 180 640
assign 1 180 641
get 1 180 641
assign 1 180 642
firstGet 0 180 642
assign 1 181 643
new 0 181 643
assign 1 181 644
get 1 181 644
assign 1 182 645
undef 1 182 650
assign 1 183 651
new 0 183 651
assign 1 185 653
new 0 185 653
assign 1 185 654
get 1 185 654
assign 1 186 655
undef 1 186 660
assign 1 187 661
new 0 187 661
assign 1 189 663
new 0 189 663
assign 1 189 664
get 1 189 664
assign 1 190 665
undef 1 190 670
assign 1 191 671
new 0 191 671
assign 1 193 673
new 0 193 673
assign 1 193 674
get 1 193 674
assign 1 194 675
undef 1 194 680
assign 1 195 681
new 0 195 681
assign 1 197 683
new 0 197 683
assign 1 197 684
get 1 197 684
assign 1 198 685
undef 1 198 690
assign 1 199 691
new 0 199 691
assign 1 201 693
new 0 201 693
assign 1 201 694
get 1 201 694
assign 1 202 695
undef 1 202 700
assign 1 203 701
new 0 203 701
assign 1 205 703
new 0 205 703
assign 1 205 704
get 1 205 704
assign 1 206 705
undef 1 206 710
assign 1 207 711
new 0 207 711
assign 1 209 713
new 0 209 713
assign 1 209 714
get 1 209 714
assign 1 210 715
undef 1 210 720
assign 1 211 721
new 0 211 721
assign 1 213 723
new 0 213 723
assign 1 213 724
get 1 213 724
assign 1 214 725
undef 1 214 730
assign 1 215 731
new 0 215 731
assign 1 217 733
new 0 217 733
assign 1 217 734
get 1 217 734
assign 1 218 735
def 1 218 740
assign 1 219 741
firstGet 0 219 741
assign 1 221 743
new 0 221 743
assign 1 221 744
get 1 221 744
assign 1 222 745
def 1 222 750
assign 1 223 751
firstGet 0 223 751
assign 1 225 754
new 0 225 754
assign 1 227 756
new 0 227 756
assign 1 227 757
new 0 227 757
assign 1 227 758
isTrue 2 227 758
assign 1 228 759
new 0 228 759
assign 1 228 760
new 0 228 760
assign 1 228 761
isTrue 2 228 761
assign 1 229 762
new 0 229 762
assign 1 229 763
isTrue 1 229 763
assign 1 230 764
new 0 230 764
assign 1 230 765
isTrue 1 230 765
assign 1 231 766
new 0 231 766
assign 1 232 767
new 0 232 767
assign 1 232 768
get 1 232 768
assign 1 233 769
def 1 233 774
assign 1 233 775
isEmptyGet 0 233 775
assign 1 233 776
not 0 233 781
assign 1 0 782
assign 1 0 785
assign 1 0 789
assign 1 234 792
linkedListIteratorGet 0 0 792
assign 1 234 795
hasNextGet 0 234 795
assign 1 234 797
nextGet 0 234 797
put 1 235 798
assign 1 238 805
new 0 238 805
assign 1 238 806
isTrue 1 238 806
assign 1 239 807
new 0 239 807
assign 1 239 808
isTrue 1 239 808
assign 1 240 809
new 0 240 809
assign 1 240 810
isTrue 1 240 810
assign 1 241 811
new 0 241 811
assign 1 241 812
new 0 241 812
assign 1 241 813
isTrue 2 241 813
assign 1 242 814
new 0 242 814
assign 1 242 815
get 1 242 815
assign 1 243 816
new 0 243 816
assign 1 243 817
get 1 243 817
assign 1 244 818
new 0 244 818
assign 1 244 819
new 0 244 819
assign 1 244 820
get 2 244 820
assign 1 244 821
firstGet 0 244 821
assign 1 245 822
new 0 245 822
assign 1 245 823
new 0 245 823
assign 1 245 824
get 2 245 824
assign 1 245 825
firstGet 0 245 825
assign 1 246 826
new 0 246 826
assign 1 246 827
add 1 246 827
assign 1 246 828
new 0 246 828
assign 1 246 829
get 2 246 829
assign 1 246 830
firstGet 0 246 830
assign 1 247 831
new 0 247 831
assign 1 248 832
new 0 248 832
assign 1 249 833
new 0 249 833
assign 1 250 834
new 0 250 834
assign 1 251 835
new 0 251 835
assign 1 254 836
def 1 254 841
assign 1 255 842
firstGet 0 255 842
assign 1 257 845
new 0 257 845
assign 1 264 847
new 0 264 847
assign 1 264 848
add 1 264 848
assign 1 264 849
nameGet 0 264 849
assign 1 264 850
add 1 264 850
assign 1 264 851
get 1 264 851
assign 1 265 852
def 1 265 857
assign 1 266 858
orderedGet 0 266 858
addAll 1 266 859
assign 1 269 861
new 0 269 861
assign 1 269 862
add 1 269 862
assign 1 269 863
get 1 269 863
assign 1 270 864
def 1 270 869
assign 1 271 870
orderedGet 0 271 870
addAll 1 271 871
assign 1 274 873
new 0 274 873
assign 1 275 874
orderedGet 0 275 874
assign 1 275 875
iteratorGet 0 0 875
assign 1 275 878
hasNextGet 0 275 878
assign 1 275 880
nextGet 0 275 880
assign 1 276 881
new 1 276 881
addValue 1 276 882
assign 1 278 888
newlineGet 0 278 888
assign 1 279 889
assign 1 280 890
new 1 280 890
assign 1 282 891
copy 0 282 891
assign 1 283 892
fileGet 0 283 892
assign 1 283 893
existsGet 0 283 893
assign 1 283 894
not 0 283 899
assign 1 284 900
fileGet 0 284 900
makeDirs 0 284 901
assign 1 286 903
def 1 286 908
assign 1 287 909
new 1 287 909
assign 1 287 910
readerGet 0 287 910
assign 1 288 911
open 0 288 911
assign 1 288 912
readString 0 288 912
close 0 289 913
assign 1 295 927
classNameGet 0 295 927
assign 1 296 928
add 1 296 928
assign 1 296 929
new 0 296 929
assign 1 296 930
add 1 296 930
assign 1 296 931
toString 0 296 931
assign 1 296 932
add 1 296 932
assign 1 297 933
add 1 297 933
assign 1 297 934
new 0 297 934
assign 1 297 935
add 1 297 935
assign 1 297 936
toString 0 297 936
assign 1 297 937
add 1 297 937
return 1 298 938
assign 1 302 978
new 0 302 978
assign 1 303 979
classesGet 0 303 979
assign 1 303 980
valueIteratorGet 0 303 980
assign 1 303 983
hasNextGet 0 303 983
assign 1 304 985
nextGet 0 304 985
assign 1 305 986
shouldEmitGet 0 305 986
assign 1 305 987
heldGet 0 305 987
assign 1 305 988
fromFileGet 0 305 988
assign 1 305 989
has 1 305 989
assign 1 306 991
heldGet 0 306 991
assign 1 306 992
namepathGet 0 306 992
assign 1 306 993
toString 0 306 993
put 1 306 994
assign 1 307 995
usedByGet 0 307 995
assign 1 307 996
heldGet 0 307 996
assign 1 307 997
namepathGet 0 307 997
assign 1 307 998
toString 0 307 998
assign 1 307 999
get 1 307 999
assign 1 308 1000
def 1 308 1005
assign 1 309 1006
setIteratorGet 0 0 1006
assign 1 309 1009
hasNextGet 0 309 1009
assign 1 309 1011
nextGet 0 309 1011
put 1 310 1012
assign 1 313 1019
subClassesGet 0 313 1019
assign 1 313 1020
heldGet 0 313 1020
assign 1 313 1021
namepathGet 0 313 1021
assign 1 313 1022
toString 0 313 1022
assign 1 313 1023
get 1 313 1023
assign 1 314 1024
def 1 314 1029
assign 1 315 1030
setIteratorGet 0 0 1030
assign 1 315 1033
hasNextGet 0 315 1033
assign 1 315 1035
nextGet 0 315 1035
put 1 316 1036
assign 1 321 1049
classesGet 0 321 1049
assign 1 321 1050
valueIteratorGet 0 321 1050
assign 1 321 1053
hasNextGet 0 321 1053
assign 1 322 1055
nextGet 0 322 1055
assign 1 323 1056
heldGet 0 323 1056
assign 1 323 1057
heldGet 0 323 1057
assign 1 323 1058
namepathGet 0 323 1058
assign 1 323 1059
toString 0 323 1059
assign 1 323 1060
has 1 323 1060
shouldWriteSet 1 323 1061
assign 1 330 1071
new 0 330 1071
return 1 330 1072
assign 1 334 1086
def 1 334 1091
return 1 335 1092
assign 1 340 1094
def 1 340 1099
assign 1 341 1100
firstGet 0 341 1100
assign 1 342 1101
new 0 342 1101
assign 1 342 1102
equals 1 342 1102
assign 1 343 1104
new 1 343 1104
assign 1 344 1107
new 0 344 1107
assign 1 344 1108
equals 1 344 1108
assign 1 345 1110
new 1 345 1110
assign 1 346 1113
new 0 346 1113
assign 1 346 1114
equals 1 346 1114
assign 1 347 1116
new 1 347 1116
assign 1 349 1119
new 0 349 1119
assign 1 349 1120
new 1 349 1120
throw 1 349 1121
dynConditionsAllSet 1 351 1125
return 1 352 1126
return 1 354 1128
assign 1 359 1240
new 0 359 1240
assign 1 359 1241
now 0 359 1241
assign 1 360 1242
new 0 360 1242
assign 1 361 1243
emitterGet 0 361 1243
assign 1 362 1244
def 1 362 1249
assign 1 363 1250
new 4 363 1250
put 1 364 1251
assign 1 366 1253
new 0 366 1253
assign 1 366 1254
add 1 366 1254
print 0 366 1255
assign 1 369 1258
new 0 369 1258
assign 1 371 1259
iteratorGet 0 0 1259
assign 1 371 1262
hasNextGet 0 371 1262
assign 1 371 1264
nextGet 0 371 1264
assign 1 372 1265
has 1 372 1265
assign 1 372 1266
not 0 372 1271
put 1 373 1272
assign 1 374 1273
new 2 374 1273
addValue 1 375 1274
assign 1 378 1281
iteratorGet 0 0 1281
assign 1 378 1284
hasNextGet 0 378 1284
assign 1 378 1286
nextGet 0 378 1286
assign 1 379 1287
has 1 379 1287
assign 1 379 1288
not 0 379 1293
put 1 380 1294
assign 1 381 1295
new 2 381 1295
addValue 1 382 1296
assign 1 383 1297
libNameGet 0 383 1297
put 1 383 1298
assign 1 388 1306
iteratorGet 0 388 1306
assign 1 388 1309
hasNextGet 0 388 1309
assign 1 389 1311
nextGet 0 389 1311
doParse 1 391 1312
buildSyns 1 393 1318
assign 1 396 1320
new 0 396 1320
assign 1 396 1321
now 0 396 1321
assign 1 396 1322
subtract 1 396 1322
assign 1 398 1323
new 0 398 1323
assign 1 398 1324
add 1 398 1324
print 0 398 1325
assign 1 400 1326
emitCommonGet 0 400 1326
assign 1 400 1327
def 1 400 1332
assign 1 402 1333
new 0 402 1333
assign 1 402 1334
now 0 402 1334
assign 1 403 1335
emitCommonGet 0 403 1335
doEmit 0 403 1336
assign 1 404 1337
new 0 404 1337
assign 1 404 1338
now 0 404 1338
assign 1 404 1339
subtract 1 404 1339
assign 1 405 1340
new 0 405 1340
assign 1 405 1341
add 1 405 1341
print 0 405 1342
assign 1 406 1343
new 0 406 1343
assign 1 406 1344
now 0 406 1344
assign 1 406 1345
subtract 1 406 1345
assign 1 407 1346
new 0 407 1346
assign 1 407 1347
add 1 407 1347
print 0 407 1348
assign 1 408 1349
new 0 408 1349
return 1 408 1350
setClassesToWrite 0 411 1353
libnameInfoGet 0 412 1354
assign 1 414 1355
classesGet 0 414 1355
assign 1 414 1356
valueIteratorGet 0 414 1356
assign 1 414 1359
hasNextGet 0 414 1359
assign 1 415 1361
nextGet 0 415 1361
doEmit 1 416 1362
emitMain 0 418 1368
emitCUInit 0 419 1369
assign 1 420 1370
classesGet 0 420 1370
assign 1 420 1371
valueIteratorGet 0 420 1371
assign 1 420 1374
hasNextGet 0 420 1374
assign 1 421 1376
nextGet 0 421 1376
emitSyn 1 422 1377
assign 1 426 1384
new 0 426 1384
assign 1 426 1385
now 0 426 1385
assign 1 426 1386
subtract 1 426 1386
assign 1 427 1387
def 1 427 1392
assign 1 428 1393
new 0 428 1393
assign 1 428 1394
add 1 428 1394
print 0 428 1395
assign 1 430 1397
new 0 430 1397
assign 1 430 1398
add 1 430 1398
print 0 430 1399
prepMake 1 433 1401
assign 1 437 1404
not 0 437 1409
make 1 438 1410
deployLibrary 1 439 1411
assign 1 441 1413
linkedListIteratorGet 0 0 1413
assign 1 441 1416
hasNextGet 0 441 1416
assign 1 441 1418
nextGet 0 441 1418
assign 1 442 1419
libnameInfoGet 0 442 1419
assign 1 442 1420
unitShlibGet 0 442 1420
assign 1 443 1421
emitPathGet 0 443 1421
assign 1 443 1422
copy 0 443 1422
assign 1 444 1423
stepsGet 0 444 1423
assign 1 444 1424
lastGet 0 444 1424
addStep 1 444 1425
assign 1 445 1426
fileGet 0 445 1426
assign 1 445 1427
existsGet 0 445 1427
assign 1 446 1429
fileGet 0 446 1429
delete 0 446 1430
assign 1 448 1432
fileGet 0 448 1432
assign 1 448 1433
existsGet 0 448 1433
assign 1 448 1434
not 0 448 1434
assign 1 449 1436
fileGet 0 449 1436
assign 1 449 1437
fileGet 0 449 1437
deployFile 2 449 1438
assign 1 453 1446
iteratorGet 0 453 1446
assign 1 454 1447
iteratorGet 0 454 1447
assign 1 456 1450
hasNextGet 0 456 1450
assign 1 456 1452
hasNextGet 0 456 1452
assign 1 0 1454
assign 1 0 1457
assign 1 0 1461
assign 1 457 1464
nextGet 0 457 1464
assign 1 457 1465
apNew 1 457 1465
assign 1 458 1466
emitPathGet 0 458 1466
assign 1 458 1467
copy 0 458 1467
assign 1 458 1468
toString 0 458 1468
assign 1 458 1469
new 0 458 1469
assign 1 458 1470
add 1 458 1470
assign 1 458 1471
nextGet 0 458 1471
assign 1 458 1472
add 1 458 1472
assign 1 458 1473
apNew 1 458 1473
assign 1 460 1474
fileGet 0 460 1474
assign 1 460 1475
existsGet 0 460 1475
assign 1 461 1477
fileGet 0 461 1477
delete 0 461 1478
assign 1 463 1480
fileGet 0 463 1480
assign 1 463 1481
existsGet 0 463 1481
assign 1 463 1482
not 0 463 1482
assign 1 464 1484
fileGet 0 464 1484
assign 1 464 1485
fileGet 0 464 1485
deployFile 2 464 1486
assign 1 469 1495
new 0 469 1495
assign 1 469 1496
now 0 469 1496
assign 1 469 1497
subtract 1 469 1497
assign 1 471 1498
def 1 471 1503
assign 1 472 1504
new 0 472 1504
assign 1 472 1505
add 1 472 1505
print 0 472 1506
assign 1 474 1508
def 1 474 1513
assign 1 475 1514
new 0 475 1514
assign 1 475 1515
add 1 475 1515
print 0 475 1516
assign 1 477 1518
def 1 477 1523
assign 1 478 1524
new 0 478 1524
assign 1 478 1525
add 1 478 1525
print 0 478 1526
assign 1 482 1529
new 0 482 1529
print 0 482 1530
assign 1 483 1531
run 2 483 1531
assign 1 484 1532
new 0 484 1532
assign 1 484 1533
add 1 484 1533
assign 1 484 1534
new 0 484 1534
assign 1 484 1535
add 1 484 1535
print 0 484 1536
return 1 485 1537
assign 1 487 1539
new 0 487 1539
return 1 487 1540
assign 1 491 1553
justParsedGet 0 491 1553
assign 1 491 1554
valueIteratorGet 0 491 1554
assign 1 491 1557
hasNextGet 0 491 1557
assign 1 492 1559
nextGet 0 492 1559
assign 1 493 1560
heldGet 0 493 1560
libNameSet 1 493 1561
assign 1 494 1562
getSyn 2 494 1562
libNameSet 1 495 1563
assign 1 497 1569
justParsedGet 0 497 1569
assign 1 497 1570
valueIteratorGet 0 497 1570
assign 1 497 1573
hasNextGet 0 497 1573
assign 1 498 1575
nextGet 0 498 1575
assign 1 499 1576
heldGet 0 499 1576
assign 1 499 1577
synGet 0 499 1577
checkInheritance 2 500 1578
integrate 1 501 1579
assign 1 503 1585
new 0 503 1585
justParsedSet 1 503 1586
assign 1 507 1614
heldGet 0 507 1614
assign 1 507 1615
synGet 0 507 1615
assign 1 507 1616
def 1 507 1621
assign 1 508 1622
heldGet 0 508 1622
assign 1 508 1623
synGet 0 508 1623
return 1 508 1624
assign 1 510 1626
heldGet 0 510 1626
libNameSet 1 510 1627
assign 1 511 1628
heldGet 0 511 1628
assign 1 511 1629
extendsGet 0 511 1629
assign 1 511 1630
undef 1 511 1635
assign 1 512 1636
new 1 512 1636
assign 1 514 1639
classesGet 0 514 1639
assign 1 514 1640
heldGet 0 514 1640
assign 1 514 1641
extendsGet 0 514 1641
assign 1 514 1642
toString 0 514 1642
assign 1 514 1643
get 1 514 1643
assign 1 516 1644
def 1 516 1649
assign 1 517 1650
heldGet 0 517 1650
libNameSet 1 517 1651
assign 1 518 1652
getSyn 2 518 1652
assign 1 521 1655
heldGet 0 521 1655
assign 1 521 1656
extendsGet 0 521 1656
assign 1 521 1657
loadSyn 1 521 1657
assign 1 523 1659
new 2 523 1659
assign 1 525 1661
heldGet 0 525 1661
synSet 1 525 1662
assign 1 526 1663
heldGet 0 526 1663
assign 1 526 1664
namepathGet 0 526 1664
assign 1 526 1665
toString 0 526 1665
addSynClass 2 526 1666
return 1 527 1667
assign 1 531 1675
toString 0 531 1675
assign 1 532 1676
synClassesGet 0 532 1676
assign 1 532 1677
get 1 532 1677
assign 1 533 1678
def 1 533 1683
return 1 534 1684
assign 1 540 1686
emitterGet 0 540 1686
assign 1 540 1687
loadSyn 1 540 1687
addSynClass 2 541 1688
return 1 542 1689
assign 1 549 1693
undef 1 549 1698
assign 1 550 1699
new 1 550 1699
return 1 552 1701
assign 1 557 1780
new 1 557 1780
assign 1 558 1781
new 0 558 1781
assign 1 559 1782
emitterGet 0 559 1782
assign 1 560 1783
assign 1 561 1784
new 0 561 1784
assign 1 562 1785
shouldEmitGet 0 562 1785
put 1 562 1786
assign 1 0 1789
assign 1 0 1793
assign 1 0 1796
assign 1 565 1800
new 0 565 1800
assign 1 565 1801
toString 0 565 1801
assign 1 565 1802
add 1 565 1802
print 0 565 1803
assign 1 567 1805
assign 1 569 1806
fileGet 0 569 1806
assign 1 569 1807
readerGet 0 569 1807
assign 1 569 1808
open 0 569 1808
assign 1 569 1809
readBuffer 1 569 1809
assign 1 570 1810
fileGet 0 570 1810
assign 1 570 1811
readerGet 0 570 1811
close 0 570 1812
assign 1 571 1813
tokenize 1 571 1813
assign 1 575 1815
new 0 575 1815
echo 0 575 1816
assign 1 577 1818
outermostGet 0 577 1818
nodify 2 577 1819
assign 1 579 1821
new 0 579 1821
print 0 579 1822
assign 1 580 1823
new 2 580 1823
traverse 1 580 1824
assign 1 584 1827
new 0 584 1827
echo 0 584 1828
assign 1 586 1830
new 0 586 1830
traverse 1 586 1831
assign 1 588 1833
new 0 588 1833
print 0 588 1834
assign 1 589 1835
new 2 589 1835
traverse 1 589 1836
assign 1 592 1839
new 0 592 1839
echo 0 592 1840
assign 1 595 1842
new 0 595 1842
traverse 1 595 1843
contain 0 596 1844
assign 1 598 1846
new 0 598 1846
print 0 598 1847
assign 1 599 1848
new 2 599 1848
traverse 1 599 1849
assign 1 603 1852
new 0 603 1852
echo 0 603 1853
assign 1 605 1855
new 0 605 1855
traverse 1 605 1856
assign 1 607 1858
new 0 607 1858
print 0 607 1859
assign 1 608 1860
new 2 608 1860
traverse 1 608 1861
assign 1 612 1864
new 0 612 1864
echo 0 612 1865
assign 1 614 1867
new 0 614 1867
traverse 1 614 1868
assign 1 616 1870
new 0 616 1870
print 0 616 1871
assign 1 617 1872
new 2 617 1872
traverse 1 617 1873
assign 1 621 1876
new 0 621 1876
echo 0 621 1877
assign 1 623 1879
new 0 623 1879
traverse 1 623 1880
assign 1 625 1882
new 0 625 1882
print 0 625 1883
assign 1 626 1884
new 2 626 1884
traverse 1 626 1885
assign 1 630 1888
new 0 630 1888
echo 0 630 1889
assign 1 632 1891
new 0 632 1891
traverse 1 632 1892
assign 1 634 1894
new 0 634 1894
print 0 634 1895
assign 1 635 1896
new 2 635 1896
traverse 1 635 1897
assign 1 639 1900
new 0 639 1900
echo 0 639 1901
assign 1 641 1903
new 0 641 1903
traverse 1 641 1904
assign 1 643 1906
new 0 643 1906
print 0 643 1907
assign 1 644 1908
new 2 644 1908
traverse 1 644 1909
assign 1 648 1912
new 0 648 1912
echo 0 648 1913
assign 1 650 1915
new 0 650 1915
traverse 1 650 1916
assign 1 652 1918
new 0 652 1918
print 0 652 1919
assign 1 653 1920
new 2 653 1920
traverse 1 653 1921
assign 1 657 1924
new 0 657 1924
echo 0 657 1925
assign 1 659 1927
new 0 659 1927
traverse 1 659 1928
assign 1 661 1930
new 0 661 1930
print 0 661 1931
assign 1 662 1932
new 2 662 1932
traverse 1 662 1933
assign 1 665 1936
new 0 665 1936
echo 0 665 1937
assign 1 667 1939
new 0 667 1939
traverse 1 667 1940
assign 1 669 1942
new 0 669 1942
print 0 669 1943
assign 1 670 1944
new 2 670 1944
traverse 1 670 1945
assign 1 674 1948
new 0 674 1948
echo 0 674 1949
assign 1 675 1950
new 0 675 1950
print 0 675 1951
assign 1 677 1953
new 0 677 1953
traverse 1 677 1954
assign 1 0 1956
assign 1 0 1960
assign 1 0 1963
assign 1 679 1967
new 0 679 1967
print 0 679 1968
assign 1 680 1969
new 2 680 1969
traverse 1 680 1970
assign 1 682 1972
classesGet 0 682 1972
assign 1 682 1973
valueIteratorGet 0 682 1973
assign 1 682 1976
hasNextGet 0 682 1976
assign 1 683 1978
nextGet 0 683 1978
assign 1 685 1979
transUnitGet 0 685 1979
assign 1 686 1980
new 1 686 1980
assign 1 687 1981
TRANSUNITGet 0 687 1981
typenameSet 1 687 1982
assign 1 688 1983
new 0 688 1983
assign 1 689 1984
heldGet 0 689 1984
assign 1 689 1985
emitsGet 0 689 1985
emitsSet 1 689 1986
heldSet 1 690 1987
delete 0 691 1988
addValue 1 692 1989
copyLoc 1 693 1990
reInitContained 0 699 2012
assign 1 700 2013
containedGet 0 700 2013
assign 1 701 2014
new 0 701 2014
assign 1 702 2015
new 0 702 2015
assign 1 702 2016
crGet 0 702 2016
assign 1 703 2017
linkedListIteratorGet 0 703 2017
assign 1 703 2020
hasNextGet 0 703 2020
assign 1 704 2022
new 1 704 2022
assign 1 705 2023
nextGet 0 705 2023
heldSet 1 705 2024
nlcSet 1 706 2025
assign 1 707 2026
heldGet 0 707 2026
assign 1 707 2027
equals 1 707 2027
assign 1 708 2029
increment 0 708 2029
assign 1 710 2031
heldGet 0 710 2031
assign 1 710 2032
notEquals 1 710 2032
addValue 1 711 2034
containerSet 1 712 2035
return 1 0 2045
assign 1 0 2048
return 1 0 2052
assign 1 0 2055
return 1 0 2059
assign 1 0 2062
return 1 0 2066
assign 1 0 2069
return 1 0 2073
assign 1 0 2076
return 1 0 2080
assign 1 0 2083
return 1 0 2087
assign 1 0 2090
return 1 0 2094
assign 1 0 2097
return 1 0 2101
assign 1 0 2104
return 1 0 2108
assign 1 0 2111
return 1 0 2115
assign 1 0 2118
return 1 0 2122
assign 1 0 2125
return 1 0 2129
assign 1 0 2132
return 1 0 2136
assign 1 0 2139
return 1 0 2143
assign 1 0 2146
return 1 0 2150
assign 1 0 2153
return 1 0 2157
assign 1 0 2160
return 1 0 2164
assign 1 0 2167
return 1 0 2171
assign 1 0 2174
return 1 0 2178
assign 1 0 2181
return 1 0 2185
assign 1 0 2188
return 1 0 2192
assign 1 0 2195
return 1 0 2199
assign 1 0 2202
return 1 0 2206
assign 1 0 2209
return 1 0 2213
assign 1 0 2216
return 1 0 2220
assign 1 0 2223
return 1 0 2227
assign 1 0 2230
return 1 0 2234
assign 1 0 2237
return 1 0 2241
assign 1 0 2244
return 1 0 2248
assign 1 0 2251
return 1 0 2255
assign 1 0 2258
return 1 0 2262
assign 1 0 2265
return 1 0 2269
assign 1 0 2272
return 1 0 2276
assign 1 0 2279
return 1 0 2283
assign 1 0 2286
return 1 0 2290
assign 1 0 2293
return 1 0 2297
assign 1 0 2300
return 1 0 2304
assign 1 0 2307
return 1 0 2311
assign 1 0 2314
return 1 0 2318
assign 1 0 2321
return 1 0 2325
assign 1 0 2328
return 1 0 2332
assign 1 0 2335
return 1 0 2339
assign 1 0 2342
return 1 0 2346
assign 1 0 2349
return 1 0 2353
assign 1 0 2356
return 1 0 2360
assign 1 0 2363
return 1 0 2367
assign 1 0 2370
return 1 0 2374
assign 1 0 2377
return 1 0 2381
assign 1 0 2384
return 1 0 2388
assign 1 0 2391
return 1 0 2395
assign 1 0 2398
return 1 0 2402
assign 1 0 2405
return 1 0 2409
assign 1 0 2412
return 1 0 2416
assign 1 0 2419
return 1 0 2423
assign 1 0 2426
return 1 0 2430
assign 1 0 2433
return 1 0 2437
assign 1 0 2440
return 1 0 2444
assign 1 0 2447
return 1 0 2451
assign 1 0 2454
return 1 0 2458
assign 1 0 2461
return 1 0 2465
assign 1 0 2468
return 1 0 2472
assign 1 0 2475
return 1 0 2479
assign 1 0 2482
return 1 0 2486
assign 1 0 2489
return 1 0 2493
assign 1 0 2496
return 1 0 2500
assign 1 0 2503
return 1 0 2507
assign 1 0 2510
return 1 0 2514
assign 1 0 2517
assign 1 0 2521
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1308786538: return bem_echo_0();
case -404051026: return bem_printPlacesGet_0();
case -729571811: return bem_serializeToString_0();
case -2113443821: return bem_deployLibraryGet_0();
case -34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case -340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case -580139405: return bem_config_0();
case -2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case -1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case -1803479881: return bem_libNameGet_0();
case -314718434: return bem_print_0();
case -2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case -186098742: return bem_exeNameGet_0();
case -1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case -829911139: return bem_compilerProfileGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case -658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case -2082855574: return bem_emitDataGet_0();
case -786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case -2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case -271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case -2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case -1919619119: return bem_setClassesToWrite_0();
case -2127864150: return bem_argsGet_0();
case -400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case -1003238764: return bem_parseGet_0();
case -902949587: return bem_printStepsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case -1505775346: return bem_putLineNumbersInTraceGet_0();
case -1713520961: return bem_linkLibArgsGet_0();
case -1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case -644675716: return bem_ntypesGet_0();
case -1185503219: return bem_deployFilesFromGet_0();
case -1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case -1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case -560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case -733055122: return bem_makeNameGet_0();
case -328200718: return bem_printAstGet_0();
case -126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case -1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case -1458327669: return bem_emitFileHeaderGet_0();
case -1220511308: return bem_buildSucceededGet_0();
case -845792839: return bem_iteratorGet_0();
case -1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -505952126: return bem_copyTo_1(bevd_0);
case -392968773: return bem_printPlacesSet_1(bevd_0);
case -2071773321: return bem_emitDataSet_1(bevd_0);
case -1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case -1702438708: return bem_linkLibArgsSet_1(bevd_0);
case -891867334: return bem_printStepsSet_1(bevd_0);
case -647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -721972869: return bem_makeNameSet_1(bevd_0);
case -175016489: return bem_exeNameSet_1(bevd_0);
case -972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case -2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case -115429536: return bem_outputPlatformSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case -818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case -1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case -706249818: return bem_getSynNp_1(bevd_0);
case -1310359934: return bem_emitLangsSet_1(bevd_0);
case -329197947: return bem_startTimeSet_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case -1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case -1174420966: return bem_deployFilesFromSet_1(bevd_0);
case -389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case -2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case -1138539097: return bem_codeSet_1(bevd_0);
case -23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -2036609109: return bem_buildSyns_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case -992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case -1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case -260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case -1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case -2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
}
