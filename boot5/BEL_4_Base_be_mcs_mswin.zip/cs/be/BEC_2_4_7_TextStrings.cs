namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_7_TextStrings : BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
static BEC_2_4_7_TextStrings() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static byte[] bels_1 = {0x0D,0x0A};
private static byte[] bels_2 = {0x0A};
private static byte[] bels_3 = {0x0A};
private static byte[] bels_4 = {0x3A};
private static byte[] bels_5 = {};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_6 = {};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 0));
public static new BEC_2_4_7_TextStrings bevs_inst;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevp_space = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevp_empty = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevp_quote = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_tab = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_tmpany_phold);
bevp_dosNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_1));
bevp_unixNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_2));
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_cr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_tmpany_phold);
bevp_lf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevp_colon = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = beva_splits.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
bevt_1_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 1113 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_tmpany_phold;
} /* Line: 1114 */
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_tmpany_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_3_tmpany_phold);
while (true)
 /* Line: 1118 */ {
bevt_4_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 1118 */ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_tmpany_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_buf.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 1120 */
 else  /* Line: 1118 */ {
break;
} /* Line: 1118 */
} /* Line: 1118 */
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_beg = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
 /* Line: 1130 */ {
bevt_0_tmpany_phold = bevl_mb.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1130 */ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_tmpany_phold = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1132 */ {
if (bevl_foundChar.bevi_bool) /* Line: 1133 */ {
bevl_end.bevi_int++;
} /* Line: 1134 */
 else  /* Line: 1135 */ {
bevl_beg.bevi_int++;
} /* Line: 1136 */
} /* Line: 1133 */
 else  /* Line: 1138 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1140 */
} /* Line: 1132 */
 else  /* Line: 1130 */ {
break;
} /* Line: 1130 */
} /* Line: 1130 */
if (bevl_foundChar.bevi_bool) /* Line: 1143 */ {
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_tmpany_phold);
} /* Line: 1144 */
 else  /* Line: 1145 */ {
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_5));
} /* Line: 1146 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
if (beva_a == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1152 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1152 */ {
if (beva_b == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1152 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1152 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1152 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1152 */ {
return null;
} /* Line: 1152 */
bevt_3_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bevs_inst;
bevt_4_tmpany_phold = beva_a.bem_sizeGet_0();
bevt_5_tmpany_phold = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_min_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 1158 */ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1158 */ {
bevl_ai.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_av);
bevl_bi.bemd_1(-1048795675, BEL_4_Base.bevn_next_1, bevl_bv);
bevt_7_tmpany_phold = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1161 */ {
bevt_9_tmpany_phold = bevo_0;
bevt_8_tmpany_phold = beva_a.bem_substring_2(bevt_9_tmpany_phold, bevl_i);
return bevt_8_tmpany_phold;
} /* Line: 1162 */
bevl_i.bevi_int++;
} /* Line: 1158 */
 else  /* Line: 1158 */ {
break;
} /* Line: 1158 */
} /* Line: 1158 */
bevt_11_tmpany_phold = bevo_1;
bevt_10_tmpany_phold = beva_a.bem_substring_2(bevt_11_tmpany_phold, bevl_i);
return bevt_10_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevt_0_tmpany_loop = beva_strs.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1169 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 1169 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpany_phold = this.bem_isEmpty_1(bevl_i);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1170 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 1171 */
} /* Line: 1170 */
 else  /* Line: 1169 */ {
break;
} /* Line: 1169 */
} /* Line: 1169 */
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1178 */ {
bevt_3_tmpany_phold = beva_value.bem_sizeGet_0();
bevt_4_tmpany_phold = bevo_2;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1178 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1178 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1178 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 1179 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_value == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1185 */ {
bevt_3_tmpany_phold = bevo_3;
bevt_2_tmpany_phold = beva_value.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1185 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1185 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1185 */
 else  /* Line: 1185 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1185 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 1186 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1087, 1088, 1089, 1089, 1090, 1090, 1091, 1092, 1094, 1094, 1095, 1096, 1097, 1098, 1101, 1102, 1103, 1104, 1108, 1108, 1112, 1113, 1113, 1114, 1114, 1116, 1117, 1117, 1118, 1119, 1120, 1120, 1122, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1134, 1136, 1139, 1139, 1140, 1144, 1144, 1144, 1146, 1148, 1152, 1152, 0, 1152, 1152, 0, 0, 1152, 1153, 1153, 1153, 1153, 1154, 1155, 1156, 1157, 1158, 1158, 1158, 1159, 1160, 1161, 1162, 1162, 1162, 1158, 1165, 1165, 1165, 1169, 0, 1169, 1169, 1170, 1171, 1171, 1174, 1174, 1178, 1178, 0, 1178, 1178, 1178, 1178, 0, 0, 1179, 1179, 1181, 1181, 1185, 1185, 1185, 1185, 0, 0, 0, 1186, 1186, 1188, 1188, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 64, 65, 76, 77, 78, 80, 81, 83, 84, 85, 88, 90, 91, 92, 98, 112, 113, 114, 115, 118, 120, 121, 124, 127, 131, 132, 133, 141, 142, 143, 146, 148, 169, 174, 175, 178, 183, 184, 187, 191, 193, 194, 195, 196, 197, 198, 199, 200, 201, 204, 209, 210, 211, 212, 214, 215, 216, 218, 224, 225, 226, 235, 235, 238, 240, 241, 243, 244, 251, 252, 262, 267, 268, 271, 272, 273, 278, 279, 282, 286, 287, 289, 290, 299, 304, 305, 306, 308, 311, 315, 318, 319, 321, 322, 325, 328, 332, 335, 339, 342, 346, 349, 353, 356, 360, 363, 367, 370, 374, 377, 381, 384, 388, 391, 395, 398, 402, 405};
/* BEGIN LINEINFO 
assign 1 1087 42
new 0 1087 42
assign 1 1088 43
new 0 1088 43
assign 1 1089 44
new 0 1089 44
assign 1 1089 45
codeNew 1 1089 45
assign 1 1090 46
new 0 1090 46
assign 1 1090 47
codeNew 1 1090 47
assign 1 1091 48
new 0 1091 48
assign 1 1092 49
new 0 1092 49
assign 1 1094 50
new 0 1094 50
assign 1 1094 51
codeNew 1 1094 51
assign 1 1095 52
new 0 1095 52
assign 1 1096 53
new 0 1096 53
assign 1 1097 54
new 1 1097 54
assign 1 1098 55
new 0 1098 55
put 1 1101 56
put 1 1102 57
put 1 1103 58
put 1 1104 59
assign 1 1108 64
joinBuffer 2 1108 64
return 1 1108 65
assign 1 1112 76
iteratorGet 0 1112 76
assign 1 1113 77
hasNextGet 0 1113 77
assign 1 1113 78
not 0 1113 78
assign 1 1114 80
new 0 1114 80
return 1 1114 81
assign 1 1116 83
new 0 1116 83
assign 1 1117 84
nextGet 0 1117 84
addValue 1 1117 85
assign 1 1118 88
hasNextGet 0 1118 88
addValue 1 1119 90
assign 1 1120 91
nextGet 0 1120 91
addValue 1 1120 92
return 1 1122 98
assign 1 1126 112
new 0 1126 112
assign 1 1127 113
new 0 1127 113
assign 1 1128 114
new 0 1128 114
assign 1 1129 115
mbiterGet 0 1129 115
assign 1 1130 118
hasNextGet 0 1130 118
assign 1 1131 120
nextGet 0 1131 120
assign 1 1132 121
has 1 1132 121
incrementValue 0 1134 124
incrementValue 0 1136 127
assign 1 1139 131
new 0 1139 131
setValue 1 1139 132
assign 1 1140 133
new 0 1140 133
assign 1 1144 141
sizeGet 0 1144 141
assign 1 1144 142
subtract 1 1144 142
assign 1 1144 143
substring 2 1144 143
assign 1 1146 146
new 0 1146 146
return 1 1148 148
assign 1 1152 169
undef 1 1152 174
assign 1 0 175
assign 1 1152 178
undef 1 1152 183
assign 1 0 184
assign 1 0 187
return 1 1152 191
assign 1 1153 193
new 0 1153 193
assign 1 1153 194
sizeGet 0 1153 194
assign 1 1153 195
sizeGet 0 1153 195
assign 1 1153 196
min 2 1153 196
assign 1 1154 197
biterGet 0 1154 197
assign 1 1155 198
biterGet 0 1155 198
assign 1 1156 199
new 0 1156 199
assign 1 1157 200
new 0 1157 200
assign 1 1158 201
new 0 1158 201
assign 1 1158 204
lesser 1 1158 209
next 1 1159 210
next 1 1160 211
assign 1 1161 212
notEquals 1 1161 212
assign 1 1162 214
new 0 1162 214
assign 1 1162 215
substring 2 1162 215
return 1 1162 216
incrementValue 0 1158 218
assign 1 1165 224
new 0 1165 224
assign 1 1165 225
substring 2 1165 225
return 1 1165 226
assign 1 1169 235
iteratorGet 0 0 235
assign 1 1169 238
hasNextGet 0 1169 238
assign 1 1169 240
nextGet 0 1169 240
assign 1 1170 241
isEmpty 1 1170 241
assign 1 1171 243
new 0 1171 243
return 1 1171 244
assign 1 1174 251
new 0 1174 251
return 1 1174 252
assign 1 1178 262
undef 1 1178 267
assign 1 0 268
assign 1 1178 271
sizeGet 0 1178 271
assign 1 1178 272
new 0 1178 272
assign 1 1178 273
lesser 1 1178 278
assign 1 0 279
assign 1 0 282
assign 1 1179 286
new 0 1179 286
return 1 1179 287
assign 1 1181 289
new 0 1181 289
return 1 1181 290
assign 1 1185 299
def 1 1185 304
assign 1 1185 305
new 0 1185 305
assign 1 1185 306
notEquals 1 1185 306
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 1186 318
new 0 1186 318
return 1 1186 319
assign 1 1188 321
new 0 1188 321
return 1 1188 322
return 1 0 325
assign 1 0 328
return 1 0 332
assign 1 0 335
return 1 0 339
assign 1 0 342
return 1 0 346
assign 1 0 349
return 1 0 353
assign 1 0 356
return 1 0 360
assign 1 0 363
return 1 0 367
assign 1 0 370
return 1 0 374
assign 1 0 377
return 1 0 381
assign 1 0 384
return 1 0 388
assign 1 0 391
return 1 0 395
assign 1 0 398
return 1 0 402
assign 1 0 405
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 482013217: return bem_spaceGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -1081741254: return bem_emptyGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 1259904107: return bem_quoteGet_0();
case -1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1708371387: return bem_dosNewlineGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1599801355: return bem_wsGet_0();
case 55016493: return bem_lfGet_0();
case -929570062: return bem_tabGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 776765523: return bem_newlineGet_0();
case 1000967768: return bem_crGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1152565608: return bem_colonGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -527120532: return bem_lineSplitterGet_0();
case -1354714650: return bem_copy_0();
case 1567400443: return bem_unixNewlineGet_0();
case -1182494494: return bem_toAny_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1270986360: return bem_quoteSet_1(bevd_0);
case 1719453640: return bem_dosNewlineSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -516038279: return bem_lineSplitterSet_1(bevd_0);
case 1629015603: return bem_anyEmpty_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1012050021: return bem_crSet_1(bevd_0);
case 66098746: return bem_lfSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1437735788: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 493095470: return bem_spaceSet_1(bevd_0);
case -918487809: return bem_tabSet_1(bevd_0);
case 1578482696: return bem_unixNewlineSet_1(bevd_0);
case 1610883608: return bem_wsSet_1(bevd_0);
case 2091366709: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1070659001: return bem_emptySet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1163647861: return bem_colonSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1881757494: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -941304624: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1331758909: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TextStrings.bevs_inst = (BEC_2_4_7_TextStrings)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TextStrings.bevs_inst;
}
}
}
