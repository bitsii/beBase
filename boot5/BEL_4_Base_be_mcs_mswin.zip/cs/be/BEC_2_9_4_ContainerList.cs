namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_2_9_4_ContainerList : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }
static BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
public static new BEC_2_9_4_ContainerList bevs_inst;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpany_phold, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_leni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 142 */ {
if (beva_capi == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 142 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 142 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 142 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bels_0));
bevt_3_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 143 */
if (bevp_length == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 145 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 148 */ {
return this;
} /* Line: 149 */
} /* Line: 148 */

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_2_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_2_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 177 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_length.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_4;
bevt_0_tmpany_phold = this.bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_5;
bevt_1_tmpany_phold = bevp_length.bem_subtract_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = this.bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bels_1));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 210 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 212 */ {
bevt_6_tmpany_phold = bevo_7;
bevt_5_tmpany_phold = beva_posi.bem_add_1(bevt_6_tmpany_phold);
this.bem_lengthSet_1(bevt_5_tmpany_phold);
} /* Line: 213 */

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 224 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
 else  /* Line: 224 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 224 */ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 225 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_1_tmpany_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bevo_10;
bevl_j = beva_pos.bem_add_1(bevt_2_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) beva_pos.bem_copy_0();
while (true)
 /* Line: 238 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_4_tmpany_phold = this.bem_get_1(bevl_j);
this.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 238 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
this.bem_put_2(bevl_fl, null);
bevt_6_tmpany_phold = bevo_11;
bevt_5_tmpany_phold = bevp_length.bem_subtract_1(bevt_6_tmpany_phold);
this.bem_lengthSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 244 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 258 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 258 */ {
this.bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 258 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_n = (BEC_2_9_4_ContainerList) this.bem_create_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 265 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_1_tmpany_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 265 */
 else  /* Line: 265 */ {
break;
} /* Line: 265 */
} /* Line: 265 */
return (BEC_2_6_6_SystemObject) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_tmpany_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpany_phold = bevp_length.bem_add_1(bevt_4_tmpany_phold);
bevl_yi = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevl_c = bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 278 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
bevt_1_tmpany_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 280 */ {
bevt_6_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 280 */ {
bevl_c = bevt_1_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 281 */
 else  /* Line: 280 */ {
break;
} /* Line: 280 */
} /* Line: 280 */
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) this.bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpany_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
while (true)
 /* Line: 295 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
bevl_j = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
while (true)
 /* Line: 297 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_3_tmpany_phold = this.bem_get_1(bevl_j);
bevt_4_tmpany_phold = this.bem_get_1(bevl_c);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 298 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_j.bem_copy_0();
} /* Line: 299 */
bevl_j.bevi_int++;
} /* Line: 297 */
 else  /* Line: 297 */ {
break;
} /* Line: 297 */
} /* Line: 297 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpany_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpany_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 295 */
 else  /* Line: 295 */ {
break;
} /* Line: 295 */
} /* Line: 295 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_si = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 314 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 314 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 315 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 315 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 315 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 315 */
 else  /* Line: 315 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 315 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpany_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpany_phold).bevi_bool) /* Line: 318 */ {
bevl_si.bevi_int++;
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 320 */
 else  /* Line: 321 */ {
bevl_fi.bevi_int++;
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 323 */
} /* Line: 318 */
 else  /* Line: 315 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 328 */
 else  /* Line: 315 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 332 */
} /* Line: 315 */
} /* Line: 315 */
bevl_i.bevi_int++;
} /* Line: 334 */
 else  /* Line: 314 */ {
break;
} /* Line: 314 */
} /* Line: 314 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) this.bem_mergeSort_2(bevt_1_tmpany_phold, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpany_phold = bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_2_tmpany_phold = this.bem_create_1(bevt_3_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevt_2_tmpany_phold;
} /* Line: 345 */
 else  /* Line: 344 */ {
bevt_5_tmpany_phold = bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) this.bem_create_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_tmpany_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 349 */
 else  /* Line: 350 */ {
bevt_9_tmpany_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpany_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_2_9_4_ContainerList) this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_2_9_4_ContainerList) this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 358 */
} /* Line: 344 */
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 363 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_2));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 364 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 387 */
while (true)
 /* Line: 390 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 390 */ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 396 */
 else  /* Line: 390 */ {
break;
} /* Line: 390 */
} /* Line: 390 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 402 */ {
while (true)
 /* Line: 403 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 403 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 404 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
} /* Line: 403 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 411 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 416 */ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 422 */
 else  /* Line: 423 */ {
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevp_length.bem_copy_0();
this.bem_put_2(bevt_1_tmpany_phold, beva_val);
} /* Line: 425 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 430 */ {
bevt_2_tmpany_phold = beva_val.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 430 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 430 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 430 */
 else  /* Line: 430 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 430 */ {
this.bem_addAll_1(beva_val);
} /* Line: 431 */
 else  /* Line: 432 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 433 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_3_tmpany_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 441 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 441 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 441 */
 else  /* Line: 441 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 441 */ {
return bevl_i;
} /* Line: 442 */
bevl_i.bevi_int++;
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 449 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 450 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 469 */ {
bevt_3_tmpany_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpany_phold = bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_divide_1(bevt_4_tmpany_phold);
bevl_mid = bevt_2_tmpany_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpany_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 472 */ {
return bevl_mid;
} /* Line: 473 */
 else  /* Line: 472 */ {
bevt_6_tmpany_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 474 */ {
bevl_low = bevl_mid;
} /* Line: 476 */
 else  /* Line: 472 */ {
bevt_7_tmpany_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 477 */ {
bevl_high = bevl_mid;
} /* Line: 479 */
} /* Line: 472 */
} /* Line: 472 */
if (bevl_lastMid == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 482 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 482 */
 else  /* Line: 482 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 482 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 483 */ {
bevt_11_tmpany_phold = this.bem_get_1(bevl_low);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 483 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 483 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 483 */
 else  /* Line: 483 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 483 */ {
return bevl_low;
} /* Line: 484 */
return null;
} /* Line: 486 */
bevl_lastMid = bevl_mid;
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 489 */ {
return null;
} /* Line: 490 */
} /* Line: 489 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {134, 134, 134, 134, 134, 138, 142, 142, 0, 142, 142, 0, 0, 143, 143, 143, 145, 145, 148, 148, 149, 165, 166, 167, 172, 176, 176, 176, 177, 177, 179, 179, 189, 189, 193, 193, 197, 197, 201, 201, 201, 205, 205, 205, 205, 209, 209, 209, 210, 210, 210, 212, 212, 213, 213, 213, 224, 224, 224, 224, 224, 0, 0, 0, 231, 235, 235, 236, 236, 237, 237, 238, 238, 238, 239, 239, 240, 238, 242, 243, 243, 243, 244, 244, 246, 246, 250, 250, 254, 254, 258, 258, 258, 259, 258, 264, 265, 265, 265, 266, 266, 265, 268, 271, 271, 273, 273, 276, 276, 276, 276, 277, 0, 277, 277, 278, 280, 0, 280, 280, 281, 283, 287, 287, 291, 291, 295, 295, 295, 296, 297, 297, 297, 298, 298, 298, 299, 297, 302, 303, 303, 304, 295, 309, 310, 311, 312, 313, 314, 314, 315, 315, 315, 315, 0, 0, 0, 316, 317, 318, 319, 320, 322, 323, 325, 325, 326, 327, 328, 329, 329, 330, 331, 332, 334, 339, 339, 339, 343, 344, 344, 344, 345, 345, 345, 346, 346, 346, 347, 347, 348, 348, 348, 349, 351, 351, 352, 353, 354, 355, 356, 357, 358, 363, 364, 364, 364, 370, 370, 371, 387, 390, 390, 396, 398, 402, 402, 403, 404, 404, 410, 410, 411, 411, 416, 416, 422, 425, 425, 430, 430, 430, 0, 0, 0, 431, 433, 439, 439, 439, 440, 441, 441, 441, 0, 0, 0, 442, 439, 445, 449, 449, 449, 450, 450, 452, 452, 458, 458, 458, 465, 466, 470, 470, 470, 470, 471, 472, 473, 474, 476, 477, 479, 482, 482, 482, 482, 0, 0, 0, 483, 483, 0, 0, 0, 484, 486, 488, 489, 490, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {51, 52, 53, 54, 55, 59, 70, 75, 76, 79, 84, 85, 88, 92, 93, 94, 96, 101, 102, 107, 108, 113, 114, 115, 119, 126, 127, 132, 133, 134, 136, 137, 147, 148, 152, 153, 158, 159, 164, 165, 166, 172, 173, 174, 175, 185, 186, 191, 192, 193, 194, 196, 201, 202, 203, 204, 216, 217, 222, 223, 228, 229, 232, 236, 242, 257, 262, 263, 264, 265, 266, 267, 270, 275, 276, 277, 278, 279, 285, 286, 287, 288, 289, 290, 292, 293, 297, 298, 302, 303, 308, 311, 316, 317, 318, 331, 332, 335, 340, 341, 342, 343, 349, 353, 354, 358, 359, 371, 372, 373, 374, 375, 375, 378, 380, 381, 387, 387, 390, 392, 393, 399, 403, 404, 408, 409, 423, 426, 431, 432, 433, 436, 441, 442, 443, 444, 446, 448, 454, 455, 456, 457, 458, 481, 482, 483, 484, 485, 488, 493, 494, 499, 500, 505, 506, 509, 513, 516, 517, 518, 520, 521, 524, 525, 529, 534, 535, 536, 537, 540, 545, 546, 547, 548, 552, 563, 564, 565, 585, 586, 587, 592, 593, 594, 595, 598, 599, 604, 605, 606, 607, 608, 609, 610, 613, 614, 615, 616, 617, 618, 619, 620, 621, 629, 631, 632, 633, 641, 646, 647, 650, 654, 659, 662, 668, 675, 680, 683, 685, 686, 698, 703, 704, 705, 712, 717, 720, 723, 724, 732, 737, 738, 740, 743, 747, 750, 753, 764, 767, 772, 773, 774, 779, 780, 782, 785, 789, 792, 794, 800, 807, 808, 813, 814, 815, 817, 818, 823, 824, 825, 846, 847, 850, 851, 852, 853, 854, 855, 857, 860, 862, 865, 867, 871, 876, 877, 882, 883, 886, 890, 894, 895, 897, 900, 904, 907, 909, 911, 912, 914, 919, 922, 925, 928};
/* BEGIN LINEINFO 
assign 1 134 51
new 0 134 51
assign 1 134 52
once 0 134 52
assign 1 134 53
new 0 134 53
assign 1 134 54
once 0 134 54
new 2 134 55
new 2 138 59
assign 1 142 70
undef 1 142 75
assign 1 0 76
assign 1 142 79
undef 1 142 84
assign 1 0 85
assign 1 0 88
assign 1 143 92
new 0 143 92
assign 1 143 93
new 1 143 93
throw 1 143 94
assign 1 145 96
def 1 145 101
assign 1 148 102
equals 1 148 107
return 1 149 108
assign 1 165 113
copy 0 165 113
assign 1 166 114
copy 0 166 114
assign 1 167 115
new 0 167 115
return 1 172 119
assign 1 176 126
new 0 176 126
assign 1 176 127
equals 1 176 132
assign 1 177 133
new 0 177 133
return 1 177 134
assign 1 179 136
new 0 179 136
return 1 179 137
assign 1 189 147
toString 0 189 147
return 1 189 148
assign 1 193 152
new 1 193 152
new 1 193 153
assign 1 197 158
iteratorGet 0 197 158
return 1 197 159
assign 1 201 164
new 0 201 164
assign 1 201 165
get 1 201 165
return 1 201 166
assign 1 205 172
new 0 205 172
assign 1 205 173
subtract 1 205 173
assign 1 205 174
get 1 205 174
return 1 205 175
assign 1 209 185
new 0 209 185
assign 1 209 186
lesser 1 209 191
assign 1 210 192
new 0 210 192
assign 1 210 193
new 1 210 193
throw 1 210 194
assign 1 212 196
greaterEquals 1 212 201
assign 1 213 202
new 0 213 202
assign 1 213 203
add 1 213 203
lengthSet 1 213 204
assign 1 224 216
new 0 224 216
assign 1 224 217
greaterEquals 1 224 222
assign 1 224 223
lesser 1 224 228
assign 1 0 229
assign 1 0 232
assign 1 0 236
return 1 231 242
assign 1 235 257
lesser 1 235 262
assign 1 236 263
new 0 236 263
assign 1 236 264
subtract 1 236 264
assign 1 237 265
new 0 237 265
assign 1 237 266
add 1 237 266
assign 1 238 267
copy 0 238 267
assign 1 238 270
lesser 1 238 275
assign 1 239 276
get 1 239 276
put 2 239 277
incrementValue 0 240 278
incrementValue 0 238 279
put 2 242 285
assign 1 243 286
new 0 243 286
assign 1 243 287
subtract 1 243 287
lengthSet 1 243 288
assign 1 244 289
new 0 244 289
return 1 244 290
assign 1 246 292
new 0 246 292
return 1 246 293
assign 1 250 297
new 1 250 297
return 1 250 298
assign 1 254 302
new 1 254 302
return 1 254 303
assign 1 258 308
new 0 258 308
assign 1 258 311
lesser 1 258 316
put 2 259 317
incrementValue 0 258 318
assign 1 264 331
create 0 264 331
assign 1 265 332
new 0 265 332
assign 1 265 335
lesser 1 265 340
assign 1 266 341
get 1 266 341
put 2 266 342
incrementValue 0 265 343
return 1 268 349
assign 1 271 353
new 1 271 353
return 1 271 354
assign 1 273 358
new 1 273 358
return 1 273 359
assign 1 276 371
new 0 276 371
assign 1 276 372
lengthGet 0 276 372
assign 1 276 373
add 1 276 373
assign 1 276 374
new 2 276 374
assign 1 277 375
iteratorGet 0 0 375
assign 1 277 378
hasNextGet 0 277 378
assign 1 277 380
nextGet 0 277 380
addValueWhole 1 278 381
assign 1 280 387
iteratorGet 0 0 387
assign 1 280 390
hasNextGet 0 280 390
assign 1 280 392
nextGet 0 280 392
addValueWhole 1 281 393
return 1 283 399
assign 1 287 403
mergeSort 0 287 403
return 1 287 404
assign 1 291 408
new 0 291 408
sortValue 2 291 409
assign 1 295 423
copy 0 295 423
assign 1 295 426
lesser 1 295 431
assign 1 296 432
copy 0 296 432
assign 1 297 433
copy 0 297 433
assign 1 297 436
lesser 1 297 441
assign 1 298 442
get 1 298 442
assign 1 298 443
get 1 298 443
assign 1 298 444
lesser 1 298 444
assign 1 299 446
copy 0 299 446
incrementValue 0 297 448
assign 1 302 454
get 1 302 454
assign 1 303 455
get 1 303 455
put 2 303 456
put 2 304 457
incrementValue 0 295 458
assign 1 309 481
new 0 309 481
assign 1 310 482
new 0 310 482
assign 1 311 483
new 0 311 483
assign 1 312 484
lengthGet 0 312 484
assign 1 313 485
lengthGet 0 313 485
assign 1 314 488
lesser 1 314 493
assign 1 315 494
lesser 1 315 499
assign 1 315 500
lesser 1 315 505
assign 1 0 506
assign 1 0 509
assign 1 0 513
assign 1 316 516
get 1 316 516
assign 1 317 517
get 1 317 517
assign 1 318 518
lesser 1 318 518
incrementValue 0 319 520
put 2 320 521
incrementValue 0 322 524
put 2 323 525
assign 1 325 529
lesser 1 325 534
assign 1 326 535
get 1 326 535
incrementValue 0 327 536
put 2 328 537
assign 1 329 540
lesser 1 329 545
assign 1 330 546
get 1 330 546
incrementValue 0 331 547
put 2 332 548
incrementValue 0 334 552
assign 1 339 563
new 0 339 563
assign 1 339 564
mergeSort 2 339 564
return 1 339 565
assign 1 343 585
subtract 1 343 585
assign 1 344 586
new 0 344 586
assign 1 344 587
equals 1 344 592
assign 1 345 593
new 0 345 593
assign 1 345 594
create 1 345 594
return 1 345 595
assign 1 346 598
new 0 346 598
assign 1 346 599
equals 1 346 604
assign 1 347 605
new 0 347 605
assign 1 347 606
create 1 347 606
assign 1 348 607
new 0 348 607
assign 1 348 608
get 1 348 608
put 2 348 609
return 1 349 610
assign 1 351 613
new 0 351 613
assign 1 351 614
divide 1 351 614
assign 1 352 615
subtract 1 352 615
assign 1 353 616
add 1 353 616
assign 1 354 617
mergeSort 2 354 617
assign 1 355 618
mergeSort 2 355 618
assign 1 356 619
create 1 356 619
mergeIn 2 357 620
return 1 358 621
assign 1 363 629
new 0 363 629
assign 1 364 631
new 0 364 631
assign 1 364 632
new 1 364 632
throw 1 364 633
assign 1 370 641
greater 1 370 646
assign 1 371 647
multiply 1 371 647
assign 1 387 650
assign 1 390 654
lesser 1 390 659
incrementValue 0 396 662
setValue 1 398 668
assign 1 402 675
def 1 402 680
assign 1 403 683
hasNextGet 0 403 683
assign 1 404 685
nextGet 0 404 685
addValueWhole 1 404 686
assign 1 410 698
def 1 410 703
assign 1 411 704
iteratorGet 0 411 704
iterateAdd 1 411 705
assign 1 416 712
lesser 1 416 717
incrementValue 0 422 720
assign 1 425 723
copy 0 425 723
put 2 425 724
assign 1 430 732
def 1 430 737
assign 1 430 738
sameType 1 430 738
assign 1 0 740
assign 1 0 743
assign 1 0 747
addAll 1 431 750
addValueWhole 1 433 753
assign 1 439 764
new 0 439 764
assign 1 439 767
lesser 1 439 772
assign 1 440 773
get 1 440 773
assign 1 441 774
def 1 441 779
assign 1 441 780
equals 1 441 780
assign 1 0 782
assign 1 0 785
assign 1 0 789
return 1 442 792
incrementValue 0 439 794
return 1 445 800
assign 1 449 807
find 1 449 807
assign 1 449 808
def 1 449 813
assign 1 450 814
new 0 450 814
return 1 450 815
assign 1 452 817
new 0 452 817
return 1 452 818
assign 1 458 823
new 0 458 823
assign 1 458 824
sortedFind 2 458 824
return 1 458 825
assign 1 465 846
assign 1 466 847
new 0 466 847
assign 1 470 850
subtract 1 470 850
assign 1 470 851
new 0 470 851
assign 1 470 852
divide 1 470 852
assign 1 470 853
add 1 470 853
assign 1 471 854
get 1 471 854
assign 1 472 855
equals 1 472 855
return 1 473 857
assign 1 474 860
greater 1 474 860
assign 1 476 862
assign 1 477 865
lesser 1 477 865
assign 1 479 867
assign 1 482 871
def 1 482 876
assign 1 482 877
equals 1 482 882
assign 1 0 883
assign 1 0 886
assign 1 0 890
assign 1 483 894
get 1 483 894
assign 1 483 895
lesser 1 483 895
assign 1 0 897
assign 1 0 900
assign 1 0 904
return 1 484 907
return 1 486 909
assign 1 488 911
assign 1 489 912
new 0 489 912
return 1 490 914
return 1 0 919
return 1 0 922
return 1 0 925
assign 1 0 928
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1525854240: return bem_arrayIteratorGet_0();
case 1990707345: return bem_lastGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1774940957: return bem_toString_0();
case -183400265: return bem_firstGet_0();
case -1354714650: return bem_copy_0();
case -1308786538: return bem_echo_0();
case 856777406: return bem_clear_0();
case 188061735: return bem_mergeSort_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 474162694: return bem_sizeGet_0();
case 1479417926: return bem_multiplierGet_0();
case 1616433729: return bem_lengthGet_0();
case -1756567691: return bem_anyraySet_0();
case -1767649943: return bem_anyrayGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1751843603: return bem_capacityGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case -1081412016: return bem_many_0();
case -896593457: return bem_sort_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1089531140: return bem_isEmptyGet_0();
case -845792839: return bem_iteratorGet_0();
case -314718434: return bem_print_0();
case 1478277476: return bem_sortValue_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1274448085: return bem_find_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case -228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerList.bevs_inst = (BEC_2_9_4_ContainerList)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerList.bevs_inst;
}
}
}
