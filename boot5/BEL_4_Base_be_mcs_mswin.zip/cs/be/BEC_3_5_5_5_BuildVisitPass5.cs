namespace be {
/* IO:File: source/build/Pass5.be */
public sealed class BEC_3_5_5_5_BuildVisitPass5 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass5() { }
static BEC_3_5_5_5_BuildVisitPass5() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x35};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x35,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_2 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x6F,0x66,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_3 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x61,0x6C,0x69,0x61,0x73,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x20,0x2D,0x61,0x73,0x2D,0x2E};
private static byte[] bels_4 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x6F,0x74,0x20,0x77,0x69,0x74,0x68,0x69,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x75,0x6E,0x69,0x74};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_5 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_6 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_7 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_10 = {0x4F,0x6E,0x6C,0x79,0x20,0x73,0x69,0x6E,0x67,0x6C,0x65,0x20,0x69,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x61,0x6C,0x6C,0x6F,0x77,0x65,0x64};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x62,0x72,0x61,0x63,0x65,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_14 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_16 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_17 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_18 = {0x4C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_19 = {0x46,0x69,0x72,0x73,0x74,0x20,0x63,0x68,0x61,0x72,0x61,0x63,0x74,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x61,0x6E,0x64,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x6E,0x61,0x6D,0x65,0x73,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x6E,0x75,0x6D,0x65,0x72,0x69,0x63,0x20,0x64,0x69,0x67,0x69,0x74};
private static byte[] bels_20 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x31};
private static byte[] bels_21 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x32};
private static byte[] bels_22 = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] bels_23 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x63,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6F,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x2E};
private static byte[] bels_24 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x74,0x68,0x65,0x73,0x69,0x73,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x28,0x62,0x75,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x29,0x20,0x61,0x66,0x74,0x65,0x72,0x3A,0x20};
public static new BEC_3_5_5_5_BuildVisitPass5 bevs_inst;
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_err = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_5_4_BuildNode bevl_lun = null;
BEC_2_5_4_LogicBool bevl_isLocalUse = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_namepath = null;
BEC_2_4_6_TextString bevl_alias = null;
BEC_2_6_6_SystemObject bevl_mas = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_6_6_SystemObject bevl_tnode = null;
BEC_2_5_4_LogicBool bevl_isFinal = null;
BEC_2_5_4_LogicBool bevl_isLocal = null;
BEC_2_5_4_LogicBool bevl_isNotNull = null;
BEC_2_5_4_BuildNode bevl_prp = null;
BEC_2_4_3_MathInt bevl_prpi = null;
BEC_2_5_4_BuildNode bevl_prptmp = null;
BEC_2_6_6_SystemObject bevl_m = null;
BEC_2_6_6_SystemObject bevl_mx = null;
BEC_2_6_6_SystemObject bevl_nx = null;
BEC_2_6_6_SystemObject bevl_con = null;
BEC_2_6_6_SystemObject bevl_lpnode = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_9_BuildTransUnit bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_97_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_98_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_104_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_121_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_5_5_BuildClass bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_129_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_137_tmpany_phold = null;
BEC_2_4_6_TextString bevt_138_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_139_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_153_tmpany_phold = null;
BEC_2_4_6_TextString bevt_154_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_169_tmpany_phold = null;
BEC_2_4_6_TextString bevt_170_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_171_tmpany_phold = null;
BEC_2_4_6_TextString bevt_172_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_173_tmpany_phold = null;
BEC_2_4_6_TextString bevt_174_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_181_tmpany_phold = null;
BEC_2_4_6_TextString bevt_182_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_183_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_184_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_185_tmpany_phold = null;
BEC_2_4_6_TextString bevt_186_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_187_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_188_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_189_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpany_phold = null;
BEC_2_5_6_BuildMethod bevt_191_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_192_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_193_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_194_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_197_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_199_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_200_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpany_phold = null;
BEC_2_4_6_TextString bevt_203_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_204_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_206_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_207_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_208_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpany_phold = null;
BEC_2_4_6_TextString bevt_211_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_212_tmpany_phold = null;
BEC_2_4_6_TextString bevt_213_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_214_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_215_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_216_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_217_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_219_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_221_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_222_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_224_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_225_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_227_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_228_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_231_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_235_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_238_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_239_tmpany_phold = null;
BEC_2_4_6_TextString bevt_240_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_241_tmpany_phold = null;
BEC_2_4_6_TextString bevt_242_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_243_tmpany_phold = null;
BEC_2_4_6_TextString bevt_244_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_245_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_246_tmpany_phold = null;
BEC_2_4_6_TextString bevt_247_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_248_tmpany_phold = null;
BEC_2_4_6_TextString bevt_249_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_250_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_251_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_252_tmpany_phold = null;
BEC_2_5_9_BuildConstants bevt_253_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_254_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_255_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_256_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_257_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_258_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_260_tmpany_phold = null;
BEC_2_4_6_TextString bevt_261_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_263_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_264_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_265_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_267_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_268_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_269_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_270_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_271_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_272_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_273_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_274_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_275_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_276_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_277_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_278_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_279_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_280_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_281_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_282_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_283_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_284_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_285_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_286_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_287_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_288_tmpany_phold = null;
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 20 */ {
bevt_22_tmpany_phold = (BEC_2_5_9_BuildTransUnit) (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
beva_node.bem_heldSet_1(bevt_22_tmpany_phold);
} /* Line: 21 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevt_27_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_29_tmpany_phold = beva_node.bem_heldGet_0();
bevt_31_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_emptyGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpany_phold).bevi_bool) /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 26 */
} /* Line: 24 */
bevl_ix = beva_node.bem_nextPeerGet_0();
if (bevl_ix == null) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevt_34_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_35_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_34_tmpany_phold.bevi_int == bevt_35_tmpany_phold.bevi_int) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_37_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 30 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 30 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 30 */
 else  /* Line: 30 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 30 */ {
bevt_40_tmpany_phold = bevl_ix.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_41_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpany_phold);
if (bevt_39_tmpany_phold != null && bevt_39_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpany_phold).bevi_bool) /* Line: 30 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 30 */
 else  /* Line: 30 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 30 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 32 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_45_tmpany_phold = beva_node.bem_heldGet_0();
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_45_tmpany_phold);
} /* Line: 34 */
 else  /* Line: 35 */ {
bevl_vinp = beva_node.bem_heldGet_0();
} /* Line: 36 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_46_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_46_tmpany_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_47_tmpany_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_47_tmpany_phold);
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 43 */
bevt_49_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_50_tmpany_phold = bevp_ntypes.bem_USEGet_0();
if (bevt_49_tmpany_phold.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevl_lun = beva_node.bem_priorPeerGet_0();
if (bevl_lun == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_53_tmpany_phold = bevl_lun.bem_typenameGet_0();
bevt_54_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_53_tmpany_phold.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevt_56_tmpany_phold = bevl_lun.bem_heldGet_0();
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_0));
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpany_phold);
if (bevt_55_tmpany_phold != null && bevt_55_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_55_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevl_isLocalUse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_lun.bem_delete_0();
} /* Line: 50 */
 else  /* Line: 51 */ {
bevl_isLocalUse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 52 */
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 57 */ {
if (bevl_nnode == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 57 */ {
bevt_60_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_61_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpany_phold);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 57 */ {
bevl_nnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 58 */
 else  /* Line: 57 */ {
break;
} /* Line: 57 */
} /* Line: 57 */
if (bevl_nnode == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_64_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_65_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_65_tmpany_phold);
if (bevt_63_tmpany_phold != null && bevt_63_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpany_phold).bevi_bool) /* Line: 60 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 60 */ {
bevl_clnode = bevl_nnode;
bevt_66_tmpany_phold = bevl_clnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nnode = bevt_66_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 62 */
 else  /* Line: 63 */ {
bevl_clnode = null;
} /* Line: 64 */
if (bevl_nnode == null) {
bevt_67_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_67_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_67_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(59, bels_1));
bevt_68_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_69_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_68_tmpany_phold);
} /* Line: 68 */
bevt_71_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpany_phold);
if (bevt_70_tmpany_phold != null && bevt_70_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpany_phold).bevi_bool) /* Line: 71 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_73_tmpany_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_73_tmpany_phold);
} /* Line: 73 */
 else  /* Line: 71 */ {
bevt_75_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpany_phold);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevl_namepath = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 75 */
 else  /* Line: 76 */ {
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bels_2));
bevt_77_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_78_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_77_tmpany_phold);
} /* Line: 77 */
} /* Line: 71 */
bevl_alias = null;
bevl_mas = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_80_tmpany_phold = bevl_mas.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_81_tmpany_phold = bevp_ntypes.bem_ASGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpany_phold);
if (bevt_79_tmpany_phold != null && bevt_79_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_79_tmpany_phold).bevi_bool) /* Line: 82 */ {
bevl_nnode = bevl_mas.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_83_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_84_tmpany_phold);
if (bevt_82_tmpany_phold != null && bevt_82_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpany_phold).bevi_bool) /* Line: 84 */ {
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bels_3));
bevt_85_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 85 */
bevl_alias = (BEC_2_4_6_TextString) bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 87 */
if (bevl_clnode == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 90 */ {
bevl_gnext = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_89_tmpany_phold = bevl_gnext.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_90_tmpany_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_90_tmpany_phold);
if (bevt_88_tmpany_phold != null && bevt_88_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_88_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevl_nnode = bevl_gnext;
bevl_gnext = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 97 */
} /* Line: 94 */
 else  /* Line: 99 */ {
bevl_gnext = bevl_clnode;
} /* Line: 100 */
beva_node.bem_heldSet_1(bevl_namepath);
bevl_tnode = beva_node.bem_transUnitGet_0();
if (bevl_tnode == null) {
bevt_91_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_91_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_91_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(53, bels_4));
bevt_92_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_93_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_92_tmpany_phold);
} /* Line: 107 */
if (bevl_alias == null) {
bevt_94_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_94_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_94_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevl_alias = (BEC_2_4_6_TextString) bevl_namepath.bemd_0(-1672091917, BEL_4_Base.bevn_labelGet_0);
} /* Line: 111 */
bevt_96_tmpany_phold = bevl_tnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_95_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_alias, bevl_namepath);
if (bevl_isLocalUse.bevi_bool) /* Line: 114 */ {
bevt_98_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_aliasedGet_0();
bevt_97_tmpany_phold.bem_put_2(bevl_alias, bevl_namepath);
} /* Line: 115 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 118 */
bevt_100_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_101_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_100_tmpany_phold.bevi_int == bevt_101_tmpany_phold.bevi_int) {
bevt_99_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_99_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_99_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevl_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_isLocal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_isNotNull = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 125 */ {
bevt_103_tmpany_phold = bevo_0;
if (bevl_prpi.bevi_int < bevt_103_tmpany_phold.bevi_int) {
bevt_102_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpany_phold.bevi_bool) /* Line: 125 */ {
if (bevl_prp == null) {
bevt_104_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_104_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_104_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_106_tmpany_phold = bevl_prp.bem_typenameGet_0();
bevt_107_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_106_tmpany_phold.bevi_int == bevt_107_tmpany_phold.bevi_int) {
bevt_105_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_105_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_105_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevt_109_tmpany_phold = bevl_prp.bem_typenameGet_0();
bevt_110_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_109_tmpany_phold.bevi_int == bevt_110_tmpany_phold.bevi_int) {
bevt_108_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_108_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevt_112_tmpany_phold = bevl_prp.bem_heldGet_0();
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_5));
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_113_tmpany_phold);
if (bevt_111_tmpany_phold != null && bevt_111_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpany_phold).bevi_bool) /* Line: 128 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 128 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 128 */
 else  /* Line: 128 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 128 */ {
bevl_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 129 */
 else  /* Line: 128 */ {
bevt_115_tmpany_phold = bevl_prp.bem_typenameGet_0();
bevt_116_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_115_tmpany_phold.bevi_int == bevt_116_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_118_tmpany_phold = bevl_prp.bem_heldGet_0();
bevt_119_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_6));
bevt_117_tmpany_phold = bevt_118_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_119_tmpany_phold);
if (bevt_117_tmpany_phold != null && bevt_117_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_117_tmpany_phold).bevi_bool) /* Line: 130 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 130 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 130 */
 else  /* Line: 130 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 130 */ {
bevl_isLocal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 131 */
 else  /* Line: 128 */ {
bevt_121_tmpany_phold = bevl_prp.bem_typenameGet_0();
bevt_122_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_121_tmpany_phold.bevi_int == bevt_122_tmpany_phold.bevi_int) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_124_tmpany_phold = bevl_prp.bem_heldGet_0();
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_7));
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_125_tmpany_phold);
if (bevt_123_tmpany_phold != null && bevt_123_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_123_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 132 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 132 */
 else  /* Line: 132 */ {
bevt_9_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpany_anchor.bevi_bool) /* Line: 132 */ {
bevl_isNotNull = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 133 */
} /* Line: 128 */
} /* Line: 128 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 137 */
 else  /* Line: 138 */ {
bevl_prp = null;
} /* Line: 139 */
} /* Line: 127 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 125 */
 else  /* Line: 125 */ {
break;
} /* Line: 125 */
} /* Line: 125 */
bevt_126_tmpany_phold = (BEC_2_5_5_BuildClass) (new BEC_2_5_5_BuildClass()).bem_new_0();
beva_node.bem_heldSet_1(bevt_126_tmpany_phold);
bevt_127_tmpany_phold = beva_node.bem_heldGet_0();
bevt_128_tmpany_phold = bevp_build.bem_fromFileGet_0();
bevt_127_tmpany_phold.bemd_1(806119150, BEL_4_Base.bevn_fromFileSet_1, bevt_128_tmpany_phold);
try  /* Line: 145 */ {
bevt_129_tmpany_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_129_tmpany_phold.bem_firstGet_0();
bevt_131_tmpany_phold = bevl_m.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_132_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_130_tmpany_phold = bevt_131_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_132_tmpany_phold);
if (bevt_130_tmpany_phold != null && bevt_130_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_130_tmpany_phold).bevi_bool) /* Line: 147 */ {
bevl_namepath = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_133_tmpany_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_133_tmpany_phold);
} /* Line: 149 */
 else  /* Line: 147 */ {
bevt_135_tmpany_phold = bevl_m.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_136_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_134_tmpany_phold = bevt_135_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpany_phold);
if (bevt_134_tmpany_phold != null && bevt_134_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_134_tmpany_phold).bevi_bool) /* Line: 150 */ {
bevl_namepath = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 151 */
 else  /* Line: 152 */ {
bevt_138_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bels_8));
bevt_137_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_138_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_137_tmpany_phold);
} /* Line: 153 */
} /* Line: 147 */
bevt_139_tmpany_phold = beva_node.bem_heldGet_0();
bevt_139_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_namepath);
bevt_140_tmpany_phold = beva_node.bem_heldGet_0();
bevt_140_tmpany_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevl_isFinal);
bevt_141_tmpany_phold = beva_node.bem_heldGet_0();
bevt_141_tmpany_phold.bemd_1(-831500365, BEL_4_Base.bevn_isLocalSet_1, bevl_isLocal);
bevt_142_tmpany_phold = beva_node.bem_heldGet_0();
bevt_142_tmpany_phold.bemd_1(374719236, BEL_4_Base.bevn_isNotNullSet_1, bevl_isNotNull);
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 159 */
 catch (System.Exception beve_0) {
bevl_err = (be.BECS_ThrowBack.handleThrow(beve_0));
bevl_err.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
bevt_144_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bels_9));
bevt_143_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 162 */
try  /* Line: 164 */ {
bevt_145_tmpany_phold = beva_node.bem_containedGet_0();
bevl_nnode = bevt_145_tmpany_phold.bem_firstGet_0();
bevt_147_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_148_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_148_tmpany_phold);
if (bevt_146_tmpany_phold != null && bevt_146_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpany_phold).bevi_bool) /* Line: 166 */ {
bevt_151_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_152_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_152_tmpany_phold);
if (bevt_149_tmpany_phold != null && bevt_149_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpany_phold).bevi_bool) /* Line: 167 */ {
bevt_154_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_10));
bevt_153_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_154_tmpany_phold, bevl_nnode);
throw new be.BECS_ThrowBack(bevt_153_tmpany_phold);
} /* Line: 168 */
try  /* Line: 170 */ {
bevt_155_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_m = bevt_155_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_157_tmpany_phold = bevl_m.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_158_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_156_tmpany_phold = bevt_157_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_158_tmpany_phold);
if (bevt_156_tmpany_phold != null && bevt_156_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_156_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevt_159_tmpany_phold = beva_node.bem_heldGet_0();
bevt_160_tmpany_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_159_tmpany_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_160_tmpany_phold);
bevt_162_tmpany_phold = beva_node.bem_heldGet_0();
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_163_tmpany_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpany_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_163_tmpany_phold);
} /* Line: 174 */
 else  /* Line: 172 */ {
bevt_165_tmpany_phold = bevl_m.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_166_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_164_tmpany_phold = bevt_165_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_166_tmpany_phold);
if (bevt_164_tmpany_phold != null && bevt_164_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_164_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevt_167_tmpany_phold = beva_node.bem_heldGet_0();
bevt_168_tmpany_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_167_tmpany_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_168_tmpany_phold);
} /* Line: 176 */
 else  /* Line: 177 */ {
bevt_170_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bels_11));
bevt_169_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_170_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_169_tmpany_phold);
} /* Line: 178 */
} /* Line: 172 */
} /* Line: 172 */
 catch (System.Exception beve_1) {
bevl_err = (be.BECS_ThrowBack.handleThrow(beve_1));
bevl_err.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
bevt_172_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(68, bels_12));
bevt_171_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_172_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_171_tmpany_phold);
} /* Line: 183 */
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 185 */
} /* Line: 166 */
 catch (System.Exception beve_2) {
bevl_err = (be.BECS_ThrowBack.handleThrow(beve_2));
bevl_err.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
bevt_174_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(60, bels_13));
bevt_173_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_174_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_173_tmpany_phold);
} /* Line: 189 */
bevt_177_tmpany_phold = beva_node.bem_heldGet_0();
bevt_176_tmpany_phold = bevt_177_tmpany_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_176_tmpany_phold == null) {
bevt_175_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_175_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_175_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_181_tmpany_phold = beva_node.bem_heldGet_0();
bevt_180_tmpany_phold = bevt_181_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_179_tmpany_phold = bevt_180_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_182_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_14));
bevt_178_tmpany_phold = bevt_179_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_182_tmpany_phold);
if (bevt_178_tmpany_phold != null && bevt_178_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_178_tmpany_phold).bevi_bool) /* Line: 192 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_10_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_183_tmpany_phold = beva_node.bem_heldGet_0();
bevt_185_tmpany_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_186_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_15));
bevt_184_tmpany_phold = (BEC_2_5_8_BuildNamePath) bevt_185_tmpany_phold.bem_fromString_1(bevt_186_tmpany_phold);
bevt_183_tmpany_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_184_tmpany_phold);
} /* Line: 193 */
bevt_187_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_187_tmpany_phold;
} /* Line: 196 */
bevt_189_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_190_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_189_tmpany_phold.bevi_int == bevt_190_tmpany_phold.bevi_int) {
bevt_188_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_188_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_188_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_191_tmpany_phold = (BEC_2_5_6_BuildMethod) (new BEC_2_5_6_BuildMethod()).bem_new_0();
beva_node.bem_heldSet_1(bevt_191_tmpany_phold);
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 201 */ {
bevt_193_tmpany_phold = bevo_1;
if (bevl_prpi.bevi_int < bevt_193_tmpany_phold.bevi_int) {
bevt_192_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_192_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_192_tmpany_phold.bevi_bool) /* Line: 201 */ {
if (bevl_prp == null) {
bevt_194_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_194_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_194_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevt_196_tmpany_phold = bevl_prp.bem_typenameGet_0();
bevt_197_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_196_tmpany_phold.bevi_int == bevt_197_tmpany_phold.bevi_int) {
bevt_195_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_195_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_195_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevt_199_tmpany_phold = bevl_prp.bem_typenameGet_0();
bevt_200_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_199_tmpany_phold.bevi_int == bevt_200_tmpany_phold.bevi_int) {
bevt_198_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_198_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_198_tmpany_phold.bevi_bool) /* Line: 204 */ {
bevt_202_tmpany_phold = bevl_prp.bem_heldGet_0();
bevt_203_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_16));
bevt_201_tmpany_phold = bevt_202_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_203_tmpany_phold);
if (bevt_201_tmpany_phold != null && bevt_201_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_201_tmpany_phold).bevi_bool) /* Line: 204 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 204 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 204 */
 else  /* Line: 204 */ {
bevt_11_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpany_anchor.bevi_bool) /* Line: 204 */ {
bevt_204_tmpany_phold = beva_node.bem_heldGet_0();
bevt_205_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_204_tmpany_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevt_205_tmpany_phold);
} /* Line: 205 */
 else  /* Line: 204 */ {
bevt_207_tmpany_phold = bevl_prp.bem_typenameGet_0();
bevt_208_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
if (bevt_207_tmpany_phold.bevi_int == bevt_208_tmpany_phold.bevi_int) {
bevt_206_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_206_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_206_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevt_210_tmpany_phold = bevl_prp.bem_heldGet_0();
bevt_211_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_17));
bevt_209_tmpany_phold = bevt_210_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_211_tmpany_phold);
if (bevt_209_tmpany_phold != null && bevt_209_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_209_tmpany_phold).bevi_bool) /* Line: 206 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 206 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 206 */
 else  /* Line: 206 */ {
bevt_12_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpany_anchor.bevi_bool) /* Line: 206 */ {
bevt_213_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bels_18));
bevt_212_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_213_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_212_tmpany_phold);
} /* Line: 208 */
} /* Line: 204 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 212 */
 else  /* Line: 213 */ {
bevl_prp = null;
} /* Line: 214 */
} /* Line: 203 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 201 */
 else  /* Line: 201 */ {
break;
} /* Line: 201 */
} /* Line: 201 */
try  /* Line: 218 */ {
bevt_214_tmpany_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_214_tmpany_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_215_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_215_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_215_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevl_mx = bevl_m.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_mx == null) {
bevt_216_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_216_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_216_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevl_mx = bevl_mx.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_218_tmpany_phold = bevl_mx.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_219_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_217_tmpany_phold = bevt_218_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_219_tmpany_phold);
if (bevt_217_tmpany_phold != null && bevt_217_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_217_tmpany_phold).bevi_bool) /* Line: 224 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_221_tmpany_phold = bevl_mx.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_222_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_220_tmpany_phold = bevt_221_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_222_tmpany_phold);
if (bevt_220_tmpany_phold != null && bevt_220_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_220_tmpany_phold).bevi_bool) /* Line: 224 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_13_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
if (bevt_13_tmpany_anchor.bevi_bool) /* Line: 224 */ {
bevt_224_tmpany_phold = bevl_mx.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_225_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_223_tmpany_phold = bevt_224_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_225_tmpany_phold);
if (bevt_223_tmpany_phold != null && bevt_223_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_223_tmpany_phold).bevi_bool) /* Line: 226 */ {
bevl_vinp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_226_tmpany_phold = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_226_tmpany_phold);
} /* Line: 228 */
 else  /* Line: 229 */ {
bevl_vinp = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 230 */
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_227_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_227_tmpany_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_228_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_mx.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_228_tmpany_phold);
bevl_mx.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
} /* Line: 236 */
} /* Line: 224 */
bevt_230_tmpany_phold = bevl_m.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_231_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_229_tmpany_phold = bevt_230_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_231_tmpany_phold);
if (bevt_229_tmpany_phold != null && bevt_229_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_229_tmpany_phold).bevi_bool) /* Line: 239 */ {
bevt_232_tmpany_phold = beva_node.bem_heldGet_0();
bevt_233_tmpany_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_232_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_233_tmpany_phold);
bevt_237_tmpany_phold = beva_node.bem_heldGet_0();
bevt_236_tmpany_phold = bevt_237_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_238_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_235_tmpany_phold = bevt_236_tmpany_phold.bemd_1(636254476, BEL_4_Base.bevn_getPoint_1, bevt_238_tmpany_phold);
bevt_234_tmpany_phold = bevt_235_tmpany_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_234_tmpany_phold != null && bevt_234_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_234_tmpany_phold).bevi_bool) /* Line: 241 */ {
bevt_240_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(75, bels_19));
bevt_239_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_239_tmpany_phold);
} /* Line: 242 */
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 244 */
 else  /* Line: 245 */ {
bevt_242_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bels_20));
bevt_241_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_242_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_241_tmpany_phold);
} /* Line: 246 */
} /* Line: 239 */
 else  /* Line: 248 */ {
bevt_244_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bels_21));
bevt_243_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_244_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_243_tmpany_phold);
} /* Line: 249 */
} /* Line: 220 */
 catch (System.Exception beve_3) {
bevl_err = (be.BECS_ThrowBack.handleThrow(beve_3));
bevt_246_tmpany_phold = bevl_err.bemd_0(1102720804, BEL_4_Base.bevn_classNameGet_0);
bevt_247_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_22));
bevt_245_tmpany_phold = bevt_246_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_247_tmpany_phold);
if (bevt_245_tmpany_phold != null && bevt_245_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_245_tmpany_phold).bevi_bool) /* Line: 252 */ {
throw new be.BECS_ThrowBack(bevl_err);
} /* Line: 252 */
bevl_err.bemd_0(-314718434, BEL_4_Base.bevn_print_0);
bevt_249_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(104, bels_23));
bevt_248_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_249_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_248_tmpany_phold);
} /* Line: 254 */
bevt_250_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_250_tmpany_phold;
} /* Line: 256 */
bevt_253_tmpany_phold = bevp_build.bem_constantsGet_0();
bevt_252_tmpany_phold = bevt_253_tmpany_phold.bem_parensReqGet_0();
bevt_254_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_251_tmpany_phold = bevt_252_tmpany_phold.bem_has_1(bevt_254_tmpany_phold);
if (bevt_251_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevt_255_tmpany_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_255_tmpany_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_256_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_256_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_256_tmpany_phold.bevi_bool) /* Line: 260 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 260 */ {
bevt_258_tmpany_phold = bevl_m.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_259_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_257_tmpany_phold = bevt_258_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_259_tmpany_phold);
if (bevt_257_tmpany_phold != null && bevt_257_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_257_tmpany_phold).bevi_bool) /* Line: 260 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 260 */ {
bevt_14_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 260 */
if (bevt_14_tmpany_anchor.bevi_bool) /* Line: 260 */ {
bevt_261_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bels_24));
bevt_260_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_261_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_260_tmpany_phold);
} /* Line: 261 */
} /* Line: 260 */
bevt_263_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_264_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_263_tmpany_phold.bevi_int == bevt_264_tmpany_phold.bevi_int) {
bevt_262_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_262_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_262_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevl_m = beva_node.bem_containerGet_0();
if (bevl_m == null) {
bevt_265_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_265_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_265_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_267_tmpany_phold = bevl_m.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_268_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_266_tmpany_phold = bevt_267_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_268_tmpany_phold);
if (bevt_266_tmpany_phold != null && bevt_266_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_266_tmpany_phold).bevi_bool) /* Line: 267 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 267 */
 else  /* Line: 267 */ {
bevt_15_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpany_anchor.bevi_bool) /* Line: 267 */ {
bevt_269_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
beva_node.bem_typenameSet_1(bevt_269_tmpany_phold);
} /* Line: 268 */
} /* Line: 267 */
bevt_271_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_272_tmpany_phold = bevp_ntypes.bem_SEMIGet_0();
if (bevt_271_tmpany_phold.bevi_int == bevt_272_tmpany_phold.bevi_int) {
bevt_270_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_270_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_270_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevl_nx = beva_node.bem_priorPeerGet_0();
bevl_gnext = beva_node.bem_nextAscendGet_0();
while (true)
 /* Line: 277 */ {
if (bevl_nx == null) {
bevt_273_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_273_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_273_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_275_tmpany_phold = bevl_nx.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_276_tmpany_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_274_tmpany_phold = bevt_275_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_276_tmpany_phold);
if (bevt_274_tmpany_phold != null && bevt_274_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_274_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_18_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_278_tmpany_phold = bevl_nx.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_279_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_277_tmpany_phold = bevt_278_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_279_tmpany_phold);
if (bevt_277_tmpany_phold != null && bevt_277_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_277_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_17_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_281_tmpany_phold = bevl_nx.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_282_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_280_tmpany_phold = bevt_281_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_282_tmpany_phold);
if (bevt_280_tmpany_phold != null && bevt_280_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_280_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_16_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpany_anchor.bevi_bool) /* Line: 277 */ {
if (bevl_con == null) {
bevt_283_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_283_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_283_tmpany_phold.bevi_bool) /* Line: 278 */ {
bevl_con = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 279 */
bevl_con.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_nx);
bevl_nx = bevl_nx.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
} /* Line: 282 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
if (bevl_con == null) {
bevt_284_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_284_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_284_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_285_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
beva_node.bem_typenameSet_1(bevt_285_tmpany_phold);
beva_node.bem_heldSet_1(null);
bevl_lpnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_286_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_lpnode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_286_tmpany_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_lpnode);
bevl_lpnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_ii = bevl_con.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 291 */ {
bevt_287_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_287_tmpany_phold != null && bevt_287_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_287_tmpany_phold).bevi_bool) /* Line: 291 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lpnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 294 */
 else  /* Line: 291 */ {
break;
} /* Line: 291 */
} /* Line: 291 */
} /* Line: 291 */
 else  /* Line: 300 */ {
beva_node.bem_delete_0();
} /* Line: 301 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 303 */
bevt_288_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_288_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 20, 20, 20, 21, 21, 23, 23, 23, 23, 24, 24, 24, 0, 24, 24, 24, 24, 0, 0, 25, 26, 29, 30, 30, 30, 30, 30, 30, 0, 30, 30, 30, 30, 0, 0, 0, 0, 0, 30, 30, 30, 0, 0, 0, 32, 32, 32, 32, 33, 34, 34, 36, 38, 39, 39, 41, 42, 42, 43, 45, 45, 45, 45, 47, 48, 48, 48, 48, 48, 48, 0, 0, 0, 48, 48, 48, 0, 0, 0, 49, 50, 52, 56, 57, 57, 57, 57, 57, 0, 0, 0, 58, 60, 60, 60, 60, 60, 0, 0, 0, 61, 62, 62, 64, 67, 67, 68, 68, 68, 71, 71, 71, 72, 73, 73, 74, 74, 74, 75, 77, 77, 77, 80, 81, 82, 82, 82, 83, 84, 84, 84, 85, 85, 85, 87, 90, 90, 91, 92, 94, 94, 94, 95, 96, 97, 100, 102, 104, 106, 106, 107, 107, 107, 110, 110, 111, 113, 113, 113, 115, 115, 115, 118, 120, 120, 120, 120, 121, 122, 123, 124, 125, 125, 125, 125, 126, 126, 127, 127, 127, 127, 128, 128, 128, 128, 128, 128, 128, 0, 0, 0, 129, 130, 130, 130, 130, 130, 130, 130, 0, 0, 0, 131, 132, 132, 132, 132, 132, 132, 132, 0, 0, 0, 133, 135, 136, 137, 139, 125, 143, 143, 144, 144, 144, 146, 146, 147, 147, 147, 148, 149, 149, 150, 150, 150, 151, 153, 153, 153, 155, 155, 156, 156, 157, 157, 158, 158, 159, 161, 162, 162, 162, 165, 165, 166, 166, 166, 167, 167, 167, 167, 168, 168, 168, 171, 171, 172, 172, 172, 173, 173, 173, 174, 174, 174, 174, 175, 175, 175, 176, 176, 176, 178, 178, 178, 182, 183, 183, 183, 185, 188, 189, 189, 189, 192, 192, 192, 192, 192, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 193, 193, 196, 196, 198, 198, 198, 198, 199, 199, 200, 201, 201, 201, 201, 202, 202, 203, 203, 203, 203, 204, 204, 204, 204, 204, 204, 204, 0, 0, 0, 205, 205, 205, 206, 206, 206, 206, 206, 206, 206, 0, 0, 0, 208, 208, 208, 210, 211, 212, 214, 201, 219, 219, 220, 220, 221, 222, 222, 223, 224, 224, 224, 0, 224, 224, 224, 0, 0, 226, 226, 226, 227, 228, 228, 230, 232, 233, 233, 234, 235, 235, 236, 239, 239, 239, 240, 240, 240, 241, 241, 241, 241, 241, 242, 242, 242, 244, 246, 246, 246, 249, 249, 249, 252, 252, 252, 252, 253, 254, 254, 254, 256, 256, 258, 258, 258, 258, 259, 259, 260, 260, 0, 260, 260, 260, 0, 0, 261, 261, 261, 265, 265, 265, 265, 266, 267, 267, 267, 267, 267, 0, 0, 0, 268, 268, 271, 271, 271, 271, 272, 273, 277, 277, 277, 277, 277, 0, 0, 0, 277, 277, 277, 0, 0, 0, 277, 277, 277, 0, 0, 0, 278, 278, 279, 281, 282, 284, 284, 285, 285, 286, 287, 288, 288, 289, 290, 291, 291, 292, 293, 294, 301, 303, 306, 306};
public static new int[] bevs_smnlec
 = new int[] {352, 353, 354, 359, 360, 361, 363, 364, 365, 370, 371, 372, 377, 378, 381, 382, 383, 384, 386, 389, 393, 394, 397, 398, 403, 404, 405, 406, 411, 412, 415, 416, 417, 422, 423, 426, 430, 433, 437, 440, 441, 442, 444, 447, 451, 454, 455, 456, 461, 462, 463, 464, 467, 469, 470, 471, 472, 473, 474, 475, 477, 478, 479, 484, 485, 486, 491, 492, 493, 494, 499, 500, 503, 507, 510, 511, 512, 514, 517, 521, 524, 525, 528, 530, 533, 538, 539, 540, 541, 543, 546, 550, 553, 559, 564, 565, 566, 567, 569, 572, 576, 579, 580, 581, 584, 586, 591, 592, 593, 594, 596, 597, 598, 600, 601, 602, 605, 606, 607, 609, 612, 613, 614, 617, 618, 619, 620, 621, 623, 624, 625, 626, 628, 629, 630, 632, 634, 639, 640, 641, 642, 643, 644, 646, 647, 648, 652, 654, 655, 656, 661, 662, 663, 664, 666, 671, 672, 674, 675, 676, 678, 679, 680, 682, 684, 685, 686, 691, 692, 693, 694, 695, 696, 699, 700, 705, 706, 711, 712, 713, 714, 719, 720, 721, 722, 727, 728, 729, 730, 732, 735, 739, 742, 745, 746, 747, 752, 753, 754, 755, 757, 760, 764, 767, 770, 771, 772, 777, 778, 779, 780, 782, 785, 789, 792, 796, 797, 798, 801, 804, 810, 811, 812, 813, 814, 816, 817, 818, 819, 820, 822, 823, 824, 827, 828, 829, 831, 834, 835, 836, 839, 840, 841, 842, 843, 844, 845, 846, 847, 851, 852, 853, 854, 857, 858, 859, 860, 861, 863, 864, 865, 866, 868, 869, 870, 873, 874, 875, 876, 877, 879, 880, 881, 882, 883, 884, 885, 888, 889, 890, 892, 893, 894, 897, 898, 899, 905, 906, 907, 908, 910, 915, 916, 917, 918, 920, 921, 922, 927, 928, 929, 930, 931, 932, 934, 937, 941, 944, 945, 946, 947, 948, 950, 951, 953, 954, 955, 960, 961, 962, 963, 964, 967, 968, 973, 974, 979, 980, 981, 982, 987, 988, 989, 990, 995, 996, 997, 998, 1000, 1003, 1007, 1010, 1011, 1012, 1015, 1016, 1017, 1022, 1023, 1024, 1025, 1027, 1030, 1034, 1037, 1038, 1039, 1042, 1043, 1044, 1047, 1050, 1057, 1058, 1059, 1064, 1065, 1066, 1071, 1072, 1073, 1074, 1075, 1077, 1080, 1081, 1082, 1084, 1087, 1091, 1092, 1093, 1095, 1096, 1097, 1100, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1111, 1112, 1113, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1124, 1125, 1126, 1128, 1131, 1132, 1133, 1137, 1138, 1139, 1144, 1145, 1146, 1148, 1150, 1151, 1152, 1153, 1155, 1156, 1158, 1159, 1160, 1161, 1163, 1164, 1165, 1170, 1171, 1174, 1175, 1176, 1178, 1181, 1185, 1186, 1187, 1190, 1191, 1192, 1197, 1198, 1199, 1204, 1205, 1206, 1207, 1209, 1212, 1216, 1219, 1220, 1223, 1224, 1225, 1230, 1231, 1232, 1235, 1240, 1241, 1242, 1243, 1245, 1248, 1252, 1255, 1256, 1257, 1259, 1262, 1266, 1269, 1270, 1271, 1273, 1276, 1280, 1283, 1288, 1289, 1291, 1292, 1298, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1315, 1317, 1318, 1319, 1327, 1329, 1331, 1332};
/* BEGIN LINEINFO 
assign 1 20 352
typenameGet 0 20 352
assign 1 20 353
TRANSUNITGet 0 20 353
assign 1 20 354
equals 1 20 359
assign 1 21 360
new 0 21 360
heldSet 1 21 361
assign 1 23 363
typenameGet 0 23 363
assign 1 23 364
VARGet 0 23 364
assign 1 23 365
equals 1 23 370
assign 1 24 371
heldGet 0 24 371
assign 1 24 372
undef 1 24 377
assign 1 0 378
assign 1 24 381
heldGet 0 24 381
assign 1 24 382
new 0 24 382
assign 1 24 383
emptyGet 0 24 383
assign 1 24 384
sameType 1 24 384
assign 1 0 386
assign 1 0 389
assign 1 25 393
new 0 25 393
heldSet 1 26 394
assign 1 29 397
nextPeerGet 0 29 397
assign 1 30 398
def 1 30 403
assign 1 30 404
typenameGet 0 30 404
assign 1 30 405
IDGet 0 30 405
assign 1 30 406
equals 1 30 411
assign 1 0 412
assign 1 30 415
typenameGet 0 30 415
assign 1 30 416
NAMEPATHGet 0 30 416
assign 1 30 417
equals 1 30 422
assign 1 0 423
assign 1 0 426
assign 1 0 430
assign 1 0 433
assign 1 0 437
assign 1 30 440
typenameGet 0 30 440
assign 1 30 441
IDGet 0 30 441
assign 1 30 442
equals 1 30 442
assign 1 0 444
assign 1 0 447
assign 1 0 451
assign 1 32 454
typenameGet 0 32 454
assign 1 32 455
IDGet 0 32 455
assign 1 32 456
equals 1 32 461
assign 1 33 462
new 0 33 462
assign 1 34 463
heldGet 0 34 463
addStep 1 34 464
assign 1 36 467
heldGet 0 36 467
assign 1 38 469
new 0 38 469
assign 1 39 470
new 0 39 470
isTypedSet 1 39 471
namepathSet 1 41 472
assign 1 42 473
VARGet 0 42 473
typenameSet 1 42 474
heldSet 1 43 475
assign 1 45 477
typenameGet 0 45 477
assign 1 45 478
USEGet 0 45 478
assign 1 45 479
equals 1 45 484
assign 1 47 485
priorPeerGet 0 47 485
assign 1 48 486
def 1 48 491
assign 1 48 492
typenameGet 0 48 492
assign 1 48 493
DEFMODGet 0 48 493
assign 1 48 494
equals 1 48 499
assign 1 0 500
assign 1 0 503
assign 1 0 507
assign 1 48 510
heldGet 0 48 510
assign 1 48 511
new 0 48 511
assign 1 48 512
equals 1 48 512
assign 1 0 514
assign 1 0 517
assign 1 0 521
assign 1 49 524
new 0 49 524
delete 0 50 525
assign 1 52 528
new 0 52 528
assign 1 56 530
nextPeerGet 0 56 530
assign 1 57 533
def 1 57 538
assign 1 57 539
typenameGet 0 57 539
assign 1 57 540
DEFMODGet 0 57 540
assign 1 57 541
equals 1 57 541
assign 1 0 543
assign 1 0 546
assign 1 0 550
assign 1 58 553
nextPeerGet 0 58 553
assign 1 60 559
def 1 60 564
assign 1 60 565
typenameGet 0 60 565
assign 1 60 566
CLASSGet 0 60 566
assign 1 60 567
equals 1 60 567
assign 1 0 569
assign 1 0 572
assign 1 0 576
assign 1 61 579
assign 1 62 580
containedGet 0 62 580
assign 1 62 581
firstGet 0 62 581
assign 1 64 584
assign 1 67 586
undef 1 67 591
assign 1 68 592
new 0 68 592
assign 1 68 593
new 2 68 593
throw 1 68 594
assign 1 71 596
typenameGet 0 71 596
assign 1 71 597
IDGet 0 71 597
assign 1 71 598
equals 1 71 598
assign 1 72 600
new 0 72 600
assign 1 73 601
heldGet 0 73 601
addStep 1 73 602
assign 1 74 605
typenameGet 0 74 605
assign 1 74 606
NAMEPATHGet 0 74 606
assign 1 74 607
equals 1 74 607
assign 1 75 609
heldGet 0 75 609
assign 1 77 612
new 0 77 612
assign 1 77 613
new 2 77 613
throw 1 77 614
assign 1 80 617
assign 1 81 618
nextPeerGet 0 81 618
assign 1 82 619
typenameGet 0 82 619
assign 1 82 620
ASGet 0 82 620
assign 1 82 621
equals 1 82 621
assign 1 83 623
nextPeerGet 0 83 623
assign 1 84 624
typenameGet 0 84 624
assign 1 84 625
IDGet 0 84 625
assign 1 84 626
notEquals 1 84 626
assign 1 85 628
new 0 85 628
assign 1 85 629
new 2 85 629
throw 1 85 630
assign 1 87 632
heldGet 0 87 632
assign 1 90 634
undef 1 90 639
assign 1 91 640
nextPeerGet 0 91 640
delete 0 92 641
assign 1 94 642
typenameGet 0 94 642
assign 1 94 643
SEMIGet 0 94 643
assign 1 94 644
equals 1 94 644
assign 1 95 646
assign 1 96 647
nextPeerGet 0 96 647
delete 0 97 648
assign 1 100 652
heldSet 1 102 654
assign 1 104 655
transUnitGet 0 104 655
assign 1 106 656
undef 1 106 661
assign 1 107 662
new 0 107 662
assign 1 107 663
new 2 107 663
throw 1 107 664
assign 1 110 666
undef 1 110 671
assign 1 111 672
labelGet 0 111 672
assign 1 113 674
heldGet 0 113 674
assign 1 113 675
aliasedGet 0 113 675
put 2 113 676
assign 1 115 678
emitDataGet 0 115 678
assign 1 115 679
aliasedGet 0 115 679
put 2 115 680
return 1 118 682
assign 1 120 684
typenameGet 0 120 684
assign 1 120 685
CLASSGet 0 120 685
assign 1 120 686
equals 1 120 691
assign 1 121 692
new 0 121 692
assign 1 122 693
new 0 122 693
assign 1 123 694
new 0 123 694
assign 1 124 695
priorPeerGet 0 124 695
assign 1 125 696
new 0 125 696
assign 1 125 699
new 0 125 699
assign 1 125 700
lesser 1 125 705
assign 1 126 706
def 1 126 711
assign 1 127 712
typenameGet 0 127 712
assign 1 127 713
DEFMODGet 0 127 713
assign 1 127 714
equals 1 127 719
assign 1 128 720
typenameGet 0 128 720
assign 1 128 721
DEFMODGet 0 128 721
assign 1 128 722
equals 1 128 727
assign 1 128 728
heldGet 0 128 728
assign 1 128 729
new 0 128 729
assign 1 128 730
equals 1 128 730
assign 1 0 732
assign 1 0 735
assign 1 0 739
assign 1 129 742
new 0 129 742
assign 1 130 745
typenameGet 0 130 745
assign 1 130 746
DEFMODGet 0 130 746
assign 1 130 747
equals 1 130 752
assign 1 130 753
heldGet 0 130 753
assign 1 130 754
new 0 130 754
assign 1 130 755
equals 1 130 755
assign 1 0 757
assign 1 0 760
assign 1 0 764
assign 1 131 767
new 0 131 767
assign 1 132 770
typenameGet 0 132 770
assign 1 132 771
DEFMODGet 0 132 771
assign 1 132 772
equals 1 132 777
assign 1 132 778
heldGet 0 132 778
assign 1 132 779
new 0 132 779
assign 1 132 780
equals 1 132 780
assign 1 0 782
assign 1 0 785
assign 1 0 789
assign 1 133 792
new 0 133 792
assign 1 135 796
priorPeerGet 0 135 796
delete 0 136 797
assign 1 137 798
assign 1 139 801
assign 1 125 804
increment 0 125 804
assign 1 143 810
new 0 143 810
heldSet 1 143 811
assign 1 144 812
heldGet 0 144 812
assign 1 144 813
fromFileGet 0 144 813
fromFileSet 1 144 814
assign 1 146 816
containedGet 0 146 816
assign 1 146 817
firstGet 0 146 817
assign 1 147 818
typenameGet 0 147 818
assign 1 147 819
IDGet 0 147 819
assign 1 147 820
equals 1 147 820
assign 1 148 822
new 0 148 822
assign 1 149 823
heldGet 0 149 823
addStep 1 149 824
assign 1 150 827
typenameGet 0 150 827
assign 1 150 828
NAMEPATHGet 0 150 828
assign 1 150 829
equals 1 150 829
assign 1 151 831
heldGet 0 151 831
assign 1 153 834
new 0 153 834
assign 1 153 835
new 2 153 835
throw 1 153 836
assign 1 155 839
heldGet 0 155 839
namepathSet 1 155 840
assign 1 156 841
heldGet 0 156 841
isFinalSet 1 156 842
assign 1 157 843
heldGet 0 157 843
isLocalSet 1 157 844
assign 1 158 845
heldGet 0 158 845
isNotNullSet 1 158 846
delete 0 159 847
print 0 161 851
assign 1 162 852
new 0 162 852
assign 1 162 853
new 2 162 853
throw 1 162 854
assign 1 165 857
containedGet 0 165 857
assign 1 165 858
firstGet 0 165 858
assign 1 166 859
typenameGet 0 166 859
assign 1 166 860
PARENSGet 0 166 860
assign 1 166 861
equals 1 166 861
assign 1 167 863
containedGet 0 167 863
assign 1 167 864
lengthGet 0 167 864
assign 1 167 865
new 0 167 865
assign 1 167 866
greater 1 167 866
assign 1 168 868
new 0 168 868
assign 1 168 869
new 2 168 869
throw 1 168 870
assign 1 171 873
containedGet 0 171 873
assign 1 171 874
firstGet 0 171 874
assign 1 172 875
typenameGet 0 172 875
assign 1 172 876
IDGet 0 172 876
assign 1 172 877
equals 1 172 877
assign 1 173 879
heldGet 0 173 879
assign 1 173 880
new 0 173 880
extendsSet 1 173 881
assign 1 174 882
heldGet 0 174 882
assign 1 174 883
extendsGet 0 174 883
assign 1 174 884
heldGet 0 174 884
addStep 1 174 885
assign 1 175 888
typenameGet 0 175 888
assign 1 175 889
NAMEPATHGet 0 175 889
assign 1 175 890
equals 1 175 890
assign 1 176 892
heldGet 0 176 892
assign 1 176 893
heldGet 0 176 893
extendsSet 1 176 894
assign 1 178 897
new 0 178 897
assign 1 178 898
new 2 178 898
throw 1 178 899
print 0 182 905
assign 1 183 906
new 0 183 906
assign 1 183 907
new 2 183 907
throw 1 183 908
delete 0 185 910
print 0 188 915
assign 1 189 916
new 0 189 916
assign 1 189 917
new 2 189 917
throw 1 189 918
assign 1 192 920
heldGet 0 192 920
assign 1 192 921
extendsGet 0 192 921
assign 1 192 922
undef 1 192 927
assign 1 192 928
heldGet 0 192 928
assign 1 192 929
namepathGet 0 192 929
assign 1 192 930
toString 0 192 930
assign 1 192 931
new 0 192 931
assign 1 192 932
notEquals 1 192 932
assign 1 0 934
assign 1 0 937
assign 1 0 941
assign 1 193 944
heldGet 0 193 944
assign 1 193 945
new 0 193 945
assign 1 193 946
new 0 193 946
assign 1 193 947
fromString 1 193 947
extendsSet 1 193 948
assign 1 196 950
nextDescendGet 0 196 950
return 1 196 951
assign 1 198 953
typenameGet 0 198 953
assign 1 198 954
METHODGet 0 198 954
assign 1 198 955
equals 1 198 960
assign 1 199 961
new 0 199 961
heldSet 1 199 962
assign 1 200 963
priorPeerGet 0 200 963
assign 1 201 964
new 0 201 964
assign 1 201 967
new 0 201 967
assign 1 201 968
lesser 1 201 973
assign 1 202 974
def 1 202 979
assign 1 203 980
typenameGet 0 203 980
assign 1 203 981
DEFMODGet 0 203 981
assign 1 203 982
equals 1 203 987
assign 1 204 988
typenameGet 0 204 988
assign 1 204 989
DEFMODGet 0 204 989
assign 1 204 990
equals 1 204 995
assign 1 204 996
heldGet 0 204 996
assign 1 204 997
new 0 204 997
assign 1 204 998
equals 1 204 998
assign 1 0 1000
assign 1 0 1003
assign 1 0 1007
assign 1 205 1010
heldGet 0 205 1010
assign 1 205 1011
new 0 205 1011
isFinalSet 1 205 1012
assign 1 206 1015
typenameGet 0 206 1015
assign 1 206 1016
DEFMODGet 0 206 1016
assign 1 206 1017
equals 1 206 1022
assign 1 206 1023
heldGet 0 206 1023
assign 1 206 1024
new 0 206 1024
assign 1 206 1025
equals 1 206 1025
assign 1 0 1027
assign 1 0 1030
assign 1 0 1034
assign 1 208 1037
new 0 208 1037
assign 1 208 1038
new 2 208 1038
throw 1 208 1039
assign 1 210 1042
priorPeerGet 0 210 1042
delete 0 211 1043
assign 1 212 1044
assign 1 214 1047
assign 1 201 1050
increment 0 201 1050
assign 1 219 1057
containedGet 0 219 1057
assign 1 219 1058
firstGet 0 219 1058
assign 1 220 1059
def 1 220 1064
assign 1 221 1065
nextPeerGet 0 221 1065
assign 1 222 1066
def 1 222 1071
assign 1 223 1072
nextPeerGet 0 223 1072
assign 1 224 1073
typenameGet 0 224 1073
assign 1 224 1074
IDGet 0 224 1074
assign 1 224 1075
equals 1 224 1075
assign 1 0 1077
assign 1 224 1080
typenameGet 0 224 1080
assign 1 224 1081
NAMEPATHGet 0 224 1081
assign 1 224 1082
equals 1 224 1082
assign 1 0 1084
assign 1 0 1087
assign 1 226 1091
typenameGet 0 226 1091
assign 1 226 1092
IDGet 0 226 1092
assign 1 226 1093
equals 1 226 1093
assign 1 227 1095
new 0 227 1095
assign 1 228 1096
heldGet 0 228 1096
addStep 1 228 1097
assign 1 230 1100
heldGet 0 230 1100
assign 1 232 1102
new 0 232 1102
assign 1 233 1103
new 0 233 1103
isTypedSet 1 233 1104
namepathSet 1 234 1105
assign 1 235 1106
VARGet 0 235 1106
typenameSet 1 235 1107
heldSet 1 236 1108
assign 1 239 1111
typenameGet 0 239 1111
assign 1 239 1112
IDGet 0 239 1112
assign 1 239 1113
equals 1 239 1113
assign 1 240 1115
heldGet 0 240 1115
assign 1 240 1116
heldGet 0 240 1116
nameSet 1 240 1117
assign 1 241 1118
heldGet 0 241 1118
assign 1 241 1119
nameGet 0 241 1119
assign 1 241 1120
new 0 241 1120
assign 1 241 1121
getPoint 1 241 1121
assign 1 241 1122
isInteger 0 241 1122
assign 1 242 1124
new 0 242 1124
assign 1 242 1125
new 2 242 1125
throw 1 242 1126
delete 0 244 1128
assign 1 246 1131
new 0 246 1131
assign 1 246 1132
new 2 246 1132
throw 1 246 1133
assign 1 249 1137
new 0 249 1137
assign 1 249 1138
new 2 249 1138
throw 1 249 1139
assign 1 252 1144
classNameGet 0 252 1144
assign 1 252 1145
new 0 252 1145
assign 1 252 1146
equals 1 252 1146
throw 1 252 1148
print 0 253 1150
assign 1 254 1151
new 0 254 1151
assign 1 254 1152
new 2 254 1152
throw 1 254 1153
assign 1 256 1155
nextDescendGet 0 256 1155
return 1 256 1156
assign 1 258 1158
constantsGet 0 258 1158
assign 1 258 1159
parensReqGet 0 258 1159
assign 1 258 1160
typenameGet 0 258 1160
assign 1 258 1161
has 1 258 1161
assign 1 259 1163
containedGet 0 259 1163
assign 1 259 1164
firstGet 0 259 1164
assign 1 260 1165
undef 1 260 1170
assign 1 0 1171
assign 1 260 1174
typenameGet 0 260 1174
assign 1 260 1175
PARENSGet 0 260 1175
assign 1 260 1176
notEquals 1 260 1176
assign 1 0 1178
assign 1 0 1181
assign 1 261 1185
new 0 261 1185
assign 1 261 1186
new 2 261 1186
throw 1 261 1187
assign 1 265 1190
typenameGet 0 265 1190
assign 1 265 1191
BRACESGet 0 265 1191
assign 1 265 1192
equals 1 265 1197
assign 1 266 1198
containerGet 0 266 1198
assign 1 267 1199
def 1 267 1204
assign 1 267 1205
typenameGet 0 267 1205
assign 1 267 1206
EXPRGet 0 267 1206
assign 1 267 1207
equals 1 267 1207
assign 1 0 1209
assign 1 0 1212
assign 1 0 1216
assign 1 268 1219
PARENSGet 0 268 1219
typenameSet 1 268 1220
assign 1 271 1223
typenameGet 0 271 1223
assign 1 271 1224
SEMIGet 0 271 1224
assign 1 271 1225
equals 1 271 1230
assign 1 272 1231
priorPeerGet 0 272 1231
assign 1 273 1232
nextAscendGet 0 273 1232
assign 1 277 1235
def 1 277 1240
assign 1 277 1241
typenameGet 0 277 1241
assign 1 277 1242
SEMIGet 0 277 1242
assign 1 277 1243
notEquals 1 277 1243
assign 1 0 1245
assign 1 0 1248
assign 1 0 1252
assign 1 277 1255
typenameGet 0 277 1255
assign 1 277 1256
BRACESGet 0 277 1256
assign 1 277 1257
notEquals 1 277 1257
assign 1 0 1259
assign 1 0 1262
assign 1 0 1266
assign 1 277 1269
typenameGet 0 277 1269
assign 1 277 1270
EXPRGet 0 277 1270
assign 1 277 1271
notEquals 1 277 1271
assign 1 0 1273
assign 1 0 1276
assign 1 0 1280
assign 1 278 1283
undef 1 278 1288
assign 1 279 1289
new 0 279 1289
prepend 1 281 1291
assign 1 282 1292
priorPeerGet 0 282 1292
assign 1 284 1298
def 1 284 1303
assign 1 285 1304
EXPRGet 0 285 1304
typenameSet 1 285 1305
heldSet 1 286 1306
assign 1 287 1307
new 1 287 1307
assign 1 288 1308
PARENSGet 0 288 1308
typenameSet 1 288 1309
addValue 1 289 1310
copyLoc 1 290 1311
assign 1 291 1312
iteratorGet 0 291 1312
assign 1 291 1315
hasNextGet 0 291 1315
assign 1 292 1317
nextGet 0 292 1317
delete 0 293 1318
addValue 1 294 1319
delete 0 301 1327
return 1 303 1329
assign 1 306 1331
nextDescendGet 0 306 1331
return 1 306 1332
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass5();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass5.bevs_inst = (BEC_3_5_5_5_BuildVisitPass5)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass5.bevs_inst;
}
}
}
