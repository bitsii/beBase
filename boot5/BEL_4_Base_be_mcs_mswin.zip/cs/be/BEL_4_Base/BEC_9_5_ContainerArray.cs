namespace be.BEL_4_Base {

using System;
    /* IO:File: source/base/Array.be */
public class BEC_9_5_ContainerArray : BEC_6_6_SystemObject {
public BEC_9_5_ContainerArray() { }
static BEC_9_5_ContainerArray() { }

   
    public BEC_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_9_5_ContainerArray(BEC_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_4_3_MathInt(bevi_array.Length);
        this.bevp_capacity = new BEC_4_3_MathInt(bevi_array.Length);
        this.bevp_multiplier = new BEC_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_4_3_MathInt bevo_7 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_8 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_10 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_11 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_12 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_13 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_14 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_4_3_MathInt bevo_15 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
public static new BEC_9_5_ContainerArray bevs_inst;
public BEC_6_6_SystemObject bevp_varray;
public BEC_4_3_MathInt bevp_length;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_multiplier;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpvar_phold, bevt_2_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_new_1(BEC_4_3_MathInt beva_leni) {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_new_2(BEC_4_3_MathInt beva_leni, BEC_4_3_MathInt beva_capi) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 142 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 144 */ {
bevt_6_tmpvar_phold = bevp_length.bem_equals_1(beva_leni);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 147 */ {
return this;
} /* Line: 148 */
} /* Line: 147 */

      bevi_array = new BEC_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevp_length.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 176 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varrayGet_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varraySet_0() {
return this;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_firstGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_put_2(BEC_4_3_MathInt beva_posi, BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = beva_posi.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 209 */
bevt_4_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevp_length);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_6_tmpvar_phold = bevo_7;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 212 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_4_3_MathInt beva_posi) {
BEC_6_6_SystemObject bevl_val = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
bevt_1_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_3_tmpvar_phold = beva_posi.bem_lesser_1(bevp_length);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 223 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 224 */
return bevl_val;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_1(BEC_4_3_MathInt beva_pos) {
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_pos.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_1_tmpvar_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 236 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 236 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_11;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 241 */
bevt_9_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_5_8_ArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_8_ArrayIterator) (new BEC_5_8_ArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_clear_0() {
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 251 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 251 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 251 */
 else  /* Line: 251 */ {
break;
} /* Line: 251 */
} /* Line: 251 */
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_9_5_ContainerArray bevl_n = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = (BEC_9_5_ContainerArray) this.bem_create_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 258 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 258 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
return bevl_n;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_create_1(BEC_4_3_MathInt beva_len) {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_create_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevp_length);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_add_1(BEC_9_5_ContainerArray beva_xi) {
BEC_9_5_ContainerArray bevl_yi = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_4_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_length.bem_add_1(bevt_4_tmpvar_phold);
bevl_yi = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 270 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 270 */ {
bevl_c = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 271 */
 else  /* Line: 270 */ {
break;
} /* Line: 270 */
} /* Line: 270 */
bevt_1_tmpvar_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 273 */ {
bevt_6_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 273 */ {
bevl_c = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 274 */
 else  /* Line: 273 */ {
break;
} /* Line: 273 */
} /* Line: 273 */
return (BEC_9_5_ContainerArray) bevl_yi;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sort_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) this.bem_mergeSort_0();
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sortInPlace_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_sortInPlace_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sortInPlace_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_6_6_SystemObject bevl_hold = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 288 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(beva_end);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 288 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 290 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(beva_end);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 291 */ {
bevl_c = bevl_j;
} /* Line: 292 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 290 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 288 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeIn_2(BEC_9_5_ContainerArray beva_first, BEC_9_5_ContainerArray beva_second) {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_fi = null;
BEC_4_3_MathInt bevl_si = null;
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_6_6_SystemObject bevl_fo = null;
BEC_6_6_SystemObject bevl_so = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_fi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_si = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 307 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevt_2_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_3_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 308 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 308 */
 else  /* Line: 308 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 308 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 311 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 316 */
} /* Line: 311 */
 else  /* Line: 308 */ {
bevt_5_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 318 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 321 */
 else  /* Line: 308 */ {
bevt_6_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 325 */
} /* Line: 308 */
} /* Line: 308 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 327 */
 else  /* Line: 307 */ {
break;
} /* Line: 307 */
} /* Line: 307 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeSort_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeSort_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_4_3_MathInt bevl_mlen = null;
BEC_9_5_ContainerArray bevl_ra = null;
BEC_4_3_MathInt bevl_shalf = null;
BEC_4_3_MathInt bevl_fhalf = null;
BEC_4_3_MathInt bevl_fend = null;
BEC_9_5_ContainerArray bevl_fa = null;
BEC_9_5_ContainerArray bevl_sa = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_12;
bevt_0_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 337 */ {
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 338 */
 else  /* Line: 337 */ {
bevt_5_tmpvar_phold = bevo_13;
bevt_4_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 339 */ {
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 342 */
 else  /* Line: 343 */ {
bevt_9_tmpvar_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 351 */
} /* Line: 337 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_capacitySet_1(BEC_4_3_MathInt beva_newcap) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_9_SystemException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_2));
bevt_1_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 357 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lengthSet_1(BEC_4_3_MathInt beva_newlen) {
BEC_4_3_MathInt bevl_newcap = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_newlen.bem_greater_1(bevp_capacity);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_array, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 380 */
while (true)
 /* Line: 383 */ {
bevt_1_tmpvar_phold = bevp_length.bem_lesser_1(beva_newlen);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 383 */ {

         this.bevi_array[this.bevp_length.bevi_int] = null;
         bevp_length.bem_incrementValue_0();
} /* Line: 389 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
bevp_length.bem_setValue_1(beva_newlen);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_iterateAdd_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 395 */ {
while (true)
 /* Line: 396 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 396 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 397 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
} /* Line: 396 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addAll_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 404 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addValueWhole_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_lesser_1(bevp_capacity);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 409 */ {

       this.bevi_array[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bem_incrementValue_0();
} /* Line: 415 */
 else  /* Line: 416 */ {
bevt_1_tmpvar_phold = bevp_length.bem_copy_0();
this.bem_put_2((BEC_4_3_MathInt) bevt_1_tmpvar_phold, beva_val);
} /* Line: 418 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addValue_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 423 */
 else  /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 423 */ {
this.bem_addAll_1(beva_val);
} /* Line: 424 */
 else  /* Line: 425 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 426 */
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_find_1(BEC_6_6_SystemObject beva_value) {
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 432 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 432 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 434 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 434 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 434 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 434 */
 else  /* Line: 434 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 434 */ {
return bevl_i;
} /* Line: 435 */
bevl_i.bem_incrementValue_0();
} /* Line: 432 */
 else  /* Line: 432 */ {
break;
} /* Line: 432 */
} /* Line: 432 */
return null;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_value) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 443 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sortedFind_1(BEC_6_6_SystemObject beva_value) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sortedFind_2(BEC_6_6_SystemObject beva_value, BEC_5_4_LogicBool beva_returnNoMatch) {
BEC_4_3_MathInt bevl_high = null;
BEC_4_3_MathInt bevl_low = null;
BEC_4_3_MathInt bevl_lastMid = null;
BEC_4_3_MathInt bevl_mid = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 462 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_15;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 465 */ {
return bevl_mid;
} /* Line: 466 */
 else  /* Line: 465 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 467 */ {
bevl_low = bevl_mid;
} /* Line: 469 */
 else  /* Line: 465 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 470 */ {
bevl_high = bevl_mid;
} /* Line: 472 */
} /* Line: 465 */
} /* Line: 465 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 475 */ {
bevt_9_tmpvar_phold = bevl_lastMid.bem_equals_1(bevl_mid);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 475 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 475 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 475 */
 else  /* Line: 475 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 475 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 476 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 476 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 476 */
 else  /* Line: 476 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 476 */ {
return bevl_low;
} /* Line: 477 */
return null;
} /* Line: 479 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 482 */ {
return null;
} /* Line: 483 */
} /* Line: 482 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varraySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_varray = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_multiplierSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multiplier = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {133, 133, 133, 133, 133, 137, 141, 141, 0, 141, 141, 0, 0, 142, 142, 142, 144, 144, 147, 148, 164, 165, 166, 171, 175, 175, 176, 176, 178, 178, 188, 188, 192, 192, 196, 196, 200, 200, 200, 204, 204, 204, 204, 208, 208, 209, 209, 209, 211, 212, 212, 212, 223, 223, 223, 0, 0, 0, 230, 234, 235, 235, 236, 236, 237, 237, 237, 237, 236, 239, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 252, 251, 257, 258, 258, 259, 259, 258, 261, 264, 264, 266, 266, 269, 269, 269, 269, 270, 0, 270, 270, 271, 273, 0, 273, 273, 274, 276, 280, 280, 284, 284, 288, 288, 289, 290, 290, 291, 291, 291, 292, 290, 295, 296, 296, 297, 288, 302, 303, 304, 305, 306, 307, 308, 308, 0, 0, 0, 309, 310, 311, 312, 313, 315, 316, 318, 319, 320, 321, 322, 323, 324, 325, 327, 332, 332, 332, 336, 337, 337, 338, 338, 338, 339, 339, 340, 340, 341, 341, 341, 342, 344, 344, 345, 346, 347, 348, 349, 350, 351, 356, 357, 357, 357, 363, 364, 380, 383, 389, 391, 395, 395, 396, 397, 397, 403, 403, 404, 404, 409, 415, 418, 418, 423, 423, 423, 0, 0, 0, 424, 426, 432, 432, 433, 434, 434, 434, 0, 0, 0, 435, 432, 438, 442, 442, 442, 443, 443, 445, 445, 451, 451, 451, 458, 459, 463, 463, 463, 463, 464, 465, 466, 467, 469, 470, 472, 475, 475, 475, 0, 0, 0, 476, 476, 0, 0, 0, 477, 479, 481, 482, 483, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {52, 53, 54, 55, 56, 60, 71, 76, 77, 80, 85, 86, 89, 93, 94, 95, 97, 102, 103, 105, 110, 111, 112, 116, 123, 124, 126, 127, 129, 130, 140, 141, 145, 146, 151, 152, 157, 158, 159, 165, 166, 167, 168, 178, 179, 181, 182, 183, 185, 187, 188, 189, 201, 202, 204, 206, 209, 213, 219, 234, 236, 237, 238, 241, 243, 244, 245, 246, 247, 253, 254, 255, 256, 257, 258, 260, 261, 265, 266, 271, 274, 276, 277, 290, 291, 294, 296, 297, 298, 304, 308, 309, 313, 314, 326, 327, 328, 329, 330, 330, 333, 335, 336, 342, 342, 345, 347, 348, 354, 358, 359, 363, 364, 378, 381, 383, 384, 387, 389, 390, 391, 393, 395, 401, 402, 403, 404, 405, 428, 429, 430, 431, 432, 435, 437, 439, 441, 444, 448, 451, 452, 453, 455, 456, 459, 460, 464, 466, 467, 468, 471, 473, 474, 475, 479, 490, 491, 492, 512, 513, 514, 516, 517, 518, 521, 522, 524, 525, 526, 527, 528, 529, 532, 533, 534, 535, 536, 537, 538, 539, 540, 548, 550, 551, 552, 560, 562, 565, 569, 573, 579, 586, 591, 594, 596, 597, 609, 614, 615, 616, 623, 627, 630, 631, 639, 644, 645, 647, 650, 654, 657, 660, 671, 674, 676, 677, 682, 683, 685, 688, 692, 695, 697, 703, 710, 711, 716, 717, 718, 720, 721, 726, 727, 728, 749, 750, 753, 754, 755, 756, 757, 758, 760, 763, 765, 768, 770, 774, 779, 780, 782, 785, 789, 793, 794, 796, 799, 803, 806, 808, 810, 811, 813, 818, 822, 825, 828, 831};
/* BEGIN LINEINFO 
assign 1 133 52
new 0 133 52
assign 1 133 53
once 0 133 53
assign 1 133 54
new 0 133 54
assign 1 133 55
once 0 133 55
new 2 133 56
new 2 137 60
assign 1 141 71
undef 1 141 76
assign 1 0 77
assign 1 141 80
undef 1 141 85
assign 1 0 86
assign 1 0 89
assign 1 142 93
new 0 142 93
assign 1 142 94
new 1 142 94
throw 1 142 95
assign 1 144 97
def 1 144 102
assign 1 147 103
equals 1 147 103
return 1 148 105
assign 1 164 110
copy 0 164 110
assign 1 165 111
copy 0 165 111
assign 1 166 112
new 0 166 112
return 1 171 116
assign 1 175 123
new 0 175 123
assign 1 175 124
equals 1 175 124
assign 1 176 126
new 0 176 126
return 1 176 127
assign 1 178 129
new 0 178 129
return 1 178 130
assign 1 188 140
toString 0 188 140
return 1 188 141
assign 1 192 145
new 1 192 145
new 1 192 146
assign 1 196 151
iteratorGet 0 196 151
return 1 196 152
assign 1 200 157
new 0 200 157
assign 1 200 158
get 1 200 158
return 1 200 159
assign 1 204 165
new 0 204 165
assign 1 204 166
subtract 1 204 166
assign 1 204 167
get 1 204 167
return 1 204 168
assign 1 208 178
new 0 208 178
assign 1 208 179
lesser 1 208 179
assign 1 209 181
new 0 209 181
assign 1 209 182
new 1 209 182
throw 1 209 183
assign 1 211 185
greaterEquals 1 211 185
assign 1 212 187
new 0 212 187
assign 1 212 188
add 1 212 188
lengthSet 1 212 189
assign 1 223 201
new 0 223 201
assign 1 223 202
greaterEquals 1 223 202
assign 1 223 204
lesser 1 223 204
assign 1 0 206
assign 1 0 209
assign 1 0 213
return 1 230 219
assign 1 234 234
lesser 1 234 234
assign 1 235 236
new 0 235 236
assign 1 235 237
subtract 1 235 237
assign 1 236 238
assign 1 236 241
lesser 1 236 241
assign 1 237 243
new 0 237 243
assign 1 237 244
add 1 237 244
assign 1 237 245
get 1 237 245
put 2 237 246
assign 1 236 247
increment 0 236 247
put 2 239 253
assign 1 240 254
new 0 240 254
assign 1 240 255
subtract 1 240 255
lengthSet 1 240 256
assign 1 241 257
new 0 241 257
return 1 241 258
assign 1 243 260
new 0 243 260
return 1 243 261
assign 1 247 265
new 1 247 265
return 1 247 266
assign 1 251 271
new 0 251 271
assign 1 251 274
lesser 1 251 274
put 2 252 276
assign 1 251 277
increment 0 251 277
assign 1 257 290
create 0 257 290
assign 1 258 291
new 0 258 291
assign 1 258 294
lesser 1 258 294
assign 1 259 296
get 1 259 296
put 2 259 297
assign 1 258 298
increment 0 258 298
return 1 261 304
assign 1 264 308
new 1 264 308
return 1 264 309
assign 1 266 313
new 1 266 313
return 1 266 314
assign 1 269 326
new 0 269 326
assign 1 269 327
lengthGet 0 269 327
assign 1 269 328
add 1 269 328
assign 1 269 329
new 2 269 329
assign 1 270 330
iteratorGet 0 0 330
assign 1 270 333
hasNextGet 0 270 333
assign 1 270 335
nextGet 0 270 335
addValueWhole 1 271 336
assign 1 273 342
iteratorGet 0 0 342
assign 1 273 345
hasNextGet 0 273 345
assign 1 273 347
nextGet 0 273 347
addValueWhole 1 274 348
return 1 276 354
assign 1 280 358
mergeSort 0 280 358
return 1 280 359
assign 1 284 363
new 0 284 363
sortInPlace 2 284 364
assign 1 288 378
assign 1 288 381
lesser 1 288 381
assign 1 289 383
assign 1 290 384
assign 1 290 387
lesser 1 290 387
assign 1 291 389
get 1 291 389
assign 1 291 390
get 1 291 390
assign 1 291 391
lesser 1 291 391
assign 1 292 393
assign 1 290 395
increment 0 290 395
assign 1 295 401
get 1 295 401
assign 1 296 402
get 1 296 402
put 2 296 403
put 2 297 404
assign 1 288 405
increment 0 288 405
assign 1 302 428
new 0 302 428
assign 1 303 429
new 0 303 429
assign 1 304 430
new 0 304 430
assign 1 305 431
lengthGet 0 305 431
assign 1 306 432
lengthGet 0 306 432
assign 1 307 435
lesser 1 307 435
assign 1 308 437
lesser 1 308 437
assign 1 308 439
lesser 1 308 439
assign 1 0 441
assign 1 0 444
assign 1 0 448
assign 1 309 451
get 1 309 451
assign 1 310 452
get 1 310 452
assign 1 311 453
lesser 1 311 453
assign 1 312 455
increment 0 312 455
put 2 313 456
assign 1 315 459
increment 0 315 459
put 2 316 460
assign 1 318 464
lesser 1 318 464
assign 1 319 466
get 1 319 466
assign 1 320 467
increment 0 320 467
put 2 321 468
assign 1 322 471
lesser 1 322 471
assign 1 323 473
get 1 323 473
assign 1 324 474
increment 0 324 474
put 2 325 475
assign 1 327 479
increment 0 327 479
assign 1 332 490
new 0 332 490
assign 1 332 491
mergeSort 2 332 491
return 1 332 492
assign 1 336 512
subtract 1 336 512
assign 1 337 513
new 0 337 513
assign 1 337 514
equals 1 337 514
assign 1 338 516
new 0 338 516
assign 1 338 517
create 1 338 517
return 1 338 518
assign 1 339 521
new 0 339 521
assign 1 339 522
equals 1 339 522
assign 1 340 524
new 0 340 524
assign 1 340 525
create 1 340 525
assign 1 341 526
new 0 341 526
assign 1 341 527
get 1 341 527
put 2 341 528
return 1 342 529
assign 1 344 532
new 0 344 532
assign 1 344 533
divide 1 344 533
assign 1 345 534
subtract 1 345 534
assign 1 346 535
add 1 346 535
assign 1 347 536
mergeSort 2 347 536
assign 1 348 537
mergeSort 2 348 537
assign 1 349 538
create 1 349 538
mergeIn 2 350 539
return 1 351 540
assign 1 356 548
new 0 356 548
assign 1 357 550
new 0 357 550
assign 1 357 551
new 1 357 551
throw 1 357 552
assign 1 363 560
greater 1 363 560
assign 1 364 562
multiply 1 364 562
assign 1 380 565
assign 1 383 569
lesser 1 383 569
incrementValue 0 389 573
setValue 1 391 579
assign 1 395 586
def 1 395 591
assign 1 396 594
hasNextGet 0 396 594
assign 1 397 596
nextGet 0 397 596
addValueWhole 1 397 597
assign 1 403 609
def 1 403 614
assign 1 404 615
iteratorGet 0 404 615
iterateAdd 1 404 616
assign 1 409 623
lesser 1 409 623
incrementValue 0 415 627
assign 1 418 630
copy 0 418 630
put 2 418 631
assign 1 423 639
def 1 423 644
assign 1 423 645
sameType 1 423 645
assign 1 0 647
assign 1 0 650
assign 1 0 654
addAll 1 424 657
addValueWhole 1 426 660
assign 1 432 671
new 0 432 671
assign 1 432 674
lesser 1 432 674
assign 1 433 676
get 1 433 676
assign 1 434 677
def 1 434 682
assign 1 434 683
equals 1 434 683
assign 1 0 685
assign 1 0 688
assign 1 0 692
return 1 435 695
incrementValue 0 432 697
return 1 438 703
assign 1 442 710
find 1 442 710
assign 1 442 711
def 1 442 716
assign 1 443 717
new 0 443 717
return 1 443 718
assign 1 445 720
new 0 445 720
return 1 445 721
assign 1 451 726
new 0 451 726
assign 1 451 727
sortedFind 2 451 727
return 1 451 728
assign 1 458 749
assign 1 459 750
new 0 459 750
assign 1 463 753
subtract 1 463 753
assign 1 463 754
new 0 463 754
assign 1 463 755
divide 1 463 755
assign 1 463 756
add 1 463 756
assign 1 464 757
get 1 464 757
assign 1 465 758
equals 1 465 758
return 1 466 760
assign 1 467 763
greater 1 467 763
assign 1 469 765
assign 1 470 768
lesser 1 470 768
assign 1 472 770
assign 1 475 774
def 1 475 779
assign 1 475 780
equals 1 475 780
assign 1 0 782
assign 1 0 785
assign 1 0 789
assign 1 476 793
get 1 476 793
assign 1 476 794
lesser 1 476 794
assign 1 0 796
assign 1 0 799
assign 1 0 803
return 1 477 806
return 1 479 808
assign 1 481 810
assign 1 482 811
new 0 482 811
return 1 483 813
assign 1 0 818
return 1 0 822
return 1 0 825
return 1 0 828
assign 1 0 831
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case 729571811: return bem_serializeToString_0();
case 1473032100: return bem_varrayGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1479417926: return bem_multiplierGet_0();
case 188061735: return bem_mergeSort_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1484114352: return bem_varraySet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1442201067: return bem_sortInPlace_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case 786424307: return bem_tagGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1484114353: return bem_varraySet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_4_3_MathInt) bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_5_ContainerArray) bevd_0);
case 228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1442201065: return bem_sortInPlace_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_9_5_ContainerArray();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_9_5_ContainerArray.bevs_inst = (BEC_9_5_ContainerArray)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_9_5_ContainerArray.bevs_inst;
}
}
}
