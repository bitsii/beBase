namespace be.BEL_4_Base {

using System;
    /* IO:File: source/base/Array.be */
public class BEC_9_5_ContainerArray : BEC_6_6_SystemObject {
public BEC_9_5_ContainerArray() { }
static BEC_9_5_ContainerArray() { }

   
    public BEC_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_9_5_ContainerArray(BEC_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_4_3_MathInt(bevi_array.Length);
        this.bevp_capacity = new BEC_4_3_MathInt(bevi_array.Length);
        this.bevp_multiplier = new BEC_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_4_3_MathInt bevo_7 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_8 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_10 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_11 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_12 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_13 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_14 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_4_3_MathInt bevo_15 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
public static new BEC_9_5_ContainerArray bevs_inst;
public BEC_6_6_SystemObject bevp_varray;
public BEC_4_3_MathInt bevp_length;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_multiplier;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpvar_phold, bevt_2_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_new_1(BEC_4_3_MathInt beva_leni) {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_new_2(BEC_4_3_MathInt beva_leni, BEC_4_3_MathInt beva_capi) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 142 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 144 */ {
bevt_6_tmpvar_phold = bevp_length.bem_equals_1(beva_leni);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 147 */ {
return this;
} /* Line: 148 */
} /* Line: 147 */

      bevi_array = new BEC_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevp_length.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 176 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varrayGet_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varraySet_0() {
return this;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_firstGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_put_2(BEC_4_3_MathInt beva_posi, BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = beva_posi.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 209 */
bevt_4_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevp_length);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_6_tmpvar_phold = bevo_7;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 212 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_4_3_MathInt beva_posi) {
BEC_6_6_SystemObject bevl_val = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
bevt_1_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_3_tmpvar_phold = beva_posi.bem_lesser_1(bevp_length);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 223 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 224 */
return bevl_val;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_1(BEC_4_3_MathInt beva_pos) {
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_pos.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_1_tmpvar_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 236 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 236 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_11;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 241 */
bevt_9_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_8_ContainerArrayIterator) (new BEC_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_8_ContainerArrayIterator bem_arrayIteratorGet_0() {
BEC_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_8_ContainerArrayIterator) (new BEC_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_clear_0() {
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 255 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 255 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 255 */
 else  /* Line: 255 */ {
break;
} /* Line: 255 */
} /* Line: 255 */
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_9_5_ContainerArray bevl_n = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = (BEC_9_5_ContainerArray) this.bem_create_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 262 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 262 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
return (BEC_6_6_SystemObject) bevl_n;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_create_1(BEC_4_3_MathInt beva_len) {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_create_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevp_length);
return (BEC_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_add_1(BEC_9_5_ContainerArray beva_xi) {
BEC_9_5_ContainerArray bevl_yi = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_9_5_8_ContainerArrayIterator bevt_1_tmpvar_loop = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_4_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_length.bem_add_1(bevt_4_tmpvar_phold);
bevl_yi = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_loop = this.bem_arrayIteratorGet_0();
while (true)
 /* Line: 274 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 274 */ {
bevl_c = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 275 */
 else  /* Line: 274 */ {
break;
} /* Line: 274 */
} /* Line: 274 */
bevt_1_tmpvar_loop = beva_xi.bem_arrayIteratorGet_0();
while (true)
 /* Line: 277 */ {
bevt_6_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevl_c = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 278 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
return (BEC_9_5_ContainerArray) bevl_yi;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sort_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) this.bem_mergeSort_0();
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sortValue_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sortValue_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_6_6_SystemObject bevl_hold = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 292 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(beva_end);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 294 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(beva_end);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 295 */ {
bevl_c = bevl_j;
} /* Line: 296 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 294 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 292 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeIn_2(BEC_9_5_ContainerArray beva_first, BEC_9_5_ContainerArray beva_second) {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_fi = null;
BEC_4_3_MathInt bevl_si = null;
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_6_6_SystemObject bevl_fo = null;
BEC_6_6_SystemObject bevl_so = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_fi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_si = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 311 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevt_2_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 312 */ {
bevt_3_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 312 */
 else  /* Line: 312 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 312 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 315 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 317 */
 else  /* Line: 318 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 320 */
} /* Line: 315 */
 else  /* Line: 312 */ {
bevt_5_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 325 */
 else  /* Line: 312 */ {
bevt_6_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 329 */
} /* Line: 312 */
} /* Line: 312 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 331 */
 else  /* Line: 311 */ {
break;
} /* Line: 311 */
} /* Line: 311 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeSort_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeSort_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_4_3_MathInt bevl_mlen = null;
BEC_9_5_ContainerArray bevl_ra = null;
BEC_4_3_MathInt bevl_shalf = null;
BEC_4_3_MathInt bevl_fhalf = null;
BEC_4_3_MathInt bevl_fend = null;
BEC_9_5_ContainerArray bevl_fa = null;
BEC_9_5_ContainerArray bevl_sa = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_12;
bevt_0_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 341 */ {
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 342 */
 else  /* Line: 341 */ {
bevt_5_tmpvar_phold = bevo_13;
bevt_4_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 343 */ {
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 346 */
 else  /* Line: 347 */ {
bevt_9_tmpvar_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 355 */
} /* Line: 341 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_capacitySet_1(BEC_4_3_MathInt beva_newcap) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_9_SystemException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 360 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_2));
bevt_1_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 361 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lengthSet_1(BEC_4_3_MathInt beva_newlen) {
BEC_4_3_MathInt bevl_newcap = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_newlen.bem_greater_1(bevp_capacity);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_array, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 384 */
while (true)
 /* Line: 387 */ {
bevt_1_tmpvar_phold = bevp_length.bem_lesser_1(beva_newlen);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 387 */ {

         this.bevi_array[this.bevp_length.bevi_int] = null;
         bevp_length.bem_incrementValue_0();
} /* Line: 393 */
 else  /* Line: 387 */ {
break;
} /* Line: 387 */
} /* Line: 387 */
bevp_length.bem_setValue_1(beva_newlen);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_iterateAdd_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 399 */ {
while (true)
 /* Line: 400 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
} /* Line: 400 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addAll_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 408 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addValueWhole_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_lesser_1(bevp_capacity);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 413 */ {

       this.bevi_array[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bem_incrementValue_0();
} /* Line: 419 */
 else  /* Line: 420 */ {
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) bevp_length.bem_copy_0();
this.bem_put_2(bevt_1_tmpvar_phold, beva_val);
} /* Line: 422 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addValue_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 427 */
 else  /* Line: 427 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 427 */ {
this.bem_addAll_1(beva_val);
} /* Line: 428 */
 else  /* Line: 429 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 430 */
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_find_1(BEC_6_6_SystemObject beva_value) {
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 436 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 438 */
 else  /* Line: 438 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 438 */ {
return bevl_i;
} /* Line: 439 */
bevl_i.bem_incrementValue_0();
} /* Line: 436 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
return null;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_value) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 447 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sortedFind_1(BEC_6_6_SystemObject beva_value) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sortedFind_2(BEC_6_6_SystemObject beva_value, BEC_5_4_LogicBool beva_returnNoMatch) {
BEC_4_3_MathInt bevl_high = null;
BEC_4_3_MathInt bevl_low = null;
BEC_4_3_MathInt bevl_lastMid = null;
BEC_4_3_MathInt bevl_mid = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 466 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_15;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 469 */ {
return bevl_mid;
} /* Line: 470 */
 else  /* Line: 469 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 471 */ {
bevl_low = bevl_mid;
} /* Line: 473 */
 else  /* Line: 469 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 474 */ {
bevl_high = bevl_mid;
} /* Line: 476 */
} /* Line: 469 */
} /* Line: 469 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_9_tmpvar_phold = bevl_lastMid.bem_equals_1(bevl_mid);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 479 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 480 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 480 */
 else  /* Line: 480 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 480 */ {
return bevl_low;
} /* Line: 481 */
return null;
} /* Line: 483 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 486 */ {
return null;
} /* Line: 487 */
} /* Line: 486 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varraySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_varray = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_multiplierSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multiplier = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {133, 133, 133, 133, 133, 137, 141, 141, 0, 141, 141, 0, 0, 142, 142, 142, 144, 144, 147, 148, 164, 165, 166, 171, 175, 175, 176, 176, 178, 178, 188, 188, 192, 192, 196, 196, 200, 200, 200, 204, 204, 204, 204, 208, 208, 209, 209, 209, 211, 212, 212, 212, 223, 223, 223, 0, 0, 0, 230, 234, 235, 235, 236, 236, 237, 237, 237, 237, 236, 239, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 255, 255, 256, 255, 261, 262, 262, 263, 263, 262, 265, 268, 268, 270, 270, 273, 273, 273, 273, 274, 0, 274, 274, 275, 277, 0, 277, 277, 278, 280, 284, 284, 288, 288, 292, 292, 293, 294, 294, 295, 295, 295, 296, 294, 299, 300, 300, 301, 292, 306, 307, 308, 309, 310, 311, 312, 312, 0, 0, 0, 313, 314, 315, 316, 317, 319, 320, 322, 323, 324, 325, 326, 327, 328, 329, 331, 336, 336, 336, 340, 341, 341, 342, 342, 342, 343, 343, 344, 344, 345, 345, 345, 346, 348, 348, 349, 350, 351, 352, 353, 354, 355, 360, 361, 361, 361, 367, 368, 384, 387, 393, 395, 399, 399, 400, 401, 401, 407, 407, 408, 408, 413, 419, 422, 422, 427, 427, 427, 0, 0, 0, 428, 430, 436, 436, 437, 438, 438, 438, 0, 0, 0, 439, 436, 442, 446, 446, 446, 447, 447, 449, 449, 455, 455, 455, 462, 463, 467, 467, 467, 467, 468, 469, 470, 471, 473, 474, 476, 479, 479, 479, 0, 0, 0, 480, 480, 0, 0, 0, 481, 483, 485, 486, 487, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {52, 53, 54, 55, 56, 60, 71, 76, 77, 80, 85, 86, 89, 93, 94, 95, 97, 102, 103, 105, 110, 111, 112, 116, 123, 124, 126, 127, 129, 130, 140, 141, 145, 146, 151, 152, 157, 158, 159, 165, 166, 167, 168, 178, 179, 181, 182, 183, 185, 187, 188, 189, 201, 202, 204, 206, 209, 213, 219, 234, 236, 237, 238, 241, 243, 244, 245, 246, 247, 253, 254, 255, 256, 257, 258, 260, 261, 265, 266, 270, 271, 276, 279, 281, 282, 295, 296, 299, 301, 302, 303, 309, 313, 314, 318, 319, 331, 332, 333, 334, 335, 335, 338, 340, 341, 347, 347, 350, 352, 353, 359, 363, 364, 368, 369, 383, 386, 388, 389, 392, 394, 395, 396, 398, 400, 406, 407, 408, 409, 410, 433, 434, 435, 436, 437, 440, 442, 444, 446, 449, 453, 456, 457, 458, 460, 461, 464, 465, 469, 471, 472, 473, 476, 478, 479, 480, 484, 495, 496, 497, 517, 518, 519, 521, 522, 523, 526, 527, 529, 530, 531, 532, 533, 534, 537, 538, 539, 540, 541, 542, 543, 544, 545, 553, 555, 556, 557, 565, 567, 570, 574, 578, 584, 591, 596, 599, 601, 602, 614, 619, 620, 621, 628, 632, 635, 636, 644, 649, 650, 652, 655, 659, 662, 665, 676, 679, 681, 682, 687, 688, 690, 693, 697, 700, 702, 708, 715, 716, 721, 722, 723, 725, 726, 731, 732, 733, 754, 755, 758, 759, 760, 761, 762, 763, 765, 768, 770, 773, 775, 779, 784, 785, 787, 790, 794, 798, 799, 801, 804, 808, 811, 813, 815, 816, 818, 823, 827, 830, 833, 836};
/* BEGIN LINEINFO 
assign 1 133 52
new 0 133 52
assign 1 133 53
once 0 133 53
assign 1 133 54
new 0 133 54
assign 1 133 55
once 0 133 55
new 2 133 56
new 2 137 60
assign 1 141 71
undef 1 141 76
assign 1 0 77
assign 1 141 80
undef 1 141 85
assign 1 0 86
assign 1 0 89
assign 1 142 93
new 0 142 93
assign 1 142 94
new 1 142 94
throw 1 142 95
assign 1 144 97
def 1 144 102
assign 1 147 103
equals 1 147 103
return 1 148 105
assign 1 164 110
copy 0 164 110
assign 1 165 111
copy 0 165 111
assign 1 166 112
new 0 166 112
return 1 171 116
assign 1 175 123
new 0 175 123
assign 1 175 124
equals 1 175 124
assign 1 176 126
new 0 176 126
return 1 176 127
assign 1 178 129
new 0 178 129
return 1 178 130
assign 1 188 140
toString 0 188 140
return 1 188 141
assign 1 192 145
new 1 192 145
new 1 192 146
assign 1 196 151
iteratorGet 0 196 151
return 1 196 152
assign 1 200 157
new 0 200 157
assign 1 200 158
get 1 200 158
return 1 200 159
assign 1 204 165
new 0 204 165
assign 1 204 166
subtract 1 204 166
assign 1 204 167
get 1 204 167
return 1 204 168
assign 1 208 178
new 0 208 178
assign 1 208 179
lesser 1 208 179
assign 1 209 181
new 0 209 181
assign 1 209 182
new 1 209 182
throw 1 209 183
assign 1 211 185
greaterEquals 1 211 185
assign 1 212 187
new 0 212 187
assign 1 212 188
add 1 212 188
lengthSet 1 212 189
assign 1 223 201
new 0 223 201
assign 1 223 202
greaterEquals 1 223 202
assign 1 223 204
lesser 1 223 204
assign 1 0 206
assign 1 0 209
assign 1 0 213
return 1 230 219
assign 1 234 234
lesser 1 234 234
assign 1 235 236
new 0 235 236
assign 1 235 237
subtract 1 235 237
assign 1 236 238
assign 1 236 241
lesser 1 236 241
assign 1 237 243
new 0 237 243
assign 1 237 244
add 1 237 244
assign 1 237 245
get 1 237 245
put 2 237 246
assign 1 236 247
increment 0 236 247
put 2 239 253
assign 1 240 254
new 0 240 254
assign 1 240 255
subtract 1 240 255
lengthSet 1 240 256
assign 1 241 257
new 0 241 257
return 1 241 258
assign 1 243 260
new 0 243 260
return 1 243 261
assign 1 247 265
new 1 247 265
return 1 247 266
assign 1 251 270
new 1 251 270
return 1 251 271
assign 1 255 276
new 0 255 276
assign 1 255 279
lesser 1 255 279
put 2 256 281
assign 1 255 282
increment 0 255 282
assign 1 261 295
create 0 261 295
assign 1 262 296
new 0 262 296
assign 1 262 299
lesser 1 262 299
assign 1 263 301
get 1 263 301
put 2 263 302
assign 1 262 303
increment 0 262 303
return 1 265 309
assign 1 268 313
new 1 268 313
return 1 268 314
assign 1 270 318
new 1 270 318
return 1 270 319
assign 1 273 331
new 0 273 331
assign 1 273 332
lengthGet 0 273 332
assign 1 273 333
add 1 273 333
assign 1 273 334
new 2 273 334
assign 1 274 335
arrayIteratorGet 0 0 335
assign 1 274 338
hasNextGet 0 274 338
assign 1 274 340
nextGet 0 274 340
addValueWhole 1 275 341
assign 1 277 347
arrayIteratorGet 0 0 347
assign 1 277 350
hasNextGet 0 277 350
assign 1 277 352
nextGet 0 277 352
addValueWhole 1 278 353
return 1 280 359
assign 1 284 363
mergeSort 0 284 363
return 1 284 364
assign 1 288 368
new 0 288 368
sortValue 2 288 369
assign 1 292 383
assign 1 292 386
lesser 1 292 386
assign 1 293 388
assign 1 294 389
assign 1 294 392
lesser 1 294 392
assign 1 295 394
get 1 295 394
assign 1 295 395
get 1 295 395
assign 1 295 396
lesser 1 295 396
assign 1 296 398
assign 1 294 400
increment 0 294 400
assign 1 299 406
get 1 299 406
assign 1 300 407
get 1 300 407
put 2 300 408
put 2 301 409
assign 1 292 410
increment 0 292 410
assign 1 306 433
new 0 306 433
assign 1 307 434
new 0 307 434
assign 1 308 435
new 0 308 435
assign 1 309 436
lengthGet 0 309 436
assign 1 310 437
lengthGet 0 310 437
assign 1 311 440
lesser 1 311 440
assign 1 312 442
lesser 1 312 442
assign 1 312 444
lesser 1 312 444
assign 1 0 446
assign 1 0 449
assign 1 0 453
assign 1 313 456
get 1 313 456
assign 1 314 457
get 1 314 457
assign 1 315 458
lesser 1 315 458
assign 1 316 460
increment 0 316 460
put 2 317 461
assign 1 319 464
increment 0 319 464
put 2 320 465
assign 1 322 469
lesser 1 322 469
assign 1 323 471
get 1 323 471
assign 1 324 472
increment 0 324 472
put 2 325 473
assign 1 326 476
lesser 1 326 476
assign 1 327 478
get 1 327 478
assign 1 328 479
increment 0 328 479
put 2 329 480
assign 1 331 484
increment 0 331 484
assign 1 336 495
new 0 336 495
assign 1 336 496
mergeSort 2 336 496
return 1 336 497
assign 1 340 517
subtract 1 340 517
assign 1 341 518
new 0 341 518
assign 1 341 519
equals 1 341 519
assign 1 342 521
new 0 342 521
assign 1 342 522
create 1 342 522
return 1 342 523
assign 1 343 526
new 0 343 526
assign 1 343 527
equals 1 343 527
assign 1 344 529
new 0 344 529
assign 1 344 530
create 1 344 530
assign 1 345 531
new 0 345 531
assign 1 345 532
get 1 345 532
put 2 345 533
return 1 346 534
assign 1 348 537
new 0 348 537
assign 1 348 538
divide 1 348 538
assign 1 349 539
subtract 1 349 539
assign 1 350 540
add 1 350 540
assign 1 351 541
mergeSort 2 351 541
assign 1 352 542
mergeSort 2 352 542
assign 1 353 543
create 1 353 543
mergeIn 2 354 544
return 1 355 545
assign 1 360 553
new 0 360 553
assign 1 361 555
new 0 361 555
assign 1 361 556
new 1 361 556
throw 1 361 557
assign 1 367 565
greater 1 367 565
assign 1 368 567
multiply 1 368 567
assign 1 384 570
assign 1 387 574
lesser 1 387 574
incrementValue 0 393 578
setValue 1 395 584
assign 1 399 591
def 1 399 596
assign 1 400 599
hasNextGet 0 400 599
assign 1 401 601
nextGet 0 401 601
addValueWhole 1 401 602
assign 1 407 614
def 1 407 619
assign 1 408 620
iteratorGet 0 408 620
iterateAdd 1 408 621
assign 1 413 628
lesser 1 413 628
incrementValue 0 419 632
assign 1 422 635
copy 0 422 635
put 2 422 636
assign 1 427 644
def 1 427 649
assign 1 427 650
sameType 1 427 650
assign 1 0 652
assign 1 0 655
assign 1 0 659
addAll 1 428 662
addValueWhole 1 430 665
assign 1 436 676
new 0 436 676
assign 1 436 679
lesser 1 436 679
assign 1 437 681
get 1 437 681
assign 1 438 682
def 1 438 687
assign 1 438 688
equals 1 438 688
assign 1 0 690
assign 1 0 693
assign 1 0 697
return 1 439 700
incrementValue 0 436 702
return 1 442 708
assign 1 446 715
find 1 446 715
assign 1 446 716
def 1 446 721
assign 1 447 722
new 0 447 722
return 1 447 723
assign 1 449 725
new 0 449 725
return 1 449 726
assign 1 455 731
new 0 455 731
assign 1 455 732
sortedFind 2 455 732
return 1 455 733
assign 1 462 754
assign 1 463 755
new 0 463 755
assign 1 467 758
subtract 1 467 758
assign 1 467 759
new 0 467 759
assign 1 467 760
divide 1 467 760
assign 1 467 761
add 1 467 761
assign 1 468 762
get 1 468 762
assign 1 469 763
equals 1 469 763
return 1 470 765
assign 1 471 768
greater 1 471 768
assign 1 473 770
assign 1 474 773
lesser 1 474 773
assign 1 476 775
assign 1 479 779
def 1 479 784
assign 1 479 785
equals 1 479 785
assign 1 0 787
assign 1 0 790
assign 1 0 794
assign 1 480 798
get 1 480 798
assign 1 480 799
lesser 1 480 799
assign 1 0 801
assign 1 0 804
assign 1 0 808
return 1 481 811
return 1 483 813
assign 1 485 815
assign 1 486 816
new 0 486 816
return 1 487 818
assign 1 0 823
return 1 0 827
return 1 0 830
return 1 0 833
assign 1 0 836
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 188061735: return bem_mergeSort_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 1616433729: return bem_lengthGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 183400265: return bem_firstGet_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1525854240: return bem_arrayIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1484114352: return bem_varraySet_0();
case 1473032100: return bem_varrayGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1478277476: return bem_sortValue_0();
case 729571811: return bem_serializeToString_0();
case 1990707345: return bem_lastGet_0();
case 1479417926: return bem_multiplierGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1484114353: return bem_varraySet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_4_3_MathInt) bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_5_ContainerArray) bevd_0);
case 228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_9_5_ContainerArray();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_9_5_ContainerArray.bevs_inst = (BEC_9_5_ContainerArray)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_9_5_ContainerArray.bevs_inst;
}
}
}
