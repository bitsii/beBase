namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_9_BuildVisitTypeCheck : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
static BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x76,0x61,0x72,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_3 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x76,0x61,0x72,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_4 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 30));
private static byte[] bels_5 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 19));
private static byte[] bels_6 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_8 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 67));
private static byte[] bels_9 = {0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 1));
private static byte[] bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_11 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_12 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_14 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_15 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 19));
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 52));
private static byte[] bels_17 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 5));
public static new BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tvar = null;
BEC_2_6_6_SystemObject bevl_ovar = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cvar = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_5_ContainerArray bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_119_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_125_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_176_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_177_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_185_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_197_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_199_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_202_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_205_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_219_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_221_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_224_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_227_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_228_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_231_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_235_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_239_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_240_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_242_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_243_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_245_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_246_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_247_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_249_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_250_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_251_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_253_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_258_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_265_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_267_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_268_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_271_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_272_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_273_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_274_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_275_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_276_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_277_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_278_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_279_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_280_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_281_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_282_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 384 */ {
bevt_16_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_firstGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 385 */ {
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bels_0));
bevt_17_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 386 */
} /* Line: 385 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevp_inClass = beva_node;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_23_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 392 */
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 394 */ {
bevp_cpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 395 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_28_tmpvar_phold.bevi_int == bevt_29_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 397 */ {
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_30_tmpvar_phold.bemd_1(2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_0_tmpvar_loop = bevt_31_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_cci.bem_typenameGet_0();
bevt_35_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_34_tmpvar_phold.bevi_int == bevt_35_tmpvar_phold.bevi_int) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 401 */ {
bevt_36_tmpvar_phold = bevl_cci.bem_heldGet_0();
bevt_36_tmpvar_phold.bemd_1(474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 402 */
} /* Line: 401 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
bevt_39_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_40_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 413 */ {
bevt_41_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_41_tmpvar_phold.bem_firstGet_0();
bevt_43_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 416 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 417 */
 else  /* Line: 418 */ {
bevt_45_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_47_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_46_tmpvar_phold);
bevl_tvar = bevt_44_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 419 */
bevt_49_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 422 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_50_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_51_tmpvar_phold);
} /* Line: 423 */
 else  /* Line: 424 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_53_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_53_tmpvar_phold.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 426 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_56_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_57_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_56_tmpvar_phold.bevi_int == bevt_57_tmpvar_phold.bevi_int) {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_55_tmpvar_phold.bevi_bool) /* Line: 426 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 426 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 426 */ {
bevt_58_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_59_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_58_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_59_tmpvar_phold);
} /* Line: 428 */
 else  /* Line: 429 */ {
bevt_61_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpvar_phold.bevi_int == bevt_62_tmpvar_phold.bevi_int) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 430 */ {
bevt_64_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 431 */ {
bevl_ovar = bevl_org.bem_heldGet_0();
} /* Line: 432 */
 else  /* Line: 433 */ {
bevt_66_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_68_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_67_tmpvar_phold);
bevl_ovar = bevt_65_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 435 */
} /* Line: 431 */
 else  /* Line: 430 */ {
bevt_70_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_70_tmpvar_phold.bevi_int == bevt_71_tmpvar_phold.bevi_int) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 438 */ {
bevt_72_tmpvar_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_72_tmpvar_phold.bem_firstGet_0();
bevt_74_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 441 */ {
bevl_cvar = bevl_ctarg.bem_heldGet_0();
} /* Line: 443 */
 else  /* Line: 444 */ {
bevt_76_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_78_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_77_tmpvar_phold);
bevl_cvar = bevt_75_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 446 */
bevl_syn = null;
bevt_81_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_80_tmpvar_phold == null) {
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 450 */ {
bevt_83_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_82_tmpvar_phold);
} /* Line: 451 */
 else  /* Line: 450 */ {
bevt_84_tmpvar_phold = bevl_cvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_84_tmpvar_phold != null && bevt_84_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_84_tmpvar_phold).bevi_bool) /* Line: 452 */ {
bevt_85_tmpvar_phold = bevl_cvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_tmpvar_phold);
} /* Line: 454 */
} /* Line: 450 */
if (bevl_syn == null) {
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 456 */ {
bevt_87_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_89_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_87_tmpvar_phold.bem_get_1(bevt_88_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 458 */ {
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_2));
bevt_91_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_92_tmpvar_phold, bevl_org);
throw new be.BELS_Base.BECS_ThrowBack(bevt_91_tmpvar_phold);
} /* Line: 459 */
 else  /* Line: 460 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 461 */
} /* Line: 458 */
} /* Line: 456 */
} /* Line: 430 */
if (bevl_ovar == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 465 */ {
bevt_94_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 465 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 465 */
 else  /* Line: 465 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 465 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_95_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_95_tmpvar_phold != null && bevt_95_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_95_tmpvar_phold).bevi_bool) /* Line: 468 */ {
if (bevl_syn == null) {
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 470 */ {
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bels_3));
bevt_97_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_98_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_97_tmpvar_phold);
} /* Line: 471 */
bevt_100_tmpvar_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_101_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_101_tmpvar_phold);
if (bevt_99_tmpvar_phold != null && bevt_99_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_99_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 478 */
 else  /* Line: 476 */ {
bevt_103_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_103_tmpvar_phold == null) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_106_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_covariantReturnsGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 479 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 479 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 479 */
 else  /* Line: 479 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 479 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 480 */
} /* Line: 476 */
} /* Line: 476 */
 else  /* Line: 468 */ {
if (bevl_mtdc == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 482 */ {
bevt_108_tmpvar_phold = bevl_mtdc.bemd_2(583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_108_tmpvar_phold);
} /* Line: 483 */
 else  /* Line: 484 */ {
bevt_109_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_109_tmpvar_phold);
} /* Line: 485 */
} /* Line: 468 */
bevt_111_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_110_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_111_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 489 */ {
bevt_112_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_113_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_112_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_113_tmpvar_phold);
} /* Line: 491 */
 else  /* Line: 492 */ {
bevt_114_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 493 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 494 */
 else  /* Line: 495 */ {
bevl_ovnp = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 496 */
bevt_115_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 499 */ {
bevt_117_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_118_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_117_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_118_tmpvar_phold);
} /* Line: 501 */
 else  /* Line: 502 */ {
bevt_123_tmpvar_phold = bevo_0;
bevt_125_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_toString_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bem_add_1(bevt_124_tmpvar_phold);
bevt_126_tmpvar_phold = bevo_1;
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_add_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bem_add_1(bevt_127_tmpvar_phold);
bevt_119_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_120_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_119_tmpvar_phold);
} /* Line: 503 */
} /* Line: 499 */
if (bevl_castForSelf.bevi_bool) /* Line: 507 */ {
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_128_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_129_tmpvar_phold);
} /* Line: 509 */
} /* Line: 507 */
bevt_132_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_131_tmpvar_phold = bevt_132_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_131_tmpvar_phold == null) {
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 512 */ {
} /* Line: 512 */
} /* Line: 512 */
} /* Line: 426 */
} /* Line: 422 */
 else  /* Line: 413 */ {
bevt_135_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_136_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_6));
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_133_tmpvar_phold != null && bevt_133_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_133_tmpvar_phold).bevi_bool) /* Line: 517 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_138_tmpvar_phold = bevl_targ.bem_typenameGet_0();
bevt_139_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_138_tmpvar_phold.bevi_int == bevt_139_tmpvar_phold.bevi_int) {
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_137_tmpvar_phold.bevi_bool) /* Line: 519 */ {
bevt_141_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_140_tmpvar_phold = bevt_141_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_140_tmpvar_phold != null && bevt_140_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_140_tmpvar_phold).bevi_bool) /* Line: 520 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 521 */
 else  /* Line: 522 */ {
bevt_143_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_145_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_144_tmpvar_phold = bevt_145_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_144_tmpvar_phold);
bevl_tvar = bevt_142_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 523 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_147_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 527 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 528 */
 else  /* Line: 529 */ {
bevt_149_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_151_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpvar_phold = bevt_149_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_150_tmpvar_phold);
bevl_tvar = bevt_148_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 530 */
bevt_154_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_153_tmpvar_phold == null) {
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_152_tmpvar_phold.bevi_bool) /* Line: 533 */ {
bevt_157_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpvar_phold = bevt_156_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_155_tmpvar_phold != null && bevt_155_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_155_tmpvar_phold).bevi_bool) /* Line: 533 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 533 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 533 */
 else  /* Line: 533 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 533 */ {
bevt_159_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 534 */ {
bevt_160_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_161_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_160_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_161_tmpvar_phold);
} /* Line: 536 */
 else  /* Line: 537 */ {
bevt_164_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_162_tmpvar_phold != null && bevt_162_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_162_tmpvar_phold).bevi_bool) /* Line: 540 */ {
bevt_166_tmpvar_phold = bevl_tvar.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_167_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_167_tmpvar_phold);
if (bevt_165_tmpvar_phold != null && bevt_165_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_165_tmpvar_phold).bevi_bool) /* Line: 541 */ {
bevt_168_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_168_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_169_tmpvar_phold);
} /* Line: 543 */
 else  /* Line: 544 */ {
bevt_170_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_170_tmpvar_phold);
bevt_172_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_171_tmpvar_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_172_tmpvar_phold);
if (bevt_171_tmpvar_phold != null && bevt_171_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_171_tmpvar_phold).bevi_bool) /* Line: 546 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 546 */ {
bevt_174_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_173_tmpvar_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_174_tmpvar_phold);
if (bevt_173_tmpvar_phold != null && bevt_173_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_173_tmpvar_phold).bevi_bool) /* Line: 546 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 546 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 546 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 546 */ {
bevt_175_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_176_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_175_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_176_tmpvar_phold);
} /* Line: 548 */
 else  /* Line: 549 */ {
bevt_181_tmpvar_phold = bevo_2;
bevt_182_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bem_add_1(bevt_182_tmpvar_phold);
bevt_183_tmpvar_phold = bevo_3;
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bem_add_1(bevt_183_tmpvar_phold);
bevt_184_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevt_184_tmpvar_phold);
bevt_177_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_178_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_177_tmpvar_phold);
} /* Line: 550 */
} /* Line: 546 */
} /* Line: 541 */
 else  /* Line: 553 */ {
bevt_185_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_185_tmpvar_phold);
bevt_189_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_186_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_187_tmpvar_phold);
if (bevt_186_tmpvar_phold != null && bevt_186_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_186_tmpvar_phold).bevi_bool) /* Line: 555 */ {
bevt_190_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_191_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_190_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_191_tmpvar_phold);
} /* Line: 557 */
 else  /* Line: 558 */ {
bevt_194_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_192_tmpvar_phold = bevt_193_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_192_tmpvar_phold);
bevt_196_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_195_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_196_tmpvar_phold);
if (bevt_195_tmpvar_phold != null && bevt_195_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_195_tmpvar_phold).bevi_bool) /* Line: 560 */ {
bevt_197_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_198_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_197_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_198_tmpvar_phold);
} /* Line: 562 */
 else  /* Line: 563 */ {
bevt_200_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bels_10));
bevt_199_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_200_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_199_tmpvar_phold);
} /* Line: 564 */
} /* Line: 560 */
} /* Line: 555 */
} /* Line: 540 */
} /* Line: 534 */
 else  /* Line: 569 */ {
bevt_201_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_202_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_201_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_202_tmpvar_phold);
} /* Line: 571 */
} /* Line: 533 */
 else  /* Line: 573 */ {
bevt_203_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_204_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_203_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_204_tmpvar_phold);
} /* Line: 574 */
} /* Line: 519 */
 else  /* Line: 576 */ {
bevt_205_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_205_tmpvar_phold.bem_firstGet_0();
bevt_207_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 579 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 580 */
 else  /* Line: 581 */ {
bevt_209_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_211_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_210_tmpvar_phold);
bevl_tvar = bevt_208_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 582 */
bevt_213_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 585 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 585 */ {
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_217_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_11));
bevt_214_tmpvar_phold = bevt_215_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_217_tmpvar_phold);
if (bevt_214_tmpvar_phold != null && bevt_214_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_214_tmpvar_phold).bevi_bool) /* Line: 585 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 585 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 585 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 585 */ {
bevt_218_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_219_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_218_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_219_tmpvar_phold);
} /* Line: 586 */
 else  /* Line: 587 */ {
bevt_220_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_221_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_220_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_221_tmpvar_phold);
bevt_223_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevt_223_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_222_tmpvar_phold != null && bevt_222_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_222_tmpvar_phold).bevi_bool) /* Line: 589 */ {
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_225_tmpvar_phold == null) {
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_224_tmpvar_phold.bevi_bool) /* Line: 590 */ {
bevt_228_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_12));
bevt_227_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_228_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_227_tmpvar_phold);
} /* Line: 591 */
bevt_230_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_229_tmpvar_phold);
bevt_231_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_233_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_232_tmpvar_phold = bevt_233_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_231_tmpvar_phold.bem_get_1(bevt_232_tmpvar_phold);
} /* Line: 594 */
 else  /* Line: 595 */ {
bevt_234_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_234_tmpvar_phold);
bevt_235_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_237_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_235_tmpvar_phold.bem_get_1(bevt_236_tmpvar_phold);
} /* Line: 597 */
if (bevl_mtdc == null) {
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 599 */ {
bevt_240_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_13));
bevt_239_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_239_tmpvar_phold);
} /* Line: 600 */
bevl_argSyns = (BEC_2_9_5_ContainerArray) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 604 */ {
bevt_242_tmpvar_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_242_tmpvar_phold.bevi_int) {
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 604 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_243_tmpvar_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_243_tmpvar_phold.bevi_bool) /* Line: 606 */ {
if (bevl_nnode == null) {
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 607 */ {
bevt_246_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_14));
bevt_245_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_246_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_245_tmpvar_phold);
} /* Line: 608 */
 else  /* Line: 607 */ {
bevt_248_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_249_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_248_tmpvar_phold.bevi_int != bevt_249_tmpvar_phold.bevi_int) {
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_247_tmpvar_phold.bevi_bool) /* Line: 609 */ {
bevt_251_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_252_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_251_tmpvar_phold.bevi_int != bevt_252_tmpvar_phold.bevi_int) {
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_250_tmpvar_phold.bevi_bool) /* Line: 609 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 609 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 609 */
 else  /* Line: 609 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 609 */ {
bevt_255_tmpvar_phold = bevo_4;
bevt_257_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_256_tmpvar_phold = bevt_257_tmpvar_phold.bem_toString_0();
bevt_254_tmpvar_phold = bevt_255_tmpvar_phold.bem_add_1(bevt_256_tmpvar_phold);
bevt_253_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_254_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_253_tmpvar_phold);
} /* Line: 610 */
} /* Line: 607 */
bevt_259_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_260_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_259_tmpvar_phold.bevi_int == bevt_260_tmpvar_phold.bevi_int) {
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_258_tmpvar_phold.bevi_bool) /* Line: 612 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_262_tmpvar_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_262_tmpvar_phold.bevi_bool) {
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_261_tmpvar_phold.bevi_bool) /* Line: 614 */ {
bevt_263_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_264_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_263_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_264_tmpvar_phold);
bevt_266_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_265_tmpvar_phold = bevt_266_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_267_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_265_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_267_tmpvar_phold);
} /* Line: 616 */
 else  /* Line: 618 */ {
bevt_268_tmpvar_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_268_tmpvar_phold);
bevt_271_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_270_tmpvar_phold = bevl_syn.bem_castsTo_1(bevt_271_tmpvar_phold);
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 620 */ {
bevt_276_tmpvar_phold = bevo_5;
bevt_278_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bem_toString_0();
bevt_275_tmpvar_phold = bevt_276_tmpvar_phold.bem_add_1(bevt_277_tmpvar_phold);
bevt_279_tmpvar_phold = bevo_6;
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bem_add_1(bevt_279_tmpvar_phold);
bevt_281_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bem_toString_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bem_add_1(bevt_280_tmpvar_phold);
bevt_272_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_273_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_272_tmpvar_phold);
} /* Line: 621 */
} /* Line: 620 */
} /* Line: 614 */
} /* Line: 612 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 604 */
 else  /* Line: 604 */ {
break;
} /* Line: 604 */
} /* Line: 604 */
} /* Line: 604 */
} /* Line: 585 */
} /* Line: 413 */
} /* Line: 413 */
bevt_282_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_282_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {384, 384, 384, 384, 385, 385, 385, 385, 385, 385, 386, 386, 386, 389, 389, 389, 389, 390, 391, 391, 392, 392, 394, 394, 394, 394, 395, 397, 397, 397, 397, 398, 398, 399, 400, 400, 0, 400, 400, 401, 401, 401, 401, 402, 402, 413, 413, 413, 413, 414, 414, 416, 416, 417, 419, 419, 419, 419, 419, 422, 422, 423, 423, 423, 425, 426, 426, 426, 426, 0, 426, 426, 426, 426, 0, 0, 428, 428, 428, 430, 430, 430, 430, 431, 431, 432, 435, 435, 435, 435, 435, 438, 438, 438, 438, 439, 439, 441, 441, 443, 446, 446, 446, 446, 446, 449, 450, 450, 450, 450, 451, 451, 451, 452, 454, 454, 456, 456, 457, 457, 457, 457, 458, 458, 459, 459, 459, 461, 465, 465, 465, 0, 0, 0, 467, 468, 470, 470, 471, 471, 471, 476, 476, 476, 478, 479, 479, 479, 479, 479, 479, 0, 0, 0, 480, 482, 482, 483, 483, 485, 485, 489, 489, 491, 491, 491, 493, 494, 496, 498, 498, 499, 501, 501, 501, 503, 503, 503, 503, 503, 503, 503, 503, 503, 503, 509, 509, 509, 512, 512, 512, 512, 517, 517, 517, 517, 518, 519, 519, 519, 519, 520, 520, 521, 523, 523, 523, 523, 523, 526, 527, 527, 528, 530, 530, 530, 530, 530, 533, 533, 533, 533, 533, 533, 533, 0, 0, 0, 534, 534, 536, 536, 536, 540, 540, 540, 541, 541, 541, 543, 543, 543, 545, 545, 546, 546, 0, 546, 546, 0, 0, 548, 548, 548, 550, 550, 550, 550, 550, 550, 550, 550, 550, 554, 554, 555, 555, 555, 555, 557, 557, 557, 559, 559, 559, 559, 560, 560, 562, 562, 562, 564, 564, 564, 571, 571, 571, 574, 574, 574, 577, 577, 579, 579, 580, 582, 582, 582, 582, 582, 585, 585, 0, 585, 585, 585, 585, 0, 0, 586, 586, 586, 588, 588, 588, 589, 589, 590, 590, 590, 590, 591, 591, 591, 593, 593, 593, 594, 594, 594, 594, 596, 596, 597, 597, 597, 597, 599, 599, 600, 600, 600, 602, 603, 604, 604, 604, 604, 605, 606, 607, 607, 608, 608, 608, 609, 609, 609, 609, 609, 609, 609, 609, 0, 0, 0, 610, 610, 610, 610, 610, 610, 612, 612, 612, 612, 613, 614, 614, 614, 615, 615, 615, 616, 616, 616, 616, 619, 619, 620, 620, 620, 621, 621, 621, 621, 621, 621, 621, 621, 621, 621, 621, 630, 604, 635, 635, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {344, 345, 346, 351, 352, 353, 354, 355, 356, 357, 359, 360, 361, 364, 365, 366, 371, 372, 373, 374, 375, 376, 378, 379, 380, 385, 386, 388, 389, 390, 395, 396, 397, 398, 399, 400, 400, 403, 405, 406, 407, 408, 413, 414, 415, 422, 423, 424, 425, 427, 428, 429, 430, 432, 435, 436, 437, 438, 439, 441, 442, 444, 445, 446, 449, 450, 451, 452, 457, 458, 461, 462, 463, 468, 469, 472, 476, 477, 478, 481, 482, 483, 488, 489, 490, 492, 495, 496, 497, 498, 499, 503, 504, 505, 510, 511, 512, 513, 514, 516, 519, 520, 521, 522, 523, 525, 526, 527, 528, 533, 534, 535, 536, 539, 541, 542, 545, 550, 551, 552, 553, 554, 555, 560, 561, 562, 563, 566, 571, 576, 577, 579, 582, 586, 589, 590, 592, 597, 598, 599, 600, 602, 603, 604, 606, 609, 610, 615, 616, 617, 618, 620, 623, 627, 630, 635, 640, 641, 642, 645, 646, 649, 650, 652, 653, 654, 657, 659, 662, 664, 665, 666, 668, 669, 670, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 686, 687, 688, 691, 692, 693, 698, 704, 705, 706, 707, 709, 710, 711, 712, 717, 718, 719, 721, 724, 725, 726, 727, 728, 730, 731, 732, 734, 737, 738, 739, 740, 741, 743, 744, 745, 750, 751, 752, 753, 755, 758, 762, 765, 766, 768, 769, 770, 773, 774, 775, 777, 778, 779, 781, 782, 783, 786, 787, 788, 789, 791, 794, 795, 797, 800, 804, 805, 806, 809, 810, 811, 812, 813, 814, 815, 816, 817, 822, 823, 824, 825, 826, 827, 829, 830, 831, 834, 835, 836, 837, 838, 839, 841, 842, 843, 846, 847, 848, 855, 856, 857, 861, 862, 863, 867, 868, 869, 870, 872, 875, 876, 877, 878, 879, 881, 882, 884, 887, 888, 889, 890, 892, 895, 899, 900, 901, 904, 905, 906, 907, 908, 910, 911, 912, 917, 918, 919, 920, 922, 923, 924, 925, 926, 927, 928, 931, 932, 933, 934, 935, 936, 938, 943, 944, 945, 946, 948, 949, 950, 953, 954, 959, 960, 961, 963, 968, 969, 970, 971, 974, 975, 976, 981, 982, 983, 984, 989, 990, 993, 997, 1000, 1001, 1002, 1003, 1004, 1005, 1008, 1009, 1010, 1015, 1016, 1017, 1018, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1033, 1034, 1035, 1036, 1037, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1054, 1055, 1065, 1066, 1069, 1072, 1076, 1079, 1083, 1086, 1090, 1093, 1097, 1100};
/* BEGIN LINEINFO 
assign 1 384 344
typenameGet 0 384 344
assign 1 384 345
CATCHGet 0 384 345
assign 1 384 346
equals 1 384 351
assign 1 385 352
containedGet 0 385 352
assign 1 385 353
firstGet 0 385 353
assign 1 385 354
containedGet 0 385 354
assign 1 385 355
firstGet 0 385 355
assign 1 385 356
heldGet 0 385 356
assign 1 385 357
isTypedGet 0 385 357
assign 1 386 359
new 0 386 359
assign 1 386 360
new 1 386 360
throw 1 386 361
assign 1 389 364
typenameGet 0 389 364
assign 1 389 365
CLASSGet 0 389 365
assign 1 389 366
equals 1 389 371
assign 1 390 372
assign 1 391 373
heldGet 0 391 373
assign 1 391 374
namepathGet 0 391 374
assign 1 392 375
heldGet 0 392 375
assign 1 392 376
synGet 0 392 376
assign 1 394 378
typenameGet 0 394 378
assign 1 394 379
METHODGet 0 394 379
assign 1 394 380
equals 1 394 385
assign 1 395 386
new 0 395 386
assign 1 397 388
typenameGet 0 397 388
assign 1 397 389
CALLGet 0 397 389
assign 1 397 390
equals 1 397 395
assign 1 398 396
heldGet 0 398 396
cposSet 1 398 397
assign 1 399 398
increment 0 399 398
assign 1 400 399
containedGet 0 400 399
assign 1 400 400
iteratorGet 0 0 400
assign 1 400 403
hasNextGet 0 400 403
assign 1 400 405
nextGet 0 400 405
assign 1 401 406
typenameGet 0 401 406
assign 1 401 407
VARGet 0 401 407
assign 1 401 408
equals 1 401 413
assign 1 402 414
heldGet 0 402 414
addCall 1 402 415
assign 1 413 422
heldGet 0 413 422
assign 1 413 423
orgNameGet 0 413 423
assign 1 413 424
new 0 413 424
assign 1 413 425
equals 1 413 425
assign 1 414 427
containedGet 0 414 427
assign 1 414 428
firstGet 0 414 428
assign 1 416 429
heldGet 0 416 429
assign 1 416 430
isDeclaredGet 0 416 430
assign 1 417 432
heldGet 0 417 432
assign 1 419 435
ptyMapGet 0 419 435
assign 1 419 436
heldGet 0 419 436
assign 1 419 437
nameGet 0 419 437
assign 1 419 438
get 1 419 438
assign 1 419 439
memSynGet 0 419 439
assign 1 422 441
isTypedGet 0 422 441
assign 1 422 442
not 0 422 442
assign 1 423 444
heldGet 0 423 444
assign 1 423 445
new 0 423 445
checkTypesSet 1 423 446
assign 1 425 449
secondGet 0 425 449
assign 1 426 450
typenameGet 0 426 450
assign 1 426 451
TRUEGet 0 426 451
assign 1 426 452
equals 1 426 457
assign 1 0 458
assign 1 426 461
typenameGet 0 426 461
assign 1 426 462
FALSEGet 0 426 462
assign 1 426 463
equals 1 426 468
assign 1 0 469
assign 1 0 472
assign 1 428 476
heldGet 0 428 476
assign 1 428 477
new 0 428 477
checkTypesSet 1 428 478
assign 1 430 481
typenameGet 0 430 481
assign 1 430 482
VARGet 0 430 482
assign 1 430 483
equals 1 430 488
assign 1 431 489
heldGet 0 431 489
assign 1 431 490
isDeclaredGet 0 431 490
assign 1 432 492
heldGet 0 432 492
assign 1 435 495
ptyMapGet 0 435 495
assign 1 435 496
heldGet 0 435 496
assign 1 435 497
nameGet 0 435 497
assign 1 435 498
get 1 435 498
assign 1 435 499
memSynGet 0 435 499
assign 1 438 503
typenameGet 0 438 503
assign 1 438 504
CALLGet 0 438 504
assign 1 438 505
equals 1 438 510
assign 1 439 511
containedGet 0 439 511
assign 1 439 512
firstGet 0 439 512
assign 1 441 513
heldGet 0 441 513
assign 1 441 514
isDeclaredGet 0 441 514
assign 1 443 516
heldGet 0 443 516
assign 1 446 519
ptyMapGet 0 446 519
assign 1 446 520
heldGet 0 446 520
assign 1 446 521
nameGet 0 446 521
assign 1 446 522
get 1 446 522
assign 1 446 523
memSynGet 0 446 523
assign 1 449 525
assign 1 450 526
heldGet 0 450 526
assign 1 450 527
newNpGet 0 450 527
assign 1 450 528
def 1 450 533
assign 1 451 534
heldGet 0 451 534
assign 1 451 535
newNpGet 0 451 535
assign 1 451 536
getSynNp 1 451 536
assign 1 452 539
isTypedGet 0 452 539
assign 1 454 541
namepathGet 0 454 541
assign 1 454 542
getSynNp 1 454 542
assign 1 456 545
def 1 456 550
assign 1 457 551
mtdMapGet 0 457 551
assign 1 457 552
heldGet 0 457 552
assign 1 457 553
nameGet 0 457 553
assign 1 457 554
get 1 457 554
assign 1 458 555
undef 1 458 560
assign 1 459 561
new 0 459 561
assign 1 459 562
new 2 459 562
throw 1 459 563
assign 1 461 566
rsynGet 0 461 566
assign 1 465 571
def 1 465 576
assign 1 465 577
isTypedGet 0 465 577
assign 1 0 579
assign 1 0 582
assign 1 0 586
assign 1 467 589
new 0 467 589
assign 1 468 590
isSelfGet 0 468 590
assign 1 470 592
undef 1 470 597
assign 1 471 598
new 0 471 598
assign 1 471 599
new 1 471 599
throw 1 471 600
assign 1 476 602
originGet 0 476 602
assign 1 476 603
namepathGet 0 476 603
assign 1 476 604
notEquals 1 476 604
assign 1 478 606
new 0 478 606
assign 1 479 609
emitCommonGet 0 479 609
assign 1 479 610
def 1 479 615
assign 1 479 616
emitCommonGet 0 479 616
assign 1 479 617
covariantReturnsGet 0 479 617
assign 1 479 618
not 0 479 618
assign 1 0 620
assign 1 0 623
assign 1 0 627
assign 1 480 630
new 0 480 630
assign 1 482 635
def 1 482 640
assign 1 483 641
getEmitReturnType 2 483 641
assign 1 483 642
getSynNp 1 483 642
assign 1 485 645
namepathGet 0 485 645
assign 1 485 646
getSynNp 1 485 646
assign 1 489 649
namepathGet 0 489 649
assign 1 489 650
castsTo 1 489 650
assign 1 491 652
heldGet 0 491 652
assign 1 491 653
new 0 491 653
checkTypesSet 1 491 654
assign 1 493 657
isSelfGet 0 493 657
assign 1 494 659
namepathGet 0 494 659
assign 1 496 662
namepathGet 0 496 662
assign 1 498 664
namepathGet 0 498 664
assign 1 498 665
getSynNp 1 498 665
assign 1 499 666
castsTo 1 499 666
assign 1 501 668
heldGet 0 501 668
assign 1 501 669
new 0 501 669
checkTypesSet 1 501 670
assign 1 503 673
new 0 503 673
assign 1 503 674
namepathGet 0 503 674
assign 1 503 675
toString 0 503 675
assign 1 503 676
add 1 503 676
assign 1 503 677
new 0 503 677
assign 1 503 678
add 1 503 678
assign 1 503 679
toString 0 503 679
assign 1 503 680
add 1 503 680
assign 1 503 681
new 2 503 681
throw 1 503 682
assign 1 509 686
heldGet 0 509 686
assign 1 509 687
new 0 509 687
checkTypesSet 1 509 688
assign 1 512 691
heldGet 0 512 691
assign 1 512 692
namepathGet 0 512 692
assign 1 512 693
def 1 512 698
assign 1 517 704
heldGet 0 517 704
assign 1 517 705
orgNameGet 0 517 705
assign 1 517 706
new 0 517 706
assign 1 517 707
equals 1 517 707
assign 1 518 709
secondGet 0 518 709
assign 1 519 710
typenameGet 0 519 710
assign 1 519 711
VARGet 0 519 711
assign 1 519 712
equals 1 519 717
assign 1 520 718
heldGet 0 520 718
assign 1 520 719
isDeclaredGet 0 520 719
assign 1 521 721
heldGet 0 521 721
assign 1 523 724
ptyMapGet 0 523 724
assign 1 523 725
heldGet 0 523 725
assign 1 523 726
nameGet 0 523 726
assign 1 523 727
get 1 523 727
assign 1 523 728
memSynGet 0 523 728
assign 1 526 730
scopeGet 0 526 730
assign 1 527 731
heldGet 0 527 731
assign 1 527 732
isDeclaredGet 0 527 732
assign 1 528 734
heldGet 0 528 734
assign 1 530 737
ptyMapGet 0 530 737
assign 1 530 738
heldGet 0 530 738
assign 1 530 739
nameGet 0 530 739
assign 1 530 740
get 1 530 740
assign 1 530 741
memSynGet 0 530 741
assign 1 533 743
heldGet 0 533 743
assign 1 533 744
rtypeGet 0 533 744
assign 1 533 745
def 1 533 750
assign 1 533 751
heldGet 0 533 751
assign 1 533 752
rtypeGet 0 533 752
assign 1 533 753
isTypedGet 0 533 753
assign 1 0 755
assign 1 0 758
assign 1 0 762
assign 1 534 765
isTypedGet 0 534 765
assign 1 534 766
not 0 534 766
assign 1 536 768
heldGet 0 536 768
assign 1 536 769
new 0 536 769
checkTypesSet 1 536 770
assign 1 540 773
heldGet 0 540 773
assign 1 540 774
rtypeGet 0 540 774
assign 1 540 775
isSelfGet 0 540 775
assign 1 541 777
nameGet 0 541 777
assign 1 541 778
new 0 541 778
assign 1 541 779
equals 1 541 779
assign 1 543 781
heldGet 0 543 781
assign 1 543 782
new 0 543 782
checkTypesSet 1 543 783
assign 1 545 786
namepathGet 0 545 786
assign 1 545 787
getSynNp 1 545 787
assign 1 546 788
namepathGet 0 546 788
assign 1 546 789
castsTo 1 546 789
assign 1 0 791
assign 1 546 794
namepathGet 0 546 794
assign 1 546 795
castsTo 1 546 795
assign 1 0 797
assign 1 0 800
assign 1 548 804
heldGet 0 548 804
assign 1 548 805
new 0 548 805
checkTypesSet 1 548 806
assign 1 550 809
new 0 550 809
assign 1 550 810
namepathGet 0 550 810
assign 1 550 811
add 1 550 811
assign 1 550 812
new 0 550 812
assign 1 550 813
add 1 550 813
assign 1 550 814
namepathGet 0 550 814
assign 1 550 815
add 1 550 815
assign 1 550 816
new 2 550 816
throw 1 550 817
assign 1 554 822
namepathGet 0 554 822
assign 1 554 823
getSynNp 1 554 823
assign 1 555 824
heldGet 0 555 824
assign 1 555 825
rtypeGet 0 555 825
assign 1 555 826
namepathGet 0 555 826
assign 1 555 827
castsTo 1 555 827
assign 1 557 829
heldGet 0 557 829
assign 1 557 830
new 0 557 830
checkTypesSet 1 557 831
assign 1 559 834
heldGet 0 559 834
assign 1 559 835
rtypeGet 0 559 835
assign 1 559 836
namepathGet 0 559 836
assign 1 559 837
getSynNp 1 559 837
assign 1 560 838
namepathGet 0 560 838
assign 1 560 839
castsTo 1 560 839
assign 1 562 841
heldGet 0 562 841
assign 1 562 842
new 0 562 842
checkTypesSet 1 562 843
assign 1 564 846
new 0 564 846
assign 1 564 847
new 2 564 847
throw 1 564 848
assign 1 571 855
heldGet 0 571 855
assign 1 571 856
new 0 571 856
checkTypesSet 1 571 857
assign 1 574 861
heldGet 0 574 861
assign 1 574 862
new 0 574 862
checkTypesSet 1 574 863
assign 1 577 867
containedGet 0 577 867
assign 1 577 868
firstGet 0 577 868
assign 1 579 869
heldGet 0 579 869
assign 1 579 870
isDeclaredGet 0 579 870
assign 1 580 872
heldGet 0 580 872
assign 1 582 875
ptyMapGet 0 582 875
assign 1 582 876
heldGet 0 582 876
assign 1 582 877
nameGet 0 582 877
assign 1 582 878
get 1 582 878
assign 1 582 879
memSynGet 0 582 879
assign 1 585 881
isTypedGet 0 585 881
assign 1 585 882
not 0 585 882
assign 1 0 884
assign 1 585 887
heldGet 0 585 887
assign 1 585 888
orgNameGet 0 585 888
assign 1 585 889
new 0 585 889
assign 1 585 890
equals 1 585 890
assign 1 0 892
assign 1 0 895
assign 1 586 899
heldGet 0 586 899
assign 1 586 900
new 0 586 900
checkTypesSet 1 586 901
assign 1 588 904
heldGet 0 588 904
assign 1 588 905
new 0 588 905
checkTypesSet 1 588 906
assign 1 589 907
heldGet 0 589 907
assign 1 589 908
isConstructGet 0 589 908
assign 1 590 910
heldGet 0 590 910
assign 1 590 911
newNpGet 0 590 911
assign 1 590 912
undef 1 590 917
assign 1 591 918
new 0 591 918
assign 1 591 919
new 1 591 919
throw 1 591 920
assign 1 593 922
heldGet 0 593 922
assign 1 593 923
newNpGet 0 593 923
assign 1 593 924
getSynNp 1 593 924
assign 1 594 925
mtdMapGet 0 594 925
assign 1 594 926
heldGet 0 594 926
assign 1 594 927
nameGet 0 594 927
assign 1 594 928
get 1 594 928
assign 1 596 931
namepathGet 0 596 931
assign 1 596 932
getSynNp 1 596 932
assign 1 597 933
mtdMapGet 0 597 933
assign 1 597 934
heldGet 0 597 934
assign 1 597 935
nameGet 0 597 935
assign 1 597 936
get 1 597 936
assign 1 599 938
undef 1 599 943
assign 1 600 944
new 0 600 944
assign 1 600 945
new 2 600 945
throw 1 600 946
assign 1 602 948
argSynsGet 0 602 948
assign 1 603 949
nextPeerGet 0 603 949
assign 1 604 950
new 0 604 950
assign 1 604 953
lengthGet 0 604 953
assign 1 604 954
lesser 1 604 959
assign 1 605 960
get 1 605 960
assign 1 606 961
isTypedGet 0 606 961
assign 1 607 963
undef 1 607 968
assign 1 608 969
new 0 608 969
assign 1 608 970
new 2 608 970
throw 1 608 971
assign 1 609 974
typenameGet 0 609 974
assign 1 609 975
VARGet 0 609 975
assign 1 609 976
notEquals 1 609 981
assign 1 609 982
typenameGet 0 609 982
assign 1 609 983
NULLGet 0 609 983
assign 1 609 984
notEquals 1 609 989
assign 1 0 990
assign 1 0 993
assign 1 0 997
assign 1 610 1000
new 0 610 1000
assign 1 610 1001
typenameGet 0 610 1001
assign 1 610 1002
toString 0 610 1002
assign 1 610 1003
add 1 610 1003
assign 1 610 1004
new 2 610 1004
throw 1 610 1005
assign 1 612 1008
typenameGet 0 612 1008
assign 1 612 1009
VARGet 0 612 1009
assign 1 612 1010
equals 1 612 1015
assign 1 613 1016
heldGet 0 613 1016
assign 1 614 1017
isTypedGet 0 614 1017
assign 1 614 1018
not 0 614 1023
assign 1 615 1024
heldGet 0 615 1024
assign 1 615 1025
new 0 615 1025
checkTypesSet 1 615 1026
assign 1 616 1027
heldGet 0 616 1027
assign 1 616 1028
argCastsGet 0 616 1028
assign 1 616 1029
namepathGet 0 616 1029
put 2 616 1030
assign 1 619 1033
namepathGet 0 619 1033
assign 1 619 1034
getSynNp 1 619 1034
assign 1 620 1035
namepathGet 0 620 1035
assign 1 620 1036
castsTo 1 620 1036
assign 1 620 1037
not 0 620 1037
assign 1 621 1039
new 0 621 1039
assign 1 621 1040
namepathGet 0 621 1040
assign 1 621 1041
toString 0 621 1041
assign 1 621 1042
add 1 621 1042
assign 1 621 1043
new 0 621 1043
assign 1 621 1044
add 1 621 1044
assign 1 621 1045
namepathGet 0 621 1045
assign 1 621 1046
toString 0 621 1046
assign 1 621 1047
add 1 621 1047
assign 1 621 1048
new 2 621 1048
throw 1 621 1049
assign 1 630 1054
nextPeerGet 0 630 1054
assign 1 604 1055
increment 0 604 1055
assign 1 635 1065
nextDescendGet 0 635 1065
return 1 635 1066
return 1 0 1069
assign 1 0 1072
return 1 0 1076
assign 1 0 1079
return 1 0 1083
assign 1 0 1086
return 1 0 1090
assign 1 0 1093
return 1 0 1097
assign 1 0 1100
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2117282045: return bem_cposSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
}
