namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_9_BuildVisitTypeCheck : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
static BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x76,0x61,0x72,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_3 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x76,0x61,0x72,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_4 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 30));
private static byte[] bels_5 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 19));
private static byte[] bels_6 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_8 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 67));
private static byte[] bels_9 = {0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 1));
private static byte[] bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_11 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_12 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_14 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_15 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 19));
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 52));
private static byte[] bels_17 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 5));
public static new BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tvar = null;
BEC_2_6_6_SystemObject bevl_ovar = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cvar = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_4_ContainerList bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_119_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_125_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_176_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_177_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_185_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_197_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_199_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_202_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_205_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_219_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_221_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_224_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_227_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_228_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_231_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_235_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_239_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_240_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_242_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_243_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_245_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_246_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_247_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_249_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_250_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_251_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_253_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_258_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_265_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_267_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_268_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_271_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_272_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_273_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_274_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_275_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_276_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_277_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_278_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_279_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_280_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_281_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_282_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 381 */ {
bevt_16_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_firstGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 382 */ {
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bels_0));
bevt_17_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 383 */
} /* Line: 382 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevp_inClass = beva_node;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_23_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 389 */
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevp_cpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 392 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_28_tmpvar_phold.bevi_int == bevt_29_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 394 */ {
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_30_tmpvar_phold.bemd_1(2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_0_tmpvar_loop = bevt_31_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 397 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 397 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_cci.bem_typenameGet_0();
bevt_35_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_34_tmpvar_phold.bevi_int == bevt_35_tmpvar_phold.bevi_int) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 398 */ {
bevt_36_tmpvar_phold = bevl_cci.bem_heldGet_0();
bevt_36_tmpvar_phold.bemd_1(474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 399 */
} /* Line: 398 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
bevt_39_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_40_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 410 */ {
bevt_41_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_41_tmpvar_phold.bem_firstGet_0();
bevt_43_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 413 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 414 */
 else  /* Line: 415 */ {
bevt_45_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_47_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_46_tmpvar_phold);
bevl_tvar = bevt_44_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 416 */
bevt_49_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 419 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_50_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_51_tmpvar_phold);
} /* Line: 420 */
 else  /* Line: 421 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_53_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_53_tmpvar_phold.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_56_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_57_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_56_tmpvar_phold.bevi_int == bevt_57_tmpvar_phold.bevi_int) {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_55_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 423 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 423 */ {
bevt_58_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_59_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_58_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_59_tmpvar_phold);
} /* Line: 425 */
 else  /* Line: 426 */ {
bevt_61_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpvar_phold.bevi_int == bevt_62_tmpvar_phold.bevi_int) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_64_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 428 */ {
bevl_ovar = bevl_org.bem_heldGet_0();
} /* Line: 429 */
 else  /* Line: 430 */ {
bevt_66_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_68_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_67_tmpvar_phold);
bevl_ovar = bevt_65_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 432 */
} /* Line: 428 */
 else  /* Line: 427 */ {
bevt_70_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_70_tmpvar_phold.bevi_int == bevt_71_tmpvar_phold.bevi_int) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 435 */ {
bevt_72_tmpvar_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_72_tmpvar_phold.bem_firstGet_0();
bevt_74_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 438 */ {
bevl_cvar = bevl_ctarg.bem_heldGet_0();
} /* Line: 440 */
 else  /* Line: 441 */ {
bevt_76_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_78_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_77_tmpvar_phold);
bevl_cvar = bevt_75_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 443 */
bevl_syn = null;
bevt_81_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_80_tmpvar_phold == null) {
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 447 */ {
bevt_83_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_82_tmpvar_phold);
} /* Line: 448 */
 else  /* Line: 447 */ {
bevt_84_tmpvar_phold = bevl_cvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_84_tmpvar_phold != null && bevt_84_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_84_tmpvar_phold).bevi_bool) /* Line: 449 */ {
bevt_85_tmpvar_phold = bevl_cvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_tmpvar_phold);
} /* Line: 451 */
} /* Line: 447 */
if (bevl_syn == null) {
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 453 */ {
bevt_87_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_89_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_87_tmpvar_phold.bem_get_1(bevt_88_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 455 */ {
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_2));
bevt_91_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_92_tmpvar_phold, bevl_org);
throw new be.BELS_Base.BECS_ThrowBack(bevt_91_tmpvar_phold);
} /* Line: 456 */
 else  /* Line: 457 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 458 */
} /* Line: 455 */
} /* Line: 453 */
} /* Line: 427 */
if (bevl_ovar == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 462 */ {
bevt_94_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 462 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 462 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_95_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_95_tmpvar_phold != null && bevt_95_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_95_tmpvar_phold).bevi_bool) /* Line: 465 */ {
if (bevl_syn == null) {
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bels_3));
bevt_97_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_98_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_97_tmpvar_phold);
} /* Line: 468 */
bevt_100_tmpvar_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_101_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_101_tmpvar_phold);
if (bevt_99_tmpvar_phold != null && bevt_99_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_99_tmpvar_phold).bevi_bool) /* Line: 473 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 475 */
 else  /* Line: 473 */ {
bevt_103_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_103_tmpvar_phold == null) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 476 */ {
bevt_106_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_covariantReturnsGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 476 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 476 */
 else  /* Line: 476 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 476 */ {
bevl_castForSelf = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 477 */
} /* Line: 473 */
} /* Line: 473 */
 else  /* Line: 465 */ {
if (bevl_mtdc == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_108_tmpvar_phold = bevl_mtdc.bemd_2(583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_108_tmpvar_phold);
} /* Line: 480 */
 else  /* Line: 481 */ {
bevt_109_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_109_tmpvar_phold);
} /* Line: 482 */
} /* Line: 465 */
bevt_111_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_110_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_111_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 486 */ {
bevt_112_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_113_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_112_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_113_tmpvar_phold);
} /* Line: 488 */
 else  /* Line: 489 */ {
bevt_114_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 490 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 491 */
 else  /* Line: 492 */ {
bevl_ovnp = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 493 */
bevt_115_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 496 */ {
bevt_117_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_118_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_117_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_118_tmpvar_phold);
} /* Line: 498 */
 else  /* Line: 499 */ {
bevt_123_tmpvar_phold = bevo_0;
bevt_125_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_toString_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bem_add_1(bevt_124_tmpvar_phold);
bevt_126_tmpvar_phold = bevo_1;
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_add_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bem_add_1(bevt_127_tmpvar_phold);
bevt_119_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_120_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_119_tmpvar_phold);
} /* Line: 500 */
} /* Line: 496 */
if (bevl_castForSelf.bevi_bool) /* Line: 504 */ {
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_128_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_129_tmpvar_phold);
} /* Line: 506 */
} /* Line: 504 */
bevt_132_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_131_tmpvar_phold = bevt_132_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_131_tmpvar_phold == null) {
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 509 */ {
} /* Line: 509 */
} /* Line: 509 */
} /* Line: 423 */
} /* Line: 419 */
 else  /* Line: 410 */ {
bevt_135_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_136_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_6));
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_133_tmpvar_phold != null && bevt_133_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_133_tmpvar_phold).bevi_bool) /* Line: 514 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_138_tmpvar_phold = bevl_targ.bem_typenameGet_0();
bevt_139_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_138_tmpvar_phold.bevi_int == bevt_139_tmpvar_phold.bevi_int) {
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_137_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_141_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_140_tmpvar_phold = bevt_141_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_140_tmpvar_phold != null && bevt_140_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_140_tmpvar_phold).bevi_bool) /* Line: 517 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_143_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_145_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_144_tmpvar_phold = bevt_145_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_144_tmpvar_phold);
bevl_tvar = bevt_142_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 520 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_147_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 524 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 525 */
 else  /* Line: 526 */ {
bevt_149_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_151_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpvar_phold = bevt_149_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_150_tmpvar_phold);
bevl_tvar = bevt_148_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 527 */
bevt_154_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_153_tmpvar_phold == null) {
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_152_tmpvar_phold.bevi_bool) /* Line: 530 */ {
bevt_157_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpvar_phold = bevt_156_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_155_tmpvar_phold != null && bevt_155_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_155_tmpvar_phold).bevi_bool) /* Line: 530 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 530 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 530 */
 else  /* Line: 530 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 530 */ {
bevt_159_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 531 */ {
bevt_160_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_161_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_160_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_161_tmpvar_phold);
} /* Line: 533 */
 else  /* Line: 534 */ {
bevt_164_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_162_tmpvar_phold != null && bevt_162_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_162_tmpvar_phold).bevi_bool) /* Line: 537 */ {
bevt_166_tmpvar_phold = bevl_tvar.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_167_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_167_tmpvar_phold);
if (bevt_165_tmpvar_phold != null && bevt_165_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_165_tmpvar_phold).bevi_bool) /* Line: 538 */ {
bevt_168_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_168_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_169_tmpvar_phold);
} /* Line: 540 */
 else  /* Line: 541 */ {
bevt_170_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_170_tmpvar_phold);
bevt_172_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_171_tmpvar_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_172_tmpvar_phold);
if (bevt_171_tmpvar_phold != null && bevt_171_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_171_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_174_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_173_tmpvar_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_174_tmpvar_phold);
if (bevt_173_tmpvar_phold != null && bevt_173_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_173_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 543 */ {
bevt_175_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_176_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_175_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_176_tmpvar_phold);
} /* Line: 545 */
 else  /* Line: 546 */ {
bevt_181_tmpvar_phold = bevo_2;
bevt_182_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bem_add_1(bevt_182_tmpvar_phold);
bevt_183_tmpvar_phold = bevo_3;
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bem_add_1(bevt_183_tmpvar_phold);
bevt_184_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevt_184_tmpvar_phold);
bevt_177_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_178_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_177_tmpvar_phold);
} /* Line: 547 */
} /* Line: 543 */
} /* Line: 538 */
 else  /* Line: 550 */ {
bevt_185_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_185_tmpvar_phold);
bevt_189_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_186_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_187_tmpvar_phold);
if (bevt_186_tmpvar_phold != null && bevt_186_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_186_tmpvar_phold).bevi_bool) /* Line: 552 */ {
bevt_190_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_191_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_190_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_191_tmpvar_phold);
} /* Line: 554 */
 else  /* Line: 555 */ {
bevt_194_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_192_tmpvar_phold = bevt_193_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_192_tmpvar_phold);
bevt_196_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_195_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_196_tmpvar_phold);
if (bevt_195_tmpvar_phold != null && bevt_195_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_195_tmpvar_phold).bevi_bool) /* Line: 557 */ {
bevt_197_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_198_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_197_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_198_tmpvar_phold);
} /* Line: 559 */
 else  /* Line: 560 */ {
bevt_200_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bels_10));
bevt_199_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_200_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_199_tmpvar_phold);
} /* Line: 561 */
} /* Line: 557 */
} /* Line: 552 */
} /* Line: 537 */
} /* Line: 531 */
 else  /* Line: 566 */ {
bevt_201_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_202_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_201_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_202_tmpvar_phold);
} /* Line: 568 */
} /* Line: 530 */
 else  /* Line: 570 */ {
bevt_203_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_204_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_203_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_204_tmpvar_phold);
} /* Line: 571 */
} /* Line: 516 */
 else  /* Line: 573 */ {
bevt_205_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_205_tmpvar_phold.bem_firstGet_0();
bevt_207_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 576 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 577 */
 else  /* Line: 578 */ {
bevt_209_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_211_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_210_tmpvar_phold);
bevl_tvar = bevt_208_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 579 */
bevt_213_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 582 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 582 */ {
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_217_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_11));
bevt_214_tmpvar_phold = bevt_215_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_217_tmpvar_phold);
if (bevt_214_tmpvar_phold != null && bevt_214_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_214_tmpvar_phold).bevi_bool) /* Line: 582 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 582 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 582 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 582 */ {
bevt_218_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_219_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_218_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_219_tmpvar_phold);
} /* Line: 583 */
 else  /* Line: 584 */ {
bevt_220_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_221_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_220_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_221_tmpvar_phold);
bevt_223_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevt_223_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_222_tmpvar_phold != null && bevt_222_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_222_tmpvar_phold).bevi_bool) /* Line: 586 */ {
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_225_tmpvar_phold == null) {
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_224_tmpvar_phold.bevi_bool) /* Line: 587 */ {
bevt_228_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_12));
bevt_227_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_228_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_227_tmpvar_phold);
} /* Line: 588 */
bevt_230_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_229_tmpvar_phold);
bevt_231_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_233_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_232_tmpvar_phold = bevt_233_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_231_tmpvar_phold.bem_get_1(bevt_232_tmpvar_phold);
} /* Line: 591 */
 else  /* Line: 592 */ {
bevt_234_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_234_tmpvar_phold);
bevt_235_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_237_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_235_tmpvar_phold.bem_get_1(bevt_236_tmpvar_phold);
} /* Line: 594 */
if (bevl_mtdc == null) {
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 596 */ {
bevt_240_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_13));
bevt_239_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_239_tmpvar_phold);
} /* Line: 597 */
bevl_argSyns = (BEC_2_9_4_ContainerList) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 601 */ {
bevt_242_tmpvar_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_242_tmpvar_phold.bevi_int) {
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 601 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_243_tmpvar_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_243_tmpvar_phold.bevi_bool) /* Line: 603 */ {
if (bevl_nnode == null) {
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 604 */ {
bevt_246_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_14));
bevt_245_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_246_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_245_tmpvar_phold);
} /* Line: 605 */
 else  /* Line: 604 */ {
bevt_248_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_249_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_248_tmpvar_phold.bevi_int != bevt_249_tmpvar_phold.bevi_int) {
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_247_tmpvar_phold.bevi_bool) /* Line: 606 */ {
bevt_251_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_252_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_251_tmpvar_phold.bevi_int != bevt_252_tmpvar_phold.bevi_int) {
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_250_tmpvar_phold.bevi_bool) /* Line: 606 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 606 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 606 */
 else  /* Line: 606 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 606 */ {
bevt_255_tmpvar_phold = bevo_4;
bevt_257_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_256_tmpvar_phold = bevt_257_tmpvar_phold.bem_toString_0();
bevt_254_tmpvar_phold = bevt_255_tmpvar_phold.bem_add_1(bevt_256_tmpvar_phold);
bevt_253_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_254_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_253_tmpvar_phold);
} /* Line: 607 */
} /* Line: 604 */
bevt_259_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_260_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_259_tmpvar_phold.bevi_int == bevt_260_tmpvar_phold.bevi_int) {
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_258_tmpvar_phold.bevi_bool) /* Line: 609 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_262_tmpvar_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_262_tmpvar_phold.bevi_bool) {
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_261_tmpvar_phold.bevi_bool) /* Line: 611 */ {
bevt_263_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_264_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_263_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_264_tmpvar_phold);
bevt_266_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_265_tmpvar_phold = bevt_266_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_267_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_265_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_267_tmpvar_phold);
} /* Line: 613 */
 else  /* Line: 615 */ {
bevt_268_tmpvar_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_268_tmpvar_phold);
bevt_271_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_270_tmpvar_phold = bevl_syn.bem_castsTo_1(bevt_271_tmpvar_phold);
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 617 */ {
bevt_276_tmpvar_phold = bevo_5;
bevt_278_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bem_toString_0();
bevt_275_tmpvar_phold = bevt_276_tmpvar_phold.bem_add_1(bevt_277_tmpvar_phold);
bevt_279_tmpvar_phold = bevo_6;
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bem_add_1(bevt_279_tmpvar_phold);
bevt_281_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bem_toString_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bem_add_1(bevt_280_tmpvar_phold);
bevt_272_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_273_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_272_tmpvar_phold);
} /* Line: 618 */
} /* Line: 617 */
} /* Line: 611 */
} /* Line: 609 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 601 */
 else  /* Line: 601 */ {
break;
} /* Line: 601 */
} /* Line: 601 */
} /* Line: 601 */
} /* Line: 582 */
} /* Line: 410 */
} /* Line: 410 */
bevt_282_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_282_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_cposGet_0() {
return bevp_cpos;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {381, 381, 381, 381, 382, 382, 382, 382, 382, 382, 383, 383, 383, 386, 386, 386, 386, 387, 388, 388, 389, 389, 391, 391, 391, 391, 392, 394, 394, 394, 394, 395, 395, 396, 397, 397, 0, 397, 397, 398, 398, 398, 398, 399, 399, 410, 410, 410, 410, 411, 411, 413, 413, 414, 416, 416, 416, 416, 416, 419, 419, 420, 420, 420, 422, 423, 423, 423, 423, 0, 423, 423, 423, 423, 0, 0, 425, 425, 425, 427, 427, 427, 427, 428, 428, 429, 432, 432, 432, 432, 432, 435, 435, 435, 435, 436, 436, 438, 438, 440, 443, 443, 443, 443, 443, 446, 447, 447, 447, 447, 448, 448, 448, 449, 451, 451, 453, 453, 454, 454, 454, 454, 455, 455, 456, 456, 456, 458, 462, 462, 462, 0, 0, 0, 464, 465, 467, 467, 468, 468, 468, 473, 473, 473, 475, 476, 476, 476, 476, 476, 476, 0, 0, 0, 477, 479, 479, 480, 480, 482, 482, 486, 486, 488, 488, 488, 490, 491, 493, 495, 495, 496, 498, 498, 498, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 506, 506, 506, 509, 509, 509, 509, 514, 514, 514, 514, 515, 516, 516, 516, 516, 517, 517, 518, 520, 520, 520, 520, 520, 523, 524, 524, 525, 527, 527, 527, 527, 527, 530, 530, 530, 530, 530, 530, 530, 0, 0, 0, 531, 531, 533, 533, 533, 537, 537, 537, 538, 538, 538, 540, 540, 540, 542, 542, 543, 543, 0, 543, 543, 0, 0, 545, 545, 545, 547, 547, 547, 547, 547, 547, 547, 547, 547, 551, 551, 552, 552, 552, 552, 554, 554, 554, 556, 556, 556, 556, 557, 557, 559, 559, 559, 561, 561, 561, 568, 568, 568, 571, 571, 571, 574, 574, 576, 576, 577, 579, 579, 579, 579, 579, 582, 582, 0, 582, 582, 582, 582, 0, 0, 583, 583, 583, 585, 585, 585, 586, 586, 587, 587, 587, 587, 588, 588, 588, 590, 590, 590, 591, 591, 591, 591, 593, 593, 594, 594, 594, 594, 596, 596, 597, 597, 597, 599, 600, 601, 601, 601, 601, 602, 603, 604, 604, 605, 605, 605, 606, 606, 606, 606, 606, 606, 606, 606, 0, 0, 0, 607, 607, 607, 607, 607, 607, 609, 609, 609, 609, 610, 611, 611, 611, 612, 612, 612, 613, 613, 613, 613, 616, 616, 617, 617, 617, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 627, 601, 632, 632, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {344, 345, 346, 351, 352, 353, 354, 355, 356, 357, 359, 360, 361, 364, 365, 366, 371, 372, 373, 374, 375, 376, 378, 379, 380, 385, 386, 388, 389, 390, 395, 396, 397, 398, 399, 400, 400, 403, 405, 406, 407, 408, 413, 414, 415, 422, 423, 424, 425, 427, 428, 429, 430, 432, 435, 436, 437, 438, 439, 441, 442, 444, 445, 446, 449, 450, 451, 452, 457, 458, 461, 462, 463, 468, 469, 472, 476, 477, 478, 481, 482, 483, 488, 489, 490, 492, 495, 496, 497, 498, 499, 503, 504, 505, 510, 511, 512, 513, 514, 516, 519, 520, 521, 522, 523, 525, 526, 527, 528, 533, 534, 535, 536, 539, 541, 542, 545, 550, 551, 552, 553, 554, 555, 560, 561, 562, 563, 566, 571, 576, 577, 579, 582, 586, 589, 590, 592, 597, 598, 599, 600, 602, 603, 604, 606, 609, 610, 615, 616, 617, 618, 620, 623, 627, 630, 635, 640, 641, 642, 645, 646, 649, 650, 652, 653, 654, 657, 659, 662, 664, 665, 666, 668, 669, 670, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 686, 687, 688, 691, 692, 693, 698, 704, 705, 706, 707, 709, 710, 711, 712, 717, 718, 719, 721, 724, 725, 726, 727, 728, 730, 731, 732, 734, 737, 738, 739, 740, 741, 743, 744, 745, 750, 751, 752, 753, 755, 758, 762, 765, 766, 768, 769, 770, 773, 774, 775, 777, 778, 779, 781, 782, 783, 786, 787, 788, 789, 791, 794, 795, 797, 800, 804, 805, 806, 809, 810, 811, 812, 813, 814, 815, 816, 817, 822, 823, 824, 825, 826, 827, 829, 830, 831, 834, 835, 836, 837, 838, 839, 841, 842, 843, 846, 847, 848, 855, 856, 857, 861, 862, 863, 867, 868, 869, 870, 872, 875, 876, 877, 878, 879, 881, 882, 884, 887, 888, 889, 890, 892, 895, 899, 900, 901, 904, 905, 906, 907, 908, 910, 911, 912, 917, 918, 919, 920, 922, 923, 924, 925, 926, 927, 928, 931, 932, 933, 934, 935, 936, 938, 943, 944, 945, 946, 948, 949, 950, 953, 954, 959, 960, 961, 963, 968, 969, 970, 971, 974, 975, 976, 981, 982, 983, 984, 989, 990, 993, 997, 1000, 1001, 1002, 1003, 1004, 1005, 1008, 1009, 1010, 1015, 1016, 1017, 1018, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1033, 1034, 1035, 1036, 1037, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1054, 1055, 1065, 1066, 1069, 1072, 1076, 1079, 1083, 1086, 1090, 1093, 1097, 1100};
/* BEGIN LINEINFO 
assign 1 381 344
typenameGet 0 381 344
assign 1 381 345
CATCHGet 0 381 345
assign 1 381 346
equals 1 381 351
assign 1 382 352
containedGet 0 382 352
assign 1 382 353
firstGet 0 382 353
assign 1 382 354
containedGet 0 382 354
assign 1 382 355
firstGet 0 382 355
assign 1 382 356
heldGet 0 382 356
assign 1 382 357
isTypedGet 0 382 357
assign 1 383 359
new 0 383 359
assign 1 383 360
new 1 383 360
throw 1 383 361
assign 1 386 364
typenameGet 0 386 364
assign 1 386 365
CLASSGet 0 386 365
assign 1 386 366
equals 1 386 371
assign 1 387 372
assign 1 388 373
heldGet 0 388 373
assign 1 388 374
namepathGet 0 388 374
assign 1 389 375
heldGet 0 389 375
assign 1 389 376
synGet 0 389 376
assign 1 391 378
typenameGet 0 391 378
assign 1 391 379
METHODGet 0 391 379
assign 1 391 380
equals 1 391 385
assign 1 392 386
new 0 392 386
assign 1 394 388
typenameGet 0 394 388
assign 1 394 389
CALLGet 0 394 389
assign 1 394 390
equals 1 394 395
assign 1 395 396
heldGet 0 395 396
cposSet 1 395 397
assign 1 396 398
increment 0 396 398
assign 1 397 399
containedGet 0 397 399
assign 1 397 400
iteratorGet 0 0 400
assign 1 397 403
hasNextGet 0 397 403
assign 1 397 405
nextGet 0 397 405
assign 1 398 406
typenameGet 0 398 406
assign 1 398 407
VARGet 0 398 407
assign 1 398 408
equals 1 398 413
assign 1 399 414
heldGet 0 399 414
addCall 1 399 415
assign 1 410 422
heldGet 0 410 422
assign 1 410 423
orgNameGet 0 410 423
assign 1 410 424
new 0 410 424
assign 1 410 425
equals 1 410 425
assign 1 411 427
containedGet 0 411 427
assign 1 411 428
firstGet 0 411 428
assign 1 413 429
heldGet 0 413 429
assign 1 413 430
isDeclaredGet 0 413 430
assign 1 414 432
heldGet 0 414 432
assign 1 416 435
ptyMapGet 0 416 435
assign 1 416 436
heldGet 0 416 436
assign 1 416 437
nameGet 0 416 437
assign 1 416 438
get 1 416 438
assign 1 416 439
memSynGet 0 416 439
assign 1 419 441
isTypedGet 0 419 441
assign 1 419 442
not 0 419 442
assign 1 420 444
heldGet 0 420 444
assign 1 420 445
new 0 420 445
checkTypesSet 1 420 446
assign 1 422 449
secondGet 0 422 449
assign 1 423 450
typenameGet 0 423 450
assign 1 423 451
TRUEGet 0 423 451
assign 1 423 452
equals 1 423 457
assign 1 0 458
assign 1 423 461
typenameGet 0 423 461
assign 1 423 462
FALSEGet 0 423 462
assign 1 423 463
equals 1 423 468
assign 1 0 469
assign 1 0 472
assign 1 425 476
heldGet 0 425 476
assign 1 425 477
new 0 425 477
checkTypesSet 1 425 478
assign 1 427 481
typenameGet 0 427 481
assign 1 427 482
VARGet 0 427 482
assign 1 427 483
equals 1 427 488
assign 1 428 489
heldGet 0 428 489
assign 1 428 490
isDeclaredGet 0 428 490
assign 1 429 492
heldGet 0 429 492
assign 1 432 495
ptyMapGet 0 432 495
assign 1 432 496
heldGet 0 432 496
assign 1 432 497
nameGet 0 432 497
assign 1 432 498
get 1 432 498
assign 1 432 499
memSynGet 0 432 499
assign 1 435 503
typenameGet 0 435 503
assign 1 435 504
CALLGet 0 435 504
assign 1 435 505
equals 1 435 510
assign 1 436 511
containedGet 0 436 511
assign 1 436 512
firstGet 0 436 512
assign 1 438 513
heldGet 0 438 513
assign 1 438 514
isDeclaredGet 0 438 514
assign 1 440 516
heldGet 0 440 516
assign 1 443 519
ptyMapGet 0 443 519
assign 1 443 520
heldGet 0 443 520
assign 1 443 521
nameGet 0 443 521
assign 1 443 522
get 1 443 522
assign 1 443 523
memSynGet 0 443 523
assign 1 446 525
assign 1 447 526
heldGet 0 447 526
assign 1 447 527
newNpGet 0 447 527
assign 1 447 528
def 1 447 533
assign 1 448 534
heldGet 0 448 534
assign 1 448 535
newNpGet 0 448 535
assign 1 448 536
getSynNp 1 448 536
assign 1 449 539
isTypedGet 0 449 539
assign 1 451 541
namepathGet 0 451 541
assign 1 451 542
getSynNp 1 451 542
assign 1 453 545
def 1 453 550
assign 1 454 551
mtdMapGet 0 454 551
assign 1 454 552
heldGet 0 454 552
assign 1 454 553
nameGet 0 454 553
assign 1 454 554
get 1 454 554
assign 1 455 555
undef 1 455 560
assign 1 456 561
new 0 456 561
assign 1 456 562
new 2 456 562
throw 1 456 563
assign 1 458 566
rsynGet 0 458 566
assign 1 462 571
def 1 462 576
assign 1 462 577
isTypedGet 0 462 577
assign 1 0 579
assign 1 0 582
assign 1 0 586
assign 1 464 589
new 0 464 589
assign 1 465 590
isSelfGet 0 465 590
assign 1 467 592
undef 1 467 597
assign 1 468 598
new 0 468 598
assign 1 468 599
new 1 468 599
throw 1 468 600
assign 1 473 602
originGet 0 473 602
assign 1 473 603
namepathGet 0 473 603
assign 1 473 604
notEquals 1 473 604
assign 1 475 606
new 0 475 606
assign 1 476 609
emitCommonGet 0 476 609
assign 1 476 610
def 1 476 615
assign 1 476 616
emitCommonGet 0 476 616
assign 1 476 617
covariantReturnsGet 0 476 617
assign 1 476 618
not 0 476 618
assign 1 0 620
assign 1 0 623
assign 1 0 627
assign 1 477 630
new 0 477 630
assign 1 479 635
def 1 479 640
assign 1 480 641
getEmitReturnType 2 480 641
assign 1 480 642
getSynNp 1 480 642
assign 1 482 645
namepathGet 0 482 645
assign 1 482 646
getSynNp 1 482 646
assign 1 486 649
namepathGet 0 486 649
assign 1 486 650
castsTo 1 486 650
assign 1 488 652
heldGet 0 488 652
assign 1 488 653
new 0 488 653
checkTypesSet 1 488 654
assign 1 490 657
isSelfGet 0 490 657
assign 1 491 659
namepathGet 0 491 659
assign 1 493 662
namepathGet 0 493 662
assign 1 495 664
namepathGet 0 495 664
assign 1 495 665
getSynNp 1 495 665
assign 1 496 666
castsTo 1 496 666
assign 1 498 668
heldGet 0 498 668
assign 1 498 669
new 0 498 669
checkTypesSet 1 498 670
assign 1 500 673
new 0 500 673
assign 1 500 674
namepathGet 0 500 674
assign 1 500 675
toString 0 500 675
assign 1 500 676
add 1 500 676
assign 1 500 677
new 0 500 677
assign 1 500 678
add 1 500 678
assign 1 500 679
toString 0 500 679
assign 1 500 680
add 1 500 680
assign 1 500 681
new 2 500 681
throw 1 500 682
assign 1 506 686
heldGet 0 506 686
assign 1 506 687
new 0 506 687
checkTypesSet 1 506 688
assign 1 509 691
heldGet 0 509 691
assign 1 509 692
namepathGet 0 509 692
assign 1 509 693
def 1 509 698
assign 1 514 704
heldGet 0 514 704
assign 1 514 705
orgNameGet 0 514 705
assign 1 514 706
new 0 514 706
assign 1 514 707
equals 1 514 707
assign 1 515 709
secondGet 0 515 709
assign 1 516 710
typenameGet 0 516 710
assign 1 516 711
VARGet 0 516 711
assign 1 516 712
equals 1 516 717
assign 1 517 718
heldGet 0 517 718
assign 1 517 719
isDeclaredGet 0 517 719
assign 1 518 721
heldGet 0 518 721
assign 1 520 724
ptyMapGet 0 520 724
assign 1 520 725
heldGet 0 520 725
assign 1 520 726
nameGet 0 520 726
assign 1 520 727
get 1 520 727
assign 1 520 728
memSynGet 0 520 728
assign 1 523 730
scopeGet 0 523 730
assign 1 524 731
heldGet 0 524 731
assign 1 524 732
isDeclaredGet 0 524 732
assign 1 525 734
heldGet 0 525 734
assign 1 527 737
ptyMapGet 0 527 737
assign 1 527 738
heldGet 0 527 738
assign 1 527 739
nameGet 0 527 739
assign 1 527 740
get 1 527 740
assign 1 527 741
memSynGet 0 527 741
assign 1 530 743
heldGet 0 530 743
assign 1 530 744
rtypeGet 0 530 744
assign 1 530 745
def 1 530 750
assign 1 530 751
heldGet 0 530 751
assign 1 530 752
rtypeGet 0 530 752
assign 1 530 753
isTypedGet 0 530 753
assign 1 0 755
assign 1 0 758
assign 1 0 762
assign 1 531 765
isTypedGet 0 531 765
assign 1 531 766
not 0 531 766
assign 1 533 768
heldGet 0 533 768
assign 1 533 769
new 0 533 769
checkTypesSet 1 533 770
assign 1 537 773
heldGet 0 537 773
assign 1 537 774
rtypeGet 0 537 774
assign 1 537 775
isSelfGet 0 537 775
assign 1 538 777
nameGet 0 538 777
assign 1 538 778
new 0 538 778
assign 1 538 779
equals 1 538 779
assign 1 540 781
heldGet 0 540 781
assign 1 540 782
new 0 540 782
checkTypesSet 1 540 783
assign 1 542 786
namepathGet 0 542 786
assign 1 542 787
getSynNp 1 542 787
assign 1 543 788
namepathGet 0 543 788
assign 1 543 789
castsTo 1 543 789
assign 1 0 791
assign 1 543 794
namepathGet 0 543 794
assign 1 543 795
castsTo 1 543 795
assign 1 0 797
assign 1 0 800
assign 1 545 804
heldGet 0 545 804
assign 1 545 805
new 0 545 805
checkTypesSet 1 545 806
assign 1 547 809
new 0 547 809
assign 1 547 810
namepathGet 0 547 810
assign 1 547 811
add 1 547 811
assign 1 547 812
new 0 547 812
assign 1 547 813
add 1 547 813
assign 1 547 814
namepathGet 0 547 814
assign 1 547 815
add 1 547 815
assign 1 547 816
new 2 547 816
throw 1 547 817
assign 1 551 822
namepathGet 0 551 822
assign 1 551 823
getSynNp 1 551 823
assign 1 552 824
heldGet 0 552 824
assign 1 552 825
rtypeGet 0 552 825
assign 1 552 826
namepathGet 0 552 826
assign 1 552 827
castsTo 1 552 827
assign 1 554 829
heldGet 0 554 829
assign 1 554 830
new 0 554 830
checkTypesSet 1 554 831
assign 1 556 834
heldGet 0 556 834
assign 1 556 835
rtypeGet 0 556 835
assign 1 556 836
namepathGet 0 556 836
assign 1 556 837
getSynNp 1 556 837
assign 1 557 838
namepathGet 0 557 838
assign 1 557 839
castsTo 1 557 839
assign 1 559 841
heldGet 0 559 841
assign 1 559 842
new 0 559 842
checkTypesSet 1 559 843
assign 1 561 846
new 0 561 846
assign 1 561 847
new 2 561 847
throw 1 561 848
assign 1 568 855
heldGet 0 568 855
assign 1 568 856
new 0 568 856
checkTypesSet 1 568 857
assign 1 571 861
heldGet 0 571 861
assign 1 571 862
new 0 571 862
checkTypesSet 1 571 863
assign 1 574 867
containedGet 0 574 867
assign 1 574 868
firstGet 0 574 868
assign 1 576 869
heldGet 0 576 869
assign 1 576 870
isDeclaredGet 0 576 870
assign 1 577 872
heldGet 0 577 872
assign 1 579 875
ptyMapGet 0 579 875
assign 1 579 876
heldGet 0 579 876
assign 1 579 877
nameGet 0 579 877
assign 1 579 878
get 1 579 878
assign 1 579 879
memSynGet 0 579 879
assign 1 582 881
isTypedGet 0 582 881
assign 1 582 882
not 0 582 882
assign 1 0 884
assign 1 582 887
heldGet 0 582 887
assign 1 582 888
orgNameGet 0 582 888
assign 1 582 889
new 0 582 889
assign 1 582 890
equals 1 582 890
assign 1 0 892
assign 1 0 895
assign 1 583 899
heldGet 0 583 899
assign 1 583 900
new 0 583 900
checkTypesSet 1 583 901
assign 1 585 904
heldGet 0 585 904
assign 1 585 905
new 0 585 905
checkTypesSet 1 585 906
assign 1 586 907
heldGet 0 586 907
assign 1 586 908
isConstructGet 0 586 908
assign 1 587 910
heldGet 0 587 910
assign 1 587 911
newNpGet 0 587 911
assign 1 587 912
undef 1 587 917
assign 1 588 918
new 0 588 918
assign 1 588 919
new 1 588 919
throw 1 588 920
assign 1 590 922
heldGet 0 590 922
assign 1 590 923
newNpGet 0 590 923
assign 1 590 924
getSynNp 1 590 924
assign 1 591 925
mtdMapGet 0 591 925
assign 1 591 926
heldGet 0 591 926
assign 1 591 927
nameGet 0 591 927
assign 1 591 928
get 1 591 928
assign 1 593 931
namepathGet 0 593 931
assign 1 593 932
getSynNp 1 593 932
assign 1 594 933
mtdMapGet 0 594 933
assign 1 594 934
heldGet 0 594 934
assign 1 594 935
nameGet 0 594 935
assign 1 594 936
get 1 594 936
assign 1 596 938
undef 1 596 943
assign 1 597 944
new 0 597 944
assign 1 597 945
new 2 597 945
throw 1 597 946
assign 1 599 948
argSynsGet 0 599 948
assign 1 600 949
nextPeerGet 0 600 949
assign 1 601 950
new 0 601 950
assign 1 601 953
lengthGet 0 601 953
assign 1 601 954
lesser 1 601 959
assign 1 602 960
get 1 602 960
assign 1 603 961
isTypedGet 0 603 961
assign 1 604 963
undef 1 604 968
assign 1 605 969
new 0 605 969
assign 1 605 970
new 2 605 970
throw 1 605 971
assign 1 606 974
typenameGet 0 606 974
assign 1 606 975
VARGet 0 606 975
assign 1 606 976
notEquals 1 606 981
assign 1 606 982
typenameGet 0 606 982
assign 1 606 983
NULLGet 0 606 983
assign 1 606 984
notEquals 1 606 989
assign 1 0 990
assign 1 0 993
assign 1 0 997
assign 1 607 1000
new 0 607 1000
assign 1 607 1001
typenameGet 0 607 1001
assign 1 607 1002
toString 0 607 1002
assign 1 607 1003
add 1 607 1003
assign 1 607 1004
new 2 607 1004
throw 1 607 1005
assign 1 609 1008
typenameGet 0 609 1008
assign 1 609 1009
VARGet 0 609 1009
assign 1 609 1010
equals 1 609 1015
assign 1 610 1016
heldGet 0 610 1016
assign 1 611 1017
isTypedGet 0 611 1017
assign 1 611 1018
not 0 611 1023
assign 1 612 1024
heldGet 0 612 1024
assign 1 612 1025
new 0 612 1025
checkTypesSet 1 612 1026
assign 1 613 1027
heldGet 0 613 1027
assign 1 613 1028
argCastsGet 0 613 1028
assign 1 613 1029
namepathGet 0 613 1029
put 2 613 1030
assign 1 616 1033
namepathGet 0 616 1033
assign 1 616 1034
getSynNp 1 616 1034
assign 1 617 1035
namepathGet 0 617 1035
assign 1 617 1036
castsTo 1 617 1036
assign 1 617 1037
not 0 617 1037
assign 1 618 1039
new 0 618 1039
assign 1 618 1040
namepathGet 0 618 1040
assign 1 618 1041
toString 0 618 1041
assign 1 618 1042
add 1 618 1042
assign 1 618 1043
new 0 618 1043
assign 1 618 1044
add 1 618 1044
assign 1 618 1045
namepathGet 0 618 1045
assign 1 618 1046
toString 0 618 1046
assign 1 618 1047
add 1 618 1047
assign 1 618 1048
new 2 618 1048
throw 1 618 1049
assign 1 627 1054
nextPeerGet 0 627 1054
assign 1 601 1055
increment 0 601 1055
assign 1 632 1065
nextDescendGet 0 632 1065
return 1 632 1066
return 1 0 1069
assign 1 0 1072
return 1 0 1076
assign 1 0 1079
return 1 0 1083
assign 1 0 1086
return 1 0 1090
assign 1 0 1093
return 1 0 1097
assign 1 0 1100
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2117282045: return bem_cposSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
}
