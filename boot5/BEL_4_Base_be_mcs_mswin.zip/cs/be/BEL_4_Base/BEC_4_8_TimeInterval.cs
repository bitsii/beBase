namespace be.BEL_4_Base {

using System;
using System.Threading;
/* IO:File: source/base/Time.be */
public class BEC_4_8_TimeInterval : BEC_6_6_SystemObject {
public BEC_4_8_TimeInterval() { }
static BEC_4_8_TimeInterval() { }

    public static readonly DateTime epochStart = new DateTime
    (1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    private static byte[] becc_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(60));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(60));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3600));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(86400));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3600));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(86400));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1000));
private static BEC_4_3_MathInt bevo_7 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1000));
private static BEC_4_3_MathInt bevo_8 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_10 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_11 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1000));
private static BEC_4_3_MathInt bevo_12 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_13 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_14 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_15 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_16 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1000));
private static BEC_4_3_MathInt bevo_17 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3600));
private static byte[] bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 10));
private static byte[] bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 13));
private static byte[] bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 13));
private static byte[] bels_3 = {0x3A};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_4, 13));
private static byte[] bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_5, 13));
public static new BEC_4_8_TimeInterval bevs_inst;
public BEC_4_3_MathInt bevp_secs;
public BEC_4_3_MathInt bevp_millis;
public virtual BEC_4_8_TimeInterval bem_now_0() {
bevp_secs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevp_millis = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();

        long ctm = (long) (DateTime.UtcNow - epochStart).TotalMilliseconds;
        bevp_secs.bevi_int = (int) (ctm / 1000);
        bevp_millis.bevi_int = (int) (ctm % 1000);
        return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_new_0() {
bevp_secs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_millis = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_new_2(BEC_4_3_MathInt beva__secs, BEC_4_3_MathInt beva__millis) {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
this.bem_carryMillis_0();
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_4_8_TimeInterval bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_secondInMinuteGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_secs.bem_modulus_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_millisecondInSecondGet_0() {
return bevp_millis;
} /*method end*/
public virtual BEC_4_3_MathInt bem_minutesGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = bevp_secs.bem_divide_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_secondsGet_0() {
return bevp_secs;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_secondsSet_1(BEC_4_3_MathInt beva__secs) {
bevp_secs = beva__secs;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_millisecondsGet_0() {
return bevp_millis;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_millisecondsSet_1(BEC_4_3_MathInt beva__millis) {
bevp_millis = beva__millis;
this.bem_carryMillis_0();
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_addHours_1(BEC_4_3_MathInt beva_hours) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_2;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_addDays_1(BEC_4_3_MathInt beva_days) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_subtractHours_1(BEC_4_3_MathInt beva_hours) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_subtractDays_1(BEC_4_3_MathInt beva_days) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_5;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_addSeconds_1(BEC_4_3_MathInt beva__secs) {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addMilliseconds_1(BEC_4_3_MathInt beva__millis) {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
this.bem_carryMillis_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_carryMillis_0() {
BEC_4_3_MathInt bevl_mmod = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevl_mmod.bem_notEquals_1(bevp_millis);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 230 */ {
bevt_5_tmpvar_phold = bevo_7;
bevt_4_tmpvar_phold = bevp_millis.bem_divide_1(bevt_5_tmpvar_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpvar_phold);
bevp_millis = bevl_mmod;
} /* Line: 232 */
bevt_7_tmpvar_phold = bevo_8;
bevt_6_tmpvar_phold = bevp_millis.bem_lesser_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_9_tmpvar_phold = bevo_9;
bevt_8_tmpvar_phold = bevp_secs.bem_greater_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevt_10_tmpvar_phold = bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_11;
bevp_millis = bevt_11_tmpvar_phold.bem_add_1(bevp_millis);
} /* Line: 236 */
 else  /* Line: 234 */ {
bevt_13_tmpvar_phold = bevo_12;
bevt_12_tmpvar_phold = bevp_millis.bem_greater_1(bevt_13_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_15_tmpvar_phold = bevo_13;
bevt_14_tmpvar_phold = bevp_secs.bem_lesser_1(bevt_15_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 237 */ {
bevt_16_tmpvar_phold = bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = bevo_15;
bevt_19_tmpvar_phold = bevo_16;
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_subtract_1(bevt_19_tmpvar_phold);
bevp_millis = bevt_17_tmpvar_phold.bem_add_1(bevp_millis);
} /* Line: 239 */
} /* Line: 234 */
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_subtractSeconds_1(BEC_4_3_MathInt beva__secs) {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_4_3_MathInt beva__millis) {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
this.bem_carryMillis_0();
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_add_1(BEC_4_8_TimeInterval beva_other) {
BEC_4_3_MathInt bevl__secs = null;
BEC_4_3_MathInt bevl__millis = null;
BEC_4_8_TimeInterval bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpvar_phold);
bevl_res = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_subtract_1(BEC_4_8_TimeInterval beva_other) {
BEC_4_3_MathInt bevl__secs = null;
BEC_4_3_MathInt bevl__millis = null;
BEC_4_8_TimeInterval bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_res = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_greater_1(BEC_4_8_TimeInterval beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_1_tmpvar_phold = bevp_secs.bem_greater_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_3_tmpvar_phold = bevp_secs.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
bevt_5_tmpvar_phold = bevp_millis.bem_greater_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 269 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 269 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 269 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 270 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_lesser_1(BEC_4_8_TimeInterval beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_1_tmpvar_phold = bevp_secs.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_3_tmpvar_phold = bevp_secs.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
bevt_5_tmpvar_phold = bevp_millis.bem_lesser_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 276 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 277 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_greaterEquals_1(BEC_4_8_TimeInterval beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_1_tmpvar_phold = bevp_secs.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_3_tmpvar_phold = bevp_secs.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
bevt_5_tmpvar_phold = bevp_millis.bem_greaterEquals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
 else  /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 283 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 284 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_lesserEquals_1(BEC_4_8_TimeInterval beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_1_tmpvar_phold = bevp_secs.bem_lesserEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_3_tmpvar_phold = bevp_secs.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
bevt_5_tmpvar_phold = bevp_millis.bem_lesserEquals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 291 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_sameClass_1(beva_other);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_4_tmpvar_phold = beva_other.bemd_0(739051419, BEL_4_Base.bevn_secsGet_0);
bevt_3_tmpvar_phold = bevp_secs.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
 else  /* Line: 297 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 297 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1914769121, BEL_4_Base.bevn_millisGet_0);
bevt_5_tmpvar_phold = bevp_millis.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
 else  /* Line: 297 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 297 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 298 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = this.bem_sameClass_1(beva_other);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(739051419, BEL_4_Base.bevn_secsGet_0);
bevt_4_tmpvar_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_7_tmpvar_phold = beva_other.bemd_0(1914769121, BEL_4_Base.bevn_millisGet_0);
bevt_6_tmpvar_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 305 */
bevt_9_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_offByHour_1(BEC_4_8_TimeInterval beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
if (beva_other == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 312 */ {
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 312 */
bevt_3_tmpvar_phold = beva_other.bem_millisGet_0();
bevt_2_tmpvar_phold = bevp_millis.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_7_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_6_tmpvar_phold = bevp_secs.bem_subtract_1(bevt_7_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_abs_0();
bevt_8_tmpvar_phold = bevo_17;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_equals_1(bevt_8_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_9_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_9_tmpvar_phold;
} /* Line: 315 */
} /* Line: 314 */
bevt_10_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_toStringMinutes_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_6_tmpvar_phold = this.bem_minutesGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_toString_0();
bevt_7_tmpvar_phold = bevo_18;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = this.bem_secondInMinuteGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevp_millis);
bevt_10_tmpvar_phold = bevo_20;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_toShortString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_secs.bem_toString_0();
bevt_3_tmpvar_phold = bevo_21;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_millis.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_secs.bem_toString_0();
bevt_4_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevp_millis);
bevt_5_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_secsGet_0() {
return bevp_secs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_secsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_secs = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_millisGet_0() {
return bevp_millis;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_millisSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_millis = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {119, 120, 157, 158, 164, 165, 166, 170, 170, 174, 174, 174, 178, 182, 182, 182, 186, 190, 194, 198, 199, 203, 203, 203, 207, 207, 207, 211, 211, 211, 215, 215, 215, 220, 224, 225, 229, 229, 230, 231, 231, 231, 232, 234, 234, 234, 234, 0, 0, 0, 235, 235, 236, 236, 237, 237, 237, 237, 0, 0, 0, 238, 238, 239, 239, 239, 239, 244, 248, 249, 253, 253, 254, 254, 255, 256, 257, 261, 261, 262, 262, 263, 264, 265, 269, 269, 0, 269, 269, 269, 269, 0, 0, 0, 0, 0, 270, 270, 272, 272, 276, 276, 0, 276, 276, 276, 276, 0, 0, 0, 0, 0, 277, 277, 279, 279, 283, 283, 0, 283, 283, 283, 283, 0, 0, 0, 0, 0, 284, 284, 286, 286, 290, 290, 0, 290, 290, 290, 290, 0, 0, 0, 0, 0, 291, 291, 293, 293, 297, 297, 297, 0, 0, 0, 297, 297, 0, 0, 0, 298, 298, 300, 300, 304, 304, 0, 304, 304, 0, 0, 0, 304, 304, 0, 0, 305, 305, 307, 307, 312, 312, 312, 312, 313, 313, 314, 314, 314, 314, 314, 315, 315, 318, 318, 322, 322, 322, 322, 322, 322, 322, 322, 322, 322, 322, 322, 326, 326, 326, 326, 326, 326, 330, 330, 330, 330, 330, 330, 330, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {48, 49, 57, 58, 62, 63, 64, 69, 70, 75, 76, 77, 80, 85, 86, 87, 90, 93, 97, 100, 101, 107, 108, 109, 115, 116, 117, 123, 124, 125, 131, 132, 133, 137, 141, 142, 167, 168, 169, 171, 172, 173, 174, 176, 177, 179, 180, 182, 185, 189, 192, 193, 194, 195, 198, 199, 201, 202, 204, 207, 211, 214, 215, 216, 217, 218, 219, 225, 229, 230, 239, 240, 241, 242, 243, 244, 245, 253, 254, 255, 256, 257, 258, 259, 271, 272, 274, 277, 278, 280, 281, 283, 286, 290, 293, 296, 300, 301, 303, 304, 316, 317, 319, 322, 323, 325, 326, 328, 331, 335, 338, 341, 345, 346, 348, 349, 361, 362, 364, 367, 368, 370, 371, 373, 376, 380, 383, 386, 390, 391, 393, 394, 406, 407, 409, 412, 413, 415, 416, 418, 421, 425, 428, 431, 435, 436, 438, 439, 451, 453, 454, 456, 459, 463, 466, 467, 469, 472, 476, 479, 480, 482, 483, 496, 497, 499, 502, 503, 505, 508, 512, 515, 516, 518, 521, 525, 526, 528, 529, 543, 548, 549, 550, 552, 553, 555, 556, 557, 558, 559, 561, 562, 565, 566, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 599, 600, 601, 602, 603, 604, 613, 614, 615, 616, 617, 618, 619, 622, 625, 629, 632};
/* BEGIN LINEINFO 
assign 1 119 48
new 0 119 48
assign 1 120 49
new 0 120 49
assign 1 157 57
new 0 157 57
assign 1 158 58
new 0 158 58
assign 1 164 62
assign 1 165 63
carryMillis 0 166 64
assign 1 170 69
new 2 170 69
return 1 170 70
assign 1 174 75
new 0 174 75
assign 1 174 76
modulus 1 174 76
return 1 174 77
return 1 178 80
assign 1 182 85
new 0 182 85
assign 1 182 86
divide 1 182 86
return 1 182 87
return 1 186 90
assign 1 190 93
return 1 194 97
assign 1 198 100
carryMillis 0 199 101
assign 1 203 107
new 0 203 107
assign 1 203 108
multiply 1 203 108
assign 1 203 109
add 1 203 109
assign 1 207 115
new 0 207 115
assign 1 207 116
multiply 1 207 116
assign 1 207 117
add 1 207 117
assign 1 211 123
new 0 211 123
assign 1 211 124
multiply 1 211 124
assign 1 211 125
subtract 1 211 125
assign 1 215 131
new 0 215 131
assign 1 215 132
multiply 1 215 132
assign 1 215 133
subtract 1 215 133
assign 1 220 137
add 1 220 137
assign 1 224 141
add 1 224 141
carryMillis 0 225 142
assign 1 229 167
new 0 229 167
assign 1 229 168
modulus 1 229 168
assign 1 230 169
notEquals 1 230 169
assign 1 231 171
new 0 231 171
assign 1 231 172
divide 1 231 172
assign 1 231 173
add 1 231 173
assign 1 232 174
assign 1 234 176
new 0 234 176
assign 1 234 177
lesser 1 234 177
assign 1 234 179
new 0 234 179
assign 1 234 180
greater 1 234 180
assign 1 0 182
assign 1 0 185
assign 1 0 189
assign 1 235 192
new 0 235 192
assign 1 235 193
subtract 1 235 193
assign 1 236 194
new 0 236 194
assign 1 236 195
add 1 236 195
assign 1 237 198
new 0 237 198
assign 1 237 199
greater 1 237 199
assign 1 237 201
new 0 237 201
assign 1 237 202
lesser 1 237 202
assign 1 0 204
assign 1 0 207
assign 1 0 211
assign 1 238 214
new 0 238 214
assign 1 238 215
add 1 238 215
assign 1 239 216
new 0 239 216
assign 1 239 217
new 0 239 217
assign 1 239 218
subtract 1 239 218
assign 1 239 219
add 1 239 219
assign 1 244 225
subtract 1 244 225
assign 1 248 229
subtract 1 248 229
carryMillis 0 249 230
assign 1 253 239
secsGet 0 253 239
assign 1 253 240
add 1 253 240
assign 1 254 241
millisGet 0 254 241
assign 1 254 242
add 1 254 242
assign 1 255 243
new 2 255 243
carryMillis 0 256 244
return 1 257 245
assign 1 261 253
secsGet 0 261 253
assign 1 261 254
subtract 1 261 254
assign 1 262 255
millisGet 0 262 255
assign 1 262 256
subtract 1 262 256
assign 1 263 257
new 2 263 257
carryMillis 0 264 258
return 1 265 259
assign 1 269 271
secsGet 0 269 271
assign 1 269 272
greater 1 269 272
assign 1 0 274
assign 1 269 277
secsGet 0 269 277
assign 1 269 278
equals 1 269 278
assign 1 269 280
millisGet 0 269 280
assign 1 269 281
greater 1 269 281
assign 1 0 283
assign 1 0 286
assign 1 0 290
assign 1 0 293
assign 1 0 296
assign 1 270 300
new 0 270 300
return 1 270 301
assign 1 272 303
new 0 272 303
return 1 272 304
assign 1 276 316
secsGet 0 276 316
assign 1 276 317
lesser 1 276 317
assign 1 0 319
assign 1 276 322
secsGet 0 276 322
assign 1 276 323
equals 1 276 323
assign 1 276 325
millisGet 0 276 325
assign 1 276 326
lesser 1 276 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 0 338
assign 1 0 341
assign 1 277 345
new 0 277 345
return 1 277 346
assign 1 279 348
new 0 279 348
return 1 279 349
assign 1 283 361
secsGet 0 283 361
assign 1 283 362
greaterEquals 1 283 362
assign 1 0 364
assign 1 283 367
secsGet 0 283 367
assign 1 283 368
equals 1 283 368
assign 1 283 370
millisGet 0 283 370
assign 1 283 371
greaterEquals 1 283 371
assign 1 0 373
assign 1 0 376
assign 1 0 380
assign 1 0 383
assign 1 0 386
assign 1 284 390
new 0 284 390
return 1 284 391
assign 1 286 393
new 0 286 393
return 1 286 394
assign 1 290 406
secsGet 0 290 406
assign 1 290 407
lesserEquals 1 290 407
assign 1 0 409
assign 1 290 412
secsGet 0 290 412
assign 1 290 413
equals 1 290 413
assign 1 290 415
millisGet 0 290 415
assign 1 290 416
lesserEquals 1 290 416
assign 1 0 418
assign 1 0 421
assign 1 0 425
assign 1 0 428
assign 1 0 431
assign 1 291 435
new 0 291 435
return 1 291 436
assign 1 293 438
new 0 293 438
return 1 293 439
assign 1 297 451
sameClass 1 297 451
assign 1 297 453
secsGet 0 297 453
assign 1 297 454
equals 1 297 454
assign 1 0 456
assign 1 0 459
assign 1 0 463
assign 1 297 466
millisGet 0 297 466
assign 1 297 467
equals 1 297 467
assign 1 0 469
assign 1 0 472
assign 1 0 476
assign 1 298 479
new 0 298 479
return 1 298 480
assign 1 300 482
new 0 300 482
return 1 300 483
assign 1 304 496
sameClass 1 304 496
assign 1 304 497
not 0 304 497
assign 1 0 499
assign 1 304 502
secsGet 0 304 502
assign 1 304 503
notEquals 1 304 503
assign 1 0 505
assign 1 0 508
assign 1 0 512
assign 1 304 515
millisGet 0 304 515
assign 1 304 516
notEquals 1 304 516
assign 1 0 518
assign 1 0 521
assign 1 305 525
new 0 305 525
return 1 305 526
assign 1 307 528
new 0 307 528
return 1 307 529
assign 1 312 543
undef 1 312 548
assign 1 312 549
new 0 312 549
return 1 312 550
assign 1 313 552
millisGet 0 313 552
assign 1 313 553
equals 1 313 553
assign 1 314 555
secsGet 0 314 555
assign 1 314 556
subtract 1 314 556
assign 1 314 557
abs 0 314 557
assign 1 314 558
new 0 314 558
assign 1 314 559
equals 1 314 559
assign 1 315 561
new 0 315 561
return 1 315 562
assign 1 318 565
new 0 318 565
return 1 318 566
assign 1 322 580
minutesGet 0 322 580
assign 1 322 581
toString 0 322 581
assign 1 322 582
new 0 322 582
assign 1 322 583
add 1 322 583
assign 1 322 584
secondInMinuteGet 0 322 584
assign 1 322 585
add 1 322 585
assign 1 322 586
new 0 322 586
assign 1 322 587
add 1 322 587
assign 1 322 588
add 1 322 588
assign 1 322 589
new 0 322 589
assign 1 322 590
add 1 322 590
return 1 322 591
assign 1 326 599
toString 0 326 599
assign 1 326 600
new 0 326 600
assign 1 326 601
add 1 326 601
assign 1 326 602
toString 0 326 602
assign 1 326 603
add 1 326 603
return 1 326 604
assign 1 330 613
toString 0 330 613
assign 1 330 614
new 0 330 614
assign 1 330 615
add 1 330 615
assign 1 330 616
add 1 330 616
assign 1 330 617
new 0 330 617
assign 1 330 618
add 1 330 618
return 1 330 619
return 1 0 622
assign 1 0 625
return 1 0 629
assign 1 0 632
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 284498275: return bem_toShortString_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 316166507: return bem_millisecondsGet_0();
case 314718434: return bem_print_0();
case 888746948: return bem_toStringMinutes_0();
case 478622533: return bem_sourceFileNameGet_0();
case 169908808: return bem_secondsGet_0();
case 1914769121: return bem_millisGet_0();
case 1490855437: return bem_millisecondInSecondGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 324838054: return bem_secondInMinuteGet_0();
case 24587954: return bem_carryMillis_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 864467992: return bem_minutesGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 105011463: return bem_now_0();
case 1354714650: return bem_copy_0();
case 739051419: return bem_secsGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 979186229: return bem_greaterEquals_1((BEC_4_8_TimeInterval) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2090192440: return bem_lesser_1((BEC_4_8_TimeInterval) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 81310150: return bem_subtract_1((BEC_4_8_TimeInterval) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_4_8_TimeInterval) bevd_0);
case 92659731: return bem_add_1((BEC_4_8_TimeInterval) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1301342541: return bem_subtractHours_1((BEC_4_3_MathInt) bevd_0);
case 180991061: return bem_secondsSet_1((BEC_4_3_MathInt) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 445912502: return bem_addDays_1((BEC_4_3_MathInt) bevd_0);
case 955482416: return bem_addSeconds_1((BEC_4_3_MathInt) bevd_0);
case 305084254: return bem_millisecondsSet_1((BEC_4_3_MathInt) bevd_0);
case 1925851374: return bem_millisSet_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_4_8_TimeInterval) bevd_0);
case 1286233312: return bem_addHours_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1103128156: return bem_offByHour_1((BEC_4_8_TimeInterval) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 727969166: return bem_secsSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 309281416: return bem_subtractMilliseconds_1((BEC_4_3_MathInt) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1689132987: return bem_addMilliseconds_1((BEC_4_3_MathInt) bevd_0);
case 1992862333: return bem_subtractDays_1((BEC_4_3_MathInt) bevd_0);
case 1081152067: return bem_subtractSeconds_1((BEC_4_3_MathInt) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_4_8_TimeInterval();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_4_8_TimeInterval.bevs_inst = (BEC_4_8_TimeInterval)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_4_8_TimeInterval.bevs_inst;
}
}
}
