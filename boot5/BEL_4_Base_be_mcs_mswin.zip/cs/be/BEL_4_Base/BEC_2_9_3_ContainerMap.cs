namespace be.BEL_4_Base {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap : BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
static BEC_2_9_3_ContainerMap() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_3_ContainerMap bevs_inst;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_3_21_ContainerMapSerializationIterator) (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_6_tmpvar_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpvar_phold = this.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_notEquals_1(bevt_7_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 133 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 133 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 133 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 133 */ {
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 134 */
bevt_0_tmpvar_loop = this.bem_mapIteratorGet_0();
while (true)
 /* Line: 136 */ {
bevt_9_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevl_i = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_10_tmpvar_phold = bevl_i.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_v == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_13_tmpvar_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
if (bevt_13_tmpvar_phold == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 138 */ {
if (bevl_v == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_16_tmpvar_phold = bevl_i.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_v);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_17_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_17_tmpvar_phold;
} /* Line: 138 */
} /* Line: 138 */
 else  /* Line: 136 */ {
break;
} /* Line: 136 */
} /* Line: 136 */
bevt_18_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_18_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_9_5_ContainerArray bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 144 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 147 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevl_slt = (BEC_2_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 148 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
bevp_slots = bevl_slt;
} /* Line: 150 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 152 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 153 */
return this;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_valueIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_3_9_3_16_ContainerMapKeyValueIterator) (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 178 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 179 */ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_tmpvar_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
 /* Line: 181 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 181 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_4_tmpvar_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_5_tmpvar_phold = bevl_x.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
} /* Line: 182 */
 else  /* Line: 181 */ {
break;
} /* Line: 181 */
} /* Line: 181 */
} /* Line: 181 */
 else  /* Line: 179 */ {
bevt_6_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 184 */ {
bevt_7_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpvar_phold = beva_other.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
} /* Line: 185 */
 else  /* Line: 186 */ {
this.bem_put_2(beva_other, beva_other);
} /* Line: 187 */
} /* Line: 179 */
} /* Line: 179 */
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_toRet = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_mapIteratorGet_0();
while (true)
 /* Line: 194 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_3_tmpvar_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, beva_prefix);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 195 */ {
bevt_4_tmpvar_phold = bevl_x.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_5_tmpvar_phold = bevl_x.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
bevl_toRet.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
} /* Line: 196 */
} /* Line: 195 */
 else  /* Line: 194 */ {
break;
} /* Line: 194 */
} /* Line: 194 */
return bevl_toRet;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {115, 119, 120, 121, 122, 123, 124, 128, 132, 133, 0, 133, 0, 134, 136, 0, 136, 137, 138, 0, 138, 0, 138, 0, 138, 140, 144, 145, 146, 147, 148, 150, 153, 158, 162, 166, 170, 174, 178, 179, 180, 181, 0, 181, 182, 184, 185, 187, 193, 194, 0, 194, 195, 196, 199};
public static new int[] bevs_smnlec
 = new int[] {11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11};
/* BEGIN LINEINFO 
assign 1 115 11
new 0 115 11
new 1 115 11
assign 1 119 11
new 1 119 11
assign 1 120 11
assign 1 121 11
new 0 121 11
assign 1 122 11
new 0 122 11
assign 1 123 11
new 0 123 11
assign 1 124 11
new 0 124 11
assign 1 128 11
new 1 128 11
return 1 128 11
assign 1 132 11
assign 1 133 11
undef 1 133 11
assign 1 0 11
assign 1 133 11
sizeGet 0 133 11
assign 1 133 11
sizeGet 0 133 11
assign 1 133 11
notEquals 1 133 11
assign 1 0 11
assign 1 0 11
assign 1 134 11
new 0 134 11
return 1 134 11
assign 1 136 11
mapIteratorGet 0 0 11
assign 1 136 11
hasNextGet 0 136 11
assign 1 136 11
nextGet 0 136 11
assign 1 137 11
keyGet 0 137 11
assign 1 137 11
get 1 137 11
assign 1 138 11
undef 1 138 11
assign 1 0 11
assign 1 138 11
valueGet 0 138 11
assign 1 138 11
undef 1 138 11
assign 1 138 11
def 1 138 11
assign 1 0 11
assign 1 0 11
assign 1 0 11
assign 1 0 11
assign 1 0 11
assign 1 0 11
assign 1 138 11
valueGet 0 138 11
assign 1 138 11
notEquals 1 138 11
assign 1 0 11
assign 1 0 11
assign 1 138 11
new 0 138 11
return 1 138 11
assign 1 140 11
new 0 140 11
return 1 140 11
assign 1 144 11
innerPut 4 144 11
assign 1 144 11
not 0 144 11
assign 1 145 11
assign 1 146 11
rehash 1 146 11
assign 1 147 11
innerPut 4 147 11
assign 1 147 11
not 0 147 11
assign 1 148 11
rehash 1 148 11
assign 1 150 11
assign 1 153 11
increment 0 153 11
assign 1 158 11
new 1 158 11
return 1 158 11
assign 1 162 11
valueIteratorGet 0 162 11
return 1 162 11
assign 1 166 11
new 1 166 11
return 1 166 11
assign 1 170 11
new 1 170 11
return 1 170 11
assign 1 174 11
new 1 174 11
return 1 174 11
assign 1 178 11
def 1 178 11
assign 1 179 11
sameType 1 179 11
assign 1 180 11
assign 1 181 11
mapIteratorGet 0 0 11
assign 1 181 11
hasNextGet 0 181 11
assign 1 181 11
nextGet 0 181 11
assign 1 182 11
keyGet 0 182 11
assign 1 182 11
valueGet 0 182 11
put 2 182 11
assign 1 184 11
sameType 1 184 11
assign 1 185 11
keyGet 0 185 11
assign 1 185 11
valueGet 0 185 11
put 2 185 11
put 2 187 11
assign 1 193 11
new 0 193 11
assign 1 194 11
mapIteratorGet 0 0 11
assign 1 194 11
hasNextGet 0 194 11
assign 1 194 11
nextGet 0 194 11
assign 1 195 11
keyGet 0 195 11
assign 1 195 11
begins 1 195 11
assign 1 196 11
keyGet 0 196 11
assign 1 196 11
valueGet 0 196 11
put 2 196 11
return 1 199 11
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1227011022: return bem_multiGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 1586230380: return bem_moduGet_0();
case 550406779: return bem_valuesGet_0();
case 1308786538: return bem_echo_0();
case 354906194: return bem_slotsGet_0();
case 856777406: return bem_clear_0();
case 712928736: return bem_innerPutAddedGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2086347094: return bem_nodesGet_0();
case 902391673: return bem_keyValueIteratorGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 2145224760: return bem_valueIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 578884498: return bem_relGet_0();
case 287040793: return bem_hashGet_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1114073101: return bem_keysGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1089531140: return bem_isEmptyGet_0();
case 845792839: return bem_iteratorGet_0();
case 2142483603: return bem_notEmptyGet_0();
case 444835395: return bem_mapIteratorGet_0();
case 314718434: return bem_print_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 1959489624: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_2_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 107034370: return bem_put_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_5_ContainerArray) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerMap.bevs_inst = (BEC_2_9_3_ContainerMap)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerMap.bevs_inst;
}
}
}
