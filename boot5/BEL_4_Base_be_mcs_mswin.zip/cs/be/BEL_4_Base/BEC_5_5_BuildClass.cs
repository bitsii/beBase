namespace be.BEL_4_Base {
/* IO:File: source/build/BuildTypes.be */
public class BEC_5_5_BuildClass : BEC_6_6_SystemObject {
public BEC_5_5_BuildClass() { }
static BEC_5_5_BuildClass() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 11));
private static byte[] bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 10));
public static new BEC_5_5_BuildClass bevs_inst;
public BEC_5_8_BuildNamePath bevp_extends;
public BEC_9_10_ContainerLinkedList bevp_emits;
public BEC_4_6_TextString bevp_name;
public BEC_5_8_BuildNamePath bevp_namepath;
public BEC_5_8_BuildClassSyn bevp_syn;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_libName;
public BEC_9_3_ContainerMap bevp_methods;
public BEC_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_9_10_ContainerLinkedList bevp_used;
public BEC_9_3_ContainerMap bevp_varMap;
public BEC_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_5_4_LogicBool bevp_isFinal;
public BEC_5_4_LogicBool bevp_isLocal;
public BEC_5_4_LogicBool bevp_isNotNull;
public BEC_5_4_LogicBool bevp_freeFirstSlot;
public BEC_5_4_LogicBool bevp_firstSlotNative;
public BEC_4_3_MathInt bevp_nativeSlots;
public BEC_5_4_LogicBool bevp_isArray;
public BEC_4_3_MathInt bevp_onceEvalCount;
public BEC_9_3_ContainerSet bevp_referencedProperties;
public BEC_5_4_LogicBool bevp_shouldWrite;
public BEC_4_3_MathInt bevp_belsCount;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_5_8_BuildNamePath bevl_np = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevp_methods = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_varMap = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isLocal = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isNotNull = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_firstSlotNative = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_nativeSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_isArray = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_referencedProperties = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_belsCount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_np = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_0));
bevl_np.bem_fromString_1(bevt_0_tmpvar_phold);
this.bem_addUsed_1(bevl_np);
bevl_np = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_1));
bevl_np.bem_fromString_1(bevt_1_tmpvar_phold);
this.bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addUsed_1(BEC_6_6_SystemObject beva_touse) {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addEmit_1(BEC_6_6_SystemObject beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_emits == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevp_emits = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 146 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_4_6_TextString bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_ret = this.bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 153 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevl_ret.bem_add_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
if (bevp_extends == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 155 */ {
bevt_6_tmpvar_phold = bevo_1;
bevt_5_tmpvar_phold = bevl_ret.bem_add_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
} /* Line: 156 */
} /* Line: 155 */
return bevl_ret;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_extendsGet_0() {
return bevp_extends;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extendsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extends = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emits = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_name = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_namepathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_namepath = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_synSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_syn = (BEC_5_8_BuildClassSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methods = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_orderedMethodsGet_0() {
return bevp_orderedMethods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_orderedMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_orderedMethods = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_usedGet_0() {
return bevp_used;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_used = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_varMapGet_0() {
return bevp_varMap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varMapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_varMap = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_orderedVarsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_orderedVars = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isFinalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isFinal = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isLocalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isLocal = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isNotNullSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isNotNull = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_freeFirstSlotGet_0() {
return bevp_freeFirstSlot;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_freeFirstSlotSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_freeFirstSlot = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_firstSlotNativeGet_0() {
return bevp_firstSlotNative;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_firstSlotNativeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_firstSlotNative = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nativeSlotsGet_0() {
return bevp_nativeSlots;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nativeSlotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nativeSlots = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isArrayGet_0() {
return bevp_isArray;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isArraySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isArray = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_onceEvalCountGet_0() {
return bevp_onceEvalCount;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_onceEvalCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_onceEvalCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_referencedPropertiesGet_0() {
return bevp_referencedProperties;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_referencedPropertiesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_referencedProperties = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_shouldWriteGet_0() {
return bevp_shouldWrite;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_shouldWriteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_shouldWrite = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_belsCountGet_0() {
return bevp_belsCount;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_belsCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_belsCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 131, 132, 133, 135, 136, 137, 141, 145, 146, 148, 152, 153, 154, 155, 156, 159, 0};
public static new int[] bevs_smnlec
 = new int[] {42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42};
/* BEGIN LINEINFO 
assign 1 111 42
new 0 111 42
assign 1 112 42
new 0 112 42
assign 1 113 42
new 0 113 42
assign 1 114 42
new 0 114 42
assign 1 115 42
new 0 115 42
assign 1 116 42
new 0 116 42
assign 1 117 42
new 0 117 42
assign 1 118 42
new 0 118 42
assign 1 119 42
new 0 119 42
assign 1 120 42
new 0 120 42
assign 1 121 42
new 0 121 42
assign 1 122 42
new 0 122 42
assign 1 123 42
new 0 123 42
assign 1 124 42
new 0 124 42
assign 1 125 42
new 0 125 42
assign 1 126 42
new 0 126 42
assign 1 131 42
new 0 131 42
assign 1 132 42
new 0 132 42
fromString 1 132 42
addUsed 1 133 42
assign 1 135 42
new 0 135 42
assign 1 136 42
new 0 136 42
fromString 1 136 42
addUsed 1 137 42
addValue 1 141 42
assign 1 145 42
undef 1 145 42
assign 1 146 42
new 0 146 42
addValue 1 148 42
assign 1 152 42
classNameGet 0 152 42
assign 1 153 42
def 1 153 42
assign 1 154 42
new 0 154 42
assign 1 154 42
add 1 154 42
assign 1 154 42
toString 0 154 42
assign 1 154 42
add 1 154 42
assign 1 155 42
def 1 155 42
assign 1 156 42
new 0 156 42
assign 1 156 42
add 1 156 42
assign 1 156 42
toString 0 156 42
assign 1 156 42
add 1 156 42
return 1 159 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
return 1 0 42
assign 1 0 42
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 87592446: return bem_orderedMethodsGet_0();
case 287367803: return bem_isFinalGet_0();
case 363636983: return bem_isNotNullGet_0();
case 287040793: return bem_hashGet_0();
case 1791388575: return bem_synGet_0();
case 429326446: return bem_extendsGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 845792839: return bem_iteratorGet_0();
case 1081760974: return bem_orderedVarsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 795036897: return bem_fromFileGet_0();
case 83882038: return bem_usedGet_0();
case 1774940957: return bem_toString_0();
case 568286617: return bem_emitsGet_0();
case 1012494862: return bem_once_0();
case 2123142907: return bem_shouldWriteGet_0();
case 368256414: return bem_belsCountGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 842582618: return bem_isLocalGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 428778779: return bem_freeFirstSlotGet_0();
case 1104169470: return bem_firstSlotNativeGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 81548343: return bem_nativeSlotsGet_0();
case 1081412016: return bem_many_0();
case 1859739893: return bem_methodsGet_0();
case 314718434: return bem_print_0();
case 1803479881: return bem_libNameGet_0();
case 1458936917: return bem_onceEvalCountGet_0();
case 354142775: return bem_namepathGet_0();
case 1211273660: return bem_nameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 1155896786: return bem_varMapGet_0();
case 1308786538: return bem_echo_0();
case 1450142629: return bem_referencedPropertiesGet_0();
case 729571811: return bem_serializeToString_0();
case 936200056: return bem_isArrayGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 406676794: return bem_addEmit_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 1802470828: return bem_synSet_1(bevd_0);
case 440408699: return bem_extendsSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 72799785: return bem_usedSet_1(bevd_0);
case 1092843227: return bem_orderedVarsSet_1(bevd_0);
case 557204364: return bem_emitsSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 357174161: return bem_belsCountSet_1(bevd_0);
case 2134225160: return bem_shouldWriteSet_1(bevd_0);
case 831500365: return bem_isLocalSet_1(bevd_0);
case 417696526: return bem_freeFirstSlotSet_1(bevd_0);
case 1093087217: return bem_firstSlotNativeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 70466090: return bem_nativeSlotsSet_1(bevd_0);
case 56796208: return bem_addUsed_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1439060376: return bem_referencedPropertiesSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1470019170: return bem_onceEvalCountSet_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 1166979039: return bem_varMapSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 76510193: return bem_orderedMethodsSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 947282309: return bem_isArraySet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_BuildClass();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_BuildClass.bevs_inst = (BEC_5_5_BuildClass)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_BuildClass.bevs_inst;
}
}
}
