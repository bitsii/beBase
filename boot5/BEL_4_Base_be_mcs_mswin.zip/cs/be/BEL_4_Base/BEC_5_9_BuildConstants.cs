namespace be.BEL_4_Base {
/* IO:File: source/build/Constants.be */
public class BEC_5_9_BuildConstants : BEC_6_6_SystemObject {
public BEC_5_9_BuildConstants() { }
static BEC_5_9_BuildConstants() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x62,0x72,0x61,0x63,0x65,0x73};
private static byte[] bels_1 = {0x63,0x61,0x6C,0x6C};
private static byte[] bels_2 = {0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_3 = {0x70,0x61,0x72,0x65,0x6E,0x73};
private static byte[] bels_4 = {0x4E,0x4F,0x54};
private static byte[] bels_5 = {0x4F,0x4E,0x43,0x45};
private static byte[] bels_6 = {0x4D,0x41,0x4E,0x59};
private static byte[] bels_7 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bels_8 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bels_9 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59};
private static byte[] bels_10 = {0x44,0x49,0x56,0x49,0x44,0x45};
private static byte[] bels_11 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53};
private static byte[] bels_12 = {0x41,0x44,0x44};
private static byte[] bels_13 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54};
private static byte[] bels_14 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52};
private static byte[] bels_15 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_16 = {0x4C,0x45,0x53,0x53,0x45,0x52};
private static byte[] bels_17 = {0x4C,0x45,0x53,0x53,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_18 = {0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_19 = {0x4E,0x4F,0x54,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bels_20 = {0x41,0x4E,0x44};
private static byte[] bels_21 = {0x4F,0x52};
private static byte[] bels_22 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x41,0x4E,0x44};
private static byte[] bels_23 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x4F,0x52};
private static byte[] bels_24 = {0x49,0x4E};
private static byte[] bels_25 = {0x41,0x44,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_26 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_27 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_28 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_29 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_30 = {0x44,0x49,0x56,0x49,0x44,0x45,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_31 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_32 = {0x41,0x4E,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_33 = {0x4F,0x52,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bels_34 = {0x41,0x53,0x53,0x49,0x47,0x4E};
private static byte[] bels_35 = {0x20};
private static BEC_6_6_SystemObject bevo_0 = (new BEC_4_6_TextString(bels_35, 1));
private static byte[] bels_36 = {0x2F};
private static byte[] bels_37 = {0x7B};
private static byte[] bels_38 = {0x7D};
private static byte[] bels_39 = {0x28};
private static byte[] bels_40 = {0x29};
private static byte[] bels_41 = {0x3B};
private static byte[] bels_42 = {0x3A};
private static byte[] bels_43 = {0x2C};
private static byte[] bels_44 = {0x2B};
private static byte[] bels_45 = {};
private static byte[] bels_46 = {0x2D};
private static byte[] bels_47 = {0x40};
private static byte[] bels_48 = {0x23};
private static byte[] bels_49 = {0x75,0x73,0x65};
private static byte[] bels_50 = {0x61,0x73};
private static byte[] bels_51 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_52 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_53 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_54 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_55 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_56 = {0x76,0x61,0x72};
private static byte[] bels_57 = {0x69,0x66};
private static byte[] bels_58 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_59 = {0x65,0x6C,0x69,0x66};
private static byte[] bels_60 = {0x65,0x6C,0x73,0x65};
private static byte[] bels_61 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_62 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bels_63 = {0x77,0x68,0x69,0x6C,0x65};
private static byte[] bels_64 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_65 = {0x66,0x6F,0x72};
private static byte[] bels_66 = {0x66,0x6F,0x72,0x65,0x61,0x63,0x68};
private static byte[] bels_67 = {0x69,0x6E};
private static byte[] bels_68 = {0x65,0x6D,0x69,0x74};
private static byte[] bels_69 = {0x69,0x66,0x45,0x6D,0x69,0x74};
private static byte[] bels_70 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bels_71 = {0x62,0x72,0x65,0x61,0x6B};
private static byte[] bels_72 = {0x63,0x6F,0x6E,0x74,0x69,0x6E,0x75,0x65};
private static byte[] bels_73 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_74 = {0x74,0x72,0x75,0x65};
private static byte[] bels_75 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_76 = {0x74,0x72,0x79};
private static byte[] bels_77 = {0x63,0x61,0x74,0x63,0x68};
public static new BEC_5_9_BuildConstants bevs_inst;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_9_3_ContainerMap bevp_matchMap;
public BEC_9_3_ContainerMap bevp_rwords;
public BEC_4_3_MathInt bevp_maxargs;
public BEC_4_3_MathInt bevp_extraSlots;
public BEC_4_3_MathInt bevp_mtdxPad;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_9_3_ContainerMap bevp_unwindTo;
public BEC_9_3_ContainerMap bevp_unwindOk;
public BEC_9_3_ContainerMap bevp_oper;
public BEC_9_3_ContainerMap bevp_operNames;
public BEC_9_3_ContainerMap bevp_conTypes;
public BEC_9_3_ContainerMap bevp_parensReq;
public BEC_9_3_ContainerMap bevp_anchorTypes;
public virtual BEC_5_9_BuildConstants bem_new_1(BEC_6_6_SystemObject beva_build) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_4_3_MathInt bevt_68_tmpvar_phold = null;
BEC_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_4_3_MathInt bevt_108_tmpvar_phold = null;
BEC_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_3_MathInt bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_4_3_MathInt bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_3_MathInt bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_4_3_MathInt bevt_118_tmpvar_phold = null;
BEC_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_4_3_MathInt bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_4_3_MathInt bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_4_3_MathInt bevt_128_tmpvar_phold = null;
BEC_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_133_tmpvar_phold = null;
BEC_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_135_tmpvar_phold = null;
BEC_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_139_tmpvar_phold = null;
BEC_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_141_tmpvar_phold = null;
BEC_4_3_MathInt bevt_142_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_143_tmpvar_phold = null;
BEC_4_3_MathInt bevt_144_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_145_tmpvar_phold = null;
BEC_4_3_MathInt bevt_146_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_147_tmpvar_phold = null;
BEC_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_4_3_MathInt bevt_150_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_151_tmpvar_phold = null;
BEC_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_153_tmpvar_phold = null;
BEC_4_3_MathInt bevt_154_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_155_tmpvar_phold = null;
BEC_4_3_MathInt bevt_156_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_159_tmpvar_phold = null;
BEC_4_3_MathInt bevt_160_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_4_3_MathInt bevt_162_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_163_tmpvar_phold = null;
BEC_4_3_MathInt bevt_164_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_165_tmpvar_phold = null;
BEC_4_3_MathInt bevt_166_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_167_tmpvar_phold = null;
BEC_4_3_MathInt bevt_168_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_4_3_MathInt bevt_170_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_171_tmpvar_phold = null;
BEC_4_3_MathInt bevt_172_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_173_tmpvar_phold = null;
BEC_4_3_MathInt bevt_174_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_175_tmpvar_phold = null;
BEC_4_3_MathInt bevt_176_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_177_tmpvar_phold = null;
BEC_4_3_MathInt bevt_178_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_179_tmpvar_phold = null;
BEC_4_3_MathInt bevt_180_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_181_tmpvar_phold = null;
BEC_4_3_MathInt bevt_182_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_183_tmpvar_phold = null;
BEC_4_3_MathInt bevt_184_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_185_tmpvar_phold = null;
BEC_4_3_MathInt bevt_186_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_4_3_MathInt bevt_188_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_189_tmpvar_phold = null;
BEC_4_3_MathInt bevt_190_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_4_3_MathInt bevt_192_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_193_tmpvar_phold = null;
BEC_4_3_MathInt bevt_194_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_197_tmpvar_phold = null;
BEC_4_3_MathInt bevt_198_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_199_tmpvar_phold = null;
bevp_maxargs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
bevp_extraSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevp_mtdxPad = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(26));
bevp_ntypes = (BEC_5_9_BuildNodeTypes) BEC_5_9_BuildNodeTypes.bevs_inst.bem_new_0();
bevp_unwindTo = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_unwindOk = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_oper = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_operNames = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_conTypes = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_parensReq = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_anchorTypes = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_0));
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindTo.bem_put_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_1));
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_2));
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_3));
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_6_tmpvar_phold, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevt_9_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_11_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_10_tmpvar_phold, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevt_13_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_15_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_14_tmpvar_phold, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_17_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_19_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_18_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_21_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_23_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_25_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_27_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_29_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_31_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_33_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_32_tmpvar_phold, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_35_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_37_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_36_tmpvar_phold, bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_39_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_38_tmpvar_phold, bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_41_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_40_tmpvar_phold, bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_43_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_42_tmpvar_phold, bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_45_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_47_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_46_tmpvar_phold, bevt_47_tmpvar_phold);
bevt_48_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_49_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_48_tmpvar_phold, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_51_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_50_tmpvar_phold, bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = bevp_ntypes.bem_INGet_0();
bevt_53_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_52_tmpvar_phold, bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_55_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
bevt_56_tmpvar_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_57_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_59_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_58_tmpvar_phold, bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_61_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_60_tmpvar_phold, bevt_61_tmpvar_phold);
bevt_62_tmpvar_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_63_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
bevt_64_tmpvar_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_65_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_64_tmpvar_phold, bevt_65_tmpvar_phold);
bevt_66_tmpvar_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_67_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_66_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_68_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_69_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(9));
bevp_oper.bem_put_2(bevt_68_tmpvar_phold, bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevt_71_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_4));
bevp_operNames.bem_put_2(bevt_70_tmpvar_phold, bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_73_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_5));
bevp_operNames.bem_put_2(bevt_72_tmpvar_phold, bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevt_75_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_6));
bevp_operNames.bem_put_2(bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
bevt_76_tmpvar_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_77_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_7));
bevp_operNames.bem_put_2(bevt_76_tmpvar_phold, bevt_77_tmpvar_phold);
bevt_78_tmpvar_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_79_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_8));
bevp_operNames.bem_put_2(bevt_78_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_81_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_9));
bevp_operNames.bem_put_2(bevt_80_tmpvar_phold, bevt_81_tmpvar_phold);
bevt_82_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_83_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_10));
bevp_operNames.bem_put_2(bevt_82_tmpvar_phold, bevt_83_tmpvar_phold);
bevt_84_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_85_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_11));
bevp_operNames.bem_put_2(bevt_84_tmpvar_phold, bevt_85_tmpvar_phold);
bevt_86_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_12));
bevp_operNames.bem_put_2(bevt_86_tmpvar_phold, bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_89_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_13));
bevp_operNames.bem_put_2(bevt_88_tmpvar_phold, bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_91_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_14));
bevp_operNames.bem_put_2(bevt_90_tmpvar_phold, bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_93_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_15));
bevp_operNames.bem_put_2(bevt_92_tmpvar_phold, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_95_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_16));
bevp_operNames.bem_put_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevt_96_tmpvar_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_97_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_17));
bevp_operNames.bem_put_2(bevt_96_tmpvar_phold, bevt_97_tmpvar_phold);
bevt_98_tmpvar_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_18));
bevp_operNames.bem_put_2(bevt_98_tmpvar_phold, bevt_99_tmpvar_phold);
bevt_100_tmpvar_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_101_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_19));
bevp_operNames.bem_put_2(bevt_100_tmpvar_phold, bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_103_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_20));
bevp_operNames.bem_put_2(bevt_102_tmpvar_phold, bevt_103_tmpvar_phold);
bevt_104_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_105_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_21));
bevp_operNames.bem_put_2(bevt_104_tmpvar_phold, bevt_105_tmpvar_phold);
bevt_106_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_107_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_22));
bevp_operNames.bem_put_2(bevt_106_tmpvar_phold, bevt_107_tmpvar_phold);
bevt_108_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_109_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_23));
bevp_operNames.bem_put_2(bevt_108_tmpvar_phold, bevt_109_tmpvar_phold);
bevt_110_tmpvar_phold = bevp_ntypes.bem_INGet_0();
bevt_111_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_24));
bevp_operNames.bem_put_2(bevt_110_tmpvar_phold, bevt_111_tmpvar_phold);
bevt_112_tmpvar_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_113_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_25));
bevp_operNames.bem_put_2(bevt_112_tmpvar_phold, bevt_113_tmpvar_phold);
bevt_114_tmpvar_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_115_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_26));
bevp_operNames.bem_put_2(bevt_114_tmpvar_phold, bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_117_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_27));
bevp_operNames.bem_put_2(bevt_116_tmpvar_phold, bevt_117_tmpvar_phold);
bevt_118_tmpvar_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_119_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_28));
bevp_operNames.bem_put_2(bevt_118_tmpvar_phold, bevt_119_tmpvar_phold);
bevt_120_tmpvar_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_121_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_29));
bevp_operNames.bem_put_2(bevt_120_tmpvar_phold, bevt_121_tmpvar_phold);
bevt_122_tmpvar_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_123_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_30));
bevp_operNames.bem_put_2(bevt_122_tmpvar_phold, bevt_123_tmpvar_phold);
bevt_124_tmpvar_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_125_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_31));
bevp_operNames.bem_put_2(bevt_124_tmpvar_phold, bevt_125_tmpvar_phold);
bevt_126_tmpvar_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_127_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_32));
bevp_operNames.bem_put_2(bevt_126_tmpvar_phold, bevt_127_tmpvar_phold);
bevt_128_tmpvar_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_129_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_33));
bevp_operNames.bem_put_2(bevt_128_tmpvar_phold, bevt_129_tmpvar_phold);
bevt_130_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_131_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_34));
bevp_operNames.bem_put_2(bevt_130_tmpvar_phold, bevt_131_tmpvar_phold);
bevt_132_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_133_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_132_tmpvar_phold, bevt_133_tmpvar_phold);
bevt_134_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_135_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_134_tmpvar_phold, bevt_135_tmpvar_phold);
bevt_136_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_137_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_136_tmpvar_phold, bevt_137_tmpvar_phold);
bevt_138_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_139_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_138_tmpvar_phold, bevt_139_tmpvar_phold);
bevt_140_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_141_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_140_tmpvar_phold, bevt_141_tmpvar_phold);
bevt_142_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_143_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_142_tmpvar_phold, bevt_143_tmpvar_phold);
bevt_144_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_145_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_144_tmpvar_phold, bevt_145_tmpvar_phold);
bevt_146_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_147_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_146_tmpvar_phold, bevt_147_tmpvar_phold);
bevt_148_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_149_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_148_tmpvar_phold, bevt_149_tmpvar_phold);
bevt_150_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_151_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_150_tmpvar_phold, bevt_151_tmpvar_phold);
bevt_152_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_153_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_152_tmpvar_phold, bevt_153_tmpvar_phold);
bevt_154_tmpvar_phold = bevp_ntypes.bem_TRYGet_0();
bevt_155_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_154_tmpvar_phold, bevt_155_tmpvar_phold);
bevt_156_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_157_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_156_tmpvar_phold, bevt_157_tmpvar_phold);
bevt_158_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_159_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_158_tmpvar_phold, bevt_159_tmpvar_phold);
bevt_160_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_161_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_160_tmpvar_phold, bevt_161_tmpvar_phold);
bevt_162_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_163_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_162_tmpvar_phold, bevt_163_tmpvar_phold);
bevt_164_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_165_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_164_tmpvar_phold, bevt_165_tmpvar_phold);
bevt_166_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_167_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_166_tmpvar_phold, bevt_167_tmpvar_phold);
bevt_168_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
bevt_169_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_168_tmpvar_phold, bevt_169_tmpvar_phold);
bevt_170_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_171_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_170_tmpvar_phold, bevt_171_tmpvar_phold);
bevt_172_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_173_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_172_tmpvar_phold, bevt_173_tmpvar_phold);
bevt_174_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_175_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_174_tmpvar_phold, bevt_175_tmpvar_phold);
bevt_176_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_177_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_176_tmpvar_phold, bevt_177_tmpvar_phold);
bevt_178_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_179_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_178_tmpvar_phold, bevt_179_tmpvar_phold);
bevt_180_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_181_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_180_tmpvar_phold, bevt_181_tmpvar_phold);
bevt_182_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_183_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_182_tmpvar_phold, bevt_183_tmpvar_phold);
bevt_184_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_185_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_184_tmpvar_phold, bevt_185_tmpvar_phold);
bevt_186_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_187_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_186_tmpvar_phold, bevt_187_tmpvar_phold);
bevt_188_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_189_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_188_tmpvar_phold, bevt_189_tmpvar_phold);
bevt_190_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_191_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_190_tmpvar_phold, bevt_191_tmpvar_phold);
bevt_192_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_193_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_192_tmpvar_phold, bevt_193_tmpvar_phold);
bevt_194_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_195_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_194_tmpvar_phold, bevt_195_tmpvar_phold);
bevt_196_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_197_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_196_tmpvar_phold, bevt_197_tmpvar_phold);
bevt_198_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_199_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_198_tmpvar_phold, bevt_199_tmpvar_phold);
this.bem_prepare_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepare_0() {
BEC_6_6_SystemObject bevl_space = null;
BEC_6_6_SystemObject bevl_ntok = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_3_MathInt bevt_105_tmpvar_phold = null;
bevp_matchMap = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_space = bevo_0;
bevl_ntok = (new BEC_4_6_TextString(1, bels_36));
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_twtok = (BEC_4_9_TextTokenizer) (new BEC_4_9_TextTokenizer()).bem_new_2((BEC_4_6_TextString) bevl_ntok, bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_1_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_37));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_2_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_2_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_38));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_3_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_3_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_39));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_4_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_4_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_40));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_5_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_5_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_41));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_6_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_6_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_42));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_7_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_7_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_43));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_8_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_8_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_44));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_9_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_9_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(0, bels_45));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_10_tmpvar_phold = bevp_ntypes.bem_ATYPEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_10_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_46));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_11_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_11_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_47));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_12_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_12_tmpvar_phold);
bevl_ntok = (new BEC_4_6_TextString(1, bels_48));
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_13_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(92));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_14_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_15_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(34));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_16_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_17_tmpvar_phold = bevp_ntypes.bem_STRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(39));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_18_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_19_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(91));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_20_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_21_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(93));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_22_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_23_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(37));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_24_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_25_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(61));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_26_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_27_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(62));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_28_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_29_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(60));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_30_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_31_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(33));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_32_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_33_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(38));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_34_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_35_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(124));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_36_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_37_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(42));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_38_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_39_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(46));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_40_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_41_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(32));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_42_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_43_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(9));
bevl_ntok = (new BEC_4_6_TextString()).bem_codeNew_1(bevt_44_tmpvar_phold);
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_45_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_ntok = bevt_46_tmpvar_phold.bem_newlineGet_0();
bevp_twtok.bem_addToken_1((BEC_4_6_TextString) bevl_ntok);
bevt_47_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_47_tmpvar_phold);
bevp_rwords = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevt_48_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_49));
bevt_49_tmpvar_phold = bevp_ntypes.bem_USEGet_0();
bevp_rwords.bem_put_2(bevt_48_tmpvar_phold, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_50));
bevt_51_tmpvar_phold = bevp_ntypes.bem_ASGet_0();
bevp_rwords.bem_put_2(bevt_50_tmpvar_phold, bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_51));
bevt_53_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevp_rwords.bem_put_2(bevt_52_tmpvar_phold, bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_52));
bevt_55_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevp_rwords.bem_put_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
bevt_56_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_53));
bevt_57_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_54));
bevt_59_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_58_tmpvar_phold, bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_55));
bevt_61_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_60_tmpvar_phold, bevt_61_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_56));
bevt_63_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
bevt_64_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_57));
bevt_65_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_64_tmpvar_phold, bevt_65_tmpvar_phold);
bevt_66_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_58));
bevt_67_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_66_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_68_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_59));
bevt_69_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevp_rwords.bem_put_2(bevt_68_tmpvar_phold, bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_60));
bevt_71_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevp_rwords.bem_put_2(bevt_70_tmpvar_phold, bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_61));
bevt_73_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevp_rwords.bem_put_2(bevt_72_tmpvar_phold, bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_62));
bevt_75_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevp_rwords.bem_put_2(bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
bevt_76_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_63));
bevt_77_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_76_tmpvar_phold, bevt_77_tmpvar_phold);
bevt_78_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_64));
bevt_79_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_78_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_65));
bevt_81_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevp_rwords.bem_put_2(bevt_80_tmpvar_phold, bevt_81_tmpvar_phold);
bevt_82_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_66));
bevt_83_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevp_rwords.bem_put_2(bevt_82_tmpvar_phold, bevt_83_tmpvar_phold);
bevt_84_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_67));
bevt_85_tmpvar_phold = bevp_ntypes.bem_INGet_0();
bevp_rwords.bem_put_2(bevt_84_tmpvar_phold, bevt_85_tmpvar_phold);
bevt_86_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_68));
bevt_87_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevp_rwords.bem_put_2(bevt_86_tmpvar_phold, bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_69));
bevt_89_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_88_tmpvar_phold, bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_70));
bevt_91_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_90_tmpvar_phold, bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_71));
bevt_93_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevp_rwords.bem_put_2(bevt_92_tmpvar_phold, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_72));
bevt_95_tmpvar_phold = bevp_ntypes.bem_CONTINUEGet_0();
bevp_rwords.bem_put_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevt_96_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_73));
bevt_97_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevp_rwords.bem_put_2(bevt_96_tmpvar_phold, bevt_97_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_74));
bevt_99_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevp_rwords.bem_put_2(bevt_98_tmpvar_phold, bevt_99_tmpvar_phold);
bevt_100_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_75));
bevt_101_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevp_rwords.bem_put_2(bevt_100_tmpvar_phold, bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_76));
bevt_103_tmpvar_phold = bevp_ntypes.bem_TRYGet_0();
bevp_rwords.bem_put_2(bevt_102_tmpvar_phold, bevt_103_tmpvar_phold);
bevt_104_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_77));
bevt_105_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevp_rwords.bem_put_2(bevt_104_tmpvar_phold, bevt_105_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_matchMapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_matchMap = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rwordsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rwords = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_maxargsGet_0() {
return bevp_maxargs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_maxargsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxargs = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_extraSlotsGet_0() {
return bevp_extraSlots;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extraSlotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extraSlots = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_mtdxPadGet_0() {
return bevp_mtdxPad;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mtdxPadSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdxPad = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_unwindToGet_0() {
return bevp_unwindTo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_unwindToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unwindTo = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_unwindOkGet_0() {
return bevp_unwindOk;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_unwindOkSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unwindOk = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_operGet_0() {
return bevp_oper;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_operSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_oper = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_operNamesGet_0() {
return bevp_operNames;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_operNamesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_operNames = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_conTypesGet_0() {
return bevp_conTypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_conTypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_conTypes = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_parensReqGet_0() {
return bevp_parensReq;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parensReqSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parensReq = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_anchorTypesGet_0() {
return bevp_anchorTypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_anchorTypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_anchorTypes = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 24, 27, 28, 29, 30, 31, 32, 33, 34, 35, 39, 39, 39, 41, 41, 41, 42, 42, 42, 43, 43, 43, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58, 58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 69, 69, 69, 70, 70, 70, 71, 71, 71, 72, 72, 72, 73, 73, 73, 74, 74, 74, 75, 75, 75, 77, 77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89, 90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 97, 97, 97, 98, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 102, 102, 102, 103, 103, 103, 104, 104, 104, 105, 105, 105, 106, 106, 106, 107, 107, 107, 109, 109, 109, 110, 110, 110, 111, 111, 111, 112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 127, 127, 127, 129, 129, 129, 130, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136, 137, 137, 137, 139, 139, 139, 140, 140, 140, 141, 141, 141, 142, 142, 142, 143, 143, 143, 144, 144, 144, 146, 152, 153, 155, 156, 156, 157, 157, 159, 160, 161, 161, 163, 164, 165, 165, 167, 168, 169, 169, 171, 172, 173, 173, 175, 176, 177, 177, 179, 180, 181, 181, 183, 184, 185, 185, 187, 188, 189, 189, 191, 192, 193, 193, 195, 196, 197, 197, 199, 200, 201, 201, 203, 204, 205, 205, 209, 209, 211, 212, 212, 214, 214, 216, 217, 217, 219, 219, 221, 222, 222, 224, 224, 226, 227, 227, 229, 229, 231, 232, 232, 234, 234, 236, 237, 237, 239, 239, 241, 242, 242, 244, 244, 246, 247, 247, 249, 249, 251, 252, 252, 254, 254, 256, 257, 257, 259, 259, 261, 262, 262, 264, 264, 266, 267, 267, 269, 269, 271, 272, 272, 274, 274, 276, 277, 277, 279, 279, 281, 282, 282, 284, 284, 286, 287, 287, 289, 289, 291, 292, 292, 295, 296, 296, 296, 297, 297, 297, 298, 298, 298, 299, 299, 299, 300, 300, 300, 301, 301, 301, 302, 302, 302, 303, 303, 303, 305, 305, 305, 306, 306, 306, 307, 307, 307, 308, 308, 308, 309, 309, 309, 311, 311, 311, 312, 312, 312, 313, 313, 313, 314, 314, 314, 315, 315, 315, 316, 316, 316, 317, 317, 317, 318, 318, 318, 319, 319, 319, 320, 320, 320, 321, 321, 321, 322, 322, 322, 323, 323, 323, 324, 324, 324, 325, 325, 325, 326, 326, 326, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 957, 960, 964, 967, 971, 974, 978, 981, 985, 988, 992, 995, 999, 1002, 1006, 1009, 1013, 1016, 1020, 1023, 1027, 1030, 1034, 1037, 1041, 1044, 1048, 1051};
/* BEGIN LINEINFO 
assign 1 23 303
new 0 23 303
assign 1 24 304
new 0 24 304
assign 1 27 305
new 0 27 305
assign 1 28 306
new 0 28 306
assign 1 29 307
new 0 29 307
assign 1 30 308
new 0 30 308
assign 1 31 309
new 0 31 309
assign 1 32 310
new 0 32 310
assign 1 33 311
new 0 33 311
assign 1 34 312
new 0 34 312
assign 1 35 313
new 0 35 313
assign 1 39 314
new 0 39 314
assign 1 39 315
new 0 39 315
put 2 39 316
assign 1 41 317
new 0 41 317
assign 1 41 318
new 0 41 318
put 2 41 319
assign 1 42 320
new 0 42 320
assign 1 42 321
new 0 42 321
put 2 42 322
assign 1 43 323
new 0 43 323
assign 1 43 324
new 0 43 324
put 2 43 325
assign 1 45 326
NOTGet 0 45 326
assign 1 45 327
new 0 45 327
put 2 45 328
assign 1 46 329
ONCEGet 0 46 329
assign 1 46 330
new 0 46 330
put 2 46 331
assign 1 47 332
MANYGet 0 47 332
assign 1 47 333
new 0 47 333
put 2 47 334
assign 1 48 335
INCREMENTGet 0 48 335
assign 1 48 336
new 0 48 336
put 2 48 337
assign 1 49 338
DECREMENTGet 0 49 338
assign 1 49 339
new 0 49 339
put 2 49 340
assign 1 50 341
INCREMENT_ASSIGNGet 0 50 341
assign 1 50 342
new 0 50 342
put 2 50 343
assign 1 51 344
DECREMENT_ASSIGNGet 0 51 344
assign 1 51 345
new 0 51 345
put 2 51 346
assign 1 52 347
MULTIPLYGet 0 52 347
assign 1 52 348
new 0 52 348
put 2 52 349
assign 1 53 350
DIVIDEGet 0 53 350
assign 1 53 351
new 0 53 351
put 2 53 352
assign 1 54 353
MODULUSGet 0 54 353
assign 1 54 354
new 0 54 354
put 2 54 355
assign 1 55 356
ADDGet 0 55 356
assign 1 55 357
new 0 55 357
put 2 55 358
assign 1 56 359
SUBTRACTGet 0 56 359
assign 1 56 360
new 0 56 360
put 2 56 361
assign 1 57 362
GREATERGet 0 57 362
assign 1 57 363
new 0 57 363
put 2 57 364
assign 1 58 365
GREATER_EQUALSGet 0 58 365
assign 1 58 366
new 0 58 366
put 2 58 367
assign 1 59 368
LESSERGet 0 59 368
assign 1 59 369
new 0 59 369
put 2 59 370
assign 1 60 371
LESSER_EQUALSGet 0 60 371
assign 1 60 372
new 0 60 372
put 2 60 373
assign 1 61 374
EQUALSGet 0 61 374
assign 1 61 375
new 0 61 375
put 2 61 376
assign 1 62 377
NOT_EQUALSGet 0 62 377
assign 1 62 378
new 0 62 378
put 2 62 379
assign 1 63 380
ANDGet 0 63 380
assign 1 63 381
new 0 63 381
put 2 63 382
assign 1 64 383
ORGet 0 64 383
assign 1 64 384
new 0 64 384
put 2 64 385
assign 1 65 386
LOGICAL_ANDGet 0 65 386
assign 1 65 387
new 0 65 387
put 2 65 388
assign 1 66 389
LOGICAL_ORGet 0 66 389
assign 1 66 390
new 0 66 390
put 2 66 391
assign 1 67 392
INGet 0 67 392
assign 1 67 393
new 0 67 393
put 2 67 394
assign 1 68 395
ADD_ASSIGNGet 0 68 395
assign 1 68 396
new 0 68 396
put 2 68 397
assign 1 69 398
SUBTRACT_ASSIGNGet 0 69 398
assign 1 69 399
new 0 69 399
put 2 69 400
assign 1 70 401
MULTIPLY_ASSIGNGet 0 70 401
assign 1 70 402
new 0 70 402
put 2 70 403
assign 1 71 404
DIVIDE_ASSIGNGet 0 71 404
assign 1 71 405
new 0 71 405
put 2 71 406
assign 1 72 407
MODULUS_ASSIGNGet 0 72 407
assign 1 72 408
new 0 72 408
put 2 72 409
assign 1 73 410
AND_ASSIGNGet 0 73 410
assign 1 73 411
new 0 73 411
put 2 73 412
assign 1 74 413
OR_ASSIGNGet 0 74 413
assign 1 74 414
new 0 74 414
put 2 74 415
assign 1 75 416
ASSIGNGet 0 75 416
assign 1 75 417
new 0 75 417
put 2 75 418
assign 1 77 419
NOTGet 0 77 419
assign 1 77 420
new 0 77 420
put 2 77 421
assign 1 78 422
ONCEGet 0 78 422
assign 1 78 423
new 0 78 423
put 2 78 424
assign 1 79 425
MANYGet 0 79 425
assign 1 79 426
new 0 79 426
put 2 79 427
assign 1 80 428
INCREMENTGet 0 80 428
assign 1 80 429
new 0 80 429
put 2 80 430
assign 1 81 431
DECREMENTGet 0 81 431
assign 1 81 432
new 0 81 432
put 2 81 433
assign 1 82 434
MULTIPLYGet 0 82 434
assign 1 82 435
new 0 82 435
put 2 82 436
assign 1 83 437
DIVIDEGet 0 83 437
assign 1 83 438
new 0 83 438
put 2 83 439
assign 1 84 440
MODULUSGet 0 84 440
assign 1 84 441
new 0 84 441
put 2 84 442
assign 1 85 443
ADDGet 0 85 443
assign 1 85 444
new 0 85 444
put 2 85 445
assign 1 86 446
SUBTRACTGet 0 86 446
assign 1 86 447
new 0 86 447
put 2 86 448
assign 1 87 449
GREATERGet 0 87 449
assign 1 87 450
new 0 87 450
put 2 87 451
assign 1 88 452
GREATER_EQUALSGet 0 88 452
assign 1 88 453
new 0 88 453
put 2 88 454
assign 1 89 455
LESSERGet 0 89 455
assign 1 89 456
new 0 89 456
put 2 89 457
assign 1 90 458
LESSER_EQUALSGet 0 90 458
assign 1 90 459
new 0 90 459
put 2 90 460
assign 1 91 461
EQUALSGet 0 91 461
assign 1 91 462
new 0 91 462
put 2 91 463
assign 1 92 464
NOT_EQUALSGet 0 92 464
assign 1 92 465
new 0 92 465
put 2 92 466
assign 1 93 467
ANDGet 0 93 467
assign 1 93 468
new 0 93 468
put 2 93 469
assign 1 94 470
ORGet 0 94 470
assign 1 94 471
new 0 94 471
put 2 94 472
assign 1 95 473
LOGICAL_ANDGet 0 95 473
assign 1 95 474
new 0 95 474
put 2 95 475
assign 1 96 476
LOGICAL_ORGet 0 96 476
assign 1 96 477
new 0 96 477
put 2 96 478
assign 1 97 479
INGet 0 97 479
assign 1 97 480
new 0 97 480
put 2 97 481
assign 1 98 482
ADD_ASSIGNGet 0 98 482
assign 1 98 483
new 0 98 483
put 2 98 484
assign 1 99 485
SUBTRACT_ASSIGNGet 0 99 485
assign 1 99 486
new 0 99 486
put 2 99 487
assign 1 100 488
INCREMENT_ASSIGNGet 0 100 488
assign 1 100 489
new 0 100 489
put 2 100 490
assign 1 101 491
DECREMENT_ASSIGNGet 0 101 491
assign 1 101 492
new 0 101 492
put 2 101 493
assign 1 102 494
MULTIPLY_ASSIGNGet 0 102 494
assign 1 102 495
new 0 102 495
put 2 102 496
assign 1 103 497
DIVIDE_ASSIGNGet 0 103 497
assign 1 103 498
new 0 103 498
put 2 103 499
assign 1 104 500
MODULUS_ASSIGNGet 0 104 500
assign 1 104 501
new 0 104 501
put 2 104 502
assign 1 105 503
AND_ASSIGNGet 0 105 503
assign 1 105 504
new 0 105 504
put 2 105 505
assign 1 106 506
OR_ASSIGNGet 0 106 506
assign 1 106 507
new 0 106 507
put 2 106 508
assign 1 107 509
ASSIGNGet 0 107 509
assign 1 107 510
new 0 107 510
put 2 107 511
assign 1 109 512
IFGet 0 109 512
assign 1 109 513
new 0 109 513
put 2 109 514
assign 1 110 515
ELIFGet 0 110 515
assign 1 110 516
new 0 110 516
put 2 110 517
assign 1 111 518
WHILEGet 0 111 518
assign 1 111 519
new 0 111 519
put 2 111 520
assign 1 112 521
FORGet 0 112 521
assign 1 112 522
new 0 112 522
put 2 112 523
assign 1 113 524
FOREACHGet 0 113 524
assign 1 113 525
new 0 113 525
put 2 113 526
assign 1 114 527
EMITGet 0 114 527
assign 1 114 528
new 0 114 528
put 2 114 529
assign 1 115 530
IFEMITGet 0 115 530
assign 1 115 531
new 0 115 531
put 2 115 532
assign 1 116 533
METHODGet 0 116 533
assign 1 116 534
new 0 116 534
put 2 116 535
assign 1 117 536
CLASSGet 0 117 536
assign 1 117 537
new 0 117 537
put 2 117 538
assign 1 118 539
EXPRGet 0 118 539
assign 1 118 540
new 0 118 540
put 2 118 541
assign 1 119 542
ELSEGet 0 119 542
assign 1 119 543
new 0 119 543
put 2 119 544
assign 1 120 545
TRYGet 0 120 545
assign 1 120 546
new 0 120 546
put 2 120 547
assign 1 121 548
LOOPGet 0 121 548
assign 1 121 549
new 0 121 549
put 2 121 550
assign 1 122 551
PROPERTIESGet 0 122 551
assign 1 122 552
new 0 122 552
put 2 122 553
assign 1 123 554
CATCHGet 0 123 554
assign 1 123 555
new 0 123 555
put 2 123 556
assign 1 124 557
TRANSUNITGet 0 124 557
assign 1 124 558
new 0 124 558
put 2 124 559
assign 1 125 560
BRACESGet 0 125 560
assign 1 125 561
new 0 125 561
put 2 125 562
assign 1 126 563
PARENSGet 0 126 563
assign 1 126 564
new 0 126 564
put 2 126 565
assign 1 127 566
IDXGet 0 127 566
assign 1 127 567
new 0 127 567
put 2 127 568
assign 1 129 569
IFGet 0 129 569
assign 1 129 570
new 0 129 570
put 2 129 571
assign 1 130 572
ELIFGet 0 130 572
assign 1 130 573
new 0 130 573
put 2 130 574
assign 1 131 575
WHILEGet 0 131 575
assign 1 131 576
new 0 131 576
put 2 131 577
assign 1 132 578
FORGet 0 132 578
assign 1 132 579
new 0 132 579
put 2 132 580
assign 1 133 581
FOREACHGet 0 133 581
assign 1 133 582
new 0 133 582
put 2 133 583
assign 1 134 584
EMITGet 0 134 584
assign 1 134 585
new 0 134 585
put 2 134 586
assign 1 135 587
IFEMITGet 0 135 587
assign 1 135 588
new 0 135 588
put 2 135 589
assign 1 136 590
METHODGet 0 136 590
assign 1 136 591
new 0 136 591
put 2 136 592
assign 1 137 593
CATCHGet 0 137 593
assign 1 137 594
new 0 137 594
put 2 137 595
assign 1 139 596
IFGet 0 139 596
assign 1 139 597
new 0 139 597
put 2 139 598
assign 1 140 599
ELIFGet 0 140 599
assign 1 140 600
new 0 140 600
put 2 140 601
assign 1 141 602
WHILEGet 0 141 602
assign 1 141 603
new 0 141 603
put 2 141 604
assign 1 142 605
FORGet 0 142 605
assign 1 142 606
new 0 142 606
put 2 142 607
assign 1 143 608
FOREACHGet 0 143 608
assign 1 143 609
new 0 143 609
put 2 143 610
assign 1 144 611
EXPRGet 0 144 611
assign 1 144 612
new 0 144 612
put 2 144 613
prepare 0 146 614
assign 1 152 726
new 0 152 726
assign 1 153 727
new 0 153 727
assign 1 155 728
new 0 155 728
assign 1 156 729
new 0 156 729
assign 1 156 730
new 2 156 730
assign 1 157 731
DIVIDEGet 0 157 731
put 2 157 732
assign 1 159 733
new 0 159 733
addToken 1 160 734
assign 1 161 735
BRACESGet 0 161 735
put 2 161 736
assign 1 163 737
new 0 163 737
addToken 1 164 738
assign 1 165 739
RBRACESGet 0 165 739
put 2 165 740
assign 1 167 741
new 0 167 741
addToken 1 168 742
assign 1 169 743
PARENSGet 0 169 743
put 2 169 744
assign 1 171 745
new 0 171 745
addToken 1 172 746
assign 1 173 747
RPARENSGet 0 173 747
put 2 173 748
assign 1 175 749
new 0 175 749
addToken 1 176 750
assign 1 177 751
SEMIGet 0 177 751
put 2 177 752
assign 1 179 753
new 0 179 753
addToken 1 180 754
assign 1 181 755
COLONGet 0 181 755
put 2 181 756
assign 1 183 757
new 0 183 757
addToken 1 184 758
assign 1 185 759
COMMAGet 0 185 759
put 2 185 760
assign 1 187 761
new 0 187 761
addToken 1 188 762
assign 1 189 763
ADDGet 0 189 763
put 2 189 764
assign 1 191 765
new 0 191 765
addToken 1 192 766
assign 1 193 767
ATYPEGet 0 193 767
put 2 193 768
assign 1 195 769
new 0 195 769
addToken 1 196 770
assign 1 197 771
SUBTRACTGet 0 197 771
put 2 197 772
assign 1 199 773
new 0 199 773
addToken 1 200 774
assign 1 201 775
ONCEGet 0 201 775
put 2 201 776
assign 1 203 777
new 0 203 777
addToken 1 204 778
assign 1 205 779
MANYGet 0 205 779
put 2 205 780
assign 1 209 781
new 0 209 781
assign 1 209 782
codeNew 1 209 782
addToken 1 211 783
assign 1 212 784
FSLASHGet 0 212 784
put 2 212 785
assign 1 214 786
new 0 214 786
assign 1 214 787
codeNew 1 214 787
addToken 1 216 788
assign 1 217 789
STRQGet 0 217 789
put 2 217 790
assign 1 219 791
new 0 219 791
assign 1 219 792
codeNew 1 219 792
addToken 1 221 793
assign 1 222 794
WSTRQGet 0 222 794
put 2 222 795
assign 1 224 796
new 0 224 796
assign 1 224 797
codeNew 1 224 797
addToken 1 226 798
assign 1 227 799
IDXGet 0 227 799
put 2 227 800
assign 1 229 801
new 0 229 801
assign 1 229 802
codeNew 1 229 802
addToken 1 231 803
assign 1 232 804
RIDXGet 0 232 804
put 2 232 805
assign 1 234 806
new 0 234 806
assign 1 234 807
codeNew 1 234 807
addToken 1 236 808
assign 1 237 809
MODULUSGet 0 237 809
put 2 237 810
assign 1 239 811
new 0 239 811
assign 1 239 812
codeNew 1 239 812
addToken 1 241 813
assign 1 242 814
ASSIGNGet 0 242 814
put 2 242 815
assign 1 244 816
new 0 244 816
assign 1 244 817
codeNew 1 244 817
addToken 1 246 818
assign 1 247 819
GREATERGet 0 247 819
put 2 247 820
assign 1 249 821
new 0 249 821
assign 1 249 822
codeNew 1 249 822
addToken 1 251 823
assign 1 252 824
LESSERGet 0 252 824
put 2 252 825
assign 1 254 826
new 0 254 826
assign 1 254 827
codeNew 1 254 827
addToken 1 256 828
assign 1 257 829
NOTGet 0 257 829
put 2 257 830
assign 1 259 831
new 0 259 831
assign 1 259 832
codeNew 1 259 832
addToken 1 261 833
assign 1 262 834
ANDGet 0 262 834
put 2 262 835
assign 1 264 836
new 0 264 836
assign 1 264 837
codeNew 1 264 837
addToken 1 266 838
assign 1 267 839
ORGet 0 267 839
put 2 267 840
assign 1 269 841
new 0 269 841
assign 1 269 842
codeNew 1 269 842
addToken 1 271 843
assign 1 272 844
MULTIPLYGet 0 272 844
put 2 272 845
assign 1 274 846
new 0 274 846
assign 1 274 847
codeNew 1 274 847
addToken 1 276 848
assign 1 277 849
DOTGet 0 277 849
put 2 277 850
assign 1 279 851
new 0 279 851
assign 1 279 852
codeNew 1 279 852
addToken 1 281 853
assign 1 282 854
SPACEGet 0 282 854
put 2 282 855
assign 1 284 856
new 0 284 856
assign 1 284 857
codeNew 1 284 857
addToken 1 286 858
assign 1 287 859
SPACEGet 0 287 859
put 2 287 860
assign 1 289 861
new 0 289 861
assign 1 289 862
newlineGet 0 289 862
addToken 1 291 863
assign 1 292 864
NEWLINEGet 0 292 864
put 2 292 865
assign 1 295 866
new 0 295 866
assign 1 296 867
new 0 296 867
assign 1 296 868
USEGet 0 296 868
put 2 296 869
assign 1 297 870
new 0 297 870
assign 1 297 871
ASGet 0 297 871
put 2 297 872
assign 1 298 873
new 0 298 873
assign 1 298 874
CLASSGet 0 298 874
put 2 298 875
assign 1 299 876
new 0 299 876
assign 1 299 877
METHODGet 0 299 877
put 2 299 878
assign 1 300 879
new 0 300 879
assign 1 300 880
DEFMODGet 0 300 880
put 2 300 881
assign 1 301 882
new 0 301 882
assign 1 301 883
DEFMODGet 0 301 883
put 2 301 884
assign 1 302 885
new 0 302 885
assign 1 302 886
DEFMODGet 0 302 886
put 2 302 887
assign 1 303 888
new 0 303 888
assign 1 303 889
VARGet 0 303 889
put 2 303 890
assign 1 305 891
new 0 305 891
assign 1 305 892
IFGet 0 305 892
put 2 305 893
assign 1 306 894
new 0 306 894
assign 1 306 895
IFGet 0 306 895
put 2 306 896
assign 1 307 897
new 0 307 897
assign 1 307 898
ELIFGet 0 307 898
put 2 307 899
assign 1 308 900
new 0 308 900
assign 1 308 901
ELSEGet 0 308 901
put 2 308 902
assign 1 309 903
new 0 309 903
assign 1 309 904
LOOPGet 0 309 904
put 2 309 905
assign 1 311 906
new 0 311 906
assign 1 311 907
PROPERTIESGet 0 311 907
put 2 311 908
assign 1 312 909
new 0 312 909
assign 1 312 910
WHILEGet 0 312 910
put 2 312 911
assign 1 313 912
new 0 313 912
assign 1 313 913
WHILEGet 0 313 913
put 2 313 914
assign 1 314 915
new 0 314 915
assign 1 314 916
FORGet 0 314 916
put 2 314 917
assign 1 315 918
new 0 315 918
assign 1 315 919
FOREACHGet 0 315 919
put 2 315 920
assign 1 316 921
new 0 316 921
assign 1 316 922
INGet 0 316 922
put 2 316 923
assign 1 317 924
new 0 317 924
assign 1 317 925
EMITGet 0 317 925
put 2 317 926
assign 1 318 927
new 0 318 927
assign 1 318 928
IFEMITGet 0 318 928
put 2 318 929
assign 1 319 930
new 0 319 930
assign 1 319 931
IFEMITGet 0 319 931
put 2 319 932
assign 1 320 933
new 0 320 933
assign 1 320 934
BREAKGet 0 320 934
put 2 320 935
assign 1 321 936
new 0 321 936
assign 1 321 937
CONTINUEGet 0 321 937
put 2 321 938
assign 1 322 939
new 0 322 939
assign 1 322 940
NULLGet 0 322 940
put 2 322 941
assign 1 323 942
new 0 323 942
assign 1 323 943
TRUEGet 0 323 943
put 2 323 944
assign 1 324 945
new 0 324 945
assign 1 324 946
FALSEGet 0 324 946
put 2 324 947
assign 1 325 948
new 0 325 948
assign 1 325 949
TRYGet 0 325 949
put 2 325 950
assign 1 326 951
new 0 326 951
assign 1 326 952
CATCHGet 0 326 952
put 2 326 953
return 1 0 957
assign 1 0 960
return 1 0 964
assign 1 0 967
return 1 0 971
assign 1 0 974
return 1 0 978
assign 1 0 981
return 1 0 985
assign 1 0 988
return 1 0 992
assign 1 0 995
return 1 0 999
assign 1 0 1002
return 1 0 1006
assign 1 0 1009
return 1 0 1013
assign 1 0 1016
return 1 0 1020
assign 1 0 1023
return 1 0 1027
assign 1 0 1030
return 1 0 1034
assign 1 0 1037
return 1 0 1041
assign 1 0 1044
return 1 0 1048
assign 1 0 1051
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 499424269: return bem_operNamesGet_0();
case 1323554192: return bem_matchMapGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 485024848: return bem_conTypesGet_0();
case 845792839: return bem_iteratorGet_0();
case 1638254553: return bem_operGet_0();
case 1284159779: return bem_anchorTypesGet_0();
case 1012494862: return bem_once_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 667821230: return bem_parensReqGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1081412016: return bem_many_0();
case 1260156474: return bem_maxargsGet_0();
case 1011420424: return bem_prepare_0();
case 634261936: return bem_rwordsGet_0();
case 314718434: return bem_print_0();
case 614472113: return bem_mtdxPadGet_0();
case 644675716: return bem_ntypesGet_0();
case 104713553: return bem_new_0();
case 1308786538: return bem_echo_0();
case 287040793: return bem_hashGet_0();
case 521161323: return bem_unwindToGet_0();
case 264093610: return bem_unwindOkGet_0();
case 2055025483: return bem_serializeContents_0();
case 1503762842: return bem_twtokGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 895284094: return bem_extraSlotsGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1514845095: return bem_twtokSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 656738977: return bem_parensReqSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 510506522: return bem_operNamesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1249074221: return bem_maxargsSet_1(bevd_0);
case 623179683: return bem_rwordsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 603389860: return bem_mtdxPadSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1649336806: return bem_operSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1295242032: return bem_anchorTypesSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 884201841: return bem_extraSlotsSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1312471939: return bem_matchMapSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 532243576: return bem_unwindToSet_1(bevd_0);
case 473942595: return bem_conTypesSet_1(bevd_0);
case 275175863: return bem_unwindOkSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_9_BuildConstants();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_9_BuildConstants.bevs_inst = (BEC_5_9_BuildConstants)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_9_BuildConstants.bevs_inst;
}
}
}
