namespace be.BEL_4_Base {
/* File: source/build/Syns.be */
public class BEC_5_8_BuildClassSyn : BEC_6_6_SystemObject {
public BEC_5_8_BuildClassSyn() { }
static BEC_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_15, 84));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_16, 80));
private static byte[] bels_17 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_17, 9));
private static byte[] bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_18, 26));
private static BEC_9_5_ContainerArray bevo_18;
private static BEC_4_3_MathInt bevo_19 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_19 = {0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
private static byte[] bels_20 = {0x64,0x65,0x70,0x74,0x68};
private static byte[] bels_21 = {0x66,0x72,0x6F,0x6D,0x46,0x69,0x6C,0x65};
private static byte[] bels_22 = {0x6C,0x69,0x62,0x4E,0x61,0x6D,0x65};
private static byte[] bels_23 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bels_24 = {0x69,0x73,0x4C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_25 = {0x73,0x75,0x70,0x65,0x72,0x4C,0x69,0x73,0x74};
private static byte[] bels_26 = {0x75,0x73,0x65,0x73};
private static byte[] bels_27 = {0x70,0x74,0x79,0x4C,0x69,0x73,0x74};
private static byte[] bels_28 = {0x6D,0x74,0x64,0x4C,0x69,0x73,0x74};
private static byte[] bels_29 = {0x61,0x6C,0x6C,0x41,0x6E,0x63,0x65,0x73,0x74,0x6F,0x72,0x73,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_30 = {0x69,0x73,0x4E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
public static new BEC_5_8_BuildClassSyn bevs_inst;
public BEC_5_8_BuildNamePath bevp_superNp;
public BEC_4_3_MathInt bevp_depth;
public BEC_5_8_BuildNamePath bevp_namepath;
public BEC_2_4_4_IOFilePath bevp_fromFile;
public BEC_4_6_TextString bevp_libName;
public BEC_5_4_LogicBool bevp_isLocal;
public BEC_5_4_LogicBool bevp_isNotNull;
public BEC_4_3_MathInt bevp_newMbrs;
public BEC_4_3_MathInt bevp_newMtds;
public BEC_4_3_MathInt bevp_defMtds;
public BEC_5_4_LogicBool bevp_directProperties;
public BEC_5_4_LogicBool bevp_directMethods;
public BEC_9_3_ContainerMap bevp_allTypes;
public BEC_9_10_ContainerLinkedList bevp_superList;
public BEC_9_3_ContainerMap bevp_mtdMap;
public BEC_9_5_ContainerArray bevp_mtdList;
public BEC_9_3_ContainerMap bevp_ptyMap;
public BEC_9_5_ContainerArray bevp_ptyList;
public BEC_9_3_ContainerMap bevp_allNames;
public BEC_9_3_ContainerMap bevp_foreignClasses;
public BEC_5_4_LogicBool bevp_allAncestorsClose;
public BEC_5_4_LogicBool bevp_integrated;
public BEC_5_4_LogicBool bevp_iChecked;
public BEC_9_3_ContainerSet bevp_uses;
public BEC_5_4_LogicBool bevp_isFinal;
public BEC_5_4_LogicBool bevp_signatureChanged;
public BEC_5_4_LogicBool bevp_signatureChecked;
public override BEC_6_6_SystemObject bem_new_0() {
bevp_allTypes = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_superList = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_ptyMap = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_allNames = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_maxMtdxGet_0() {
BEC_4_3_MathInt bevl_maxMtdx = null;
BEC_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_5_6_BuildMtdSyn bevl_ms = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevl_maxMtdx = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 104 */ {
bevt_0_tmpvar_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevl_ms = (BEC_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpvar_phold = bevl_ms.bem_mtdxGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_greater_1(bevl_maxMtdx);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 106 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 107 */
} /* Line: 106 */
 else  /* Line: 104 */ {
break;
} /* Line: 104 */
} /* Line: 104 */
return bevl_maxMtdx;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_hasDefaultGet_0() {
BEC_6_6_SystemObject bevl_dmtd = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpvar_phold);
if (bevl_dmtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 117 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
this.bem_new_0();
return this;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_new_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_psyn) {
BEC_6_6_SystemObject bevl_pmr = null;
BEC_6_6_SystemObject bevl_omr = null;
BEC_6_6_SystemObject bevl_iv = null;
BEC_6_6_SystemObject bevl_ov = null;
BEC_6_6_SystemObject bevl_pv = null;
BEC_6_6_SystemObject bevl_im = null;
BEC_6_6_SystemObject bevl_om = null;
BEC_6_6_SystemObject bevl_pm = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
bevp_allTypes = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = beva_psyn.bemd_0(1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_9_10_ContainerLinkedList) bevt_2_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpvar_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_9_5_ContainerArray) bevt_4_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_9_5_ContainerArray) bevt_5_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 142 */ {
bevt_8_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpvar_phold);
bevt_14_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_1));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 145 */ {
if (bevl_pv == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
 else  /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_19_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_24_tmpvar_phold = bevo_1;
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_2;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 146 */
} /* Line: 145 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevt_31_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 151 */ {
bevt_32_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 151 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevt_35_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpvar_phold);
} /* Line: 154 */
} /* Line: 153 */
 else  /* Line: 151 */ {
break;
} /* Line: 151 */
} /* Line: 151 */
bevt_39_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 158 */ {
bevt_40_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 158 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpvar_phold);
if (bevl_pm == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevt_46_tmpvar_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpvar_phold == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_49_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpvar_phold == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_54_tmpvar_phold = bevo_3;
bevt_56_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_55_tmpvar_phold);
bevt_57_tmpvar_phold = bevo_4;
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_59_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_50_tmpvar_phold);
} /* Line: 164 */
} /* Line: 163 */
} /* Line: 162 */
} /* Line: 161 */
 else  /* Line: 158 */ {
break;
} /* Line: 158 */
} /* Line: 158 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpvar_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevp_depth = (BEC_4_3_MathInt) bevt_60_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_castsTo_1(BEC_5_8_BuildNamePath beva_cto) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_integrate_1(BEC_5_5_BuildBuild beva_build) {
BEC_5_6_BuildMtdSyn bevl_om = null;
BEC_5_8_BuildClassSyn bevl_psyn = null;
BEC_5_8_BuildNamePath bevl_pn = null;
BEC_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_6_6_SystemObject bevl_im = null;
BEC_5_6_BuildMtdSyn bevl_pm = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_8_tmpvar_phold = null;
BEC_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_5_11_BuildMethodIndex bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_55_tmpvar_phold = null;
BEC_5_8_BuildEmitData bevt_56_tmpvar_phold = null;
BEC_5_11_BuildMethodIndex bevt_57_tmpvar_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 178 */ {
return this;
} /* Line: 178 */
bevp_integrated = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directProperties = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directMethods = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevp_allAncestorsClose = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpvar_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 188 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 188 */ {
bevl_om = (BEC_5_6_BuildMtdSyn) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_methodIndexesGet_0();
bevt_10_tmpvar_phold = (BEC_5_11_BuildMethodIndex) (new BEC_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpvar_phold.bem_put_1(bevt_10_tmpvar_phold);
} /* Line: 189 */
 else  /* Line: 188 */ {
break;
} /* Line: 188 */
} /* Line: 188 */
return this;
} /* Line: 191 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_defMtds = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_11_tmpvar_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpvar_phold.bem_subtract_1(bevt_12_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 198 */
bevt_16_tmpvar_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_19_tmpvar_phold = bevo_5;
bevt_20_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 200 */
bevt_21_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_23_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 202 */
 else  /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 202 */ {
bevt_26_tmpvar_phold = bevo_6;
bevt_27_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_24_tmpvar_phold);
} /* Line: 203 */
bevt_28_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_29_tmpvar_phold = bevp_isLocal.bem_not_0();
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 205 */ {
bevt_30_tmpvar_phold = bevp_isFinal.bem_not_0();
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 205 */ {
bevt_33_tmpvar_phold = bevo_7;
bevt_34_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_31_tmpvar_phold);
} /* Line: 206 */
bevt_1_tmpvar_loop = bevp_superList.bem_iteratorGet_0();
while (true)
 /* Line: 208 */ {
bevt_35_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 208 */ {
bevl_pn = (BEC_5_8_BuildNamePath) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_has_1(bevt_39_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_not_0();
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_41_tmpvar_phold = bevl_pn.bem_toString_0();
bevt_42_tmpvar_phold = bevo_8;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_notEquals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 210 */
 else  /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 210 */ {
bevp_directProperties = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_directMethods = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 213 */
bevt_45_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_has_1(bevt_46_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_not_0();
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevp_allAncestorsClose = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 216 */
} /* Line: 215 */
 else  /* Line: 208 */ {
break;
} /* Line: 208 */
} /* Line: 208 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 220 */ {
bevt_47_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 220 */ {
bevl_om = (BEC_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpvar_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpvar_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_5_6_BuildMtdSyn) bevt_48_tmpvar_phold.bem_get_1(bevt_49_tmpvar_phold);
if (bevl_pm == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_51_tmpvar_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_52_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpvar_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 227 */
} /* Line: 224 */
 else  /* Line: 229 */ {
bevt_54_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpvar_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_methodIndexesGet_0();
bevt_57_tmpvar_phold = (BEC_5_11_BuildMethodIndex) (new BEC_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpvar_phold.bem_put_1(bevt_57_tmpvar_phold);
} /* Line: 233 */
} /* Line: 223 */
 else  /* Line: 220 */ {
break;
} /* Line: 220 */
} /* Line: 220 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_checkInheritance_2(BEC_6_6_SystemObject beva_build, BEC_6_6_SystemObject beva_klass) {
BEC_6_6_SystemObject bevl_psyn = null;
BEC_6_6_SystemObject bevl_iv = null;
BEC_6_6_SystemObject bevl_ov = null;
BEC_6_6_SystemObject bevl_pv = null;
BEC_6_6_SystemObject bevl_im = null;
BEC_6_6_SystemObject bevl_om = null;
BEC_6_6_SystemObject bevl_pm = null;
BEC_6_6_SystemObject bevl_oa = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_pmr = null;
BEC_6_6_SystemObject bevl_omr = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 240 */ {
return this;
} /* Line: 240 */
bevp_iChecked = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 242 */ {
return this;
} /* Line: 242 */
bevl_psyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_3_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 244 */ {
bevt_5_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 244 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_6_tmpvar_phold = bevl_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_8_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
if (bevl_pv == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_16_tmpvar_phold = bevo_9;
bevt_18_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_10;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_13_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_12_tmpvar_phold);
} /* Line: 249 */
 else  /* Line: 250 */ {
bevt_23_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_23_tmpvar_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_24_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_27_tmpvar_phold);
} /* Line: 252 */
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 244 */ {
break;
} /* Line: 244 */
} /* Line: 244 */
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_29_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 256 */ {
bevt_31_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 256 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_32_tmpvar_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_34_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_32_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_33_tmpvar_phold);
if (bevl_pm == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_36_tmpvar_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevt_41_tmpvar_phold = bevo_11;
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_12;
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_47_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_38_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_37_tmpvar_phold);
} /* Line: 261 */
bevt_49_tmpvar_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_48_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 264 */ {
bevt_52_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_50_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 264 */ {
bevt_53_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_53_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_54_tmpvar_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_54_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 264 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_55_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_55_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
if (bevl_omr == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
if (bevl_pmr == null) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bem_not_0();
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
if (bevl_omr == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_not_0();
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 273 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 273 */ {
bevt_64_tmpvar_phold = bevo_13;
bevt_67_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_add_1(bevt_65_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_63_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_62_tmpvar_phold);
} /* Line: 274 */
} /* Line: 273 */
 else  /* Line: 276 */ {
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 278 */
} /* Line: 272 */
} /* Line: 259 */
 else  /* Line: 256 */ {
break;
} /* Line: 256 */
} /* Line: 256 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_checkTypes_5(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_build, BEC_6_6_SystemObject beva_pmr, BEC_6_6_SystemObject beva_omr, BEC_6_6_SystemObject beva_om) {
BEC_6_6_SystemObject bevl_osyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpvar_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevt_6_tmpvar_phold = bevo_14;
bevt_9_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
bevt_10_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_11_tmpvar_phold = beva_pmr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_12_tmpvar_phold = beva_omr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
return this;
} /* Line: 291 */
bevt_13_tmpvar_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_osyn.bemd_0(986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpvar_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 294 */ {
bevt_20_tmpvar_phold = bevo_15;
bevt_23_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_18_tmpvar_phold);
} /* Line: 295 */
} /* Line: 294 */
} /* Line: 285 */
return this;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_new_1(BEC_6_6_SystemObject beva_klass) {
BEC_6_6_SystemObject bevl_iv = null;
BEC_6_6_SystemObject bevl_ov = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
this.bem_new_0();
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 302 */ {
bevt_2_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 302 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 304 */ {
bevt_10_tmpvar_phold = bevo_16;
bevt_12_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_17;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 305 */
} /* Line: 304 */
 else  /* Line: 302 */ {
break;
} /* Line: 302 */
} /* Line: 302 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_loadClass_1(BEC_6_6_SystemObject beva_klass) {
BEC_6_6_SystemObject bevl_iu = null;
BEC_6_6_SystemObject bevl_ou = null;
BEC_6_6_SystemObject bevl_iv = null;
BEC_6_6_SystemObject bevl_ov = null;
BEC_6_6_SystemObject bevl_prop = null;
BEC_6_6_SystemObject bevl_im = null;
BEC_6_6_SystemObject bevl_om = null;
BEC_6_6_SystemObject bevl_msyn = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_5_8_BuildNamePath) bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_5_4_LogicBool) bevt_3_tmpvar_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_5_4_LogicBool) bevt_4_tmpvar_phold.bemd_0(842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_5_4_LogicBool) bevt_5_tmpvar_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 320 */ {
bevt_8_tmpvar_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpvar_phold);
} /* Line: 322 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
bevt_11_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 324 */ {
bevt_12_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 324 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 327 */
 else  /* Line: 324 */ {
break;
} /* Line: 324 */
} /* Line: 324 */
bevt_14_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 329 */ {
bevt_15_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 329 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 332 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
this.bem_postLoad_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_postLoad_0() {
BEC_9_5_ContainerArray bevl_nptyList = null;
BEC_9_5_ContainerArray bevl_mtdnList = null;
BEC_9_3_ContainerMap bevl_unq = null;
BEC_6_6_SystemObject bevl_iv = null;
BEC_6_6_SystemObject bevl_ov = null;
BEC_6_6_SystemObject bevl_mpos = null;
BEC_6_6_SystemObject bevl_nom = null;
BEC_9_3_ContainerMap bevl_mtdOmap = null;
BEC_6_6_SystemObject bevl_im = null;
BEC_6_6_SystemObject bevl_om = null;
BEC_4_3_MathInt bevl_mtdx = null;
BEC_6_6_SystemObject bevl_oma = null;
BEC_5_6_BuildMtdSyn bevl_msyno = null;
BEC_6_6_SystemObject bevl_s = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_27_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_28_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
bevl_nptyList = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_mtdnList = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 342 */ {
bevt_1_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 342 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevt_5_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpvar_phold, bevl_ov);
} /* Line: 346 */
} /* Line: 344 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevl_unq = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 352 */ {
bevt_6_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 352 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = bevl_unq.bem_has_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_not_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevt_10_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpvar_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
} /* Line: 359 */
} /* Line: 354 */
 else  /* Line: 352 */ {
break;
} /* Line: 352 */
} /* Line: 352 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 366 */ {
bevt_14_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 366 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpvar_phold, bevl_om);
bevt_18_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_not_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 371 */ {
bevt_19_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpvar_phold, bevl_om);
} /* Line: 372 */
} /* Line: 371 */
 else  /* Line: 366 */ {
break;
} /* Line: 366 */
} /* Line: 366 */
bevl_unq = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 378 */ {
bevt_20_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 378 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpvar_phold = bevl_unq.bem_has_1(bevt_23_tmpvar_phold);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_not_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevt_24_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevt_28_tmpvar_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpvar_phold);
} /* Line: 392 */
bevt_29_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpvar_phold);
bevl_oma.bemd_1(1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
} /* Line: 398 */
} /* Line: 380 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpvar_loop = bevp_superList.bem_iteratorGet_0();
while (true)
 /* Line: 403 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 403 */ {
bevl_s = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_5_8_BuildNamePath) bevl_s;
} /* Line: 405 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_9_5_ContainerArray bevl_names = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(12));
lock (typeof(BEC_5_8_BuildClassSyn)) {
if (bevo_18 == null) {
bevo_18 = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
}
}
bevl_names = bevo_18;
bevt_3_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevl_names.bem_get_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 413 */ {
bevt_4_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_19));
bevl_names.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_20));
bevl_names.bem_put_2(bevt_6_tmpvar_phold, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_21));
bevl_names.bem_put_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_22));
bevl_names.bem_put_2(bevt_10_tmpvar_phold, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4));
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_23));
bevl_names.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(5));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_24));
bevl_names.bem_put_2(bevt_14_tmpvar_phold, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(6));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_25));
bevl_names.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(7));
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_26));
bevl_names.bem_put_2(bevt_18_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_27));
bevl_names.bem_put_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(9));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_28));
bevl_names.bem_put_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(10));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(17, bels_29));
bevl_names.bem_put_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(11));
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_30));
bevl_names.bem_put_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
} /* Line: 425 */
bevt_28_tmpvar_phold = (new BEC_6_23_SystemNamedPropertiesIterator()).bem_new_2(this, bevl_names);
return bevt_28_tmpvar_phold;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_superNpGet_0() {
return bevp_superNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_superNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_superNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_depthGet_0() {
return bevp_depth;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_depthSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_depth = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_namepathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_namepath = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isLocalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isLocal = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isNotNullSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isNotNull = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_newMbrsGet_0() {
return bevp_newMbrs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_newMbrsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newMbrs = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_newMtdsGet_0() {
return bevp_newMtds;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_newMtdsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newMtds = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_defMtdsGet_0() {
return bevp_defMtds;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_defMtdsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_defMtds = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_directPropertiesGet_0() {
return bevp_directProperties;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_directPropertiesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_directProperties = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_directMethodsGet_0() {
return bevp_directMethods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_directMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_directMethods = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_allTypesGet_0() {
return bevp_allTypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_allTypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allTypes = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_superListGet_0() {
return bevp_superList;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_superListSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_superList = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_mtdMapGet_0() {
return bevp_mtdMap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mtdMapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdMap = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mtdListGet_0() {
return bevp_mtdList;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mtdListSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdList = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_ptyMapGet_0() {
return bevp_ptyMap;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ptyMapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ptyMap = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_ptyListGet_0() {
return bevp_ptyList;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ptyListSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ptyList = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_allNamesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allNames = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_foreignClassesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_foreignClasses = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_allAncestorsCloseGet_0() {
return bevp_allAncestorsClose;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_allAncestorsCloseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allAncestorsClose = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_integratedGet_0() {
return bevp_integrated;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_integratedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_integrated = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_iCheckedGet_0() {
return bevp_iChecked;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_iCheckedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_iChecked = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_usesGet_0() {
return bevp_uses;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_uses = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isFinalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isFinal = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_signatureChangedGet_0() {
return bevp_signatureChanged;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_signatureChangedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_signatureChanged = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_signatureCheckedGet_0() {
return bevp_signatureChecked;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_signatureCheckedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_signatureChecked = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {80, 82, 84, 86, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 103, 104, 104, 105, 106, 106, 107, 110, 114, 114, 115, 115, 117, 117, 119, 119, 122, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 136, 137, 137, 138, 138, 139, 139, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 145, 145, 145, 145, 145, 0, 0, 0, 145, 145, 145, 0, 0, 0, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 151, 151, 151, 152, 153, 153, 154, 154, 154, 154, 158, 158, 158, 158, 159, 160, 160, 160, 160, 161, 161, 162, 162, 162, 163, 163, 163, 163, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 169, 170, 170, 170, 174, 174, 178, 179, 180, 181, 182, 183, 183, 184, 185, 186, 187, 188, 0, 188, 188, 189, 189, 189, 189, 191, 193, 194, 195, 197, 197, 197, 197, 198, 198, 198, 199, 200, 200, 200, 200, 200, 202, 202, 202, 0, 0, 0, 203, 203, 203, 203, 203, 205, 205, 0, 0, 0, 205, 0, 0, 0, 206, 206, 206, 206, 206, 208, 0, 208, 208, 209, 210, 210, 210, 210, 210, 210, 210, 0, 0, 0, 212, 213, 215, 215, 215, 215, 216, 220, 220, 221, 222, 222, 222, 223, 223, 224, 225, 225, 226, 226, 227, 230, 230, 231, 232, 233, 233, 233, 233, 240, 241, 242, 242, 242, 243, 244, 244, 244, 244, 245, 246, 246, 246, 246, 247, 247, 248, 248, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 249, 251, 251, 251, 251, 252, 252, 252, 252, 256, 256, 256, 256, 257, 258, 258, 258, 258, 259, 259, 260, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 263, 263, 263, 264, 264, 264, 264, 265, 265, 266, 266, 268, 264, 270, 271, 271, 272, 272, 0, 272, 272, 0, 0, 273, 273, 0, 273, 273, 0, 0, 274, 274, 274, 274, 274, 274, 274, 278, 285, 285, 285, 286, 286, 286, 286, 286, 286, 286, 287, 290, 290, 0, 0, 0, 291, 293, 293, 294, 294, 294, 294, 295, 295, 295, 295, 295, 295, 295, 301, 302, 302, 302, 302, 303, 304, 304, 304, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 308, 309, 314, 314, 315, 315, 316, 316, 317, 317, 318, 318, 319, 319, 320, 320, 320, 320, 321, 322, 322, 324, 324, 324, 324, 325, 326, 327, 329, 329, 329, 329, 330, 331, 332, 334, 338, 339, 342, 342, 343, 344, 344, 344, 346, 346, 350, 351, 352, 352, 353, 354, 354, 354, 355, 355, 356, 357, 357, 358, 359, 359, 359, 362, 364, 366, 366, 367, 369, 369, 371, 371, 371, 372, 372, 376, 377, 378, 378, 379, 380, 380, 380, 381, 381, 390, 390, 391, 391, 391, 392, 392, 394, 394, 395, 396, 397, 398, 398, 398, 401, 403, 0, 403, 403, 404, 405, 408, 412, 412, 413, 413, 413, 413, 414, 414, 414, 415, 415, 415, 416, 416, 416, 417, 417, 417, 418, 418, 418, 419, 419, 419, 420, 420, 420, 421, 421, 421, 422, 422, 422, 423, 423, 423, 424, 424, 424, 425, 425, 425, 427, 427, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 112, 113, 116, 118, 119, 120, 122, 129, 137, 138, 139, 144, 145, 146, 148, 149, 152, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 250, 252, 253, 254, 255, 256, 257, 258, 259, 260, 262, 267, 268, 271, 275, 278, 279, 280, 282, 285, 289, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 310, 311, 314, 316, 317, 318, 320, 321, 322, 323, 330, 331, 332, 335, 337, 338, 339, 340, 341, 342, 347, 348, 349, 354, 355, 356, 357, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 382, 383, 384, 385, 390, 391, 459, 461, 462, 463, 464, 465, 470, 471, 472, 473, 474, 475, 475, 478, 480, 481, 482, 483, 484, 490, 492, 493, 494, 495, 496, 497, 498, 499, 500, 502, 504, 506, 507, 508, 509, 510, 512, 514, 515, 517, 520, 524, 527, 528, 529, 530, 531, 533, 535, 537, 540, 544, 547, 549, 552, 556, 559, 560, 561, 562, 563, 565, 565, 568, 570, 571, 572, 573, 574, 575, 577, 578, 579, 581, 584, 588, 591, 592, 594, 595, 596, 597, 599, 606, 609, 611, 612, 613, 614, 615, 620, 621, 623, 624, 625, 626, 627, 631, 632, 633, 634, 635, 636, 637, 638, 728, 730, 731, 736, 737, 739, 740, 741, 742, 745, 747, 748, 749, 750, 751, 752, 757, 758, 759, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 775, 776, 777, 778, 779, 780, 781, 782, 790, 791, 792, 795, 797, 798, 799, 800, 801, 802, 807, 808, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 823, 824, 825, 826, 829, 830, 831, 833, 834, 835, 836, 837, 838, 844, 845, 846, 847, 852, 853, 856, 861, 862, 865, 869, 874, 876, 879, 884, 886, 889, 893, 894, 895, 896, 897, 898, 899, 903, 939, 940, 941, 943, 944, 945, 946, 947, 948, 949, 952, 954, 956, 958, 961, 965, 968, 970, 971, 972, 973, 974, 975, 977, 978, 979, 980, 981, 982, 983, 1009, 1010, 1011, 1012, 1015, 1017, 1018, 1019, 1020, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1040, 1041, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1086, 1088, 1089, 1090, 1096, 1097, 1098, 1101, 1103, 1104, 1105, 1111, 1112, 1113, 1116, 1118, 1119, 1120, 1126, 1177, 1178, 1179, 1182, 1184, 1185, 1186, 1187, 1189, 1190, 1197, 1198, 1199, 1202, 1204, 1205, 1206, 1207, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1224, 1225, 1226, 1229, 1231, 1232, 1233, 1234, 1235, 1236, 1238, 1239, 1246, 1247, 1248, 1251, 1253, 1254, 1255, 1256, 1258, 1259, 1260, 1261, 1262, 1263, 1268, 1269, 1270, 1272, 1273, 1274, 1275, 1276, 1277, 1278, 1279, 1286, 1287, 1287, 1290, 1292, 1293, 1294, 1300, 1334, 1335, 1341, 1342, 1343, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1386, 1387, 1390, 1393, 1397, 1400, 1404, 1407, 1411, 1414, 1418, 1421, 1425, 1428, 1432, 1435, 1439, 1442, 1446, 1449, 1453, 1456, 1460, 1463, 1467, 1470, 1474, 1477, 1481, 1484, 1488, 1491, 1495, 1498, 1502, 1505, 1509, 1512, 1516, 1519, 1523, 1526, 1530, 1533, 1537, 1540, 1544, 1547, 1551, 1554, 1558, 1561, 1565, 1568, 1572, 1575};
/* BEGIN LINEINFO 
assign 1 80 88
new 0 80 88
assign 1 82 89
new 0 82 89
assign 1 84 90
new 0 84 90
assign 1 86 91
new 0 86 91
assign 1 87 92
new 0 87 92
assign 1 88 93
new 0 88 93
assign 1 89 94
new 0 89 94
assign 1 90 95
new 0 90 95
assign 1 91 96
new 0 91 96
assign 1 92 97
new 0 92 97
assign 1 93 98
new 0 93 98
assign 1 95 99
new 0 95 99
assign 1 96 100
new 0 96 100
assign 1 97 101
new 0 97 101
assign 1 98 102
new 0 98 102
assign 1 103 112
new 0 103 112
assign 1 104 113
valueIteratorGet 0 104 113
assign 1 104 116
hasNextGet 0 104 116
assign 1 105 118
nextGet 0 105 118
assign 1 106 119
mtdxGet 0 106 119
assign 1 106 120
greater 1 106 120
assign 1 107 122
mtdxGet 0 107 122
return 1 110 129
assign 1 114 137
new 0 114 137
assign 1 114 138
get 1 114 138
assign 1 115 139
def 1 115 144
assign 1 117 145
new 0 117 145
return 1 117 146
assign 1 119 148
new 0 119 148
return 1 119 149
new 0 122 152
assign 1 125 226
new 0 125 226
assign 1 126 227
new 0 126 227
assign 1 127 228
new 0 127 228
assign 1 128 229
new 0 128 229
assign 1 129 230
new 0 129 230
assign 1 130 231
new 0 130 231
assign 1 131 232
new 0 131 232
assign 1 132 233
new 0 132 233
assign 1 133 234
new 0 133 234
assign 1 134 235
new 0 134 235
assign 1 135 236
new 0 135 236
assign 1 136 237
superListGet 0 136 237
assign 1 136 238
copy 0 136 238
assign 1 137 239
namepathGet 0 137 239
addValue 1 137 240
assign 1 138 241
mtdListGet 0 138 241
assign 1 138 242
copy 0 138 242
assign 1 139 243
ptyListGet 0 139 243
assign 1 139 244
copy 0 139 244
assign 1 142 245
heldGet 0 142 245
assign 1 142 246
orderedVarsGet 0 142 246
assign 1 142 247
iteratorGet 0 142 247
assign 1 142 250
hasNextGet 0 142 250
assign 1 143 252
nextGet 0 143 252
assign 1 144 253
ptyMapGet 0 144 253
assign 1 144 254
heldGet 0 144 254
assign 1 144 255
nameGet 0 144 255
assign 1 144 256
get 1 144 256
assign 1 145 257
heldGet 0 145 257
assign 1 145 258
nameGet 0 145 258
assign 1 145 259
new 0 145 259
assign 1 145 260
notEquals 1 145 260
assign 1 145 262
undef 1 145 267
assign 1 0 268
assign 1 0 271
assign 1 0 275
assign 1 145 278
heldGet 0 145 278
assign 1 145 279
isDeclaredGet 0 145 279
assign 1 145 280
not 0 145 280
assign 1 0 282
assign 1 0 285
assign 1 0 289
assign 1 146 292
new 0 146 292
assign 1 146 293
heldGet 0 146 293
assign 1 146 294
nameGet 0 146 294
assign 1 146 295
add 1 146 295
assign 1 146 296
new 0 146 296
assign 1 146 297
add 1 146 297
assign 1 146 298
heldGet 0 146 298
assign 1 146 299
namepathGet 0 146 299
assign 1 146 300
toString 0 146 300
assign 1 146 301
add 1 146 301
assign 1 146 302
new 2 146 302
throw 1 146 303
assign 1 151 310
ptyListGet 0 151 310
assign 1 151 311
iteratorGet 0 151 311
assign 1 151 314
hasNextGet 0 151 314
assign 1 152 316
nextGet 0 152 316
assign 1 153 317
memSynGet 0 153 317
assign 1 153 318
isTypedGet 0 153 318
assign 1 154 320
heldGet 0 154 320
assign 1 154 321
memSynGet 0 154 321
assign 1 154 322
namepathGet 0 154 322
addUsed 1 154 323
assign 1 158 330
heldGet 0 158 330
assign 1 158 331
orderedMethodsGet 0 158 331
assign 1 158 332
iteratorGet 0 158 332
assign 1 158 335
hasNextGet 0 158 335
assign 1 159 337
nextGet 0 159 337
assign 1 160 338
mtdMapGet 0 160 338
assign 1 160 339
heldGet 0 160 339
assign 1 160 340
nameGet 0 160 340
assign 1 160 341
get 1 160 341
assign 1 161 342
def 1 161 347
assign 1 162 348
rsynGet 0 162 348
assign 1 162 349
def 1 162 354
assign 1 163 355
heldGet 0 163 355
assign 1 163 356
rtypeGet 0 163 356
assign 1 163 357
undef 1 163 362
assign 1 164 363
new 0 164 363
assign 1 164 364
heldGet 0 164 364
assign 1 164 365
nameGet 0 164 365
assign 1 164 366
add 1 164 366
assign 1 164 367
new 0 164 367
assign 1 164 368
add 1 164 368
assign 1 164 369
heldGet 0 164 369
assign 1 164 370
nameGet 0 164 370
assign 1 164 371
add 1 164 371
assign 1 164 372
new 2 164 372
throw 1 164 373
loadClass 1 169 382
assign 1 170 383
depthGet 0 170 383
assign 1 170 384
new 0 170 384
assign 1 170 385
add 1 170 385
assign 1 174 390
has 1 174 390
return 1 174 391
return 1 178 459
assign 1 179 461
new 0 179 461
assign 1 180 462
new 0 180 462
assign 1 181 463
new 0 181 463
assign 1 182 464
new 0 182 464
assign 1 183 465
undef 1 183 470
assign 1 184 471
new 0 184 471
assign 1 185 472
sizeGet 0 185 472
assign 1 186 473
sizeGet 0 186 473
assign 1 187 474
assign 1 188 475
iteratorGet 0 0 475
assign 1 188 478
hasNextGet 0 188 478
assign 1 188 480
nextGet 0 188 480
assign 1 189 481
emitDataGet 0 189 481
assign 1 189 482
methodIndexesGet 0 189 482
assign 1 189 483
new 2 189 483
put 1 189 484
return 1 191 490
assign 1 193 492
getSynNp 1 193 492
assign 1 194 493
new 0 194 493
assign 1 195 494
new 0 195 494
assign 1 197 495
sizeGet 0 197 495
assign 1 197 496
ptyListGet 0 197 496
assign 1 197 497
sizeGet 0 197 497
assign 1 197 498
subtract 1 197 498
assign 1 198 499
libNameGet 0 198 499
assign 1 198 500
equals 1 198 500
integrate 1 198 502
assign 1 199 504
isFinalGet 0 199 504
assign 1 200 506
new 0 200 506
assign 1 200 507
toString 0 200 507
assign 1 200 508
add 1 200 508
assign 1 200 509
new 1 200 509
throw 1 200 510
assign 1 202 512
isLocalGet 0 202 512
assign 1 202 514
libNameGet 0 202 514
assign 1 202 515
notEquals 1 202 515
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 203 527
new 0 203 527
assign 1 203 528
toString 0 203 528
assign 1 203 529
add 1 203 529
assign 1 203 530
new 1 203 530
throw 1 203 531
assign 1 205 533
isLocalGet 0 205 533
assign 1 205 535
not 0 205 535
assign 1 0 537
assign 1 0 540
assign 1 0 544
assign 1 205 547
not 0 205 547
assign 1 0 549
assign 1 0 552
assign 1 0 556
assign 1 206 559
new 0 206 559
assign 1 206 560
toString 0 206 560
assign 1 206 561
add 1 206 561
assign 1 206 562
new 1 206 562
throw 1 206 563
assign 1 208 565
iteratorGet 0 0 565
assign 1 208 568
hasNextGet 0 208 568
assign 1 208 570
nextGet 0 208 570
assign 1 209 571
getSynNp 1 209 571
assign 1 210 572
closeLibrariesGet 0 210 572
assign 1 210 573
libNameGet 0 210 573
assign 1 210 574
has 1 210 574
assign 1 210 575
not 0 210 575
assign 1 210 577
toString 0 210 577
assign 1 210 578
new 0 210 578
assign 1 210 579
notEquals 1 210 579
assign 1 0 581
assign 1 0 584
assign 1 0 588
assign 1 212 591
new 0 212 591
assign 1 213 592
new 0 213 592
assign 1 215 594
closeLibrariesGet 0 215 594
assign 1 215 595
libNameGet 0 215 595
assign 1 215 596
has 1 215 596
assign 1 215 597
not 0 215 597
assign 1 216 599
new 0 216 599
assign 1 220 606
valueIteratorGet 0 220 606
assign 1 220 609
hasNextGet 0 220 609
assign 1 221 611
nextGet 0 221 611
assign 1 222 612
mtdMapGet 0 222 612
assign 1 222 613
nameGet 0 222 613
assign 1 222 614
get 1 222 614
assign 1 223 615
def 1 223 620
assign 1 224 621
notEquals 1 224 621
assign 1 225 623
new 0 225 623
lastDefSet 1 225 624
assign 1 226 625
new 0 226 625
isOverrideSet 1 226 626
assign 1 227 627
increment 0 227 627
assign 1 230 631
new 0 230 631
isOverrideSet 1 230 632
assign 1 231 633
increment 0 231 633
assign 1 232 634
increment 0 232 634
assign 1 233 635
emitDataGet 0 233 635
assign 1 233 636
methodIndexesGet 0 233 636
assign 1 233 637
new 2 233 637
put 1 233 638
return 1 240 728
assign 1 241 730
new 0 241 730
assign 1 242 731
undef 1 242 736
return 1 242 737
assign 1 243 739
getSynNp 1 243 739
assign 1 244 740
heldGet 0 244 740
assign 1 244 741
orderedVarsGet 0 244 741
assign 1 244 742
iteratorGet 0 244 742
assign 1 244 745
hasNextGet 0 244 745
assign 1 245 747
nextGet 0 245 747
assign 1 246 748
ptyMapGet 0 246 748
assign 1 246 749
heldGet 0 246 749
assign 1 246 750
nameGet 0 246 750
assign 1 246 751
get 1 246 751
assign 1 247 752
def 1 247 757
assign 1 248 758
heldGet 0 248 758
assign 1 248 759
isDeclaredGet 0 248 759
assign 1 249 761
new 0 249 761
assign 1 249 762
heldGet 0 249 762
assign 1 249 763
nameGet 0 249 763
assign 1 249 764
add 1 249 764
assign 1 249 765
new 0 249 765
assign 1 249 766
add 1 249 766
assign 1 249 767
heldGet 0 249 767
assign 1 249 768
namepathGet 0 249 768
assign 1 249 769
toString 0 249 769
assign 1 249 770
add 1 249 770
assign 1 249 771
new 1 249 771
throw 1 249 772
assign 1 251 775
heldGet 0 251 775
assign 1 251 776
memSynGet 0 251 776
assign 1 251 777
isTypedGet 0 251 777
isTypedSet 1 251 778
assign 1 252 779
heldGet 0 252 779
assign 1 252 780
memSynGet 0 252 780
assign 1 252 781
namepathGet 0 252 781
namepathSet 1 252 782
assign 1 256 790
heldGet 0 256 790
assign 1 256 791
orderedMethodsGet 0 256 791
assign 1 256 792
iteratorGet 0 256 792
assign 1 256 795
hasNextGet 0 256 795
assign 1 257 797
nextGet 0 257 797
assign 1 258 798
mtdMapGet 0 258 798
assign 1 258 799
heldGet 0 258 799
assign 1 258 800
nameGet 0 258 800
assign 1 258 801
get 1 258 801
assign 1 259 802
def 1 259 807
assign 1 260 808
isFinalGet 0 260 808
assign 1 261 810
new 0 261 810
assign 1 261 811
heldGet 0 261 811
assign 1 261 812
nameGet 0 261 812
assign 1 261 813
add 1 261 813
assign 1 261 814
new 0 261 814
assign 1 261 815
add 1 261 815
assign 1 261 816
heldGet 0 261 816
assign 1 261 817
namepathGet 0 261 817
assign 1 261 818
toString 0 261 818
assign 1 261 819
add 1 261 819
assign 1 261 820
new 2 261 820
throw 1 261 821
assign 1 263 823
containedGet 0 263 823
assign 1 263 824
firstGet 0 263 824
assign 1 263 825
containedGet 0 263 825
assign 1 264 826
new 0 264 826
assign 1 264 829
argSynsGet 0 264 829
assign 1 264 830
lengthGet 0 264 830
assign 1 264 831
lesser 1 264 831
assign 1 265 833
argSynsGet 0 265 833
assign 1 265 834
get 1 265 834
assign 1 266 835
get 1 266 835
assign 1 266 836
heldGet 0 266 836
checkTypes 5 268 837
assign 1 264 838
increment 0 264 838
assign 1 270 844
rsynGet 0 270 844
assign 1 271 845
heldGet 0 271 845
assign 1 271 846
rtypeGet 0 271 846
assign 1 272 847
undef 1 272 852
assign 1 0 853
assign 1 272 856
undef 1 272 861
assign 1 0 862
assign 1 0 865
assign 1 273 869
undef 1 273 874
assign 1 273 874
not 0 273 874
assign 1 0 876
assign 1 273 879
undef 1 273 884
assign 1 273 884
not 0 273 884
assign 1 0 886
assign 1 0 889
assign 1 274 893
new 0 274 893
assign 1 274 894
heldGet 0 274 894
assign 1 274 895
namepathGet 0 274 895
assign 1 274 896
toString 0 274 896
assign 1 274 897
add 1 274 897
assign 1 274 898
new 2 274 898
throw 1 274 899
checkTypes 5 278 903
assign 1 285 939
isTypedGet 0 285 939
assign 1 285 940
isTypedGet 0 285 940
assign 1 285 941
notEquals 1 285 941
assign 1 286 943
new 0 286 943
assign 1 286 944
heldGet 0 286 944
assign 1 286 945
namepathGet 0 286 945
assign 1 286 946
toString 0 286 946
assign 1 286 947
add 1 286 947
assign 1 286 948
new 2 286 948
throw 1 286 949
assign 1 287 952
isTypedGet 0 287 952
assign 1 290 954
isSelfGet 0 290 954
assign 1 290 956
isSelfGet 0 290 956
assign 1 0 958
assign 1 0 961
assign 1 0 965
return 1 291 968
assign 1 293 970
namepathGet 0 293 970
assign 1 293 971
getSynNp 1 293 971
assign 1 294 972
allTypesGet 0 294 972
assign 1 294 973
namepathGet 0 294 973
assign 1 294 974
has 1 294 974
assign 1 294 975
not 0 294 975
assign 1 295 977
new 0 295 977
assign 1 295 978
heldGet 0 295 978
assign 1 295 979
namepathGet 0 295 979
assign 1 295 980
toString 0 295 980
assign 1 295 981
add 1 295 981
assign 1 295 982
new 2 295 982
throw 1 295 983
new 0 301 1009
assign 1 302 1010
heldGet 0 302 1010
assign 1 302 1011
orderedVarsGet 0 302 1011
assign 1 302 1012
iteratorGet 0 302 1012
assign 1 302 1015
hasNextGet 0 302 1015
assign 1 303 1017
nextGet 0 303 1017
assign 1 304 1018
heldGet 0 304 1018
assign 1 304 1019
isDeclaredGet 0 304 1019
assign 1 304 1020
not 0 304 1020
assign 1 305 1022
new 0 305 1022
assign 1 305 1023
heldGet 0 305 1023
assign 1 305 1024
nameGet 0 305 1024
assign 1 305 1025
add 1 305 1025
assign 1 305 1026
new 0 305 1026
assign 1 305 1027
add 1 305 1027
assign 1 305 1028
heldGet 0 305 1028
assign 1 305 1029
namepathGet 0 305 1029
assign 1 305 1030
toString 0 305 1030
assign 1 305 1031
add 1 305 1031
assign 1 305 1032
new 2 305 1032
throw 1 305 1033
loadClass 1 308 1040
assign 1 309 1041
new 0 309 1041
assign 1 314 1069
heldGet 0 314 1069
assign 1 314 1070
fromFileGet 0 314 1070
assign 1 315 1071
heldGet 0 315 1071
assign 1 315 1072
namepathGet 0 315 1072
assign 1 316 1073
heldGet 0 316 1073
assign 1 316 1074
libNameGet 0 316 1074
assign 1 317 1075
heldGet 0 317 1075
assign 1 317 1076
isFinalGet 0 317 1076
assign 1 318 1077
heldGet 0 318 1077
assign 1 318 1078
isLocalGet 0 318 1078
assign 1 319 1079
heldGet 0 319 1079
assign 1 319 1080
isNotNullGet 0 319 1080
assign 1 320 1081
heldGet 0 320 1081
assign 1 320 1082
usedGet 0 320 1082
assign 1 320 1083
iteratorGet 0 320 1083
assign 1 320 1086
hasNextGet 0 320 1086
assign 1 321 1088
nextGet 0 321 1088
assign 1 322 1089
toString 0 322 1089
put 1 322 1090
assign 1 324 1096
heldGet 0 324 1096
assign 1 324 1097
orderedVarsGet 0 324 1097
assign 1 324 1098
iteratorGet 0 324 1098
assign 1 324 1101
hasNextGet 0 324 1101
assign 1 325 1103
nextGet 0 325 1103
assign 1 326 1104
new 2 326 1104
addValue 1 327 1105
assign 1 329 1111
heldGet 0 329 1111
assign 1 329 1112
orderedMethodsGet 0 329 1112
assign 1 329 1113
iteratorGet 0 329 1113
assign 1 329 1116
hasNextGet 0 329 1116
assign 1 330 1118
nextGet 0 330 1118
assign 1 331 1119
new 2 331 1119
addValue 1 332 1120
postLoad 0 334 1126
assign 1 338 1177
new 0 338 1177
assign 1 339 1178
new 0 339 1178
assign 1 342 1179
iteratorGet 0 342 1179
assign 1 342 1182
hasNextGet 0 342 1182
assign 1 343 1184
nextGet 0 343 1184
assign 1 344 1185
nameGet 0 344 1185
assign 1 344 1186
has 1 344 1186
assign 1 344 1187
not 0 344 1187
assign 1 346 1189
nameGet 0 346 1189
put 2 346 1190
assign 1 350 1197
new 0 350 1197
assign 1 351 1198
new 0 351 1198
assign 1 352 1199
iteratorGet 0 352 1199
assign 1 352 1202
hasNextGet 0 352 1202
assign 1 353 1204
nextGet 0 353 1204
assign 1 354 1205
nameGet 0 354 1205
assign 1 354 1206
has 1 354 1206
assign 1 354 1207
not 0 354 1207
assign 1 355 1209
nameGet 0 355 1209
assign 1 355 1210
get 1 355 1210
mposSet 1 356 1211
assign 1 357 1212
new 0 357 1212
assign 1 357 1213
add 1 357 1213
addValue 1 358 1214
assign 1 359 1215
nameGet 0 359 1215
assign 1 359 1216
nameGet 0 359 1216
put 2 359 1217
assign 1 362 1224
assign 1 364 1225
new 0 364 1225
assign 1 366 1226
iteratorGet 0 366 1226
assign 1 366 1229
hasNextGet 0 366 1229
assign 1 367 1231
nextGet 0 367 1231
assign 1 369 1232
nameGet 0 369 1232
put 2 369 1233
assign 1 371 1234
nameGet 0 371 1234
assign 1 371 1235
has 1 371 1235
assign 1 371 1236
not 0 371 1236
assign 1 372 1238
nameGet 0 372 1238
put 2 372 1239
assign 1 376 1246
new 0 376 1246
assign 1 377 1247
new 0 377 1247
assign 1 378 1248
iteratorGet 0 378 1248
assign 1 378 1251
hasNextGet 0 378 1251
assign 1 379 1253
nextGet 0 379 1253
assign 1 380 1254
nameGet 0 380 1254
assign 1 380 1255
has 1 380 1255
assign 1 380 1256
not 0 380 1256
assign 1 381 1258
nameGet 0 381 1258
assign 1 381 1259
get 1 381 1259
assign 1 390 1260
nameGet 0 390 1260
assign 1 390 1261
get 1 390 1261
assign 1 391 1262
declarationGet 0 391 1262
assign 1 391 1263
undef 1 391 1268
assign 1 392 1269
originGet 0 392 1269
declarationSet 1 392 1270
assign 1 394 1272
declarationGet 0 394 1272
declarationSet 1 394 1273
mtdxSet 1 395 1274
assign 1 396 1275
increment 0 396 1275
addValue 1 397 1276
assign 1 398 1277
nameGet 0 398 1277
assign 1 398 1278
nameGet 0 398 1278
put 2 398 1279
assign 1 401 1286
assign 1 403 1287
iteratorGet 0 0 1287
assign 1 403 1290
hasNextGet 0 403 1290
assign 1 403 1292
nextGet 0 403 1292
put 2 404 1293
assign 1 405 1294
put 2 408 1300
assign 1 412 1334
new 0 412 1334
assign 1 412 1335
new 1 412 1335
assign 1 413 1341
new 0 413 1341
assign 1 413 1342
get 1 413 1342
assign 1 413 1343
undef 1 413 1348
assign 1 414 1349
new 0 414 1349
assign 1 414 1350
new 0 414 1350
put 2 414 1351
assign 1 415 1352
new 0 415 1352
assign 1 415 1353
new 0 415 1353
put 2 415 1354
assign 1 416 1355
new 0 416 1355
assign 1 416 1356
new 0 416 1356
put 2 416 1357
assign 1 417 1358
new 0 417 1358
assign 1 417 1359
new 0 417 1359
put 2 417 1360
assign 1 418 1361
new 0 418 1361
assign 1 418 1362
new 0 418 1362
put 2 418 1363
assign 1 419 1364
new 0 419 1364
assign 1 419 1365
new 0 419 1365
put 2 419 1366
assign 1 420 1367
new 0 420 1367
assign 1 420 1368
new 0 420 1368
put 2 420 1369
assign 1 421 1370
new 0 421 1370
assign 1 421 1371
new 0 421 1371
put 2 421 1372
assign 1 422 1373
new 0 422 1373
assign 1 422 1374
new 0 422 1374
put 2 422 1375
assign 1 423 1376
new 0 423 1376
assign 1 423 1377
new 0 423 1377
put 2 423 1378
assign 1 424 1379
new 0 424 1379
assign 1 424 1380
new 0 424 1380
put 2 424 1381
assign 1 425 1382
new 0 425 1382
assign 1 425 1383
new 0 425 1383
put 2 425 1384
assign 1 427 1386
new 2 427 1386
return 1 427 1387
return 1 0 1390
assign 1 0 1393
return 1 0 1397
assign 1 0 1400
return 1 0 1404
assign 1 0 1407
return 1 0 1411
assign 1 0 1414
return 1 0 1418
assign 1 0 1421
return 1 0 1425
assign 1 0 1428
return 1 0 1432
assign 1 0 1435
return 1 0 1439
assign 1 0 1442
return 1 0 1446
assign 1 0 1449
return 1 0 1453
assign 1 0 1456
return 1 0 1460
assign 1 0 1463
return 1 0 1467
assign 1 0 1470
return 1 0 1474
assign 1 0 1477
return 1 0 1481
assign 1 0 1484
return 1 0 1488
assign 1 0 1491
return 1 0 1495
assign 1 0 1498
return 1 0 1502
assign 1 0 1505
return 1 0 1509
assign 1 0 1512
return 1 0 1516
assign 1 0 1519
return 1 0 1523
assign 1 0 1526
return 1 0 1530
assign 1 0 1533
return 1 0 1537
assign 1 0 1540
return 1 0 1544
assign 1 0 1547
return 1 0 1551
assign 1 0 1554
return 1 0 1558
assign 1 0 1561
return 1 0 1565
assign 1 0 1568
return 1 0 1572
assign 1 0 1575
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1477961836: return bem_mtdListGet_0();
case 314718434: return bem_print_0();
case 1443447938: return bem_directMethodsGet_0();
case 68632810: return bem_superNpGet_0();
case 287367803: return bem_isFinalGet_0();
case 1214937871: return bem_newMtdsGet_0();
case 1012494862: return bem_once_0();
case 311680096: return bem_allNamesGet_0();
case 481879936: return bem_hasDefaultGet_0();
case 492006165: return bem_directPropertiesGet_0();
case 244359240: return bem_mtdMapGet_0();
case 986531569: return bem_allTypesGet_0();
case 2097069068: return bem_integratedGet_0();
case 345555227: return bem_usesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1631955979: return bem_foreignClassesGet_0();
case 786424307: return bem_tagGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1413594071: return bem_postLoad_0();
case 1102720804: return bem_classNameGet_0();
case 2058095605: return bem_signatureChangedGet_0();
case 71634217: return bem_iCheckedGet_0();
case 1760712968: return bem_signatureCheckedGet_0();
case 287040793: return bem_hashGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case 1974592946: return bem_superListGet_0();
case 845792839: return bem_iteratorGet_0();
case 1774940957: return bem_toString_0();
case 1314364113: return bem_newMbrsGet_0();
case 795036897: return bem_fromFileGet_0();
case 1803479881: return bem_libNameGet_0();
case 1820417453: return bem_create_0();
case 1308786538: return bem_echo_0();
case 2033393684: return bem_ptyListGet_0();
case 729571811: return bem_serializeToString_0();
case 1081412016: return bem_many_0();
case 2055025483: return bem_serializeContents_0();
case 1354714650: return bem_copy_0();
case 354142775: return bem_namepathGet_0();
case 842582618: return bem_isLocalGet_0();
case 363636983: return bem_isNotNullGet_0();
case 834964524: return bem_defMtdsGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 153365600: return bem_ptyMapGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 443668840: return bem_methodNotDefined_0();
case 104713553: return bem_new_0();
case 202810500: return bem_depthGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case 1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case 975449316: return bem_allTypesSet_1(bevd_0);
case 142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case 1749630715: return bem_signatureCheckedSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2085986815: return bem_integratedSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case 300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case 831500365: return bem_isLocalSet_1(bevd_0);
case 480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1963510693: return bem_superListSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1156342947: return bem_integrate_1((BEC_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case 1620873726: return bem_foreignClassesSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) {
switch (callHash) {
case 913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_8_BuildClassSyn();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_8_BuildClassSyn.bevs_inst = (BEC_5_8_BuildClassSyn)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_8_BuildClassSyn.bevs_inst;
}
}
}
