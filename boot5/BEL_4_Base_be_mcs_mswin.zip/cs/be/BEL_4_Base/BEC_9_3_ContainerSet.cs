namespace be.BEL_4_Base {
/* File: source/base/Map.be */
public class BEC_9_3_ContainerSet : BEC_6_6_SystemObject {
public BEC_9_3_ContainerSet() { }
static BEC_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
public static new BEC_9_3_ContainerSet bevs_inst;
public BEC_9_5_ContainerArray bevp_slots;
public BEC_4_3_MathInt bevp_modu;
public BEC_4_3_MathInt bevp_multi;
public BEC_9_3_9_ContainerSetRelations bevp_rel;
public BEC_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_4_3_MathInt bevp_size;
public BEC_5_4_LogicBool bevp_innerPutAdded;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_new_1(BEC_4_3_MathInt beva__modu) {
bevp_slots = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevp_rel = (BEC_9_3_9_ContainerSetRelations) BEC_9_3_9_ContainerSetRelations.bevs_inst.bem_new_0();
bevp_baseNode = (BEC_9_3_7_ContainerSetSetNode) (new BEC_9_3_7_ContainerSetSetNode()).bem_new_0();
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_innerPutAdded = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_size.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 226 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 227 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_9_3_21_ContainerSetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_3_21_ContainerSetSerializationIterator) (new BEC_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_insertAll_2(BEC_9_5_ContainerArray beva_ninner, BEC_9_5_ContainerArray beva_ir) {
BEC_6_6_SystemObject bevl_i = null;
BEC_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_iteratorGet_0();
while (true)
 /* Line: 245 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevl_ni = (BEC_9_3_7_ContainerSetSetNode) bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 249 */
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 245 */ {
break;
} /* Line: 245 */
} /* Line: 245 */
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rehash_1(BEC_9_5_ContainerArray beva_slt) {
BEC_4_3_MathInt bevl_nslots = null;
BEC_9_5_ContainerArray bevl_ninner = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_1;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 260 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevl_nslots);
} /* Line: 262 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
return bevl_ninner;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_contentsEqual_1(BEC_9_3_ContainerSet beva_other) {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 268 */ {
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 269 */
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 271 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevl_i = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_10_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 272 */
} /* Line: 272 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
bevt_11_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_innerPut_4(BEC_6_6_SystemObject beva_k, BEC_6_6_SystemObject beva_v, BEC_6_6_SystemObject beva_inode, BEC_9_5_ContainerArray beva_slt) {
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 279 */ {
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_2;
bevt_1_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 282 */
} /* Line: 281 */
 else  /* Line: 284 */ {
bevl_hval = (BEC_4_3_MathInt) beva_inode.bemd_0(449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 285 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 289 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 291 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_6_tmpvar_phold = bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_3(104713556, BEL_4_Base.bevn_new_3, bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 293 */
 else  /* Line: 294 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 295 */
bevp_innerPutAdded = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 298 */
 else  /* Line: 291 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 299 */ {
bevt_11_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 300 */
 else  /* Line: 291 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 301 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 305 */
 else  /* Line: 306 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_15_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_16_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 309 */
} /* Line: 308 */
} /* Line: 291 */
} /* Line: 291 */
} /* Line: 291 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_put_1(BEC_6_6_SystemObject beva_k) {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 316 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 319 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 319 */ {
bevl_slt = (BEC_9_5_ContainerArray) this.bem_rehash_1(bevl_slt);
} /* Line: 320 */
 else  /* Line: 319 */ {
break;
} /* Line: 319 */
} /* Line: 319 */
bevp_slots = bevl_slt;
} /* Line: 322 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 324 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 325 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_6_6_SystemObject beva_k) {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 333 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 334 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 338 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 340 */ {
return null;
} /* Line: 341 */
 else  /* Line: 340 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 342 */ {
return null;
} /* Line: 343 */
 else  /* Line: 340 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 344 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 345 */
 else  /* Line: 346 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_9_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 348 */ {
return null;
} /* Line: 349 */
} /* Line: 348 */
} /* Line: 340 */
} /* Line: 340 */
} /* Line: 340 */
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_k) {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 359 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 360 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 364 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 367 */
 else  /* Line: 366 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 369 */
 else  /* Line: 366 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 370 */ {
bevt_10_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 371 */
 else  /* Line: 372 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_11_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 374 */ {
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 375 */
} /* Line: 374 */
} /* Line: 366 */
} /* Line: 366 */
} /* Line: 366 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_1(BEC_6_6_SystemObject beva_k) {
BEC_9_5_ContainerArray bevl_slt = null;
BEC_4_3_MathInt bevl_modu = null;
BEC_4_3_MathInt bevl_hval = null;
BEC_4_3_MathInt bevl_orgsl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevl_hval.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 387 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 391 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 393 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 394 */
 else  /* Line: 393 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 395 */ {
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 396 */
 else  /* Line: 393 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 397 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 401 */ {
bevt_11_tmpvar_phold = bevl_sl.bem_lesser_1(bevl_modu);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 401 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 403 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_notEquals_1(bevl_orgsl);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 403 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 403 */ {
bevt_16_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 404 */
 else  /* Line: 405 */ {
bevt_18_tmpvar_phold = bevo_6;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 407 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 409 */
 else  /* Line: 401 */ {
break;
} /* Line: 401 */
} /* Line: 401 */
bevt_19_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 411 */
 else  /* Line: 412 */ {
bevl_sl = bevl_sl.bem_increment_0();
bevt_20_tmpvar_phold = bevl_sl.bem_greaterEquals_1(bevl_modu);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 414 */ {
bevt_21_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 415 */
} /* Line: 414 */
} /* Line: 393 */
} /* Line: 393 */
} /* Line: 393 */
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_6_6_SystemObject bevl_other = null;
BEC_4_3_MathInt bevl_i = null;
BEC_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 425 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 425 */ {
bevl_n = (BEC_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_3(104713556, BEL_4_Base.bevn_new_3, bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 428 */
 else  /* Line: 429 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 430 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 425 */
 else  /* Line: 425 */ {
break;
} /* Line: 425 */
} /* Line: 425 */
return bevl_other;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_clear_0() {
bevp_slots.bem_clear_0();
bevp_size = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() {
BEC_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_3_11_ContainerSetKeyIterator bem_keysGet_0() {
BEC_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() {
BEC_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() {
BEC_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_intersection_1(BEC_9_3_ContainerSet beva_other) {
BEC_9_3_ContainerSet bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 464 */ {
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 465 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 466 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 467 */
} /* Line: 466 */
 else  /* Line: 465 */ {
break;
} /* Line: 465 */
} /* Line: 465 */
} /* Line: 465 */
return bevl_i;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_union_1(BEC_9_3_ContainerSet beva_other) {
BEC_9_3_ContainerSet bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevl_i = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 476 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bem_put_1(bevl_x);
} /* Line: 477 */
 else  /* Line: 476 */ {
break;
} /* Line: 476 */
} /* Line: 476 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_1_tmpvar_loop = beva_other.bem_iteratorGet_0();
while (true)
 /* Line: 480 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 480 */ {
bevl_x = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bem_put_1(bevl_x);
} /* Line: 481 */
 else  /* Line: 480 */ {
break;
} /* Line: 480 */
} /* Line: 480 */
} /* Line: 480 */
return bevl_i;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_add_1(BEC_9_3_ContainerSet beva_other) {
BEC_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_9_3_ContainerSet) this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_9_3_ContainerSet) bevl_x;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_addValue_1(BEC_6_6_SystemObject beva_other) {
BEC_6_6_SystemObject bevl_x = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 494 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 495 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 496 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 496 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 497 */
 else  /* Line: 496 */ {
break;
} /* Line: 496 */
} /* Line: 496 */
} /* Line: 496 */
 else  /* Line: 495 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 499 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 500 */
 else  /* Line: 501 */ {
this.bem_put_1(beva_other);
} /* Line: 502 */
} /* Line: 495 */
} /* Line: 495 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_slotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_slots = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_moduSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_modu = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_multiGet_0() {
return bevp_multi;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_multiSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multi = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_9_ContainerSetRelations bem_relGet_0() {
return bevp_rel;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_relSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rel = (BEC_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() {
return bevp_baseNode;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_baseNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_baseNode = (BEC_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_innerPutAddedGet_0() {
return bevp_innerPutAdded;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_innerPutAddedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_innerPutAdded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {208, 208, 214, 215, 216, 217, 218, 219, 220, 226, 226, 227, 227, 229, 229, 233, 233, 237, 237, 241, 241, 245, 245, 246, 247, 247, 248, 248, 248, 249, 249, 253, 253, 258, 258, 258, 258, 259, 260, 260, 261, 262, 264, 268, 268, 0, 268, 268, 268, 0, 0, 269, 269, 271, 0, 271, 271, 272, 272, 272, 272, 274, 274, 278, 279, 279, 280, 281, 281, 282, 285, 287, 288, 290, 291, 291, 292, 292, 293, 293, 293, 295, 297, 298, 298, 299, 299, 299, 300, 300, 301, 301, 302, 304, 305, 305, 307, 308, 309, 309, 316, 316, 317, 318, 319, 319, 320, 322, 325, 330, 331, 332, 333, 333, 334, 336, 337, 339, 340, 340, 341, 342, 342, 342, 343, 344, 344, 345, 345, 347, 348, 349, 356, 357, 358, 359, 359, 360, 362, 363, 365, 366, 366, 367, 367, 368, 368, 368, 369, 369, 370, 370, 371, 371, 373, 374, 375, 375, 382, 383, 385, 386, 386, 387, 389, 390, 392, 393, 393, 394, 394, 395, 395, 395, 396, 396, 397, 397, 398, 399, 400, 401, 402, 403, 403, 0, 403, 403, 403, 0, 0, 404, 404, 406, 406, 406, 407, 409, 411, 411, 413, 414, 415, 415, 422, 423, 424, 424, 425, 425, 425, 426, 427, 427, 428, 428, 428, 428, 428, 428, 428, 430, 430, 425, 433, 438, 439, 443, 443, 447, 447, 451, 451, 455, 455, 459, 459, 463, 464, 464, 465, 0, 465, 465, 466, 467, 471, 475, 476, 0, 476, 476, 477, 479, 479, 480, 0, 480, 480, 481, 484, 488, 489, 490, 494, 494, 495, 496, 0, 496, 496, 497, 499, 500, 500, 502, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 30, 31, 32, 33, 34, 35, 36, 44, 45, 47, 48, 50, 51, 55, 56, 60, 61, 66, 67, 79, 82, 84, 85, 90, 91, 92, 93, 95, 96, 104, 105, 115, 116, 117, 118, 119, 122, 123, 125, 126, 132, 148, 153, 154, 157, 158, 159, 161, 164, 168, 169, 171, 171, 174, 176, 177, 178, 180, 181, 188, 189, 214, 215, 220, 221, 222, 223, 225, 229, 231, 232, 235, 236, 241, 242, 247, 248, 249, 250, 253, 255, 256, 257, 260, 261, 262, 264, 265, 268, 269, 271, 272, 273, 274, 277, 278, 280, 281, 294, 295, 297, 298, 301, 302, 304, 310, 313, 334, 335, 336, 337, 338, 340, 342, 343, 346, 347, 352, 353, 356, 357, 358, 360, 363, 364, 366, 367, 370, 371, 373, 400, 401, 402, 403, 404, 406, 408, 409, 412, 413, 418, 419, 420, 423, 424, 425, 427, 428, 431, 432, 434, 435, 438, 439, 441, 442, 478, 479, 480, 481, 482, 484, 486, 487, 490, 491, 496, 497, 498, 501, 502, 503, 505, 506, 509, 510, 512, 513, 514, 517, 519, 520, 525, 526, 529, 530, 531, 533, 536, 540, 541, 544, 545, 546, 547, 549, 555, 556, 559, 560, 562, 563, 585, 586, 587, 588, 589, 592, 593, 595, 596, 601, 602, 603, 604, 605, 606, 607, 608, 611, 612, 614, 620, 623, 624, 629, 630, 634, 635, 639, 640, 644, 645, 649, 650, 659, 660, 665, 666, 666, 669, 671, 672, 674, 682, 692, 693, 693, 696, 698, 699, 705, 710, 711, 711, 714, 716, 717, 724, 728, 729, 730, 740, 745, 746, 748, 748, 751, 753, 754, 762, 764, 765, 768, 775, 778, 782, 785, 789, 792, 796, 799, 803, 806, 810, 813, 817, 820};
/* BEGIN LINEINFO 
assign 1 208 25
new 0 208 25
new 1 208 26
assign 1 214 30
new 1 214 30
assign 1 215 31
assign 1 216 32
new 0 216 32
assign 1 217 33
new 0 217 33
assign 1 218 34
new 0 218 34
assign 1 219 35
new 0 219 35
assign 1 220 36
new 0 220 36
assign 1 226 44
new 0 226 44
assign 1 226 45
equals 1 226 45
assign 1 227 47
new 0 227 47
return 1 227 48
assign 1 229 50
new 0 229 50
return 1 229 51
assign 1 233 55
toString 0 233 55
return 1 233 56
assign 1 237 60
new 1 237 60
new 1 237 61
assign 1 241 66
new 1 241 66
return 1 241 67
assign 1 245 79
iteratorGet 0 245 79
assign 1 245 82
hasNextGet 0 245 82
assign 1 246 84
nextGet 0 246 84
assign 1 247 85
def 1 247 90
assign 1 248 91
keyGet 0 248 91
assign 1 248 92
innerPut 4 248 92
assign 1 248 93
not 0 248 93
assign 1 249 95
new 0 249 95
return 1 249 96
assign 1 253 104
new 0 253 104
return 1 253 105
assign 1 258 115
sizeGet 0 258 115
assign 1 258 116
multiply 1 258 116
assign 1 258 117
new 0 258 117
assign 1 258 118
add 1 258 118
assign 1 259 119
new 1 259 119
assign 1 260 122
insertAll 2 260 122
assign 1 260 123
not 0 260 123
assign 1 261 125
increment 0 261 125
assign 1 262 126
new 1 262 126
return 1 264 132
assign 1 268 148
undef 1 268 153
assign 1 0 154
assign 1 268 157
sizeGet 0 268 157
assign 1 268 158
sizeGet 0 268 158
assign 1 268 159
notEquals 1 268 159
assign 1 0 161
assign 1 0 164
assign 1 269 168
new 0 269 168
return 1 269 169
assign 1 271 171
iteratorGet 0 0 171
assign 1 271 174
hasNextGet 0 271 174
assign 1 271 176
nextGet 0 271 176
assign 1 272 177
has 1 272 177
assign 1 272 178
not 0 272 178
assign 1 272 180
new 0 272 180
return 1 272 181
assign 1 274 188
new 0 274 188
return 1 274 189
assign 1 278 214
sizeGet 0 278 214
assign 1 279 215
undef 1 279 220
assign 1 280 221
getHash 1 280 221
assign 1 281 222
new 0 281 222
assign 1 281 223
lesser 1 281 223
assign 1 282 225
abs 0 282 225
assign 1 285 229
hvalGet 0 285 229
assign 1 287 231
modulus 1 287 231
assign 1 288 232
assign 1 290 235
get 1 290 235
assign 1 291 236
undef 1 291 241
assign 1 292 242
undef 1 292 247
assign 1 293 248
create 0 293 248
assign 1 293 249
new 3 293 249
put 2 293 250
put 2 295 253
assign 1 297 255
new 0 297 255
assign 1 298 256
new 0 298 256
return 1 298 257
assign 1 299 260
hvalGet 0 299 260
assign 1 299 261
modulus 1 299 261
assign 1 299 262
notEquals 1 299 262
assign 1 300 264
new 0 300 264
return 1 300 265
assign 1 301 268
keyGet 0 301 268
assign 1 301 269
isEqual 2 301 269
putTo 2 302 271
assign 1 304 272
new 0 304 272
assign 1 305 273
new 0 305 273
return 1 305 274
assign 1 307 277
increment 0 307 277
assign 1 308 278
greaterEquals 1 308 278
assign 1 309 280
new 0 309 280
return 1 309 281
assign 1 316 294
innerPut 4 316 294
assign 1 316 295
not 0 316 295
assign 1 317 297
assign 1 318 298
rehash 1 318 298
assign 1 319 301
innerPut 4 319 301
assign 1 319 302
not 0 319 302
assign 1 320 304
rehash 1 320 304
assign 1 322 310
assign 1 325 313
increment 0 325 313
assign 1 330 334
assign 1 331 335
sizeGet 0 331 335
assign 1 332 336
getHash 1 332 336
assign 1 333 337
new 0 333 337
assign 1 333 338
lesser 1 333 338
assign 1 334 340
abs 0 334 340
assign 1 336 342
modulus 1 336 342
assign 1 337 343
assign 1 339 346
get 1 339 346
assign 1 340 347
undef 1 340 352
return 1 341 353
assign 1 342 356
hvalGet 0 342 356
assign 1 342 357
modulus 1 342 357
assign 1 342 358
notEquals 1 342 358
return 1 343 360
assign 1 344 363
keyGet 0 344 363
assign 1 344 364
isEqual 2 344 364
assign 1 345 366
getFrom 0 345 366
return 1 345 367
assign 1 347 370
increment 0 347 370
assign 1 348 371
greaterEquals 1 348 371
return 1 349 373
assign 1 356 400
assign 1 357 401
sizeGet 0 357 401
assign 1 358 402
getHash 1 358 402
assign 1 359 403
new 0 359 403
assign 1 359 404
lesser 1 359 404
assign 1 360 406
abs 0 360 406
assign 1 362 408
modulus 1 362 408
assign 1 363 409
assign 1 365 412
get 1 365 412
assign 1 366 413
undef 1 366 418
assign 1 367 419
new 0 367 419
return 1 367 420
assign 1 368 423
hvalGet 0 368 423
assign 1 368 424
modulus 1 368 424
assign 1 368 425
notEquals 1 368 425
assign 1 369 427
new 0 369 427
return 1 369 428
assign 1 370 431
keyGet 0 370 431
assign 1 370 432
isEqual 2 370 432
assign 1 371 434
new 0 371 434
return 1 371 435
assign 1 373 438
increment 0 373 438
assign 1 374 439
greaterEquals 1 374 439
assign 1 375 441
new 0 375 441
return 1 375 442
assign 1 382 478
assign 1 383 479
sizeGet 0 383 479
assign 1 385 480
getHash 1 385 480
assign 1 386 481
new 0 386 481
assign 1 386 482
lesser 1 386 482
assign 1 387 484
abs 0 387 484
assign 1 389 486
modulus 1 389 486
assign 1 390 487
assign 1 392 490
get 1 392 490
assign 1 393 491
undef 1 393 496
assign 1 394 497
new 0 394 497
return 1 394 498
assign 1 395 501
hvalGet 0 395 501
assign 1 395 502
modulus 1 395 502
assign 1 395 503
notEquals 1 395 503
assign 1 396 505
new 0 396 505
return 1 396 506
assign 1 397 509
keyGet 0 397 509
assign 1 397 510
isEqual 2 397 510
put 2 398 512
assign 1 399 513
decrement 0 399 513
assign 1 400 514
increment 0 400 514
assign 1 401 517
lesser 1 401 517
assign 1 402 519
get 1 402 519
assign 1 403 520
undef 1 403 525
assign 1 0 526
assign 1 403 529
hvalGet 0 403 529
assign 1 403 530
modulus 1 403 530
assign 1 403 531
notEquals 1 403 531
assign 1 0 533
assign 1 0 536
assign 1 404 540
new 0 404 540
return 1 404 541
assign 1 406 544
new 0 406 544
assign 1 406 545
subtract 1 406 545
put 2 406 546
put 2 407 547
assign 1 409 549
increment 0 409 549
assign 1 411 555
new 0 411 555
return 1 411 556
assign 1 413 559
increment 0 413 559
assign 1 414 560
greaterEquals 1 414 560
assign 1 415 562
new 0 415 562
return 1 415 563
assign 1 422 585
create 0 422 585
copyTo 1 423 586
assign 1 424 587
copy 0 424 587
slotsSet 1 424 588
assign 1 425 589
new 0 425 589
assign 1 425 592
lengthGet 0 425 592
assign 1 425 593
lesser 1 425 593
assign 1 426 595
get 1 426 595
assign 1 427 596
def 1 427 601
assign 1 428 602
slotsGet 0 428 602
assign 1 428 603
create 0 428 603
assign 1 428 604
hvalGet 0 428 604
assign 1 428 605
keyGet 0 428 605
assign 1 428 606
getFrom 0 428 606
assign 1 428 607
new 3 428 607
put 2 428 608
assign 1 430 611
slotsGet 0 430 611
put 2 430 612
assign 1 425 614
increment 0 425 614
return 1 433 620
clear 0 438 623
assign 1 439 624
new 0 439 624
assign 1 443 629
new 1 443 629
return 1 443 630
assign 1 447 634
new 1 447 634
return 1 447 635
assign 1 451 639
keyIteratorGet 0 451 639
return 1 451 640
assign 1 455 644
new 1 455 644
return 1 455 645
assign 1 459 649
nodeIteratorGet 0 459 649
return 1 459 650
assign 1 463 659
new 0 463 659
assign 1 464 660
def 1 464 665
assign 1 465 666
iteratorGet 0 0 666
assign 1 465 669
hasNextGet 0 465 669
assign 1 465 671
nextGet 0 465 671
assign 1 466 672
has 1 466 672
put 1 467 674
return 1 471 682
assign 1 475 692
new 0 475 692
assign 1 476 693
iteratorGet 0 0 693
assign 1 476 696
hasNextGet 0 476 696
assign 1 476 698
nextGet 0 476 698
put 1 477 699
assign 1 479 705
def 1 479 710
assign 1 480 711
iteratorGet 0 0 711
assign 1 480 714
hasNextGet 0 480 714
assign 1 480 716
nextGet 0 480 716
put 1 481 717
return 1 484 724
assign 1 488 728
copy 0 488 728
addValue 1 489 729
return 1 490 730
assign 1 494 740
def 1 494 745
assign 1 495 746
sameType 1 495 746
assign 1 496 748
iteratorGet 0 0 748
assign 1 496 751
hasNextGet 0 496 751
assign 1 496 753
nextGet 0 496 753
put 1 497 754
assign 1 499 762
sameType 1 499 762
assign 1 500 764
keyGet 0 500 764
put 1 500 765
put 1 502 768
return 1 0 775
assign 1 0 778
return 1 0 782
assign 1 0 785
return 1 0 789
assign 1 0 792
return 1 0 796
assign 1 0 799
return 1 0 803
assign 1 0 806
return 1 0 810
assign 1 0 813
return 1 0 817
assign 1 0 820
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 712928736: return bem_innerPutAddedGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1586230380: return bem_moduGet_0();
case 1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case 578884498: return bem_relGet_0();
case 786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 567802245: return bem_relSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_9_3_ContainerSet) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 79841285: return bem_intersection_1((BEC_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 286659903: return bem_union_1((BEC_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_3_ContainerSet) bevd_0);
case 668984013: return bem_rehash_1((BEC_9_5_ContainerArray) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 131089957: return bem_insertAll_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_9_5_ContainerArray) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_9_3_ContainerSet();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_9_3_ContainerSet.bevs_inst = (BEC_9_3_ContainerSet)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_9_3_ContainerSet.bevs_inst;
}
}
}
