namespace be.BEL_4_Base {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_8_DbDirStore : BEC_6_6_SystemObject {
public BEC_2_8_DbDirStore() { }
static BEC_2_8_DbDirStore() { }
private static byte[] becc_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 0));
private static byte[] bels_1 = {};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 0));
private static byte[] bels_2 = {};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 0));
private static byte[] bels_3 = {};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 0));
public static new BEC_2_8_DbDirStore bevs_inst;
public BEC_6_10_SystemSerializer bevp_ser;
public BEC_2_4_4_IOFilePath bevp_storageDir;
public BEC_6_6_SystemObject bevp_keyEncoder;
public virtual BEC_2_8_DbDirStore bem_new_2(BEC_4_6_TextString beva_storageDir, BEC_6_6_SystemObject beva__keyEncoder) {
this.bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public virtual BEC_2_8_DbDirStore bem_new_1(BEC_4_6_TextString beva_storageDir) {
BEC_2_4_4_IOFilePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
this.bem_pathNew_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_8_DbDirStore bem_pathNew_1(BEC_2_4_4_IOFilePath beva__storageDir) {
bevp_ser = (BEC_6_10_SystemSerializer) (new BEC_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getStoreId_1(BEC_4_6_TextString beva_id) {
BEC_4_6_TextString bevl_storeId = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_keyEncoder == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevl_storeId = (BEC_4_6_TextString) bevp_keyEncoder.bemd_1(1711217736, BEL_4_Base.bevn_encode_1, beva_id);
} /* Line: 376 */
 else  /* Line: 377 */ {
bevl_storeId = beva_id;
} /* Line: 378 */
return bevl_storeId;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_getPath_1(BEC_4_6_TextString beva_id) {
BEC_2_4_4_IOFilePath bevl_p = null;
BEC_4_6_TextString bevl_storeId = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
if (beva_id == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_id.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 385 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 385 */
 else  /* Line: 385 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 385 */ {
bevt_6_tmpvar_phold = bevp_storageDir.bem_fileGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_existsGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_not_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevt_7_tmpvar_phold = bevp_storageDir.bem_fileGet_0();
bevt_7_tmpvar_phold.bem_makeDirs_0();
} /* Line: 387 */
bevl_storeId = (BEC_4_6_TextString) this.bem_getStoreId_1(beva_id);
bevt_8_tmpvar_phold = bevp_storageDir.bem_copy_0();
bevl_p = (BEC_2_4_4_IOFilePath) bevt_8_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevl_storeId);
} /* Line: 390 */
return bevl_p;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_put_2(BEC_4_6_TextString beva_id, BEC_6_6_SystemObject beva_object) {
BEC_2_4_4_IOFilePath bevl_p = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_IOFile bevt_9_tmpvar_phold = null;
if (beva_id == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 396 */ {
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = beva_id.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 396 */
 else  /* Line: 396 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 396 */ {
bevl_p = this.bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 398 */ {
bevt_7_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_writerGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_ser.bem_serialize_2(beva_object, bevt_5_tmpvar_phold);
bevt_9_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevt_8_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 400 */
} /* Line: 398 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_4_6_TextString beva_id) {
BEC_2_4_4_IOFilePath bevl_p = null;
BEC_6_6_SystemObject bevl_object = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_IOFile bevt_12_tmpvar_phold = null;
if (beva_id == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_3_tmpvar_phold = beva_id.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 406 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 406 */
 else  /* Line: 406 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 406 */ {
bevl_p = this.bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_7_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_existsGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 408 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 408 */
 else  /* Line: 408 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 408 */ {
bevt_10_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_readerGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_tmpvar_phold);
bevt_12_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_readerGet_0();
bevt_11_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return bevl_object;
} /* Line: 411 */
} /* Line: 408 */
return null;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_4_6_TextString beva_id) {
BEC_2_4_4_IOFilePath bevl_p = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
if (beva_id == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 418 */ {
bevt_3_tmpvar_phold = bevo_3;
bevt_2_tmpvar_phold = beva_id.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 418 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 418 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 418 */
bevl_p = this.bem_getPath_1(beva_id);
bevt_6_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_existsGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 421 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_2_8_DbDirStore bem_delete_1(BEC_4_6_TextString beva_id) {
BEC_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_IOFile bevt_0_tmpvar_phold = null;
bevl_p = this.bem_getPath_1(beva_id);
bevt_0_tmpvar_phold = bevl_p.bem_fileGet_0();
bevt_0_tmpvar_phold.bem_delete_0();
return this;
} /*method end*/
public virtual BEC_6_10_SystemSerializer bem_serGet_0() {
return bevp_ser;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_serSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ser = (BEC_6_10_SystemSerializer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_storageDirGet_0() {
return bevp_storageDir;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_storageDirSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_storageDir = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_keyEncoderGet_0() {
return bevp_keyEncoder;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_keyEncoderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_keyEncoder = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {357, 358, 362, 362, 367, 368, 369, 375, 375, 376, 378, 380, 385, 385, 385, 385, 0, 0, 0, 386, 386, 386, 387, 387, 389, 390, 390, 392, 396, 396, 396, 396, 0, 0, 0, 397, 398, 398, 399, 399, 399, 399, 400, 400, 400, 406, 406, 406, 406, 0, 0, 0, 407, 408, 408, 408, 408, 0, 0, 0, 409, 409, 409, 409, 410, 410, 410, 411, 414, 418, 418, 0, 418, 418, 0, 0, 418, 418, 419, 420, 420, 421, 421, 423, 423, 427, 428, 428, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 27, 28, 32, 33, 34, 40, 45, 46, 49, 51, 65, 70, 71, 72, 74, 77, 81, 84, 85, 86, 88, 89, 91, 92, 93, 95, 109, 114, 115, 116, 118, 121, 125, 128, 129, 134, 135, 136, 137, 138, 139, 140, 141, 162, 167, 168, 169, 171, 174, 178, 181, 182, 187, 188, 189, 191, 194, 198, 201, 202, 203, 204, 205, 206, 207, 208, 211, 224, 229, 230, 233, 234, 236, 239, 243, 244, 246, 247, 248, 250, 251, 253, 254, 259, 260, 261, 265, 268, 272, 275, 279, 282};
/* BEGIN LINEINFO 
new 1 357 21
assign 1 358 22
assign 1 362 27
apNew 1 362 27
pathNew 1 362 28
assign 1 367 32
new 0 367 32
assign 1 368 33
assign 1 369 34
assign 1 375 40
def 1 375 45
assign 1 376 46
encode 1 376 46
assign 1 378 49
return 1 380 51
assign 1 385 65
def 1 385 70
assign 1 385 71
new 0 385 71
assign 1 385 72
notEquals 1 385 72
assign 1 0 74
assign 1 0 77
assign 1 0 81
assign 1 386 84
fileGet 0 386 84
assign 1 386 85
existsGet 0 386 85
assign 1 386 86
not 0 386 86
assign 1 387 88
fileGet 0 387 88
makeDirs 0 387 89
assign 1 389 91
getStoreId 1 389 91
assign 1 390 92
copy 0 390 92
assign 1 390 93
addStep 1 390 93
return 1 392 95
assign 1 396 109
def 1 396 114
assign 1 396 115
new 0 396 115
assign 1 396 116
notEquals 1 396 116
assign 1 0 118
assign 1 0 121
assign 1 0 125
assign 1 397 128
getPath 1 397 128
assign 1 398 129
def 1 398 134
assign 1 399 135
fileGet 0 399 135
assign 1 399 136
writerGet 0 399 136
assign 1 399 137
open 0 399 137
serialize 2 399 138
assign 1 400 139
fileGet 0 400 139
assign 1 400 140
writerGet 0 400 140
close 0 400 141
assign 1 406 162
def 1 406 167
assign 1 406 168
new 0 406 168
assign 1 406 169
notEquals 1 406 169
assign 1 0 171
assign 1 0 174
assign 1 0 178
assign 1 407 181
getPath 1 407 181
assign 1 408 182
def 1 408 187
assign 1 408 188
fileGet 0 408 188
assign 1 408 189
existsGet 0 408 189
assign 1 0 191
assign 1 0 194
assign 1 0 198
assign 1 409 201
fileGet 0 409 201
assign 1 409 202
readerGet 0 409 202
assign 1 409 203
open 0 409 203
assign 1 409 204
deserialize 1 409 204
assign 1 410 205
fileGet 0 410 205
assign 1 410 206
readerGet 0 410 206
close 0 410 207
return 1 411 208
return 1 414 211
assign 1 418 224
undef 1 418 229
assign 1 0 230
assign 1 418 233
new 0 418 233
assign 1 418 234
equals 1 418 234
assign 1 0 236
assign 1 0 239
assign 1 418 243
new 0 418 243
return 1 418 244
assign 1 419 246
getPath 1 419 246
assign 1 420 247
fileGet 0 420 247
assign 1 420 248
existsGet 0 420 248
assign 1 421 250
new 0 421 250
return 1 421 251
assign 1 423 253
new 0 423 253
return 1 423 254
assign 1 427 259
getPath 1 427 259
assign 1 428 260
fileGet 0 428 260
delete 0 428 261
return 1 0 265
assign 1 0 268
return 1 0 272
assign 1 0 275
return 1 0 279
assign 1 0 282
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 770804587: return bem_storageDirGet_0();
case 1335700743: return bem_serGet_0();
case 1102720804: return bem_classNameGet_0();
case 1875432906: return bem_keyEncoderGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 759722334: return bem_storageDirSet_1(bevd_0);
case 99049420: return bem_has_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 700652941: return bem_getPath_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1682031576: return bem_getStoreId_1((BEC_4_6_TextString) bevd_0);
case 393721811: return bem_pathNew_1((BEC_2_4_4_IOFilePath) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1346782996: return bem_serSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1886515159: return bem_keyEncoderSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 107034370: return bem_put_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_2_8_DbDirStore();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_2_8_DbDirStore.bevs_inst = (BEC_2_8_DbDirStore)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_DbDirStore.bevs_inst;
}
}
}
