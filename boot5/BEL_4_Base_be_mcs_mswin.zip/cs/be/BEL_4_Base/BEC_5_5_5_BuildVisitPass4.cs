namespace be.BEL_4_Base {
/* IO:File: source/build/Pass4.be */
public class BEC_5_5_5_BuildVisitPass4 : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass4() { }
static BEC_5_5_5_BuildVisitPass4() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static new BEC_5_5_5_BuildVisitPass4 bevs_inst;
public override BEC_6_6_SystemObject bem_begin_1(BEC_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
return this;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_BuildNode bevl_nnode = null;
BEC_4_6_TextString bevl_nps = null;
BEC_5_4_BuildNode bevl_nxn = null;
BEC_5_4_BuildNode bevl_nxnn = null;
BEC_5_4_BuildNode bevl_first = null;
BEC_5_8_BuildNamePath bevl_np = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 26 */ {
bevt_5_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 26 */ {
if (bevl_nnode == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 26 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 26 */
 else  /* Line: 26 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 26 */ {
bevt_9_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 26 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 26 */
 else  /* Line: 26 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 26 */ {
if (bevl_nps == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevl_nps = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 28 */
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevl_nps.bem_add_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 32 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_17_tmpvar_phold = bevl_nxn.bem_typenameGet_0();
bevt_18_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_notEquals_1(bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 32 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 32 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 32 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(19, bels_0));
bevt_19_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_20_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_19_tmpvar_phold);
} /* Line: 33 */
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 36 */ {
beva_node.bem_delete_0();
} /* Line: 37 */
 else  /* Line: 38 */ {
bevl_first = beva_node;
} /* Line: 39 */
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 43 */
 else  /* Line: 26 */ {
break;
} /* Line: 26 */
} /* Line: 26 */
if (bevl_first == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_23_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_tmpvar_phold);
bevl_np = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_26_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_equals_1(bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 48 */ {
bevt_28_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_tmpvar_phold);
beva_node.bem_delete_0();
} /* Line: 50 */
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_tmpvar_phold = bevl_first.bem_nextDescendGet_0();
return bevt_29_tmpvar_phold;
} /* Line: 54 */
bevt_30_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 25, 26, 26, 26, 26, 26, 0, 0, 0, 26, 26, 26, 0, 0, 0, 27, 27, 28, 30, 30, 30, 30, 31, 32, 32, 0, 32, 32, 32, 0, 0, 33, 33, 33, 35, 36, 36, 37, 39, 41, 42, 43, 45, 45, 46, 46, 47, 48, 48, 48, 48, 48, 0, 0, 0, 49, 49, 50, 52, 53, 54, 54, 56, 56};
public static new int[] bevs_smnlec
 = new int[] {11, 52, 55, 56, 57, 59, 64, 65, 68, 72, 75, 76, 77, 79, 82, 86, 89, 94, 95, 97, 98, 99, 100, 101, 102, 107, 108, 111, 112, 113, 115, 118, 122, 123, 124, 126, 127, 132, 133, 136, 138, 139, 140, 146, 151, 152, 153, 154, 155, 160, 161, 162, 163, 165, 168, 172, 175, 176, 177, 179, 180, 181, 182, 184, 185};
/* BEGIN LINEINFO 
begin 1 21 11
assign 1 25 52
nextPeerGet 0 25 52
assign 1 26 55
typenameGet 0 26 55
assign 1 26 56
IDGet 0 26 56
assign 1 26 57
equals 1 26 57
assign 1 26 59
def 1 26 64
assign 1 0 65
assign 1 0 68
assign 1 0 72
assign 1 26 75
typenameGet 0 26 75
assign 1 26 76
COLONGet 0 26 76
assign 1 26 77
equals 1 26 77
assign 1 0 79
assign 1 0 82
assign 1 0 86
assign 1 27 89
undef 1 27 94
assign 1 28 95
new 0 28 95
assign 1 30 97
heldGet 0 30 97
assign 1 30 98
add 1 30 98
assign 1 30 99
heldGet 0 30 99
assign 1 30 100
add 1 30 100
assign 1 31 101
nextPeerGet 0 31 101
assign 1 32 102
undef 1 32 107
assign 1 0 108
assign 1 32 111
typenameGet 0 32 111
assign 1 32 112
IDGet 0 32 112
assign 1 32 113
notEquals 1 32 113
assign 1 0 115
assign 1 0 118
assign 1 33 122
new 0 33 122
assign 1 33 123
new 2 33 123
throw 1 33 124
assign 1 35 126
nextPeerGet 0 35 126
assign 1 36 127
def 1 36 132
delete 0 37 133
assign 1 39 136
delete 0 41 138
assign 1 42 139
assign 1 43 140
assign 1 45 146
def 1 45 151
assign 1 46 152
NAMEPATHGet 0 46 152
typenameSet 1 46 153
assign 1 47 154
new 0 47 154
assign 1 48 155
def 1 48 160
assign 1 48 161
typenameGet 0 48 161
assign 1 48 162
IDGet 0 48 162
assign 1 48 163
equals 1 48 163
assign 1 0 165
assign 1 0 168
assign 1 0 172
assign 1 49 175
heldGet 0 49 175
assign 1 49 176
add 1 49 176
delete 0 50 177
fromString 1 52 179
heldSet 1 53 180
assign 1 54 181
nextDescendGet 0 54 181
return 1 54 182
assign 1 56 184
nextDescendGet 0 56 184
return 1 56 185
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_5_BuildVisitPass4();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_5_BuildVisitPass4.bevs_inst = (BEC_5_5_5_BuildVisitPass4)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_5_BuildVisitPass4.bevs_inst;
}
}
}
