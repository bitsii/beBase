namespace be.BEL_4_Base {
/* IO:File: source/build/Syns.be */
public class BEC_2_5_8_BuildClassSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
static BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 84));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 80));
private static byte[] bels_17 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 9));
private static byte[] bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 26));
private static BEC_2_9_5_ContainerArray bevo_18;
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_19 = {0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
private static byte[] bels_20 = {0x64,0x65,0x70,0x74,0x68};
private static byte[] bels_21 = {0x66,0x72,0x6F,0x6D,0x46,0x69,0x6C,0x65};
private static byte[] bels_22 = {0x6C,0x69,0x62,0x4E,0x61,0x6D,0x65};
private static byte[] bels_23 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bels_24 = {0x69,0x73,0x4C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_25 = {0x73,0x75,0x70,0x65,0x72,0x4C,0x69,0x73,0x74};
private static byte[] bels_26 = {0x75,0x73,0x65,0x73};
private static byte[] bels_27 = {0x70,0x74,0x79,0x4C,0x69,0x73,0x74};
private static byte[] bels_28 = {0x6D,0x74,0x64,0x4C,0x69,0x73,0x74};
private static byte[] bels_29 = {0x61,0x6C,0x6C,0x41,0x6E,0x63,0x65,0x73,0x74,0x6F,0x72,0x73,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_30 = {0x69,0x73,0x4E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
public static new BEC_2_5_8_BuildClassSyn bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_5_ContainerArray bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_5_ContainerArray bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxMtdxGet_0() {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevl_maxMtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 98 */ {
bevt_0_tmpvar_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 98 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpvar_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpvar_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 101 */
} /* Line: 100 */
 else  /* Line: 98 */ {
break;
} /* Line: 98 */
} /* Line: 98 */
return bevl_maxMtdx;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasDefaultGet_0() {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpvar_phold);
if (bevl_dmtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 111 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
this.bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = beva_psyn.bemd_0(1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpvar_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_4_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_5_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 136 */ {
bevt_8_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpvar_phold);
bevt_14_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_1));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 139 */ {
if (bevl_pv == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 139 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 139 */
 else  /* Line: 139 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 139 */ {
bevt_19_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 139 */
 else  /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 139 */ {
bevt_24_tmpvar_phold = bevo_1;
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_2;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 140 */
} /* Line: 139 */
 else  /* Line: 136 */ {
break;
} /* Line: 136 */
} /* Line: 136 */
bevt_31_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 145 */ {
bevt_32_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevt_35_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpvar_phold);
} /* Line: 148 */
} /* Line: 147 */
 else  /* Line: 145 */ {
break;
} /* Line: 145 */
} /* Line: 145 */
bevt_39_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 152 */ {
bevt_40_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 152 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpvar_phold);
if (bevl_pm == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 155 */ {
bevt_46_tmpvar_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpvar_phold == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 156 */ {
bevt_49_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpvar_phold == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 157 */ {
bevt_54_tmpvar_phold = bevo_3;
bevt_56_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_55_tmpvar_phold);
bevt_57_tmpvar_phold = bevo_4;
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_59_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_50_tmpvar_phold);
} /* Line: 158 */
} /* Line: 157 */
} /* Line: 156 */
} /* Line: 155 */
 else  /* Line: 152 */ {
break;
} /* Line: 152 */
} /* Line: 152 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpvar_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpvar_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 172 */ {
return this;
} /* Line: 172 */
bevp_integrated = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 177 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpvar_loop = bevp_mtdList.bem_arrayIteratorGet_0();
while (true)
 /* Line: 182 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 182 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_methodIndexesGet_0();
bevt_10_tmpvar_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpvar_phold.bem_put_1(bevt_10_tmpvar_phold);
} /* Line: 183 */
 else  /* Line: 182 */ {
break;
} /* Line: 182 */
} /* Line: 182 */
return this;
} /* Line: 185 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_11_tmpvar_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpvar_phold.bem_subtract_1(bevt_12_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 192 */
bevt_16_tmpvar_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 193 */ {
bevt_19_tmpvar_phold = bevo_5;
bevt_20_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 194 */
bevt_21_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_23_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_26_tmpvar_phold = bevo_6;
bevt_27_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_24_tmpvar_phold);
} /* Line: 197 */
bevt_28_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 199 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 199 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 199 */
 else  /* Line: 199 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 199 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 199 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 199 */
 else  /* Line: 199 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 199 */ {
bevt_33_tmpvar_phold = bevo_7;
bevt_34_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_31_tmpvar_phold);
} /* Line: 200 */
bevt_1_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 202 */ {
bevt_35_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 202 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_has_1(bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold.bevi_bool) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_41_tmpvar_phold = bevl_pn.bem_toString_0();
bevt_42_tmpvar_phold = bevo_8;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_notEquals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 204 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 204 */
 else  /* Line: 204 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 204 */ {
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 207 */
bevt_45_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_has_1(bevt_46_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) {
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 210 */
} /* Line: 209 */
 else  /* Line: 202 */ {
break;
} /* Line: 202 */
} /* Line: 202 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 214 */ {
bevt_47_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 214 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpvar_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpvar_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpvar_phold.bem_get_1(bevt_49_tmpvar_phold);
if (bevl_pm == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 217 */ {
bevt_51_tmpvar_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_52_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpvar_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 221 */
} /* Line: 218 */
 else  /* Line: 223 */ {
bevt_54_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpvar_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_methodIndexesGet_0();
bevt_57_tmpvar_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpvar_phold.bem_put_1(bevt_57_tmpvar_phold);
} /* Line: 227 */
} /* Line: 217 */
 else  /* Line: 214 */ {
break;
} /* Line: 214 */
} /* Line: 214 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 234 */ {
return this;
} /* Line: 234 */
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 236 */ {
return this;
} /* Line: 236 */
bevl_psyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_3_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 238 */ {
bevt_5_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 238 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_6_tmpvar_phold = bevl_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_8_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
if (bevl_pv == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 241 */ {
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 242 */ {
bevt_16_tmpvar_phold = bevo_9;
bevt_18_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_10;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_13_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_12_tmpvar_phold);
} /* Line: 243 */
 else  /* Line: 244 */ {
bevt_23_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_23_tmpvar_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_24_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_27_tmpvar_phold);
} /* Line: 246 */
} /* Line: 242 */
} /* Line: 241 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_29_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 250 */ {
bevt_31_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 250 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_32_tmpvar_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_34_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_32_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_33_tmpvar_phold);
if (bevl_pm == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 253 */ {
bevt_36_tmpvar_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevt_41_tmpvar_phold = bevo_11;
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_12;
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_47_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_38_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_37_tmpvar_phold);
} /* Line: 255 */
bevt_49_tmpvar_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_48_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 258 */ {
bevt_52_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_50_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 258 */ {
bevt_53_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_53_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_54_tmpvar_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_54_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 258 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_55_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_55_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
if (bevl_omr == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 266 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 266 */ {
if (bevl_pmr == null) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpvar_phold.bevi_bool) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 267 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
if (bevl_omr == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_61_tmpvar_phold.bevi_bool) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 267 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 267 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 267 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 267 */ {
bevt_64_tmpvar_phold = bevo_13;
bevt_67_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_add_1(bevt_65_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_63_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_62_tmpvar_phold);
} /* Line: 268 */
} /* Line: 267 */
 else  /* Line: 270 */ {
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 272 */
} /* Line: 266 */
} /* Line: 253 */
 else  /* Line: 250 */ {
break;
} /* Line: 250 */
} /* Line: 250 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpvar_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 279 */ {
bevt_6_tmpvar_phold = bevo_14;
bevt_9_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 280 */
 else  /* Line: 279 */ {
bevt_10_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevt_11_tmpvar_phold = beva_pmr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 284 */ {
bevt_12_tmpvar_phold = beva_omr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 284 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 284 */ {
return this;
} /* Line: 285 */
bevt_13_tmpvar_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_osyn.bemd_0(986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpvar_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 288 */ {
bevt_20_tmpvar_phold = bevo_15;
bevt_23_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_18_tmpvar_phold);
} /* Line: 289 */
} /* Line: 288 */
} /* Line: 279 */
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
this.bem_new_0();
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 296 */ {
bevt_2_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 296 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 298 */ {
bevt_10_tmpvar_phold = bevo_16;
bevt_12_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_17;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 299 */
} /* Line: 298 */
 else  /* Line: 296 */ {
break;
} /* Line: 296 */
} /* Line: 296 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpvar_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpvar_phold.bemd_0(842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpvar_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 314 */ {
bevt_8_tmpvar_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 314 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpvar_phold);
} /* Line: 316 */
 else  /* Line: 314 */ {
break;
} /* Line: 314 */
} /* Line: 314 */
bevt_11_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 318 */ {
bevt_12_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 318 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 321 */
 else  /* Line: 318 */ {
break;
} /* Line: 318 */
} /* Line: 318 */
bevt_14_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 323 */ {
bevt_15_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 323 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 326 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
this.bem_postLoad_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_postLoad_0() {
BEC_2_9_5_ContainerArray bevl_nptyList = null;
BEC_2_9_5_ContainerArray bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
bevl_nptyList = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_mtdnList = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 336 */ {
bevt_1_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 336 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_5_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpvar_phold, bevl_ov);
} /* Line: 340 */
} /* Line: 338 */
 else  /* Line: 336 */ {
break;
} /* Line: 336 */
} /* Line: 336 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 346 */ {
bevt_6_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 346 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = bevl_unq.bem_has_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_10_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpvar_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
} /* Line: 353 */
} /* Line: 348 */
 else  /* Line: 346 */ {
break;
} /* Line: 346 */
} /* Line: 346 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 360 */ {
bevt_14_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 360 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpvar_phold, bevl_om);
bevt_18_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 365 */ {
bevt_19_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpvar_phold, bevl_om);
} /* Line: 366 */
} /* Line: 365 */
 else  /* Line: 360 */ {
break;
} /* Line: 360 */
} /* Line: 360 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 372 */ {
bevt_20_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 372 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpvar_phold = bevl_unq.bem_has_1(bevt_23_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 374 */ {
bevt_24_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_28_tmpvar_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpvar_phold);
} /* Line: 386 */
bevt_29_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpvar_phold);
bevl_oma.bemd_1(1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
} /* Line: 392 */
} /* Line: 374 */
 else  /* Line: 372 */ {
break;
} /* Line: 372 */
} /* Line: 372 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 397 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 397 */ {
bevl_s = bevt_0_tmpvar_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 399 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_9_5_ContainerArray bevl_names = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
lock (typeof(BEC_2_5_8_BuildClassSyn)) {
if (bevo_18 == null) {
bevo_18 = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
}
}
bevl_names = bevo_18;
bevt_3_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevl_names.bem_get_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_19));
bevl_names.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_20));
bevl_names.bem_put_2(bevt_6_tmpvar_phold, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_21));
bevl_names.bem_put_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_22));
bevl_names.bem_put_2(bevt_10_tmpvar_phold, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_23));
bevl_names.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_24));
bevl_names.bem_put_2(bevt_14_tmpvar_phold, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_25));
bevl_names.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_26));
bevl_names.bem_put_2(bevt_18_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_27));
bevl_names.bem_put_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_28));
bevl_names.bem_put_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bels_29));
bevl_names.bem_put_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_30));
bevl_names.bem_put_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
} /* Line: 419 */
bevt_28_tmpvar_phold = (new BEC_2_6_23_SystemNamedPropertiesIterator()).bem_new_2(this, bevl_names);
return bevt_28_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_superNpGet_0() {
return bevp_superNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_depthGet_0() {
return bevp_depth;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_newMbrsGet_0() {
return bevp_newMbrs;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_newMtdsGet_0() {
return bevp_newMtds;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_defMtdsGet_0() {
return bevp_defMtds;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_directPropertiesGet_0() {
return bevp_directProperties;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_directMethodsGet_0() {
return bevp_directMethods;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_allTypesGet_0() {
return bevp_allTypes;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_superListGet_0() {
return bevp_superList;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mtdMapGet_0() {
return bevp_mtdMap;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_mtdListGet_0() {
return bevp_mtdList;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_ptyMapGet_0() {
return bevp_ptyMap;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_ptyListGet_0() {
return bevp_ptyList;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() {
return bevp_allAncestorsClose;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_integratedGet_0() {
return bevp_integrated;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_iCheckedGet_0() {
return bevp_iChecked;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_usesGet_0() {
return bevp_uses;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_signatureChangedGet_0() {
return bevp_signatureChanged;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() {
return bevp_signatureChecked;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {74, 76, 78, 80, 81, 82, 83, 84, 85, 86, 87, 89, 90, 91, 92, 97, 98, 98, 99, 100, 100, 100, 101, 104, 108, 108, 109, 109, 111, 111, 113, 113, 116, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 130, 131, 131, 132, 132, 133, 133, 136, 136, 136, 136, 137, 138, 138, 138, 138, 139, 139, 139, 139, 139, 139, 0, 0, 0, 139, 139, 139, 0, 0, 0, 140, 140, 140, 140, 140, 140, 140, 140, 140, 140, 140, 140, 145, 145, 145, 146, 147, 147, 148, 148, 148, 148, 152, 152, 152, 152, 153, 154, 154, 154, 154, 155, 155, 156, 156, 156, 157, 157, 157, 157, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 163, 164, 164, 164, 168, 168, 172, 173, 174, 175, 176, 177, 177, 178, 179, 180, 181, 182, 0, 182, 182, 183, 183, 183, 183, 185, 187, 188, 189, 191, 191, 191, 191, 192, 192, 192, 193, 194, 194, 194, 194, 194, 196, 196, 196, 0, 0, 0, 197, 197, 197, 197, 197, 199, 199, 199, 0, 0, 0, 199, 199, 0, 0, 0, 200, 200, 200, 200, 200, 202, 0, 202, 202, 203, 204, 204, 204, 204, 204, 204, 204, 204, 0, 0, 0, 206, 207, 209, 209, 209, 209, 209, 210, 214, 214, 215, 216, 216, 216, 217, 217, 218, 219, 219, 220, 220, 221, 224, 224, 225, 226, 227, 227, 227, 227, 234, 235, 236, 236, 236, 237, 238, 238, 238, 238, 239, 240, 240, 240, 240, 241, 241, 242, 242, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 245, 245, 245, 245, 246, 246, 246, 246, 250, 250, 250, 250, 251, 252, 252, 252, 252, 253, 253, 254, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 257, 257, 257, 258, 258, 258, 258, 259, 259, 260, 260, 262, 258, 264, 265, 265, 266, 266, 0, 266, 266, 0, 0, 267, 267, 267, 0, 267, 267, 267, 0, 0, 268, 268, 268, 268, 268, 268, 268, 272, 279, 279, 279, 280, 280, 280, 280, 280, 280, 280, 281, 284, 284, 0, 0, 0, 285, 287, 287, 288, 288, 288, 288, 289, 289, 289, 289, 289, 289, 289, 295, 296, 296, 296, 296, 297, 298, 298, 298, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 302, 303, 308, 308, 309, 309, 310, 310, 311, 311, 312, 312, 313, 313, 314, 314, 314, 314, 315, 316, 316, 318, 318, 318, 318, 319, 320, 321, 323, 323, 323, 323, 324, 325, 326, 328, 332, 333, 336, 336, 337, 338, 338, 338, 338, 340, 340, 344, 345, 346, 346, 347, 348, 348, 348, 348, 349, 349, 350, 351, 351, 352, 353, 353, 353, 356, 358, 360, 360, 361, 363, 363, 365, 365, 365, 365, 366, 366, 370, 371, 372, 372, 373, 374, 374, 374, 374, 375, 375, 384, 384, 385, 385, 385, 386, 386, 388, 388, 389, 390, 391, 392, 392, 392, 395, 397, 0, 397, 397, 398, 399, 402, 406, 406, 407, 407, 407, 407, 408, 408, 408, 409, 409, 409, 410, 410, 410, 411, 411, 411, 412, 412, 412, 413, 413, 413, 414, 414, 414, 415, 415, 415, 416, 416, 416, 417, 417, 417, 418, 418, 418, 419, 419, 419, 421, 421, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 112, 113, 116, 118, 119, 120, 125, 126, 133, 141, 142, 143, 148, 149, 150, 152, 153, 156, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 254, 256, 257, 258, 259, 260, 261, 262, 263, 264, 266, 271, 272, 275, 279, 282, 283, 284, 286, 289, 293, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 314, 315, 318, 320, 321, 322, 324, 325, 326, 327, 334, 335, 336, 339, 341, 342, 343, 344, 345, 346, 351, 352, 353, 358, 359, 360, 361, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 386, 387, 388, 389, 394, 395, 463, 465, 466, 467, 468, 469, 474, 475, 476, 477, 478, 479, 479, 482, 484, 485, 486, 487, 488, 494, 496, 497, 498, 499, 500, 501, 502, 503, 504, 506, 508, 510, 511, 512, 513, 514, 516, 518, 519, 521, 524, 528, 531, 532, 533, 534, 535, 537, 539, 544, 545, 548, 552, 555, 560, 561, 564, 568, 571, 572, 573, 574, 575, 577, 577, 580, 582, 583, 584, 585, 586, 587, 592, 593, 594, 595, 597, 600, 604, 607, 608, 610, 611, 612, 613, 618, 619, 626, 629, 631, 632, 633, 634, 635, 640, 641, 643, 644, 645, 646, 647, 651, 652, 653, 654, 655, 656, 657, 658, 748, 750, 751, 756, 757, 759, 760, 761, 762, 765, 767, 768, 769, 770, 771, 772, 777, 778, 779, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 795, 796, 797, 798, 799, 800, 801, 802, 810, 811, 812, 815, 817, 818, 819, 820, 821, 822, 827, 828, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 843, 844, 845, 846, 849, 850, 851, 853, 854, 855, 856, 857, 858, 864, 865, 866, 867, 872, 873, 876, 881, 882, 885, 889, 894, 899, 900, 903, 908, 913, 914, 917, 921, 922, 923, 924, 925, 926, 927, 931, 967, 968, 969, 971, 972, 973, 974, 975, 976, 977, 980, 982, 984, 986, 989, 993, 996, 998, 999, 1000, 1001, 1002, 1003, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1037, 1038, 1039, 1040, 1043, 1045, 1046, 1047, 1048, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1068, 1069, 1097, 1098, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1114, 1116, 1117, 1118, 1124, 1125, 1126, 1129, 1131, 1132, 1133, 1139, 1140, 1141, 1144, 1146, 1147, 1148, 1154, 1205, 1206, 1207, 1210, 1212, 1213, 1214, 1215, 1220, 1221, 1222, 1229, 1230, 1231, 1234, 1236, 1237, 1238, 1239, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1260, 1261, 1262, 1265, 1267, 1268, 1269, 1270, 1271, 1272, 1277, 1278, 1279, 1286, 1287, 1288, 1291, 1293, 1294, 1295, 1296, 1301, 1302, 1303, 1304, 1305, 1306, 1307, 1312, 1313, 1314, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1330, 1331, 1331, 1334, 1336, 1337, 1338, 1344, 1378, 1379, 1385, 1386, 1387, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1430, 1431, 1434, 1437, 1441, 1444, 1448, 1451, 1455, 1458, 1462, 1465, 1469, 1472, 1476, 1479, 1483, 1486, 1490, 1493, 1497, 1500, 1504, 1507, 1511, 1514, 1518, 1521, 1525, 1528, 1532, 1535, 1539, 1542, 1546, 1549, 1553, 1556, 1560, 1563, 1567, 1570, 1574, 1577, 1581, 1584, 1588, 1591, 1595, 1598, 1602, 1605, 1609, 1612, 1616, 1619};
/* BEGIN LINEINFO 
assign 1 74 88
new 0 74 88
assign 1 76 89
new 0 76 89
assign 1 78 90
new 0 78 90
assign 1 80 91
new 0 80 91
assign 1 81 92
new 0 81 92
assign 1 82 93
new 0 82 93
assign 1 83 94
new 0 83 94
assign 1 84 95
new 0 84 95
assign 1 85 96
new 0 85 96
assign 1 86 97
new 0 86 97
assign 1 87 98
new 0 87 98
assign 1 89 99
new 0 89 99
assign 1 90 100
new 0 90 100
assign 1 91 101
new 0 91 101
assign 1 92 102
new 0 92 102
assign 1 97 112
new 0 97 112
assign 1 98 113
valueIteratorGet 0 98 113
assign 1 98 116
hasNextGet 0 98 116
assign 1 99 118
nextGet 0 99 118
assign 1 100 119
mtdxGet 0 100 119
assign 1 100 120
greater 1 100 125
assign 1 101 126
mtdxGet 0 101 126
return 1 104 133
assign 1 108 141
new 0 108 141
assign 1 108 142
get 1 108 142
assign 1 109 143
def 1 109 148
assign 1 111 149
new 0 111 149
return 1 111 150
assign 1 113 152
new 0 113 152
return 1 113 153
new 0 116 156
assign 1 119 230
new 0 119 230
assign 1 120 231
new 0 120 231
assign 1 121 232
new 0 121 232
assign 1 122 233
new 0 122 233
assign 1 123 234
new 0 123 234
assign 1 124 235
new 0 124 235
assign 1 125 236
new 0 125 236
assign 1 126 237
new 0 126 237
assign 1 127 238
new 0 127 238
assign 1 128 239
new 0 128 239
assign 1 129 240
new 0 129 240
assign 1 130 241
superListGet 0 130 241
assign 1 130 242
copy 0 130 242
assign 1 131 243
namepathGet 0 131 243
addValue 1 131 244
assign 1 132 245
mtdListGet 0 132 245
assign 1 132 246
copy 0 132 246
assign 1 133 247
ptyListGet 0 133 247
assign 1 133 248
copy 0 133 248
assign 1 136 249
heldGet 0 136 249
assign 1 136 250
orderedVarsGet 0 136 250
assign 1 136 251
iteratorGet 0 136 251
assign 1 136 254
hasNextGet 0 136 254
assign 1 137 256
nextGet 0 137 256
assign 1 138 257
ptyMapGet 0 138 257
assign 1 138 258
heldGet 0 138 258
assign 1 138 259
nameGet 0 138 259
assign 1 138 260
get 1 138 260
assign 1 139 261
heldGet 0 139 261
assign 1 139 262
nameGet 0 139 262
assign 1 139 263
new 0 139 263
assign 1 139 264
notEquals 1 139 264
assign 1 139 266
undef 1 139 271
assign 1 0 272
assign 1 0 275
assign 1 0 279
assign 1 139 282
heldGet 0 139 282
assign 1 139 283
isDeclaredGet 0 139 283
assign 1 139 284
not 0 139 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 140 296
new 0 140 296
assign 1 140 297
heldGet 0 140 297
assign 1 140 298
nameGet 0 140 298
assign 1 140 299
add 1 140 299
assign 1 140 300
new 0 140 300
assign 1 140 301
add 1 140 301
assign 1 140 302
heldGet 0 140 302
assign 1 140 303
namepathGet 0 140 303
assign 1 140 304
toString 0 140 304
assign 1 140 305
add 1 140 305
assign 1 140 306
new 2 140 306
throw 1 140 307
assign 1 145 314
ptyListGet 0 145 314
assign 1 145 315
iteratorGet 0 145 315
assign 1 145 318
hasNextGet 0 145 318
assign 1 146 320
nextGet 0 146 320
assign 1 147 321
memSynGet 0 147 321
assign 1 147 322
isTypedGet 0 147 322
assign 1 148 324
heldGet 0 148 324
assign 1 148 325
memSynGet 0 148 325
assign 1 148 326
namepathGet 0 148 326
addUsed 1 148 327
assign 1 152 334
heldGet 0 152 334
assign 1 152 335
orderedMethodsGet 0 152 335
assign 1 152 336
iteratorGet 0 152 336
assign 1 152 339
hasNextGet 0 152 339
assign 1 153 341
nextGet 0 153 341
assign 1 154 342
mtdMapGet 0 154 342
assign 1 154 343
heldGet 0 154 343
assign 1 154 344
nameGet 0 154 344
assign 1 154 345
get 1 154 345
assign 1 155 346
def 1 155 351
assign 1 156 352
rsynGet 0 156 352
assign 1 156 353
def 1 156 358
assign 1 157 359
heldGet 0 157 359
assign 1 157 360
rtypeGet 0 157 360
assign 1 157 361
undef 1 157 366
assign 1 158 367
new 0 158 367
assign 1 158 368
heldGet 0 158 368
assign 1 158 369
nameGet 0 158 369
assign 1 158 370
add 1 158 370
assign 1 158 371
new 0 158 371
assign 1 158 372
add 1 158 372
assign 1 158 373
heldGet 0 158 373
assign 1 158 374
nameGet 0 158 374
assign 1 158 375
add 1 158 375
assign 1 158 376
new 2 158 376
throw 1 158 377
loadClass 1 163 386
assign 1 164 387
depthGet 0 164 387
assign 1 164 388
new 0 164 388
assign 1 164 389
add 1 164 389
assign 1 168 394
has 1 168 394
return 1 168 395
return 1 172 463
assign 1 173 465
new 0 173 465
assign 1 174 466
new 0 174 466
assign 1 175 467
new 0 175 467
assign 1 176 468
new 0 176 468
assign 1 177 469
undef 1 177 474
assign 1 178 475
new 0 178 475
assign 1 179 476
sizeGet 0 179 476
assign 1 180 477
sizeGet 0 180 477
assign 1 181 478
assign 1 182 479
arrayIteratorGet 0 0 479
assign 1 182 482
hasNextGet 0 182 482
assign 1 182 484
nextGet 0 182 484
assign 1 183 485
emitDataGet 0 183 485
assign 1 183 486
methodIndexesGet 0 183 486
assign 1 183 487
new 2 183 487
put 1 183 488
return 1 185 494
assign 1 187 496
getSynNp 1 187 496
assign 1 188 497
new 0 188 497
assign 1 189 498
new 0 189 498
assign 1 191 499
sizeGet 0 191 499
assign 1 191 500
ptyListGet 0 191 500
assign 1 191 501
sizeGet 0 191 501
assign 1 191 502
subtract 1 191 502
assign 1 192 503
libNameGet 0 192 503
assign 1 192 504
equals 1 192 504
integrate 1 192 506
assign 1 193 508
isFinalGet 0 193 508
assign 1 194 510
new 0 194 510
assign 1 194 511
toString 0 194 511
assign 1 194 512
add 1 194 512
assign 1 194 513
new 1 194 513
throw 1 194 514
assign 1 196 516
isLocalGet 0 196 516
assign 1 196 518
libNameGet 0 196 518
assign 1 196 519
notEquals 1 196 519
assign 1 0 521
assign 1 0 524
assign 1 0 528
assign 1 197 531
new 0 197 531
assign 1 197 532
toString 0 197 532
assign 1 197 533
add 1 197 533
assign 1 197 534
new 1 197 534
throw 1 197 535
assign 1 199 537
isLocalGet 0 199 537
assign 1 199 539
not 0 199 544
assign 1 0 545
assign 1 0 548
assign 1 0 552
assign 1 199 555
not 0 199 560
assign 1 0 561
assign 1 0 564
assign 1 0 568
assign 1 200 571
new 0 200 571
assign 1 200 572
toString 0 200 572
assign 1 200 573
add 1 200 573
assign 1 200 574
new 1 200 574
throw 1 200 575
assign 1 202 577
linkedListIteratorGet 0 0 577
assign 1 202 580
hasNextGet 0 202 580
assign 1 202 582
nextGet 0 202 582
assign 1 203 583
getSynNp 1 203 583
assign 1 204 584
closeLibrariesGet 0 204 584
assign 1 204 585
libNameGet 0 204 585
assign 1 204 586
has 1 204 586
assign 1 204 587
not 0 204 592
assign 1 204 593
toString 0 204 593
assign 1 204 594
new 0 204 594
assign 1 204 595
notEquals 1 204 595
assign 1 0 597
assign 1 0 600
assign 1 0 604
assign 1 206 607
new 0 206 607
assign 1 207 608
new 0 207 608
assign 1 209 610
closeLibrariesGet 0 209 610
assign 1 209 611
libNameGet 0 209 611
assign 1 209 612
has 1 209 612
assign 1 209 613
not 0 209 618
assign 1 210 619
new 0 210 619
assign 1 214 626
valueIteratorGet 0 214 626
assign 1 214 629
hasNextGet 0 214 629
assign 1 215 631
nextGet 0 215 631
assign 1 216 632
mtdMapGet 0 216 632
assign 1 216 633
nameGet 0 216 633
assign 1 216 634
get 1 216 634
assign 1 217 635
def 1 217 640
assign 1 218 641
notEquals 1 218 641
assign 1 219 643
new 0 219 643
lastDefSet 1 219 644
assign 1 220 645
new 0 220 645
isOverrideSet 1 220 646
assign 1 221 647
increment 0 221 647
assign 1 224 651
new 0 224 651
isOverrideSet 1 224 652
assign 1 225 653
increment 0 225 653
assign 1 226 654
increment 0 226 654
assign 1 227 655
emitDataGet 0 227 655
assign 1 227 656
methodIndexesGet 0 227 656
assign 1 227 657
new 2 227 657
put 1 227 658
return 1 234 748
assign 1 235 750
new 0 235 750
assign 1 236 751
undef 1 236 756
return 1 236 757
assign 1 237 759
getSynNp 1 237 759
assign 1 238 760
heldGet 0 238 760
assign 1 238 761
orderedVarsGet 0 238 761
assign 1 238 762
iteratorGet 0 238 762
assign 1 238 765
hasNextGet 0 238 765
assign 1 239 767
nextGet 0 239 767
assign 1 240 768
ptyMapGet 0 240 768
assign 1 240 769
heldGet 0 240 769
assign 1 240 770
nameGet 0 240 770
assign 1 240 771
get 1 240 771
assign 1 241 772
def 1 241 777
assign 1 242 778
heldGet 0 242 778
assign 1 242 779
isDeclaredGet 0 242 779
assign 1 243 781
new 0 243 781
assign 1 243 782
heldGet 0 243 782
assign 1 243 783
nameGet 0 243 783
assign 1 243 784
add 1 243 784
assign 1 243 785
new 0 243 785
assign 1 243 786
add 1 243 786
assign 1 243 787
heldGet 0 243 787
assign 1 243 788
namepathGet 0 243 788
assign 1 243 789
toString 0 243 789
assign 1 243 790
add 1 243 790
assign 1 243 791
new 1 243 791
throw 1 243 792
assign 1 245 795
heldGet 0 245 795
assign 1 245 796
memSynGet 0 245 796
assign 1 245 797
isTypedGet 0 245 797
isTypedSet 1 245 798
assign 1 246 799
heldGet 0 246 799
assign 1 246 800
memSynGet 0 246 800
assign 1 246 801
namepathGet 0 246 801
namepathSet 1 246 802
assign 1 250 810
heldGet 0 250 810
assign 1 250 811
orderedMethodsGet 0 250 811
assign 1 250 812
iteratorGet 0 250 812
assign 1 250 815
hasNextGet 0 250 815
assign 1 251 817
nextGet 0 251 817
assign 1 252 818
mtdMapGet 0 252 818
assign 1 252 819
heldGet 0 252 819
assign 1 252 820
nameGet 0 252 820
assign 1 252 821
get 1 252 821
assign 1 253 822
def 1 253 827
assign 1 254 828
isFinalGet 0 254 828
assign 1 255 830
new 0 255 830
assign 1 255 831
heldGet 0 255 831
assign 1 255 832
nameGet 0 255 832
assign 1 255 833
add 1 255 833
assign 1 255 834
new 0 255 834
assign 1 255 835
add 1 255 835
assign 1 255 836
heldGet 0 255 836
assign 1 255 837
namepathGet 0 255 837
assign 1 255 838
toString 0 255 838
assign 1 255 839
add 1 255 839
assign 1 255 840
new 2 255 840
throw 1 255 841
assign 1 257 843
containedGet 0 257 843
assign 1 257 844
firstGet 0 257 844
assign 1 257 845
containedGet 0 257 845
assign 1 258 846
new 0 258 846
assign 1 258 849
argSynsGet 0 258 849
assign 1 258 850
lengthGet 0 258 850
assign 1 258 851
lesser 1 258 851
assign 1 259 853
argSynsGet 0 259 853
assign 1 259 854
get 1 259 854
assign 1 260 855
get 1 260 855
assign 1 260 856
heldGet 0 260 856
checkTypes 5 262 857
assign 1 258 858
increment 0 258 858
assign 1 264 864
rsynGet 0 264 864
assign 1 265 865
heldGet 0 265 865
assign 1 265 866
rtypeGet 0 265 866
assign 1 266 867
undef 1 266 872
assign 1 0 873
assign 1 266 876
undef 1 266 881
assign 1 0 882
assign 1 0 885
assign 1 267 889
undef 1 267 894
assign 1 267 894
not 0 267 899
assign 1 0 900
assign 1 267 903
undef 1 267 908
assign 1 267 908
not 0 267 913
assign 1 0 914
assign 1 0 917
assign 1 268 921
new 0 268 921
assign 1 268 922
heldGet 0 268 922
assign 1 268 923
namepathGet 0 268 923
assign 1 268 924
toString 0 268 924
assign 1 268 925
add 1 268 925
assign 1 268 926
new 2 268 926
throw 1 268 927
checkTypes 5 272 931
assign 1 279 967
isTypedGet 0 279 967
assign 1 279 968
isTypedGet 0 279 968
assign 1 279 969
notEquals 1 279 969
assign 1 280 971
new 0 280 971
assign 1 280 972
heldGet 0 280 972
assign 1 280 973
namepathGet 0 280 973
assign 1 280 974
toString 0 280 974
assign 1 280 975
add 1 280 975
assign 1 280 976
new 2 280 976
throw 1 280 977
assign 1 281 980
isTypedGet 0 281 980
assign 1 284 982
isSelfGet 0 284 982
assign 1 284 984
isSelfGet 0 284 984
assign 1 0 986
assign 1 0 989
assign 1 0 993
return 1 285 996
assign 1 287 998
namepathGet 0 287 998
assign 1 287 999
getSynNp 1 287 999
assign 1 288 1000
allTypesGet 0 288 1000
assign 1 288 1001
namepathGet 0 288 1001
assign 1 288 1002
has 1 288 1002
assign 1 288 1003
not 0 288 1003
assign 1 289 1005
new 0 289 1005
assign 1 289 1006
heldGet 0 289 1006
assign 1 289 1007
namepathGet 0 289 1007
assign 1 289 1008
toString 0 289 1008
assign 1 289 1009
add 1 289 1009
assign 1 289 1010
new 2 289 1010
throw 1 289 1011
new 0 295 1037
assign 1 296 1038
heldGet 0 296 1038
assign 1 296 1039
orderedVarsGet 0 296 1039
assign 1 296 1040
iteratorGet 0 296 1040
assign 1 296 1043
hasNextGet 0 296 1043
assign 1 297 1045
nextGet 0 297 1045
assign 1 298 1046
heldGet 0 298 1046
assign 1 298 1047
isDeclaredGet 0 298 1047
assign 1 298 1048
not 0 298 1048
assign 1 299 1050
new 0 299 1050
assign 1 299 1051
heldGet 0 299 1051
assign 1 299 1052
nameGet 0 299 1052
assign 1 299 1053
add 1 299 1053
assign 1 299 1054
new 0 299 1054
assign 1 299 1055
add 1 299 1055
assign 1 299 1056
heldGet 0 299 1056
assign 1 299 1057
namepathGet 0 299 1057
assign 1 299 1058
toString 0 299 1058
assign 1 299 1059
add 1 299 1059
assign 1 299 1060
new 2 299 1060
throw 1 299 1061
loadClass 1 302 1068
assign 1 303 1069
new 0 303 1069
assign 1 308 1097
heldGet 0 308 1097
assign 1 308 1098
fromFileGet 0 308 1098
assign 1 309 1099
heldGet 0 309 1099
assign 1 309 1100
namepathGet 0 309 1100
assign 1 310 1101
heldGet 0 310 1101
assign 1 310 1102
libNameGet 0 310 1102
assign 1 311 1103
heldGet 0 311 1103
assign 1 311 1104
isFinalGet 0 311 1104
assign 1 312 1105
heldGet 0 312 1105
assign 1 312 1106
isLocalGet 0 312 1106
assign 1 313 1107
heldGet 0 313 1107
assign 1 313 1108
isNotNullGet 0 313 1108
assign 1 314 1109
heldGet 0 314 1109
assign 1 314 1110
usedGet 0 314 1110
assign 1 314 1111
iteratorGet 0 314 1111
assign 1 314 1114
hasNextGet 0 314 1114
assign 1 315 1116
nextGet 0 315 1116
assign 1 316 1117
toString 0 316 1117
put 1 316 1118
assign 1 318 1124
heldGet 0 318 1124
assign 1 318 1125
orderedVarsGet 0 318 1125
assign 1 318 1126
iteratorGet 0 318 1126
assign 1 318 1129
hasNextGet 0 318 1129
assign 1 319 1131
nextGet 0 319 1131
assign 1 320 1132
new 2 320 1132
addValue 1 321 1133
assign 1 323 1139
heldGet 0 323 1139
assign 1 323 1140
orderedMethodsGet 0 323 1140
assign 1 323 1141
iteratorGet 0 323 1141
assign 1 323 1144
hasNextGet 0 323 1144
assign 1 324 1146
nextGet 0 324 1146
assign 1 325 1147
new 2 325 1147
addValue 1 326 1148
postLoad 0 328 1154
assign 1 332 1205
new 0 332 1205
assign 1 333 1206
new 0 333 1206
assign 1 336 1207
iteratorGet 0 336 1207
assign 1 336 1210
hasNextGet 0 336 1210
assign 1 337 1212
nextGet 0 337 1212
assign 1 338 1213
nameGet 0 338 1213
assign 1 338 1214
has 1 338 1214
assign 1 338 1215
not 0 338 1220
assign 1 340 1221
nameGet 0 340 1221
put 2 340 1222
assign 1 344 1229
new 0 344 1229
assign 1 345 1230
new 0 345 1230
assign 1 346 1231
iteratorGet 0 346 1231
assign 1 346 1234
hasNextGet 0 346 1234
assign 1 347 1236
nextGet 0 347 1236
assign 1 348 1237
nameGet 0 348 1237
assign 1 348 1238
has 1 348 1238
assign 1 348 1239
not 0 348 1244
assign 1 349 1245
nameGet 0 349 1245
assign 1 349 1246
get 1 349 1246
mposSet 1 350 1247
assign 1 351 1248
new 0 351 1248
assign 1 351 1249
add 1 351 1249
addValue 1 352 1250
assign 1 353 1251
nameGet 0 353 1251
assign 1 353 1252
nameGet 0 353 1252
put 2 353 1253
assign 1 356 1260
assign 1 358 1261
new 0 358 1261
assign 1 360 1262
iteratorGet 0 360 1262
assign 1 360 1265
hasNextGet 0 360 1265
assign 1 361 1267
nextGet 0 361 1267
assign 1 363 1268
nameGet 0 363 1268
put 2 363 1269
assign 1 365 1270
nameGet 0 365 1270
assign 1 365 1271
has 1 365 1271
assign 1 365 1272
not 0 365 1277
assign 1 366 1278
nameGet 0 366 1278
put 2 366 1279
assign 1 370 1286
new 0 370 1286
assign 1 371 1287
new 0 371 1287
assign 1 372 1288
iteratorGet 0 372 1288
assign 1 372 1291
hasNextGet 0 372 1291
assign 1 373 1293
nextGet 0 373 1293
assign 1 374 1294
nameGet 0 374 1294
assign 1 374 1295
has 1 374 1295
assign 1 374 1296
not 0 374 1301
assign 1 375 1302
nameGet 0 375 1302
assign 1 375 1303
get 1 375 1303
assign 1 384 1304
nameGet 0 384 1304
assign 1 384 1305
get 1 384 1305
assign 1 385 1306
declarationGet 0 385 1306
assign 1 385 1307
undef 1 385 1312
assign 1 386 1313
originGet 0 386 1313
declarationSet 1 386 1314
assign 1 388 1316
declarationGet 0 388 1316
declarationSet 1 388 1317
mtdxSet 1 389 1318
assign 1 390 1319
increment 0 390 1319
addValue 1 391 1320
assign 1 392 1321
nameGet 0 392 1321
assign 1 392 1322
nameGet 0 392 1322
put 2 392 1323
assign 1 395 1330
assign 1 397 1331
linkedListIteratorGet 0 0 1331
assign 1 397 1334
hasNextGet 0 397 1334
assign 1 397 1336
nextGet 0 397 1336
put 2 398 1337
assign 1 399 1338
put 2 402 1344
assign 1 406 1378
new 0 406 1378
assign 1 406 1379
new 1 406 1379
assign 1 407 1385
new 0 407 1385
assign 1 407 1386
get 1 407 1386
assign 1 407 1387
undef 1 407 1392
assign 1 408 1393
new 0 408 1393
assign 1 408 1394
new 0 408 1394
put 2 408 1395
assign 1 409 1396
new 0 409 1396
assign 1 409 1397
new 0 409 1397
put 2 409 1398
assign 1 410 1399
new 0 410 1399
assign 1 410 1400
new 0 410 1400
put 2 410 1401
assign 1 411 1402
new 0 411 1402
assign 1 411 1403
new 0 411 1403
put 2 411 1404
assign 1 412 1405
new 0 412 1405
assign 1 412 1406
new 0 412 1406
put 2 412 1407
assign 1 413 1408
new 0 413 1408
assign 1 413 1409
new 0 413 1409
put 2 413 1410
assign 1 414 1411
new 0 414 1411
assign 1 414 1412
new 0 414 1412
put 2 414 1413
assign 1 415 1414
new 0 415 1414
assign 1 415 1415
new 0 415 1415
put 2 415 1416
assign 1 416 1417
new 0 416 1417
assign 1 416 1418
new 0 416 1418
put 2 416 1419
assign 1 417 1420
new 0 417 1420
assign 1 417 1421
new 0 417 1421
put 2 417 1422
assign 1 418 1423
new 0 418 1423
assign 1 418 1424
new 0 418 1424
put 2 418 1425
assign 1 419 1426
new 0 419 1426
assign 1 419 1427
new 0 419 1427
put 2 419 1428
assign 1 421 1430
new 2 421 1430
return 1 421 1431
return 1 0 1434
assign 1 0 1437
return 1 0 1441
assign 1 0 1444
return 1 0 1448
assign 1 0 1451
return 1 0 1455
assign 1 0 1458
return 1 0 1462
assign 1 0 1465
return 1 0 1469
assign 1 0 1472
return 1 0 1476
assign 1 0 1479
return 1 0 1483
assign 1 0 1486
return 1 0 1490
assign 1 0 1493
return 1 0 1497
assign 1 0 1500
return 1 0 1504
assign 1 0 1507
return 1 0 1511
assign 1 0 1514
return 1 0 1518
assign 1 0 1521
return 1 0 1525
assign 1 0 1528
return 1 0 1532
assign 1 0 1535
return 1 0 1539
assign 1 0 1542
return 1 0 1546
assign 1 0 1549
return 1 0 1553
assign 1 0 1556
return 1 0 1560
assign 1 0 1563
return 1 0 1567
assign 1 0 1570
return 1 0 1574
assign 1 0 1577
return 1 0 1581
assign 1 0 1584
return 1 0 1588
assign 1 0 1591
return 1 0 1595
assign 1 0 1598
return 1 0 1602
assign 1 0 1605
return 1 0 1609
assign 1 0 1612
return 1 0 1616
assign 1 0 1619
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 153365600: return bem_ptyMapGet_0();
case 1314364113: return bem_newMbrsGet_0();
case 2097069068: return bem_integratedGet_0();
case 1803479881: return bem_libNameGet_0();
case 287040793: return bem_hashGet_0();
case 1443447938: return bem_directMethodsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2033393684: return bem_ptyListGet_0();
case 842582618: return bem_isLocalGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 311680096: return bem_allNamesGet_0();
case 2058095605: return bem_signatureChangedGet_0();
case 1774940957: return bem_toString_0();
case 786424307: return bem_tagGet_0();
case 492006165: return bem_directPropertiesGet_0();
case 834964524: return bem_defMtdsGet_0();
case 1820417453: return bem_create_0();
case 1974592946: return bem_superListGet_0();
case 1760712968: return bem_signatureCheckedGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 363636983: return bem_isNotNullGet_0();
case 1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1012494862: return bem_once_0();
case 1631955979: return bem_foreignClassesGet_0();
case 1214937871: return bem_newMtdsGet_0();
case 795036897: return bem_fromFileGet_0();
case 845792839: return bem_iteratorGet_0();
case 71634217: return bem_iCheckedGet_0();
case 287367803: return bem_isFinalGet_0();
case 354142775: return bem_namepathGet_0();
case 202810500: return bem_depthGet_0();
case 1477961836: return bem_mtdListGet_0();
case 345555227: return bem_usesGet_0();
case 1308786538: return bem_echo_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 244359240: return bem_mtdMapGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case 986531569: return bem_allTypesGet_0();
case 481879936: return bem_hasDefaultGet_0();
case 1413594071: return bem_postLoad_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 68632810: return bem_superNpGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case 1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case 975449316: return bem_allTypesSet_1(bevd_0);
case 142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case 1749630715: return bem_signatureCheckedSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2085986815: return bem_integratedSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case 300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case 831500365: return bem_isLocalSet_1(bevd_0);
case 480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1963510693: return bem_superListSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1156342947: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case 1620873726: return bem_foreignClassesSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callHash) {
case 913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildClassSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildClassSyn.bevs_inst = (BEC_2_5_8_BuildClassSyn)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildClassSyn.bevs_inst;
}
}
}
