namespace be.BEL_4_Base {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_6_3_EncodeHex : BEC_6_6_SystemObject {
public BEC_6_3_EncodeHex() { }
static BEC_6_3_EncodeHex() { }
private static byte[] becc_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x65,0x78};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_0 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x68,0x65,0x78,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 26));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
public static new BEC_6_3_EncodeHex bevs_inst;
public override BEC_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_6_3_EncodeHex bem_default_0() {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_encode_1(BEC_4_6_TextString beva_str) {
BEC_4_6_TextString bevl_cur = null;
BEC_4_3_MathInt bevl_ssz = null;
BEC_4_6_TextString bevl_r = null;
BEC_4_3_MathInt bevl_pos = null;
BEC_4_3_MathInt bevl_ac = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_cur = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevl_ssz.bem_multiply_1(bevt_2_tmpvar_phold);
bevl_r = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
bevl_pos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 27 */ {
bevt_3_tmpvar_phold = bevl_pos.bem_lesser_1(bevl_ssz);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevl_ac = beva_str.bem_getCode_1(bevl_pos);
bevt_4_tmpvar_phold = bevl_ac.bem_toHexString_1(bevl_cur);
bevl_r.bem_addValue_1(bevt_4_tmpvar_phold);
bevl_pos = bevl_pos.bem_increment_0();
} /* Line: 27 */
 else  /* Line: 27 */ {
break;
} /* Line: 27 */
} /* Line: 27 */
return bevl_r;
} /*method end*/
public virtual BEC_4_6_TextString bem_decode_1(BEC_4_6_TextString beva_str) {
BEC_4_3_MathInt bevl_ssz = null;
BEC_4_6_TextString bevl_cur = null;
BEC_4_6_TextString bevl_r = null;
BEC_4_12_TextByteIterator bevl_tb = null;
BEC_4_6_TextString bevl_pta = null;
BEC_4_6_TextString bevl_ptb = null;
BEC_4_3_MathInt bevl_pos = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_6_9_SystemException bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = bevl_ssz.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 36 */ {
return beva_str;
} /* Line: 37 */
bevt_4_tmpvar_phold = bevo_2;
bevt_3_tmpvar_phold = bevl_ssz.bem_modulus_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_3;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_8_tmpvar_phold = bevo_4;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevl_ssz);
bevt_6_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_7_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 40 */
bevt_9_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_cur = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_9_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_5;
bevt_10_tmpvar_phold = bevl_ssz.bem_divide_1(bevt_11_tmpvar_phold);
bevl_r = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_10_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_6;
bevt_12_tmpvar_phold = bevl_ssz.bem_divide_1(bevt_13_tmpvar_phold);
bevl_r.bem_sizeSet_1(bevt_12_tmpvar_phold);
bevl_tb = (BEC_4_12_TextByteIterator) (new BEC_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_14_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_pta = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_ptb = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_15_tmpvar_phold);
bevl_pos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 49 */ {
bevt_16_tmpvar_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevl_tb.bem_next_1(bevl_pta);
bevl_tb.bem_next_1(bevl_ptb);
bevt_18_tmpvar_phold = bevl_pta.bem_add_1(bevl_ptb);
bevt_17_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpvar_phold);
bevl_r.bem_setCodeUnchecked_2(bevl_pos, bevt_17_tmpvar_phold);
bevl_pos = bevl_pos.bem_increment_0();
} /* Line: 53 */
 else  /* Line: 49 */ {
break;
} /* Line: 49 */
} /* Line: 49 */
return bevl_r;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {24, 24, 25, 26, 26, 26, 27, 27, 28, 29, 29, 27, 31, 35, 36, 36, 37, 39, 39, 39, 39, 40, 40, 40, 40, 42, 42, 43, 43, 43, 44, 44, 44, 45, 46, 46, 47, 47, 48, 49, 50, 51, 52, 52, 52, 53, 55};
public static new int[] bevs_smnlec
 = new int[] {36, 37, 38, 39, 40, 41, 42, 45, 47, 48, 49, 50, 56, 85, 86, 87, 89, 91, 92, 93, 94, 96, 97, 98, 99, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 117, 119, 120, 121, 122, 123, 124, 130};
/* BEGIN LINEINFO 
assign 1 24 36
new 0 24 36
assign 1 24 37
new 1 24 37
assign 1 25 38
sizeGet 0 25 38
assign 1 26 39
new 0 26 39
assign 1 26 40
multiply 1 26 40
assign 1 26 41
new 1 26 41
assign 1 27 42
new 0 27 42
assign 1 27 45
lesser 1 27 45
assign 1 28 47
getCode 1 28 47
assign 1 29 48
toHexString 1 29 48
addValue 1 29 49
assign 1 27 50
increment 0 27 50
return 1 31 56
assign 1 35 85
sizeGet 0 35 85
assign 1 36 86
new 0 36 86
assign 1 36 87
lesser 1 36 87
return 1 37 89
assign 1 39 91
new 0 39 91
assign 1 39 92
modulus 1 39 92
assign 1 39 93
new 0 39 93
assign 1 39 94
notEquals 1 39 94
assign 1 40 96
new 0 40 96
assign 1 40 97
add 1 40 97
assign 1 40 98
new 1 40 98
throw 1 40 99
assign 1 42 101
new 0 42 101
assign 1 42 102
new 1 42 102
assign 1 43 103
new 0 43 103
assign 1 43 104
divide 1 43 104
assign 1 43 105
new 1 43 105
assign 1 44 106
new 0 44 106
assign 1 44 107
divide 1 44 107
sizeSet 1 44 108
assign 1 45 109
new 1 45 109
assign 1 46 110
new 0 46 110
assign 1 46 111
new 1 46 111
assign 1 47 112
new 0 47 112
assign 1 47 113
new 1 47 113
assign 1 48 114
new 0 48 114
assign 1 49 117
hasNextGet 0 49 117
next 1 50 119
next 1 51 120
assign 1 52 121
add 1 52 121
assign 1 52 122
hexNew 1 52 122
setCodeUnchecked 2 52 123
assign 1 53 124
increment 0 53 124
return 1 55 130
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1711217736: return bem_encode_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 570808864: return bem_decode_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_3_EncodeHex();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_3_EncodeHex.bevs_inst = (BEC_6_3_EncodeHex)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_3_EncodeHex.bevs_inst;
}
}
}
