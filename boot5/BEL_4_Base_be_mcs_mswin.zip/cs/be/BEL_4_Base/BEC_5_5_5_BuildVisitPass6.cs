namespace be.BEL_4_Base {
/* IO:File: source/build/Pass6.be */
public class BEC_5_5_5_BuildVisitPass6 : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass6() { }
static BEC_5_5_5_BuildVisitPass6() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_0 = {0x2C};
private static byte[] bels_1 = {0x2C};
private static byte[] bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_4 = {0x5F};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
public static new BEC_5_5_5_BuildVisitPass6 bevs_inst;
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_nnode = null;
BEC_6_6_SystemObject bevl_gnext = null;
BEC_9_3_ContainerSet bevl_langs = null;
BEC_5_4_BuildNode bevl_lang = null;
BEC_6_6_SystemObject bevl_doit = null;
BEC_6_6_SystemObject bevl_si = null;
BEC_6_6_SystemObject bevl_snode = null;
BEC_6_6_SystemObject bevl_lnode = null;
BEC_6_6_SystemObject bevl_enode = null;
BEC_6_6_SystemObject bevl_brnode = null;
BEC_6_6_SystemObject bevl_inode = null;
BEC_6_6_SystemObject bevl_nxnode = null;
BEC_6_6_SystemObject bevl_parens = null;
BEC_6_6_SystemObject bevl_nd = null;
BEC_6_6_SystemObject bevl_toremove = null;
BEC_6_6_SystemObject bevl_numargs = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_ix = null;
BEC_6_6_SystemObject bevl_vid = null;
BEC_6_6_SystemObject bevl_vinp = null;
BEC_6_6_SystemObject bevl_s = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_38_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_5_4_BuildEmit bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_6_BuildIfEmit bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_85_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_92_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_97_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_4_3_MathInt bevt_109_tmpvar_phold = null;
BEC_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_138_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_144_tmpvar_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpvar_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpvar_phold == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_15_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_lengthGet_0();
bevt_16_tmpvar_phold = bevo_0;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_greater_1(bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevt_20_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_18_tmpvar_phold == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevt_25_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_firstGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 29 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevt_30_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_containedGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_lengthGet_0();
bevt_31_tmpvar_phold = bevo_1;
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_greater_1(bevt_31_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevl_langs = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_firstGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_0_tmpvar_loop = bevt_32_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 32 */ {
bevt_35_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 32 */ {
bevl_lang = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_36_tmpvar_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpvar_phold);
} /* Line: 34 */
 else  /* Line: 32 */ {
break;
} /* Line: 32 */
} /* Line: 32 */
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpvar_phold);
bevl_doit = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevl_doit != null && bevl_doit is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_doit).bevi_bool) /* Line: 38 */ {
bevl_doit = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_39_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 40 */ {
bevt_40_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 40 */ {
bevl_si = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_42_tmpvar_phold = bevl_si.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_43_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 42 */ {
bevt_44_tmpvar_phold = bevl_si.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_44_tmpvar_phold);
bevl_doit = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 46 */
} /* Line: 42 */
 else  /* Line: 40 */ {
break;
} /* Line: 40 */
} /* Line: 40 */
} /* Line: 40 */
bevt_45_tmpvar_phold = bevl_doit.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 50 */ {
beva_node.bem_delete_0();
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 52 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = (BEC_5_4_BuildEmit) (new BEC_5_4_BuildEmit()).bem_new_2((BEC_4_6_TextString) bevt_47_tmpvar_phold, bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpvar_phold);
} /* Line: 55 */
 else  /* Line: 56 */ {
beva_node.bem_delete_0();
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 58 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpvar_phold = bevl_snode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_50_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_50_tmpvar_phold);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 62 */ {
bevl_snode = null;
} /* Line: 63 */
if (bevl_snode == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 66 */ {
beva_node.bem_delete_0();
bevt_52_tmpvar_phold = bevl_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_52_tmpvar_phold.bemd_1(406676794, BEL_4_Base.bevn_addEmit_1, beva_node);
} /* Line: 68 */
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 71 */
 else  /* Line: 27 */ {
bevt_54_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_equals_1(bevt_55_tmpvar_phold);
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 72 */ {
bevl_langs = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_firstGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpvar_loop = bevt_56_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 75 */ {
bevt_59_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevl_lang = (BEC_5_4_BuildNode) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_60_tmpvar_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpvar_phold);
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lang);
} /* Line: 78 */
 else  /* Line: 75 */ {
break;
} /* Line: 75 */
} /* Line: 75 */
bevt_61_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_1));
bevl_langs.bem_delete_1(bevt_61_tmpvar_phold);
bevt_63_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_62_tmpvar_phold = (BEC_5_6_BuildIfEmit) (new BEC_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_4_6_TextString) bevt_63_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_62_tmpvar_phold);
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 82 */ {
bevt_64_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_64_tmpvar_phold != null && bevt_64_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_64_tmpvar_phold).bevi_bool) /* Line: 82 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 84 */
 else  /* Line: 82 */ {
break;
} /* Line: 82 */
} /* Line: 82 */
} /* Line: 82 */
 else  /* Line: 27 */ {
bevt_66_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_equals_1(bevt_67_tmpvar_phold);
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 86 */ {
if (bevl_nnode == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 89 */ {
if (bevl_nnode == null) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 89 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 89 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 89 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 89 */
 else  /* Line: 89 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 89 */ {
bevl_enode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_73_tmpvar_phold);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_brnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_74_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_74_tmpvar_phold);
bevl_inode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_75_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_75_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevt_77_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_78_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = bevt_78_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 102 */ {
bevt_79_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 102 */ {
bevt_80_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_80_tmpvar_phold);
} /* Line: 103 */
 else  /* Line: 102 */ {
break;
} /* Line: 102 */
} /* Line: 102 */
} /* Line: 102 */
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_nnode = bevl_nxnode;
} /* Line: 114 */
 else  /* Line: 89 */ {
break;
} /* Line: 89 */
} /* Line: 89 */
if (bevl_nnode == null) {
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_83_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_84_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 116 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
 else  /* Line: 116 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nnode);
} /* Line: 118 */
} /* Line: 116 */
bevt_85_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpvar_phold;
} /* Line: 121 */
 else  /* Line: 27 */ {
bevt_87_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bem_equals_1(bevt_88_tmpvar_phold);
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 122 */ {
bevt_89_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpvar_phold.bem_firstGet_0();
bevl_nd = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_90_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_2));
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_91_tmpvar_phold);
bevl_parens.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_nd);
bevl_toremove = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_4_3_MathInt(0));
bevt_92_tmpvar_phold = bevl_parens.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_92_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 131 */ {
bevt_93_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_93_tmpvar_phold != null && bevt_93_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_93_tmpvar_phold).bevi_bool) /* Line: 131 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_ix = bevl_i.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_95_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_96_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpvar_phold = bevt_95_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_96_tmpvar_phold);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 137 */
 else  /* Line: 136 */ {
bevt_98_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_99_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_99_tmpvar_phold);
if (bevt_97_tmpvar_phold != null && bevt_97_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_97_tmpvar_phold).bevi_bool) /* Line: 138 */ {
bevt_100_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_100_tmpvar_phold);
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_101_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_102_tmpvar_phold);
bevl_i.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
bevt_103_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_103_tmpvar_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
} /* Line: 145 */
 else  /* Line: 136 */ {
bevt_105_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_106_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_106_tmpvar_phold);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 146 */ {
bevt_108_tmpvar_phold = bevl_ix.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_109_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_109_tmpvar_phold);
if (bevt_107_tmpvar_phold != null && bevt_107_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_107_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevt_110_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_110_tmpvar_phold);
bevt_111_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_112_tmpvar_phold = bevl_ix.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_111_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_114_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_113_tmpvar_phold.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_114_tmpvar_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevt_115_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpvar_phold);
} /* Line: 152 */
 else  /* Line: 153 */ {
bevt_117_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_3));
bevt_116_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpvar_phold, bevl_i);
throw new be.BELS_Base.BECS_ThrowBack(bevt_116_tmpvar_phold);
} /* Line: 154 */
} /* Line: 147 */
} /* Line: 136 */
} /* Line: 136 */
} /* Line: 136 */
 else  /* Line: 131 */ {
break;
} /* Line: 131 */
} /* Line: 131 */
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 158 */ {
bevt_118_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_118_tmpvar_phold != null && bevt_118_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_118_tmpvar_phold).bevi_bool) /* Line: 158 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 160 */
 else  /* Line: 158 */ {
break;
} /* Line: 158 */
} /* Line: 158 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_119_tmpvar_phold = bevl_numargs.bemd_1(81310150, BEL_4_Base.bevn_subtract_1, bevt_120_tmpvar_phold);
bevl_s.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_119_tmpvar_phold);
bevt_121_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_s.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_121_tmpvar_phold);
bevt_124_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_125_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_4));
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_125_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_s.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_126_tmpvar_phold);
bevl_s.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_122_tmpvar_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_130_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_130_tmpvar_phold);
if (bevt_128_tmpvar_phold != null && bevt_128_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_128_tmpvar_phold).bevi_bool) /* Line: 167 */ {
bevl_i.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_131_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_s.bemd_1(419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_131_tmpvar_phold);
bevt_135_tmpvar_phold = bevl_s.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_136_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_5));
bevt_132_tmpvar_phold = bevt_133_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_132_tmpvar_phold != null && bevt_132_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_132_tmpvar_phold).bevi_bool) /* Line: 171 */ {
bevt_137_tmpvar_phold = bevl_s.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_138_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_137_tmpvar_phold.bemd_1(524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_138_tmpvar_phold);
} /* Line: 172 */
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 174 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_140_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_139_tmpvar_phold = bevt_140_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_141_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_139_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_141_tmpvar_phold, beva_node);
bevt_143_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_142_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 178 */
} /* Line: 27 */
} /* Line: 27 */
} /* Line: 27 */
bevt_144_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_144_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 26, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 29, 0, 0, 0, 29, 29, 29, 29, 29, 0, 0, 0, 29, 29, 29, 29, 29, 29, 0, 0, 0, 29, 29, 29, 29, 29, 0, 0, 0, 31, 32, 32, 32, 32, 0, 32, 32, 34, 34, 36, 36, 37, 39, 40, 40, 40, 40, 41, 42, 42, 42, 43, 43, 46, 50, 51, 52, 54, 55, 55, 55, 57, 58, 61, 62, 62, 62, 63, 66, 66, 67, 68, 68, 71, 72, 72, 72, 73, 74, 75, 75, 75, 75, 0, 75, 75, 77, 77, 78, 80, 80, 81, 81, 81, 82, 82, 83, 84, 86, 86, 86, 87, 87, 88, 89, 89, 89, 89, 89, 0, 0, 0, 90, 91, 91, 92, 93, 94, 95, 95, 96, 97, 98, 98, 99, 100, 101, 101, 101, 102, 102, 102, 103, 103, 110, 111, 112, 113, 114, 116, 116, 116, 116, 116, 0, 0, 0, 117, 118, 121, 121, 122, 122, 122, 123, 123, 124, 125, 126, 126, 127, 127, 128, 129, 130, 131, 131, 131, 132, 133, 136, 136, 136, 137, 138, 138, 138, 139, 139, 140, 141, 141, 142, 142, 143, 144, 144, 145, 146, 146, 146, 147, 147, 147, 148, 148, 149, 149, 149, 150, 150, 150, 151, 152, 152, 154, 154, 154, 158, 158, 159, 160, 162, 163, 163, 163, 164, 164, 165, 165, 165, 165, 165, 165, 165, 166, 167, 167, 167, 168, 170, 170, 171, 171, 171, 171, 171, 172, 172, 172, 174, 176, 177, 177, 177, 177, 178, 178, 178, 180, 180};
public static new int[] bevs_smnlec
 = new int[] {187, 188, 189, 190, 191, 193, 194, 195, 200, 201, 202, 203, 204, 206, 209, 213, 216, 217, 218, 219, 224, 225, 228, 232, 235, 236, 237, 238, 239, 240, 242, 245, 249, 252, 253, 254, 255, 256, 258, 261, 265, 268, 269, 270, 271, 272, 272, 275, 277, 278, 279, 285, 286, 287, 289, 290, 291, 292, 295, 297, 298, 299, 300, 302, 303, 304, 312, 314, 315, 317, 318, 319, 320, 323, 324, 326, 327, 328, 329, 331, 333, 338, 339, 340, 341, 343, 346, 347, 348, 350, 351, 352, 353, 354, 355, 355, 358, 360, 361, 362, 363, 369, 370, 371, 372, 373, 374, 377, 379, 380, 388, 389, 390, 392, 397, 398, 401, 406, 407, 408, 409, 411, 414, 418, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 441, 442, 443, 446, 448, 449, 456, 457, 458, 459, 460, 466, 471, 472, 473, 474, 476, 479, 483, 486, 487, 490, 491, 494, 495, 496, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 513, 515, 516, 517, 518, 519, 521, 524, 525, 526, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 541, 542, 543, 545, 546, 547, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 562, 563, 564, 574, 577, 579, 580, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 604, 605, 606, 607, 608, 609, 610, 611, 613, 614, 615, 617, 619, 620, 621, 622, 623, 624, 625, 626, 631, 632};
/* BEGIN LINEINFO 
resolveNp 0 23 187
assign 1 26 188
nextPeerGet 0 26 188
assign 1 27 189
typenameGet 0 27 189
assign 1 27 190
EMITGet 0 27 190
assign 1 27 191
equals 1 27 191
assign 1 28 193
nextAscendGet 0 28 193
assign 1 29 194
containedGet 0 29 194
assign 1 29 195
def 1 29 200
assign 1 29 201
containedGet 0 29 201
assign 1 29 202
lengthGet 0 29 202
assign 1 29 203
new 0 29 203
assign 1 29 204
greater 1 29 204
assign 1 0 206
assign 1 0 209
assign 1 0 213
assign 1 29 216
containedGet 0 29 216
assign 1 29 217
firstGet 0 29 217
assign 1 29 218
containedGet 0 29 218
assign 1 29 219
def 1 29 224
assign 1 0 225
assign 1 0 228
assign 1 0 232
assign 1 29 235
containedGet 0 29 235
assign 1 29 236
firstGet 0 29 236
assign 1 29 237
containedGet 0 29 237
assign 1 29 238
lengthGet 0 29 238
assign 1 29 239
new 0 29 239
assign 1 29 240
greater 1 29 240
assign 1 0 242
assign 1 0 245
assign 1 0 249
assign 1 29 252
secondGet 0 29 252
assign 1 29 253
containedGet 0 29 253
assign 1 29 254
lengthGet 0 29 254
assign 1 29 255
new 0 29 255
assign 1 29 256
greater 1 29 256
assign 1 0 258
assign 1 0 261
assign 1 0 265
assign 1 31 268
new 0 31 268
assign 1 32 269
containedGet 0 32 269
assign 1 32 270
firstGet 0 32 270
assign 1 32 271
containedGet 0 32 271
assign 1 32 272
iteratorGet 0 0 272
assign 1 32 275
hasNextGet 0 32 275
assign 1 32 277
nextGet 0 32 277
assign 1 34 278
heldGet 0 34 278
addValue 1 34 279
assign 1 36 285
new 0 36 285
delete 1 36 286
assign 1 37 287
new 0 37 287
assign 1 39 289
new 0 39 289
assign 1 40 290
secondGet 0 40 290
assign 1 40 291
containedGet 0 40 291
assign 1 40 292
iteratorGet 0 40 292
assign 1 40 295
hasNextGet 0 40 295
assign 1 41 297
nextGet 0 41 297
assign 1 42 298
typenameGet 0 42 298
assign 1 42 299
STRINGLGet 0 42 299
assign 1 42 300
equals 1 42 300
assign 1 43 302
heldGet 0 43 302
heldSet 1 43 303
assign 1 46 304
new 0 46 304
assign 1 50 312
not 0 50 312
delete 0 51 314
return 1 52 315
containedSet 1 54 317
assign 1 55 318
heldGet 0 55 318
assign 1 55 319
new 2 55 319
heldSet 1 55 320
delete 0 57 323
return 1 58 324
assign 1 61 326
scopeGet 0 61 326
assign 1 62 327
typenameGet 0 62 327
assign 1 62 328
METHODGet 0 62 328
assign 1 62 329
equals 1 62 329
assign 1 63 331
assign 1 66 333
def 1 66 338
delete 0 67 339
assign 1 68 340
heldGet 0 68 340
addEmit 1 68 341
return 1 71 343
assign 1 72 346
typenameGet 0 72 346
assign 1 72 347
IFEMITGet 0 72 347
assign 1 72 348
equals 1 72 348
assign 1 73 350
new 0 73 350
assign 1 74 351
new 0 74 351
assign 1 75 352
containedGet 0 75 352
assign 1 75 353
firstGet 0 75 353
assign 1 75 354
containedGet 0 75 354
assign 1 75 355
iteratorGet 0 0 355
assign 1 75 358
hasNextGet 0 75 358
assign 1 75 360
nextGet 0 75 360
assign 1 77 361
heldGet 0 77 361
addValue 1 77 362
addValue 1 78 363
assign 1 80 369
new 0 80 369
delete 1 80 370
assign 1 81 371
heldGet 0 81 371
assign 1 81 372
new 2 81 372
heldSet 1 81 373
assign 1 82 374
iteratorGet 0 82 374
assign 1 82 377
hasNextGet 0 82 377
assign 1 83 379
nextGet 0 83 379
delete 0 84 380
assign 1 86 388
typenameGet 0 86 388
assign 1 86 389
IFGet 0 86 389
assign 1 86 390
equals 1 86 390
assign 1 87 392
def 1 87 397
assign 1 88 398
assign 1 89 401
def 1 89 406
assign 1 89 407
typenameGet 0 89 407
assign 1 89 408
ELIFGet 0 89 408
assign 1 89 409
equals 1 89 409
assign 1 0 411
assign 1 0 414
assign 1 0 418
assign 1 90 421
new 1 90 421
assign 1 91 422
ELSEGet 0 91 422
typenameSet 1 91 423
copyLoc 1 92 424
assign 1 93 425
new 1 93 425
copyLoc 1 94 426
assign 1 95 427
BRACESGet 0 95 427
typenameSet 1 95 428
assign 1 96 429
new 1 96 429
copyLoc 1 97 430
assign 1 98 431
IFGet 0 98 431
typenameSet 1 98 432
addValue 1 99 433
addValue 1 100 434
assign 1 101 435
containedGet 0 101 435
assign 1 101 436
def 1 101 441
assign 1 102 442
containedGet 0 102 442
assign 1 102 443
iteratorGet 0 102 443
assign 1 102 446
hasNextGet 0 102 446
assign 1 103 448
nextGet 0 103 448
addValue 1 103 449
addValue 1 110 456
assign 1 111 457
assign 1 112 458
nextPeerGet 0 112 458
delete 0 113 459
assign 1 114 460
assign 1 116 466
def 1 116 471
assign 1 116 472
typenameGet 0 116 472
assign 1 116 473
ELSEGet 0 116 473
assign 1 116 474
equals 1 116 474
assign 1 0 476
assign 1 0 479
assign 1 0 483
delete 0 117 486
addValue 1 118 487
assign 1 121 490
nextDescendGet 0 121 490
return 1 121 491
assign 1 122 494
typenameGet 0 122 494
assign 1 122 495
METHODGet 0 122 495
assign 1 122 496
equals 1 122 496
assign 1 123 498
containedGet 0 123 498
assign 1 123 499
firstGet 0 123 499
assign 1 124 500
new 1 124 500
copyLoc 1 125 501
assign 1 126 502
IDGet 0 126 502
typenameSet 1 126 503
assign 1 127 504
new 0 127 504
heldSet 1 127 505
prepend 1 128 506
assign 1 129 507
new 0 129 507
assign 1 130 508
new 0 130 508
assign 1 131 509
containedGet 0 131 509
assign 1 131 510
iteratorGet 0 131 510
assign 1 131 513
hasNextGet 0 131 513
assign 1 132 515
nextGet 0 132 515
assign 1 133 516
nextPeerGet 0 133 516
assign 1 136 517
typenameGet 0 136 517
assign 1 136 518
COMMAGet 0 136 518
assign 1 136 519
equals 1 136 519
addValue 1 137 521
assign 1 138 524
typenameGet 0 138 524
assign 1 138 525
IDGet 0 138 525
assign 1 138 526
equals 1 138 526
assign 1 139 528
new 0 139 528
assign 1 139 529
add 1 139 529
assign 1 140 530
new 0 140 530
assign 1 141 531
heldGet 0 141 531
nameSet 1 141 532
assign 1 142 533
new 0 142 533
isArgSet 1 142 534
heldSet 1 143 535
assign 1 144 536
VARGet 0 144 536
typenameSet 1 144 537
addVariable 0 145 538
assign 1 146 541
typenameGet 0 146 541
assign 1 146 542
VARGet 0 146 542
assign 1 146 543
equals 1 146 543
assign 1 147 545
typenameGet 0 147 545
assign 1 147 546
IDGet 0 147 546
assign 1 147 547
equals 1 147 547
assign 1 148 549
new 0 148 549
assign 1 148 550
add 1 148 550
assign 1 149 551
heldGet 0 149 551
assign 1 149 552
heldGet 0 149 552
nameSet 1 149 553
assign 1 150 554
heldGet 0 150 554
assign 1 150 555
new 0 150 555
isArgSet 1 150 556
addVariable 0 151 557
assign 1 152 558
COMMAGet 0 152 558
typenameSet 1 152 559
assign 1 154 562
new 0 154 562
assign 1 154 563
new 2 154 563
throw 1 154 564
assign 1 158 574
iteratorGet 0 158 574
assign 1 158 577
hasNextGet 0 158 577
assign 1 159 579
nextGet 0 159 579
delete 0 160 580
assign 1 162 586
heldGet 0 162 586
assign 1 163 587
new 0 163 587
assign 1 163 588
subtract 1 163 588
numargsSet 1 163 589
assign 1 164 590
nameGet 0 164 590
orgNameSet 1 164 591
assign 1 165 592
nameGet 0 165 592
assign 1 165 593
new 0 165 593
assign 1 165 594
add 1 165 594
assign 1 165 595
numargsGet 0 165 595
assign 1 165 596
toString 0 165 596
assign 1 165 597
add 1 165 597
nameSet 1 165 598
assign 1 166 599
secondGet 0 166 599
assign 1 167 600
typenameGet 0 167 600
assign 1 167 601
VARGet 0 167 601
assign 1 167 602
equals 1 167 602
resolveNp 0 168 604
assign 1 170 605
heldGet 0 170 605
rtypeSet 1 170 606
assign 1 171 607
rtypeGet 0 171 607
assign 1 171 608
namepathGet 0 171 608
assign 1 171 609
toString 0 171 609
assign 1 171 610
new 0 171 610
assign 1 171 611
equals 1 171 611
assign 1 172 613
rtypeGet 0 172 613
assign 1 172 614
new 0 172 614
isSelfSet 1 172 615
delete 0 174 617
assign 1 176 619
classGet 0 176 619
assign 1 177 620
heldGet 0 177 620
assign 1 177 621
methodsGet 0 177 621
assign 1 177 622
nameGet 0 177 622
put 2 177 623
assign 1 178 624
heldGet 0 178 624
assign 1 178 625
orderedMethodsGet 0 178 625
addValue 1 178 626
assign 1 180 631
nextDescendGet 0 180 631
return 1 180 632
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_5_BuildVisitPass6();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_5_BuildVisitPass6.bevs_inst = (BEC_5_5_5_BuildVisitPass6)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_5_BuildVisitPass6.bevs_inst;
}
}
}
