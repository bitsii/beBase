namespace be.BEL_4_Base {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6A,0x73};
private static byte[] bels_1 = {0x2E,0x6A,0x73};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bels_7 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_8 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bels_11 = {0x29,0x20,0x7B};
private static byte[] bels_12 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 41));
private static byte[] bels_13 = {0x29,0x29};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bels_15 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_18 = {0x28,0x29,0x3B};
private static byte[] bels_19 = {0x7D};
private static byte[] bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bels_21 = {0x2C,0x20};
private static byte[] bels_22 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_23 = {0x5D,0x3B};
private static byte[] bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bels_25 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_26 = {0x7D};
private static byte[] bels_27 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_28 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_29 = {0x3B};
private static byte[] bels_30 = {0x7D};
private static byte[] bels_31 = {0x5D,0x3B};
private static byte[] bels_32 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_34 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_35 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bels_36 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x28,0x29};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_37, 2));
private static byte[] bels_38 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_39 = {0x29,0x3B};
private static byte[] bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_41 = {0x29,0x3B};
private static byte[] bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_43 = {0x2C,0x20};
private static byte[] bels_44 = {0x29,0x3B};
private static byte[] bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_46 = {0x2C,0x20};
private static byte[] bels_47 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bels_51 = {};
private static byte[] bels_52 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_53 = {0x28,0x29,0x3B};
private static byte[] bels_54 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bels_55 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_56 = {0x22,0x3B};
private static byte[] bels_57 = {};
private static byte[] bels_58 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_59 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_60 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_60, 62));
private static byte[] bels_61 = {0x76,0x61,0x72,0x20};
private static byte[] bels_62 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bels_63 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_63, 25));
private static byte[] bels_64 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_64, 2));
private static byte[] bels_65 = {0x74,0x68,0x69,0x73};
private static byte[] bels_66 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_66, 17));
private static byte[] bels_67 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_67, 3));
private static byte[] bels_68 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_68, 38));
private static byte[] bels_69 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_69, 4));
private static byte[] bels_70 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_70, 21));
private static byte[] bels_71 = {0x29};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_71, 1));
private static byte[] bels_72 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_72, 4));
private static byte[] bels_73 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_73, 23));
private static byte[] bels_74 = {0x29};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_74, 1));
private static byte[] bels_75 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_75, 4));
private static byte[] bels_76 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_76, 27));
private static byte[] bels_77 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_77, 22));
private static byte[] bels_78 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_78, 2));
private static byte[] bels_79 = {0x29};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_79, 1));
private static byte[] bels_80 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 4));
private static byte[] bels_81 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 32));
private static byte[] bels_82 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_82, 22));
private static byte[] bels_83 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_83, 2));
private static byte[] bels_84 = {0x29};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_84, 1));
private static byte[] bels_85 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_86 = {0x76,0x61,0x72,0x20};
private static byte[] bels_87 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_88 = {0x7D};
private static byte[] bels_89 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_89, 5));
private static byte[] bels_90 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {};
private static byte[] bels_92 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_92, 11));
private static byte[] bels_93 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_93, 5));
private static byte[] bels_94 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_94, 3));
private static byte[] bels_95 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_95, 11));
private static byte[] bels_96 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 4));
private static byte[] bels_97 = {0x3B};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 1));
private static byte[] bels_98 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_99 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_100 = {};
private static byte[] bels_101 = {};
private static byte[] bels_102 = {};
private static byte[] bels_103 = {};
private static byte[] bels_104 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_105 = {};
private static byte[] bels_106 = {};
private static byte[] bels_107 = {};
private static byte[] bels_108 = {};
private static byte[] bels_109 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_109, 7));
private static byte[] bels_110 = {0x3A,0x20};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_110, 2));
private static byte[] bels_111 = {};
private static byte[] bels_112 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_113 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_113, 22));
private static byte[] bels_114 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_114, 5));
private static byte[] bels_115 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_116 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bels_117 = {0x29,0x20,0x7B};
private static byte[] bels_118 = {};
private static byte[] bels_119 = {0x5F};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_119, 1));
private static byte[] bels_120 = {0x62,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_120, 3));
public static new BEC_2_5_9_BuildJSEmitter bevs_inst;
public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_6_6_SystemObject bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(44, bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(45, bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_6));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bels_7));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_8));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpvar_phold.bem_add_1(bevt_1_tmpvar_phold);
bevp_methodCatch = bevp_methodCatch.bem_increment_0();
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_10));
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_11));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_firstGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpvar_phold = bevo_1;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_8_tmpvar_phold, bevt_12_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_2_4_6_TextString beva_belsBase) {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bels_14));
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_15));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bels_16));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_17));
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_relEmitName_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_18));
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_19));
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_14_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bels_20));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 70 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 70 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 71 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 72 */
 else  /* Line: 73 */ {
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_21));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 74 */
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_22));
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold.bem_addValue_1(bevp_q);
} /* Line: 76 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_23));
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_12_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bels_24));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_25));
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_26));
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bels_27));
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_28));
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) bevt_17_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_29));
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_30));
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
this.bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_31));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_2_tmpvar_phold = bevo_3;
bevt_3_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /* Line: 121 */
bevt_4_tmpvar_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_typeInstances = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_107_tmpvar_phold = null;
bevl_libe = this.bem_getLibOutput_0();
bevl_typeInstances = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 135 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 135 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bels_33));
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_12_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_34));
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_17_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_relEmitName_1(bevt_18_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_35));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevt_24_tmpvar_phold = bevo_4;
bevt_28_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpvar_phold);
bevt_29_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_relEmitName_1(bevt_29_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_30_tmpvar_phold = bevo_5;
bevl_nc = bevt_23_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(75, bels_38));
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_2_4_6_TextString) bevt_33_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_39));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 150 */ {
bevt_42_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bels_40));
bevt_41_tmpvar_phold = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) bevt_41_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_41));
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) bevt_40_tmpvar_phold.bem_addValue_1(bevt_43_tmpvar_phold);
bevt_39_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 151 */
} /* Line: 150 */
} /* Line: 141 */
 else  /* Line: 135 */ {
break;
} /* Line: 135 */
} /* Line: 135 */
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpvar_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpvar_loop = bevt_44_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 159 */ {
bevt_45_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 159 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bels_42));
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bem_quoteGet_0();
bevt_51_tmpvar_phold = (BEC_2_4_6_TextString) bevt_52_tmpvar_phold.bem_addValue_1(bevt_54_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_quoteGet_0();
bevt_49_tmpvar_phold = (BEC_2_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_58_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_43));
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) bevt_48_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_44));
bevt_46_tmpvar_phold = (BEC_2_4_6_TextString) bevt_47_tmpvar_phold.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_46_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(53, bels_45));
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_quoteGet_0();
bevt_66_tmpvar_phold = (BEC_2_4_6_TextString) bevt_67_tmpvar_phold.bem_addValue_1(bevt_69_tmpvar_phold);
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) bevt_66_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bem_quoteGet_0();
bevt_64_tmpvar_phold = (BEC_2_4_6_TextString) bevt_65_tmpvar_phold.bem_addValue_1(bevt_71_tmpvar_phold);
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_46));
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) bevt_64_tmpvar_phold.bem_addValue_1(bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) bevt_63_tmpvar_phold.bem_addValue_1(bevt_74_tmpvar_phold);
bevt_75_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_47));
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) bevt_62_tmpvar_phold.bem_addValue_1(bevt_75_tmpvar_phold);
bevt_61_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 162 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_78_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bem_sizeGet_0();
bevt_79_tmpvar_phold = bevo_6;
if (bevt_77_tmpvar_phold.bevi_int == bevt_79_tmpvar_phold.bevi_int) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(112, bels_48));
bevt_80_tmpvar_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_81_tmpvar_phold);
bevt_80_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(114, bels_49));
bevt_82_tmpvar_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_83_tmpvar_phold);
bevt_82_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(99, bels_50));
bevt_84_tmpvar_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_85_tmpvar_phold);
bevt_84_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 174 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_51));
bevt_90_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_52));
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) bevt_89_tmpvar_phold.bem_addValue_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_53));
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) bevt_88_tmpvar_phold.bem_addValue_1(bevt_92_tmpvar_phold);
bevt_87_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpvar_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 187 */ {
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bels_54));
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_95_tmpvar_phold);
bevt_94_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 188 */
bevt_99_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bels_55));
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_99_tmpvar_phold);
bevt_101_tmpvar_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) bevt_98_tmpvar_phold.bem_addValue_1(bevt_100_tmpvar_phold);
bevt_102_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_56));
bevt_96_tmpvar_phold = (BEC_2_4_6_TextString) bevt_97_tmpvar_phold.bem_addValue_1(bevt_102_tmpvar_phold);
bevt_96_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_57));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpvar_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_105_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_58));
bevt_104_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_tmpvar_phold);
bevt_104_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_59));
bevt_106_tmpvar_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_107_tmpvar_phold);
bevt_106_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 198 */
bevl_libe.bem_write_1(bevl_main);
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_procStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 211 */ {
} /* Line: 211 */
 else  /* Line: 213 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_61));
beva_b.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 215 */
bevt_4_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 217 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_62));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpvar_phold = bevo_9;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_65));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_parent);
bevt_5_tmpvar_phold = bevo_11;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevl_extstr.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_12;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_13;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_14;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_15;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_17;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 249 */ {
bevt_8_tmpvar_phold = bevo_19;
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_20;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_21;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_14_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_15_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 250 */
bevt_24_tmpvar_phold = bevo_24;
bevt_26_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_25;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_26;
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(beva_belsName);
bevt_30_tmpvar_phold = bevo_27;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(beva_lisz);
bevt_31_tmpvar_phold = bevo_28;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
return bevt_16_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_2_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 257 */
 else  /* Line: 258 */ {
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bels_85));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 259 */
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_86));
bevt_6_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_87));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_88));
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitNameForCall_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1796577138, BEL_4_Base.bevn_superCallGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 275 */ {
bevt_3_tmpvar_phold = bevo_29;
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 276 */
bevt_7_tmpvar_phold = bevo_30;
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
return bevt_6_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_91));
bevt_0_tmpvar_loop = bevp_superCalls.bem_iteratorGet_0();
while (true)
 /* Line: 283 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 283 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpvar_phold = bevo_31;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_32;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevo_33;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_34;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_35;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_22_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 284 */
 else  /* Line: 283 */ {
break;
} /* Line: 283 */
} /* Line: 283 */
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 294 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpvar_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getLibOutput_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 310 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_fileGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_existsGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 312 */ {
bevt_7_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold.bem_makeDirs_0();
} /* Line: 313 */
bevt_9_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevt_11_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_98));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_has_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 317 */ {
bevt_14_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_99));
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_get_1(bevt_15_tmpvar_phold);
bevt_0_tmpvar_loop = bevt_13_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 318 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 318 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpvar_phold.bem_fileGet_0();
bevt_19_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_20_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_21_tmpvar_phold = this.bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpvar_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 323 */
 else  /* Line: 318 */ {
break;
} /* Line: 318 */
} /* Line: 318 */
} /* Line: 318 */
} /* Line: 317 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_100));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_101));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_102));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_103));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_104));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_105));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_106));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_107));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_108));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_37;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_varName);
bevt_4_tmpvar_phold = bevo_38;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_typeName);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_varName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_111));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_112));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_2_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_39;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_40;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_115));
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_116));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_117));
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_1(BEC_2_5_11_BuildClassConfig beva_cc) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_118));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_41;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_42;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_6_6_SystemObject bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 21, 22, 26, 28, 29, 31, 32, 36, 36, 36, 36, 36, 36, 36, 36, 40, 40, 40, 41, 42, 42, 42, 42, 42, 42, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 52, 52, 52, 52, 52, 52, 52, 56, 56, 56, 56, 56, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 59, 59, 59, 64, 64, 65, 67, 67, 67, 67, 69, 70, 0, 70, 70, 72, 74, 74, 76, 76, 76, 76, 76, 76, 80, 80, 80, 85, 85, 85, 86, 88, 88, 88, 88, 88, 91, 91, 91, 91, 93, 93, 93, 95, 95, 95, 95, 95, 98, 98, 98, 98, 98, 98, 100, 100, 100, 102, 107, 108, 109, 115, 115, 115, 120, 121, 121, 121, 121, 123, 123, 129, 131, 132, 133, 134, 135, 135, 137, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 139, 141, 141, 141, 143, 143, 143, 143, 143, 143, 143, 143, 143, 149, 149, 149, 149, 149, 149, 150, 150, 150, 151, 151, 151, 151, 151, 151, 157, 159, 159, 0, 159, 159, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 161, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 166, 168, 171, 171, 171, 171, 171, 172, 172, 172, 173, 173, 173, 174, 174, 174, 177, 178, 181, 182, 182, 183, 185, 186, 186, 186, 186, 186, 186, 186, 187, 188, 188, 188, 190, 190, 190, 190, 190, 190, 190, 190, 192, 193, 194, 195, 196, 197, 197, 197, 198, 198, 198, 200, 202, 207, 207, 207, 211, 214, 214, 214, 215, 215, 217, 217, 222, 222, 226, 226, 226, 226, 226, 226, 230, 230, 235, 235, 235, 235, 235, 235, 235, 236, 236, 236, 236, 236, 237, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 256, 256, 257, 257, 257, 259, 259, 261, 261, 261, 261, 261, 269, 269, 269, 270, 271, 275, 275, 276, 276, 276, 276, 276, 278, 278, 278, 278, 278, 282, 283, 0, 283, 283, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 284, 286, 293, 293, 294, 296, 297, 297, 302, 302, 310, 310, 311, 312, 312, 312, 312, 312, 313, 313, 313, 315, 315, 315, 317, 317, 317, 318, 318, 318, 318, 0, 318, 318, 319, 319, 320, 320, 320, 321, 321, 322, 322, 323, 329, 333, 334, 339, 339, 343, 343, 347, 347, 351, 351, 355, 355, 359, 359, 363, 363, 368, 368, 373, 373, 377, 377, 377, 377, 377, 377, 381, 381, 385, 385, 385, 385, 385, 390, 390, 390, 390, 390, 390, 390, 395, 395, 395, 395, 395, 395, 395, 397, 399, 399, 399, 404, 404, 408, 408, 412, 412, 412, 412, 416, 416, 416, 416, 420, 421, 421, 422, 426, 427, 427, 428, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {176, 177, 178, 179, 180, 181, 182, 183, 194, 195, 196, 197, 198, 199, 200, 201, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 254, 255, 256, 257, 258, 259, 260, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 320, 321, 322, 323, 324, 325, 326, 327, 328, 328, 331, 333, 335, 338, 339, 341, 342, 343, 344, 345, 346, 352, 353, 354, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 417, 418, 419, 425, 426, 427, 436, 438, 439, 440, 441, 443, 444, 568, 569, 570, 571, 572, 573, 576, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 621, 622, 623, 624, 625, 626, 634, 635, 636, 636, 639, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 679, 680, 681, 682, 683, 684, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 716, 717, 718, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 734, 735, 736, 737, 738, 739, 741, 742, 748, 749, 750, 758, 762, 763, 768, 769, 770, 772, 773, 779, 780, 788, 789, 790, 791, 792, 793, 797, 798, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 959, 964, 965, 966, 967, 970, 971, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 995, 996, 998, 999, 1000, 1001, 1002, 1004, 1005, 1006, 1007, 1008, 1037, 1038, 1038, 1041, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1072, 1077, 1082, 1083, 1085, 1086, 1087, 1091, 1092, 1123, 1128, 1129, 1130, 1131, 1132, 1133, 1138, 1139, 1140, 1141, 1143, 1144, 1145, 1146, 1147, 1148, 1150, 1151, 1152, 1153, 1153, 1156, 1158, 1159, 1160, 1161, 1162, 1163, 1164, 1165, 1166, 1167, 1168, 1176, 1179, 1180, 1185, 1186, 1190, 1191, 1195, 1196, 1200, 1201, 1205, 1206, 1210, 1211, 1215, 1216, 1220, 1221, 1225, 1226, 1234, 1235, 1236, 1237, 1238, 1239, 1243, 1244, 1251, 1252, 1253, 1254, 1255, 1264, 1265, 1266, 1267, 1268, 1269, 1270, 1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1296, 1297, 1301, 1302, 1308, 1309, 1310, 1311, 1317, 1318, 1319, 1320, 1325, 1326, 1327, 1328, 1333, 1334, 1335, 1336, 1339, 1342, 1346, 1349};
/* BEGIN LINEINFO 
assign 1 20 176
new 0 20 176
assign 1 21 177
new 0 21 177
assign 1 22 178
new 0 22 178
new 1 26 179
assign 1 28 180
new 0 28 180
assign 1 29 181
new 0 29 181
assign 1 31 182
new 0 31 182
assign 1 32 183
new 0 32 183
assign 1 36 194
new 0 36 194
assign 1 36 195
addValue 1 36 195
assign 1 36 196
secondGet 0 36 196
assign 1 36 197
formTarg 1 36 197
assign 1 36 198
addValue 1 36 198
assign 1 36 199
new 0 36 199
assign 1 36 200
addValue 1 36 200
addValue 1 36 201
assign 1 40 222
new 0 40 222
assign 1 40 223
toString 0 40 223
assign 1 40 224
add 1 40 224
assign 1 41 225
increment 0 41 225
assign 1 42 226
new 0 42 226
assign 1 42 227
addValue 1 42 227
assign 1 42 228
addValue 1 42 228
assign 1 42 229
new 0 42 229
assign 1 42 230
addValue 1 42 230
addValue 1 42 231
assign 1 44 232
containedGet 0 44 232
assign 1 44 233
firstGet 0 44 233
assign 1 44 234
containedGet 0 44 234
assign 1 44 235
firstGet 0 44 235
assign 1 44 236
new 0 44 236
assign 1 44 237
add 1 44 237
assign 1 44 238
new 0 44 238
assign 1 44 239
add 1 44 239
assign 1 44 240
finalAssign 3 44 240
addValue 1 44 241
assign 1 52 254
emitNameGet 0 52 254
assign 1 52 255
addValue 1 52 255
assign 1 52 256
new 0 52 256
assign 1 52 257
addValue 1 52 257
assign 1 52 258
addValue 1 52 258
assign 1 52 259
new 0 52 259
addValue 1 52 260
assign 1 56 280
emitNameGet 0 56 280
assign 1 56 281
addValue 1 56 281
assign 1 56 282
new 0 56 282
assign 1 56 283
addValue 1 56 283
addValue 1 56 284
assign 1 57 285
new 0 57 285
assign 1 57 286
addValue 1 57 286
assign 1 57 287
heldGet 0 57 287
assign 1 57 288
namepathGet 0 57 288
assign 1 57 289
getClassConfig 1 57 289
assign 1 57 290
libNameGet 0 57 290
assign 1 57 291
relEmitName 1 57 291
assign 1 57 292
addValue 1 57 292
assign 1 57 293
new 0 57 293
assign 1 57 294
addValue 1 57 294
addValue 1 57 295
assign 1 59 296
new 0 59 296
assign 1 59 297
addValue 1 59 297
addValue 1 59 298
assign 1 64 320
heldGet 0 64 320
assign 1 64 321
synGet 0 64 321
assign 1 65 322
ptyListGet 0 65 322
assign 1 67 323
emitNameGet 0 67 323
assign 1 67 324
addValue 1 67 324
assign 1 67 325
new 0 67 325
addValue 1 67 326
assign 1 69 327
new 0 69 327
assign 1 70 328
iteratorGet 0 0 328
assign 1 70 331
hasNextGet 0 70 331
assign 1 70 333
nextGet 0 70 333
assign 1 72 335
new 0 72 335
assign 1 74 338
new 0 74 338
addValue 1 74 339
assign 1 76 341
addValue 1 76 341
assign 1 76 342
new 0 76 342
assign 1 76 343
addValue 1 76 343
assign 1 76 344
nameGet 0 76 344
assign 1 76 345
addValue 1 76 345
addValue 1 76 346
assign 1 80 352
new 0 80 352
assign 1 80 353
addValue 1 80 353
addValue 1 80 354
assign 1 85 382
heldGet 0 85 382
assign 1 85 383
namepathGet 0 85 383
assign 1 85 384
getClassConfig 1 85 384
assign 1 86 385
getInitialInst 1 86 385
assign 1 88 386
emitNameGet 0 88 386
assign 1 88 387
addValue 1 88 387
assign 1 88 388
new 0 88 388
assign 1 88 389
addValue 1 88 389
addValue 1 88 390
assign 1 91 391
addValue 1 91 391
assign 1 91 392
new 0 91 392
assign 1 91 393
addValue 1 91 393
addValue 1 91 394
assign 1 93 395
new 0 93 395
assign 1 93 396
addValue 1 93 396
addValue 1 93 397
assign 1 95 398
emitNameGet 0 95 398
assign 1 95 399
addValue 1 95 399
assign 1 95 400
new 0 95 400
assign 1 95 401
addValue 1 95 401
addValue 1 95 402
assign 1 98 403
new 0 98 403
assign 1 98 404
addValue 1 98 404
assign 1 98 405
addValue 1 98 405
assign 1 98 406
new 0 98 406
assign 1 98 407
addValue 1 98 407
addValue 1 98 408
assign 1 100 409
new 0 100 409
assign 1 100 410
addValue 1 100 410
addValue 1 100 411
buildPropList 0 102 412
getCode 2 107 417
assign 1 108 418
toString 0 108 418
addValue 1 109 419
assign 1 115 425
new 0 115 425
assign 1 115 426
addValue 1 115 426
addValue 1 115 427
assign 1 120 436
isPropertyGet 0 120 436
assign 1 121 438
new 0 121 438
assign 1 121 439
nameGet 0 121 439
assign 1 121 440
add 1 121 440
return 1 121 441
assign 1 123 443
nameForVar 1 123 443
return 1 123 444
assign 1 129 568
getLibOutput 0 129 568
assign 1 131 569
new 0 131 569
assign 1 132 570
new 0 132 570
assign 1 133 571
new 0 133 571
assign 1 134 572
new 0 134 572
assign 1 135 573
iteratorGet 0 135 573
assign 1 135 576
hasNextGet 0 135 576
assign 1 137 578
nextGet 0 137 578
assign 1 139 579
new 0 139 579
assign 1 139 580
addValue 1 139 580
assign 1 139 581
addValue 1 139 581
assign 1 139 582
heldGet 0 139 582
assign 1 139 583
namepathGet 0 139 583
assign 1 139 584
toString 0 139 584
assign 1 139 585
addValue 1 139 585
assign 1 139 586
addValue 1 139 586
assign 1 139 587
new 0 139 587
assign 1 139 588
addValue 1 139 588
assign 1 139 589
heldGet 0 139 589
assign 1 139 590
namepathGet 0 139 590
assign 1 139 591
getClassConfig 1 139 591
assign 1 139 592
libNameGet 0 139 592
assign 1 139 593
relEmitName 1 139 593
assign 1 139 594
addValue 1 139 594
assign 1 139 595
new 0 139 595
assign 1 139 596
addValue 1 139 596
addValue 1 139 597
assign 1 141 598
heldGet 0 141 598
assign 1 141 599
synGet 0 141 599
assign 1 141 600
hasDefaultGet 0 141 600
assign 1 143 602
new 0 143 602
assign 1 143 603
heldGet 0 143 603
assign 1 143 604
namepathGet 0 143 604
assign 1 143 605
getClassConfig 1 143 605
assign 1 143 606
libNameGet 0 143 606
assign 1 143 607
relEmitName 1 143 607
assign 1 143 608
add 1 143 608
assign 1 143 609
new 0 143 609
assign 1 143 610
add 1 143 610
assign 1 149 611
new 0 149 611
assign 1 149 612
addValue 1 149 612
assign 1 149 613
addValue 1 149 613
assign 1 149 614
new 0 149 614
assign 1 149 615
addValue 1 149 615
addValue 1 149 616
assign 1 150 617
heldGet 0 150 617
assign 1 150 618
synGet 0 150 618
assign 1 150 619
hasDefaultGet 0 150 619
assign 1 151 621
new 0 151 621
assign 1 151 622
addValue 1 151 622
assign 1 151 623
addValue 1 151 623
assign 1 151 624
new 0 151 624
assign 1 151 625
addValue 1 151 625
addValue 1 151 626
assign 1 157 634
new 0 157 634
assign 1 159 635
keysGet 0 159 635
assign 1 159 636
iteratorGet 0 0 636
assign 1 159 639
hasNextGet 0 159 639
assign 1 159 641
nextGet 0 159 641
assign 1 161 642
new 0 161 642
assign 1 161 643
addValue 1 161 643
assign 1 161 644
new 0 161 644
assign 1 161 645
quoteGet 0 161 645
assign 1 161 646
addValue 1 161 646
assign 1 161 647
addValue 1 161 647
assign 1 161 648
new 0 161 648
assign 1 161 649
quoteGet 0 161 649
assign 1 161 650
addValue 1 161 650
assign 1 161 651
new 0 161 651
assign 1 161 652
addValue 1 161 652
assign 1 161 653
get 1 161 653
assign 1 161 654
addValue 1 161 654
assign 1 161 655
new 0 161 655
assign 1 161 656
addValue 1 161 656
addValue 1 161 657
assign 1 162 658
new 0 162 658
assign 1 162 659
addValue 1 162 659
assign 1 162 660
new 0 162 660
assign 1 162 661
quoteGet 0 162 661
assign 1 162 662
addValue 1 162 662
assign 1 162 663
addValue 1 162 663
assign 1 162 664
new 0 162 664
assign 1 162 665
quoteGet 0 162 665
assign 1 162 666
addValue 1 162 666
assign 1 162 667
new 0 162 667
assign 1 162 668
addValue 1 162 668
assign 1 162 669
get 1 162 669
assign 1 162 670
addValue 1 162 670
assign 1 162 671
new 0 162 671
assign 1 162 672
addValue 1 162 672
addValue 1 162 673
write 1 166 679
write 1 168 680
assign 1 171 681
usedLibrarysGet 0 171 681
assign 1 171 682
sizeGet 0 171 682
assign 1 171 683
new 0 171 683
assign 1 171 684
equals 1 171 689
assign 1 172 690
new 0 172 690
assign 1 172 691
addValue 1 172 691
addValue 1 172 692
assign 1 173 693
new 0 173 693
assign 1 173 694
addValue 1 173 694
addValue 1 173 695
assign 1 174 696
new 0 174 696
assign 1 174 697
addValue 1 174 697
addValue 1 174 698
write 1 177 700
write 1 178 701
assign 1 181 702
new 0 181 702
assign 1 182 703
mainNameGet 0 182 703
fromString 1 182 704
assign 1 183 705
getClassConfig 1 183 705
assign 1 185 706
new 0 185 706
assign 1 186 707
new 0 186 707
assign 1 186 708
addValue 1 186 708
assign 1 186 709
fullEmitNameGet 0 186 709
assign 1 186 710
addValue 1 186 710
assign 1 186 711
new 0 186 711
assign 1 186 712
addValue 1 186 712
addValue 1 186 713
assign 1 187 714
ownProcessGet 0 187 714
assign 1 188 716
new 0 188 716
assign 1 188 717
addValue 1 188 717
addValue 1 188 718
assign 1 190 720
new 0 190 720
assign 1 190 721
addValue 1 190 721
assign 1 190 722
outputPlatformGet 0 190 722
assign 1 190 723
nameGet 0 190 723
assign 1 190 724
addValue 1 190 724
assign 1 190 725
new 0 190 725
assign 1 190 726
addValue 1 190 726
addValue 1 190 727
write 1 192 728
assign 1 193 729
new 0 193 729
write 1 194 730
write 1 195 731
assign 1 196 732
ownProcessGet 0 196 732
assign 1 197 734
new 0 197 734
assign 1 197 735
addValue 1 197 735
addValue 1 197 736
assign 1 198 737
new 0 198 737
assign 1 198 738
addValue 1 198 738
addValue 1 198 739
write 1 200 741
finishLibOutput 1 202 742
assign 1 207 748
new 0 207 748
assign 1 207 749
add 1 207 749
return 1 207 750
assign 1 211 758
isPropertyGet 0 211 758
assign 1 214 762
isArgGet 0 214 762
assign 1 214 763
not 0 214 768
assign 1 215 769
new 0 215 769
addValue 1 215 770
assign 1 217 772
nameForVar 1 217 772
addValue 1 217 773
assign 1 222 779
new 0 222 779
return 1 222 780
assign 1 226 788
new 0 226 788
assign 1 226 789
add 1 226 789
assign 1 226 790
new 0 226 790
assign 1 226 791
add 1 226 791
assign 1 226 792
add 1 226 792
return 1 226 793
assign 1 230 797
new 0 230 797
return 1 230 798
assign 1 235 812
emitNameGet 0 235 812
assign 1 235 813
new 0 235 813
assign 1 235 814
add 1 235 814
assign 1 235 815
add 1 235 815
assign 1 235 816
new 0 235 816
assign 1 235 817
add 1 235 817
assign 1 235 818
addValue 1 235 818
assign 1 236 819
emitNameGet 0 236 819
assign 1 236 820
add 1 236 820
assign 1 236 821
new 0 236 821
assign 1 236 822
add 1 236 822
assign 1 236 823
addValue 1 236 823
return 1 237 824
assign 1 241 838
new 0 241 838
assign 1 241 839
libNameGet 0 241 839
assign 1 241 840
relEmitName 1 241 840
assign 1 241 841
add 1 241 841
assign 1 241 842
new 0 241 842
assign 1 241 843
add 1 241 843
assign 1 241 844
heldGet 0 241 844
assign 1 241 845
literalValueGet 0 241 845
assign 1 241 846
add 1 241 846
assign 1 241 847
new 0 241 847
assign 1 241 848
add 1 241 848
return 1 241 849
assign 1 245 863
new 0 245 863
assign 1 245 864
libNameGet 0 245 864
assign 1 245 865
relEmitName 1 245 865
assign 1 245 866
add 1 245 866
assign 1 245 867
new 0 245 867
assign 1 245 868
add 1 245 868
assign 1 245 869
heldGet 0 245 869
assign 1 245 870
literalValueGet 0 245 870
assign 1 245 871
add 1 245 871
assign 1 245 872
new 0 245 872
assign 1 245 873
add 1 245 873
return 1 245 874
assign 1 250 910
new 0 250 910
assign 1 250 911
libNameGet 0 250 911
assign 1 250 912
relEmitName 1 250 912
assign 1 250 913
add 1 250 913
assign 1 250 914
new 0 250 914
assign 1 250 915
add 1 250 915
assign 1 250 916
emitNameGet 0 250 916
assign 1 250 917
add 1 250 917
assign 1 250 918
new 0 250 918
assign 1 250 919
add 1 250 919
assign 1 250 920
add 1 250 920
assign 1 250 921
new 0 250 921
assign 1 250 922
add 1 250 922
assign 1 250 923
add 1 250 923
assign 1 250 924
new 0 250 924
assign 1 250 925
add 1 250 925
return 1 250 926
assign 1 252 928
new 0 252 928
assign 1 252 929
libNameGet 0 252 929
assign 1 252 930
relEmitName 1 252 930
assign 1 252 931
add 1 252 931
assign 1 252 932
new 0 252 932
assign 1 252 933
add 1 252 933
assign 1 252 934
emitNameGet 0 252 934
assign 1 252 935
add 1 252 935
assign 1 252 936
new 0 252 936
assign 1 252 937
add 1 252 937
assign 1 252 938
add 1 252 938
assign 1 252 939
new 0 252 939
assign 1 252 940
add 1 252 940
assign 1 252 941
add 1 252 941
assign 1 252 942
new 0 252 942
assign 1 252 943
add 1 252 943
return 1 252 944
assign 1 256 959
def 1 256 964
assign 1 257 965
libNameGet 0 257 965
assign 1 257 966
relEmitName 1 257 966
assign 1 257 967
extend 1 257 967
assign 1 259 970
new 0 259 970
assign 1 259 971
extend 1 259 971
assign 1 261 973
new 0 261 973
assign 1 261 974
emitNameGet 0 261 974
assign 1 261 975
addValue 1 261 975
assign 1 261 976
new 0 261 976
assign 1 261 977
addValue 1 261 977
assign 1 269 978
new 0 269 978
assign 1 269 979
addValue 1 269 979
addValue 1 269 980
addValue 1 270 981
return 1 271 982
assign 1 275 995
heldGet 0 275 995
assign 1 275 996
superCallGet 0 275 996
assign 1 276 998
new 0 276 998
assign 1 276 999
heldGet 0 276 999
assign 1 276 1000
nameGet 0 276 1000
assign 1 276 1001
add 1 276 1001
return 1 276 1002
assign 1 278 1004
new 0 278 1004
assign 1 278 1005
heldGet 0 278 1005
assign 1 278 1006
nameGet 0 278 1006
assign 1 278 1007
add 1 278 1007
return 1 278 1008
assign 1 282 1037
new 0 282 1037
assign 1 283 1038
iteratorGet 0 0 1038
assign 1 283 1041
hasNextGet 0 283 1041
assign 1 283 1043
nextGet 0 283 1043
assign 1 284 1044
emitNameGet 0 284 1044
assign 1 284 1045
new 0 284 1045
assign 1 284 1046
add 1 284 1046
assign 1 284 1047
new 0 284 1047
assign 1 284 1048
add 1 284 1048
assign 1 284 1049
heldGet 0 284 1049
assign 1 284 1050
nameGet 0 284 1050
assign 1 284 1051
add 1 284 1051
assign 1 284 1052
new 0 284 1052
assign 1 284 1053
add 1 284 1053
assign 1 284 1054
emitNameGet 0 284 1054
assign 1 284 1055
add 1 284 1055
assign 1 284 1056
new 0 284 1056
assign 1 284 1057
add 1 284 1057
assign 1 284 1058
new 0 284 1058
assign 1 284 1059
add 1 284 1059
assign 1 284 1060
heldGet 0 284 1060
assign 1 284 1061
nameGet 0 284 1061
assign 1 284 1062
add 1 284 1062
assign 1 284 1063
new 0 284 1063
assign 1 284 1064
add 1 284 1064
assign 1 284 1065
add 1 284 1065
addValue 1 284 1066
return 1 286 1072
assign 1 293 1077
undef 1 293 1082
assign 1 294 1083
new 0 294 1083
addValue 1 296 1085
assign 1 297 1086
new 0 297 1086
return 1 297 1087
assign 1 302 1091
getLibOutput 0 302 1091
return 1 302 1092
assign 1 310 1123
undef 1 310 1128
assign 1 311 1129
new 0 311 1129
assign 1 312 1130
parentGet 0 312 1130
assign 1 312 1131
fileGet 0 312 1131
assign 1 312 1132
existsGet 0 312 1132
assign 1 312 1133
not 0 312 1138
assign 1 313 1139
parentGet 0 313 1139
assign 1 313 1140
fileGet 0 313 1140
makeDirs 0 313 1141
assign 1 315 1143
fileGet 0 315 1143
assign 1 315 1144
writerGet 0 315 1144
assign 1 315 1145
open 0 315 1145
assign 1 317 1146
paramsGet 0 317 1146
assign 1 317 1147
new 0 317 1147
assign 1 317 1148
has 1 317 1148
assign 1 318 1150
paramsGet 0 318 1150
assign 1 318 1151
new 0 318 1151
assign 1 318 1152
get 1 318 1152
assign 1 318 1153
iteratorGet 0 0 1153
assign 1 318 1156
hasNextGet 0 318 1156
assign 1 318 1158
nextGet 0 318 1158
assign 1 319 1159
apNew 1 319 1159
assign 1 319 1160
fileGet 0 319 1160
assign 1 320 1161
readerGet 0 320 1161
assign 1 320 1162
open 0 320 1162
assign 1 320 1163
readString 0 320 1163
assign 1 321 1164
readerGet 0 321 1164
close 0 321 1165
assign 1 322 1166
countLines 1 322 1166
addValue 1 322 1167
write 1 323 1168
return 1 329 1176
close 0 333 1179
assign 1 334 1180
assign 1 339 1185
new 0 339 1185
return 1 339 1186
assign 1 343 1190
new 0 343 1190
return 1 343 1191
assign 1 347 1195
new 0 347 1195
return 1 347 1196
assign 1 351 1200
new 0 351 1200
return 1 351 1201
assign 1 355 1205
new 0 355 1205
return 1 355 1206
assign 1 359 1210
new 0 359 1210
return 1 359 1211
assign 1 363 1215
new 0 363 1215
return 1 363 1216
assign 1 368 1220
new 0 368 1220
return 1 368 1221
assign 1 373 1225
new 0 373 1225
return 1 373 1226
assign 1 377 1234
new 0 377 1234
assign 1 377 1235
add 1 377 1235
assign 1 377 1236
new 0 377 1236
assign 1 377 1237
add 1 377 1237
assign 1 377 1238
add 1 377 1238
return 1 377 1239
assign 1 381 1243
new 0 381 1243
return 1 381 1244
assign 1 385 1251
libNameGet 0 385 1251
assign 1 385 1252
relEmitName 1 385 1252
assign 1 385 1253
new 0 385 1253
assign 1 385 1254
add 1 385 1254
return 1 385 1255
assign 1 390 1264
emitNameGet 0 390 1264
assign 1 390 1265
new 0 390 1265
assign 1 390 1266
add 1 390 1266
assign 1 390 1267
new 0 390 1267
assign 1 390 1268
add 1 390 1268
assign 1 390 1269
add 1 390 1269
return 1 390 1270
assign 1 395 1281
emitNameGet 0 395 1281
assign 1 395 1282
addValue 1 395 1282
assign 1 395 1283
new 0 395 1283
assign 1 395 1284
addValue 1 395 1284
assign 1 395 1285
addValue 1 395 1285
assign 1 395 1286
new 0 395 1286
addValue 1 395 1287
addValue 1 397 1288
assign 1 399 1289
new 0 399 1289
assign 1 399 1290
addValue 1 399 1290
addValue 1 399 1291
assign 1 404 1296
new 0 404 1296
return 1 404 1297
assign 1 408 1301
new 0 408 1301
return 1 408 1302
assign 1 412 1308
new 0 412 1308
assign 1 412 1309
add 1 412 1309
assign 1 412 1310
add 1 412 1310
return 1 412 1311
assign 1 416 1317
new 0 416 1317
assign 1 416 1318
libEmitName 1 416 1318
assign 1 416 1319
add 1 416 1319
return 1 416 1320
assign 1 420 1325
getClassConfig 1 420 1325
assign 1 421 1326
fullEmitNameGet 0 421 1326
emitNameSet 1 421 1327
return 1 422 1328
assign 1 426 1333
getLocalClassConfig 1 426 1333
assign 1 427 1334
fullEmitNameGet 0 427 1334
emitNameSet 1 427 1335
return 1 428 1336
return 1 0 1339
assign 1 0 1342
return 1 0 1346
assign 1 0 1349
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1109279973: return bem_spropDecGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 229958684: return bem_constGet_0();
case 944442837: return bem_classConfGet_0();
case 362974009: return bem_parentConfGet_0();
case 1413054881: return bem_smnlcsGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1859739893: return bem_methodsGet_0();
case 1529527065: return bem_onceCountGet_0();
case 1947619572: return bem_msynGet_0();
case 89706405: return bem_ccCacheGet_0();
case 1967844855: return bem_initialDecGet_0();
case 1774940957: return bem_toString_0();
case 1074463609: return bem_saveSyns_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 4647121: return bem_doEmit_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2001798761: return bem_nlGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 1308786538: return bem_echo_0();
case 160277051: return bem_procStartGet_0();
case 1372235405: return bem_superCallsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 1380285640: return bem_objectCcGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 604504089: return bem_falseValueGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 378762597: return bem_boolNpGet_0();
case 1727672536: return bem_propDecGet_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1487140092: return bem_classEndGet_0();
case 104713553: return bem_new_0();
case 402158238: return bem_inFilePathedGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1177623581: return bem_callNamesGet_0();
case 991179882: return bem_qGet_0();
case 644675716: return bem_ntypesGet_0();
case 1081412016: return bem_many_0();
case 1638160588: return bem_lineCountGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 772789066: return bem_libEmitPathGet_0();
case 2055025483: return bem_serializeContents_0();
case 1312373307: return bem_buildCreate_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 36542021: return bem_mainEndGet_0();
case 916491491: return bem_emitLib_0();
case 603479476: return bem_allOnceDecsGet_0();
case 1747980150: return bem_smnlecsGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 1073009537: return bem_beginNs_0();
case 2085643372: return bem_stringNpGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1052944126: return bem_csynGet_0();
case 1607412815: return bem_endNs_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 498080472: return bem_mnodeGet_0();
case 1820417453: return bem_create_0();
case 962646066: return bem_shlibeGet_0();
case 946095539: return bem_mainInClassGet_0();
case 681402717: return bem_boolTypeGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 211282910: return bem_loadSyns_0();
case 493012039: return bem_buildGet_0();
case 1354714650: return bem_copy_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 254265568: return bem_buildPropList_0();
case 361542143: return bem_classEmitsGet_0();
case 902412214: return bem_classCallsGet_0();
case 294732055: return bem_floatNpGet_0();
case 729571811: return bem_serializeToString_0();
case 1831751774: return bem_cnodeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 622039562: return bem_intNpGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 991255330: return bem_mainStartGet_0();
case 722876119: return bem_buildClassInfo_0();
case 1910715228: return bem_libEmitNameGet_0();
case 797225458: return bem_dynMethodsGet_0();
case 1181505319: return bem_buildInitial_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1755995201: return bem_transGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1012494862: return bem_once_0();
case 1369896794: return bem_objectNpGet_0();
case 1498619679: return bem_getLibOutput_0();
case 287040793: return bem_hashGet_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 483359873: return bem_superNameGet_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1102720804: return bem_classNameGet_0();
case 727049506: return bem_exceptDecGet_0();
case 57260628: return bem_getClassOutput_0();
case 388723214: return bem_preClassGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 1926693913: return bem_synEmitPathGet_0();
case 1064889660: return bem_trueValueGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 1915611660: return bem_synEmitPathSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1887784556: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 596365949: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 193407613: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 614561729: return bem_allOnceDecsSet_1(bevd_0);
case 2118534024: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bevs_inst = (BEC_2_5_9_BuildJSEmitter)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bevs_inst;
}
}
}
