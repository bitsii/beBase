namespace be.BEL_4_Base {
/* IO:File: source/base/Tokenize.be */
public class BEC_2_4_4_TextGlob : BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
static BEC_2_4_4_TextGlob() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2A,0x3F};
private static byte[] bels_1 = {0x2A};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 1));
private static byte[] bels_2 = {0x3F};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
public static new BEC_2_4_4_TextGlob bevs_inst;
public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public virtual BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) {
this.bem_globSet_1(beva__glob);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_globSet_1(BEC_2_4_6_TextString beva__glob) {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_0));
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_phold.bemd_0(1816451342, BEL_4_Base.bevn_nextNodeGet_0);
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpvar_phold = this.bem_caseMatch_4(bevl_node, beva_input, bevt_2_tmpvar_phold, null);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
if (beva_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_2_tmpvar_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 128 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 129 */
 else  /* Line: 130 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 131 */
} /* Line: 128 */
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevl_val.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_7_tmpvar_phold = this.bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_tmpvar_phold;
} /* Line: 136 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevl_val.bem_equals_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 138 */ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_tmpvar_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_tmpvar_phold.bevi_int) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 140 */ {
bevt_13_tmpvar_phold = beva_node.bem_nextGet_0();
bevt_12_tmpvar_phold = this.bem_caseMatch_4(bevt_13_tmpvar_phold, beva_input, beva_pos, null);
return bevt_12_tmpvar_phold;
} /* Line: 140 */
 else  /* Line: 140 */ {
bevt_14_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_14_tmpvar_phold;
} /* Line: 140 */
} /* Line: 140 */
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 143 */ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 144 */ {
bevt_18_tmpvar_phold = beva_node.bem_nextGet_0();
bevt_20_tmpvar_phold = bevl_val.bem_sizeGet_0();
bevt_19_tmpvar_phold = beva_pos.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = this.bem_caseMatch_4(bevt_18_tmpvar_phold, beva_input, bevt_19_tmpvar_phold, null);
return bevt_17_tmpvar_phold;
} /* Line: 145 */
 else  /* Line: 146 */ {
if (beva_lpos == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 147 */ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 148 */
} /* Line: 147 */
} /* Line: 144 */
bevt_22_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_22_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (BEC_2_9_6_ContainerSingle) (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
 /* Line: 159 */ {
bevt_1_tmpvar_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevl_ok = this.bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool) /* Line: 161 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 161 */
bevt_4_tmpvar_phold = bevl_lpos.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 162 */ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 164 */
 else  /* Line: 165 */ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 166 */
} /* Line: 162 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_globGet_0() {
return bevp_glob;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() {
return bevp_splits;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {104, 108, 108, 108, 109, 111, 112, 122, 122, 123, 123, 123, 127, 127, 128, 128, 128, 129, 129, 131, 131, 134, 135, 135, 136, 136, 138, 138, 139, 140, 140, 140, 140, 140, 140, 140, 140, 142, 143, 143, 144, 144, 145, 145, 145, 145, 145, 147, 147, 148, 152, 152, 156, 157, 159, 159, 159, 160, 161, 161, 162, 162, 162, 163, 164, 166, 169, 169, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 25, 26, 27, 28, 29, 30, 38, 39, 40, 41, 42, 70, 75, 76, 77, 82, 83, 84, 87, 88, 91, 92, 93, 95, 96, 98, 99, 101, 102, 103, 108, 109, 110, 111, 114, 115, 118, 119, 124, 125, 130, 131, 132, 133, 134, 135, 138, 143, 144, 148, 149, 161, 162, 165, 166, 171, 172, 174, 175, 177, 178, 183, 184, 185, 188, 195, 196, 199, 202, 205};
/* BEGIN LINEINFO 
globSet 1 104 17
assign 1 108 25
new 0 108 25
assign 1 108 26
new 0 108 26
assign 1 108 27
new 2 108 27
assign 1 109 28
tokenize 1 109 28
assign 1 111 29
assign 1 112 30
assign 1 122 38
iteratorGet 0 122 38
assign 1 122 39
nextNodeGet 0 122 39
assign 1 123 40
new 0 123 40
assign 1 123 41
caseMatch 4 123 41
return 1 123 42
assign 1 127 70
undef 1 127 75
assign 1 128 76
sizeGet 0 128 76
assign 1 128 77
equals 1 128 82
assign 1 129 83
new 0 129 83
return 1 129 84
assign 1 131 87
new 0 131 87
return 1 131 88
assign 1 134 91
heldGet 0 134 91
assign 1 135 92
new 0 135 92
assign 1 135 93
equals 1 135 93
assign 1 136 95
starMatch 3 136 95
return 1 136 96
assign 1 138 98
new 0 138 98
assign 1 138 99
equals 1 138 99
assign 1 139 101
increment 0 139 101
assign 1 140 102
sizeGet 0 140 102
assign 1 140 103
lesserEquals 1 140 108
assign 1 140 109
nextGet 0 140 109
assign 1 140 110
caseMatch 4 140 110
return 1 140 111
assign 1 140 114
new 0 140 114
return 1 140 115
assign 1 142 118
find 2 142 118
assign 1 143 119
def 1 143 124
assign 1 144 125
equals 1 144 130
assign 1 145 131
nextGet 0 145 131
assign 1 145 132
sizeGet 0 145 132
assign 1 145 133
add 1 145 133
assign 1 145 134
caseMatch 4 145 134
return 1 145 135
assign 1 147 138
def 1 147 143
firstSet 1 148 144
assign 1 152 148
new 0 152 148
return 1 152 149
assign 1 156 161
nextGet 0 156 161
assign 1 157 162
new 0 157 162
assign 1 159 165
sizeGet 0 159 165
assign 1 159 166
lesserEquals 1 159 171
assign 1 160 172
caseMatch 4 160 172
assign 1 161 174
new 0 161 174
return 1 161 175
assign 1 162 177
firstGet 0 162 177
assign 1 162 178
def 1 162 183
assign 1 163 184
firstGet 0 163 184
firstSet 1 164 185
assign 1 166 188
increment 0 166 188
assign 1 169 195
new 0 169 195
return 1 169 196
return 1 0 199
return 1 0 202
assign 1 0 205
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 363750127: return bem_globGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1413456786: return bem_splitsGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 374832380: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case 1402374533: return bem_splitsSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 840861751: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1718699641: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1345367786: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_TextGlob();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_TextGlob.bevs_inst = (BEC_2_4_4_TextGlob)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_TextGlob.bevs_inst;
}
}
}
