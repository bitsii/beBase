namespace be.BEL_4_Base {
/* IO:File: source/base/Tokenize.be */
public class BEC_2_4_4_TextGlob : BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
static BEC_2_4_4_TextGlob() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2A,0x3F};
private static byte[] bels_1 = {0x2A};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 1));
private static byte[] bels_2 = {0x3F};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
public static new BEC_2_4_4_TextGlob bevs_inst;
public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public virtual BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) {
this.bem_globSet_1(beva__glob);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_globSet_1(BEC_2_4_6_TextString beva__glob) {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_0));
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_phold.bemd_0(1816451342, BEL_4_Base.bevn_nextNodeGet_0);
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpvar_phold = this.bem_caseMatch_4(bevl_node, beva_input, bevt_2_tmpvar_phold, null);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
if (beva_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_2_tmpvar_phold = beva_input.bem_sizeGet_0();
bevt_1_tmpvar_phold = beva_pos.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 137 */
 else  /* Line: 138 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 139 */
} /* Line: 136 */
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevl_val.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 143 */ {
bevt_7_tmpvar_phold = this.bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_tmpvar_phold;
} /* Line: 144 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevl_val.bem_equals_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 146 */ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_tmpvar_phold = beva_input.bem_sizeGet_0();
bevt_10_tmpvar_phold = beva_pos.bem_lesserEquals_1(bevt_11_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 148 */ {
bevt_13_tmpvar_phold = beva_node.bem_nextGet_0();
bevt_12_tmpvar_phold = this.bem_caseMatch_4(bevt_13_tmpvar_phold, beva_input, beva_pos, null);
return bevt_12_tmpvar_phold;
} /* Line: 148 */
 else  /* Line: 148 */ {
bevt_14_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_14_tmpvar_phold;
} /* Line: 148 */
} /* Line: 148 */
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 151 */ {
bevt_16_tmpvar_phold = bevl_found.bem_equals_1(beva_pos);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 152 */ {
bevt_18_tmpvar_phold = beva_node.bem_nextGet_0();
bevt_20_tmpvar_phold = bevl_val.bem_sizeGet_0();
bevt_19_tmpvar_phold = beva_pos.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = this.bem_caseMatch_4(bevt_18_tmpvar_phold, beva_input, bevt_19_tmpvar_phold, null);
return bevt_17_tmpvar_phold;
} /* Line: 153 */
 else  /* Line: 154 */ {
if (beva_lpos == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 155 */ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 156 */
} /* Line: 155 */
} /* Line: 152 */
bevt_22_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_22_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (BEC_2_9_6_ContainerSingle) (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
 /* Line: 167 */ {
bevt_1_tmpvar_phold = beva_input.bem_sizeGet_0();
bevt_0_tmpvar_phold = beva_pos.bem_lesserEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevl_ok = this.bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool) /* Line: 169 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 169 */
bevt_4_tmpvar_phold = bevl_lpos.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 170 */ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 172 */
 else  /* Line: 173 */ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 174 */
} /* Line: 170 */
 else  /* Line: 167 */ {
break;
} /* Line: 167 */
} /* Line: 167 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_globGet_0() {
return bevp_glob;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() {
return bevp_splits;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {112, 116, 117, 119, 120, 130, 131, 135, 136, 137, 139, 142, 143, 144, 146, 147, 148, 150, 151, 152, 153, 155, 156, 160, 164, 165, 167, 168, 169, 170, 171, 172, 174, 177, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17};
/* BEGIN LINEINFO 
globSet 1 112 17
assign 1 116 17
new 0 116 17
assign 1 116 17
new 0 116 17
assign 1 116 17
new 2 116 17
assign 1 117 17
tokenize 1 117 17
assign 1 119 17
assign 1 120 17
assign 1 130 17
iteratorGet 0 130 17
assign 1 130 17
nextNodeGet 0 130 17
assign 1 131 17
new 0 131 17
assign 1 131 17
caseMatch 4 131 17
return 1 131 17
assign 1 135 17
undef 1 135 17
assign 1 136 17
sizeGet 0 136 17
assign 1 136 17
equals 1 136 17
assign 1 137 17
new 0 137 17
return 1 137 17
assign 1 139 17
new 0 139 17
return 1 139 17
assign 1 142 17
heldGet 0 142 17
assign 1 143 17
new 0 143 17
assign 1 143 17
equals 1 143 17
assign 1 144 17
starMatch 3 144 17
return 1 144 17
assign 1 146 17
new 0 146 17
assign 1 146 17
equals 1 146 17
assign 1 147 17
increment 0 147 17
assign 1 148 17
sizeGet 0 148 17
assign 1 148 17
lesserEquals 1 148 17
assign 1 148 17
nextGet 0 148 17
assign 1 148 17
caseMatch 4 148 17
return 1 148 17
assign 1 148 17
new 0 148 17
return 1 148 17
assign 1 150 17
find 2 150 17
assign 1 151 17
def 1 151 17
assign 1 152 17
equals 1 152 17
assign 1 153 17
nextGet 0 153 17
assign 1 153 17
sizeGet 0 153 17
assign 1 153 17
add 1 153 17
assign 1 153 17
caseMatch 4 153 17
return 1 153 17
assign 1 155 17
def 1 155 17
firstSet 1 156 17
assign 1 160 17
new 0 160 17
return 1 160 17
assign 1 164 17
nextGet 0 164 17
assign 1 165 17
new 0 165 17
assign 1 167 17
sizeGet 0 167 17
assign 1 167 17
lesserEquals 1 167 17
assign 1 168 17
caseMatch 4 168 17
assign 1 169 17
new 0 169 17
return 1 169 17
assign 1 170 17
firstGet 0 170 17
assign 1 170 17
def 1 170 17
assign 1 171 17
firstGet 0 171 17
firstSet 1 172 17
assign 1 174 17
increment 0 174 17
assign 1 177 17
new 0 177 17
return 1 177 17
return 1 0 17
return 1 0 17
assign 1 0 17
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 363750127: return bem_globGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1413456786: return bem_splitsGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 374832380: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case 1402374533: return bem_splitsSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 840861751: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1718699641: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1345367786: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_TextGlob();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_TextGlob.bevs_inst = (BEC_2_4_4_TextGlob)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_TextGlob.bevs_inst;
}
}
}
