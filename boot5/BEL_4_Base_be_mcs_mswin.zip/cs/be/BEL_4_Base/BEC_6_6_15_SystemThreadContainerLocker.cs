namespace be.BEL_4_Base {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_6_6_15_SystemThreadContainerLocker : BEC_6_6_SystemObject {
public BEC_6_6_15_SystemThreadContainerLocker() { }
static BEC_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_6_6_15_SystemThreadContainerLocker bevs_inst;
public BEC_6_6_4_SystemThreadLock bevp_lock;
public BEC_6_6_SystemObject bevp_container;
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_6_6_SystemObject beva__container) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_6_6_4_SystemThreadLock) (new BEC_6_6_4_SystemThreadLock()).bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 821 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 823 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 826 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_key) {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 832 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 834 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 837 */
return bevl_r;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_key2) {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 844 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_2(99049421, BEL_4_Base.bevn_has_2, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 846 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 849 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_0() {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 856 */ {
bevl_r = bevp_container.bemd_0(98246023, BEL_4_Base.bevn_get_0);
bevp_lock.bem_unlock_0();
} /* Line: 858 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 861 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 868 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 870 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 873 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getAndClear_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 880 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 883 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 886 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_2(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 893 */ {
bevl_r = bevp_container.bemd_2(98246025, BEL_4_Base.bevn_get_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 895 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 898 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 905 */ {
bevp_container.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 907 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 910 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_putReturn_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 916 */ {
bevl_r = bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 918 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 921 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 928 */ {
bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 930 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 933 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_putReturn_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 939 */ {
bevl_r = bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 941 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 944 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 951 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 953 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 956 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_putIfAbsent_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_5_4_LogicBool bevl_didPut = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 962 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 963 */ {
bevl_didPut = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 964 */
 else  /* Line: 965 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_didPut = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 967 */
bevp_lock.bem_unlock_0();
} /* Line: 969 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 972 */
return bevl_didPut;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getOrPut_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_6_6_SystemObject bevl_result = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 979 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 980 */ {
bevl_result = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
} /* Line: 981 */
 else  /* Line: 982 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 984 */
bevp_lock.bem_unlock_0();
} /* Line: 986 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 989 */
return bevl_result;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k, BEC_6_6_SystemObject beva_v) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 996 */ {
bevp_container.bemd_3(107034371, BEL_4_Base.bevn_put_3, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 998 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1001 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1007 */ {
bevl_r = bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1009 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1012 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_2(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1019 */ {
bevl_r = bevp_container.bemd_2(819712670, BEL_4_Base.bevn_delete_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1021 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1024 */
return bevl_r;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
BEC_4_3_MathInt bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1031 */ {
bevl_r = (BEC_4_3_MathInt) bevp_container.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1033 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1036 */
return bevl_r;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1043 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_0(1089531140, BEL_4_Base.bevn_isEmptyGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1045 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1048 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_copyContainer_0() {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1055 */ {
bevl_r = bevp_container.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevp_lock.bem_unlock_0();
} /* Line: 1057 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1060 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1067 */ {
bevp_container.bemd_0(856777406, BEL_4_Base.bevn_clear_0);
bevp_lock.bem_unlock_0();
} /* Line: 1069 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1072 */
return this;
} /*method end*/
public virtual BEC_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lockSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lock = (BEC_6_6_4_SystemThreadLock) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_container = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {817, 820, 822, 823, 825, 826, 831, 833, 834, 836, 837, 839, 843, 845, 846, 848, 849, 851, 855, 857, 858, 860, 861, 863, 867, 869, 870, 872, 873, 875, 879, 881, 882, 883, 885, 886, 888, 892, 894, 895, 897, 898, 900, 904, 906, 907, 909, 910, 915, 917, 918, 920, 921, 923, 927, 929, 930, 932, 933, 938, 940, 941, 943, 944, 946, 950, 952, 953, 955, 956, 961, 963, 964, 966, 967, 969, 971, 972, 974, 978, 980, 981, 983, 984, 986, 988, 989, 991, 995, 997, 998, 1000, 1001, 1006, 1008, 1009, 1011, 1012, 1014, 1018, 1020, 1021, 1023, 1024, 1026, 1030, 1032, 1033, 1035, 1036, 1038, 1042, 1044, 1045, 1047, 1048, 1050, 1054, 1056, 1057, 1059, 1060, 1062, 1066, 1068, 1069, 1071, 1072, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 21, 22, 26, 27, 34, 36, 37, 41, 42, 44, 49, 51, 52, 56, 57, 59, 64, 66, 67, 71, 72, 74, 79, 81, 82, 86, 87, 89, 94, 96, 97, 98, 102, 103, 105, 110, 112, 113, 117, 118, 120, 124, 126, 127, 131, 132, 139, 141, 142, 146, 147, 149, 153, 155, 156, 160, 161, 168, 170, 171, 175, 176, 178, 182, 184, 185, 189, 190, 198, 200, 202, 205, 206, 208, 212, 213, 215, 221, 223, 225, 228, 229, 231, 235, 236, 238, 242, 244, 245, 249, 250, 257, 259, 260, 264, 265, 267, 272, 274, 275, 279, 280, 282, 287, 289, 290, 294, 295, 297, 302, 304, 305, 309, 310, 312, 317, 319, 320, 324, 325, 327, 331, 333, 334, 338, 339, 344, 347, 351, 354};
/* BEGIN LINEINFO 
assign 1 817 18
new 0 817 18
lock 0 820 19
assign 1 822 21
unlock 0 823 22
unlock 0 825 26
throw 1 826 27
lock 0 831 34
assign 1 833 36
has 1 833 36
unlock 0 834 37
unlock 0 836 41
throw 1 837 42
return 1 839 44
lock 0 843 49
assign 1 845 51
has 2 845 51
unlock 0 846 52
unlock 0 848 56
throw 1 849 57
return 1 851 59
lock 0 855 64
assign 1 857 66
get 0 857 66
unlock 0 858 67
unlock 0 860 71
throw 1 861 72
return 1 863 74
lock 0 867 79
assign 1 869 81
get 1 869 81
unlock 0 870 82
unlock 0 872 86
throw 1 873 87
return 1 875 89
lock 0 879 94
assign 1 881 96
get 1 881 96
delete 1 882 97
unlock 0 883 98
unlock 0 885 102
throw 1 886 103
return 1 888 105
lock 0 892 110
assign 1 894 112
get 2 894 112
unlock 0 895 113
unlock 0 897 117
throw 1 898 118
return 1 900 120
lock 0 904 124
addValue 1 906 126
unlock 0 907 127
unlock 0 909 131
throw 1 910 132
lock 0 915 139
assign 1 917 141
put 1 917 141
unlock 0 918 142
unlock 0 920 146
throw 1 921 147
return 1 923 149
lock 0 927 153
put 1 929 155
unlock 0 930 156
unlock 0 932 160
throw 1 933 161
lock 0 938 168
assign 1 940 170
put 2 940 170
unlock 0 941 171
unlock 0 943 175
throw 1 944 176
return 1 946 178
lock 0 950 182
put 2 952 184
unlock 0 953 185
unlock 0 955 189
throw 1 956 190
lock 0 961 198
assign 1 963 200
has 1 963 200
assign 1 964 202
new 0 964 202
put 2 966 205
assign 1 967 206
new 0 967 206
unlock 0 969 208
unlock 0 971 212
throw 1 972 213
return 1 974 215
lock 0 978 221
assign 1 980 223
has 1 980 223
assign 1 981 225
get 1 981 225
put 2 983 228
assign 1 984 229
unlock 0 986 231
unlock 0 988 235
throw 1 989 236
return 1 991 238
lock 0 995 242
put 3 997 244
unlock 0 998 245
unlock 0 1000 249
throw 1 1001 250
lock 0 1006 257
assign 1 1008 259
delete 1 1008 259
unlock 0 1009 260
unlock 0 1011 264
throw 1 1012 265
return 1 1014 267
lock 0 1018 272
assign 1 1020 274
delete 2 1020 274
unlock 0 1021 275
unlock 0 1023 279
throw 1 1024 280
return 1 1026 282
lock 0 1030 287
assign 1 1032 289
sizeGet 0 1032 289
unlock 0 1033 290
unlock 0 1035 294
throw 1 1036 295
return 1 1038 297
lock 0 1042 302
assign 1 1044 304
isEmptyGet 0 1044 304
unlock 0 1045 305
unlock 0 1047 309
throw 1 1048 310
return 1 1050 312
lock 0 1054 317
assign 1 1056 319
copy 0 1056 319
unlock 0 1057 320
unlock 0 1059 324
throw 1 1060 325
return 1 1062 327
lock 0 1066 331
clear 0 1068 333
unlock 0 1069 334
unlock 0 1071 338
throw 1 1072 339
return 1 0 344
assign 1 0 347
return 1 0 351
assign 1 0 354
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 833063302: return bem_containerGet_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 952571108: return bem_lockGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 98246023: return bem_get_0();
case 1820417453: return bem_create_0();
case 454584637: return bem_copyContainer_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 941488855: return bem_lockSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 365996783: return bem_putReturn_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1572587742: return bem_getAndClear_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2(bevd_0, bevd_1);
case 98246025: return bem_get_2(bevd_0, bevd_1);
case 819712670: return bem_delete_2(bevd_0, bevd_1);
case 99049421: return bem_has_2(bevd_0, bevd_1);
case 365996782: return bem_putReturn_2(bevd_0, bevd_1);
case 188241239: return bem_getOrPut_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 2074693976: return bem_putIfAbsent_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) {
switch (callHash) {
case 107034371: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_6_15_SystemThreadContainerLocker.bevs_inst = (BEC_6_6_15_SystemThreadContainerLocker)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_6_15_SystemThreadContainerLocker.bevs_inst;
}
}
}
