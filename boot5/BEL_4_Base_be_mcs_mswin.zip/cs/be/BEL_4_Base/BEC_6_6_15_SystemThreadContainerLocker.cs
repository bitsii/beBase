namespace be.BEL_4_Base {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* File: source/base/System.be */
public class BEC_6_6_15_SystemThreadContainerLocker : BEC_6_6_SystemObject {
public BEC_6_6_15_SystemThreadContainerLocker() { }
static BEC_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_6_6_15_SystemThreadContainerLocker bevs_inst;
public BEC_6_6_4_SystemThreadLock bevp_lock;
public BEC_6_6_SystemObject bevp_container;
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_6_6_SystemObject beva__container) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_6_6_4_SystemThreadLock) (new BEC_6_6_4_SystemThreadLock()).bem_new_0();
bevp_lock.bem_lock_0();
try  /* Line: 820 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 822 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 825 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_key) {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 831 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 833 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 836 */
return bevl_r;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_key2) {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 843 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_2(99049421, BEL_4_Base.bevn_has_2, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 845 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 848 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_0() {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 855 */ {
bevl_r = bevp_container.bemd_0(98246023, BEL_4_Base.bevn_get_0);
bevp_lock.bem_unlock_0();
} /* Line: 857 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 860 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 867 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 869 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 872 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getAndClear_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 879 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 882 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 885 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_2(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 892 */ {
bevl_r = bevp_container.bemd_2(98246025, BEL_4_Base.bevn_get_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 894 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 897 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 904 */ {
bevp_container.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 906 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 909 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_putReturn_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 915 */ {
bevl_r = bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 917 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 920 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 927 */ {
bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 929 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 932 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_putReturn_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 938 */ {
bevl_r = bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 940 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 943 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 950 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 952 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 955 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_putIfAbsent_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_5_4_LogicBool bevl_didPut = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 961 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 962 */ {
bevl_didPut = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 963 */
 else  /* Line: 964 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_didPut = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 966 */
bevp_lock.bem_unlock_0();
} /* Line: 968 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 971 */
return bevl_didPut;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getOrPut_2(BEC_6_6_SystemObject beva_key, BEC_6_6_SystemObject beva_value) {
BEC_6_6_SystemObject bevl_result = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 978 */ {
bevt_0_tmpvar_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 979 */ {
bevl_result = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
} /* Line: 980 */
 else  /* Line: 981 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 983 */
bevp_lock.bem_unlock_0();
} /* Line: 985 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 988 */
return bevl_result;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k, BEC_6_6_SystemObject beva_v) {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 995 */ {
bevp_container.bemd_3(107034371, BEL_4_Base.bevn_put_3, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 997 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1000 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_1(BEC_6_6_SystemObject beva_key) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1006 */ {
bevl_r = bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1008 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1011 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_2(BEC_6_6_SystemObject beva_p, BEC_6_6_SystemObject beva_k) {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1018 */ {
bevl_r = bevp_container.bemd_2(819712670, BEL_4_Base.bevn_delete_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1020 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1023 */
return bevl_r;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
BEC_4_3_MathInt bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1030 */ {
bevl_r = (BEC_4_3_MathInt) bevp_container.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1032 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1035 */
return bevl_r;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1042 */ {
bevl_r = (BEC_5_4_LogicBool) bevp_container.bemd_0(1089531140, BEL_4_Base.bevn_isEmptyGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1044 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1047 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_copyContainer_0() {
BEC_6_6_SystemObject bevl_r = null;
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1054 */ {
bevl_r = bevp_container.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevp_lock.bem_unlock_0();
} /* Line: 1056 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1059 */
return bevl_r;
} /*method end*/
public virtual BEC_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1066 */ {
bevp_container.bemd_0(856777406, BEL_4_Base.bevn_clear_0);
bevp_lock.bem_unlock_0();
} /* Line: 1068 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 1071 */
return this;
} /*method end*/
public virtual BEC_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lockSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lock = (BEC_6_6_4_SystemThreadLock) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_container = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {816, 819, 821, 822, 824, 825, 830, 832, 833, 835, 836, 838, 842, 844, 845, 847, 848, 850, 854, 856, 857, 859, 860, 862, 866, 868, 869, 871, 872, 874, 878, 880, 881, 882, 884, 885, 887, 891, 893, 894, 896, 897, 899, 903, 905, 906, 908, 909, 914, 916, 917, 919, 920, 922, 926, 928, 929, 931, 932, 937, 939, 940, 942, 943, 945, 949, 951, 952, 954, 955, 960, 962, 963, 965, 966, 968, 970, 971, 973, 977, 979, 980, 982, 983, 985, 987, 988, 990, 994, 996, 997, 999, 1000, 1005, 1007, 1008, 1010, 1011, 1013, 1017, 1019, 1020, 1022, 1023, 1025, 1029, 1031, 1032, 1034, 1035, 1037, 1041, 1043, 1044, 1046, 1047, 1049, 1053, 1055, 1056, 1058, 1059, 1061, 1065, 1067, 1068, 1070, 1071, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 21, 22, 26, 27, 34, 36, 37, 41, 42, 44, 49, 51, 52, 56, 57, 59, 64, 66, 67, 71, 72, 74, 79, 81, 82, 86, 87, 89, 94, 96, 97, 98, 102, 103, 105, 110, 112, 113, 117, 118, 120, 124, 126, 127, 131, 132, 139, 141, 142, 146, 147, 149, 153, 155, 156, 160, 161, 168, 170, 171, 175, 176, 178, 182, 184, 185, 189, 190, 198, 200, 202, 205, 206, 208, 212, 213, 215, 221, 223, 225, 228, 229, 231, 235, 236, 238, 242, 244, 245, 249, 250, 257, 259, 260, 264, 265, 267, 272, 274, 275, 279, 280, 282, 287, 289, 290, 294, 295, 297, 302, 304, 305, 309, 310, 312, 317, 319, 320, 324, 325, 327, 331, 333, 334, 338, 339, 344, 347, 351, 354};
/* BEGIN LINEINFO 
assign 1 816 18
new 0 816 18
lock 0 819 19
assign 1 821 21
unlock 0 822 22
unlock 0 824 26
throw 1 825 27
lock 0 830 34
assign 1 832 36
has 1 832 36
unlock 0 833 37
unlock 0 835 41
throw 1 836 42
return 1 838 44
lock 0 842 49
assign 1 844 51
has 2 844 51
unlock 0 845 52
unlock 0 847 56
throw 1 848 57
return 1 850 59
lock 0 854 64
assign 1 856 66
get 0 856 66
unlock 0 857 67
unlock 0 859 71
throw 1 860 72
return 1 862 74
lock 0 866 79
assign 1 868 81
get 1 868 81
unlock 0 869 82
unlock 0 871 86
throw 1 872 87
return 1 874 89
lock 0 878 94
assign 1 880 96
get 1 880 96
delete 1 881 97
unlock 0 882 98
unlock 0 884 102
throw 1 885 103
return 1 887 105
lock 0 891 110
assign 1 893 112
get 2 893 112
unlock 0 894 113
unlock 0 896 117
throw 1 897 118
return 1 899 120
lock 0 903 124
addValue 1 905 126
unlock 0 906 127
unlock 0 908 131
throw 1 909 132
lock 0 914 139
assign 1 916 141
put 1 916 141
unlock 0 917 142
unlock 0 919 146
throw 1 920 147
return 1 922 149
lock 0 926 153
put 1 928 155
unlock 0 929 156
unlock 0 931 160
throw 1 932 161
lock 0 937 168
assign 1 939 170
put 2 939 170
unlock 0 940 171
unlock 0 942 175
throw 1 943 176
return 1 945 178
lock 0 949 182
put 2 951 184
unlock 0 952 185
unlock 0 954 189
throw 1 955 190
lock 0 960 198
assign 1 962 200
has 1 962 200
assign 1 963 202
new 0 963 202
put 2 965 205
assign 1 966 206
new 0 966 206
unlock 0 968 208
unlock 0 970 212
throw 1 971 213
return 1 973 215
lock 0 977 221
assign 1 979 223
has 1 979 223
assign 1 980 225
get 1 980 225
put 2 982 228
assign 1 983 229
unlock 0 985 231
unlock 0 987 235
throw 1 988 236
return 1 990 238
lock 0 994 242
put 3 996 244
unlock 0 997 245
unlock 0 999 249
throw 1 1000 250
lock 0 1005 257
assign 1 1007 259
delete 1 1007 259
unlock 0 1008 260
unlock 0 1010 264
throw 1 1011 265
return 1 1013 267
lock 0 1017 272
assign 1 1019 274
delete 2 1019 274
unlock 0 1020 275
unlock 0 1022 279
throw 1 1023 280
return 1 1025 282
lock 0 1029 287
assign 1 1031 289
sizeGet 0 1031 289
unlock 0 1032 290
unlock 0 1034 294
throw 1 1035 295
return 1 1037 297
lock 0 1041 302
assign 1 1043 304
isEmptyGet 0 1043 304
unlock 0 1044 305
unlock 0 1046 309
throw 1 1047 310
return 1 1049 312
lock 0 1053 317
assign 1 1055 319
copy 0 1055 319
unlock 0 1056 320
unlock 0 1058 324
throw 1 1059 325
return 1 1061 327
lock 0 1065 331
clear 0 1067 333
unlock 0 1068 334
unlock 0 1070 338
throw 1 1071 339
return 1 0 344
assign 1 0 347
return 1 0 351
assign 1 0 354
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 833063302: return bem_containerGet_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 952571108: return bem_lockGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 98246023: return bem_get_0();
case 1820417453: return bem_create_0();
case 454584637: return bem_copyContainer_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1(bevd_0);
case 941488855: return bem_lockSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 365996783: return bem_putReturn_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1572587742: return bem_getAndClear_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2(bevd_0, bevd_1);
case 98246025: return bem_get_2(bevd_0, bevd_1);
case 819712670: return bem_delete_2(bevd_0, bevd_1);
case 99049421: return bem_has_2(bevd_0, bevd_1);
case 365996782: return bem_putReturn_2(bevd_0, bevd_1);
case 188241239: return bem_getOrPut_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 2074693976: return bem_putIfAbsent_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) {
switch (callHash) {
case 107034371: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_6_15_SystemThreadContainerLocker.bevs_inst = (BEC_6_6_15_SystemThreadContainerLocker)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_6_15_SystemThreadContainerLocker.bevs_inst;
}
}
}
