namespace be.BEL_4_Base {
/* IO:File: source/base/Exceptions.be */
public class BEC_6_9_SystemException : BEC_6_6_SystemObject {
public BEC_6_9_SystemException() { }
static BEC_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x63,0x73};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_11, 2));
private static byte[] bels_12 = {0x0D,0x0A};
private static byte[] bels_13 = {0x63,0x73};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x61,0x74,0x20};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_14, 3));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_15 = {0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_15, 1));
private static BEC_4_3_MathInt bevo_7 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_8 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static byte[] bels_16 = {0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_16, 2));
private static BEC_4_3_MathInt bevo_10 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static byte[] bels_17 = {0x20};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_17, 1));
private static BEC_4_3_MathInt bevo_12 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_18 = {0x3A};
private static BEC_4_3_MathInt bevo_13 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_14 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_19 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_19, 5));
private static byte[] bels_20 = {0x28};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_20, 1));
private static byte[] bels_21 = {0x29};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_21, 1));
private static BEC_4_3_MathInt bevo_18 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_19 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_22 = {0x3A};
private static BEC_4_3_MathInt bevo_20 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_23 = {0x3A};
private static BEC_4_3_MathInt bevo_21 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_22 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_24 = {0x28};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_24, 1));
private static BEC_4_3_MathInt bevo_24 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_25 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_26 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
private static byte[] bels_25 = {0x2E};
private static byte[] bels_26 = {0x2E};
private static BEC_4_3_MathInt bevo_27 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_27 = {0x42,0x45,0x4C,0x5F};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_27, 4));
private static BEC_4_3_MathInt bevo_29 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_28 = {0x5F};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_28, 1));
private static BEC_4_3_MathInt bevo_31 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_32 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_33 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_34 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(7));
private static byte[] bels_29 = {0x62,0x65};
private static byte[] bels_30 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_35 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_30, 2));
private static byte[] bels_31 = {0x62,0x65};
private static byte[] bels_32 = {0x2E};
private static byte[] bels_33 = {0x42,0x45,0x43,0x5F};
private static BEC_4_6_TextString bevo_36 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_33, 4));
private static byte[] bels_34 = {0x5F};
private static BEC_4_3_MathInt bevo_37 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_38 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_35 = {0x3A};
private static byte[] bels_36 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_39 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x5F};
private static BEC_4_3_MathInt bevo_40 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_41 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_38 = {0x5F};
private static byte[] bels_39 = {0x0A};
private static BEC_4_6_TextString bevo_42 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_39, 1));
public static new BEC_6_9_SystemException bevs_inst;
public BEC_6_6_SystemObject bevp_methodName;
public BEC_6_6_SystemObject bevp_klassName;
public BEC_6_6_SystemObject bevp_description;
public BEC_6_6_SystemObject bevp_fileName;
public BEC_6_6_SystemObject bevp_lineNumber;
public BEC_4_6_TextString bevp_lang;
public BEC_4_6_TextString bevp_emitLang;
public BEC_9_10_ContainerLinkedList bevp_frames;
public BEC_4_6_TextString bevp_framesText;
public BEC_5_4_LogicBool bevp_translated;
public virtual BEC_6_9_SystemException bem_new_1(BEC_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 41 */ {
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_1));
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevl_toRet = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 42 */
if (bevp_emitLang == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_2));
bevt_4_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 45 */
if (bevp_methodName == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 47 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_3));
bevt_7_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpvar_phold);
bevl_toRet = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 48 */
if (bevp_klassName == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_4));
bevt_10_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_toRet = bevt_10_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 51 */
if (bevp_description == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_5));
bevt_13_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevl_toRet = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 54 */
if (bevp_fileName == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 56 */ {
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_6));
bevt_16_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpvar_phold);
bevl_toRet = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 57 */
if (bevp_lineNumber == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 59 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_7));
bevt_19_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
} /* Line: 60 */
if (bevp_framesText == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevl_toRet = bevt_23_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 63 */
if (bevp_frames == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_26_tmpvar_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 66 */
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_translateEmittedException_0() {
BEC_6_6_SystemObject bevl_e = null;
BEC_6_6_SystemObject bevl_ee = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
try  /* Line: 72 */ {
this.bem_translateEmittedExceptionInner_0();
} /* Line: 73 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold.bem_print_0();
if (bevl_e == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 76 */ {
try  /* Line: 77 */ {
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 77 */
 catch (System.Exception beve_1) {
bevl_ee = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_1));
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 76 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_translateEmittedExceptionInner_0() {
BEC_4_9_TextTokenizer bevl_ltok = null;
BEC_9_10_ContainerLinkedList bevl_lines = null;
BEC_5_4_LogicBool bevl_isCs = null;
BEC_4_6_TextString bevl_line = null;
BEC_4_3_MathInt bevl_start = null;
BEC_4_6_TextString bevl_efile = null;
BEC_4_3_MathInt bevl_eline = null;
BEC_4_3_MathInt bevl_end = null;
BEC_4_6_TextString bevl_callPart = null;
BEC_4_6_TextString bevl_inPart = null;
BEC_4_3_MathInt bevl_pdelim = null;
BEC_4_6_TextString bevl_iv = null;
BEC_9_10_ContainerLinkedList bevl_parts = null;
BEC_4_6_TextString bevl_klass = null;
BEC_4_6_TextString bevl_mtd = null;
BEC_4_6_TextString bevl_libLens = null;
BEC_4_3_MathInt bevl_libLen = null;
BEC_9_5_ExceptionFrame bevl_fr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
if (bevp_translated == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 83 */ {
if (bevp_translated.bevi_bool) /* Line: 83 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 83 */ {
return this;
} /* Line: 84 */
bevp_translated = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 87 */ {
if (bevp_lang == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 87 */ {
bevt_16_tmpvar_phold = bevo_1;
bevt_15_tmpvar_phold = bevp_lang.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_18_tmpvar_phold = bevo_2;
bevt_17_tmpvar_phold = bevp_lang.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 87 */ {
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_12));
bevl_ltok = (BEC_4_9_TextTokenizer) (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_19_tmpvar_phold);
bevl_lines = (BEC_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_21_tmpvar_phold = bevo_3;
bevt_20_tmpvar_phold = bevp_lang.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 90 */ {
bevl_isCs = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 91 */
 else  /* Line: 92 */ {
bevl_isCs = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 93 */
bevt_0_tmpvar_loop = bevl_lines.bem_iteratorGet_0();
while (true)
 /* Line: 95 */ {
bevt_22_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 95 */ {
bevl_line = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpvar_phold = bevo_4;
bevl_start = bevl_line.bem_find_1(bevt_23_tmpvar_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_26_tmpvar_phold = bevo_5;
bevt_25_tmpvar_phold = bevl_start.bem_greaterEquals_1(bevt_26_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 100 */
 else  /* Line: 100 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 100 */ {
bevt_27_tmpvar_phold = bevo_6;
bevt_29_tmpvar_phold = bevo_7;
bevt_28_tmpvar_phold = bevl_start.bem_add_1(bevt_29_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_27_tmpvar_phold, bevt_28_tmpvar_phold);
if (bevl_end == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_31_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 103 */ {
bevt_33_tmpvar_phold = bevo_8;
bevt_32_tmpvar_phold = bevl_start.bem_add_1(bevt_33_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_32_tmpvar_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 107 */ {
bevt_34_tmpvar_phold = bevo_9;
bevl_start = bevl_line.bem_find_2(bevt_34_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_37_tmpvar_phold = bevo_10;
bevt_36_tmpvar_phold = bevl_start.bem_add_1(bevt_37_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevo_11;
bevt_38_tmpvar_phold = bevl_inPart.bem_ends_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_41_tmpvar_phold = bevl_inPart.bem_sizeGet_0();
bevt_42_tmpvar_phold = bevo_12;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_subtract_1(bevt_42_tmpvar_phold);
bevl_inPart.bem_sizeSet_1(bevt_40_tmpvar_phold);
} /* Line: 113 */
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_18));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_43_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_45_tmpvar_phold = bevo_13;
bevl_efile = bevl_inPart.bem_substring_2(bevt_45_tmpvar_phold, bevl_pdelim);
bevt_47_tmpvar_phold = bevo_14;
bevt_46_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_47_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_46_tmpvar_phold);
bevt_49_tmpvar_phold = bevo_15;
bevt_48_tmpvar_phold = bevl_iv.bem_begins_1(bevt_49_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_50_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_50_tmpvar_phold);
} /* Line: 122 */
bevt_51_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevl_eline = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 126 */
} /* Line: 125 */
} /* Line: 117 */
} /* Line: 109 */
 else  /* Line: 130 */ {
bevt_52_tmpvar_phold = bevo_16;
bevl_start = bevl_line.bem_find_2(bevt_52_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 132 */ {
bevt_54_tmpvar_phold = bevo_17;
bevt_56_tmpvar_phold = bevo_18;
bevt_55_tmpvar_phold = bevl_start.bem_add_1(bevt_56_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
if (bevl_end == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_59_tmpvar_phold = bevo_19;
bevt_58_tmpvar_phold = bevl_start.bem_add_1(bevt_59_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_58_tmpvar_phold, bevl_end);
bevt_60_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_60_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_62_tmpvar_phold = bevo_20;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_62_tmpvar_phold, bevl_pdelim);
bevt_63_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_23));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_63_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_65_tmpvar_phold = bevo_21;
bevl_efile = bevl_inPart.bem_substring_2(bevt_65_tmpvar_phold, bevl_pdelim);
} /* Line: 146 */
bevt_67_tmpvar_phold = bevo_22;
bevt_66_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_67_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 150 */ {
bevl_eline = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 151 */
} /* Line: 150 */
} /* Line: 141 */
} /* Line: 136 */
} /* Line: 132 */
} /* Line: 107 */
 else  /* Line: 157 */ {
bevt_69_tmpvar_phold = bevo_23;
bevt_71_tmpvar_phold = bevo_24;
bevt_70_tmpvar_phold = bevl_start.bem_add_1(bevt_71_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_69_tmpvar_phold, bevt_70_tmpvar_phold);
if (bevl_end == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_73_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 159 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 159 */
 else  /* Line: 159 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 159 */ {
bevt_75_tmpvar_phold = bevo_25;
bevt_74_tmpvar_phold = bevl_start.bem_add_1(bevt_75_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_74_tmpvar_phold, bevl_end);
} /* Line: 160 */
 else  /* Line: 161 */ {
bevt_77_tmpvar_phold = bevo_26;
bevt_76_tmpvar_phold = bevl_start.bem_add_1(bevt_77_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_76_tmpvar_phold);
} /* Line: 162 */
} /* Line: 159 */
if (bevl_callPart == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 165 */ {
if (bevl_isCs.bevi_bool) /* Line: 166 */ {
bevt_79_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_25));
bevl_parts = (BEC_9_10_ContainerLinkedList) bevl_callPart.bem_split_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_klass = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_80_tmpvar_phold);
bevt_81_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(3));
bevl_mtd = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_81_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (BEC_9_5_ExceptionFrame) (new BEC_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_83_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_82_tmpvar_phold = this.bem_getSourceFileName_1(bevt_83_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_82_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 179 */
 else  /* Line: 180 */ {
bevt_84_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_26));
bevl_parts = (BEC_9_10_ContainerLinkedList) bevl_callPart.bem_split_1(bevt_84_tmpvar_phold);
bevt_86_tmpvar_phold = bevl_parts.bem_sizeGet_0();
bevt_87_tmpvar_phold = bevo_27;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_greater_1(bevt_87_tmpvar_phold);
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 184 */ {
bevt_88_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_mtd = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_88_tmpvar_phold);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevt_89_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_klass = (BEC_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = bevo_28;
bevl_start = bevl_klass.bem_find_1(bevt_90_tmpvar_phold);
if (bevl_start == null) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevt_93_tmpvar_phold = bevo_29;
bevt_92_tmpvar_phold = bevl_start.bem_greater_1(bevt_93_tmpvar_phold);
if (bevt_92_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 190 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 190 */
 else  /* Line: 190 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 190 */ {
bevt_94_tmpvar_phold = bevo_30;
bevt_96_tmpvar_phold = bevo_31;
bevt_95_tmpvar_phold = bevl_start.bem_add_1(bevt_96_tmpvar_phold);
bevl_end = bevl_klass.bem_find_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
if (bevl_end == null) {
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_99_tmpvar_phold = bevo_32;
bevt_98_tmpvar_phold = bevl_end.bem_greater_1(bevt_99_tmpvar_phold);
if (bevt_98_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 192 */ {
bevt_101_tmpvar_phold = bevo_33;
bevt_100_tmpvar_phold = bevl_start.bem_add_1(bevt_101_tmpvar_phold);
bevl_libLens = bevl_klass.bem_substring_2(bevt_100_tmpvar_phold, bevl_end);
bevl_libLen = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevl_libLens);
bevt_104_tmpvar_phold = bevo_34;
bevt_103_tmpvar_phold = bevl_start.bem_add_1(bevt_104_tmpvar_phold);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_add_1(bevl_libLen);
bevl_klass = bevl_klass.bem_substring_1(bevt_102_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_fr = (BEC_9_5_ExceptionFrame) (new BEC_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_106_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_105_tmpvar_phold = this.bem_getSourceFileName_1(bevt_106_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_105_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 202 */
} /* Line: 192 */
} /* Line: 190 */
} /* Line: 184 */
} /* Line: 166 */
} /* Line: 165 */
} /* Line: 100 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_29));
bevp_framesText = null;
} /* Line: 212 */
 else  /* Line: 87 */ {
if (bevp_frames == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 213 */ {
if (bevp_lang == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
 else  /* Line: 213 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 213 */ {
bevt_110_tmpvar_phold = bevo_35;
bevt_109_tmpvar_phold = bevp_lang.bem_equals_1(bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
 else  /* Line: 213 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 213 */ {
bevt_1_tmpvar_loop = bevp_frames.bem_iteratorGet_0();
while (true)
 /* Line: 214 */ {
bevt_111_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 214 */ {
bevl_fr = (BEC_9_5_ExceptionFrame) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_113_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_112_tmpvar_phold = this.bem_extractKlassLib_1(bevt_113_tmpvar_phold);
bevl_fr.bem_klassNameSet_1(bevt_112_tmpvar_phold);
bevt_115_tmpvar_phold = bevl_fr.bem_methodNameGet_0();
bevt_114_tmpvar_phold = this.bem_extractMethod_1(bevt_115_tmpvar_phold);
bevl_fr.bem_methodNameSet_1(bevt_114_tmpvar_phold);
bevt_117_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_116_tmpvar_phold = this.bem_getSourceFileName_1(bevt_117_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_116_tmpvar_phold);
} /* Line: 218 */
 else  /* Line: 214 */ {
break;
} /* Line: 214 */
} /* Line: 214 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_31));
} /* Line: 223 */
 else  /* Line: 224 */ {
} /* Line: 224 */
} /* Line: 87 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_getSourceFileName_1(BEC_4_6_TextString beva_klassName) {
BEC_6_6_SystemObject bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpvar_phold);
if (bevl_i == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevt_2_tmpvar_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_4_6_TextString) bevt_2_tmpvar_phold;
} /* Line: 234 */
return null;
} /*method end*/
public virtual BEC_4_6_TextString bem_extractKlassLib_1(BEC_4_6_TextString beva_callPart) {
BEC_9_10_ContainerLinkedList bevl_parts = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_32));
bevl_parts = (BEC_9_10_ContainerLinkedList) beva_callPart.bem_split_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevt_2_tmpvar_phold = bevl_parts.bem_get_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_extractKlass_1((BEC_4_6_TextString) bevt_2_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_extractKlass_1(BEC_4_6_TextString beva_klass) {
BEC_6_6_SystemObject bevl_e = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
try  /* Line: 248 */ {
bevt_0_tmpvar_phold = this.bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpvar_phold;
} /* Line: 249 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 250 */
return beva_klass;
} /*method end*/
public virtual BEC_4_6_TextString bem_extractKlassInner_1(BEC_4_6_TextString beva_klass) {
BEC_9_10_ContainerLinkedList bevl_kparts = null;
BEC_4_3_MathInt bevl_kps = null;
BEC_4_6_TextString bevl_rawkl = null;
BEC_4_6_TextString bevl_bec = null;
BEC_4_3_MathInt bevl_sofar = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_len = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
if (beva_klass == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_4_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = beva_klass.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 257 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 257 */ {
return beva_klass;
} /* Line: 258 */
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_klass.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_34));
bevl_kparts = (BEC_9_10_ContainerLinkedList) bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_37;
bevl_kps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_rawkl = (BEC_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_sofar = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 265 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_kps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevt_11_tmpvar_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpvar_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpvar_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_38;
bevt_15_tmpvar_phold = bevl_i.bem_add_1(bevt_16_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_lesser_1(bevl_kps);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_35));
bevl_bec.bem_addValue_1(bevt_17_tmpvar_phold);
} /* Line: 269 */
bevl_sofar.bem_addValue_1(bevl_len);
bevl_i.bem_incrementValue_0();
} /* Line: 265 */
 else  /* Line: 265 */ {
break;
} /* Line: 265 */
} /* Line: 265 */
return bevl_bec;
} /*method end*/
public virtual BEC_4_6_TextString bem_extractMethod_1(BEC_4_6_TextString beva_mtd) {
BEC_9_10_ContainerLinkedList bevl_mparts = null;
BEC_4_3_MathInt bevl_mps = null;
BEC_4_6_TextString bevl_bem = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
if (beva_mtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_4_tmpvar_phold = bevo_39;
bevt_3_tmpvar_phold = beva_mtd.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 277 */ {
return beva_mtd;
} /* Line: 278 */
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_mtd.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_37));
bevl_mparts = (BEC_9_10_ContainerLinkedList) bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_40;
bevl_mps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_bem = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 283 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_mps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_11_tmpvar_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_41;
bevt_13_tmpvar_phold = bevl_i.bem_add_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_lesser_1(bevl_mps);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_38));
bevl_bem.bem_addValue_1(bevt_15_tmpvar_phold);
} /* Line: 285 */
bevl_i.bem_incrementValue_0();
} /* Line: 283 */
 else  /* Line: 283 */ {
break;
} /* Line: 283 */
} /* Line: 283 */
return bevl_bem;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_framesGet_0() {
return bevp_frames;
} /*method end*/
public virtual BEC_4_6_TextString bem_getFrameText_0() {
BEC_4_6_TextString bevl_toRet = null;
BEC_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_6_6_SystemObject bevl_ft = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 301 */ {
bevt_2_tmpvar_phold = bevo_42;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_loop = bevl_myFrames.bem_iteratorGet_0();
while (true)
 /* Line: 303 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevl_ft = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 304 */
 else  /* Line: 303 */ {
break;
} /* Line: 303 */
} /* Line: 303 */
} /* Line: 303 */
return bevl_toRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_klassNameGet_0() {
return (BEC_4_6_TextString) bevp_klassName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addFrame_1(BEC_9_5_ExceptionFrame beva_frame) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_frames == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevp_frames = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 316 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addFrame_4(BEC_4_6_TextString beva__klassName, BEC_4_6_TextString beva__methodName, BEC_4_6_TextString beva__fileName, BEC_4_3_MathInt beva__line) {
BEC_9_5_ExceptionFrame bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ExceptionFrame) (new BEC_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_klassNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_klassName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_descriptionGet_0() {
return bevp_description;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_descriptionSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_description = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fileNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fileName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lineNumberGet_0() {
return bevp_lineNumber;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lineNumberSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lineNumber = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_langGet_0() {
return bevp_lang;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_langSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLangSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_framesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_frames = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_framesTextGet_0() {
return bevp_framesText;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_framesTextSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_framesText = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_translatedGet_0() {
return bevp_translated;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_translatedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_translated = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {33, 37, 40, 41, 41, 42, 42, 42, 44, 44, 45, 45, 45, 47, 47, 48, 48, 48, 50, 50, 51, 51, 51, 53, 53, 54, 54, 54, 56, 56, 57, 57, 57, 59, 59, 60, 60, 60, 60, 62, 62, 63, 63, 63, 65, 65, 66, 66, 68, 73, 75, 75, 76, 76, 77, 83, 83, 0, 0, 0, 84, 86, 87, 87, 87, 87, 0, 0, 0, 87, 87, 0, 87, 87, 0, 0, 0, 0, 0, 88, 88, 89, 90, 90, 91, 93, 95, 0, 95, 95, 97, 97, 98, 99, 100, 100, 100, 100, 0, 0, 0, 102, 102, 102, 102, 103, 103, 103, 0, 0, 0, 105, 105, 105, 108, 108, 109, 109, 111, 111, 111, 112, 112, 113, 113, 113, 113, 116, 116, 117, 117, 118, 118, 120, 120, 120, 121, 121, 122, 122, 125, 126, 131, 131, 132, 132, 135, 135, 135, 135, 136, 136, 138, 138, 138, 140, 140, 141, 141, 142, 142, 144, 144, 145, 145, 146, 146, 148, 148, 148, 150, 151, 158, 158, 158, 158, 159, 159, 159, 0, 0, 0, 160, 160, 160, 162, 162, 162, 165, 165, 168, 168, 170, 170, 171, 171, 173, 175, 177, 178, 178, 178, 179, 183, 183, 184, 184, 184, 185, 185, 186, 188, 188, 189, 189, 190, 190, 190, 190, 0, 0, 0, 191, 191, 191, 191, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 195, 196, 196, 196, 196, 198, 200, 201, 201, 201, 202, 210, 211, 212, 213, 213, 213, 213, 0, 0, 0, 213, 213, 0, 0, 0, 214, 0, 214, 214, 215, 215, 215, 216, 216, 216, 217, 217, 217, 222, 223, 231, 231, 232, 232, 234, 234, 237, 242, 242, 244, 244, 244, 244, 249, 249, 253, 257, 257, 0, 257, 257, 257, 0, 0, 258, 260, 260, 260, 260, 261, 261, 261, 262, 263, 264, 265, 265, 266, 266, 268, 268, 268, 269, 269, 269, 269, 269, 270, 265, 273, 277, 277, 0, 277, 277, 277, 0, 0, 278, 280, 280, 280, 280, 281, 281, 281, 282, 283, 283, 284, 284, 285, 285, 285, 285, 285, 283, 288, 294, 298, 299, 300, 301, 301, 302, 302, 303, 0, 303, 303, 304, 307, 311, 315, 315, 316, 318, 322, 322, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {103, 135, 136, 137, 142, 143, 144, 145, 147, 152, 153, 154, 155, 157, 162, 163, 164, 165, 167, 172, 173, 174, 175, 177, 182, 183, 184, 185, 187, 192, 193, 194, 195, 197, 202, 203, 204, 205, 206, 208, 213, 214, 215, 216, 218, 223, 224, 225, 227, 235, 239, 240, 241, 246, 248, 394, 399, 401, 404, 408, 411, 413, 414, 419, 420, 425, 426, 429, 433, 436, 437, 439, 442, 443, 445, 448, 452, 455, 459, 462, 463, 464, 465, 466, 468, 471, 473, 473, 476, 478, 479, 480, 481, 482, 483, 488, 489, 490, 492, 495, 499, 502, 503, 504, 505, 506, 511, 512, 514, 517, 521, 524, 525, 526, 528, 529, 530, 535, 536, 537, 538, 539, 540, 542, 543, 544, 545, 547, 548, 549, 554, 555, 556, 557, 558, 559, 560, 561, 563, 564, 566, 568, 574, 575, 576, 581, 582, 583, 584, 585, 586, 591, 592, 593, 594, 595, 596, 597, 602, 603, 604, 605, 606, 607, 612, 613, 614, 616, 617, 618, 619, 621, 629, 630, 631, 632, 633, 638, 639, 641, 644, 648, 651, 652, 653, 656, 657, 658, 661, 666, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 683, 684, 685, 686, 687, 689, 690, 691, 692, 693, 694, 695, 696, 701, 702, 703, 705, 708, 712, 715, 716, 717, 718, 719, 724, 725, 726, 728, 731, 735, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 763, 764, 765, 768, 773, 774, 779, 780, 783, 787, 790, 791, 793, 796, 800, 803, 803, 806, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 823, 824, 836, 837, 838, 843, 844, 845, 847, 855, 856, 857, 858, 859, 860, 866, 867, 872, 900, 905, 906, 909, 910, 911, 913, 916, 920, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 935, 937, 938, 939, 940, 941, 942, 943, 944, 946, 947, 949, 950, 956, 979, 984, 985, 988, 989, 990, 992, 995, 999, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1012, 1014, 1015, 1016, 1017, 1018, 1020, 1021, 1023, 1029, 1032, 1042, 1043, 1044, 1045, 1050, 1051, 1052, 1053, 1053, 1056, 1058, 1059, 1066, 1069, 1073, 1078, 1079, 1081, 1086, 1087, 1091, 1094, 1098, 1102, 1105, 1109, 1112, 1116, 1119, 1123, 1126, 1130, 1133, 1137, 1141, 1144, 1148, 1151};
/* BEGIN LINEINFO 
assign 1 33 103
translateEmittedException 0 37 135
assign 1 40 136
new 0 40 136
assign 1 41 137
def 1 41 142
assign 1 42 143
new 0 42 143
assign 1 42 144
add 1 42 144
assign 1 42 145
add 1 42 145
assign 1 44 147
def 1 44 152
assign 1 45 153
new 0 45 153
assign 1 45 154
add 1 45 154
assign 1 45 155
add 1 45 155
assign 1 47 157
def 1 47 162
assign 1 48 163
new 0 48 163
assign 1 48 164
add 1 48 164
assign 1 48 165
add 1 48 165
assign 1 50 167
def 1 50 172
assign 1 51 173
new 0 51 173
assign 1 51 174
add 1 51 174
assign 1 51 175
add 1 51 175
assign 1 53 177
def 1 53 182
assign 1 54 183
new 0 54 183
assign 1 54 184
add 1 54 184
assign 1 54 185
add 1 54 185
assign 1 56 187
def 1 56 192
assign 1 57 193
new 0 57 193
assign 1 57 194
add 1 57 194
assign 1 57 195
add 1 57 195
assign 1 59 197
def 1 59 202
assign 1 60 203
new 0 60 203
assign 1 60 204
add 1 60 204
assign 1 60 205
toString 0 60 205
assign 1 60 206
add 1 60 206
assign 1 62 208
def 1 62 213
assign 1 63 214
new 0 63 214
assign 1 63 215
add 1 63 215
assign 1 63 216
add 1 63 216
assign 1 65 218
def 1 65 223
assign 1 66 224
getFrameText 0 66 224
assign 1 66 225
add 1 66 225
return 1 68 227
translateEmittedExceptionInner 0 73 235
assign 1 75 239
new 0 75 239
print 0 75 240
assign 1 76 241
def 1 76 246
print 0 77 248
assign 1 83 394
def 1 83 399
assign 1 0 401
assign 1 0 404
assign 1 0 408
return 1 84 411
assign 1 86 413
new 0 86 413
assign 1 87 414
def 1 87 419
assign 1 87 420
def 1 87 425
assign 1 0 426
assign 1 0 429
assign 1 0 433
assign 1 87 436
new 0 87 436
assign 1 87 437
equals 1 87 437
assign 1 0 439
assign 1 87 442
new 0 87 442
assign 1 87 443
equals 1 87 443
assign 1 0 445
assign 1 0 448
assign 1 0 452
assign 1 0 455
assign 1 0 459
assign 1 88 462
new 0 88 462
assign 1 88 463
new 1 88 463
assign 1 89 464
tokenize 1 89 464
assign 1 90 465
new 0 90 465
assign 1 90 466
equals 1 90 466
assign 1 91 468
new 0 91 468
assign 1 93 471
new 0 93 471
assign 1 95 473
iteratorGet 0 0 473
assign 1 95 476
hasNextGet 0 95 476
assign 1 95 478
nextGet 0 95 478
assign 1 97 479
new 0 97 479
assign 1 97 480
find 1 97 480
assign 1 98 481
assign 1 99 482
assign 1 100 483
def 1 100 488
assign 1 100 489
new 0 100 489
assign 1 100 490
greaterEquals 1 100 490
assign 1 0 492
assign 1 0 495
assign 1 0 499
assign 1 102 502
new 0 102 502
assign 1 102 503
new 0 102 503
assign 1 102 504
add 1 102 504
assign 1 102 505
find 2 102 505
assign 1 103 506
def 1 103 511
assign 1 103 512
greater 1 103 512
assign 1 0 514
assign 1 0 517
assign 1 0 521
assign 1 105 524
new 0 105 524
assign 1 105 525
add 1 105 525
assign 1 105 526
substring 2 105 526
assign 1 108 528
new 0 108 528
assign 1 108 529
find 2 108 529
assign 1 109 530
def 1 109 535
assign 1 111 536
new 0 111 536
assign 1 111 537
add 1 111 537
assign 1 111 538
substring 1 111 538
assign 1 112 539
new 0 112 539
assign 1 112 540
ends 1 112 540
assign 1 113 542
sizeGet 0 113 542
assign 1 113 543
new 0 113 543
assign 1 113 544
subtract 1 113 544
sizeSet 1 113 545
assign 1 116 547
new 0 116 547
assign 1 116 548
rfind 1 116 548
assign 1 117 549
def 1 117 554
assign 1 118 555
new 0 118 555
assign 1 118 556
substring 2 118 556
assign 1 120 557
new 0 120 557
assign 1 120 558
add 1 120 558
assign 1 120 559
substring 1 120 559
assign 1 121 560
new 0 121 560
assign 1 121 561
begins 1 121 561
assign 1 122 563
new 0 122 563
assign 1 122 564
substring 1 122 564
assign 1 125 566
isInteger 0 125 566
assign 1 126 568
new 1 126 568
assign 1 131 574
new 0 131 574
assign 1 131 575
find 2 131 575
assign 1 132 576
def 1 132 581
assign 1 135 582
new 0 135 582
assign 1 135 583
new 0 135 583
assign 1 135 584
add 1 135 584
assign 1 135 585
find 2 135 585
assign 1 136 586
def 1 136 591
assign 1 138 592
new 0 138 592
assign 1 138 593
add 1 138 593
assign 1 138 594
substring 2 138 594
assign 1 140 595
new 0 140 595
assign 1 140 596
rfind 1 140 596
assign 1 141 597
def 1 141 602
assign 1 142 603
new 0 142 603
assign 1 142 604
substring 2 142 604
assign 1 144 605
new 0 144 605
assign 1 144 606
rfind 1 144 606
assign 1 145 607
def 1 145 612
assign 1 146 613
new 0 146 613
assign 1 146 614
substring 2 146 614
assign 1 148 616
new 0 148 616
assign 1 148 617
add 1 148 617
assign 1 148 618
substring 1 148 618
assign 1 150 619
isInteger 0 150 619
assign 1 151 621
new 1 151 621
assign 1 158 629
new 0 158 629
assign 1 158 630
new 0 158 630
assign 1 158 631
add 1 158 631
assign 1 158 632
find 2 158 632
assign 1 159 633
def 1 159 638
assign 1 159 639
greater 1 159 639
assign 1 0 641
assign 1 0 644
assign 1 0 648
assign 1 160 651
new 0 160 651
assign 1 160 652
add 1 160 652
assign 1 160 653
substring 2 160 653
assign 1 162 656
new 0 162 656
assign 1 162 657
add 1 162 657
assign 1 162 658
substring 1 162 658
assign 1 165 661
def 1 165 666
assign 1 168 668
new 0 168 668
assign 1 168 669
split 1 168 669
assign 1 170 670
new 0 170 670
assign 1 170 671
get 1 170 671
assign 1 171 672
new 0 171 672
assign 1 171 673
get 1 171 673
assign 1 173 674
extractKlass 1 173 674
assign 1 175 675
extractMethod 1 175 675
assign 1 177 676
new 4 177 676
assign 1 178 677
klassNameGet 0 178 677
assign 1 178 678
getSourceFileName 1 178 678
fileNameSet 1 178 679
addFrame 1 179 680
assign 1 183 683
new 0 183 683
assign 1 183 684
split 1 183 684
assign 1 184 685
sizeGet 0 184 685
assign 1 184 686
new 0 184 686
assign 1 184 687
greater 1 184 687
assign 1 185 689
new 0 185 689
assign 1 185 690
get 1 185 690
assign 1 186 691
extractMethod 1 186 691
assign 1 188 692
new 0 188 692
assign 1 188 693
get 1 188 693
assign 1 189 694
new 0 189 694
assign 1 189 695
find 1 189 695
assign 1 190 696
def 1 190 701
assign 1 190 702
new 0 190 702
assign 1 190 703
greater 1 190 703
assign 1 0 705
assign 1 0 708
assign 1 0 712
assign 1 191 715
new 0 191 715
assign 1 191 716
new 0 191 716
assign 1 191 717
add 1 191 717
assign 1 191 718
find 2 191 718
assign 1 192 719
def 1 192 724
assign 1 192 725
new 0 192 725
assign 1 192 726
greater 1 192 726
assign 1 0 728
assign 1 0 731
assign 1 0 735
assign 1 193 738
new 0 193 738
assign 1 193 739
add 1 193 739
assign 1 193 740
substring 2 193 740
assign 1 195 741
new 1 195 741
assign 1 196 742
new 0 196 742
assign 1 196 743
add 1 196 743
assign 1 196 744
add 1 196 744
assign 1 196 745
substring 1 196 745
assign 1 198 746
extractKlass 1 198 746
assign 1 200 747
new 4 200 747
assign 1 201 748
klassNameGet 0 201 748
assign 1 201 749
getSourceFileName 1 201 749
fileNameSet 1 201 750
addFrame 1 202 751
assign 1 210 763
assign 1 211 764
new 0 211 764
assign 1 212 765
assign 1 213 768
def 1 213 773
assign 1 213 774
def 1 213 779
assign 1 0 780
assign 1 0 783
assign 1 0 787
assign 1 213 790
new 0 213 790
assign 1 213 791
equals 1 213 791
assign 1 0 793
assign 1 0 796
assign 1 0 800
assign 1 214 803
iteratorGet 0 0 803
assign 1 214 806
hasNextGet 0 214 806
assign 1 214 808
nextGet 0 214 808
assign 1 215 809
klassNameGet 0 215 809
assign 1 215 810
extractKlassLib 1 215 810
klassNameSet 1 215 811
assign 1 216 812
methodNameGet 0 216 812
assign 1 216 813
extractMethod 1 216 813
methodNameSet 1 216 814
assign 1 217 815
klassNameGet 0 217 815
assign 1 217 816
getSourceFileName 1 217 816
fileNameSet 1 217 817
assign 1 222 823
assign 1 223 824
new 0 223 824
assign 1 231 836
new 0 231 836
assign 1 231 837
createInstance 2 231 837
assign 1 232 838
def 1 232 843
assign 1 234 844
sourceFileNameGet 0 234 844
return 1 234 845
return 1 237 847
assign 1 242 855
new 0 242 855
assign 1 242 856
split 1 242 856
assign 1 244 857
new 0 244 857
assign 1 244 858
get 1 244 858
assign 1 244 859
extractKlass 1 244 859
return 1 244 860
assign 1 249 866
extractKlassInner 1 249 866
return 1 249 867
return 1 253 872
assign 1 257 900
undef 1 257 905
assign 1 0 906
assign 1 257 909
new 0 257 909
assign 1 257 910
begins 1 257 910
assign 1 257 911
not 0 257 911
assign 1 0 913
assign 1 0 916
return 1 258 920
assign 1 260 922
new 0 260 922
assign 1 260 923
substring 1 260 923
assign 1 260 924
new 0 260 924
assign 1 260 925
split 1 260 925
assign 1 261 926
sizeGet 0 261 926
assign 1 261 927
new 0 261 927
assign 1 261 928
subtract 1 261 928
assign 1 262 929
get 1 262 929
assign 1 263 930
new 0 263 930
assign 1 264 931
new 0 264 931
assign 1 265 932
new 0 265 932
assign 1 265 935
lesser 1 265 935
assign 1 266 937
get 1 266 937
assign 1 266 938
new 1 266 938
assign 1 268 939
add 1 268 939
assign 1 268 940
substring 2 268 940
addValue 1 268 941
assign 1 269 942
new 0 269 942
assign 1 269 943
add 1 269 943
assign 1 269 944
lesser 1 269 944
assign 1 269 946
new 0 269 946
addValue 1 269 947
addValue 1 270 949
incrementValue 0 265 950
return 1 273 956
assign 1 277 979
undef 1 277 984
assign 1 0 985
assign 1 277 988
new 0 277 988
assign 1 277 989
begins 1 277 989
assign 1 277 990
not 0 277 990
assign 1 0 992
assign 1 0 995
return 1 278 999
assign 1 280 1001
new 0 280 1001
assign 1 280 1002
substring 1 280 1002
assign 1 280 1003
new 0 280 1003
assign 1 280 1004
split 1 280 1004
assign 1 281 1005
sizeGet 0 281 1005
assign 1 281 1006
new 0 281 1006
assign 1 281 1007
subtract 1 281 1007
assign 1 282 1008
new 0 282 1008
assign 1 283 1009
new 0 283 1009
assign 1 283 1012
lesser 1 283 1012
assign 1 284 1014
get 1 284 1014
addValue 1 284 1015
assign 1 285 1016
new 0 285 1016
assign 1 285 1017
add 1 285 1017
assign 1 285 1018
lesser 1 285 1018
assign 1 285 1020
new 0 285 1020
addValue 1 285 1021
incrementValue 0 283 1023
return 1 288 1029
return 1 294 1032
translateEmittedException 0 298 1042
assign 1 299 1043
new 0 299 1043
assign 1 300 1044
framesGet 0 300 1044
assign 1 301 1045
def 1 301 1050
assign 1 302 1051
new 0 302 1051
assign 1 302 1052
add 1 302 1052
assign 1 303 1053
iteratorGet 0 0 1053
assign 1 303 1056
hasNextGet 0 303 1056
assign 1 303 1058
nextGet 0 303 1058
assign 1 304 1059
add 1 304 1059
return 1 307 1066
return 1 311 1069
assign 1 315 1073
undef 1 315 1078
assign 1 316 1079
new 0 316 1079
addValue 1 318 1081
assign 1 322 1086
new 4 322 1086
addFrame 1 322 1087
return 1 0 1091
assign 1 0 1094
assign 1 0 1098
return 1 0 1102
assign 1 0 1105
return 1 0 1109
assign 1 0 1112
return 1 0 1116
assign 1 0 1119
return 1 0 1123
assign 1 0 1126
return 1 0 1130
assign 1 0 1133
assign 1 0 1137
return 1 0 1141
assign 1 0 1144
return 1 0 1148
assign 1 0 1151
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case 1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case 1184167343: return bem_translatedGet_0();
case 764669899: return bem_getFrameText_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case 1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 970476426: return bem_translateEmittedExceptionInner_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 845792839: return bem_iteratorGet_0();
case 1141730732: return bem_framesTextGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1286797640: return bem_extractKlassLib_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2124977673: return bem_extractKlassInner_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case 813541388: return bem_extractMethod_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1173085090: return bem_translatedSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 205231606: return bem_getSourceFileName_1((BEC_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_9_5_ExceptionFrame) bevd_0);
case 371136143: return bem_extractKlass_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1130648479: return bem_framesTextSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_9_SystemException();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_9_SystemException.bevs_inst = (BEC_6_9_SystemException)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_9_SystemException.bevs_inst;
}
}
}
