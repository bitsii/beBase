namespace be.BEL_4_Base {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller : BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
static BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
public static new BEC_2_4_12_JsonUnmarshaller bevs_inst;
public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_10_ContainerLinkedList bevp_ll;
public BEC_2_6_6_SystemObject bevp_key;
public BEC_2_6_6_SystemObject bevp_top;
public BEC_2_9_5_ContainerStack bevp_stack;
public BEC_2_5_4_LogicBool bevp_inList;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_parser = (BEC_2_4_6_JsonParser) (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_ll = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_parser == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 481 */ {
this.bem_new_0();
} /* Line: 482 */
bevp_key = null;
bevp_top = null;
bevp_stack = (BEC_2_9_5_ContainerStack) (new BEC_2_9_5_ContainerStack()).bem_new_0();
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parser.bem_parse_2(beva_str, this);
return bevp_top;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_beginMap_0() {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_m = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 496 */ {
this.bem_addItem_1(bevl_m);
bevp_stack.bem_push_1(bevp_top);
} /* Line: 498 */
bevp_top = bevl_m;
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_endMap_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_stack.bem_isEmptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 506 */ {
bevp_top = bevp_stack.bem_pop_0();
bevt_2_tmpvar_phold = bevp_top.bemd_1(631500772, BEL_4_Base.bevn_sameClass_1, bevp_ll);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 509 */ {
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 510 */
 else  /* Line: 511 */ {
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 512 */
} /* Line: 509 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_kvMid_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_beginList_0() {
BEC_2_9_5_ContainerArray bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_l = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_0();
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 524 */ {
this.bem_addItem_1(bevl_l);
bevp_stack.bem_push_1(bevp_top);
} /* Line: 526 */
bevp_top = bevl_l;
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_endList_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_stack.bem_isEmptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 534 */ {
bevp_top = bevp_stack.bem_pop_0();
bevt_2_tmpvar_phold = bevp_top.bemd_1(631500772, BEL_4_Base.bevn_sameClass_1, bevp_ll);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 537 */ {
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 538 */
 else  /* Line: 539 */ {
bevp_inList = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 540 */
} /* Line: 537 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addItem_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 546 */ {
if (bevp_inList.bevi_bool) /* Line: 548 */ {
bevp_top.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_item);
} /* Line: 549 */
 else  /* Line: 550 */ {
if (bevp_key == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 553 */ {
bevp_key = beva_item;
} /* Line: 554 */
 else  /* Line: 555 */ {
bevp_top.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevp_key, beva_item);
bevp_key = null;
} /* Line: 557 */
} /* Line: 553 */
} /* Line: 548 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_handleString_1(BEC_2_4_6_TextString beva_str) {
this.bem_addItem_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_handleTrue_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
this.bem_addItem_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_handleFalse_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
this.bem_addItem_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_handleNull_0() {
this.bem_addItem_1(null);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) {
this.bem_addItem_1(beva_int);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parserGet_0() {
return bevp_parser;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_llGet_0() {
return bevp_ll;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_llSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ll = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_keyGet_0() {
return bevp_key;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_keySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_key = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_topGet_0() {
return bevp_top;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_top = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_stackGet_0() {
return bevp_stack;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_inListGet_0() {
return bevp_inList;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inList = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {470, 471, 476, 481, 481, 482, 484, 485, 486, 487, 489, 490, 495, 496, 496, 497, 498, 500, 501, 506, 506, 507, 509, 510, 512, 523, 524, 524, 525, 526, 528, 529, 534, 534, 535, 537, 538, 540, 546, 546, 549, 553, 553, 554, 556, 557, 566, 571, 571, 576, 576, 581, 586, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 18, 23, 28, 29, 31, 32, 33, 34, 35, 36, 41, 42, 47, 48, 49, 51, 52, 59, 60, 62, 63, 65, 68, 79, 80, 85, 86, 87, 89, 90, 97, 98, 100, 101, 103, 106, 114, 119, 121, 124, 129, 130, 133, 134, 141, 146, 147, 152, 153, 157, 161, 165, 168, 172, 175, 179, 182, 186, 189, 193, 196, 200, 203};
/* BEGIN LINEINFO 
assign 1 470 16
new 0 470 16
assign 1 471 17
new 0 471 17
assign 1 476 18
new 0 476 18
assign 1 481 23
undef 1 481 28
new 0 482 29
assign 1 484 31
assign 1 485 32
assign 1 486 33
new 0 486 33
assign 1 487 34
new 0 487 34
parse 2 489 35
return 1 490 36
assign 1 495 41
new 0 495 41
assign 1 496 42
def 1 496 47
addItem 1 497 48
push 1 498 49
assign 1 500 51
assign 1 501 52
new 0 501 52
assign 1 506 59
isEmptyGet 0 506 59
assign 1 506 60
not 0 506 60
assign 1 507 62
pop 0 507 62
assign 1 509 63
sameClass 1 509 63
assign 1 510 65
new 0 510 65
assign 1 512 68
new 0 512 68
assign 1 523 79
new 0 523 79
assign 1 524 80
def 1 524 85
addItem 1 525 86
push 1 526 87
assign 1 528 89
assign 1 529 90
new 0 529 90
assign 1 534 97
isEmptyGet 0 534 97
assign 1 534 98
not 0 534 98
assign 1 535 100
pop 0 535 100
assign 1 537 101
sameClass 1 537 101
assign 1 538 103
new 0 538 103
assign 1 540 106
new 0 540 106
assign 1 546 114
def 1 546 119
addValue 1 549 121
assign 1 553 124
undef 1 553 129
assign 1 554 130
put 2 556 133
assign 1 557 134
addItem 1 566 141
assign 1 571 146
new 0 571 146
addItem 1 571 147
assign 1 576 152
new 0 576 152
addItem 1 576 153
addItem 1 581 157
addItem 1 586 161
return 1 0 165
assign 1 0 168
return 1 0 172
assign 1 0 175
return 1 0 179
assign 1 0 182
return 1 0 186
assign 1 0 189
return 1 0 193
assign 1 0 196
return 1 0 200
assign 1 0 203
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1398681994: return bem_endList_0();
case 1095000804: return bem_beginMap_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 914308068: return bem_inListGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 506014516: return bem_handleFalse_0();
case 167292072: return bem_parserGet_0();
case 435843368: return bem_beginList_0();
case 1308786538: return bem_echo_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1431394368: return bem_handleNull_0();
case 368775858: return bem_kvMid_0();
case 1708368370: return bem_endMap_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 478524008: return bem_keyGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 1262128633: return bem_handleTrue_0();
case 988612302: return bem_topGet_0();
case 287040793: return bem_hashGet_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 226791399: return bem_llGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 845792839: return bem_iteratorGet_0();
case 2013904863: return bem_stackGet_0();
case 314718434: return bem_print_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 178374325: return bem_parserSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2024987116: return bem_stackSet_1(bevd_0);
case 489606261: return bem_keySet_1(bevd_0);
case 925390321: return bem_inListSet_1(bevd_0);
case 1512002600: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 977530049: return bem_topSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1818023961: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1774332469: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case 237873652: return bem_llSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 285821434: return bem_addItem_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_JsonUnmarshaller();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_JsonUnmarshaller.bevs_inst = (BEC_2_4_12_JsonUnmarshaller)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_JsonUnmarshaller.bevs_inst;
}
}
}
