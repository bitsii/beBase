namespace be.BEL_4_Base {
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_8_ContainerLinkedListIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_10_8_ContainerLinkedListIterator() { }
static BEC_3_9_10_8_ContainerLinkedListIterator() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_3_9_10_8_ContainerLinkedListIterator bevs_inst;
public BEC_2_9_10_ContainerLinkedList bevp_list;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_currNode;
public BEC_2_5_4_LogicBool bevp_starting;
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_new_1(BEC_2_9_10_ContainerLinkedList beva_l) {
bevp_list = beva_l;
bevp_starting = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_containerGet_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 453 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 454 */
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
if (bevp_starting.bevi_bool) /* Line: 460 */ {
bevt_2_tmpvar_phold = bevp_list.bem_firstNodeGet_0();
if (bevt_2_tmpvar_phold == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 461 */ {
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 462 */
 else  /* Line: 463 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 464 */
} /* Line: 461 */
if (bevp_currNode == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 467 */ {
bevt_7_tmpvar_phold = bevp_currNode.bem_nextGet_0();
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 467 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 467 */ {
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 468 */
bevt_9_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_9_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_nxnode = (BEC_3_9_10_4_ContainerLinkedListNode) this.bem_nextNodeGet_0();
if (bevl_nxnode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 475 */ {
bevp_list.bem_addValue_1(beva_value);
this.bem_nextNodeGet_0();
} /* Line: 477 */
 else  /* Line: 478 */ {
bevl_nxnode.bem_heldSet_1(beva_value);
} /* Line: 479 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextNodeGet_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_starting.bevi_bool) /* Line: 485 */ {
bevp_starting = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 487 */
 else  /* Line: 488 */ {
if (bevp_currNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 489 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 490 */
} /* Line: 489 */
bevp_currNode = bevl_nxnode;
return bevp_currNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentNodeGet_0() {
return bevp_currNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva__currNode) {
bevp_starting = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva__currNode;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 507 */ {
return null;
} /* Line: 508 */
bevt_1_tmpvar_phold = bevp_currNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 515 */
bevp_currNode.bem_heldSet_1(beva_x);
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_starting.bevi_bool) /* Line: 523 */ {
bevp_starting = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 525 */
 else  /* Line: 526 */ {
if (bevp_currNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 527 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 528 */
} /* Line: 527 */
bevp_currNode = bevl_nxnode;
if (bevp_currNode == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 532 */ {
bevt_2_tmpvar_phold = bevp_currNode.bem_heldGet_0();
return bevt_2_tmpvar_phold;
} /* Line: 533 */
return bevp_currNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 539 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 539 */ {
this.bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 539 */
 else  /* Line: 539 */ {
break;
} /* Line: 539 */
} /* Line: 539 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_listGet_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGet_0() {
return bevp_currNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startingGet_0() {
return bevp_starting;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_startingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {441, 443, 449, 453, 453, 454, 454, 456, 456, 461, 461, 461, 462, 462, 464, 464, 467, 467, 0, 467, 467, 467, 0, 0, 468, 468, 470, 470, 474, 475, 475, 476, 477, 479, 486, 487, 489, 489, 490, 493, 494, 498, 502, 503, 507, 507, 508, 510, 510, 514, 514, 515, 515, 517, 518, 518, 524, 525, 527, 527, 528, 531, 532, 532, 533, 533, 535, 539, 539, 539, 540, 539, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {13, 14, 18, 24, 29, 30, 31, 33, 34, 48, 49, 54, 55, 56, 59, 60, 63, 68, 69, 72, 73, 78, 79, 82, 86, 87, 89, 90, 95, 96, 101, 102, 103, 106, 114, 115, 118, 123, 124, 127, 128, 131, 134, 135, 141, 146, 147, 149, 150, 156, 161, 162, 163, 165, 166, 167, 175, 176, 179, 184, 185, 188, 189, 194, 195, 196, 198, 203, 206, 211, 212, 213, 222, 225, 229, 232, 236, 239};
/* BEGIN LINEINFO 
assign 1 441 13
assign 1 443 14
new 0 443 14
return 1 449 18
assign 1 453 24
undef 1 453 29
assign 1 454 30
new 0 454 30
return 1 454 31
assign 1 456 33
new 0 456 33
return 1 456 34
assign 1 461 48
firstNodeGet 0 461 48
assign 1 461 49
undef 1 461 54
assign 1 462 55
new 0 462 55
return 1 462 56
assign 1 464 59
new 0 464 59
return 1 464 60
assign 1 467 63
undef 1 467 68
assign 1 0 69
assign 1 467 72
nextGet 0 467 72
assign 1 467 73
undef 1 467 78
assign 1 0 79
assign 1 0 82
assign 1 468 86
new 0 468 86
return 1 468 87
assign 1 470 89
new 0 470 89
return 1 470 90
assign 1 474 95
nextNodeGet 0 474 95
assign 1 475 96
undef 1 475 101
addValue 1 476 102
nextNodeGet 0 477 103
heldSet 1 479 106
assign 1 486 114
new 0 486 114
assign 1 487 115
firstNodeGet 0 487 115
assign 1 489 118
def 1 489 123
assign 1 490 124
nextGet 0 490 124
assign 1 493 127
return 1 494 128
return 1 498 131
assign 1 502 134
new 0 502 134
assign 1 503 135
assign 1 507 141
undef 1 507 146
return 1 508 147
assign 1 510 149
heldGet 0 510 149
return 1 510 150
assign 1 514 156
undef 1 514 161
assign 1 515 162
new 0 515 162
return 1 515 163
heldSet 1 517 165
assign 1 518 166
new 0 518 166
return 1 518 167
assign 1 524 175
new 0 524 175
assign 1 525 176
firstNodeGet 0 525 176
assign 1 527 179
def 1 527 184
assign 1 528 185
nextGet 0 528 185
assign 1 531 188
assign 1 532 189
def 1 532 194
assign 1 533 195
heldGet 0 533 195
return 1 533 196
return 1 535 198
assign 1 539 203
new 0 539 203
assign 1 539 206
lesser 1 539 211
nextSet 1 540 212
incrementValue 0 539 213
return 1 0 222
assign 1 0 225
return 1 0 229
assign 1 0 232
return 1 0 236
assign 1 0 239
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1582066476: return bem_currentNodeGet_0();
case 1816451342: return bem_nextNodeGet_0();
case 104713553: return bem_new_0();
case 1766138515: return bem_currNodeGet_0();
case 1246679159: return bem_listGet_0();
case 1693924536: return bem_hasCurrentGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 232617255: return bem_startingGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case 1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 1593148729: return bem_currentNodeSet_1(bevd_0);
case 900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1777220768: return bem_currNodeSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1235596906: return bem_listSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 243699508: return bem_startingSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_10_8_ContainerLinkedListIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_10_8_ContainerLinkedListIterator.bevs_inst = (BEC_3_9_10_8_ContainerLinkedListIterator)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_10_8_ContainerLinkedListIterator.bevs_inst;
}
}
}
