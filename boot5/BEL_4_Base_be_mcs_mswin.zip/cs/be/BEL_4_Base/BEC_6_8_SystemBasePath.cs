namespace be.BEL_4_Base {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_6_8_SystemBasePath : BEC_6_6_SystemObject {
public BEC_6_8_SystemBasePath() { }
static BEC_6_8_SystemBasePath() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
public static new BEC_6_8_SystemBasePath bevs_inst;
public BEC_4_6_TextString bevp_separator;
public BEC_4_6_TextString bevp_path;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_new_1(BEC_4_6_TextString beva_spath) {
bevp_separator = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromString_1(BEC_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_4_6_TextString bem_toString_1(BEC_4_6_TextString beva_newsep) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_toStringWithSeparator_1(BEC_4_6_TextString beva_newsep) {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_4_6_TextString bevl_npath = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_npath = bevt_0_tmpvar_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_firstStepGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lastStepGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_add_1(BEC_6_6_SystemObject beva_other) {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_ContainerLinkedList bevl_spath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_l = null;
BEC_4_6_TextString bevl_rstr = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_emptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 382 */ {
bevt_4_tmpvar_phold = this.bem_copy_0();
return (BEC_6_8_SystemBasePath) bevt_4_tmpvar_phold;
} /* Line: 383 */
bevt_5_tmpvar_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 385 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_6_8_SystemBasePath) bevt_6_tmpvar_phold;
} /* Line: 386 */
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_9_10_ContainerLinkedList) bevt_7_tmpvar_phold.bemd_1(2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_iteratorGet_0();
while (true)
 /* Line: 390 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 390 */ {
bevl_l = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 392 */
 else  /* Line: 390 */ {
break;
} /* Line: 390 */
} /* Line: 390 */
bevt_9_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_rstr = bevt_9_tmpvar_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevl_rpath = (BEC_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return bevl_rpath;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_parentGet_0() {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_4_3_MathInt bevl_rpl = null;
BEC_4_3_MathInt bevl_c = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpvar_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_iteratorGet_0();
while (true)
 /* Line: 408 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 408 */ {
bevt_2_tmpvar_phold = bevl_c.bem_lesser_1(bevl_rpl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_3_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_rpath.bem_addStep_1(bevt_3_tmpvar_phold);
} /* Line: 410 */
 else  /* Line: 411 */ {
bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 412 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 414 */
 else  /* Line: 408 */ {
break;
} /* Line: 408 */
} /* Line: 408 */
bevt_4_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 416 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 417 */
return bevl_rpath;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (bevp_path == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_4_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 423 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 423 */ {
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 423 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevp_path.bem_getPoint_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_10_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 425 */
bevt_11_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 431 */ {
bevt_1_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
} /* Line: 432 */
return this;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_isAbsoluteGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 437 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 438 */
return this;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_trimParents_1(BEC_4_3_MathInt beva_howMany) {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = beva_howMany.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 443 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 448 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_howMany);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 448 */ {
if (bevl_next == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 449 */ {
break;
} /* Line: 449 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 448 */
 else  /* Line: 448 */ {
break;
} /* Line: 448 */
} /* Line: 448 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 454 */
return this;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_addStep_1(BEC_6_6_SystemObject beva_step) {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_4_3_MathInt bevl_fp = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 466 */ {
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevp_path = bevt_1_tmpvar_phold.bem_emptyGet_0();
} /* Line: 467 */
 else  /* Line: 468 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_2_tmpvar_phold = bevl_fp.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
} /* Line: 469 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addStepList_1(BEC_9_10_ContainerLinkedList beva_sl) {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_iteratorGet_0();
while (true)
 /* Line: 475 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 475 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevt_1_tmpvar_phold);
} /* Line: 476 */
 else  /* Line: 475 */ {
break;
} /* Line: 475 */
} /* Line: 475 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addSteps_1(BEC_6_6_SystemObject beva_step) {
BEC_6_8_SystemBasePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_addStep_1(beva_step);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addSteps_2(BEC_6_6_SystemObject beva_s1, BEC_6_6_SystemObject beva_s2) {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_6_8_SystemBasePath bevl_other = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_other = (BEC_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpvar_phold);
return bevl_other;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_3_MathInt bem_hashGet_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_x) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_x) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_x == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_3_tmpvar_phold = beva_x.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 515 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 515 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 515 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_5_tmpvar_phold = beva_x.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpvar_phold = bevp_path.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 515 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 515 */ {
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 516 */
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_subPath_1(BEC_4_3_MathInt beva_start) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_subPath_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_9_10_ContainerLinkedList bevl_st = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_res = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 527 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 528 */
 else  /* Line: 529 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 530 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_1_tmpvar_phold = BEC_4_7_TextStrings.bevs_inst.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpvar_phold);
return bevl_res;
} /*method end*/
public virtual BEC_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_separatorSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_separator = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_pathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_path = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {343, 343, 347, 348, 352, 356, 360, 360, 364, 365, 365, 366, 370, 370, 374, 374, 374, 378, 378, 378, 382, 382, 382, 382, 383, 383, 385, 386, 386, 388, 389, 389, 390, 390, 391, 392, 394, 394, 395, 396, 398, 402, 403, 404, 404, 405, 406, 407, 408, 408, 409, 410, 410, 412, 414, 416, 417, 419, 423, 423, 0, 423, 423, 423, 423, 0, 0, 423, 423, 424, 424, 424, 425, 425, 427, 427, 431, 432, 432, 432, 437, 437, 438, 443, 443, 444, 445, 447, 448, 448, 449, 449, 450, 451, 452, 448, 454, 459, 460, 461, 465, 466, 466, 467, 467, 469, 469, 469, 469, 474, 475, 475, 476, 476, 478, 482, 482, 486, 487, 488, 489, 493, 494, 495, 495, 496, 500, 500, 504, 504, 508, 508, 508, 515, 515, 0, 515, 0, 0, 0, 515, 515, 0, 0, 516, 516, 518, 518, 522, 522, 526, 527, 527, 528, 530, 532, 533, 534, 534, 535, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 29, 30, 34, 38, 42, 43, 49, 50, 51, 52, 56, 57, 62, 63, 64, 69, 70, 71, 90, 91, 92, 93, 95, 96, 98, 100, 101, 103, 104, 105, 106, 109, 111, 112, 118, 119, 120, 121, 122, 135, 136, 137, 138, 139, 140, 141, 142, 145, 147, 149, 150, 153, 155, 161, 163, 165, 180, 185, 186, 189, 190, 191, 192, 194, 197, 201, 202, 204, 205, 206, 208, 209, 211, 212, 218, 220, 221, 222, 229, 230, 232, 245, 246, 248, 249, 250, 251, 254, 256, 261, 264, 265, 266, 267, 273, 279, 280, 281, 291, 292, 297, 298, 299, 302, 303, 304, 305, 314, 315, 318, 320, 321, 327, 332, 333, 337, 338, 339, 340, 346, 347, 348, 349, 350, 354, 355, 359, 360, 365, 366, 367, 378, 383, 384, 387, 389, 392, 396, 399, 400, 402, 405, 409, 410, 412, 413, 417, 418, 426, 427, 432, 433, 436, 438, 439, 440, 441, 442, 445, 448, 452, 455};
/* BEGIN LINEINFO 
assign 1 343 24
new 0 343 24
new 1 343 25
assign 1 347 29
new 0 347 29
fromString 1 348 30
assign 1 352 34
return 1 356 38
assign 1 360 42
toStringWithSeparator 1 360 42
return 1 360 43
assign 1 364 49
split 1 364 49
assign 1 365 50
new 0 365 50
assign 1 365 51
join 2 365 51
return 1 366 52
assign 1 370 56
split 1 370 56
return 1 370 57
assign 1 374 62
split 1 374 62
assign 1 374 63
firstGet 0 374 63
return 1 374 64
assign 1 378 69
split 1 378 69
assign 1 378 70
lastGet 0 378 70
return 1 378 71
assign 1 382 90
pathGet 0 382 90
assign 1 382 91
new 0 382 91
assign 1 382 92
emptyGet 0 382 92
assign 1 382 93
equals 1 382 93
assign 1 383 95
copy 0 383 95
return 1 383 96
assign 1 385 98
isAbsoluteGet 0 385 98
assign 1 386 100
copy 0 386 100
return 1 386 101
assign 1 388 103
split 1 388 103
assign 1 389 104
pathGet 0 389 104
assign 1 389 105
split 1 389 105
assign 1 390 106
iteratorGet 0 390 106
assign 1 390 109
hasNextGet 0 390 109
assign 1 391 111
nextGet 0 391 111
addValue 1 392 112
assign 1 394 118
new 0 394 118
assign 1 394 119
join 2 394 119
assign 1 395 120
copy 0 395 120
assign 1 396 121
fromString 1 396 121
return 1 398 122
assign 1 402 135
split 1 402 135
assign 1 403 136
copy 0 403 136
assign 1 404 137
new 0 404 137
pathSet 1 404 138
assign 1 405 139
lengthGet 0 405 139
assign 1 406 140
decrement 0 406 140
assign 1 407 141
new 0 407 141
assign 1 408 142
iteratorGet 0 408 142
assign 1 408 145
hasNextGet 0 408 145
assign 1 409 147
lesser 1 409 147
assign 1 410 149
nextGet 0 410 149
addStep 1 410 150
nextGet 0 412 153
assign 1 414 155
increment 0 414 155
assign 1 416 161
isAbsoluteGet 0 416 161
makeAbsolute 0 417 163
return 1 419 165
assign 1 423 180
undef 1 423 185
assign 1 0 186
assign 1 423 189
toString 0 423 189
assign 1 423 190
sizeGet 0 423 190
assign 1 423 191
new 0 423 191
assign 1 423 192
lesser 1 423 192
assign 1 0 194
assign 1 0 197
assign 1 423 201
new 0 423 201
return 1 423 202
assign 1 424 204
new 0 424 204
assign 1 424 205
getPoint 1 424 205
assign 1 424 206
equals 1 424 206
assign 1 425 208
new 0 425 208
return 1 425 209
assign 1 427 211
new 0 427 211
return 1 427 212
assign 1 431 218
isAbsoluteGet 0 431 218
assign 1 432 220
new 0 432 220
assign 1 432 221
sizeGet 0 432 221
assign 1 432 222
substring 2 432 222
assign 1 437 229
isAbsoluteGet 0 437 229
assign 1 437 230
not 0 437 230
assign 1 438 232
add 1 438 232
assign 1 443 245
new 0 443 245
assign 1 443 246
greater 1 443 246
makeNonAbsolute 0 444 248
assign 1 445 249
split 1 445 249
assign 1 447 250
firstNodeGet 0 447 250
assign 1 448 251
new 0 448 251
assign 1 448 254
lesser 1 448 254
assign 1 449 256
undef 1 449 261
assign 1 450 264
assign 1 451 265
nextGet 0 451 265
delete 0 452 266
assign 1 448 267
increment 0 448 267
assign 1 454 273
join 2 454 273
assign 1 459 279
split 1 459 279
addValue 1 460 280
assign 1 461 281
join 2 461 281
assign 1 465 291
find 1 465 291
assign 1 466 292
undef 1 466 297
assign 1 467 298
new 0 467 298
assign 1 467 299
emptyGet 0 467 299
assign 1 469 302
new 0 469 302
assign 1 469 303
add 1 469 303
assign 1 469 304
sizeGet 0 469 304
assign 1 469 305
substring 2 469 305
assign 1 474 314
split 1 474 314
assign 1 475 315
iteratorGet 0 475 315
assign 1 475 318
hasNextGet 0 475 318
assign 1 476 320
nextGet 0 476 320
addValue 1 476 321
assign 1 478 327
join 2 478 327
assign 1 482 332
addStep 1 482 332
return 1 482 333
assign 1 486 337
split 1 486 337
addValue 1 487 338
addValue 1 488 339
assign 1 489 340
join 2 489 340
assign 1 493 346
create 0 493 346
copyTo 1 494 347
assign 1 495 348
copy 0 495 348
pathSet 1 495 349
return 1 496 350
assign 1 500 354
split 1 500 354
return 1 500 355
assign 1 504 359
hashGet 0 504 359
return 1 504 360
assign 1 508 365
equals 1 508 365
assign 1 508 366
not 0 508 366
return 1 508 367
assign 1 515 378
undef 1 515 383
assign 1 0 384
assign 1 515 387
otherType 1 515 387
assign 1 0 389
assign 1 0 392
assign 1 0 396
assign 1 515 399
pathGet 0 515 399
assign 1 515 400
notEquals 1 515 400
assign 1 0 402
assign 1 0 405
assign 1 516 409
new 0 516 409
return 1 516 410
assign 1 518 412
new 0 518 412
return 1 518 413
assign 1 522 417
subPath 2 522 417
return 1 522 418
assign 1 526 426
stepsGet 0 526 426
assign 1 527 427
undef 1 527 432
assign 1 528 433
subList 1 528 433
assign 1 530 436
subList 2 530 436
assign 1 532 438
create 0 532 438
separatorSet 1 533 439
assign 1 534 440
join 2 534 440
pathSet 1 534 441
return 1 535 442
return 1 0 445
assign 1 0 448
return 1 0 452
assign 1 0 455
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case 1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 471950299: return bem_lastStepGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case 935459934: return bem_deleteFirstStep_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1719674549: return bem_firstStepGet_0();
case 723109216: return bem_stepsGet_0();
case 1354714650: return bem_copy_0();
case 400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case 1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 630006451: return bem_fromString_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 488966921: return bem_subPath_1((BEC_4_3_MathInt) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1787791811: return bem_addStepList_1((BEC_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case 2006569863: return bem_trimParents_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 488966920: return bem_subPath_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_8_SystemBasePath.bevs_inst = (BEC_6_8_SystemBasePath)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_8_SystemBasePath.bevs_inst;
}
}
}
