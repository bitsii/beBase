namespace be.BEL_4_Base {

using System;
    /* IO:File: source/base/Array.be */
public class BEC_3_9_5_8_ContainerArrayIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_5_8_ContainerArrayIterator() { }
static BEC_3_9_5_8_ContainerArrayIterator() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_3_9_5_8_ContainerArrayIterator bevs_inst;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_5_ContainerArray bevp_list;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_list = (BEC_2_9_5_ContainerArray) (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_3_9_5_8_ContainerArrayIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_5_ContainerArray) beva_a;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_containerGet_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_pos.bem_greater_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_4_tmpvar_phold = bevp_list.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_pos.bem_lesser_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 39 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 39 */
 else  /* Line: 39 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 39 */ {
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /* Line: 40 */
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_currentGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = bevp_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_5_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold = bevp_pos.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevp_list.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_lesser_1(bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
 else  /* Line: 54 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 54 */ {
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 55 */
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_pos = bevp_pos.bem_increment_0();
bevt_0_tmpvar_phold = bevp_list.bem_get_1(bevp_pos);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_pos = bevp_pos.bem_increment_0();
bevt_0_tmpvar_phold = bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
bevp_pos = bevp_pos.bem_add_1(beva_multiNullCount);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerArray bem_listGet_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_list = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {24, 25, 30, 31, 35, 39, 0, 40, 42, 46, 50, 54, 0, 55, 57, 61, 62, 66, 67, 71, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18};
/* BEGIN LINEINFO 
assign 1 24 18
new 0 24 18
assign 1 25 18
new 0 25 18
assign 1 25 18
new 1 25 18
assign 1 30 18
new 0 30 18
assign 1 31 18
return 1 35 18
assign 1 39 18
new 0 39 18
assign 1 39 18
greater 1 39 18
assign 1 39 18
lengthGet 0 39 18
assign 1 39 18
lesser 1 39 18
assign 1 0 18
assign 1 0 18
assign 1 0 18
assign 1 40 18
new 0 40 18
return 1 40 18
assign 1 42 18
new 0 42 18
return 1 42 18
assign 1 46 18
get 1 46 18
return 1 46 18
assign 1 50 18
put 2 50 18
return 1 50 18
assign 1 54 18
new 0 54 18
assign 1 54 18
greaterEquals 1 54 18
assign 1 54 18
new 0 54 18
assign 1 54 18
add 1 54 18
assign 1 54 18
lengthGet 0 54 18
assign 1 54 18
lesser 1 54 18
assign 1 0 18
assign 1 0 18
assign 1 0 18
assign 1 55 18
new 0 55 18
return 1 55 18
assign 1 57 18
new 0 57 18
return 1 57 18
assign 1 61 18
increment 0 61 18
assign 1 62 18
get 1 62 18
return 1 62 18
assign 1 66 18
increment 0 66 18
assign 1 67 18
put 2 67 18
return 1 67 18
assign 1 71 18
add 1 71 18
return 1 0 18
assign 1 0 18
return 1 0 18
assign 1 0 18
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 715968403: return bem_posGet_0();
case 1246679159: return bem_listGet_0();
case 1693924536: return bem_hasCurrentGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1446310798: return bem_currentGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1235596906: return bem_listSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_5_8_ContainerArrayIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_5_8_ContainerArrayIterator.bevs_inst = (BEC_3_9_5_8_ContainerArrayIterator)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_5_8_ContainerArrayIterator.bevs_inst;
}
}
}
